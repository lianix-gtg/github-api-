// src/data/tgQueue.js
// Antrian pengiriman pesan Telegram GLOBAL.
//
// Kenapa ini dibutuhin:
// Sebelumnya beberapa fitur (contoh: /autoga di index.js) nembak
// bot.sendMessage() ke banyak chat_id sekaligus TANPA jeda. Telegram
// punya batas ~30 request/detik per bot (global) dan ~1 pesan/detik per
// chat. Kalau kelewatan, Telegram bisa nge-flood-limit SELURUH bot
// (bukan cuma fitur yang bikin) selama beberapa menit sampai belasan jam
// (retry_after). Efeknya: fitur lain yang sama sekali gak salah (misal
// "Chat Owner" di relaychat.js) ikut ke-block dan tiba-tiba error 429
// padahal kodenya gak diubah.
//
// Modul ini nyediain satu "jalur" bareng buat semua fitur kirim pesan:
// - MIN_GAP_MS  -> jaga jarak antar request secara global.
// - PER_CHAT_GAP_MS -> jaga jarak per chat_id yang sama.
// - Kalau tetep kena 429, otomatis nunggu sesuai retry_after dari
//   Telegram lalu di-retry (maks MAX_RETRY kali) alih-alih langsung
//   gagal dan lempar error ke user.
//
// Cara pakai (lihat contoh di relaychat.js / index.js):
//   const { enqueueSend } = require("./data/tgQueue");
//   const sent = await enqueueSend(() => bot.sendMessage(chatId, text, opts), chatId);

const MIN_GAP_MS = 40;        // ~25 request/detik total, di bawah limit global Telegram (~30/detik)
const PER_CHAT_GAP_MS = 1100; // per chat_id, jangan lebih dari ~1 pesan/detik
const MAX_RETRY = 3;

let queueTail = Promise.resolve();
const lastSentPerChat = {};

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// Ambil nilai retry_after (detik) dari error node-telegram-bot-api, dengan
// fallback parse dari message kalau strukturnya beda-beda antar versi lib.
function getRetryAfterMs(err) {
  const ra =
    err?.response?.body?.parameters?.retry_after ??
    err?.response?.parameters?.retry_after ??
    err?.parameters?.retry_after;

  if (ra) return (Number(ra) + 1) * 1000;

  const m = /retry after (\d+)/i.exec(err?.message || "");
  return m ? (Number(m[1]) + 1) * 1000 : null;
}

function isFlood429(err) {
  const code = err?.response?.statusCode || err?.response?.body?.error_code;
  return code === 429 || /\b429\b/.test(err?.message || "");
}

/**
 * Jalanin fn() (fungsi yang manggil method Telegram, misal
 * `() => bot.sendMessage(chatId, text)`) lewat antrian global + throttle
 * per-chat, dan auto-retry kalau kena flood limit (429).
 *
 * @param {() => Promise<any>} fn - pemanggil method Telegram, dibungkus arrow function.
 * @param {string|number} [chatId] - dipakai buat jaga jarak per-chat. Boleh dikosongin.
 * @returns {Promise<any>}
 */
function enqueueSend(fn, chatId) {
  const runner = queueTail.then(async () => {
    if (chatId !== undefined && chatId !== null) {
      const key = String(chatId);
      const last = lastSentPerChat[key] || 0;
      const waitMs = last + PER_CHAT_GAP_MS - Date.now();
      if (waitMs > 0) await wait(waitMs);
      lastSentPerChat[key] = Date.now();
    }

    let lastErr;
    for (let attempt = 0; attempt <= MAX_RETRY; attempt++) {
      try {
        const result = await fn();
        await wait(MIN_GAP_MS);
        return result;
      } catch (err) {
        lastErr = err;
        if (isFlood429(err) && attempt < MAX_RETRY) {
          const delayMs = getRetryAfterMs(err) || 3000;
          console.error(
            `[tgQueue] Kena 429, nunggu ${Math.ceil(delayMs / 1000)}s sebelum retry (percobaan ${attempt + 1}/${MAX_RETRY})...`
          );
          await wait(delayMs);
          continue;
        }
        throw err;
      }
    }
    throw lastErr;
  });

  // Pastiin error di satu task gak nge-block antrian buat task-task
  // berikutnya (task berikutnya tetep jalan meski task ini reject).
  queueTail = runner.catch(() => {});

  return runner;
}

module.exports = { enqueueSend, isFlood429, getRetryAfterMs };
