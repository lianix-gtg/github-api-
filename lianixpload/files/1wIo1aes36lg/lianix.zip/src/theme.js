// src/theme.js
// ============================================================
//  THEME ENGINE - ganti "warna" tampilan menu utama.
//  Telegram gak punya API buat ngewarnain teks/tombol beneran,
//  jadi "warna" di sini disimulasikan lewat kombinasi border
//  unicode + emoji kotak warna di depan judul & tiap tombol.
//  Ada mode auto-cycle: ganti tema sendiri tiap 1 detik / 10 detik,
//  dikontrol lewat Dev Panel (khusus Owner).
// ============================================================

// Telegram InlineKeyboardButton tidak menerima properti `style` pada payload
// yang dipakai project ini. Tema hanya memengaruhi label/dekorasi; jangan
// pernah meneruskan `style` ke reply_markup karena satu field ilegal dapat
// membuat seluruh keyboard ditolak Telegram.
const THEMES = [
  { key: "primary", name: "Biru", style: "primary", deco: "🔵", accent: "🔵" },
  { key: "success", name: "Hijau", style: "success", deco: "🟢", accent: "🟢" },
  { key: "danger", name: "Merah", style: "danger", deco: "🔴", accent: "🔴" },
  { key: "mono", name: "Netral", style: null, deco: "⚪", accent: "⚪" },
];

let currentIndex = 0;
let cycling = false;
// Auto Cycle default aktif setelah bot siap. Interval aman 10 detik.
let intervalMs = 10000; // default 10 detik; aman dari rate-limit Telegram
let timer = null;
let lastBot = null;
let lastBuildFn = null;
let watchdog = null;

// registry pesan menu utama yang lagi kebuka, biar bisa di-refresh
// otomatis pas tema ganti. key = chatId (string)
const registry = new Map();

function getTheme() {
  return THEMES[currentIndex];
}

// Nempelin field `style` resmi Telegram ke sebuah tombol, sesuai tema
// yang lagi aktif (atau tema yang di-pass manual). Kalau style-nya null
// (tema mono), field style sengaja gak ditambahin sama sekali.
function cleanButtonLabel(value, callbackData) {
  const original = String(value ?? '');
  if (/buy script|dev panel/i.test(original)) return original;

  const normalized = original.normalize('NFKC');
  const controlCallback = String(callbackData || '');
  const isControl = /(?:^|[:_])(plus|minus|inc|dec|increase|decrease|adjust|threshold_(?:up|down)|cpu_(?:up|down)|disk_(?:up|down)|add|del)(?:$|[:_\-])/i.test(controlCallback);
  const controlOnly = /^[+−–—±＋－➕➖-]\s*$/.test(normalized);

  const statusPrefix = normalized.includes('🟢') ? '🟢 ' : normalized.includes('🔴') ? '🔴 ' : '';
  let cleaned = normalized
    // Hapus ikon dekoratif umum. Status ON/OFF hijau/merah dipertahankan secara eksplisit.
    .replace(/[\p{Extended_Pictographic}\u200B-\u200D\uFE0E\uFE0F\u{1F3FB}-\u{1F3FF}]/gu, '')
    // Hapus dekorasi visual yang memang bukan bagian dari teks button.
    .replace(/[•·◆◇◈◉⟐⟡⌖↯◌✦✧★☆✓✔✕✖⚙▣◒]/gu, '')
    .replace(/\s{2,}/g, ' ')
    .trim();

  // Kontrol +/- harus tetap ada karena memang merupakan bagian dari fungsi.
  if (isControl || controlOnly) {
    const controlPrefix = normalized.match(/^[\s]*(?:\+|-|−|–|—|±|＋|－|➕|➖)/u);
    if (controlPrefix) {
      cleaned = controlPrefix[0].trim() + (cleaned.replace(/^[+−–—±＋－➕➖-]\s*/u, '') ? ' ' + cleaned.replace(/^[+−–—±＋－➕➖-]\s*/u, '') : '');
    }
  }

  // Jangan mengganti tombol ikon dengan placeholder "Back". Ikon asli
  // harus tetap terlihat dan tidak boleh berubah menjadi tombol palsu.
  cleaned = cleaned.replace(/^(?:ON|OFF)\s*[•·-]?\s*/i, m => m);
  return (statusPrefix + (cleaned || normalized.trim() || 'Menu')).trim();
}

function styled(btn, t) {
  const theme_ = t || getTheme();
  const normalized = { ...btn };
  if (Object.prototype.hasOwnProperty.call(normalized, 'text')) {
    normalized.text = cleanButtonLabel(normalized.text, normalized.callback_data);
  }
  // Telegram Bot API tidak mendukung properti `style`, jadi perubahan tema
  // divisualisasikan lewat marker warna di label tombol. Ini membuat auto-cycle
  // benar-benar terlihat tanpa mengirim field ilegal ke Telegram.
  if (normalized.text && theme_?.accent && !/^(?:🔵|🟢|🔴|⚪)/u.test(normalized.text)) {
    normalized.text = `${theme_.accent} ${normalized.text}`;
  }
  return normalized;
}

function getThemeList() {
  return THEMES;
}

function setThemeIndex(i) {
  if (i < 0 || i >= THEMES.length) return getTheme();
  currentIndex = i;
  return getTheme();
}

function nextTheme() {
  currentIndex = (currentIndex + 1) % THEMES.length;
  return getTheme();
}

function registerMenuMessage(chatId, messageId, userId, username) {
  const key = String(chatId);
  const previous = registry.get(key);
  // A chat may only have one canonical dashboard registered. If a fallback
  // created a new message, remove the previous dashboard so its old buttons
  // can never remain visible beside the new UI.
  if (previous && String(previous.messageId) !== String(messageId)) {
    try {
      if (global.__lianixBotForMenuRegistry?.deleteMessage) {
        global.__lianixBotForMenuRegistry.deleteMessage(chatId, previous.messageId).catch(() => {});
      }
    } catch {}
  }
  registry.set(key, { messageId, userId, username });
}

function unregisterMenuMessage(chatId) {
  registry.delete(String(chatId));
}

function bindMenuBot(bot) {
  global.__lianixBotForMenuRegistry = bot;
}

// buildFn(userId, username) harus balikin { text, reply_markup }
async function refreshAllRegistered(bot, buildFn) {
  if (!bot) return;
  for (const [chatId, { messageId, userId, username }] of registry.entries()) {
    try {
      const { text, reply_markup } = buildFn(userId, username);
      const opts = { chat_id: chatId, message_id: messageId, parse_mode: "HTML", reply_markup };
      try {
        await bot.editMessageText(text, opts);
      } catch (firstErr) {
        const desc = String(firstErr?.response?.body?.description || firstErr?.message || firstErr || "");
        if (/message is not modified/i.test(desc)) continue;
        if (/there is no text in the message to edit/i.test(desc)) {
          try { await bot.editMessageCaption(text, opts); } catch (captionErr) {
            const cdesc = String(captionErr?.response?.body?.description || captionErr?.message || captionErr || "");
            if (!/message is not modified/i.test(cdesc)) throw captionErr;
          }
        } else {
          throw firstErr;
        }
      }
    } catch (e) {
      const desc = e?.response?.body?.description || e.message || "";
      // pesan udah kehapus / chat diblokir / dll -> bersihin biar ga nyoba terus
      if (/not found|chat not found|blocked|kicked/i.test(desc)) {
        registry.delete(chatId);
      }
      // error "message is not modified" -> aman, diemin aja
    }
  }
}

function startAutoCycle(bot, buildFn, ms) {
  if (!bot || typeof buildFn !== "function") return false;
  if (ms && Number.isFinite(Number(ms)) && Number(ms) >= 500) intervalMs = Number(ms);

  lastBot = bot;
  lastBuildFn = buildFn;
  if (timer) clearInterval(timer);
  if (watchdog) clearInterval(watchdog);

  cycling = true;
  timer = setInterval(() => {
    nextTheme();
    Promise.resolve(refreshAllRegistered(lastBot, lastBuildFn)).catch(() => {});
  }, intervalMs);

  // Self-heal: bila ada modul lain yang membersihkan timer atau timer mati,
  // Auto Cycle dibuat lagi tanpa perlu Owner menekan tombol ON.
  watchdog = setInterval(() => {
    if (!cycling || !lastBot || typeof lastBuildFn !== "function") return;
    if (!timer) {
      timer = setInterval(() => {
        nextTheme();
        Promise.resolve(refreshAllRegistered(lastBot, lastBuildFn)).catch(() => {});
      }, intervalMs);
    }
  }, 30000);
  return true;
}

function stopAutoCycle() {
  cycling = false;
  if (timer) clearInterval(timer);
  if (watchdog) clearInterval(watchdog);
  timer = null;
  watchdog = null;
}

function isCycling() {
  return cycling;
}

function getIntervalMs() {
  return intervalMs;
}

function setIntervalMs(ms) {
  intervalMs = ms;
  if (cycling) {
    // restart pake interval baru, tapi butuh bot+buildFn lagi dari luar,
    // jadi ini cuma nyimpen nilainya -> caller yang panggil ulang startAutoCycle
  }
  return intervalMs;
}

module.exports = {
  THEMES,
  getTheme,
  getThemeList,
  setThemeIndex,
  nextTheme,
  styled,
  registerMenuMessage,
  unregisterMenuMessage,
  bindMenuBot,
  startAutoCycle,
  stopAutoCycle,
  isCycling,
  getIntervalMs,
  setIntervalMs,
};
