const fs = require("fs");
const roleAccess = require("./roleAccess");
const { Client } = require("ssh2");
const path = require("path");
const axios = require("axios");
const settings = require("../settings.js");

const escapeHtml = (value) =>
  String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");


/**
 * safeReply — sendMessage with reply_to_message_id fallback.
 * Jika pesan asli sudah dihapus, retry tanpa reply daripada throw error.
 */
async function safeReply(bot, chatId, text, opts = {}) {
  try {
    return await bot.sendMessage(chatId, text, opts);
  } catch (err) {
    const desc = String(err?.response?.body?.description || err?.message || '');
    if (/message to be replied not found/i.test(desc) && opts.reply_to_message_id) {
      const { reply_to_message_id: _, ...safeOpts } = opts;
      return await bot.sendMessage(chatId, text, safeOpts);
    }
    throw err;
  }
}
const ownerStore = require("./data/ownerStore.js");
const { checkLimit, consumeLimit } = require("./limit.js");
const channelStore = require("./data/channelStore.js");
const OWNER_ID = "./db/onlyID.json";
const OWNER_UID = settings.ownerId;
const CPU_CHECK_STATUS_FILE = "./db/cekcpu.json";
const ALLOWED_GROUP_ID = settings.groupId;

const {
    domain,
    plta,
    pltc,
    domain_adp, 
    plta_adp, 
    pltc_adp, 
    domainV2,
    pltaV2,
    pltcV2,
    domainV3,
    pltaV3,
    pltcV3,
    domainV4,
    pltaV4,
    pltcV4,
    domainV5,
    pltaV5,
    pltcV5,
    domainV6,
    pltaV6,
    pltcV6,
    domainV7,
    pltaV7,
    pltcV7,
    domainV8,
    pltaV8,
    pltcV8,
    domainV9,
    pltaV9,
    pltcV9,
    domainV10,
    pltaV10,
    pltcV10,
    domainV11,
    pltaV11,
    pltcV11,
    domainV12,
    pltaV12,
    pltcV12,
    domainV13,
    pltaV13,
    pltcV13,
    domainV14,
    pltaV14,
    pltcV14,
    domainV15,
    pltaV15,
    pltcV15,
    domainV16,
    pltaV16,
    pltcV16,
    domainV17,
    pltaV17,
    pltcV17,
    domainV18,
    pltaV18,
    pltcV18,
    domainV19,
    pltaV19,
    pltcV19,
    domainV20,
    pltaV20,
    pltcV20,
    eggs,
    eggsPython,
    dockerImagePython,
    loc,
    dev,
    panel
} = settings;


// ===== Notifikasi Channel: tampilan Admin Panel =====
async function sendPanelToChannel(bot, { type, username, uid, domainUrl, createdBy, runtimeLabel, serverLabel, targetTgId, targetUsername }) {
  const channelId = settings.notifChannelId;
  if (!channelId) return;

  const safe = (v) => sanitizeHtml(v ?? "-");
  const rtLabel = runtimeLabel || "Node.js";
  const srvLabel = serverLabel || (String(type || "").match(/V\d+/i)?.[0] || "V1").toUpperCase();
  const targetLabel = targetUsername
    ? `@${String(targetUsername).replace(/^@/, "")}`
    : (targetTgId ? `<code>${safe(targetTgId)}</code>` : "-");

  const isAdminPanel = /admin\s*panel/i.test(String(type || ""));
  const notifTitle = isAdminPanel
    ? "🛡️ ADMIN PANEL BERHASIL DIBUAT"
    : "✅ PANEL BERHASIL DIBUAT";

  const caption =
    `<b>${notifTitle}</b>\n\n` +
    `<blockquote expandable>` +
    `<b>📋 INFORMASI PANEL</b>\n` +
    `├ <b>Jenis</b> : <code>${safe(type)}</code>\n` +
    `├ <b>ID</b> : <code>${safe(uid)}</code>\n` +
    `├ <b>Username</b> : <code>${safe(username)}</code>\n` +
    `├ <b>Server</b> : <b>${safe(srvLabel)}</b>\n` +
    `├ <b>Runtime</b> : ${safe(rtLabel)}\n` +
    `├ <b>Penerima</b> : ${targetLabel}\n` +
    `└ <b>Dibuat oleh</b> : ${safe(createdBy || "-")}` +
    `</blockquote>\n\n` +
    `<b>🟢 Status:</b> <b>AKTIF</b>\n` +
    `<i>🔐 Password tidak ditampilkan di channel demi keamanan.</i>`;

  const keyboard = { inline_keyboard: domainUrl ? [[{ text: "🌐 BUKA PANEL", url: domainUrl }]] : [] };
  try {
    await bot.sendPhoto(channelId, settings.notifChannelImage, { caption, parse_mode: "HTML", reply_markup: keyboard });
  } catch (err) {
    try { await bot.sendMessage(channelId, caption, { parse_mode: "HTML", reply_markup: keyboard }); }
    catch (err2) { console.error("[sendPanelToChannel] gagal:", err2.response?.body?.description || err2.message); }
  }
}

// database cooldown
const COOLDOWN_FILE = "./db/cooldown.json";
const cooldowns = {};

let sock = null;
const versions = {
  1: { domain: "domain", plta: "plta", pltc: "pltc" },
  2: { domain: "domainV2", plta: "pltaV2", pltc: "pltcV2" },
  3: { domain: "domainV3", plta: "pltaV3", pltc: "pltcV3" },
  4: { domain: "domainV4", plta: "pltaV4", pltc: "pltcV4" },
  5: { domain: "domainV5", plta: "pltaV5", pltc: "pltcV5" },
  6: { domain: "domainV6", plta: "pltaV6", pltc: "pltcV6" },
  7: { domain: "domainV7", plta: "pltaV7", pltc: "pltcV7" },
  8: { domain: "domainV8", plta: "pltaV8", pltc: "pltcV8" },
  9: { domain: "domainV9", plta: "pltaV9", pltc: "pltcV9" },
  10: { domain: "domainV10", plta: "pltaV10", pltc: "pltcV10" },
  11: { domain: "domainV11", plta: "pltaV11", pltc: "pltcV11" },
  12: { domain: "domainV12", plta: "pltaV12", pltc: "pltcV12" },
  13: { domain: "domainV13", plta: "pltaV13", pltc: "pltcV13" },
  14: { domain: "domainV14", plta: "pltaV14", pltc: "pltcV14" },
  15: { domain: "domainV15", plta: "pltaV15", pltc: "pltcV15" },
  16: { domain: "domainV16", plta: "pltaV16", pltc: "pltcV16" },
  17: { domain: "domainV17", plta: "pltaV17", pltc: "pltcV17" },
  18: { domain: "domainV18", plta: "pltaV18", pltc: "pltcV18" },
  19: { domain: "domainV19", plta: "pltaV19", pltc: "pltcV19" },
  20: { domain: "domainV20", plta: "pltaV20", pltc: "pltcV20" }
};
const domainMap = {
  "1": domain,
  "2": domainV2,
  "3": domainV3,
  "4": domainV4,
  "5": domainV5,
  "6": domainV6,
  "7": domainV7,
  "8": domainV8,
  "9": domainV9,
  "10": domainV10,
  "11": domainV11,
  "12": domainV12,
  "13": domainV13,
  "14": domainV14,
  "15": domainV15,
  "16": domainV16,
  "17": domainV17,
  "18": domainV18,
  "19": domainV19,
  "20": domainV20
};

const pltaMap = {
  "1": plta,
  "2": pltaV2,
  "3": pltaV3,
  "4": pltaV4,
  "5": pltaV5,
  "6": pltaV6,
  "7": pltaV7,
  "8": pltaV8,
  "9": pltaV9,
  "10": pltaV10,
  "11": pltaV11,
  "12": pltaV12,
  "13": pltaV13,
  "14": pltaV14,
  "15": pltaV15,
  "16": pltaV16,
  "17": pltaV17,
  "18": pltaV18,
  "19": pltaV19,
  "20": pltaV20
};

const pltcMap = {
  "1": pltc,
  "2": pltcV2,
  "3": pltcV3,
  "4": pltcV4,
  "5": pltcV5,
  "6": pltcV6,
  "7": pltcV7,
  "8": pltcV8,
  "9": pltcV9,
  "10": pltcV10,
  "11": pltcV11,
  "12": pltcV12,
  "13": pltcV13,
  "14": pltcV14,
  "15": pltcV15,
  "16": pltcV16,
  "17": pltcV17,
  "18": pltcV18,
  "19": pltcV19,
  "20": pltcV20
};
function loadCooldown() {
  if (!fs.existsSync(COOLDOWN_FILE)) {
    fs.writeFileSync(COOLDOWN_FILE, JSON.stringify({ globalCooldown: 5000 }, null, 2));
  }
  return JSON.parse(fs.readFileSync(COOLDOWN_FILE));
}

function saveCooldown(data) {
  fs.writeFileSync(COOLDOWN_FILE, JSON.stringify(data, null, 2));
}
function checkCooldown(msg) {
  const db = loadCooldown();
  const userId = msg.from.id.toString();
  const now = Date.now();

  if (!cooldowns[userId]) {
    cooldowns[userId] = now;
    return false;
  }

  const diff = now - cooldowns[userId];
  if (diff < db.globalCooldown) {
    const sisa = Math.ceil((db.globalCooldown - diff) / 1000);
    return `⏳ Tunggu ${sisa} detik lagi sebelum pakai command ini!`;
  }

  cooldowns[userId] = now;
  return false;
}

// fungsi load json file
function loadJsonData(filename) {
    try {
        if (fs.existsSync(filename)) {
            const data = fs.readFileSync(filename, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {
        console.error(`Error loading ${filename}:`, error);
    }
    return [];
}
// fungsi save json file
function saveJsonData(filename, data) {
    try {
        fs.writeFileSync(filename, JSON.stringify(data, null, 4));
        return true;
    } catch (error) {
        console.error(`Error saving ${filename}:`, error);
        return false;
    }
}
function sanitizeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function asHtmlBlockFromPlain(captionPlain) {
  const safeHtml = sanitizeHtml(captionPlain);
  return `<blockquote expandable><pre>${safeHtml}</pre></blockquote>`;
}
const OWNER_FILE = './db/users/adminID.json';

const PREMIUM_FILE = './db/users/premiumUsers.json';
const PREMV2_FILE = './db/users/version/premiumV2.json';
const PREMV3_FILE = './db/users/version/premiumV3.json';
const PREMV4_FILE = './db/users/version/premiumV4.json';
const PREMV5_FILE = './db/users/version/premiumV5.json';
const PREMV6_FILE = './db/users/version/premiumV6.json';
const PREMV7_FILE = './db/users/version/premiumV7.json';
const PREMV8_FILE = './db/users/version/premiumV8.json';
const PREMV9_FILE = './db/users/version/premiumV9.json';
const PREMV10_FILE = './db/users/version/premiumV10.json';
const PREMV11_FILE = './db/users/version/premiumV11.json';
const PREMV12_FILE = './db/users/version/premiumV12.json';
const PREMV13_FILE = './db/users/version/premiumV13.json';
const PREMV14_FILE = './db/users/version/premiumV14.json';
const PREMV15_FILE = './db/users/version/premiumV15.json';
const PREMV16_FILE = './db/users/version/premiumV16.json';
const PREMV17_FILE = './db/users/version/premiumV17.json';
const PREMV18_FILE = './db/users/version/premiumV18.json';
const PREMV19_FILE = './db/users/version/premiumV19.json';
const PREMV20_FILE = './db/users/version/premiumV20.json';

const RESS_FILE = './db/users/resellerUsers.json';
const RESSV2_FILE = './db/users/version/resellerV2.json';
const RESSV3_FILE = './db/users/version/resellerV3.json';
const RESSV4_FILE = './db/users/version/resellerV4.json';
const RESSV5_FILE = './db/users/version/resellerV5.json';
const RESSV6_FILE = './db/users/version/resellerV6.json';
const RESSV7_FILE = './db/users/version/resellerV7.json';
const RESSV8_FILE = './db/users/version/resellerV8.json';
const RESSV9_FILE = './db/users/version/resellerV9.json';
const RESSV10_FILE = './db/users/version/resellerV10.json';
const RESSV11_FILE = './db/users/version/resellerV11.json';
const RESSV12_FILE = './db/users/version/resellerV12.json';
const RESSV13_FILE = './db/users/version/resellerV13.json';
const RESSV14_FILE = './db/users/version/resellerV14.json';
const RESSV15_FILE = './db/users/version/resellerV15.json';
const RESSV16_FILE = './db/users/version/resellerV16.json';
const RESSV17_FILE = './db/users/version/resellerV17.json';
const RESSV18_FILE = './db/users/version/resellerV18.json';
const RESSV19_FILE = './db/users/version/resellerV19.json';
const RESSV20_FILE = './db/users/version/resellerV20.json';

module.exports = (bot) => {
const featureLocks = require("./featureLocks.js");
const ADP_FILE = "./db/panel.json";

function loadPanelDB() {
  if (!fs.existsSync("./db")) fs.mkdirSync("./db");
  if (!fs.existsSync(ADP_FILE)) {
    fs.writeFileSync(
      ADP_FILE,
      JSON.stringify(
        {
          panelres: true,
          paneladp: true,
          adp: true
        },
        null,
        2
      )
    );
  }
  return JSON.parse(fs.readFileSync(ADP_FILE));
}

function savePanelDB(data) {
  fs.writeFileSync(ADP_FILE, JSON.stringify(data, null, 2));
}

function getPanelAdp() {
  const db = loadPanelDB();
  return db.paneladp;
}

function setPanelAdp(status) {
  const db = loadPanelDB();
  db.paneladp = status;
  savePanelDB(db);
}

function getAdpMode() {
  const db = loadPanelDB();
  return db.adp;
}

function setAdpMode(status) {
  const db = loadPanelDB();
  db.adp = status;
  savePanelDB(db);
}


// ================= FEATURE LOCK: ADP / UNLI =================
async function isFeatureAdmin(msg) {
  if (String(msg.from?.id) === String(OWNER_UID)) return true;
  if (!["group", "supergroup"].includes(msg.chat?.type)) return false;
  try {
    const m = await bot.getChatMember(msg.chat.id, msg.from.id);
    return ["creator", "administrator"].includes(m.status);
  } catch {
    return false;
  }
}

function featureLockKeyboard() {
  const adp = featureLocks.isAdpLocked();
  const unli = featureLocks.isUnliLocked();
  return {
    reply_markup: {
      inline_keyboard: [
        [
          { text: adp ? "Unlock ADP" : "Lock ADP", callback_data: `featurelock:adp:${adp ? "off" : "on"}` },
          { text: unli ? "Unlock UNLI" : "Lock UNLI", callback_data: `featurelock:unli:${unli ? "off" : "on"}` }
        ]
      ]
    }
  };
}

async function handleFeatureLock(msg, type, locked) {
  if (!(await isFeatureAdmin(msg))) {
    return bot.sendMessage(msg.chat.id, "<blockquote expandable>◇ <b>Fitur ini khusus admin.</b></blockquote>", { parse_mode: "HTML" });
  }
  if (type === "adp") featureLocks.setAdpLocked(locked, msg.from.id);
  else featureLocks.setUnliLocked(locked, msg.from.id);
  return bot.sendMessage(
    msg.chat.id,
    `<blockquote expandable>${locked ? "🔒" : "🔓"} <b>${type.toUpperCase()} ${locked ? "DI-LOCK" : "DI-UNLOCK"}</b>\n\n${featureLocks.statusText()}</blockquote>`,
    { parse_mode: "HTML", ...featureLockKeyboard() }
  );
}

// Prefix + no-prefix. Exact match only supaya tidak mengganggu pesan biasa.
bot.onText(/^\/?lockadp(?:@\w+)?$/i, msg => handleFeatureLock(msg, "adp", true));
bot.onText(/^\/?unlockadp(?:@\w+)?$/i, msg => handleFeatureLock(msg, "adp", false));
bot.onText(/^\/?lockunli(?:@\w+)?$/i, msg => handleFeatureLock(msg, "unli", true));
bot.onText(/^\/?unlockunli(?:@\w+)?$/i, msg => handleFeatureLock(msg, "unli", false));
bot.onText(/^\/?featurelock(?:@\w+)?$/i, async msg => {
  if (!(await isFeatureAdmin(msg))) {
    return bot.sendMessage(msg.chat.id, "<blockquote expandable>◇ <b>Fitur ini khusus admin.</b></blockquote>", { parse_mode: "HTML" });
  }
  return bot.sendMessage(msg.chat.id, `<blockquote expandable>${featureLocks.statusText()}</blockquote>`, { parse_mode: "HTML", ...featureLockKeyboard() });
});

bot.on("callback_query", async q => {
  const data = String(q.data || "");
  if (!data.startsWith("featurelock:")) return;
  const [_, type, action] = data.split(":");
  const msg = q.message;
  if (!msg) return;
  const fake = { from: q.from, chat: msg.chat };
  if (!(await isFeatureAdmin(fake))) {
    return bot.answerCallbackQuery(q.id, { text: "Khusus admin.", show_alert: true }).catch(() => {});
  }
  if (type === "adp") featureLocks.setAdpLocked(action === "on", q.from.id);
  if (type === "unli") featureLocks.setUnliLocked(action === "on", q.from.id);
  await bot.answerCallbackQuery(q.id).catch(() => {});
  return bot.editMessageText(`<blockquote expandable>${featureLocks.statusText()}</blockquote>`, {
    chat_id: msg.chat.id,
    message_id: msg.message_id,
    parse_mode: "HTML",
    ...featureLockKeyboard()
  }).catch(() => {});
});

bot.onText(/^\/paneladp (on|off)$/i, (msg, match) => {
  const chatId = msg.chat.id;

  if (!settings.isOwner(msg.from.id)) {
    return bot.sendMessage(chatId, "◇ Hanya owner yang bisa menggunakan fitur ini.");
  }

  const mode = match[1].toLowerCase();

  if (mode === "on") {
    setPanelAdp(true);
    bot.sendMessage(chatId, "◉ Create Admin Panel berhasil diaktifkan.");
  } else {
    setPanelAdp(false);
    bot.sendMessage(chatId, "⊘ Create Admin Panel dimatikan.");
  }
});

bot.onText(/^\/adp (on|off)$/i, (msg, match) => {
  const chatId = msg.chat.id;

  if (!settings.isOwner(msg.from.id)) {
    return bot.sendMessage(chatId, "◇ Hanya owner yang bisa menggunakan fitur ini.");
  }

  const mode = match[1].toLowerCase();

  if (mode === "on") {
    setAdpMode(true);
    bot.sendMessage(chatId, "◉ Mode ADP aktif.\nBot akan menggunakan server ADP.");
  } else {
    setAdpMode(false);
    bot.sendMessage(chatId, "⊘ Mode ADP dimatikan.\nBot kembali menggunakan server utama.");
  }
});

bot.onText(/^\/cadp(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  if (featureLocks.isAdpLocked() && String(msg.from?.id) !== String(OWNER_UID)) {
    return bot.sendMessage(chatId, "<blockquote expandable>🔒 <b>CREATE ADP SEDANG DI-LOCK</b>\n\nAdmin sedang menutup akses ADP. Silakan coba lagi nanti.</blockquote>", { parse_mode: "HTML" });
  }

  const userId = msg.from.id;
  const text = match[1] ? match[1].trim() : null;

  if (!getPanelAdp()) {
    return bot.sendMessage(chatId, "⊘ Create Admin Panel sedang dimatikan oleh admin.");
  }

  let useDomain = domain;
  let usePlta = plta;
  let usePltc = pltc;

  if (getAdpMode()) {
    useDomain = domain_adp;
    usePlta = plta_adp;
    usePltc = pltc_adp;
  }

  if ((msg.chat.type !== "group" && msg.chat.type !== "supergroup") && !settings.isOwner(msg.from.id)) {
    return bot.sendMessage(chatId, "◈ Fitur ini khusus grup.");
  }

  const isCooldown = checkCooldown(msg);
  if (isCooldown) return bot.sendMessage(chatId, isCooldown);

  const premiumUsers = JSON.parse(fs.readFileSync(PREMIUM_FILE));
  if (!premiumUsers.includes(String(userId))) {
    return bot.sendMessage(chatId, "◈ Akses ditolak — butuh akses premium.", {
      reply_markup: {
        inline_keyboard: [[{ text: "ʟᴀᴘᴏʀᴀɴ", url: `https://t.me/${dev}` }]],
      },
    });
  }

  if (!text) {
    return bot.sendMessage(chatId, "◇ Format Salah!\nContoh:\n/cadp namapanel\n/cadp namapanel,idtele");
  }

  let panelName;
  let telegramId;

  const commandParams = text.split(",");

  if (commandParams.length === 1) {
    panelName = commandParams[0].trim();
    telegramId = msg.from.id;
  } else {
    panelName = commandParams[0].trim();
    telegramId = commandParams[1].trim();
  }

  if (!panelName) {
    return bot.sendMessage(chatId, "◇ Nama panel tidak boleh kosong!");
  }

  let finalUsername = panelName;
  let isCreated = false;
  let attempt = 0;

  while (!isCreated && attempt < 10) {
    const password = finalUsername + Math.random().toString(36).slice(2, 5);

    try {
      const response = await fetch(`${useDomain}/api/application/users`, {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${usePlta}`,
        },
        body: JSON.stringify({
          email: `${finalUsername}@gmail.com`,
          username: finalUsername,
          first_name: finalUsername,
          last_name: "admin",
          language: "en",
          root_admin: true,
          password: password,
        }),
      });

      const data = await response.json();

      if (data.errors) {
        const errorDetail = JSON.stringify(data.errors);

        if (errorDetail.toLowerCase().includes("username")) {
          const lastChar = finalUsername.slice(-1);
          finalUsername += lastChar;
          attempt++;
          continue;
        } else {
          return bot.sendMessage(chatId, JSON.stringify(data.errors[0], null, 2));
        }
      }

      const user = data.attributes;

      const userInfo =
        `<b>🛡️ ADMIN PANEL BERHASIL DIBUAT</b>\n\n` +
        `<blockquote expandable><b>📋 DETAIL AKUN</b>\n` +
        `🆔 <b>ID</b> : <code>${sanitizeHtml(user.id)}</code>\n` +
        `👤 <b>Username</b> : <code>${sanitizeHtml(user.username)}</code>\n` +
        `📧 <b>Email</b> : <code>${sanitizeHtml(user.email)}</code>\n` +
        `📝 <b>Nama</b> : ${sanitizeHtml(`${user.first_name || ""} ${user.last_name || ""}`.trim())}\n` +
        `🔐 <b>Hak Akses</b> : <b>${user.root_admin ? "ADMIN PANEL" : "USER"}</b></blockquote>\n\n` +
        `<i>Data utama disimpan. Gunakan tombol panel untuk melanjutkan.</i>`;
      bot.sendMessage(chatId, userInfo, { parse_mode: "HTML" });

      await bot.sendPhoto(telegramId, settings.notifChannelImage, {
        caption: `<blockquote expandable>⚿ Sukses Created Admin Panel!</blockquote>
◉ Username : <code>${finalUsername}</code>
⚷ Password : <code>${password}</code>

<blockquote expandable>⬡ Rules Admin Panel</blockquote>
⌁ No Rusuh Panel!
⌁ No DDoS!!
⌁ Simpan data akun
⌁ No Share Free!
`,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [[{ text: "⟐ Domain", url: useDomain }]],
        },
      });

      bot.sendMessage(
        chatId,
        `◉ *Berhasil kirim Admin Panel ke @${msg.from.username}*\n(ID: ${telegramId})`,
        { parse_mode: "Markdown", reply_to_message_id: msg.message_id }
      );

      sendPanelToChannel(bot, {
        type: "ADMIN PANEL",
        username: finalUsername,
        uid: user.id,
        domainUrl: useDomain,
        createdBy: msg.from.username ? `@${msg.from.username}` : msg.from.id,
      });

      isCreated = true;

    } catch (error) {
      console.error(error);
      return bot.sendMessage(chatId, "◇ Terjadi kesalahan saat membuat admin panel.");
    }
  }

  if (!isCreated) {
    bot.sendMessage(chatId, "◇ Gagal membuat username unik setelah beberapa percobaan.");
  }
});
bot.onText(/^\/topcpu$/i, async (msg) => {
    const chatId = msg.chat.id;

    const panel = domain;        // langsung variabel
    const API_KEY = plta;        // langsung variabel
    const NODE_API_KEY = pltc;   // langsung variabel

    try {
        const res = await axios.get(`${panel}/api/application/servers`, {
            headers: {
                Authorization: `Bearer ${API_KEY}`,
                Accept: "application/json"
            }
        });

        const servers = res.data.data;
        let results = [];

        await Promise.all(servers.map(async (srv) => {
            try {
                const attr = srv.attributes;

                const nodeRes = await axios.get(`${panel}/api/application/nodes/${attr.node}`, {
                    headers: {
                        Authorization: `Bearer ${API_KEY}`,
                        Accept: "application/json"
                    }
                });

                const node = nodeRes.data.attributes;
                const wingUrl = `http://${node.fqdn}:${node.daemon_listen}`;

                const usage = await axios.get(
                    `${wingUrl}/api/servers/${attr.uuid}/resources`,
                    {
                        headers: {
                            Authorization: `Bearer ${NODE_API_KEY}`,
                            Accept: "application/json"
                        },
                        timeout: 5000
                    }
                );

                const data = usage.data.attributes;

                if (data.current_state === "running") {
                    results.push({
                        name: attr.name,
                        cpu: data.resources.cpu_absolute
                    });
                }

            } catch {}
        }));

        if (!results.length) {
            return bot.sendMessage(chatId, "◇ Tidak ada server aktif");
        }

        results.sort((a, b) => b.cpu - a.cpu);
        const top = results.slice(0, 5);

        let text = "⟡ <b>TOP CPU SERVER</b>\n\n";
        top.forEach((s, i) => {
            text += `${i + 1}. ${s.name}\nCPU: ${s.cpu}%\n\n`;
        });

        bot.sendMessage(chatId, text, { parse_mode: "HTML" });

    } catch {
        bot.sendMessage(chatId, "◇ Gagal ambil data");
    }
});
const RAM_LIMIT_MB = 5120;
const DISK_LIMIT_MB = 5120;
const CHECK_INTERVAL = 60000;

let protectInterval = null;
let isProtectActive = false;

bot.onText(/\/protect (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const args = match[1];

    if (args === "on") {

        if (isProtectActive)
            return bot.sendMessage(chatId, "⚠ Protect sudah aktif!");

        isProtectActive = true;
        protectInterval = setInterval(checkAllServers, CHECK_INTERVAL);

        bot.sendMessage(chatId, "⟠ Protect Aktif");
        checkAllServers();

    } else if (args === "off") {

        if (!isProtectActive)
            return bot.sendMessage(chatId, "⚠ Protect belum aktif!");

        clearInterval(protectInterval);
        protectInterval = null;
        isProtectActive = false;

        bot.sendMessage(chatId, "◇ Protect Dimatikan");

    } else {
        bot.sendMessage(chatId, "Gunakan: /protect on atau /protect off");
    }
});

async function checkAllServers() {
    try {
        const res = await axios.get(`${domain}/api/application/servers`, {
            headers: {
                Authorization: `Bearer ${plta}`,
                Accept: "Application/vnd.pterodactyl.v1+json",
            },
        });

        for (let server of res.data.data) {
            await checkServer(
                server.attributes.id,
                server.attributes.identifier,
                server.attributes.name
            );
        }

    } catch (err) {
        console.error(err.response?.data || err.message);
    }
}

async function checkServer(serverId, identifier, serverName) {
    try {

        const res = await axios.get(
            `${domain}/api/client/servers/${identifier}/resources`,
            {
                headers: {
                    Authorization: `Bearer ${pltc}`,
                    Accept: "Application/vnd.pterodactyl.v1+json",
                },
            }
        );

        const resources = res.data.attributes.resources;

        const ramUsage = resources.memory_bytes / 1024 / 1024;
        const diskUsage = resources.disk_bytes / 1024 / 1024;

        let reason = null;

        if (ramUsage >= RAM_LIMIT_MB)
            reason = `RAM Overload (${ramUsage.toFixed(2)}MB)`;

        if (diskUsage >= DISK_LIMIT_MB)
            reason = `Disk Overload (${diskUsage.toFixed(2)}MB)`;

        if (reason)
            await stopSuspendDelete(serverId, identifier, serverName, reason);

    } catch (err) {
        console.error(err.response?.data || err.message);
    }
}

async function stopSuspendDelete(serverId, identifier, serverName, reason) {
    try {

        // 1⃣ DELETE SEMUA FILE
        const fileList = await axios.get(
            `${domain}/api/client/servers/${identifier}/files/list?directory=/`,
            {
                headers: {
                    Authorization: `Bearer ${pltc}`,
                    Accept: "Application/vnd.pterodactyl.v1+json",
                },
            }
        );

        const files = fileList.data.data.map(f => f.attributes.name);

        if (files.length > 0) {
            await axios.post(
                `${domain}/api/client/servers/${identifier}/files/delete`,
                { root: "/", files: files },
                {
                    headers: {
                        Authorization: `Bearer ${pltc}`,
                        Accept: "Application/vnd.pterodactyl.v1+json",
                        "Content-Type": "application/json",
                    },
                }
            );
        }

        await bot.sendMessage(
            OWNER_UID,
            `⟲ FILE SERVER DI HAPUS\n\n◈ ${serverName}\n⌇ ${serverId}`
        );

        await new Promise(r => setTimeout(r, 2000));

        // 2⃣ STOP SERVER
        await axios.post(
            `${domain}/api/client/servers/${identifier}/power`,
            { signal: "stop" },
            {
                headers: {
                    Authorization: `Bearer ${pltc}`,
                    Accept: "Application/vnd.pterodactyl.v1+json",
                    "Content-Type": "application/json",
                },
            }
        );

        await bot.sendMessage(
            OWNER_UID,
            `⊘ SERVER DI STOP\n\n◈ ${serverName}\n⌇ ${serverId}`
        );

        await new Promise(r => setTimeout(r, 2000));

        // 3⃣ SUSPEND SERVER
        await axios.post(
            `${domain}/api/application/servers/${serverId}/suspend`,
            {},
            {
                headers: {
                    Authorization: `Bearer ${plta}`,
                    Accept: "Application/vnd.pterodactyl.v1+json",
                },
            }
        );

        await bot.sendMessage(
            OWNER_UID,
            `⊘ SERVER DI SUSPEND\n\n◈ ${serverName}\n⌇ ${serverId}\n⚠ ${reason}`
        );

        await new Promise(r => setTimeout(r, 2000));

        // 4⃣ DELETE SERVER
        await axios.delete(
            `${domain}/api/application/servers/${serverId}`,
            {
                headers: {
                    Authorization: `Bearer ${plta}`,
                    Accept: "Application/vnd.pterodactyl.v1+json",
                },
            }
        );

        await bot.sendMessage(
            OWNER_UID,
            `☠ SERVER DI DELETE\n\n◈ ${serverName}\n⌇ ${serverId}`
        );

    } catch (err) {
        console.error(err.response?.data || err.message);
    }
}
const PAGE_BUTTON = 5;
let scanCache = {};

bot.onText(/\/scanpanel/, async (msg) => {

    const chatId = msg.chat.id;

    const res = await axios.get(`${domain}/api/application/servers`, {
        headers: {
            Authorization: `Bearer ${plta}`,
            Accept: "Application/vnd.pterodactyl.v1+json"
        }
    });

    scanCache[chatId] = res.data.data;

    sendPage(chatId, 0);
});

async function sendPage(chatId, page, messageId = null) {

    const servers = scanCache[chatId];
    const start = page * PAGE_BUTTON;
    const end = start + PAGE_BUTTON;

    const slice = servers.slice(start, end);

    let text = "⌗ SCAN SERVER PANEL\n\n";

    for (let s of slice) {

        const id = s.attributes.id;
        const identifier = s.attributes.identifier;
        const name = s.attributes.name;

        let cpu = 0;
        let ram = 0;
        let disk = 0;
        let status = "● Aman";

        try {

            const resource = await axios.get(
                `${domain}/api/client/servers/${identifier}/resources`,
                {
                    headers: {
                        Authorization: `Bearer ${pltc}`,
                        Accept: "Application/vnd.pterodactyl.v1+json"
                    }
                }
            );

            const r = resource.data.attributes.resources;

            cpu = r.cpu_absolute || 0;
            ram = (r.memory_bytes / 1024 / 1024).toFixed(0);
            disk = (r.disk_bytes / 1024 / 1024).toFixed(0);

            if (cpu > 200 || ram > 3000) {
                status = "○ Berbahaya";
            }

        } catch {}

        text +=
`◈ ${name}
⌇ ${id}

⌘ CPU : ${cpu}%
⟡ RAM : ${ram} MB
⟡ Disk: ${disk} MB
⚠ ${status}

`;
    }

    const buttons = [];

    if (page > 0) {
        buttons.push({ text: "⬅ ‹", callback_data: `scan_${page-1}` });
    }

    if (end < servers.length) {
        buttons.push({ text: "➡ Lanjut", callback_data: `scan_${page+1}` });
    }

    const opts = {
        reply_markup: {
            inline_keyboard: [buttons]
        }
    };

    if (messageId) {
        bot.editMessageText(text, {
            chat_id: chatId,
            message_id: messageId,
            reply_markup: opts.reply_markup
        });
    } else {
        bot.sendMessage(chatId, text, opts);
    }
}

bot.on("callback_query", async (q) => {

    const data = q.data;
    const chatId = q.message.chat.id;
    const messageId = q.message.message_id;

    if (data.startsWith("scan_")) {

        const page = parseInt(data.split("_")[1]);

        sendPage(chatId, page, messageId);

        bot.answerCallbackQuery(q.id);
    }
});
bot.onText(/^\/cadpv2(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (featureLocks.isAdpLocked() && String(msg.from?.id) !== String(OWNER_UID)) {
    return bot.sendMessage(chatId, "<blockquote expandable>🔒 <b>CREATE ADP SEDANG DI-LOCK</b>\n\nAdmin sedang menutup akses ADP. Silakan coba lagi nanti.</blockquote>", { parse_mode: "HTML" });
  }

  const userId = msg.from.id;
  const text = match[1] || "";
    
      if ((msg.chat.type !== "group" && msg.chat.type !== "supergroup") && !settings.isOwner(msg.from.id)) {
        return bot.sendMessage(chatId, "◈ Fitur ini khusus grup.");
      }
    
  const premV2Users = JSON.parse(fs.readFileSync(PREMV2_FILE));
  const isPremiumV2 = premV2Users.includes(String(msg.from.id));   
      if (!isPremiumV2) {
    bot.sendMessage(chatId, "◇ Kamu tidak memiliki akses premium v2!", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "ᴊᴏɪɴ ꜱᴇʀᴠᴇʀ", url: `https://t.me/${dev}` }],
        ],
      },
    });
    return;
  }
  
  const commandParams = (match[1] || "").split(",");
if (commandParams.length < 1 || !commandParams[0].trim()) {
  bot.sendMessage(
    chatId,
    "◇ Format Salah! Penggunaan: /cadpv2 nama"
  );
  return;
}

  const panelName = commandParams[0].trim();
  const telegramId = commandParams[1] ? commandParams[1].trim() : msg.from.id;

  const password = panelName + Math.random().toString(36).slice(2, 5);
    
  try {
    const response = await fetch(`${domainV2}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${pltaV2}`,
      },
      body: JSON.stringify({
        email: `${panelName}@gmail.com`,
        username: panelName,
        first_name: panelName,
        last_name: "admin",
        language: "en",
        root_admin: true,
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      bot.sendMessage(chatId, JSON.stringify(data.errors[0], null, 2));
      return;
    }
    const user = data.attributes;
    const userInfo =
      `<b>🛡️ ADMIN PANEL V2 BERHASIL DIBUAT</b>\n\n` +
      `<blockquote expandable><b>📋 DETAIL AKUN</b>\n` +
      `🆔 <b>ID</b> : <code>${sanitizeHtml(user.id)}</code>\n` +
      `👤 <b>Username</b> : <code>${sanitizeHtml(user.username)}</code>\n` +
      `📧 <b>Email</b> : <code>${sanitizeHtml(user.email)}</code>\n` +
      `📝 <b>Nama</b> : ${sanitizeHtml(`${user.first_name || ""} ${user.last_name || ""}`.trim())}\n` +
      `🌐 <b>Bahasa</b> : <code>${sanitizeHtml(user.language || "-")}</code>\n` +
      `🔐 <b>Hak Akses</b> : <b>${user.root_admin ? "ADMIN PANEL" : "USER"}</b></blockquote>\n\n` +
      `<i>Data akun berhasil dibuat dan siap digunakan.</i>`;
    bot.sendMessage(chatId, userInfo, { parse_mode: "HTML" });
     
    const caption = `╭━━〔 ⚡ ADMIN PANEL CREATED 〕━━╮\n\n◈ <b>Panel</b> : <b>ADMIN PANEL V2</b>!

◈ Username : <code>${user.username}</code>
🔐 Password: <code>${password}</code>
🌐 Login    : ${domainV2}

<blockquote expandable>⬡ Catatan :
Simpan informasi data ini dengan aman
dan jangan bagikan ke orang lain!
</blockquote>
`;

bot.sendPhoto(telegramId, settings.notifChannelImage, {
  caption,
  parse_mode: "HTML",
  reply_markup: {
    inline_keyboard: [[{ text: "🌐 BUKA PANEL", url: domainV2 }]]
  }
});
sendPanelToChannel(bot, { type: "ADMIN PANEL V2", username: user.username, uid: user.id, domainUrl: domainV2, createdBy: msg.from.username ? `@${msg.from.username}` : msg.from.id });

   
  } catch (error) {
    console.error(error);
    bot.sendMessage(
      chatId,
      "Terjadi kesalahan dalam pembuatan admin. Silakan coba lagi nanti."
    );
  }
});
 

            
bot.onText(/^\/cadpv3(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (featureLocks.isAdpLocked() && String(msg.from?.id) !== String(OWNER_UID)) {
    return bot.sendMessage(chatId, "<blockquote expandable>🔒 <b>CREATE ADP SEDANG DI-LOCK</b>\n\nAdmin sedang menutup akses ADP. Silakan coba lagi nanti.</blockquote>", { parse_mode: "HTML" });
  }

  const userId = msg.from.id;
  const text = match[1] || "";
    
      if ((msg.chat.type !== "group" && msg.chat.type !== "supergroup") && !settings.isOwner(msg.from.id)) {
        return bot.sendMessage(chatId, "◈ Fitur ini khusus grup.");
      }
    
  const premV3Users = JSON.parse(fs.readFileSync(PREMV3_FILE));
  const isPremiumV3 = premV3Users.includes(String(msg.from.id));   
      if (!isPremiumV3) {
    bot.sendMessage(chatId, "◇ Kamu tidak memiliki akses premium v3", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "ᴊᴏɪɴ ꜱᴇʀᴠᴇʀ", url: `https://t.me/${dev}` }],
        ],
      },
    });
    return;
  }
  
  const commandParams = (match[1] || "").split(",");
if (commandParams.length < 1 || !commandParams[0].trim()) {
  bot.sendMessage(
    chatId,
    "◇ Format Salah! Penggunaan: /cadpv3 nama"
  );
  return;
}

  const panelName = commandParams[0].trim();
  const telegramId = commandParams[1] ? commandParams[1].trim() : msg.from.id;

  const password = panelName + Math.random().toString(36).slice(2, 5);
    
  try {
    const response = await fetch(`${domainV3}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${pltaV3}`,
      },
      body: JSON.stringify({
        email: `${panelName}@gmail.com`,
        username: panelName,
        first_name: panelName,
        last_name: "admin",
        language: "en",
        root_admin: true,
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      bot.sendMessage(chatId, JSON.stringify(data.errors[0], null, 2));
      return;
    }
    const user = data.attributes;
    const userInfo =
      `<b>🛡️ ADMIN PANEL V3 BERHASIL DIBUAT</b>\n\n` +
      `<blockquote expandable><b>📋 DETAIL AKUN</b>\n` +
      `🆔 <b>ID</b> : <code>${sanitizeHtml(user.id)}</code>\n` +
      `👤 <b>Username</b> : <code>${sanitizeHtml(user.username)}</code>\n` +
      `📧 <b>Email</b> : <code>${sanitizeHtml(user.email)}</code>\n` +
      `📝 <b>Nama</b> : ${sanitizeHtml(`${user.first_name || ""} ${user.last_name || ""}`.trim())}\n` +
      `🌐 <b>Bahasa</b> : <code>${sanitizeHtml(user.language || "-")}</code>\n` +
      `🔐 <b>Hak Akses</b> : <b>${user.root_admin ? "ADMIN PANEL" : "USER"}</b></blockquote>\n\n` +
      `<i>Data akun berhasil dibuat dan siap digunakan.</i>`;
    bot.sendMessage(chatId, userInfo, { parse_mode: "HTML" });
     
    const caption = `╭━━〔 ⚡ ADMIN PANEL CREATED 〕━━╮\n\n◈ <b>Panel</b> : <b>ADMIN PANEL V3</b>!

◈ Username : <code>${user.username}</code>
🔐 Password: <code>${password}</code>
🌐 Login    : ${domainV3}

<blockquote expandable>⬡ Catatan :
Simpan informasi data ini dengan aman
dan jangan bagikan ke orang lain!
</blockquote>
`;

bot.sendPhoto(telegramId, settings.notifChannelImage, {
  caption,
  parse_mode: "HTML",
  reply_markup: {
    inline_keyboard: [[{ text: "🌐 BUKA PANEL", url: domainV3 }]]
  }
});
sendPanelToChannel(bot, { type: "ADMIN PANEL V3", username: user.username, uid: user.id, domainUrl: domainV3, createdBy: msg.from.username ? `@${msg.from.username}` : msg.from.id });

   
  } catch (error) {
    console.error(error);
    bot.sendMessage(
      chatId,
      "Terjadi kesalahan dalam pembuatan admin. Silakan coba lagi nanti."
    );
  }
});
    
    // cadpv4
bot.onText(/^\/cadpv4(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (featureLocks.isAdpLocked() && String(msg.from?.id) !== String(OWNER_UID)) {
    return bot.sendMessage(chatId, "<blockquote expandable>🔒 <b>CREATE ADP SEDANG DI-LOCK</b>\n\nAdmin sedang menutup akses ADP. Silakan coba lagi nanti.</blockquote>", { parse_mode: "HTML" });
  }

  const userId = msg.from.id;
  const text = match[1] || "";
    
      if ((msg.chat.type !== "group" && msg.chat.type !== "supergroup") && !settings.isOwner(msg.from.id)) {
        return bot.sendMessage(chatId, "◈ Fitur ini khusus grup.");
      }
    
  const premV4Users = JSON.parse(fs.readFileSync(PREMV4_FILE));
  const isPremiumV4 = premV4Users.includes(String(msg.from.id));   
      if (!isPremiumV4) {
    bot.sendMessage(chatId, "◇ Kamu tidak memiliki akses premium v4", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "ᴊᴏɪɴ ꜱᴇʀᴠᴇʀ", url: `https://t.me/${dev}` }],
        ],
      },
    });
    return;
  }
  
  const commandParams = (match[1] || "").split(",");
if (commandParams.length < 1 || !commandParams[0].trim()) {
  bot.sendMessage(
    chatId,
    "◇ Format Salah! Penggunaan: /cadpv4 nama"
  );
  return;
}

  const panelName = commandParams[0].trim();
  const telegramId = commandParams[1] ? commandParams[1].trim() : msg.from.id;

  const password = panelName + Math.random().toString(36).slice(2, 5);
    
  try {
    const response = await fetch(`${domainV4}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${pltaV4}`,
      },
      body: JSON.stringify({
        email: `${panelName}@gmail.com`,
        username: panelName,
        first_name: panelName,
        last_name: "admin",
        language: "en",
        root_admin: true,
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      bot.sendMessage(chatId, JSON.stringify(data.errors[0], null, 2));
      return;
    }
    const user = data.attributes;
    const userInfo =
      `<b>🛡️ ADMIN PANEL V4 BERHASIL DIBUAT</b>\n\n` +
      `<blockquote expandable><b>📋 DETAIL AKUN</b>\n` +
      `🆔 <b>ID</b> : <code>${sanitizeHtml(user.id)}</code>\n` +
      `👤 <b>Username</b> : <code>${sanitizeHtml(user.username)}</code>\n` +
      `📧 <b>Email</b> : <code>${sanitizeHtml(user.email)}</code>\n` +
      `📝 <b>Nama</b> : ${sanitizeHtml(`${user.first_name || ""} ${user.last_name || ""}`.trim())}\n` +
      `🌐 <b>Bahasa</b> : <code>${sanitizeHtml(user.language || "-")}</code>\n` +
      `🔐 <b>Hak Akses</b> : <b>${user.root_admin ? "ADMIN PANEL" : "USER"}</b></blockquote>\n\n` +
      `<i>Data akun berhasil dibuat dan siap digunakan.</i>`;
    bot.sendMessage(chatId, userInfo, { parse_mode: "HTML" });
     
    const caption = `╭━━〔 ⚡ ADMIN PANEL CREATED 〕━━╮\n\n◈ <b>Panel</b> : <b>ADMIN PANEL V4</b>!

◈ Username : <code>${user.username}</code>
🔐 Password: <code>${password}</code>
🌐 Login    : ${domainV4}

<blockquote expandable>⬡ Catatan :
Simpan informasi data ini dengan aman
dan jangan bagikan ke orang lain!
</blockquote>
`;

bot.sendPhoto(telegramId, settings.notifChannelImage, {
  caption,
  parse_mode: "HTML",
  reply_markup: {
    inline_keyboard: [[{ text: "🌐 BUKA PANEL", url: domainV4 }]]
  }
});
sendPanelToChannel(bot, { type: "ADMIN PANEL V4", username: user.username, uid: user.id, domainUrl: domainV4, createdBy: msg.from.username ? `@${msg.from.username}` : msg.from.id });

   
  } catch (error) {
    console.error(error);
    bot.sendMessage(
      chatId,
      "Terjadi kesalahan dalam pembuatan admin. Silakan coba lagi nanti."
    );
  }
});
    
    // cadpv5
bot.onText(/^\/cadpv5(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (featureLocks.isAdpLocked() && String(msg.from?.id) !== String(OWNER_UID)) {
    return bot.sendMessage(chatId, "<blockquote expandable>🔒 <b>CREATE ADP SEDANG DI-LOCK</b>\n\nAdmin sedang menutup akses ADP. Silakan coba lagi nanti.</blockquote>", { parse_mode: "HTML" });
  }

  const userId = msg.from.id;
  const text = match[1] || "";
    
      if ((msg.chat.type !== "group" && msg.chat.type !== "supergroup") && !settings.isOwner(msg.from.id)) {
        return bot.sendMessage(chatId, "◈ Fitur ini khusus grup.");
      }
    
  const premV5Users = JSON.parse(fs.readFileSync(PREMV5_FILE));
  const isPremiumV5 = premV5Users.includes(String(msg.from.id));   
      if (!isPremiumV5) {
    bot.sendMessage(chatId, "◇ Kamu tidak memiliki akses premium v5", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "ᴊᴏɪɴ ꜱᴇʀᴠᴇʀ", url: `https://t.me/${dev}` }],
        ],
      },
    });
    return;
  }
  
  const commandParams = (match[1] || "").split(",");
if (commandParams.length < 1 || !commandParams[0].trim()) {
  bot.sendMessage(
    chatId,
    "◇ Format Salah! Penggunaan: /cadpv5 nama"
  );
  return;
}

  const panelName = commandParams[0].trim();
  const telegramId = commandParams[1] ? commandParams[1].trim() : msg.from.id;

  const password = panelName + Math.random().toString(36).slice(2, 5);
    
  try {
    const response = await fetch(`${domainV5}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${pltaV5}`,
      },
      body: JSON.stringify({
        email: `${panelName}@gmail.com`,
        username: panelName,
        first_name: panelName,
        last_name: "admin",
        language: "en",
        root_admin: true,
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      bot.sendMessage(chatId, JSON.stringify(data.errors[0], null, 2));
      return;
    }
    const user = data.attributes;
    const userInfo =
      `<b>🛡️ ADMIN PANEL V5 BERHASIL DIBUAT</b>\n\n` +
      `<blockquote expandable><b>📋 DETAIL AKUN</b>\n` +
      `🆔 <b>ID</b> : <code>${sanitizeHtml(user.id)}</code>\n` +
      `👤 <b>Username</b> : <code>${sanitizeHtml(user.username)}</code>\n` +
      `📧 <b>Email</b> : <code>${sanitizeHtml(user.email)}</code>\n` +
      `📝 <b>Nama</b> : ${sanitizeHtml(`${user.first_name || ""} ${user.last_name || ""}`.trim())}\n` +
      `🌐 <b>Bahasa</b> : <code>${sanitizeHtml(user.language || "-")}</code>\n` +
      `🔐 <b>Hak Akses</b> : <b>${user.root_admin ? "ADMIN PANEL" : "USER"}</b></blockquote>\n\n` +
      `<i>Data akun berhasil dibuat dan siap digunakan.</i>`;
    bot.sendMessage(chatId, userInfo, { parse_mode: "HTML" });
     
    const caption = `╭━━〔 ⚡ ADMIN PANEL CREATED 〕━━╮\n\n◈ <b>Panel</b> : <b>ADMIN PANEL V5</b>!

◈ Username : <code>${user.username}</code>
🔐 Password: <code>${password}</code>
🌐 Login    : ${domainV5}

<blockquote expandable>⬡ Catatan :
Simpan informasi data ini dengan aman
dan jangan bagikan ke orang lain!
</blockquote>
`;

bot.sendPhoto(telegramId, settings.notifChannelImage, {
  caption,
  parse_mode: "HTML",
  reply_markup: {
    inline_keyboard: [[{ text: "🌐 BUKA PANEL", url: domainV5 }]]
  }
});
sendPanelToChannel(bot, { type: "ADMIN PANEL V5", username: user.username, uid: user.id, domainUrl: domainV5, createdBy: msg.from.username ? `@${msg.from.username}` : msg.from.id });

   
  } catch (error) {
    console.error(error);
    bot.sendMessage(
      chatId,
      "Terjadi kesalahan dalam pembuatan admin. Silakan coba lagi nanti."
    );
  }
});
bot.onText(/^\/cadpv6(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (featureLocks.isAdpLocked() && String(msg.from?.id) !== String(OWNER_UID)) {
    return bot.sendMessage(chatId, "<blockquote expandable>🔒 <b>CREATE ADP SEDANG DI-LOCK</b>\n\nAdmin sedang menutup akses ADP. Silakan coba lagi nanti.</blockquote>", { parse_mode: "HTML" });
  }

  const userId = msg.from.id;
  const text = match[1] || "";

      if ((msg.chat.type !== "group" && msg.chat.type !== "supergroup") && !settings.isOwner(msg.from.id)) {
        return bot.sendMessage(chatId, "◈ Fitur ini khusus grup.");
      }
    
  const premV6Users = JSON.parse(fs.readFileSync(PREMV6_FILE));
  const isPremiumV6 = premV6Users.includes(String(msg.from.id));   
      if (!isPremiumV6) {
    bot.sendMessage(chatId, "◇ Kamu tidak memiliki akses premium v6", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "ᴊᴏɪɴ ꜱᴇʀᴠᴇʀ", url: `https://t.me/${dev}` }],
        ],
      },
    });
    return;
  }
  
  const commandParams = (match[1] || "").split(",");
if (commandParams.length < 1 || !commandParams[0].trim()) {
  bot.sendMessage(
    chatId,
    "◇ Format Salah! Penggunaan: /cadpv6 nama"
  );
  return;
}

  const panelName = commandParams[0].trim();
  const telegramId = commandParams[1] ? commandParams[1].trim() : msg.from.id;

  const password = panelName + Math.random().toString(36).slice(2, 5);
    
  try {
    const response = await fetch(`${domainV6}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${pltaV6}`,
      },
      body: JSON.stringify({
        email: `${panelName}@gmail.com`,
        username: panelName,
        first_name: panelName,
        last_name: "admin",
        language: "en",
        root_admin: true,
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      bot.sendMessage(chatId, JSON.stringify(data.errors[0], null, 2));
      return;
    }
    const user = data.attributes;
    const userInfo =
      `<b>🛡️ ADMIN PANEL V6 BERHASIL DIBUAT</b>\n\n` +
      `<blockquote expandable><b>📋 DETAIL AKUN</b>\n` +
      `🆔 <b>ID</b> : <code>${sanitizeHtml(user.id)}</code>\n` +
      `👤 <b>Username</b> : <code>${sanitizeHtml(user.username)}</code>\n` +
      `📧 <b>Email</b> : <code>${sanitizeHtml(user.email)}</code>\n` +
      `📝 <b>Nama</b> : ${sanitizeHtml(`${user.first_name || ""} ${user.last_name || ""}`.trim())}\n` +
      `🌐 <b>Bahasa</b> : <code>${sanitizeHtml(user.language || "-")}</code>\n` +
      `🔐 <b>Hak Akses</b> : <b>${user.root_admin ? "ADMIN PANEL" : "USER"}</b></blockquote>\n\n` +
      `<i>Data akun berhasil dibuat dan siap digunakan.</i>`;
    bot.sendMessage(chatId, userInfo, { parse_mode: "HTML" });
     
    const caption = `╭━━〔 ⚡ ADMIN PANEL CREATED 〕━━╮\n\n◈ <b>Panel</b> : <b>ADMIN PANEL V6</b>!

◈ Username : <code>${user.username}</code>
🔐 Password: <code>${password}</code>
🌐 Login    : ${domainV6}

<blockquote expandable>⬡ Catatan :
Simpan informasi data ini dengan aman
dan jangan bagikan ke orang lain!
</blockquote>
`;

bot.sendPhoto(telegramId, settings.notifChannelImage, {
  caption,
  parse_mode: "HTML",
  reply_markup: {
    inline_keyboard: [[{ text: "🌐 BUKA PANEL", url: domainV6 }]]
  }
});
sendPanelToChannel(bot, { type: "ADMIN PANEL V6", username: user.username, uid: user.id, domainUrl: domainV6, createdBy: msg.from.username ? `@${msg.from.username}` : msg.from.id });

   
  } catch (error) {
    console.error(error);
    bot.sendMessage(
      chatId,
      "Terjadi kesalahan dalam pembuatan admin. Silakan coba lagi nanti."
    );
  }
});
bot.onText(/^\/cadpv7(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (featureLocks.isAdpLocked() && String(msg.from?.id) !== String(OWNER_UID)) {
    return bot.sendMessage(chatId, "<blockquote expandable>🔒 <b>CREATE ADP SEDANG DI-LOCK</b>\n\nAdmin sedang menutup akses ADP. Silakan coba lagi nanti.</blockquote>", { parse_mode: "HTML" });
  }

  const userId = msg.from.id;
  const text = match[1] || "";
    
      if ((msg.chat.type !== "group" && msg.chat.type !== "supergroup") && !settings.isOwner(msg.from.id)) {
        return bot.sendMessage(chatId, "◈ Fitur ini khusus grup.");
      }
    
  const premV7Users = JSON.parse(fs.readFileSync(PREMV7_FILE));
  const isPremiumV7 = premV7Users.includes(String(msg.from.id));   
      if (!isPremiumV7) {
    bot.sendMessage(chatId, "◇ Kamu tidak memiliki akses premium v7", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "ᴊᴏɪɴ ꜱᴇʀᴠᴇʀ", url: `https://t.me/${dev}` }],
        ],
      },
    });
    return;
  }
  
  const commandParams = (match[1] || "").split(",");
if (commandParams.length < 1 || !commandParams[0].trim()) {
  bot.sendMessage(
    chatId,
    "◇ Format Salah! Penggunaan: /cadpv7 nama"
  );
  return;
}

  const panelName = commandParams[0].trim();
  const telegramId = commandParams[1] ? commandParams[1].trim() : msg.from.id;

  const password = panelName + Math.random().toString(36).slice(2, 5);
    
  try {
    const response = await fetch(`${domainV7}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${pltaV7}`,
      },
      body: JSON.stringify({
        email: `${panelName}@gmail.com`,
        username: panelName,
        first_name: panelName,
        last_name: "admin",
        language: "en",
        root_admin: true,
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      bot.sendMessage(chatId, JSON.stringify(data.errors[0], null, 2));
      return;
    }
    const user = data.attributes;
    const userInfo =
      `<b>🛡️ ADMIN PANEL V7 BERHASIL DIBUAT</b>\n\n` +
      `<blockquote expandable><b>📋 DETAIL AKUN</b>\n` +
      `🆔 <b>ID</b> : <code>${sanitizeHtml(user.id)}</code>\n` +
      `👤 <b>Username</b> : <code>${sanitizeHtml(user.username)}</code>\n` +
      `📧 <b>Email</b> : <code>${sanitizeHtml(user.email)}</code>\n` +
      `📝 <b>Nama</b> : ${sanitizeHtml(`${user.first_name || ""} ${user.last_name || ""}`.trim())}\n` +
      `🌐 <b>Bahasa</b> : <code>${sanitizeHtml(user.language || "-")}</code>\n` +
      `🔐 <b>Hak Akses</b> : <b>${user.root_admin ? "ADMIN PANEL" : "USER"}</b></blockquote>\n\n` +
      `<i>Data akun berhasil dibuat dan siap digunakan.</i>`;
    bot.sendMessage(chatId, userInfo, { parse_mode: "HTML" });
     
    const caption = `╭━━〔 ⚡ ADMIN PANEL CREATED 〕━━╮\n\n◈ <b>Panel</b> : <b>ADMIN PANEL V7</b>!

◈ Username : <code>${user.username}</code>
🔐 Password: <code>${password}</code>
🌐 Login    : ${domainV7}

<blockquote expandable>⬡ Catatan :
Simpan informasi data ini dengan aman
dan jangan bagikan ke orang lain!
</blockquote>
`;

bot.sendPhoto(telegramId, settings.notifChannelImage, {
  caption,
  parse_mode: "HTML",
  reply_markup: {
    inline_keyboard: [[{ text: "🌐 BUKA PANEL", url: domainV7 }]]
  }
});
sendPanelToChannel(bot, { type: "ADMIN PANEL V7", username: user.username, uid: user.id, domainUrl: domainV7, createdBy: msg.from.username ? `@${msg.from.username}` : msg.from.id });

   
  } catch (error) {
    console.error(error);
    bot.sendMessage(
      chatId,
      "Terjadi kesalahan dalam pembuatan admin. Silakan coba lagi nanti."
    );
  }
});
bot.onText(/^\/cadpv8(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (featureLocks.isAdpLocked() && String(msg.from?.id) !== String(OWNER_UID)) {
    return bot.sendMessage(chatId, "<blockquote expandable>🔒 <b>CREATE ADP SEDANG DI-LOCK</b>\n\nAdmin sedang menutup akses ADP. Silakan coba lagi nanti.</blockquote>", { parse_mode: "HTML" });
  }

  const userId = msg.from.id;
  const text = match[1] || "";
    
      if ((msg.chat.type !== "group" && msg.chat.type !== "supergroup") && !settings.isOwner(msg.from.id)) {
        return bot.sendMessage(chatId, "◈ Fitur ini khusus grup.");
      }
    
  const premV8Users = JSON.parse(fs.readFileSync(PREMV8_FILE));
  const isPremiumV8 = premV8Users.includes(String(msg.from.id));   
      if (!isPremiumV8) {
    bot.sendMessage(chatId, "◇ Kamu tidak memiliki akses premium v8", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "ᴊᴏɪɴ ꜱᴇʀᴠᴇʀ", url: `https://t.me/${dev}` }],
        ],
      },
    });
    return;
  }
  
  const commandParams = (match[1] || "").split(",");
if (commandParams.length < 1 || !commandParams[0].trim()) {
  bot.sendMessage(
    chatId,
    "◇ Format Salah! Penggunaan: /cadpv8 nama"
  );
  return;
}

  const panelName = commandParams[0].trim();
  const telegramId = commandParams[1] ? commandParams[1].trim() : msg.from.id;

  const password = panelName + Math.random().toString(36).slice(2, 5);
    
  try {
    const response = await fetch(`${domainV8}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${pltaV8}`,
      },
      body: JSON.stringify({
        email: `${panelName}@gmail.com`,
        username: panelName,
        first_name: panelName,
        last_name: "admin",
        language: "en",
        root_admin: true,
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      bot.sendMessage(chatId, JSON.stringify(data.errors[0], null, 2));
      return;
    }
    const user = data.attributes;
    const userInfo =
      `<b>🛡️ ADMIN PANEL V8 BERHASIL DIBUAT</b>\n\n` +
      `<blockquote expandable><b>📋 DETAIL AKUN</b>\n` +
      `🆔 <b>ID</b> : <code>${sanitizeHtml(user.id)}</code>\n` +
      `👤 <b>Username</b> : <code>${sanitizeHtml(user.username)}</code>\n` +
      `📧 <b>Email</b> : <code>${sanitizeHtml(user.email)}</code>\n` +
      `📝 <b>Nama</b> : ${sanitizeHtml(`${user.first_name || ""} ${user.last_name || ""}`.trim())}\n` +
      `🌐 <b>Bahasa</b> : <code>${sanitizeHtml(user.language || "-")}</code>\n` +
      `🔐 <b>Hak Akses</b> : <b>${user.root_admin ? "ADMIN PANEL" : "USER"}</b></blockquote>\n\n` +
      `<i>Data akun berhasil dibuat dan siap digunakan.</i>`;
    bot.sendMessage(chatId, userInfo, { parse_mode: "HTML" });
     
    const caption = `╭━━〔 ⚡ ADMIN PANEL CREATED 〕━━╮\n\n◈ <b>Panel</b> : <b>ADMIN PANEL V7</b>!

◈ Username : <code>${user.username}</code>
🔐 Password: <code>${password}</code>
🌐 Login    : ${domainV8}

<blockquote expandable>⬡ Catatan :
Simpan informasi data ini dengan aman
dan jangan bagikan ke orang lain!
</blockquote>
`;

bot.sendPhoto(telegramId, settings.notifChannelImage, {
  caption,
  parse_mode: "HTML",
  reply_markup: {
    inline_keyboard: [[{ text: "🌐 BUKA PANEL", url: domainV8 }]]
  }
});
sendPanelToChannel(bot, { type: "ADMIN PANEL V8", username: user.username, uid: user.id, domainUrl: domainV8, createdBy: msg.from.username ? `@${msg.from.username}` : msg.from.id });

   
  } catch (error) {
    console.error(error);
    bot.sendMessage(
      chatId,
      "Terjadi kesalahan dalam pembuatan admin. Silakan coba lagi nanti."
    );
  }
});
bot.onText(/^\/cadpv9(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (featureLocks.isAdpLocked() && String(msg.from?.id) !== String(OWNER_UID)) {
    return bot.sendMessage(chatId, "<blockquote expandable>🔒 <b>CREATE ADP SEDANG DI-LOCK</b>\n\nAdmin sedang menutup akses ADP. Silakan coba lagi nanti.</blockquote>", { parse_mode: "HTML" });
  }

  const userId = msg.from.id;
  const text = match[1] || "";
    
      if ((msg.chat.type !== "group" && msg.chat.type !== "supergroup") && !settings.isOwner(msg.from.id)) {
        return bot.sendMessage(chatId, "◈ Fitur ini khusus grup.");
      }
    
  const premV9Users = JSON.parse(fs.readFileSync(PREMV9_FILE));
  const isPremiumV9 = premV9Users.includes(String(msg.from.id));   
      if (!isPremiumV9) {
    bot.sendMessage(chatId, "◇ Kamu tidak memiliki akses premium v9", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "ᴊᴏɪɴ ꜱᴇʀᴠᴇʀ", url: `https://t.me/${dev}` }],
        ],
      },
    });
    return;
  }
  
  const commandParams = (match[1] || "").split(",");
if (commandParams.length < 1 || !commandParams[0].trim()) {
  bot.sendMessage(
    chatId,
    "◇ Format Salah! Penggunaan: /cadpv9 nama"
  );
  return;
}

  const panelName = commandParams[0].trim();
  const telegramId = commandParams[1] ? commandParams[1].trim() : msg.from.id;

  const password = panelName + Math.random().toString(36).slice(2, 5);
    
  try {
    const response = await fetch(`${domainV9}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${pltaV9}`,
      },
      body: JSON.stringify({
        email: `${panelName}@gmail.com`,
        username: panelName,
        first_name: panelName,
        last_name: "admin",
        language: "en",
        root_admin: true,
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      bot.sendMessage(chatId, JSON.stringify(data.errors[0], null, 2));
      return;
    }
    const user = data.attributes;
    const userInfo =
      `<b>🛡️ ADMIN PANEL V9 BERHASIL DIBUAT</b>\n\n` +
      `<blockquote expandable><b>📋 DETAIL AKUN</b>\n` +
      `🆔 <b>ID</b> : <code>${sanitizeHtml(user.id)}</code>\n` +
      `👤 <b>Username</b> : <code>${sanitizeHtml(user.username)}</code>\n` +
      `📧 <b>Email</b> : <code>${sanitizeHtml(user.email)}</code>\n` +
      `📝 <b>Nama</b> : ${sanitizeHtml(`${user.first_name || ""} ${user.last_name || ""}`.trim())}\n` +
      `🌐 <b>Bahasa</b> : <code>${sanitizeHtml(user.language || "-")}</code>\n` +
      `🔐 <b>Hak Akses</b> : <b>${user.root_admin ? "ADMIN PANEL" : "USER"}</b></blockquote>\n\n` +
      `<i>Data akun berhasil dibuat dan siap digunakan.</i>`;
    bot.sendMessage(chatId, userInfo, { parse_mode: "HTML" });
     
    const caption = `╭━━〔 ⚡ ADMIN PANEL CREATED 〕━━╮\n\n◈ <b>Panel</b> : <b>ADMIN PANEL V7</b>!

◈ Username : <code>${user.username}</code>
🔐 Password: <code>${password}</code>
🌐 Login    : ${domainV9}

<blockquote expandable>⬡ Catatan :
Simpan informasi data ini dengan aman
dan jangan bagikan ke orang lain!
</blockquote>
`;

bot.sendPhoto(telegramId, settings.notifChannelImage, {
  caption,
  parse_mode: "HTML",
  reply_markup: {
    inline_keyboard: [[{ text: "🌐 BUKA PANEL", url: domainV9 }]]
  }
});
sendPanelToChannel(bot, { type: "ADMIN PANEL V9", username: user.username, uid: user.id, domainUrl: domainV9, createdBy: msg.from.username ? `@${msg.from.username}` : msg.from.id });

   
  } catch (error) {
    console.error(error);
    bot.sendMessage(
      chatId,
      "Terjadi kesalahan dalam pembuatan admin. Silakan coba lagi nanti."
    );
  }
});
bot.onText(/^\/cadpv10(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (featureLocks.isAdpLocked() && String(msg.from?.id) !== String(OWNER_UID)) {
    return bot.sendMessage(chatId, "<blockquote expandable>🔒 <b>CREATE ADP SEDANG DI-LOCK</b>\n\nAdmin sedang menutup akses ADP. Silakan coba lagi nanti.</blockquote>", { parse_mode: "HTML" });
  }

  const userId = msg.from.id;
  const text = match[1] || "";
    
      if ((msg.chat.type !== "group" && msg.chat.type !== "supergroup") && !settings.isOwner(msg.from.id)) {
        return bot.sendMessage(chatId, "◈ Fitur ini khusus grup.");
      }
    
  const premV10Users = JSON.parse(fs.readFileSync(PREMV10_FILE));
  const isPremiumV10 = premV10Users.includes(String(msg.from.id));   
      if (!isPremiumV10) {
    bot.sendMessage(chatId, "◇ Kamu tidak memiliki akses premium v10", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "ᴊᴏɪɴ ꜱᴇʀᴠᴇʀ", url: `https://t.me/${dev}` }],
        ],
      },
    });
    return;
  }
  
  const commandParams = (match[1] || "").split(",");
if (commandParams.length < 1 || !commandParams[0].trim()) {
  bot.sendMessage(
    chatId,
    "◇ Format Salah! Penggunaan: /cadpv10 nama"
  );
  return;
}

  const panelName = commandParams[0].trim();
  const telegramId = commandParams[1] ? commandParams[1].trim() : msg.from.id;

  const password = panelName + Math.random().toString(36).slice(2, 5);
    
  try {
    const response = await fetch(`${domainV10}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${pltaV10}`,
      },
      body: JSON.stringify({
        email: `${panelName}@gmail.com`,
        username: panelName,
        first_name: panelName,
        last_name: "admin",
        language: "en",
        root_admin: true,
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      bot.sendMessage(chatId, JSON.stringify(data.errors[0], null, 2));
      return;
    }
    const user = data.attributes;
    const userInfo =
      `<b>🛡️ ADMIN PANEL V10 BERHASIL DIBUAT</b>\n\n` +
      `<blockquote expandable><b>📋 DETAIL AKUN</b>\n` +
      `🆔 <b>ID</b> : <code>${sanitizeHtml(user.id)}</code>\n` +
      `👤 <b>Username</b> : <code>${sanitizeHtml(user.username)}</code>\n` +
      `📧 <b>Email</b> : <code>${sanitizeHtml(user.email)}</code>\n` +
      `📝 <b>Nama</b> : ${sanitizeHtml(`${user.first_name || ""} ${user.last_name || ""}`.trim())}\n` +
      `🌐 <b>Bahasa</b> : <code>${sanitizeHtml(user.language || "-")}</code>\n` +
      `🔐 <b>Hak Akses</b> : <b>${user.root_admin ? "ADMIN PANEL" : "USER"}</b></blockquote>\n\n` +
      `<i>Data akun berhasil dibuat dan siap digunakan.</i>`;
    bot.sendMessage(chatId, userInfo, { parse_mode: "HTML" });
     
    const caption = `╭━━〔 ⚡ ADMIN PANEL CREATED 〕━━╮\n\n◈ <b>Panel</b> : <b>ADMIN PANEL V7</b>!

◈ Username : <code>${user.username}</code>
🔐 Password: <code>${password}</code>
🌐 Login    : ${domainV10}

<blockquote expandable>⬡ Catatan :
Simpan informasi data ini dengan aman
dan jangan bagikan ke orang lain!
</blockquote>
`;

bot.sendPhoto(telegramId, settings.notifChannelImage, {
  caption,
  parse_mode: "HTML",
  reply_markup: {
    inline_keyboard: [[{ text: "🌐 BUKA PANEL", url: domainV10 }]]
  }
});
sendPanelToChannel(bot, { type: "ADMIN PANEL V10", username: user.username, uid: user.id, domainUrl: domainV10, createdBy: msg.from.username ? `@${msg.from.username}` : msg.from.id });

   
  } catch (error) {
    console.error(error);
    bot.sendMessage(
      chatId,
      "Terjadi kesalahan dalam pembuatan admin. Silakan coba lagi nanti."
    );
  }
});
bot.onText(/^\/cadpv11(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (featureLocks.isAdpLocked() && String(msg.from?.id) !== String(OWNER_UID)) {
    return bot.sendMessage(chatId, "<blockquote expandable>🔒 <b>CREATE ADP SEDANG DI-LOCK</b>\n\nAdmin sedang menutup akses ADP. Silakan coba lagi nanti.</blockquote>", { parse_mode: "HTML" });
  }

  const userId = msg.from.id;
  const text = match[1] || "";
    
      if ((msg.chat.type !== "group" && msg.chat.type !== "supergroup") && !settings.isOwner(msg.from.id)) {
        return bot.sendMessage(chatId, "◈ Fitur ini khusus grup.");
      }
    
  const premV11Users = JSON.parse(fs.readFileSync(PREMV11_FILE));
  const isPremiumV11 = premV11Users.includes(String(msg.from.id));   
      if (!isPremiumV11) {
    bot.sendMessage(chatId, "◇ Kamu tidak memiliki akses premium v11", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "ᴊᴏɪɴ ꜱᴇʀᴠᴇʀ", url: `https://t.me/${dev}` }],
        ],
      },
    });
    return;
  }
  
  const commandParams = (match[1] || "").split(",");
if (commandParams.length < 1 || !commandParams[0].trim()) {
  bot.sendMessage(
    chatId,
    "◇ Format Salah! Penggunaan: /cadpv11 nama"
  );
  return;
}

  const panelName = commandParams[0].trim();
  const telegramId = commandParams[1] ? commandParams[1].trim() : msg.from.id;

  const password = panelName + Math.random().toString(36).slice(2, 5);
    
  try {
    const response = await fetch(`${domainV11}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${pltaV11}`,
      },
      body: JSON.stringify({
        email: `${panelName}@gmail.com`,
        username: panelName,
        first_name: panelName,
        last_name: "admin",
        language: "en",
        root_admin: true,
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      bot.sendMessage(chatId, JSON.stringify(data.errors[0], null, 2));
      return;
    }
    const user = data.attributes;
    const userInfo =
      `<b>🛡️ ADMIN PANEL V11 BERHASIL DIBUAT</b>\n\n` +
      `<blockquote expandable><b>📋 DETAIL AKUN</b>\n` +
      `🆔 <b>ID</b> : <code>${sanitizeHtml(user.id)}</code>\n` +
      `👤 <b>Username</b> : <code>${sanitizeHtml(user.username)}</code>\n` +
      `📧 <b>Email</b> : <code>${sanitizeHtml(user.email)}</code>\n` +
      `📝 <b>Nama</b> : ${sanitizeHtml(`${user.first_name || ""} ${user.last_name || ""}`.trim())}\n` +
      `🌐 <b>Bahasa</b> : <code>${sanitizeHtml(user.language || "-")}</code>\n` +
      `🔐 <b>Hak Akses</b> : <b>${user.root_admin ? "ADMIN PANEL" : "USER"}</b></blockquote>\n\n` +
      `<i>Data akun berhasil dibuat dan siap digunakan.</i>`;
    bot.sendMessage(chatId, userInfo, { parse_mode: "HTML" });
     
    const caption = `╭━━〔 ⚡ ADMIN PANEL CREATED 〕━━╮\n\n◈ <b>Panel</b> : <b>ADMIN PANEL V11</b>!

◈ Username : <code>${user.username}</code>
🔐 Password: <code>${password}</code>
🌐 Login    : ${domainV11}

<blockquote expandable>⬡ Catatan :
Simpan informasi data ini dengan aman
dan jangan bagikan ke orang lain!
</blockquote>
`;

bot.sendPhoto(telegramId, settings.notifChannelImage, {
  caption,
  parse_mode: "HTML",
  reply_markup: {
    inline_keyboard: [[{ text: "🌐 BUKA PANEL", url: domainV11 }]]
  }
});
sendPanelToChannel(bot, { type: "ADMIN PANEL V11", username: user.username, uid: user.id, domainUrl: domainV11, createdBy: msg.from.username ? `@${msg.from.username}` : msg.from.id });

   
  } catch (error) {
    console.error(error);
    bot.sendMessage(
      chatId,
      "Terjadi kesalahan dalam pembuatan admin. Silakan coba lagi nanti."
    );
  }
});
bot.onText(/^\/cadpv12(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (featureLocks.isAdpLocked() && String(msg.from?.id) !== String(OWNER_UID)) {
    return bot.sendMessage(chatId, "<blockquote expandable>🔒 <b>CREATE ADP SEDANG DI-LOCK</b>\n\nAdmin sedang menutup akses ADP. Silakan coba lagi nanti.</blockquote>", { parse_mode: "HTML" });
  }

  const userId = msg.from.id;
  const text = match[1] || "";
    
      if ((msg.chat.type !== "group" && msg.chat.type !== "supergroup") && !settings.isOwner(msg.from.id)) {
        return bot.sendMessage(chatId, "◈ Fitur ini khusus grup.");
      }
    
  const premV12Users = JSON.parse(fs.readFileSync(PREMV12_FILE));
  const isPremiumV12 = premV12Users.includes(String(msg.from.id));   
      if (!isPremiumV12) {
    bot.sendMessage(chatId, "◇ Kamu tidak memiliki akses premium v12", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "ᴊᴏɪɴ ꜱᴇʀᴠᴇʀ", url: `https://t.me/${dev}` }],
        ],
      },
    });
    return;
  }
  
  const commandParams = (match[1] || "").split(",");
if (commandParams.length < 1 || !commandParams[0].trim()) {
  bot.sendMessage(
    chatId,
    "◇ Format Salah! Penggunaan: /cadpv12 nama"
  );
  return;
}

  const panelName = commandParams[0].trim();
  const telegramId = commandParams[1] ? commandParams[1].trim() : msg.from.id;

  const password = panelName + Math.random().toString(36).slice(2, 5);
    
  try {
    const response = await fetch(`${domainV12}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${pltaV12}`,
      },
      body: JSON.stringify({
        email: `${panelName}@gmail.com`,
        username: panelName,
        first_name: panelName,
        last_name: "admin",
        language: "en",
        root_admin: true,
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      bot.sendMessage(chatId, JSON.stringify(data.errors[0], null, 2));
      return;
    }
    const user = data.attributes;
    const userInfo =
      `<b>🛡️ ADMIN PANEL V12 BERHASIL DIBUAT</b>\n\n` +
      `<blockquote expandable><b>📋 DETAIL AKUN</b>\n` +
      `🆔 <b>ID</b> : <code>${sanitizeHtml(user.id)}</code>\n` +
      `👤 <b>Username</b> : <code>${sanitizeHtml(user.username)}</code>\n` +
      `📧 <b>Email</b> : <code>${sanitizeHtml(user.email)}</code>\n` +
      `📝 <b>Nama</b> : ${sanitizeHtml(`${user.first_name || ""} ${user.last_name || ""}`.trim())}\n` +
      `🌐 <b>Bahasa</b> : <code>${sanitizeHtml(user.language || "-")}</code>\n` +
      `🔐 <b>Hak Akses</b> : <b>${user.root_admin ? "ADMIN PANEL" : "USER"}</b></blockquote>\n\n` +
      `<i>Data akun berhasil dibuat dan siap digunakan.</i>`;
    bot.sendMessage(chatId, userInfo, { parse_mode: "HTML" });
     
    const caption = `╭━━〔 ⚡ ADMIN PANEL CREATED 〕━━╮\n\n◈ <b>Panel</b> : <b>ADMIN PANEL V12</b>!

◈ Username : <code>${user.username}</code>
🔐 Password: <code>${password}</code>
🌐 Login    : ${domainV12}

<blockquote expandable>⬡ Catatan :
Simpan informasi data ini dengan aman
dan jangan bagikan ke orang lain!
</blockquote>
`;

bot.sendPhoto(telegramId, settings.notifChannelImage, {
  caption,
  parse_mode: "HTML",
  reply_markup: {
    inline_keyboard: [[{ text: "🌐 BUKA PANEL", url: domainV12 }]]
  }
});
sendPanelToChannel(bot, { type: "ADMIN PANEL V12", username: user.username, uid: user.id, domainUrl: domainV12, createdBy: msg.from.username ? `@${msg.from.username}` : msg.from.id });

   
  } catch (error) {
    console.error(error);
    bot.sendMessage(
      chatId,
      "Terjadi kesalahan dalam pembuatan admin. Silakan coba lagi nanti."
    );
  }
});
bot.onText(/^\/cadpv13(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (featureLocks.isAdpLocked() && String(msg.from?.id) !== String(OWNER_UID)) {
    return bot.sendMessage(chatId, "<blockquote expandable>🔒 <b>CREATE ADP SEDANG DI-LOCK</b>\n\nAdmin sedang menutup akses ADP. Silakan coba lagi nanti.</blockquote>", { parse_mode: "HTML" });
  }

  const userId = msg.from.id;
  const text = match[1] || "";
    
      if ((msg.chat.type !== "group" && msg.chat.type !== "supergroup") && !settings.isOwner(msg.from.id)) {
        return bot.sendMessage(chatId, "◈ Fitur ini khusus grup.");
      }
    
  const premV13Users = JSON.parse(fs.readFileSync(PREMV13_FILE));
  const isPremiumV13 = premV13Users.includes(String(msg.from.id));   
      if (!isPremiumV13) {
    bot.sendMessage(chatId, "◇ Kamu tidak memiliki akses premium v13", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "ᴊᴏɪɴ ꜱᴇʀᴠᴇʀ", url: `https://t.me/${dev}` }],
        ],
      },
    });
    return;
  }
  
  const commandParams = (match[1] || "").split(",");
if (commandParams.length < 1 || !commandParams[0].trim()) {
  bot.sendMessage(
    chatId,
    "◇ Format Salah! Penggunaan: /cadpv13 nama"
  );
  return;
}

  const panelName = commandParams[0].trim();
  const telegramId = commandParams[1] ? commandParams[1].trim() : msg.from.id;

  const password = panelName + Math.random().toString(36).slice(2, 5);
    
  try {
    const response = await fetch(`${domainV13}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${pltaV13}`,
      },
      body: JSON.stringify({
        email: `${panelName}@gmail.com`,
        username: panelName,
        first_name: panelName,
        last_name: "admin",
        language: "en",
        root_admin: true,
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      bot.sendMessage(chatId, JSON.stringify(data.errors[0], null, 2));
      return;
    }
    const user = data.attributes;
    const userInfo =
      `<b>🛡️ ADMIN PANEL V13 BERHASIL DIBUAT</b>\n\n` +
      `<blockquote expandable><b>📋 DETAIL AKUN</b>\n` +
      `🆔 <b>ID</b> : <code>${sanitizeHtml(user.id)}</code>\n` +
      `👤 <b>Username</b> : <code>${sanitizeHtml(user.username)}</code>\n` +
      `📧 <b>Email</b> : <code>${sanitizeHtml(user.email)}</code>\n` +
      `📝 <b>Nama</b> : ${sanitizeHtml(`${user.first_name || ""} ${user.last_name || ""}`.trim())}\n` +
      `🌐 <b>Bahasa</b> : <code>${sanitizeHtml(user.language || "-")}</code>\n` +
      `🔐 <b>Hak Akses</b> : <b>${user.root_admin ? "ADMIN PANEL" : "USER"}</b></blockquote>\n\n` +
      `<i>Data akun berhasil dibuat dan siap digunakan.</i>`;
    bot.sendMessage(chatId, userInfo, { parse_mode: "HTML" });
     
    const caption = `╭━━〔 ⚡ ADMIN PANEL CREATED 〕━━╮\n\n◈ <b>Panel</b> : <b>ADMIN PANEL V13</b>!

◈ Username : <code>${user.username}</code>
🔐 Password: <code>${password}</code>
🌐 Login    : ${domainV13}

<blockquote expandable>⬡ Catatan :
Simpan informasi data ini dengan aman
dan jangan bagikan ke orang lain!
</blockquote>
`;

bot.sendPhoto(telegramId, settings.notifChannelImage, {
  caption,
  parse_mode: "HTML",
  reply_markup: {
    inline_keyboard: [[{ text: "🌐 BUKA PANEL", url: domainV13 }]]
  }
});
sendPanelToChannel(bot, { type: "ADMIN PANEL V13", username: user.username, uid: user.id, domainUrl: domainV13, createdBy: msg.from.username ? `@${msg.from.username}` : msg.from.id });

   
  } catch (error) {
    console.error(error);
    bot.sendMessage(
      chatId,
      "Terjadi kesalahan dalam pembuatan admin. Silakan coba lagi nanti."
    );
  }
});
bot.onText(/^\/cadpv14(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (featureLocks.isAdpLocked() && String(msg.from?.id) !== String(OWNER_UID)) {
    return bot.sendMessage(chatId, "<blockquote expandable>🔒 <b>CREATE ADP SEDANG DI-LOCK</b>\n\nAdmin sedang menutup akses ADP. Silakan coba lagi nanti.</blockquote>", { parse_mode: "HTML" });
  }

  const userId = msg.from.id;
  const text = match[1] || "";
    
      if ((msg.chat.type !== "group" && msg.chat.type !== "supergroup") && !settings.isOwner(msg.from.id)) {
        return bot.sendMessage(chatId, "◈ Fitur ini khusus grup.");
      }
    
  const premV14Users = JSON.parse(fs.readFileSync(PREMV14_FILE));
  const isPremiumV14 = premV14Users.includes(String(msg.from.id));   
      if (!isPremiumV14) {
    bot.sendMessage(chatId, "◇ Kamu tidak memiliki akses premium v14", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "ᴊᴏɪɴ ꜱᴇʀᴠᴇʀ", url: `https://t.me/${dev}` }],
        ],
      },
    });
    return;
  }
  
  const commandParams = (match[1] || "").split(",");
if (commandParams.length < 1 || !commandParams[0].trim()) {
  bot.sendMessage(
    chatId,
    "◇ Format Salah! Penggunaan: /cadpv14 nama"
  );
  return;
}

  const panelName = commandParams[0].trim();
  const telegramId = commandParams[1] ? commandParams[1].trim() : msg.from.id;

  const password = panelName + Math.random().toString(36).slice(2, 5);
    
  try {
    const response = await fetch(`${domainV14}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${pltaV14}`,
      },
      body: JSON.stringify({
        email: `${panelName}@gmail.com`,
        username: panelName,
        first_name: panelName,
        last_name: "admin",
        language: "en",
        root_admin: true,
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      bot.sendMessage(chatId, JSON.stringify(data.errors[0], null, 2));
      return;
    }
    const user = data.attributes;
    const userInfo =
      `<b>🛡️ ADMIN PANEL V14 BERHASIL DIBUAT</b>\n\n` +
      `<blockquote expandable><b>📋 DETAIL AKUN</b>\n` +
      `🆔 <b>ID</b> : <code>${sanitizeHtml(user.id)}</code>\n` +
      `👤 <b>Username</b> : <code>${sanitizeHtml(user.username)}</code>\n` +
      `📧 <b>Email</b> : <code>${sanitizeHtml(user.email)}</code>\n` +
      `📝 <b>Nama</b> : ${sanitizeHtml(`${user.first_name || ""} ${user.last_name || ""}`.trim())}\n` +
      `🌐 <b>Bahasa</b> : <code>${sanitizeHtml(user.language || "-")}</code>\n` +
      `🔐 <b>Hak Akses</b> : <b>${user.root_admin ? "ADMIN PANEL" : "USER"}</b></blockquote>\n\n` +
      `<i>Data akun berhasil dibuat dan siap digunakan.</i>`;
    bot.sendMessage(chatId, userInfo, { parse_mode: "HTML" });
     
    const caption = `╭━━〔 ⚡ ADMIN PANEL CREATED 〕━━╮\n\n◈ <b>Panel</b> : <b>ADMIN PANEL V14</b>!

◈ Username : <code>${user.username}</code>
🔐 Password: <code>${password}</code>
🌐 Login    : ${domainV14}

<blockquote expandable>⬡ Catatan :
Simpan informasi data ini dengan aman
dan jangan bagikan ke orang lain!
</blockquote>
`;

bot.sendPhoto(telegramId, settings.notifChannelImage, {
  caption,
  parse_mode: "HTML",
  reply_markup: {
    inline_keyboard: [[{ text: "🌐 BUKA PANEL", url: domainV14 }]]
  }
});
sendPanelToChannel(bot, { type: "ADMIN PANEL V14", username: user.username, uid: user.id, domainUrl: domainV14, createdBy: msg.from.username ? `@${msg.from.username}` : msg.from.id });

   
  } catch (error) {
    console.error(error);
    bot.sendMessage(
      chatId,
      "Terjadi kesalahan dalam pembuatan admin. Silakan coba lagi nanti."
    );
  }
});
bot.onText(/^\/cadpv15(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (featureLocks.isAdpLocked() && String(msg.from?.id) !== String(OWNER_UID)) {
    return bot.sendMessage(chatId, "<blockquote expandable>🔒 <b>CREATE ADP SEDANG DI-LOCK</b>\n\nAdmin sedang menutup akses ADP. Silakan coba lagi nanti.</blockquote>", { parse_mode: "HTML" });
  }

  const userId = msg.from.id;
  const text = match[1] || "";
    
      if ((msg.chat.type !== "group" && msg.chat.type !== "supergroup") && !settings.isOwner(msg.from.id)) {
        return bot.sendMessage(chatId, "◈ Fitur ini khusus grup.");
      }
    
  const premV15Users = JSON.parse(fs.readFileSync(PREMV15_FILE));
  const isPremiumV15 = premV15Users.includes(String(msg.from.id));   
      if (!isPremiumV15) {
    bot.sendMessage(chatId, "◇ Kamu tidak memiliki akses premium v15", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "ᴊᴏɪɴ ꜱᴇʀᴠᴇʀ", url: `https://t.me/${dev}` }],
        ],
      },
    });
    return;
  }
  
  const commandParams = (match[1] || "").split(",");
if (commandParams.length < 1 || !commandParams[0].trim()) {
  bot.sendMessage(
    chatId,
    "◇ Format Salah! Penggunaan: /cadpv15 nama"
  );
  return;
}

  const panelName = commandParams[0].trim();
  const telegramId = commandParams[1] ? commandParams[1].trim() : msg.from.id;

  const password = panelName + Math.random().toString(36).slice(2, 5);
    
  try {
    const response = await fetch(`${domainV15}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${pltaV15}`,
      },
      body: JSON.stringify({
        email: `${panelName}@gmail.com`,
        username: panelName,
        first_name: panelName,
        last_name: "admin",
        language: "en",
        root_admin: true,
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      bot.sendMessage(chatId, JSON.stringify(data.errors[0], null, 2));
      return;
    }
    const user = data.attributes;
    const userInfo =
      `<b>🛡️ ADMIN PANEL V15 BERHASIL DIBUAT</b>\n\n` +
      `<blockquote expandable><b>📋 DETAIL AKUN</b>\n` +
      `🆔 <b>ID</b> : <code>${sanitizeHtml(user.id)}</code>\n` +
      `👤 <b>Username</b> : <code>${sanitizeHtml(user.username)}</code>\n` +
      `📧 <b>Email</b> : <code>${sanitizeHtml(user.email)}</code>\n` +
      `📝 <b>Nama</b> : ${sanitizeHtml(`${user.first_name || ""} ${user.last_name || ""}`.trim())}\n` +
      `🌐 <b>Bahasa</b> : <code>${sanitizeHtml(user.language || "-")}</code>\n` +
      `🔐 <b>Hak Akses</b> : <b>${user.root_admin ? "ADMIN PANEL" : "USER"}</b></blockquote>\n\n` +
      `<i>Data akun berhasil dibuat dan siap digunakan.</i>`;
    bot.sendMessage(chatId, userInfo, { parse_mode: "HTML" });
     
    const caption = `╭━━〔 ⚡ ADMIN PANEL CREATED 〕━━╮\n\n◈ <b>Panel</b> : <b>ADMIN PANEL V15</b>!

◈ Username : <code>${user.username}</code>
🔐 Password: <code>${password}</code>
🌐 Login    : ${domainV15}

<blockquote expandable>⬡ Catatan :
Simpan informasi data ini dengan aman
dan jangan bagikan ke orang lain!
</blockquote>
`;

bot.sendPhoto(telegramId, settings.notifChannelImage, {
  caption,
  parse_mode: "HTML",
  reply_markup: {
    inline_keyboard: [[{ text: "🌐 BUKA PANEL", url: domainV15 }]]
  }
});
sendPanelToChannel(bot, { type: "ADMIN PANEL V15", username: user.username, uid: user.id, domainUrl: domainV15, createdBy: msg.from.username ? `@${msg.from.username}` : msg.from.id });

   
  } catch (error) {
    console.error(error);
    bot.sendMessage(
      chatId,
      "Terjadi kesalahan dalam pembuatan admin. Silakan coba lagi nanti."
    );
  }
});
bot.onText(/^\/cadpv16(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (featureLocks.isAdpLocked() && String(msg.from?.id) !== String(OWNER_UID)) {
    return bot.sendMessage(chatId, "<blockquote expandable>🔒 <b>CREATE ADP SEDANG DI-LOCK</b>\n\nAdmin sedang menutup akses ADP. Silakan coba lagi nanti.</blockquote>", { parse_mode: "HTML" });
  }

  const userId = msg.from.id;
  const text = match[1] || "";
    
      if ((msg.chat.type !== "group" && msg.chat.type !== "supergroup") && !settings.isOwner(msg.from.id)) {
        return bot.sendMessage(chatId, "◈ Fitur ini khusus grup.");
      }
    
  const premV16Users = JSON.parse(fs.readFileSync(PREMV16_FILE));
  const isPremiumV16 = premV16Users.includes(String(msg.from.id));   
      if (!isPremiumV16) {
    bot.sendMessage(chatId, "◇ Kamu tidak memiliki akses premium v16", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "ᴊᴏɪɴ ꜱᴇʀᴠᴇʀ", url: `https://t.me/${dev}` }],
        ],
      },
    });
    return;
  }
  
  const commandParams = (match[1] || "").split(",");
if (commandParams.length < 1 || !commandParams[0].trim()) {
  bot.sendMessage(
    chatId,
    "◇ Format Salah! Penggunaan: /cadpv16 nama"
  );
  return;
}

  const panelName = commandParams[0].trim();
  const telegramId = commandParams[1] ? commandParams[1].trim() : msg.from.id;

  const password = panelName + Math.random().toString(36).slice(2, 5);
    
  try {
    const response = await fetch(`${domainV16}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${pltaV16}`,
      },
      body: JSON.stringify({
        email: `${panelName}@gmail.com`,
        username: panelName,
        first_name: panelName,
        last_name: "admin",
        language: "en",
        root_admin: true,
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      bot.sendMessage(chatId, JSON.stringify(data.errors[0], null, 2));
      return;
    }
    const user = data.attributes;
    const userInfo =
      `<b>🛡️ ADMIN PANEL V16 BERHASIL DIBUAT</b>\n\n` +
      `<blockquote expandable><b>📋 DETAIL AKUN</b>\n` +
      `🆔 <b>ID</b> : <code>${sanitizeHtml(user.id)}</code>\n` +
      `👤 <b>Username</b> : <code>${sanitizeHtml(user.username)}</code>\n` +
      `📧 <b>Email</b> : <code>${sanitizeHtml(user.email)}</code>\n` +
      `📝 <b>Nama</b> : ${sanitizeHtml(`${user.first_name || ""} ${user.last_name || ""}`.trim())}\n` +
      `🌐 <b>Bahasa</b> : <code>${sanitizeHtml(user.language || "-")}</code>\n` +
      `🔐 <b>Hak Akses</b> : <b>${user.root_admin ? "ADMIN PANEL" : "USER"}</b></blockquote>\n\n` +
      `<i>Data akun berhasil dibuat dan siap digunakan.</i>`;
    bot.sendMessage(chatId, userInfo, { parse_mode: "HTML" });
     
    const caption = `╭━━〔 ⚡ ADMIN PANEL CREATED 〕━━╮\n\n◈ <b>Panel</b> : <b>ADMIN PANEL V16</b>!

◈ Username : <code>${user.username}</code>
🔐 Password: <code>${password}</code>
🌐 Login    : ${domainV16}

<blockquote expandable>⬡ Catatan :
Simpan informasi data ini dengan aman
dan jangan bagikan ke orang lain!
</blockquote>
`;

bot.sendPhoto(telegramId, settings.notifChannelImage, {
  caption,
  parse_mode: "HTML",
  reply_markup: {
    inline_keyboard: [[{ text: "🌐 BUKA PANEL", url: domainV16 }]]
  }
});
sendPanelToChannel(bot, { type: "ADMIN PANEL V16", username: user.username, uid: user.id, domainUrl: domainV16, createdBy: msg.from.username ? `@${msg.from.username}` : msg.from.id });

   
  } catch (error) {
    console.error(error);
    bot.sendMessage(
      chatId,
      "Terjadi kesalahan dalam pembuatan admin. Silakan coba lagi nanti."
    );
  }
});
bot.onText(/^\/cadpv17(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (featureLocks.isAdpLocked() && String(msg.from?.id) !== String(OWNER_UID)) {
    return bot.sendMessage(chatId, "<blockquote expandable>🔒 <b>CREATE ADP SEDANG DI-LOCK</b>\n\nAdmin sedang menutup akses ADP. Silakan coba lagi nanti.</blockquote>", { parse_mode: "HTML" });
  }

  const userId = msg.from.id;
  const text = match[1] || "";
    
      if ((msg.chat.type !== "group" && msg.chat.type !== "supergroup") && !settings.isOwner(msg.from.id)) {
        return bot.sendMessage(chatId, "◈ Fitur ini khusus grup.");
      }
    
  const premV17Users = JSON.parse(fs.readFileSync(PREMV17_FILE));
  const isPremiumV17 = premV17Users.includes(String(msg.from.id));   
      if (!isPremiumV17) {
    bot.sendMessage(chatId, "◇ Kamu tidak memiliki akses premium v17", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "ᴊᴏɪɴ ꜱᴇʀᴠᴇʀ", url: `https://t.me/${dev}` }],
        ],
      },
    });
    return;
  }
  
  const commandParams = (match[1] || "").split(",");
if (commandParams.length < 1 || !commandParams[0].trim()) {
  bot.sendMessage(
    chatId,
    "◇ Format Salah! Penggunaan: /cadpv17 nama"
  );
  return;
}

  const panelName = commandParams[0].trim();
  const telegramId = commandParams[1] ? commandParams[1].trim() : msg.from.id;

  const password = panelName + Math.random().toString(36).slice(2, 5);
    
  try {
    const response = await fetch(`${domainV17}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${pltaV17}`,
      },
      body: JSON.stringify({
        email: `${panelName}@gmail.com`,
        username: panelName,
        first_name: panelName,
        last_name: "admin",
        language: "en",
        root_admin: true,
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      bot.sendMessage(chatId, JSON.stringify(data.errors[0], null, 2));
      return;
    }
    const user = data.attributes;
    const userInfo =
      `<b>🛡️ ADMIN PANEL V17 BERHASIL DIBUAT</b>\n\n` +
      `<blockquote expandable><b>📋 DETAIL AKUN</b>\n` +
      `🆔 <b>ID</b> : <code>${sanitizeHtml(user.id)}</code>\n` +
      `👤 <b>Username</b> : <code>${sanitizeHtml(user.username)}</code>\n` +
      `📧 <b>Email</b> : <code>${sanitizeHtml(user.email)}</code>\n` +
      `📝 <b>Nama</b> : ${sanitizeHtml(`${user.first_name || ""} ${user.last_name || ""}`.trim())}\n` +
      `🌐 <b>Bahasa</b> : <code>${sanitizeHtml(user.language || "-")}</code>\n` +
      `🔐 <b>Hak Akses</b> : <b>${user.root_admin ? "ADMIN PANEL" : "USER"}</b></blockquote>\n\n` +
      `<i>Data akun berhasil dibuat dan siap digunakan.</i>`;
    bot.sendMessage(chatId, userInfo, { parse_mode: "HTML" });
     
    const caption = `╭━━〔 ⚡ ADMIN PANEL CREATED 〕━━╮\n\n◈ <b>Panel</b> : <b>ADMIN PANEL V17</b>!

◈ Username : <code>${user.username}</code>
🔐 Password: <code>${password}</code>
🌐 Login    : ${domainV17}

<blockquote expandable>⬡ Catatan :
Simpan informasi data ini dengan aman
dan jangan bagikan ke orang lain!
</blockquote>
`;

bot.sendPhoto(telegramId, settings.notifChannelImage, {
  caption,
  parse_mode: "HTML",
  reply_markup: {
    inline_keyboard: [[{ text: "🌐 BUKA PANEL", url: domainV17 }]]
  }
});
sendPanelToChannel(bot, { type: "ADMIN PANEL V17", username: user.username, uid: user.id, domainUrl: domainV17, createdBy: msg.from.username ? `@${msg.from.username}` : msg.from.id });

   
  } catch (error) {
    console.error(error);
    bot.sendMessage(
      chatId,
      "Terjadi kesalahan dalam pembuatan admin. Silakan coba lagi nanti."
    );
  }
});
bot.onText(/^\/cadpv18(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (featureLocks.isAdpLocked() && String(msg.from?.id) !== String(OWNER_UID)) {
    return bot.sendMessage(chatId, "<blockquote expandable>🔒 <b>CREATE ADP SEDANG DI-LOCK</b>\n\nAdmin sedang menutup akses ADP. Silakan coba lagi nanti.</blockquote>", { parse_mode: "HTML" });
  }

  const userId = msg.from.id;
  const text = match[1] || "";
    
      if ((msg.chat.type !== "group" && msg.chat.type !== "supergroup") && !settings.isOwner(msg.from.id)) {
        return bot.sendMessage(chatId, "◈ Fitur ini khusus grup.");
      }
    
  const premV18Users = JSON.parse(fs.readFileSync(PREMV18_FILE));
  const isPremiumV18 = premV18Users.includes(String(msg.from.id));   
      if (!isPremiumV18) {
    bot.sendMessage(chatId, "◇ Kamu tidak memiliki akses premium v18", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "ᴊᴏɪɴ ꜱᴇʀᴠᴇʀ", url: `https://t.me/${dev}` }],
        ],
      },
    });
    return;
  }
  
  const commandParams = (match[1] || "").split(",");
if (commandParams.length < 1 || !commandParams[0].trim()) {
  bot.sendMessage(
    chatId,
    "◇ Format Salah! Penggunaan: /cadpv18 nama"
  );
  return;
}

  const panelName = commandParams[0].trim();
  const telegramId = commandParams[1] ? commandParams[1].trim() : msg.from.id;

  const password = panelName + Math.random().toString(36).slice(2, 5);
    
  try {
    const response = await fetch(`${domainV18}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${pltaV18}`,
      },
      body: JSON.stringify({
        email: `${panelName}@gmail.com`,
        username: panelName,
        first_name: panelName,
        last_name: "admin",
        language: "en",
        root_admin: true,
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      bot.sendMessage(chatId, JSON.stringify(data.errors[0], null, 2));
      return;
    }
    const user = data.attributes;
    const userInfo =
      `<b>🛡️ ADMIN PANEL V18 BERHASIL DIBUAT</b>\n\n` +
      `<blockquote expandable><b>📋 DETAIL AKUN</b>\n` +
      `🆔 <b>ID</b> : <code>${sanitizeHtml(user.id)}</code>\n` +
      `👤 <b>Username</b> : <code>${sanitizeHtml(user.username)}</code>\n` +
      `📧 <b>Email</b> : <code>${sanitizeHtml(user.email)}</code>\n` +
      `📝 <b>Nama</b> : ${sanitizeHtml(`${user.first_name || ""} ${user.last_name || ""}`.trim())}\n` +
      `🌐 <b>Bahasa</b> : <code>${sanitizeHtml(user.language || "-")}</code>\n` +
      `🔐 <b>Hak Akses</b> : <b>${user.root_admin ? "ADMIN PANEL" : "USER"}</b></blockquote>\n\n` +
      `<i>Data akun berhasil dibuat dan siap digunakan.</i>`;
    bot.sendMessage(chatId, userInfo, { parse_mode: "HTML" });
     
    const caption = `╭━━〔 ⚡ ADMIN PANEL CREATED 〕━━╮\n\n◈ <b>Panel</b> : <b>ADMIN PANEL V18</b>!

◈ Username : <code>${user.username}</code>
🔐 Password: <code>${password}</code>
🌐 Login    : ${domainV18}

<blockquote expandable>⬡ Catatan :
Simpan informasi data ini dengan aman
dan jangan bagikan ke orang lain!
</blockquote>
`;

bot.sendPhoto(telegramId, settings.notifChannelImage, {
  caption,
  parse_mode: "HTML",
  reply_markup: {
    inline_keyboard: [[{ text: "🌐 BUKA PANEL", url: domainV18 }]]
  }
});
sendPanelToChannel(bot, { type: "ADMIN PANEL V18", username: user.username, uid: user.id, domainUrl: domainV18, createdBy: msg.from.username ? `@${msg.from.username}` : msg.from.id });

   
  } catch (error) {
    console.error(error);
    bot.sendMessage(
      chatId,
      "Terjadi kesalahan dalam pembuatan admin. Silakan coba lagi nanti."
    );
  }
});
bot.onText(/^\/cadpv19(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (featureLocks.isAdpLocked() && String(msg.from?.id) !== String(OWNER_UID)) {
    return bot.sendMessage(chatId, "<blockquote expandable>🔒 <b>CREATE ADP SEDANG DI-LOCK</b>\n\nAdmin sedang menutup akses ADP. Silakan coba lagi nanti.</blockquote>", { parse_mode: "HTML" });
  }

  const userId = msg.from.id;
  const text = match[1] || "";
    
      if ((msg.chat.type !== "group" && msg.chat.type !== "supergroup") && !settings.isOwner(msg.from.id)) {
        return bot.sendMessage(chatId, "◈ Fitur ini khusus grup.");
      }
    
  const premV19Users = JSON.parse(fs.readFileSync(PREMV19_FILE));
  const isPremiumV19 = premV19Users.includes(String(msg.from.id));   
      if (!isPremiumV19) {
    bot.sendMessage(chatId, "◇ Kamu tidak memiliki akses premium v19", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "ᴊᴏɪɴ ꜱᴇʀᴠᴇʀ", url: `https://t.me/${dev}` }],
        ],
      },
    });
    return;
  }
  
  const commandParams = (match[1] || "").split(",");
if (commandParams.length < 1 || !commandParams[0].trim()) {
  bot.sendMessage(
    chatId,
    "◇ Format Salah! Penggunaan: /cadpv19 nama"
  );
  return;
}

  const panelName = commandParams[0].trim();
  const telegramId = commandParams[1] ? commandParams[1].trim() : msg.from.id;

  const password = panelName + Math.random().toString(36).slice(2, 5);
    
  try {
    const response = await fetch(`${domainV19}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${pltaV19}`,
      },
      body: JSON.stringify({
        email: `${panelName}@gmail.com`,
        username: panelName,
        first_name: panelName,
        last_name: "admin",
        language: "en",
        root_admin: true,
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      bot.sendMessage(chatId, JSON.stringify(data.errors[0], null, 2));
      return;
    }
    const user = data.attributes;
    const userInfo =
      `<b>🛡️ ADMIN PANEL V19 BERHASIL DIBUAT</b>\n\n` +
      `<blockquote expandable><b>📋 DETAIL AKUN</b>\n` +
      `🆔 <b>ID</b> : <code>${sanitizeHtml(user.id)}</code>\n` +
      `👤 <b>Username</b> : <code>${sanitizeHtml(user.username)}</code>\n` +
      `📧 <b>Email</b> : <code>${sanitizeHtml(user.email)}</code>\n` +
      `📝 <b>Nama</b> : ${sanitizeHtml(`${user.first_name || ""} ${user.last_name || ""}`.trim())}\n` +
      `🌐 <b>Bahasa</b> : <code>${sanitizeHtml(user.language || "-")}</code>\n` +
      `🔐 <b>Hak Akses</b> : <b>${user.root_admin ? "ADMIN PANEL" : "USER"}</b></blockquote>\n\n` +
      `<i>Data akun berhasil dibuat dan siap digunakan.</i>`;
    bot.sendMessage(chatId, userInfo, { parse_mode: "HTML" });
     
    const caption = `╭━━〔 ⚡ ADMIN PANEL CREATED 〕━━╮\n\n◈ <b>Panel</b> : <b>ADMIN PANEL V19</b>!

◈ Username : <code>${user.username}</code>
🔐 Password: <code>${password}</code>
🌐 Login    : ${domainV19}

<blockquote expandable>⬡ Catatan :
Simpan informasi data ini dengan aman
dan jangan bagikan ke orang lain!
</blockquote>
`;

bot.sendPhoto(telegramId, settings.notifChannelImage, {
  caption,
  parse_mode: "HTML",
  reply_markup: {
    inline_keyboard: [[{ text: "🌐 BUKA PANEL", url: domainV19 }]]
  }
});
sendPanelToChannel(bot, { type: "ADMIN PANEL V19", username: user.username, uid: user.id, domainUrl: domainV19, createdBy: msg.from.username ? `@${msg.from.username}` : msg.from.id });

   
  } catch (error) {
    console.error(error);
    bot.sendMessage(
      chatId,
      "Terjadi kesalahan dalam pembuatan admin. Silakan coba lagi nanti."
    );
  }
});
bot.onText(/^\/cadpv20(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (featureLocks.isAdpLocked() && String(msg.from?.id) !== String(OWNER_UID)) {
    return bot.sendMessage(chatId, "<blockquote expandable>🔒 <b>CREATE ADP SEDANG DI-LOCK</b>\n\nAdmin sedang menutup akses ADP. Silakan coba lagi nanti.</blockquote>", { parse_mode: "HTML" });
  }

  const userId = msg.from.id;
  const text = match[1] || "";
    
      if ((msg.chat.type !== "group" && msg.chat.type !== "supergroup") && !settings.isOwner(msg.from.id)) {
        return bot.sendMessage(chatId, "◈ Fitur ini khusus grup.");
      }
    
  const premV20Users = JSON.parse(fs.readFileSync(PREMV20_FILE));
  const isPremiumV20 = premV20Users.includes(String(msg.from.id));   
      if (!isPremiumV20) {
    bot.sendMessage(chatId, "◇ Kamu tidak memiliki akses premium v20", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "ᴊᴏɪɴ ꜱᴇʀᴠᴇʀ", url: `https://t.me/${dev}` }],
        ],
      },
    });
    return;
  }
  
  const commandParams = (match[1] || "").split(",");
if (commandParams.length < 1 || !commandParams[0].trim()) {
  bot.sendMessage(
    chatId,
    "◇ Format Salah! Penggunaan: /cadpv20 nama"
  );
  return;
}

  const panelName = commandParams[0].trim();
  const telegramId = commandParams[1] ? commandParams[1].trim() : msg.from.id;

  const password = panelName + Math.random().toString(36).slice(2, 5);
    
  try {
    const response = await fetch(`${domainV20}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${pltaV20}`,
      },
      body: JSON.stringify({
        email: `${panelName}@gmail.com`,
        username: panelName,
        first_name: panelName,
        last_name: "admin",
        language: "en",
        root_admin: true,
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      bot.sendMessage(chatId, JSON.stringify(data.errors[0], null, 2));
      return;
    }
    const user = data.attributes;
    const userInfo =
      `<b>🛡️ ADMIN PANEL V20 BERHASIL DIBUAT</b>\n\n` +
      `<blockquote expandable><b>📋 DETAIL AKUN</b>\n` +
      `🆔 <b>ID</b> : <code>${sanitizeHtml(user.id)}</code>\n` +
      `👤 <b>Username</b> : <code>${sanitizeHtml(user.username)}</code>\n` +
      `📧 <b>Email</b> : <code>${sanitizeHtml(user.email)}</code>\n` +
      `📝 <b>Nama</b> : ${sanitizeHtml(`${user.first_name || ""} ${user.last_name || ""}`.trim())}\n` +
      `🌐 <b>Bahasa</b> : <code>${sanitizeHtml(user.language || "-")}</code>\n` +
      `🔐 <b>Hak Akses</b> : <b>${user.root_admin ? "ADMIN PANEL" : "USER"}</b></blockquote>\n\n` +
      `<i>Data akun berhasil dibuat dan siap digunakan.</i>`;
    bot.sendMessage(chatId, userInfo, { parse_mode: "HTML" });
     
    const caption = `╭━━〔 ⚡ ADMIN PANEL CREATED 〕━━╮\n\n◈ <b>Panel</b> : <b>ADMIN PANEL V20</b>!

◈ Username : <code>${user.username}</code>
🔐 Password: <code>${password}</code>
🌐 Login    : ${domainV20}

<blockquote expandable>⬡ Catatan :
Simpan informasi data ini dengan aman
dan jangan bagikan ke orang lain!
</blockquote>
`;

bot.sendPhoto(telegramId, settings.notifChannelImage, {
  caption,
  parse_mode: "HTML",
  reply_markup: {
    inline_keyboard: [[{ text: "🌐 BUKA PANEL", url: domainV20 }]]
  }
});
sendPanelToChannel(bot, { type: "ADMIN PANEL V20", username: user.username, uid: user.id, domainUrl: domainV20, createdBy: msg.from.username ? `@${msg.from.username}` : msg.from.id });

   
  } catch (error) {
    console.error(error);
    bot.sendMessage(
      chatId,
      "Terjadi kesalahan dalam pembuatan admin. Silakan coba lagi nanti."
    );
  }
});
const DB_DIR = "./db";
const DB_FILE = "./db/panelres.json";
const UNLI_FILE = "./db/unliinfo.json";
// Channel wajib-join buat /unli sekarang DIAMBIL DARI settings.js
// (settings.chUsn) -- biar gantinya cukup di satu tempat aja, gak perlu
// nyari-nyari di panel.js. Baca `settings.chUsn` tiap dipake (bukan
// dijadiin const sekali di sini) biar kalau `settings.chUsn` diedit,
// bot langsung ikut nilai baru abis restart.

function loadUnliInfo() {
  if (!fs.existsSync(UNLI_FILE)) {
    fs.writeFileSync(UNLI_FILE, JSON.stringify([], null, 2));
  }
  return JSON.parse(fs.readFileSync(UNLI_FILE));
}

function saveUnliInfo(data) {
  fs.writeFileSync(UNLI_FILE, JSON.stringify(data, null, 2));
}

if (!fs.existsSync(DB_DIR)) {
  fs.mkdirSync(DB_DIR);
}

function loadPanelRes() {
  if (!fs.existsSync(DB_FILE)) {
    fs.writeFileSync(DB_FILE, JSON.stringify({ status: true }, null, 2));
  }
  return JSON.parse(fs.readFileSync(DB_FILE));
}

function savePanelRes(data) {
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
}

function getPanelRes() {
  const db = loadPanelRes();
  return db.status;
}

function setPanelRes(status) {
  const db = loadPanelRes();
  db.status = status;
  savePanelRes(db);
}

bot.onText(/^\/panelres (on|off)$/i, (msg, match) => {
  const chatId = msg.chat.id;

  if (!settings.isOwner(msg.from.id)) {
    return bot.sendMessage(chatId, "◇ Hanya owner yang bisa menggunakan fitur ini.");
  }

  const mode = match[1].toLowerCase();

  if (mode === "on") {
    setPanelRes(true);
    bot.sendMessage(chatId, "◉ Panel Reseller berhasil diaktifkan.");
  } else {
    setPanelRes(false);
    bot.sendMessage(chatId, "⊘ Panel Reseller berhasil dimatikan.\nSemua create panel akan ditolak.");
  }
});
// ================= PANEL CONFIG =================
let currentPanel = {
  domain: domain,
  plta: plta,
  pltc: pltc
};

// ================= COMMAND PANEL =================
bot.onText(/^\/panel\s+(1[0-9]|20|[1-9])$/i, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const panelNum = match[1];

  if (!settings.isOwner(userId)) {
    return bot.sendMessage(chatId, "◇ Hanya owner yang bisa ganti panel!");
  }

  switch (panelNum) {
    case "1":
      currentPanel = { domain, plta, pltc };
      break;
    case "2":
      currentPanel = { domain: domainV2, plta: pltaV2, pltc: pltcV2 };
      break;
    case "3":
      currentPanel = { domain: domainV3, plta: pltaV3, pltc: pltcV3 };
      break;
    case "4":
      currentPanel = { domain: domainV4, plta: pltaV4, pltc: pltcV4 };
      break;
    case "5":
      currentPanel = { domain: domainV5, plta: pltaV5, pltc: pltcV5 };
      break;
    case "6":
      currentPanel = { domain: domainV6, plta: pltaV6, pltc: pltcV6 };
      break;
    case "7":
      currentPanel = { domain: domainV7, plta: pltaV7, pltc: pltcV7 };
      break;
    case "8":
      currentPanel = { domain: domainV8, plta: pltaV8, pltc: pltcV8 };
      break;
    case "9":
      currentPanel = { domain: domainV9, plta: pltaV9, pltc: pltcV9 };
      break;
    case "10":
      currentPanel = { domain: domainV10, plta: pltaV10, pltc: pltcV10 };
      break;
    case "11":
      currentPanel = { domain: domainV11, plta: pltaV11, pltc: pltcV11 };
      break;
    case "12":
      currentPanel = { domain: domainV12, plta: pltaV12, pltc: pltcV12 };
      break;
    case "13":
      currentPanel = { domain: domainV13, plta: pltaV13, pltc: pltcV13 };
      break;
    case "14":
      currentPanel = { domain: domainV14, plta: pltaV14, pltc: pltcV14 };
      break;
    case "15":
      currentPanel = { domain: domainV15, plta: pltaV15, pltc: pltcV15 };
      break;
    case "16":
      currentPanel = { domain: domainV16, plta: pltaV16, pltc: pltcV16 };
      break;
    case "17":
      currentPanel = { domain: domainV17, plta: pltaV17, pltc: pltcV17 };
      break;
    case "18":
      currentPanel = { domain: domainV18, plta: pltaV18, pltc: pltcV18 };
      break;
    case "19":
      currentPanel = { domain: domainV19, plta: pltaV19, pltc: pltcV19 };
      break;
    case "20":
      currentPanel = { domain: domainV20, plta: pltaV20, pltc: pltcV20 };
      break;
  }

  bot.sendMessage(chatId, `◉ Berhasil ganti ke Panel ${panelNum}`);
});

// ===== CREATE PANEL UNLI (V1 - V20) =====
// Dulu 20 blok /unli../unliv20 copy-paste di sini (~3300 baris).
// Sekarang satu modul konsolidasi -- lihat src/panelCreate.js.
const { registerPanelCreateHandlers } = require("./panelCreate.js");
const panelLog = require("./data/panelLog.js");
registerPanelCreateHandlers(bot, { sendPanelToChannel, loadPanelRes, RESS_FILE, OWNER_UID });
    // specs ram
const specs = {
  "1gb":  { memo: 1024,  cpu: 30,  disk: 1024 },
  "2gb":  { memo: 2048,  cpu: 60,  disk: 2048 },
  "3gb":  { memo: 3072,  cpu: 90,  disk: 3072 },
  "4gb":  { memo: 4096,  cpu: 120, disk: 4096 },
  "5gb":  { memo: 5120,  cpu: 150, disk: 5120 },
  "6gb":  { memo: 6144,  cpu: 180, disk: 6144 },
  "7gb":  { memo: 7168,  cpu: 210, disk: 7168 },
  "8gb":  { memo: 8192,  cpu: 240, disk: 8192 },
  "9gb":  { memo: 9216,  cpu: 270, disk: 9216 },
  "10gb": { memo: 10240, cpu: 300, disk: 10240 },

  "1gbv2": { memo: 1024,  cpu: 30,  disk: 1024 },
  "2gbv2": { memo: 2048,  cpu: 60,  disk: 2048 },
  "3gbv2": { memo: 3072,  cpu: 90,  disk: 3072 },
  "4gbv2": { memo: 4096,  cpu: 120, disk: 4096 },
  "5gbv2": { memo: 5120,  cpu: 150, disk: 5120 },
  "6gbv2": { memo: 6144,  cpu: 180, disk: 6144 },
  "7gbv2": { memo: 7168,  cpu: 210, disk: 7168 },
  "8gbv2": { memo: 8192,  cpu: 240, disk: 8192 },
  "9gbv2": { memo: 9216,  cpu: 270, disk: 9216 },
  "10gbv2":{ memo: 10240, cpu: 300, disk: 10240 },

  "1gbv3": { memo: 1024,  cpu: 30,  disk: 1024 },
  "2gbv3": { memo: 2048,  cpu: 60,  disk: 2048 },
  "3gbv3": { memo: 3072,  cpu: 90,  disk: 3072 },
  "4gbv3": { memo: 4096,  cpu: 120, disk: 4096 },
  "5gbv3": { memo: 5120,  cpu: 150, disk: 5120 },
  "6gbv3": { memo: 6144,  cpu: 180, disk: 6144 },
  "7gbv3": { memo: 7168,  cpu: 210, disk: 7168 },
  "8gbv3": { memo: 8192,  cpu: 240, disk: 8192 },
  "9gbv3": { memo: 9216,  cpu: 270, disk: 9216 },
  "10gbv3":{ memo: 10240, cpu: 300, disk: 10240 },

  "1gbv4": { memo: 1024,  cpu: 30,  disk: 1024 },
  "2gbv4": { memo: 2048,  cpu: 60,  disk: 2048 },
  "3gbv4": { memo: 3072,  cpu: 90,  disk: 3072 },
  "4gbv4": { memo: 4096,  cpu: 120, disk: 4096 },
  "5gbv4": { memo: 5120,  cpu: 150, disk: 5120 },
  "6gbv4": { memo: 6144,  cpu: 180, disk: 6144 },
  "7gbv4": { memo: 7168,  cpu: 210, disk: 7168 },
  "8gbv4": { memo: 8192,  cpu: 240, disk: 8192 },
  "9gbv4": { memo: 9216,  cpu: 270, disk: 9216 },
  "10gbv4":{ memo: 10240, cpu: 300, disk: 10240 },

  "1gbv5": { memo: 1024,  cpu: 30,  disk: 1024 },
  "2gbv5": { memo: 2048,  cpu: 60,  disk: 2048 },
  "3gbv5": { memo: 3072,  cpu: 90,  disk: 3072 },
  "4gbv5": { memo: 4096,  cpu: 120, disk: 4096 },
  "5gbv5": { memo: 5120,  cpu: 150, disk: 5120 },
  "6gbv5": { memo: 6144,  cpu: 180, disk: 6144 },
  "7gbv5": { memo: 7168,  cpu: 210, disk: 7168 },
  "8gbv5": { memo: 8192,  cpu: 240, disk: 8192 },
  "9gbv5": { memo: 9216,  cpu: 270, disk: 9216 },
  "10gbv5":{ memo: 10240, cpu: 300, disk: 10240 },
  
  "1gbv6": { memo: 1024,  cpu: 30,  disk: 1024 },
  "2gbv6": { memo: 2048,  cpu: 60,  disk: 2048 },
  "3gbv6": { memo: 3072,  cpu: 90,  disk: 3072 },
  "4gbv6": { memo: 4096,  cpu: 120, disk: 4096 },
  "5gbv6": { memo: 5120,  cpu: 150, disk: 5120 },
  "6gbv6": { memo: 6144,  cpu: 180, disk: 6144 },
  "7gbv6": { memo: 7168,  cpu: 210, disk: 7168 },
  "8gbv6": { memo: 8192,  cpu: 240, disk: 8192 },
  "9gbv6": { memo: 9216,  cpu: 270, disk: 9216 },
  "10gbv6":{ memo: 10240, cpu: 300, disk: 10240 },

  "1gbv7": { memo: 1024,  cpu: 30,  disk: 1024 },
  "2gbv7": { memo: 2048,  cpu: 60,  disk: 2048 },
  "3gbv7": { memo: 3072,  cpu: 90,  disk: 3072 },
  "4gbv7": { memo: 4096,  cpu: 120, disk: 4096 },
  "5gbv7": { memo: 5120,  cpu: 150, disk: 5120 },
  "6gbv7": { memo: 6144,  cpu: 180, disk: 6144 },
  "7gbv7": { memo: 7168,  cpu: 210, disk: 7168 },
  "8gbv7": { memo: 8192,  cpu: 240, disk: 8192 },
  "9gbv7": { memo: 9216,  cpu: 270, disk: 9216 },
  "10gbv7":{ memo: 10240, cpu: 300, disk: 10240 },

  "1gbv8": { memo: 1024,  cpu: 30,  disk: 1024 },
  "2gbv8": { memo: 2048,  cpu: 60,  disk: 2048 },
  "3gbv8": { memo: 3072,  cpu: 90,  disk: 3072 },
  "4gbv8": { memo: 4096,  cpu: 120, disk: 4096 },
  "5gbv8": { memo: 5120,  cpu: 150, disk: 5120 },
  "6gbv8": { memo: 6144,  cpu: 180, disk: 6144 },
  "7gbv8": { memo: 7168,  cpu: 210, disk: 7168 },
  "8gbv8": { memo: 8192,  cpu: 240, disk: 8192 },
  "9gbv8": { memo: 9216,  cpu: 270, disk: 9216 },
  "10gbv8":{ memo: 10240, cpu: 300, disk: 10240 },

  "1gbv9": { memo: 1024,  cpu: 30,  disk: 1024 },
  "2gbv9": { memo: 2048,  cpu: 60,  disk: 2048 },
  "3gbv9": { memo: 3072,  cpu: 90,  disk: 3072 },
  "4gbv9": { memo: 4096,  cpu: 120, disk: 4096 },
  "5gbv9": { memo: 5120,  cpu: 150, disk: 5120 },
  "6gbv9": { memo: 6144,  cpu: 180, disk: 6144 },
  "7gbv9": { memo: 7168,  cpu: 210, disk: 7168 },
  "8gbv9": { memo: 8192,  cpu: 240, disk: 8192 },
  "9gbv9": { memo: 9216,  cpu: 270, disk: 9216 },
  "10gbv9":{ memo: 10240, cpu: 300, disk: 10240 },

  "1gbv10": { memo: 1024,  cpu: 30,  disk: 1024 },
  "2gbv10": { memo: 2048,  cpu: 60,  disk: 2048 },
  "3gbv10": { memo: 3072,  cpu: 90,  disk: 3072 },
  "4gbv10": { memo: 4096,  cpu: 120, disk: 4096 },
  "5gbv10": { memo: 5120,  cpu: 150, disk: 5120 },
  "6gbv10": { memo: 6144,  cpu: 180, disk: 6144 },
  "7gbv10": { memo: 7168,  cpu: 210, disk: 7168 },
  "8gbv10": { memo: 8192,  cpu: 240, disk: 8192 },
  "9gbv10": { memo: 9216,  cpu: 270, disk: 9216 },
  "10gbv10":{ memo: 10240, cpu: 300, disk: 10240 },

  "1gbv11": { memo: 1024, cpu: 30, disk: 1024 },
  "2gbv11": { memo: 2048, cpu: 60, disk: 2048 },
  "3gbv11": { memo: 3072, cpu: 90, disk: 3072 },
  "4gbv11": { memo: 4096, cpu: 120, disk: 4096 },
  "5gbv11": { memo: 5120, cpu: 150, disk: 5120 },
  "6gbv11": { memo: 6144, cpu: 180, disk: 6144 },
  "7gbv11": { memo: 7168, cpu: 210, disk: 7168 },
  "8gbv11": { memo: 8192, cpu: 240, disk: 8192 },
  "9gbv11": { memo: 9216, cpu: 270, disk: 9216 },
  "10gbv11": { memo: 10240, cpu: 300, disk: 10240 },

  "1gbv12": { memo: 1024, cpu: 30, disk: 1024 },
  "2gbv12": { memo: 2048, cpu: 60, disk: 2048 },
  "3gbv12": { memo: 3072, cpu: 90, disk: 3072 },
  "4gbv12": { memo: 4096, cpu: 120, disk: 4096 },
  "5gbv12": { memo: 5120, cpu: 150, disk: 5120 },
  "6gbv12": { memo: 6144, cpu: 180, disk: 6144 },
  "7gbv12": { memo: 7168, cpu: 210, disk: 7168 },
  "8gbv12": { memo: 8192, cpu: 240, disk: 8192 },
  "9gbv12": { memo: 9216, cpu: 270, disk: 9216 },
  "10gbv12": { memo: 10240, cpu: 300, disk: 10240 },

  "1gbv13": { memo: 1024, cpu: 30, disk: 1024 },
  "2gbv13": { memo: 2048, cpu: 60, disk: 2048 },
  "3gbv13": { memo: 3072, cpu: 90, disk: 3072 },
  "4gbv13": { memo: 4096, cpu: 120, disk: 4096 },
  "5gbv13": { memo: 5120, cpu: 150, disk: 5120 },
  "6gbv13": { memo: 6144, cpu: 180, disk: 6144 },
  "7gbv13": { memo: 7168, cpu: 210, disk: 7168 },
  "8gbv13": { memo: 8192, cpu: 240, disk: 8192 },
  "9gbv13": { memo: 9216, cpu: 270, disk: 9216 },
  "10gbv13": { memo: 10240, cpu: 300, disk: 10240 },

  "1gbv14": { memo: 1024, cpu: 30, disk: 1024 },
  "2gbv14": { memo: 2048, cpu: 60, disk: 2048 },
  "3gbv14": { memo: 3072, cpu: 90, disk: 3072 },
  "4gbv14": { memo: 4096, cpu: 120, disk: 4096 },
  "5gbv14": { memo: 5120, cpu: 150, disk: 5120 },
  "6gbv14": { memo: 6144, cpu: 180, disk: 6144 },
  "7gbv14": { memo: 7168, cpu: 210, disk: 7168 },
  "8gbv14": { memo: 8192, cpu: 240, disk: 8192 },
  "9gbv14": { memo: 9216, cpu: 270, disk: 9216 },
  "10gbv14": { memo: 10240, cpu: 300, disk: 10240 },

  "1gbv15": { memo: 1024, cpu: 30, disk: 1024 },
  "2gbv15": { memo: 2048, cpu: 60, disk: 2048 },
  "3gbv15": { memo: 3072, cpu: 90, disk: 3072 },
  "4gbv15": { memo: 4096, cpu: 120, disk: 4096 },
  "5gbv15": { memo: 5120, cpu: 150, disk: 5120 },
  "6gbv15": { memo: 6144, cpu: 180, disk: 6144 },
  "7gbv15": { memo: 7168, cpu: 210, disk: 7168 },
  "8gbv15": { memo: 8192, cpu: 240, disk: 8192 },
  "9gbv15": { memo: 9216, cpu: 270, disk: 9216 },
  "10gbv15": { memo: 10240, cpu: 300, disk: 10240 },

  "1gbv16": { memo: 1024, cpu: 30, disk: 1024 },
  "2gbv16": { memo: 2048, cpu: 60, disk: 2048 },
  "3gbv16": { memo: 3072, cpu: 90, disk: 3072 },
  "4gbv16": { memo: 4096, cpu: 120, disk: 4096 },
  "5gbv16": { memo: 5120, cpu: 150, disk: 5120 },
  "6gbv16": { memo: 6144, cpu: 180, disk: 6144 },
  "7gbv16": { memo: 7168, cpu: 210, disk: 7168 },
  "8gbv16": { memo: 8192, cpu: 240, disk: 8192 },
  "9gbv16": { memo: 9216, cpu: 270, disk: 9216 },
  "10gbv16": { memo: 10240, cpu: 300, disk: 10240 },

  "1gbv17": { memo: 1024, cpu: 30, disk: 1024 },
  "2gbv17": { memo: 2048, cpu: 60, disk: 2048 },
  "3gbv17": { memo: 3072, cpu: 90, disk: 3072 },
  "4gbv17": { memo: 4096, cpu: 120, disk: 4096 },
  "5gbv17": { memo: 5120, cpu: 150, disk: 5120 },
  "6gbv17": { memo: 6144, cpu: 180, disk: 6144 },
  "7gbv17": { memo: 7168, cpu: 210, disk: 7168 },
  "8gbv17": { memo: 8192, cpu: 240, disk: 8192 },
  "9gbv17": { memo: 9216, cpu: 270, disk: 9216 },
  "10gbv17": { memo: 10240, cpu: 300, disk: 10240 },

  "1gbv18": { memo: 1024, cpu: 30, disk: 1024 },
  "2gbv18": { memo: 2048, cpu: 60, disk: 2048 },
  "3gbv18": { memo: 3072, cpu: 90, disk: 3072 },
  "4gbv18": { memo: 4096, cpu: 120, disk: 4096 },
  "5gbv18": { memo: 5120, cpu: 150, disk: 5120 },
  "6gbv18": { memo: 6144, cpu: 180, disk: 6144 },
  "7gbv18": { memo: 7168, cpu: 210, disk: 7168 },
  "8gbv18": { memo: 8192, cpu: 240, disk: 8192 },
  "9gbv18": { memo: 9216, cpu: 270, disk: 9216 },
  "10gbv18": { memo: 10240, cpu: 300, disk: 10240 },

  "1gbv19": { memo: 1024, cpu: 30, disk: 1024 },
  "2gbv19": { memo: 2048, cpu: 60, disk: 2048 },
  "3gbv19": { memo: 3072, cpu: 90, disk: 3072 },
  "4gbv19": { memo: 4096, cpu: 120, disk: 4096 },
  "5gbv19": { memo: 5120, cpu: 150, disk: 5120 },
  "6gbv19": { memo: 6144, cpu: 180, disk: 6144 },
  "7gbv19": { memo: 7168, cpu: 210, disk: 7168 },
  "8gbv19": { memo: 8192, cpu: 240, disk: 8192 },
  "9gbv19": { memo: 9216, cpu: 270, disk: 9216 },
  "10gbv19": { memo: 10240, cpu: 300, disk: 10240 },

  "1gbv20": { memo: 1024, cpu: 30, disk: 1024 },
  "2gbv20": { memo: 2048, cpu: 60, disk: 2048 },
  "3gbv20": { memo: 3072, cpu: 90, disk: 3072 },
  "4gbv20": { memo: 4096, cpu: 120, disk: 4096 },
  "5gbv20": { memo: 5120, cpu: 150, disk: 5120 },
  "6gbv20": { memo: 6144, cpu: 180, disk: 6144 },
  "7gbv20": { memo: 7168, cpu: 210, disk: 7168 },
  "8gbv20": { memo: 8192, cpu: 240, disk: 8192 },
  "9gbv20": { memo: 9216, cpu: 270, disk: 9216 },
  "10gbv20": { memo: 10240, cpu: 300, disk: 10240 }
};
bot.onText(/^\/(1|2|3|4|5|6|7|8|9|10)gb(?:\s+(.+))?$/i,
  async (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;

      if ((msg.chat.type !== "group" && msg.chat.type !== "supergroup") && !settings.isOwner(msg.from.id)) {
        return bot.sendMessage(chatId, "◈ Fitur ini khusus grup.");
      }

    // ===== RESELLER CHECK =====
    const ressUsers = JSON.parse(fs.readFileSync(RESS_FILE));
    if (!roleAccess.hasActiveRole("reseller", userId)) {
    return bot.sendMessage(chatId, roleAccess.restrictedResellerText(), {
      parse_mode: "HTML",
      reply_markup: roleAccess.restrictedResellerKeyboard(),
    });
  }

    const size = match[1]; // 1-10
    const text = match[2]; // nama

    // ===== VALIDASI FORMAT =====
    if (!text) {
      return bot.sendMessage(
        chatId,
        `◇ Format Salah!\n\nGunakan:\n/${size}gb nama`
      );
    }

    const username = text.trim().toLowerCase();

    if (!username) {
      return bot.sendMessage(
        chatId,
        `◇ Format Salah!\n\nGunakan:\n/${size}gb nama`
      );
    }

    // ===== AMBIL SPEK =====
    const key = `${size}gb`;
    const spec = specs[key];
    if (!spec) {
      return bot.sendMessage(chatId, "◇ Spesifikasi tidak ditemukan");
    }

    // ===== GLOBAL PANEL CONFIG =====
    const panelDomain = domain;
    const panelToken = plta;
    const email = `${username}@gmail.com`;

    // ===== PASSWORD RANDOM =====
    const chars =
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    const password = Array.from({ length: 8 }, () =>
      chars[Math.floor(Math.random() * chars.length)]
    ).join("");

    let user, server;

    try {
      // ===== CREATE USER =====
      const resUser = await fetch(`${panelDomain}/api/application/users`, {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${panelToken}`,
        },
        body: JSON.stringify({
          email,
          username,
          first_name: username,
          last_name: username,
          language: "en",
          password,
        }),
      });

      const du = await resUser.json();
      if (du.errors) {
        return bot.sendMessage(chatId, `◇ ${du.errors[0].detail}`);
      }

      user = du.attributes;

      // ===== CREATE SERVER =====
      const resServer = await fetch(`${panelDomain}/api/application/servers`, {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${panelToken}`,
        },
        body: JSON.stringify({
          name: `${username}-${size}GB`,
          user: user.id,
          egg: parseInt(settings.eggs),
          docker_image: "ghcr.io/parkervcp/yolks:nodejs_20",
          startup:
            'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then npm install ${NODE_PACKAGES}; fi; if [ -f package.json ]; then npm install; fi; npm start',
          environment: {
            INST: "npm",
            USER_UPLOAD: "0",
            AUTO_UPDATE: "0",
            CMD_RUN: "npm start",
          },
          limits: {
            memory: spec.memo,
            swap: 0,
            disk: spec.disk,
            io: 500,
            cpu: spec.cpu,
          },
          feature_limits: {
            databases: 5,
            backups: 5,
            allocations: 1,
          },
          deploy: {
            locations: [parseInt(settings.loc)],
            dedicated_ip: false,
            port_range: [],
          },
        }),
      });

      const ds = await resServer.json();
      server = ds.attributes;

      // ===== INFO KE GRUP (TIDAK DIUBAH) =====
      bot.sendMessage(
        chatId,
        `NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory} MB
DISK: ${server.limits.disk} MB
CPU: ${server.limits.cpu}%`
      );

      // ===== KIRIM DATA PANEL KE CHAT YANG SAMA =====
      bot.sendPhoto(
        chatId,
        "https://files.catbox.moe/a7ljii.jpeg",
        {
          caption: `<blockquote expandable>
<blockquote expandable>⚿ BERIKUT DATA PANEL ${size}GB ANDA</blockquote>
⟐ Login: ${domain}/
◉ Username: ${user.username}
⚷ Password: <code>${password}</code>

<blockquote expandable>⬡ Rules Panel!</blockquote>
- Jangan DDoS
- Jangan sebar domain
- Simpan data panel anda!!
</blockquote>`,
          parse_mode: "HTML",
        }
      );
    } catch (err) {
      console.error(err);
      bot.sendMessage(chatId, "◇ Gagal membuat panel.");
    }
  }
);
bot.onText(/^\/(1|2|3|4|5|6|7|8|9|10)gbv([2-9]|1[0-9]|20)(?:\s+)?(.*)?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

      if ((msg.chat.type !== "group" && msg.chat.type !== "supergroup") && !settings.isOwner(msg.from.id)) {
        return bot.sendMessage(chatId, "◈ Fitur ini khusus grup.");
      }

  const ressUsers = JSON.parse(fs.readFileSync(RESS_FILE));
  if (!roleAccess.hasActiveRole("reseller", userId)) {
    return bot.sendMessage(chatId, roleAccess.restrictedResellerText(), {
      parse_mode: "HTML",
      reply_markup: roleAccess.restrictedResellerKeyboard(),
    });
  }

  const size = match[1];
  const ver = match[2];
  const text = match[3];

  if (!text) {
    return bot.sendMessage(
      chatId,
      `◇ Format Salah: /${size}gbv${ver} nama,id`
    );
  }

  const t = text.split(",");
  if (t.length < 2) {
    return bot.sendMessage(
      chatId,
      `◇ Format Salah: /${size}gbv${ver} nama,id`
    );
  }

  const key = `${size}gbv${ver}`;
  const spec = specs[key];
  if (!spec) {
    return bot.sendMessage(chatId, "◇ Spesifikasi tidak ditemukan");
  }

  const domain = domainMap[ver];
  const plta = pltaMap[ver];

  const username = t[0].trim();
  const targetId = t[1].trim();
  const name = username + `${size}gb`;

  const egg = settings.eggs;
  const loc = settings.loc;
  const email = `${username}@gmail.com`;

  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  const password = Array.from(
    { length: 8 },
    () => chars[Math.floor(Math.random() * chars.length)]
  ).join("");

  let user, server;

  try {
    const resUser = await fetch(`${domain}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        email,
        username,
        first_name: username,
        last_name: username,
        language: "en",
        password,
      }),
    });

    const du = await resUser.json();
    if (du.errors) {
      return bot.sendMessage(chatId, `Error: ${du.errors[0].detail}`);
    }

    user = du.attributes;

    const resServer = await fetch(`${domain}/api/application/servers`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        name,
        user: user.id,
        egg: parseInt(egg),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_20",
        startup:
          'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}',
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start",
        },
        limits: {
          memory: spec.memo,
          swap: 0,
          disk: spec.disk,
          io: 500,
          cpu: spec.cpu,
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1,
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: [],
        },
      }),
    });

    const ds = await resServer.json();
    server = ds.attributes;
  } catch (e) {
    return bot.sendMessage(chatId, `Error: ${e.message}`);
  }

  bot.sendMessage(
    chatId,
    `NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory} MB
DISK: ${server.limits.disk} MB
CPU: ${server.limits.cpu}%`
  );

bot.sendPhoto(
  targetId,
  "https://files.catbox.moe/a7ljii.jpeg",
  {
    caption: `<blockquote expandable>
<blockquote expandable>⚿ BERIKUT DATA PANEL ${size}GB V${ver} ANDA</blockquote>
⟐ Login: ${domain}/
◉ Username: ${user.username}
⚷ Password: <code>${password}</code>

<blockquote expandable>⬡ Rules Panel!</blockquote>
- Jangan DDoS
- Jangan sebar domain
- Simpan data panel anda!!
</blockquote>`,
    parse_mode: "HTML"
  }
);

  bot.sendMessage(chatId, "◉ Data panel telah dikirim ke chat pribadi pengguna!");
});
    
bot.onText(/^\/delsrv (.+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const srv = match[1].trim();

  const isCooldown = checkCooldown(msg);
  if (isCooldown) return bot.sendMessage(chatId, isCooldown);

  const ownerUsers = JSON.parse(fs.readFileSync(OWNER_FILE));
  if (!ownerUsers.includes(String(msg.from.id))) {
    return bot.sendMessage(chatId, "⌖ Perintah ini khusus owner.", {
      reply_markup: {
        inline_keyboard: [[{ text: "ʟᴀᴘᴏʀᴀɴ", url: `https://t.me/${dev}` }]]
      }
    });
  }

  if (!srv) {
    return bot.sendMessage(
      chatId,
      "⚠ Gunakan format:\n/delsrv <ID_SERVER>"
    );
  }

  try {
    const del = await fetch(`${domain}/api/application/servers/${srv}`, {
      method: "DELETE",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
    });

    /* ====== STATUS VALIDATION ====== */

    if (del.status === 204) {
      return bot.sendMessage(
        chatId,
        `<blockquote expandable>◉ <b>SERVER BERHASIL DIHAPUS</b>

⌇ <b>ID</b>: <code>${srv}</code>
⟲ Status: <b>Clean</b>
</blockquote>`,
        {
          parse_mode: "HTML",
          reply_to_message_id: msg.message_id,
        }
      );
    }

    if (del.status === 404) {
      return bot.sendMessage(
        chatId,
        `<blockquote expandable>◇ <b>SERVER TIDAK DITEMUKAN</b>

⌇ <b>ID</b>: <code>${srv}</code>
</blockquote>`,
        { parse_mode: "HTML" }
      );
    }

    /* ====== ERROR LAIN ====== */
    const errText = await del.text();
    console.error("DEL SRV ERROR:", errText);

    bot.sendMessage(
      chatId,
      `<blockquote expandable>⚠ <b>GAGAL MENGHAPUS SERVER</b>

⌇ <b>ID</b>: <code>${srv}</code>
◈ <b>Status</b>: ${del.status}
</blockquote>`,
      { parse_mode: "HTML" }
    );

  } catch (error) {
    console.error("DEL SRV CATCH:", error);
    bot.sendMessage(
      chatId,
      "⚠ Terjadi kesalahan sistem saat menghapus server."
    );
  }
});

bot.onText(/^\/listsrvoff$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (msg.text.trim() !== "/listsrvoff") return;

  if (
    (msg.chat.type !== "group" && msg.chat.type !== "supergroup") &&
    !settings.isOwner(userId)
  ) return bot.sendMessage(chatId, "◇ Khusus grup!");

  const ownerUsers = JSON.parse(fs.readFileSync(OWNER_FILE));
  if (!ownerUsers.includes(String(userId)))
    return bot.sendMessage(chatId, "◇ Khusus owner");

  const loading = await bot.sendMessage(
    chatId,
    "<blockquote expandable>⏳ <b>Proses mengambil daftar server offline...</b></blockquote>",
    { parse_mode: "HTML" }
  );

  await renderOfflineServerListSingle(chatId, 1, loading.message_id);
});

bot.on("callback_query", async (q) => {
  if (!q.data.startsWith("srvoffs_page_")) return;

  const chatId = q.message.chat.id;
  const messageId = q.message.message_id;
  const page = parseInt(q.data.split("_")[2]);

  await bot.editMessageText(
    "<blockquote expandable>⏳ <b>Proses mengambil daftar userver offline...</b></blockquote>",
    {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: "HTML",
    }
  );

  await renderOfflineServerListSingle(chatId, page, messageId);
  await bot.answerCallbackQuery(q.id);
});

async function renderOfflineServerListSingle(chatId, page, editMessageId) {
  try {
    const limit = 15;

    // ambil SEMUA server lalu filter offline
    let offline = [];
    let p = 1;
    let totalPages = 1;

    do {
      const f = await fetch(`${domain}/api/application/servers?page=${p}`, {
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${plta}`,
        },
      });

      const res = await f.json();
      const servers = res.data || [];
      totalPages = res?.meta?.pagination?.total_pages || 1;

      for (const server of servers) {
        const s = server.attributes;
        let status = s.status;

        try {
          const f3 = await fetch(
            `${domain}/api/client/servers/${s.uuid.split("-")[0]}/resources`,
            {
              headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${pltc}`,
              },
            }
          );
          const data = await f3.json();
          if (data?.attributes?.current_state)
            status = data.attributes.current_state;
        } catch {}

        if (status === "offline") {
          offline.push({ id: s.id, name: s.name, status });
        }
      }
      p++;
    } while (p <= totalPages);

    if (offline.length === 0) {
      return bot.editMessageText(
        "<blockquote expandable>◉ <b>Tidak ada server offline</b></blockquote>",
        {
          chat_id: chatId,
          message_id: editMessageId,
          parse_mode: "HTML",
        }
      );
    }

    // pagination manual dari hasil offline
    const totalOfflinePages = Math.ceil(offline.length / limit);
    const start = (page - 1) * limit;
    const slice = offline.slice(start, start + limit);

    let content = `⊘ <b>Daftar Server Offline</b>
Halaman ${page}/${totalOfflinePages}
Total: ${offline.length}

`;

    for (const s of slice) {
      content += `⌇ <b>ID</b>: ${s.id}
▭ <b>Nama</b>: ${s.name}
⊘ <b>Status</b>: offline

`;
    }

    const text = `<blockquote expandable>${content}</blockquote>`;

    const buttons = [];
    if (page > 1) {
      buttons.push({
        text: "⬅ ‹",
        callback_data: `srvoffs_page_${page - 1}`,
      });
    }
    if (page < totalOfflinePages) {
      buttons.push({
        text: "➡ Lanjut",
        callback_data: `srvoffs_page_${page + 1}`,
      });
    }

    await bot.editMessageText(text, {
      chat_id: chatId,
      message_id: editMessageId,
      parse_mode: "HTML",
      reply_markup: buttons.length
        ? { inline_keyboard: [buttons] }
        : undefined,
    });
  } catch (err) {
    console.error(err);
    await bot.editMessageText(
      "<blockquote expandable>◇ <b>Gagal memuat server offline</b></blockquote>",
      {
        chat_id: chatId,
        message_id: editMessageId,
        parse_mode: "HTML",
      }
    );
  }
}

bot.onText(/^\/listsrvoff(([2-9]|1[0-9]|20))$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const ver = match[1];

  if (msg.text.trim() !== `/listsrvoff${ver}`) return;

  if (
    (msg.chat.type !== "group" && msg.chat.type !== "supergroup") &&
    !settings.isOwner(userId)
  ) return bot.sendMessage(chatId, "◇ Khusus grup!");

  const ownerUsers = JSON.parse(fs.readFileSync(OWNER_FILE));
  if (!ownerUsers.includes(String(userId)))
    return bot.sendMessage(chatId, "◇ Khusus owner");

  const domain = domainMap[ver];
  const plta = pltaMap[ver];
  const pltc = pltcMap[ver];

  if (!domain || !plta || !pltc)
    return bot.sendMessage(chatId, "◇ Konfigurasi panel tidak ditemukan");

  const loading = await bot.sendMessage(
    chatId,
    "<blockquote expandable>⏳ <b>Proses mengambi daftarl server offline...</b></blockquote>",
    { parse_mode: "HTML" }
  );

  await renderOfflineServerList(chatId, ver, 1, loading.message_id);
});

bot.on("callback_query", async (q) => {
  if (!q.data.startsWith("srvoff_page_")) return;

  const [, , ver, pageStr] = q.data.split("_");
  const page = parseInt(pageStr);

  const chatId = q.message.chat.id;
  const messageId = q.message.message_id;

  const domain = domainMap[ver];
  const plta = pltaMap[ver];
  const pltc = pltcMap[ver];

  if (!domain || !plta || !pltc) {
    return bot.answerCallbackQuery(q.id, {
      text: "Panel tidak ditemukan",
      show_alert: true,
    });
  }

  await bot.editMessageText(
    "<blockquote expandable>⏳ <b>Proses mengambil daftar server offline...</b></blockquote>",
    {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: "HTML",
    }
  );

  await renderOfflineServerList(chatId, ver, page, messageId);
  await bot.answerCallbackQuery(q.id);
});

async function renderOfflineServerList(chatId, ver, page, editMessageId) {
  try {
    const limit = 15;
    const domain = domainMap[ver];
    const plta = pltaMap[ver];
    const pltc = pltcMap[ver];

    let offline = [];
    let p = 1;
    let totalPages = 1;

    do {
      const f = await fetch(`${domain}/api/application/servers?page=${p}`, {
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${plta}`,
        },
      });

      const res = await f.json();
      const servers = res?.data || [];
      totalPages = res?.meta?.pagination?.total_pages || 1;

      for (const server of servers) {
        const s = server.attributes;
        let status = s.status;

        try {
          const f3 = await fetch(
            `${domain}/api/client/servers/${s.uuid.split("-")[0]}/resources`,
            {
              headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${pltc}`,
              },
            }
          );
          const data = await f3.json();
          if (data?.attributes?.current_state)
            status = data.attributes.current_state;
        } catch {}

        if (status === "offline") {
          offline.push({ id: s.id, name: s.name });
        }
      }

      p++;
    } while (p <= totalPages);

    if (offline.length === 0) {
      return bot.editMessageText(
        "<blockquote expandable>◉ <b>Tidak ada server offline</b></blockquote>",
        {
          chat_id: chatId,
          message_id: editMessageId,
          parse_mode: "HTML",
        }
      );
    }

    const totalOfflinePages = Math.ceil(offline.length / limit);
    const start = (page - 1) * limit;
    const slice = offline.slice(start, start + limit);

    let content = `⊘ <b>Daftar Server Offline (Panel ${ver})</b>
Halaman ${page}/${totalOfflinePages}
Total: ${offline.length}

`;

    for (const s of slice) {
      content += `⌇ <b>ID</b>: ${s.id}
▭ <b>Nama</b>: ${s.name}
⊘ <b>Status</b>: offline

`;
    }

    const buttons = [];

    if (page > 1) {
      buttons.push({
        text: "⬅ ‹",
        callback_data: `srvoff_page_${ver}_${page - 1}`,
      });
    }

    if (page < totalOfflinePages) {
      buttons.push({
        text: "➡ Lanjut",
        callback_data: `srvoff_page_${ver}_${page + 1}`,
      });
    }

    await bot.editMessageText(`<blockquote expandable>${content}</blockquote>`, {
      chat_id: chatId,
      message_id: editMessageId,
      parse_mode: "HTML",
      reply_markup: buttons.length
        ? { inline_keyboard: [buttons] }
        : undefined,
    });
  } catch (err) {
    console.error(err);
    await bot.editMessageText(
      "<blockquote expandable>◇ <b>Gagal memuat server offline</b></blockquote>",
      {
        chat_id: chatId,
        message_id: editMessageId,
        parse_mode: "HTML",
      }
    );
  }
}
   
// ================= HELPER =================
const sleep = (ms) => new Promise(res => setTimeout(res, ms));

async function safeFetch(url, options, retry = 3) {
  for (let i = 0; i < retry; i++) {
    try {
      let res = await fetch(url, options);

      // ⟡ HANDLE RATE LIMIT CF
      if (res.status === 429) {
        await sleep(3000); // tunggu 3 detik
        continue;
      }

      return res;
    } catch (e) {
      if (i === retry - 1) throw e;
      await sleep(2000);
    }
  }
}

// ================= COMMAND =================
bot.onText(/\/clearoff/, async (msg) => {
  const chatId = msg.chat.id;

  if (msg.text.trim() !== `/clearoff`) return;

  const isCooldown = checkCooldown(msg);
  if (isCooldown) return bot.sendMessage(chatId, isCooldown);

  const ownerUsers = JSON.parse(fs.readFileSync(OWNER_FILE));
  const isOwner = ownerUsers.includes(String(msg.from.id));
  if (!isOwner) {
    return bot.sendMessage(chatId, "⌖ Perintah ini khusus owner.", {
      reply_markup: { inline_keyboard: [[{ text: "ʟᴀᴘᴏʀᴀɴ", url: `https://t.me/${dev}` }]] },
    });
  }

  let serverSuccess = [];
  let serverFailed = [];
  let userSuccess = [];
  let userFailed = [];

  try {
    await bot.sendMessage(chatId, "⏳ Menghapus semua server & user offline...");

    let offlineServers = [];
    let page = 1;
    let totalPages = 1;

    // ================= SERVER =================
    do {
      let f = await safeFetch(`${domain}/api/application/servers?page=${page}`, {
        headers: { Accept: "application/json", Authorization: `Bearer ${plta}` },
      });

      let res = await f.json();
      let servers = res.data || [];
      totalPages = res?.meta?.pagination?.total_pages || 1;

      for (let server of servers) {
        let s = server.attributes;
        let status = s.status;

        try {
          let f3 = await safeFetch(`${domain}/api/client/servers/${s.uuid.split("-")[0]}/resources`, {
            headers: { Accept: "application/json", Authorization: `Bearer ${pltc}` },
          });

          let data = await f3.json();
          if (data?.attributes?.current_state) {
            status = data.attributes.current_state;
          }
        } catch {}

        if (status === "offline") {
          offlineServers.push({ id: s.id, name: s.name });
        }

        await sleep(500); // ⟡ DELAY BIAR AMAN CF
      }

      page++;
      await sleep(1000); // delay antar page
    } while (page <= totalPages);

    // DELETE SERVER (QUEUE)
    for (let srv of offlineServers) {
      try {
        let del = await safeFetch(`${domain}/api/application/servers/${srv.id}`, {
          method: "DELETE",
          headers: { Accept: "application/json", Authorization: `Bearer ${plta}` },
        });

        if (del.status === 204) {
          serverSuccess.push(srv);
        } else {
          serverFailed.push(srv);
        }
      } catch {
        serverFailed.push(srv);
      }

      await sleep(1500); // ⟡ WAJIB (hapus = sensitif)
    }

    // ================= USER =================
    let offlineUsers = [];
    page = 1;
    totalPages = 1;

    do {
      let f = await safeFetch(`${domain}/api/application/users?page=${page}`, {
        headers: { Accept: "application/json", Authorization: `Bearer ${plta}` },
      });

      let res = await f.json();
      let users = res.data || [];
      totalPages = res?.meta?.pagination?.total_pages || 1;

      for (let user of users) {
        let u = user.attributes;

        if (u.root_admin) continue;

        let hasServer = false;

        try {
          let serverCheck = await safeFetch(`${domain}/api/application/servers?filter[user_id]=${u.id}`, {
            headers: { Accept: "application/json", Authorization: `Bearer ${plta}` },
          });

          let serverData = await serverCheck.json();
          if (serverData?.data?.length > 0) hasServer = true;
        } catch {}

        if (!hasServer) {
          offlineUsers.push({
            id: u.id,
            username: u.username,
            email: u.email,
          });
        }

        await sleep(500); // ⟡ delay
      }

      page++;
      await sleep(1000);
    } while (page <= totalPages);

    // DELETE USER
    for (let user of offlineUsers) {
      try {
        let del = await safeFetch(`${domain}/api/application/users/${user.id}`, {
          method: "DELETE",
          headers: { Accept: "application/json", Authorization: `Bearer ${plta}` },
        });

        if (del.status === 204) {
          userSuccess.push(user);
        } else {
          userFailed.push(user);
        }
      } catch {
        userFailed.push(user);
      }

      await sleep(1500); // ⟡ delay wajib
    }

  } catch (err) {
    console.error("PROCESS ERROR:", err);
  }

  // ================= HASIL =================
  let report = `<blockquote expandable>◉ <b>CLEAR OFF SELESAI</b>

⬢ Server Offline
├ ◉ Berhasil: ${serverSuccess.length}
└ ◇ Gagal: ${serverFailed.length}

◉ User Tanpa Server
├ ◉ Berhasil: ${userSuccess.length}
└ ◇ Gagal: ${userFailed.length}</blockquote>`;

  try {
    await bot.sendMessage(chatId, report, { parse_mode: "HTML" });
  } catch {
    await bot.sendMessage(chatId,
`◉ CLEAR OFF SELESAI

⬢ Server Offline
├ ◉ Berhasil: ${serverSuccess.length}
└ ◇ Gagal: ${serverFailed.length}

◉ User Tanpa Server
├ ◉ Berhasil: ${userSuccess.length}
└ ◇ Gagal: ${userFailed.length}`
    );
  }
});
bot.onText(/^\/clearoff(([2-9]|1[0-9]|20))$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const ver = match[1];

  if (msg.text.trim() !== `/clearoff${ver}`) return;

  const domain = domainMap[ver];
  const plta = pltaMap[ver];
  const pltc = pltcMap[ver];

  if (!domain || !plta || !pltc) {
    return bot.sendMessage(chatId, "◇ Konfigurasi domain tidak valid");
  }

      if ((msg.chat.type !== "group" && msg.chat.type !== "supergroup") && !settings.isOwner(msg.from.id)) {
        return bot.sendMessage(chatId, "◈ Fitur ini khusus grup.");
      }

  const isCooldown = checkCooldown(msg);
  if (isCooldown) return bot.sendMessage(chatId, isCooldown);

  const ownerUsers = JSON.parse(fs.readFileSync(OWNER_FILE));
  if (!ownerUsers.includes(String(msg.from.id))) {
    return bot.sendMessage(chatId, "⌖ Perintah ini khusus owner.", {
      reply_markup: {
        inline_keyboard: [[{ text: "ʟᴀᴘᴏʀᴀɴ", url: `https://t.me/${dev}` }]],
      },
    });
  }

  try {
    await bot.sendMessage(
      chatId,
      `<blockquote expandable>⏳ Membersihkan server & user OFFLINE (Panel ${ver})...</blockquote>`,
      { parse_mode: "HTML" }
    );

    /* ================= SERVER OFFLINE ================= */

    let offlineServers = [];
    let page = 1;
    let totalPages = 1;

    do {
      const f = await fetch(`${domain}/api/application/servers?page=${page}`, {
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${plta}`,
        },
      });

      const res = await f.json();
      totalPages = res.meta.pagination.total_pages;

      for (const server of res.data) {
        const s = server.attributes;
        let status = "offline";

        try {
          const f3 = await fetch(
            `${domain}/api/client/servers/${s.identifier}/resources`,
            {
              headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${pltc}`,
              },
            }
          );
          const data = await f3.json();
          if (data?.attributes?.current_state)
            status = data.attributes.current_state;
        } catch {}

        if (status === "offline") {
          offlineServers.push({ id: s.id, name: s.name });
        }
      }

      page++;
    } while (page <= totalPages);

    let serverSuccess = [];
    let serverFailed = [];

    for (const srv of offlineServers) {
      try {
        const del = await fetch(
          `${domain}/api/application/servers/${srv.id}`,
          {
            method: "DELETE",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: `Bearer ${plta}`,
            },
          }
        );

        if (del.status === 204)
          serverSuccess.push(`◉ ${srv.name} (ID: ${srv.id})`);
        else serverFailed.push(`◇ ${srv.name} (ID: ${srv.id})`);
      } catch {
        serverFailed.push(`◇ ${srv.name} (ID: ${srv.id})`);
      }
    }

    /* ================= USER TANPA SERVER ================= */

    let offlineUsers = [];
    page = 1;
    totalPages = 1;

    do {
      const f = await fetch(`${domain}/api/application/users?page=${page}`, {
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${plta}`,
        },
      });

      const res = await f.json();
      totalPages = res.meta.pagination.total_pages;

      for (const user of res.data) {
        const u = user.attributes;
        if (u.root_admin) continue;

        let hasServer = false;
        try {
          const sc = await fetch(
            `${domain}/api/application/servers?filter[user_id]=${u.id}`,
            {
              headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${plta}`,
              },
            }
          );
          const sd = await sc.json();
          if (sd.data && sd.data.length > 0) hasServer = true;
        } catch {}

        if (!hasServer) {
          offlineUsers.push({
            id: u.id,
            username: u.username,
            email: u.email,
          });
        }
      }

      page++;
    } while (page <= totalPages);

    let userSuccess = [];
    let userFailed = [];

    for (const u of offlineUsers) {
      try {
        const del = await fetch(
          `${domain}/api/application/users/${u.id}`,
          {
            method: "DELETE",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: `Bearer ${plta}`,
            },
          }
        );

        if (del.status === 204)
          userSuccess.push(`◉ ${u.username} (${u.email})`);
        else userFailed.push(`◇ ${u.username} (${u.email})`);
      } catch {
        userFailed.push(`◇ ${u.username} (${u.email})`);
      }
    }

    /* ================= LAPORAN ================= */

    const report = `<blockquote expandable><b>◉ CLEAR OFF SELESAI (Panel ${ver})</b>

<b>Server OFFLINE:</b>
◉ ${serverSuccess.length} berhasil
◇ ${serverFailed.length} gagal

${serverSuccess.slice(0, 10).join("\n")}
${serverSuccess.length > 10 ? `\n...dan ${serverSuccess.length - 10} lainnya` : ""}

<b>User tanpa server:</b>
◉ ${userSuccess.length} berhasil
◇ ${userFailed.length} gagal

${userSuccess.slice(0, 10).join("\n")}
${userSuccess.length > 10 ? `\n...dan ${userSuccess.length - 10} lainnya` : ""}
</blockquote>`;

    await bot.sendMessage(chatId, report, { parse_mode: "HTML" });

  } catch (err) {
    console.error("CLEAROFF ERROR:", err);
    bot.sendMessage(chatId, "⚠ Terjadi kesalahan saat memproses /clearoff");
  }
});
bot.onText(/\/delalladp (.+)/, async (msg, match) => {
      const chatId = msg.chat.id;
      const excludedId = match[1].trim();

      if ((msg.chat.type !== "group" && msg.chat.type !== "supergroup") && !settings.isOwner(msg.from.id)) {
        return bot.sendMessage(chatId, "◈ Fitur ini khusus grup.");
      }

      const isCooldown = checkCooldown(msg);
      if (isCooldown) return bot.sendMessage(chatId, isCooldown);

      const ownerUsers = JSON.parse(fs.readFileSync(OWNER_FILE));
      const isOwner = ownerUsers.includes(String(msg.from.id));
      if (!isOwner) {
        return bot.sendMessage(chatId, "⌖ Perintah ini khusus owner.", {
          reply_markup: {
            inline_keyboard: [
              [{ text: "ʟᴀᴘᴏʀᴀɴ", url: `https://t.me/${dev}` }],
            ],
          },
        });
      }

      bot.sendMessage(chatId, `⏳ Menghapus semua admin panel kecuali ID: ${excludedId}...`);

      try {
        let page = 1;
        let totalPages = 1;
        let adminUsers = [];
        let deletedCount = 0;
        let failedCount = 0;

        // Ambil semua user dari semua halaman
        do {
          let f = await fetch(`${domain}/api/application/users?page=${page}`, {
            method: "GET",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: `Bearer ${plta}`,
            },
          });

          let res = await f.json();
          let users = res.data;
          totalPages = res.meta.pagination.total_pages;

          // Filter hanya admin panel (root_admin = true)
          for (let user of users) {
            let u = user.attributes;
            if (u.root_admin && u.id.toString() !== excludedId) {
              adminUsers.push({ id: u.id, username: u.username, email: u.email });
            }
          }

          page++;
        } while (page <= totalPages);

        // Hapus admin panel yang tidak termasuk excluded ID
        for (let admin of adminUsers) {
          try {
            let del = await fetch(`${domain}/api/application/users/${admin.id}`, {
              method: "DELETE",
              headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${plta}`,
              },
            });

            if (del.status === 204) {
              deletedCount++;
              console.log(`◉ Deleted admin: ${admin.username} (${admin.id})`);
            } else {
              failedCount++;
              console.log(`◇ Failed to delete admin: ${admin.username} (${admin.id})`);
            }
          } catch (err) {
            failedCount++;
            console.error(`Error deleting admin ${admin.id}:`, err);
          }
        }

        const resultMessage = `⌫ *HASIL DELETE ALL ADMIN PANEL*

◉ Berhasil dihapus: ${deletedCount}
◇ Gagal dihapus: ${failedCount}
⟠ ID yang dilindungi: ${excludedId}

${deletedCount > 0 ? '⟡ Semua admin panel berhasil dihapus kecuali yang dilindungi!' : '◇ Tidak ada admin panel yang dihapus.'}`;

        bot.sendMessage(chatId, resultMessage, { parse_mode: "HTML" });

      } catch (error) {
        console.error(error);
        bot.sendMessage(chatId, "◇ Terjadi kesalahan saat menghapus admin panel.");
      }
    });

// command /autodel - set auto delete on/off (untuk group)
bot.onText(/^\/autodel\s+(on|off)$/, (msg, match) => {
    const chatId = msg.chat.id;
    const action = match[1].toLowerCase();

    const ownerUsers = JSON.parse(fs.readFileSync(OWNER_FILE));
      const isOwner = ownerUsers.includes(String(msg.from.id));
      if (!isOwner) {
        return bot.sendMessage(chatId, "⌖ Perintah ini khusus owner.", {
          reply_markup: {
            inline_keyboard: [
              [{ text: "ʟᴀᴘᴏʀᴀɴ", url: `https://t.me/${dev}` }],
            ],
          },
        });
      }

    bot.sendMessage(chatId, '⚒ Mengatur auto-delete...', {
        reply_to_message_id: msg.message_id
    });
});

// command /setautodel - atur interval (untuk group)
bot.onText(/^\/setautodel\s+(\d+)$/, (msg, match) => {
    const chatId = msg.chat.id;
    const interval = parseInt(match[1]);

    const ownerUsers = JSON.parse(fs.readFileSync(OWNER_FILE));
      const isOwner = ownerUsers.includes(String(msg.from.id));
      if (!isOwner) {
        return bot.sendMessage(chatId, "⌖ Perintah ini khusus owner.", {
          reply_markup: {
            inline_keyboard: [
              [{ text: "ʟᴀᴘᴏʀᴀɴ", url: `https://t.me/${dev}` }],
            ],
          },
        });
      }

    if (interval < 1 || interval > 24) {
        return bot.sendMessage(chatId, '◇ Interval harus antara 1-24 jam!', {
            reply_to_message_id: msg.message_id
        });
    }

    bot.sendMessage(chatId, `◉ Interval auto-delete diatur menjadi ${interval} jam!`, {
        reply_to_message_id: msg.message_id
    });
});

// command /autodelstatus - cek status (untuk group)
bot.onText(/^\/autodelstatus$/, (msg) => {
    const chatId = msg.chat.id;

    const ownerUsers = JSON.parse(fs.readFileSync(OWNER_FILE));
      const isOwner = ownerUsers.includes(String(msg.from.id));
      if (!isOwner) {
        return bot.sendMessage(chatId, "⌖ Perintah ini khusus owner.", {
          reply_markup: {
            inline_keyboard: [
              [{ text: "ʟᴀᴘᴏʀᴀɴ", url: `https://t.me/${dev}` }],
            ],
          },
        });
      }

    const statusMessage = `
⚒ **STATUS AUTO-DELETE**

**Status:** ◇ Fitur ini hanya tersedia di private chat bot
**Info:** Gunakan command di private chat bot untuk mengatur auto-delete

**Fitur:**
- Hapus server offline otomatis
- Hapus user offline otomatis  
- Jadwal customizable (1-24 jam)
- Laporan detail setiap eksekusi
    `;

    bot.sendMessage(chatId, statusMessage, { 
        parse_mode: "Markdown",
        reply_to_message_id: msg.message_id
    });
});
bot.onText(/^\/totalserver$/, async (msg) => {
    await totalServerHandler(msg, 1);
});

for (let i = 2; i <= 10; i++) {
    bot.onText(new RegExp(`^\\/totalserverv${i}$`), async (msg) => {
        await totalServerHandler(msg, i);
    });
}

async function totalServerHandler(msg, num) {
    const chatId = msg.chat.id;

    const isCooldown = checkCooldown(msg);
    if (isCooldown) return bot.sendMessage(chatId, isCooldown);

    let domain, plta;
    if (num === 1) {
        domain = settings.domain;
        plta = settings.plta;
    } else if (num >= 2 && num <= 10) {
        domain = settings[`domainV${num}`];
        plta = settings[`pltaV${num}`];
    } else {
        return bot.sendMessage(chatId, "◇ Pilih server 1–10\nContoh: /totalserver atau /totalserverv2");
    }

    if (!domain || !plta) {
        return bot.sendMessage(chatId, "⚠ Domain atau token PLTA belum di-set.");
    }

    try {
        const loadingMsg = await safeReply(bot, chatId, "⏳ Sedang mengecek server...", { reply_to_message_id: msg.message_id });

        let page = 1;
        let totalServers = 0;
        let totalAdmin = 0;

        while (true) {
            const res = await fetch(`${domain}/api/application/servers?page=${page}`, {
                method: "GET",
                headers: {
                    Accept: "application/json",
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${plta}`,
                },
            }).then(r => r.json());

            if (!res?.data || !Array.isArray(res.data) || res.data.length === 0) break;

            totalServers += res.data.length;

            res.data.forEach(s => {
                if (s?.relationships?.users?.data) {
                    totalAdmin += s.relationships.users.data.length;
                }
            });

            const totalPages = res?.meta?.pagination?.total_pages || 1;
            if (page >= totalPages) break;
            page++;
        }

        const text = 
`➤ Total Server Panel V${num}: <b>${totalServers}</b>`;

        await bot.editMessageText(text, {
            chat_id: chatId,
            message_id: loadingMsg.message_id,
            parse_mode: "HTML"
        });

    } catch (err) {
        console.error(err);
        await bot.sendMessage(chatId, "⚠ Terjadi kesalahan saat memproses /totalserver.");
    }
}

    bot.onText(/^\/cekserver\s+(.+)$/, async (msg, match) => {
  const chatId = msg.chat.id;

  // ===== CEK COOLDOWN =====
  const isCooldown = checkCooldown(msg);
  if (isCooldown) return bot.sendMessage(chatId, isCooldown);

  const input = match[1].trim();
  const parts = input.split(",");
  if (parts.length < 2) {
    return bot.sendMessage(
      chatId,
      "◇ Format salah!\nGunakan: /cekserver domain,plta"
    );
  }

  const domain = parts[0].trim();
  const plta = parts[1].trim();

  if (!domain || !plta) {
    return bot.sendMessage(chatId, "⚠ Domain atau token PLTA tidak valid.");
  }

  let loadingMsg;
  try {
    loadingMsg = await bot.sendMessage(chatId, "⏳ Sedang mengecek server...", {
      reply_to_message_id: msg.message_id
    });

    let page = 1;
    let totalServers = 0;
    let totalAdmin = 0;

    while (true) {
      const res = await fetch(`${domain}/api/application/servers?page=${page}`, {
        method: "GET",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${plta}`,
        },
      }).then(r => r.json());

      if (!res?.data || !Array.isArray(res.data) || res.data.length === 0) break;

      totalServers += res.data.length;

      res.data.forEach(s => {
        if (s?.relationships?.users?.data) {
          totalAdmin += s.relationships.users.data.length;
        }
      });

      const totalPages = res?.meta?.pagination?.total_pages || 1;
      if (page >= totalPages) break;
      page++;
    }

    const text = 
`➤ Total Server: <b>${totalServers}</b>
◉ Total Admin: <b>${totalAdmin}</b>
↠ Domain: <code>${domain}</code>`;

    // EDIT pesan loading sebelumnya
    await bot.editMessageText(text, {
      chat_id: chatId,
      message_id: loadingMsg.message_id,
      parse_mode: "HTML"
    });

  } catch (err) {
    console.error(err);
    if (loadingMsg?.message_id) {
      await bot.editMessageText("⚠ Terjadi kesalahan saat memproses /cekserver.", {
        chat_id: chatId,
        message_id: loadingMsg.message_id
      });
    } else {
      await bot.sendMessage(chatId, "⚠ Terjadi kesalahan saat memproses /cekserver.");
    }
  }
});
bot.onText(/^\/listsrv$/, async (msg) => {
  const chatId = msg.chat.id;
  const ver = "1";

  if (
    (msg.chat.type !== "group" && msg.chat.type !== "supergroup") &&
    !settings.isOwner(msg.from.id)
  ) return bot.sendMessage(chatId, "◇ Khusus grup!");

  const ownerUsers = JSON.parse(fs.readFileSync(OWNER_FILE));
  if (!ownerUsers.includes(String(msg.from.id)))
    return bot.sendMessage(chatId, "◇ Khusus owner");

  const domain = domainMap[ver];
  const plta = pltaMap[ver];
  const pltc = pltcMap[ver];

  if (!domain || !plta || !pltc)
    return bot.sendMessage(chatId, "◇ Konfigurasi panel tidak ditemukan");

  const loading = await bot.sendMessage(
    chatId,
    `<blockquote expandable>⏳ <b>Mengambil daftar server (Panel ${ver})...</b></blockquote>`,
    { parse_mode: "HTML" }
  );

  await renderServerListSingle(chatId, 1, loading.message_id, ver, domain, plta, pltc);
});

// ======================
// CALLBACK PAGINATION
// ======================
bot.on("callback_query", async (q) => {
  if (!q.data || !q.data.startsWith("srv1_")) return;

  const [, ver, page] = q.data.split("_");
  const chatId = q.message.chat.id;
  const messageId = q.message.message_id;

  const domain = domainMap[ver];
  const plta = pltaMap[ver];
  const pltc = pltcMap[ver];

  if (!domain || !plta || !pltc) {
    return bot.answerCallbackQuery(q.id, {
      text: "◇ Konfigurasi panel tidak ditemukan",
      show_alert: true
    });
  }

  // ⟡ biar loading button gak muter terus
  await bot.answerCallbackQuery(q.id).catch(() => {});

  try {
    await bot.editMessageText(
      `<blockquote expandable>⏳ <b>Memuat halaman ${page}...</b></blockquote>`,
      {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML",
      }
    );
  } catch {}

  await renderServerListSingle(
    chatId,
    parseInt(page),
    messageId,
    ver,
    domain,
    plta,
    pltc
  );
});

// ======================
// RENDER SERVER LIST
// ======================
async function panelFetch(url, options = {}, retries = 2) {
  let last;
  for (let i = 0; i <= retries; i++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 15000);
    try {
      const res = await fetch(url, { ...options, signal: controller.signal });
      clearTimeout(timer);
      return res;
    } catch (e) {
      clearTimeout(timer);
      last = e;
      if (i < retries) await new Promise(r => setTimeout(r, 700 * (i + 1)));
    }
  }
  throw last || new Error("Panel API tidak dapat dihubungi");
}

async function renderServerListSingle(chatId, page, messageId, ver, domain, plta, pltc) {
  try {
    const limit = 10; // ⟡ lebih ringan & stabil

    page = Math.max(1, Number.parseInt(page, 10) || 1);

    const f = await panelFetch(
      `${domain.replace(/\/$/, "")}/api/application/servers?page=${page}&per_page=${limit}`,
      {
        headers: {
          Accept: "application/json",
          Authorization: `Bearer ${plta}`,
        },
      }
    );

    let res;
    try {
      res = await f.json();
    } catch {
      throw new Error(`Panel API mengembalikan JSON tidak valid (HTTP ${f.status})`);
    }

    // Pterodactyl mengembalikan object "errors" ketika token/domain/API bermasalah.
    // Jangan menyebutnya sebagai "pagination invalid" karena penyebab sebenarnya
    // jadi jauh lebih mudah diketahui dari pesan error-nya.
    if (!f.ok) {
      const apiDetail = Array.isArray(res?.errors)
        ? res.errors.map(e => e?.detail || e?.code || e?.status).filter(Boolean).join(" | ")
        : "";
      throw new Error(
        `Panel API HTTP ${f.status}${apiDetail ? `: ${apiDetail}` : ""}`
      );
    }

    if (!Array.isArray(res?.data)) {
      throw new Error("Panel API response tidak memiliki data server yang valid");
    }

    // API Pterodactyl normalnya selalu mengirim meta.pagination.
    // Fallback ini menjaga menu tetap bekerja pada proxy/API kompatibel
    // yang hanya mengirim data tanpa metadata pagination.
    const pagination = res?.meta?.pagination || {};
    const current_page = Math.max(
      1,
      Number.parseInt(pagination.current_page, 10) || page
    );
    const total_pages = Math.max(
      current_page,
      Number.parseInt(pagination.total_pages, 10) ||
        (res.data.length >= limit ? current_page + 1 : current_page)
    );

    const escapeHtml = value =>
      String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");

    let content = `⬢ <b>DAFTAR SERVER</b>
Panel ${escapeHtml(ver)}
Halaman ${current_page}/${total_pages}

`;

    // ======================
    // LOOP SERVER (SAFE)
    // ======================
    for (const server of res.data) {
      const s = server.attributes;

      let status = s.status || "offline";

      // ⟡ SAFE FETCH STATUS (TIDAK BOLEH GAGAL TOTAL)
      try {
        const f3 = await panelFetch(
          `${domain}/api/client/servers/${s.uuid.split("-")[0]}/resources`,
          {
            headers: {
              Accept: "application/json",
              Authorization: `Bearer ${pltc}`,
            },
          }
        );

        const data = await f3.json();

        if (data?.attributes?.current_state) {
          status = data.attributes.current_state;
        }
      } catch {
        status = "error"; // ⟡ fallback
      }

      // ── Lookup pembuat dari panelLog ──
      let creatorLine = "";
      try {
        const identifier = s.identifier || (s.uuid || "").split("-")[0];
        const log = identifier ? panelLog.findByIdentifier(identifier) : null;
        if (log) {
          const uname = log.creatorTgUsername || "-";
          const cname = log.creatorTgName ? ` (${log.creatorTgName})` : "";
          creatorLine = `\\n⊞ <b>Pembuat</b>: ID <code>${escapeHtml(log.creatorTgId)}</code> | ${escapeHtml(uname)}${escapeHtml(cname)}`;
        }
      } catch (_) {}

      content += `⌇ <b>ID</b>: ${escapeHtml(s.id)}
▭ <b>Nama</b>: ${escapeHtml(s.name)}
⊙ <b>Status</b>: ${escapeHtml(status)}${creatorLine}

`;
    }

    // ======================
    // BUTTON PAGINATION
    // ======================
    const buttons = [];

    if (current_page > 1) {
      buttons.push({
        text: "⬅ ‹",
        callback_data: `srv1_${ver}_${current_page - 1}`,
      });
    }

    if (current_page < total_pages) {
      buttons.push({
        text: "➡ Lanjut",
        callback_data: `srv1_${ver}_${current_page + 1}`,
      });
    }

    await bot.editMessageText(`<blockquote expandable>${content}</blockquote>`, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: "HTML",
      reply_markup: buttons.length
        ? { inline_keyboard: [buttons] }
        : undefined,
    });

  } catch (err) {
    // LIST ERROR adalah kegagalan jaringan/API yang sudah ditangani di UI; jangan spam SYSTEM ERROR.
    if (!/Panel API|fetch failed|aborted|ENOTFOUND|ECONN|ETIMEDOUT/i.test(String(err?.message || err))) console.error("LIST ERROR:", err);

    await bot.editMessageText(
      "<blockquote expandable>◇ <b>Gagal memuat daftar server</b></blockquote>",
      {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML",
      }
    );
  }
}
bot.onText(/^\/listsrv(([2-9]|1[0-9]|20))$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const ver = match[1];

  if (
    (msg.chat.type !== "group" && msg.chat.type !== "supergroup") &&
    !settings.isOwner(msg.from.id)
  ) return bot.sendMessage(chatId, "◇ Khusus grup!");

  const ownerUsers = JSON.parse(fs.readFileSync(OWNER_FILE));
  if (!ownerUsers.includes(String(msg.from.id)))
    return bot.sendMessage(chatId, "◇ Khusus owner");

  const domain = domainMap[ver];
  const plta = pltaMap[ver];
  const pltc = pltcMap[ver];

  if (!domain || !plta || !pltc)
    return bot.sendMessage(chatId, "◇ Konfigurasi panel tidak ditemukan");

  const loading = await bot.sendMessage(
    chatId,
    `<blockquote expandable>⏳ <b>Proses mengambil daftar server (Panel ${ver})...</b></blockquote>`,
    { parse_mode: "HTML" }
  );

  await renderServerList(chatId, 1, loading.message_id, ver, domain, plta, pltc);
});

// CALLBACK PAGINATION
bot.on("callback_query", async (q) => {
  if (!q.data.startsWith("srv_")) return;

  const [, ver, page] = q.data.split("_");
  const chatId = q.message.chat.id;
  const messageId = q.message.message_id;

  const domain = domainMap[ver];
  const plta = pltaMap[ver];
  const pltc = pltcMap[ver];

  if (!domain || !plta || !pltc) return bot.answerCallbackQuery(q.id);

  await bot.editMessageText(
    `<blockquote expandable>⏳ <b>Proses mengambil server (Panel ${ver})...</b></blockquote>`,
    {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: "HTML",
    }
  );

  await renderServerList(
    chatId,
    parseInt(page),
    messageId,
    ver,
    domain,
    plta,
    pltc
  );

  await bot.answerCallbackQuery(q.id);
});

// RENDER SERVER LIST
async function renderServerList(chatId, page, messageId, ver, domain, plta, pltc) {
  try {
    const limit = 15;

    const f = await fetch(
      `${domain}/api/application/servers?page=${page}&per_page=${limit}`,
      {
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${plta}`,
        },
      }
    );

    const res = await f.json();
    if (!res?.data || !res?.meta?.pagination)
      throw new Error("Pagination invalid");

    const { current_page, total_pages } = res.meta.pagination;

    let content = `⬢ <b>Daftar Server</b>
Panel ${ver}
Halaman ${current_page}/${total_pages}

`;

    for (const server of res.data) {
      const s = server.attributes;
      let status = s.status;

      try {
        const f3 = await fetch(
          `${domain}/api/client/servers/${s.uuid.split("-")[0]}/resources`,
          {
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: `Bearer ${pltc}`,
            },
          }
        );
        const data = await f3.json();
        if (data?.attributes?.current_state)
          status = data.attributes.current_state;
      } catch {}

      // ── Lookup pembuat dari panelLog ──
      let creatorLine = "";
      try {
        const identifier = s.identifier || (s.uuid || "").split("-")[0];
        const log = identifier ? panelLog.findByIdentifier(identifier) : null;
        if (log) {
          const uname = log.creatorTgUsername || "-";
          const cname = log.creatorTgName ? ` (${log.creatorTgName})` : "";
          creatorLine = `\\n⊞ <b>Pembuat</b>: ID <code>${escapeHtml(log.creatorTgId)}</code> | ${escapeHtml(uname)}${escapeHtml(cname)}`;
        }
      } catch (_) {}

      content += `⌇ <b>ID</b>: ${escapeHtml(s.id)}
▭ <b>Nama</b>: ${escapeHtml(s.name)}
⊙ <b>Status</b>: ${escapeHtml(status)}${creatorLine}

`;
    }

    const text = `<blockquote expandable>${content}</blockquote>`;

    const buttons = [];
    if (current_page > 1) {
      buttons.push({
        text: "⬅ ‹",
        callback_data: `srv_${ver}_${current_page - 1}`,
      });
    }
    if (current_page < total_pages) {
      buttons.push({
        text: "➡ Lanjut",
        callback_data: `srv_${ver}_${current_page + 1}`,
      });
    }

    await bot.editMessageText(text, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: "HTML",
      reply_markup: buttons.length
        ? { inline_keyboard: [buttons] }
        : undefined,
    });
  } catch (err) {
    console.error(err);
    await bot.editMessageText(
      "<blockquote expandable>◇ <b>Gagal memuat daftar server</b></blockquote>",
      {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML",
      }
    );
  }
}
bot.onText(/\/autodeladp\s+(.+)/, async (msg, match) => {
  const chatId = msg.chat.id;

  const ownerUsers = JSON.parse(fs.readFileSync(OWNER_FILE));
  if (!ownerUsers.includes(String(msg.from.id))) {
    return bot.sendMessage(chatId, "⌖ Perintah ini khusus owner.", {
      reply_markup: { inline_keyboard: [[{ text: "ʟᴀᴘᴏʀᴀɴ", url: `https://t.me/${dev}` }]] },
    });
  }

  const args = match[1].split(',').map(a => a.trim()).filter(a => a !== '');
  const targetId = parseInt(args[0]);
  if (isNaN(targetId) || targetId < 1) {
    return bot.sendMessage(chatId, '⌖ Format salah.\nGunakan: /autodeladp <sampai_id>,<id_blacklist>\nContoh: /autodeladp 100,105,110');
  }

  const blacklistIds = args.slice(1)
    .map(a => parseInt(a))
    .filter(id => !isNaN(id) && id > targetId);

  bot.sendMessage(chatId, `⊙ Mengambil semua data admin panel...\nMohon tunggu sebentar.`);

  let allUsers = [];
  let page = 1;

  try {
    while (true) {
      const res = await fetch(`${domain}/api/application/users?page=${page}&per_page=100`, {
        method: 'GET',
        headers: {
          'Accept': 'application/json',
          'Authorization': `Bearer ${plta}`
        }
      });

      if (!res.ok) break;
      const json = await res.json();
      if (!json.data || json.data.length === 0) break;

      allUsers.push(...json.data);
      if (!json.meta?.pagination?.links?.next) break;
      page++;
    }
  } catch (err) {
    return bot.sendMessage(chatId, `◇ Gagal mengambil daftar admin: ${err.message}`);
  }

  if (allUsers.length === 0) {
    return bot.sendMessage(chatId, '⌖ Tidak ada user ditemukan di panel.');
  }

  const admins = allUsers
    .filter(u => u.attributes.root_admin === true)
    .map(u => u.attributes.id)
    .filter(id => id >= targetId && !blacklistIds.includes(id))
    .sort((a, b) => b - a);

  if (admins.length === 0) {
    return bot.sendMessage(chatId, `⌖ Tidak ada admin yang cocok untuk dihapus (>= ${targetId} dan tidak di blacklist).`);
  }

  bot.sendMessage(chatId, `⚠ Proses penghapusan admin panel dimulai...\n◉ Total admin: ${admins.length}\n▼ Dari ID ${admins[0]} sampai ${targetId}\n⊘ Blacklist: ${blacklistIds.length ? blacklistIds.join(', ') : 'Tidak ada'}`);

  let success = 0;
  let failed = 0;
  let failedList = [];

  for (const id of admins) {
    try {
      const del = await fetch(`${domain}/api/application/users/${id}`, {
        method: 'DELETE',
        headers: {
          'Accept': 'application/json',
          'Authorization': `Bearer ${plta}`
        }
      });

      if (del.status === 204) success++;
      else {
        failed++;
        failedList.push(`${id} (gagal hapus)`);
      }
    } catch (err) {
      failed++;
      failedList.push(`${id} (error: ${err.message})`);
    }

    await new Promise(r => setTimeout(r, typeof DELAY_MS !== 'undefined' ? DELAY_MS : 200));
  }

  let result = `⌫ Hasil Auto Delete Admin Panel\n\n◉ Berhasil : ${success}\n◇ Gagal    : ${failed}`;
  if (failedList.length) result += `\n\n☰ Gagal pada:\n- ${failedList.join('\n- ')}`;

  bot.sendMessage(chatId, result);
});


bot.onText(/\/autodelsrv\s+(\d+)/, async (msg, match) => {
  const chatId = msg.chat.id;

  const ownerUsers = JSON.parse(fs.readFileSync(OWNER_FILE));
  if (!ownerUsers.includes(String(msg.from.id))) {
    return bot.sendMessage(chatId, "⌖ Perintah ini khusus owner.", {
      reply_markup: { inline_keyboard: [[{ text: "ʟᴀᴘᴏʀᴀɴ", url: `https://t.me/${dev}` }]] },
    });
  }

  const targetId = parseInt(match[1]);
  if (isNaN(targetId) || targetId < 1) {
    return bot.sendMessage(chatId, '⌖ Masukkan angka ID server yang valid. Contoh: /autodelsrv 50');
  }

  bot.sendMessage(chatId, `⊙ Mengambil semua data server dari panel...\nMohon tunggu, ini bisa memakan waktu.`);

  let allServers = [];
  let page = 1;

  try {
    while (true) {
      const res = await fetch(`${domain}/api/application/servers?page=${page}&per_page=100`, {
        method: 'GET',
        headers: {
          'Accept': 'application/json',
          'Authorization': `Bearer ${plta}`
        }
      });

      if (!res.ok) break;
      const json = await res.json();
      if (!json.data || json.data.length === 0) break;

      allServers.push(...json.data);
      if (!json.meta?.pagination?.links?.next) break;
      page++;
    }
  } catch (err) {
    return bot.sendMessage(chatId, `◇ Gagal mengambil daftar server: ${err.message}`);
  }

  if (allServers.length === 0) {
    return bot.sendMessage(chatId, '⌖ Tidak ada server ditemukan di panel.');
  }

  const servers = allServers
    .map(s => s.attributes.id)
    .filter(id => id >= targetId)
    .sort((a, b) => b - a);

  if (servers.length === 0) {
    return bot.sendMessage(chatId, `⌖ Tidak ada server dengan ID >= ${targetId}`);
  }

  bot.sendMessage(chatId, `⚠ Proses penghapusan dimulai...\n⟲ Total server: ${servers.length}\n▼ Dari ID ${servers[0]} sampai ${targetId}`);

  let successCount = 0;
  let failCount = 0;
  let failList = [];

  for (const id of servers) {
    try {
      const info = await fetch(`${domain}/api/application/servers/${id}`, {
        method: 'GET',
        headers: {
          'Accept': 'application/json',
          'Authorization': `Bearer ${plta}`
        }
      });

      if (!info.ok) {
        failCount++;
        failList.push(`${id} (tidak ditemukan)`);
        continue;
      }

      const serverData = await info.json();
      const userId = serverData.attributes.user;

      const delServer = await fetch(`${domain}/api/application/servers/${id}`, {
        method: 'DELETE',
        headers: {
          'Accept': 'application/json',
          'Authorization': `Bearer ${plta}`
        }
      });

      if (!delServer.ok) {
        failCount++;
        failList.push(`${id} (gagal hapus server)`);
        continue;
      }

      const delUser = await fetch(`${domain}/api/application/users/${userId}`, {
        method: 'DELETE',
        headers: {
          'Accept': 'application/json',
          'Authorization': `Bearer ${plta}`
        }
      });

      if (delUser.ok) successCount++;
      else {
        failCount++;
        failList.push(`${id} (gagal hapus user ${userId})`);
      }

    } catch (err) {
      failCount++;
      failList.push(`${id} (error: ${err.message})`);
    }

    await new Promise(r => setTimeout(r, typeof DELAY_MS !== 'undefined' ? DELAY_MS : 200));
  }

  let result = `⌫ Hasil Auto Delete Server\n\n◉ Berhasil : ${successCount}\n◇ Gagal    : ${failCount}`;
  if (failList.length) result += `\n\n☰ Gagal pada:\n- ${failList.join('\n- ')}`;

  bot.sendMessage(chatId, result);
});


bot.onText(/^\/infovps(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const input = match[1];

  if (!input) {
    return bot.sendMessage(chatId, "◇ Format salah!\nContoh: `/infovps 1.1.1.1|password`", {
      parse_mode: "Markdown"
    });
  }

  if (!input.includes("|")) {
    return bot.sendMessage(chatId, "◇ Format salah!\nGunakan format:\n`/infovps ip|password`", {
      parse_mode: "Markdown"
    });
  }

  let [host, password] = input.split("|");
  host = host.trim();
  password = password.trim();

  try {
    const conn = new Client();

    conn.on("ready", () => {
      const command = `
        echo "RUNTIME: $(uptime -p)"
        echo "LOAD: $(uptime | awk -F'load average:' '{print $2}')"
        echo "RAM_TOTAL: $(free -g | awk '/Mem:/ {print $2}')"
        echo "RAM_USED: $(free -g | awk '/Mem:/ {print $3}')"
        echo "CORE: $(nproc)"
        echo "CPU_USAGE: $(top -bn1 | grep "Cpu(s)" | awk '{print 100 - $8}' )"
        echo "DISK_TOTAL: $(df -h / | awk 'NR==2 {print $2}')"
        echo "DISK_USED: $(df -h / | awk 'NR==2 {print $3}')"
        echo "DISK_FREE: $(df -h / | awk 'NR==2 {print $4}')"
        echo "OS: $(hostnamectl | grep 'Operating System' | cut -d ':' -f2)"
        echo "KERNEL: $(uname -r)"
      `;

      conn.exec(command, (err, stream) => {
        if (err) {
          bot.sendMessage(chatId, "◇ Gagal mengeksekusi perintah di VPS.");
          return conn.end();
        }

        let output = "";
        stream.on("data", (data) => (output += data.toString()));
        stream.on("close", () => {

          // Pisahkan per baris
          let info = {};
          output.trim().split("\n").forEach(line => {
            const [key, ...valueParts] = line.split(":");
            info[key.trim()] = valueParts.join(":").trim();
          });

          // Hilangkan nilai 0
          const fix = (val) => (!val || val === "0" || val === "0G") ? "-" : val;

          const runtime = fix(info.RUNTIME);
          const load = fix(info.LOAD);
          const ramTotal = fix(info.RAM_TOTAL);
          const ramUsed = fix(info.RAM_USED);
          const core = fix(info.CORE);
          const cpuUsage = fix(parseFloat(info.CPU_USAGE).toFixed(1));
          const diskTotal = fix(info.DISK_TOTAL);
          const diskUsed = fix(info.DISK_USED);
          const diskFree = fix(info.DISK_FREE);
          const osName = fix(info.OS);
          const kernel = fix(info.KERNEL);

          // Output
          const result = `
⌂ *INFO VPS (${host})*

▭ *System*
• OS: ${osName}
• Kernel: ${kernel}
• Runtime: ${runtime}
• Load Average: ${load}

⟡ *Memory*
• RAM Total: ${ramTotal} GB
• RAM Terpakai: ${ramUsed} GB

⊙ *CPU*
• Core: ${core}
• CPU Usage: ${cpuUsage}%

⌗ *Disk*
• Total: ${diskTotal}
• Digunakan: ${diskUsed}
• Tersisa: ${diskFree}
          `.trim();

          bot.sendMessage(chatId, result, { parse_mode: "HTML" });
          conn.end();
        });
      });
    });

    conn.on("error", (err) => {
      bot.sendMessage(chatId, `◇ Gagal konek ke VPS: ${err.message}`);
    });

    conn.connect({
      host,
      port: 22,
      username: "root",
      password
    });

  } catch (err) {
    bot.sendMessage(chatId, "◇ Terjadi kesalahan koneksi VPS.");
    console.error(err);
  }
});
// V1 (tanpa angka) menggunakan domain, plta, pltc
bot.onText(/^\/deladp (.+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const targetId = match[1].trim();

  const isCooldown = checkCooldown(msg);
  if (isCooldown) return bot.sendMessage(chatId, isCooldown);

  const ownerUsers = JSON.parse(fs.readFileSync(OWNER_FILE));
  if (!ownerUsers.includes(String(msg.from.id))) {
    return bot.sendMessage(chatId, "⌖ Perintah ini khusus owner.", {
      reply_markup: { inline_keyboard: [[{ text: "ʟᴀᴘᴏʀᴀɴ", url: `https://t.me/${dev}` }]] }
    });
  }

  bot.sendMessage(chatId, `⏳ Menghapus admin panel dengan ID: ${targetId}...`);

  try {
    let f = await fetch(`${domain}/api/application/users/${targetId}`, {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
    });

    if (f.status === 404) return bot.sendMessage(chatId, "◇ ID admin tidak ditemukan!");
    let res = await f.json();
    let user = res.attributes;

    if (!user.root_admin) return bot.sendMessage(chatId, "◇ User ini bukan admin panel (root_admin = false)");

    let del = await fetch(`${domain}/api/application/users/${targetId}`, {
      method: "DELETE",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
    });

    if (del.status === 204) {
      bot.sendMessage(chatId,
        `<b>🗑️ ADMIN PANEL BERHASIL DIHAPUS</b>\n\n<blockquote expandable><b>📋 DETAIL PENGHAPUSAN</b>\n🆔 <b>ID</b> : <code>${targetId}</code>\n👤 <b>Username</b> : <code>${sanitizeHtml(user.username)}</code>\n🟢 <b>Status</b> : <b>AKUN ADMIN TELAH DIHAPUS</b></blockquote>\n\n<i>Perubahan sudah diterapkan pada panel.</i>`,
        { parse_mode: "HTML" }
      );
    } else {
      bot.sendMessage(chatId, "◇ Gagal menghapus admin panel.");
    }

  } catch (err) {
    console.error(err);
    bot.sendMessage(chatId, "◇ Terjadi kesalahan saat menghapus admin panel.");
  }
});

// V2–V10 (menggunakan domainVx, pltaVx, pltcVx)
for (let i = 2; i <= 10; i++) {
  let domainVar = eval(`domainV${i}`);
  let pltaVar = eval(`pltaV${i}`);
  let pltcVar = eval(`pltcV${i}`);

  bot.onText(new RegExp(`^\\/deladp${i} (.+)$`), async (msg, match) => {
    const chatId = msg.chat.id;
    const targetId = match[1].trim();

    const isCooldown = checkCooldown(msg);
    if (isCooldown) return bot.sendMessage(chatId, isCooldown);

    const ownerUsers = JSON.parse(fs.readFileSync(OWNER_FILE));
    if (!ownerUsers.includes(String(msg.from.id))) {
      return bot.sendMessage(chatId, "⌖ Perintah ini khusus owner.", {
        reply_markup: { inline_keyboard: [[{ text: "ʟᴀᴘᴏʀᴀɴ", url: `https://t.me/${dev}` }]] }
      });
    }

    bot.sendMessage(chatId, `⏳ Menghapus admin panel dengan ID: ${targetId}...`);

    try {
      let f = await fetch(`${domainVar}/api/application/users/${targetId}`, {
        method: "GET",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${pltaVar}`,
        },
      });

      if (f.status === 404) return bot.sendMessage(chatId, "◇ ID admin tidak ditemukan!");
      let res = await f.json();
      let user = res.attributes;

      if (!user.root_admin) return bot.sendMessage(chatId, "◇ User ini bukan admin panel (root_admin = false)");

      let del = await fetch(`${domainVar}/api/application/users/${targetId}`, {
        method: "DELETE",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${pltaVar}`,
        },
      });

      if (del.status === 204) {
        bot.sendMessage(chatId,
          `<b>🗑️ ADMIN PANEL BERHASIL DIHAPUS</b>\n\n<blockquote expandable><b>📋 DETAIL PENGHAPUSAN</b>\n🆔 <b>ID</b> : <code>${targetId}</code>\n👤 <b>Username</b> : <code>${sanitizeHtml(user.username)}</code>\n🟢 <b>Status</b> : <b>AKUN ADMIN TELAH DIHAPUS</b></blockquote>\n\n<i>Perubahan sudah diterapkan pada panel.</i>`,
          { parse_mode: "HTML" }
        );
      } else {
        bot.sendMessage(chatId, "◇ Gagal menghapus admin panel.");
      }

    } catch (err) {
      console.error(err);
      bot.sendMessage(chatId, "◇ Terjadi kesalahan saat menghapus admin panel.");
    }
  });
}
bot.onText(/^\/servercpu$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (!settings.isOwner(userId)) {
    return bot.sendMessage(chatId, '◇ Hanya OWNER yang bisa menggunakan perintah ini.');
  }

  const panelDomain = domain;
  const pltaKey = plta;
  const pltcKey = pltc;

  if (!panelDomain || !pltaKey || !pltcKey) {
    return bot.sendMessage(chatId, `<blockquote expandable>◇ Konfigurasi panel tidak ditemukan.</blockquote>`, {
      parse_mode: 'HTML'
    });
  }

  const sentMessage = await bot.sendMessage(
    chatId,
    `<blockquote expandable>⏳ Memeriksa penggunaan CPU server...\n\nBatas CPU Wajar: <b>80%</b></blockquote>`,
    { parse_mode: 'HTML' }
  );

  (async () => {
    try {
      let servers = [];
      let page = 1;
      let hasMore = true;

      while (hasMore) {
        const response = await axios.get(`${panelDomain}/api/application/servers?page=${page}`, {
          headers: { 'Authorization': `Bearer ${pltaKey}` }
        });

        const result = response.data;
        servers = servers.concat(result.data);
        hasMore = result.meta.pagination.current_page < result.meta.pagination.total_pages;
        page++;
      }

      let abnormalCpuServers = [];

      for (const server of servers) {
        const { id: serverId, name: serverName, uuid: serverUuid } = server.attributes;

        try {
          const resourceResponse = await axios.get(
            `${panelDomain}/api/client/servers/${serverUuid}/resources`,
            { headers: { 'Authorization': `Bearer ${pltcKey}` } }
          );

          const resources = resourceResponse.data.attributes.resources;
          const cpuUsage = resources.cpu_absolute;
          const cpuLimit = resources.cpu_limit;

          const effectiveLimit = cpuLimit > 0 ? cpuLimit : 100;

          if (cpuUsage > 80 && effectiveLimit <= 100 || (cpuLimit > 100 && cpuUsage > (cpuLimit * 0.8))) {
            abnormalCpuServers.push({
              id: serverId,
              name: serverName,
              usage: cpuUsage,
              limit: cpuLimit,
            });
          }
        } catch {}
      }

      if (abnormalCpuServers.length === 0) {
        return bot.editMessageText(
          `<blockquote expandable>◉ Tidak ditemukan server dengan penggunaan CPU di atas batas wajar (80%).</blockquote>`,
          { chat_id: chatId, message_id: sentMessage.message_id, parse_mode: 'HTML' }
        );
      }

      let message = `⎔ <b>Daftar Server CPU Tidak Wajar</b> ⎔\n\n`;
      message += `<b>Batas Wajar:</b> 80%\n`;
      message += "\n";

      abnormalCpuServers.forEach(srv => {
        message += `⌇ <b>ID</b>: <code>${srv.id}</code>\n`;
        message += `⬡ <b>Nama</b>: ${srv.name}\n`;
        message += `⎔ <b>Penggunaan</b>: ${srv.usage.toFixed(2)}% dari ${srv.limit}%\n`;
        message += "\n";
      });

      message += `⌗ <b>Total Server Tidak Wajar</b>: ${abnormalCpuServers.length}`;

      await bot.editMessageText(
        `<blockquote expandable>${message}</blockquote>`,
        { chat_id: chatId, message_id: sentMessage.message_id, parse_mode: 'HTML' }
      );

    } catch (err) {
      await bot.editMessageText(
        `<blockquote expandable>◇ Gagal mengambil data server: ${err.message}</blockquote>`,
        { chat_id: chatId, message_id: sentMessage.message_id, parse_mode: 'HTML' }
      );
    }
  })();
});
let autoCpuInterval = null;
let autoCpuMode = null;
const autoCpuWhitelist = new Set();
let serverCache = [];
let serverPage = 0;
const PAGE_SIZE = 10;

/* ================= AUTOCPU COMMAND ================= */

bot.onText(/^\/autocpu\s+(on|off)$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const action = match[1].toLowerCase();

  if (!settings.isOwner(userId)) {
    return bot.sendMessage(chatId, "◇ Hanya OWNER yang bisa menggunakan perintah ini.");
  }

  if (action === "off") {
    if (autoCpuInterval) {
      clearInterval(autoCpuInterval);
      autoCpuInterval = null;
      autoCpuMode = null;
    }
    return bot.sendMessage(chatId, `<blockquote expandable>⊘ Auto CPU <b>DIMATIKAN</b></blockquote>`, { parse_mode: "HTML" });
  }

  await bot.sendMessage(chatId, `<b>Pilih Menu Di Bawah</b>`, {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [{ text: "⟡ Auto Del", callback_data: "autocpu_del" }],
        [{ text: "⊘ Auto Stop", callback_data: "autocpu_stop" }]
      ]
    }
  });
});

/* ================= CALLBACK ================= */

bot.on("callback_query", async (query) => {
  const chatId = query.message.chat.id;
  const userId = query.from.id;
  const data = query.data;
  if (!settings.isOwner(userId)) return;

  if (data === "autocpu_del" || data === "autocpu_stop") {
    autoCpuMode = data === "autocpu_del" ? "del" : "stop";
    serverPage = 0;

    if (!serverCache.length) {
      serverCache = await fetchAllServers();
    }

    await bot.answerCallbackQuery(query.id);
    await bot.sendMessage(chatId, `<blockquote expandable>◉ Auto CPU <b>AKTIF</b>
Mode: <b>${autoCpuMode === "del" ? "AUTO DELETE" : "AUTO STOP"}</b>
⏱ Interval: 1 menit
⌗ Batas CPU: 80%</blockquote>`, { parse_mode: "HTML" });

    await sendServerPage(chatId);
    startAutoCpu(chatId);
    return;
  }

  if (data === "autocpu_next") {
    serverPage++;
    await bot.answerCallbackQuery(query.id);
    return sendServerPage(chatId);
  }

  if (data.startsWith("autocpu_bl_")) {
    const serverId = Number(data.split("_")[2]);
    autoCpuWhitelist.has(serverId)
      ? autoCpuWhitelist.delete(serverId)
      : autoCpuWhitelist.add(serverId);

    await bot.answerCallbackQuery(query.id);
    return sendServerPage(chatId);
  }
});

/* ================= AUTO CPU ================= */

function startAutoCpu(chatId) {
  if (autoCpuInterval) clearInterval(autoCpuInterval);
  const run = async () => {
    try {
      serverCache = await fetchAllServers();
    } catch (e) {
      console.warn('[autocpu] gagal refresh server:', e.message);
    }
    for (const srv of serverCache) {
      const { id, name, uuid } = srv.attributes;
      if (autoCpuWhitelist.has(id)) continue;

      try {
        const r = await axios.get(
          `${domain}/api/client/servers/${uuid}/resources`,
          { headers: { Authorization: `Bearer ${pltc}` } }
        );

        const cpu = r.data.attributes.resources.cpu_absolute;
        const limit = r.data.attributes.resources.cpu_limit || 100;

        if (cpu > limit * 0.8) {
          if (autoCpuMode === "stop") {
            await axios.post(
              `${domain}/api/client/servers/${uuid}/power`,
              { signal: "stop" },
              { headers: { Authorization: `Bearer ${pltc}` } }
            );
          }

          if (autoCpuMode === "del") {
            await axios.delete(
              `${domain}/api/application/servers/${id}`,
              { headers: { Authorization: `Bearer ${plta}` } }
            );
          }

          await bot.sendMessage(chatId, `<blockquote expandable>⎔ <b>CPU TINGGI</b>
⌇ ID: <code>${id}</code>
⬡ Nama: ${name}
⎔ CPU: ${cpu.toFixed(2)}%
⚠ Aksi: <b>${autoCpuMode.toUpperCase()}</b></blockquote>`, { parse_mode: "HTML" });
        }
      } catch {}
    }
  };
  // Jalankan sekali langsung supaya fitur tidak terlihat mati selama 1 menit.
  void run();
  autoCpuInterval = setInterval(run, 60 * 1000);
}

/* ================= SERVER PAGINATION ================= */

async function fetchAllServers() {
  let servers = [];
  let page = 1;
  let hasMore = true;

  while (hasMore) {
    const res = await axios.get(
      `${domain}/api/application/servers?page=${page}`,
      { headers: { Authorization: `Bearer ${plta}` } }
    );
    servers.push(...res.data.data);
    hasMore = res.data.meta.pagination.current_page < res.data.meta.pagination.total_pages;
    page++;
  }
  return servers;
}

async function sendServerPage(chatId) {
  const start = serverPage * PAGE_SIZE;
  const end = start + PAGE_SIZE;
  const slice = serverCache.slice(start, end);

  const buttons = slice.map(srv => {
    const id = srv.attributes.id;
    const name = srv.attributes.name;
    const mark = autoCpuWhitelist.has(id) ? "◉" : "◇";
    return [{ text: `${mark} ${id} | ${name}`, callback_data: `autocpu_bl_${id}` }];
  });

  if (end < serverCache.length) {
    buttons.push([{ text: "➡ Lanjut", callback_data: "autocpu_next" }]);
  }

  await bot.sendMessage(chatId, `<b>Pilih ID Yg Mau Di BL</b>`, {
    parse_mode: "HTML",
    reply_markup: { inline_keyboard: buttons }
  });
}
bot.onText(/^\/statuscpu$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (!settings.isOwner(userId)) {
    return bot.sendMessage(chatId, "◇ Hanya OWNER yang bisa menggunakan perintah ini.");
  }

  const status = autoCpuInterval ? "● <b>ON</b>" : "○ <b>OFF</b>";
  const mode =
    autoCpuMode === "del"
      ? "AUTO DELETE"
      : autoCpuMode === "stop"
      ? "AUTO STOP"
      : "-";

  const whitelistCount = autoCpuWhitelist ? autoCpuWhitelist.size : 0;

  await bot.sendMessage(
    chatId,
    `<blockquote expandable>⌗ <b>Status Auto CPU</b>

⊙ Monitoring: ${status}
⌘ Mode: <b>${mode}</b>
⏱ Interval: <b>1 menit</b>
⎔ Batas CPU: <b>80%</b>
⟠ Server BL: <b>${whitelistCount}</b></blockquote>`,
    { parse_mode: "HTML" }
  );
});
bot.onText(/^\/servercpuv(([2-9]|1[0-9]|20))$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (!settings.isOwner(userId)) return;

  const ver = match[1];

  // ============================
  //  FIX: Gunakan settings, bukan global
  // ============================
  const panelDomain = settings[`domainV${ver}`];
  const pltaKey     = settings[`pltaV${ver}`];
  const pltcKey     = settings[`pltcV${ver}`];
  // ============================

  if (!panelDomain || !pltaKey || !pltcKey) {
    return bot.sendMessage(chatId,
      `<blockquote expandable>◇ Konfigurasi panel v${ver} tidak ditemukan.</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  const sent = await bot.sendMessage(
    chatId,
    `<blockquote expandable>⏳ Memeriksa CPU server panel v${ver}...</blockquote>`,
    { parse_mode: "HTML" }
  );

  try {
    let servers = [];
    let page = 1;
    let more = true;

    while (more) {
      const res = await axios.get(`${panelDomain}/api/application/servers?page=${page}`, {
        headers: { Authorization: `Bearer ${pltaKey}` }
      });

      servers = servers.concat(res.data.data);
      more = res.data.meta.pagination.current_page < res.data.meta.pagination.total_pages;
      page++;
    }

    let abnormal = [];

    for (const srv of servers) {
      const { id, name, uuid } = srv.attributes;

      try {
        const rr = await axios.get(`${panelDomain}/api/client/servers/${uuid}/resources`, {
          headers: { Authorization: `Bearer ${pltcKey}` }
        });

        const r = rr.data.attributes.resources;
        const cpu = r.cpu_absolute;
        const limit = r.cpu_limit > 0 ? r.cpu_limit : 100;

        if (cpu > 80 || cpu > limit * 0.8) {
          abnormal.push({ id, name, cpu, limit });
        }

      } catch {}
    }

    if (abnormal.length === 0) {
      return bot.editMessageText(
        `<blockquote expandable>◉ Tidak ditemukan server CPU tinggi di panel v${ver}.</blockquote>`,
        {
          chat_id: chatId,
          message_id: sent.message_id,
          parse_mode: "HTML"
        }
      );
    }

    let m = `⎔ <b>CPU Tinggi (v${ver})</b> ⎔\n\n`;

    abnormal.forEach(x => {
      m += `⌇ <b>ID:</b> <code>${x.id}</code>\n`;
      m += `⬡ <b>Nama:</b> ${x.name}\n`;
      m += `⎔ <b>CPU:</b> ${x.cpu.toFixed(2)}% / ${x.limit}%\n`;
      m += `\n`;
    });

    bot.editMessageText(
      `<blockquote expandable>${m}</blockquote>`,
      {
        chat_id: chatId,
        message_id: sent.message_id,
        parse_mode: "HTML"
      }
    );

  } catch (e) {
    bot.editMessageText(
      `<blockquote expandable>◇ Error: ${e.message}</blockquote>`,
      {
        chat_id: chatId,
        message_id: sent.message_id,
        parse_mode: "HTML"
      }
    );
  }
});

// ================= LIST USER / LIST ADP =================
// /listuser      = daftar semua user panel utama
// /listuserv2... = daftar semua user panel V2..V20
// /listadp       = daftar semua root admin panel utama
// /listadpv2...  = daftar semua root admin panel V2..V20
function readOwnerIdsSafe() {
  try {
    // Gunakan ownerStore sebagai sumber utama. Versi lama membaca
    // db/onlyID.json yang memang tidak selalu ada sehingga /listuser dan
    // /listadp selalu menolak owner.
    if (typeof ownerStore.getOwnerIds === "function") {
      const ids = ownerStore.getOwnerIds();
      if (Array.isArray(ids) && ids.length) return ids.map(String);
    }
    if (typeof ownerStore.getOwnerId === "function") {
      const id = ownerStore.getOwnerId();
      if (id) return [String(id)];
    }
  } catch (_) {}
  return [String(OWNER_UID)].filter(Boolean);
}

function isPanelOwner(senderId) {
  return readOwnerIdsSafe().includes(String(senderId));
}

function getPanelConfigByVersion(ver) {
  const n = Number(ver || 1);
  if (n === 1) return { label: "V1", domain, plta };
  return { label: `V${n}`, domain: settings[`domainV${n}`], plta: settings[`pltaV${n}`] };
}

function listApiErrorMessage(res, json) {
  const detail = Array.isArray(json?.errors)
    ? json.errors.map(e => e?.detail || e?.code).filter(Boolean).join("; ")
    : (json?.message || res?.statusText || "API error");
  return `HTTP ${res.status}: ${detail}`;
}

function getPagination(json, fallbackPage = 1, fallbackPerPage = 25, itemCount = 0) {
  const p = json?.meta?.pagination;
  if (!p || !Number.isFinite(Number(p.current_page))) {
    return {
      current_page: fallbackPage,
      total_pages: itemCount >= fallbackPerPage ? fallbackPage + 1 : fallbackPage,
      total: itemCount,
      per_page: fallbackPerPage,
    };
  }
  return {
    current_page: Number(p.current_page) || fallbackPage,
    total_pages: Number(p.total_pages) || fallbackPage,
    total: Number(p.total) || itemCount,
    per_page: Number(p.per_page) || fallbackPerPage,
  };
}

function formatPanelUserLine(a, index, adminOnly = false) {
  const name = [a.first_name, a.last_name].filter(Boolean).join(" ") || "Tidak ada nama";
  const role = a.root_admin ? "ADMIN PANEL" : "USER PANEL";
  const badge = adminOnly ? "🛡️" : "👤";
  return (
    `<blockquote expandable><b>${badge} ${index}. ${sanitizeHtml(a.username || "tanpa-username")}</b>\n\n` +
    `🆔 <b>ID</b> : <code>${sanitizeHtml(a.id)}</code>\n` +
    `👤 <b>Username</b> : <code>${sanitizeHtml(a.username || "-")}</code>\n` +
    `📧 <b>Email</b> : <code>${sanitizeHtml(a.email || "-")}</code>\n` +
    `📝 <b>Nama</b> : ${sanitizeHtml(name)}\n` +
    `🔐 <b>Akses</b> : <b>${role}</b></blockquote>`
  );
}

async function fetchPanelUsersPage(panelCfg, page) {
  if (!panelCfg.domain || !panelCfg.plta) throw new Error("Konfigurasi domain/PLTA panel belum lengkap.");
  const cleanDomain = String(panelCfg.domain).replace(/\/+$/, "");
  const url = `${cleanDomain}/api/application/users?page=${page}&per_page=25`;
  const res = await fetch(url, { headers: { Authorization: `Bearer ${panelCfg.plta}`, Accept: "application/json" } });
  let json = {};
  try { json = await res.json(); } catch (_) {}
  if (!res.ok) throw new Error(listApiErrorMessage(res, json));
  return { data: Array.isArray(json.data) ? json.data : [], pagination: getPagination(json, page, 25, json.data?.length || 0) };
}

function listNavigation(prefix, page, totalPages) {
  const row = [];
  if (page > 1) row.push({ text: "◀ Sebelumnya", callback_data: `${prefix}:${page - 1}` });
  if (page < totalPages) row.push({ text: "Berikutnya ▶", callback_data: `${prefix}:${page + 1}` });
  return row.length ? [row, [{ text: "↩ ‹", callback_data: "panel_list_back" }]] : [[{ text: "↩ ‹", callback_data: "panel_list_back" }]];
}

async function fetchAllRootAdmins(panelCfg) {
  const all = [];
  let page = 1;
  const seen = new Set();
  while (page <= 50) {
    const result = await fetchPanelUsersPage(panelCfg, page);
    for (const item of result.data) if (item?.attributes?.root_admin) all.push(item.attributes);
    const next = result.pagination.total_pages;
    if (page >= next || seen.has(next)) break;
    seen.add(next); page++;
  }
  return all;
}

async function renderPanelUserList(chatId, page, messageId, ver, adminOnly = false) {
  const cfg = getPanelConfigByVersion(ver);
  const prefix = adminOnly ? `listadp${ver === 1 ? "" : `v${ver}`}` : `listuser${ver === 1 ? "" : `v${ver}`}`;
  try {
    const result = await fetchPanelUsersPage(cfg, page);
    const users = adminOnly ? result.data.filter(u => u.attributes?.root_admin) : result.data;
    const p = result.pagination;
    let totalAdminCount = null;
    if (adminOnly) { try { totalAdminCount = (await fetchAllRootAdmins(cfg)).length; } catch (_) {} }

    const title = adminOnly ? "🛡️ DAFTAR ADMIN PANEL" : "👥 DAFTAR USER PANEL";
    const description = adminOnly
      ? "Daftar akun yang memiliki hak Admin Panel / root admin."
      : "Daftar seluruh akun pengguna pada panel ini.";
    const cards = users.length
      ? users.map((u, i) => formatPanelUserLine(u.attributes || {}, ((p.current_page - 1) * p.per_page) + i + 1, adminOnly)).join("\n")
      : `<blockquote expandable>📭 <b>BELUM ADA DATA</b>\nTidak ada ${adminOnly ? "Admin Panel" : "user"} pada halaman ini.</blockquote>`;

    const text =
      `<b>${title}</b>\n` +
      `<i>${description}</i>\n\n` +
      `<blockquote><b>📊 RINGKASAN</b>\n` +
      `├ 🖥️ <b>Panel</b> : <code>${sanitizeHtml(cfg.label)}</code>\n` +
      `├ 🌐 <b>Domain</b> : <code>${sanitizeHtml(cfg.domain)}</code>\n` +
      `├ 📄 <b>Halaman</b> : <b>${p.current_page} / ${p.total_pages}</b>\n` +
      `├ 📌 <b>Data halaman</b> : <b>${users.length}</b>\n` +
      (adminOnly ? `└ 🛡️ <b>Total Admin Panel</b> : <b>${totalAdminCount == null ? "-" : totalAdminCount}</b>` : `└ 👥 <b>Total data API</b> : <b>${p.total}</b>`) +
      `</blockquote>\n\n` +
      `<b>📚 DATA</b>\n${cards}`;

    return bot.editMessageText(text, { chat_id: chatId, message_id: messageId, parse_mode: "HTML", reply_markup: { inline_keyboard: listNavigation(prefix, p.current_page, p.total_pages) } });
  } catch (err) {
    const text =
      `<b>⚠️ ${adminOnly ? "DAFTAR ADMIN PANEL" : "DAFTAR USER PANEL"}</b>\n\n` +
      `<blockquote expandable><b>GAGAL MEMUAT DATA</b>\n\n` +
      `🖥️ <b>Panel</b> : <code>${sanitizeHtml(cfg.label)}</code>\n` +
      `❌ <b>Keterangan</b> : <code>${sanitizeHtml(err.message)}</code></blockquote>`;
    return bot.editMessageText(text, { chat_id: chatId, message_id: messageId, parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "↩ ‹", callback_data: "panel_list_back" }]] } }).catch(() => {});
  }
}

async function handlePanelListCommand(msg, ver, adminOnly) {
  const chatId = msg.chat.id;
  if (!isPanelOwner(msg.from.id)) {
    return bot.sendMessage(chatId, "◇ Fitur ini khusus owner.", {
      reply_markup: { inline_keyboard: [[{ text: "Laporan", url: `https://t.me/${dev}` }]] },
    });
  }

  const cfg = getPanelConfigByVersion(ver);
  if (!cfg.domain || !cfg.plta) {
    return bot.sendMessage(chatId, `<blockquote expandable>◇ Konfigurasi panel ${cfg.label} tidak ditemukan.</blockquote>`, { parse_mode: "HTML" });
  }

  const sent = await bot.sendMessage(chatId,
    `<blockquote expandable>⏳ Mengambil daftar ${adminOnly ? "Admin Panel" : "user"} ${cfg.label}...</blockquote>`,
    { parse_mode: "HTML" }
  );
  return renderPanelUserList(chatId, 1, sent.message_id, ver, adminOnly);
}

bot.onText(/^\/listuser$/i, msg => handlePanelListCommand(msg, 1, false));
bot.onText(/^\/listuserv([2-9]|1[0-9]|20)$/i, (msg, m) => handlePanelListCommand(msg, Number(m[1]), false));
bot.onText(/^\/listadp$/i, msg => handlePanelListCommand(msg, 1, true));
bot.onText(/^\/listadpv([2-9]|1[0-9]|20)$/i, (msg, m) => handlePanelListCommand(msg, Number(m[1]), true));

// Tombol Kembali untuk daftar user/admin panel.
bot.on("callback_query", async (q) => {
  if (q.data !== "panel_list_back") return;
  await bot.answerCallbackQuery(q.id).catch(() => {});
  if (!isPanelOwner(q.from.id)) return;
  const text = "<b>LIST PANEL</b>\n\nPilih daftar yang ingin dilihat.";
  const kb = { inline_keyboard: [
    [{ text: "List User", callback_data: "panel_list_users" }],
    [{ text: "List ADP", callback_data: "panel_list_adp" }],
  ]};
  try {
    await bot.editMessageText(text, { chat_id: q.message.chat.id, message_id: q.message.message_id, parse_mode: "HTML", reply_markup: kb });
  } catch (_) {
    await bot.sendMessage(q.message.chat.id, text, { parse_mode: "HTML", reply_markup: kb }).catch(() => {});
  }
});

bot.on("callback_query", async (q) => {
  const data = String(q.data || "");
  if (data !== "panel_list_users" && data !== "panel_list_adp") return;
  await bot.answerCallbackQuery(q.id).catch(() => {});
  if (!isPanelOwner(q.from.id)) return;
  return renderPanelUserList(q.message.chat.id, 1, q.message.message_id, 1, data === "panel_list_adp");
});

// Callback pagination untuk kedua daftar.
bot.on("callback_query", async (q) => {
  const data = String(q.data || "");
  const m = data.match(/^(listuser|listuserv([2-9]|1[0-9]|20)|listadp|listadpv([2-9]|1[0-9]|20)):(\d+)$/i);
  if (!m) return;
  await bot.answerCallbackQuery(q.id);
  if (!isPanelOwner(q.from.id)) return;
  const isAdp = /^listadp/i.test(m[1]);
  const verMatch = m[1].match(/v(\d+)$/i);
  const ver = verMatch ? Number(verMatch[1]) : 1;
  return renderPanelUserList(q.message.chat.id, Number(m[4]), q.message.message_id, ver, isAdp);
});

bot.onText(/^\/listadmin(?:\s+(\d+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  const ownerUsers = JSON.parse(fs.readFileSync(OWNER_FILE));
  if (!ownerUsers.includes(String(senderId)))
    return bot.sendMessage(chatId, "◇ Khusus owner", {
      reply_markup: { inline_keyboard: [[{ text: "Laporan", url: `https://t.me/${dev}` }]] }
    });

  const page = parseInt(match && match[1]) || 1;

  if (!domain || !plta) {
    return bot.sendMessage(chatId, "<blockquote expandable>◇ Konfigurasi panel tidak ditemukan</blockquote>", { parse_mode: "HTML" });
  }

  // Kirim pesan proses pertama
  const prosesMsg = await bot.sendMessage(chatId, "<blockquote expandable>⏳ Memproses daftar admin panel...</blockquote>", { parse_mode: "HTML" });

  try {
    const res = await fetch(`${domain}/api/application/users?page=${page}&per_page=25`, {
      headers: { Authorization: `Bearer ${plta}`, Accept: "application/json" }
    });

    const json = await res.json();
    if (!res.ok) throw new Error();

    const admins = (json.data || []).filter(u => u.attributes?.root_admin);

    let text = "";
    if (!admins.length) {
      text = "<blockquote expandable>⊘ Tidak ada admin di halaman ini</blockquote>";
    } else {
      text = `☰ <b>DAFTAR ADMIN PANEL</b>\n<b>Domain</b>: ${domain}\n━━━━━`;
      admins.forEach(u => {
        const a = u.attributes;
        text += `<b>ID</b> : <code>${a.id}</code>\n<b>User</b> : ${a.username}\n\n`;
      });
      const meta = json.meta.pagination;
      text += `⌗ Halaman: ${meta.current_page}/${meta.total_pages}`;
    }

    const nav = [];
    if (page > 1) nav.push({ text: "⬅ ‹", callback_data: `listadmin:${page - 1}` });
    if (admins.length && page < json.meta.pagination.total_pages) nav.push({ text: "➡ Lanjut", callback_data: `listadmin:${page + 1}` });

    await bot.editMessageText(`<blockquote expandable>${text}</blockquote>`, {
      chat_id: chatId,
      message_id: prosesMsg.message_id,
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: nav.length ? [nav] : [] }
    });

  } catch {
    await bot.editMessageText("<blockquote expandable>⚠ Gagal mengambil data admin</blockquote>", {
      chat_id: chatId,
      message_id: prosesMsg.message_id,
      parse_mode: "HTML"
    });
  }
});

// ================= LIST ADMIN v2–v10 =================
bot.onText(/^\/listadmin([2-9]|1[0-9]|20)(?:\s+(\d+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  const ownerUsers = JSON.parse(fs.readFileSync(OWNER_FILE));
  if (!ownerUsers.includes(String(senderId)))
    return bot.sendMessage(chatId, "◇ Khusus owner", {
      reply_markup: { inline_keyboard: [[{ text: "Laporan", url: `https://t.me/${dev}` }]] }
    });

  const i = parseInt(match[1]);
  const page = parseInt(match[2]) || 1;

  const domainVar = eval(`domainV${i}`);
  const pltaVar = eval(`pltaV${i}`);

  if (!domainVar || !pltaVar) {
    return bot.sendMessage(chatId, "<blockquote expandable>◇ Konfigurasi panel tidak ditemukan</blockquote>", { parse_mode: "HTML" });
  }

  const prosesMsg = await bot.sendMessage(chatId, `<blockquote expandable>⏳ Memproses daftar admin panel v${i}...</blockquote>`, { parse_mode: "HTML" });

  try {
    const res = await fetch(`${domainVar}/api/application/users?page=${page}&per_page=25`, {
      headers: { Authorization: `Bearer ${pltaVar}`, Accept: "application/json" }
    });

    const json = await res.json();
    if (!res.ok) throw new Error();

    const admins = (json.data || []).filter(u => u.attributes?.root_admin);

    let text = "";
    if (!admins.length) {
      text = "<blockquote expandable>⊘ Tidak ada admin di halaman ini</blockquote>";
    } else {
      text = `☰ <b>DAFTAR ADMIN PANEL v${i}</b>\n<b>Domain</b>: ${domainVar}\n━━━━━`;
      admins.forEach(u => {
        const a = u.attributes;
        text += `<b>ID</b> : <code>${a.id}</code>\n<b>User</b> : ${a.username}\n\n`;
      });
      const meta = json.meta.pagination;
      text += `⌗ Halaman: ${meta.current_page}/${meta.total_pages}`;
    }

    const nav = [];
    if (page > 1) nav.push({ text: "⬅ ‹", callback_data: `listadminv${i}:${page - 1}` });
    if (admins.length && page < json.meta.pagination.total_pages) nav.push({ text: "➡ Lanjut", callback_data: `listadminv${i}:${page + 1}` });

    await bot.editMessageText(`<blockquote expandable>${text}</blockquote>`, {
      chat_id: chatId,
      message_id: prosesMsg.message_id,
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: nav.length ? [nav] : [] }
    });

  } catch {
    await bot.editMessageText("<blockquote expandable>⚠ Gagal mengambil data admin</blockquote>", {
      chat_id: chatId,
      message_id: prosesMsg.message_id,
      parse_mode: "HTML"
    });
  }
});

// ================= CALLBACK QUERY =================
bot.on("callback_query", async (q) => {
  if (!q.data.startsWith("listadmin")) return;
  await bot.answerCallbackQuery(q.id);

  const chatId = q.message.chat.id;
  const senderId = q.from.id;

  const ownerUsers = JSON.parse(fs.readFileSync(OWNER_FILE));
  if (!ownerUsers.includes(String(senderId))) {
    return bot.sendMessage(chatId, "◇ Khusus owner", {
      reply_markup: { inline_keyboard: [[{ text: "Laporan", url: `https://t.me/${dev}` }]] }
    });
  }

  if (q.data.startsWith("listadminv")) {
    const [, v, p] = q.data.match(/listadminv(\d+):(\d+)/);
    bot.editMessageText(`<blockquote expandable>⏳ Memproses daftar admin panel v${v} halaman ${p}...</blockquote>`, {
      chat_id: chatId,
      message_id: q.message.message_id,
      parse_mode: "HTML"
    }).then(() => {
      bot.processUpdate({
        update_id: Date.now(),
        message: { ...q.message, from: { id: senderId }, text: `/listadminv${v} ${p}` }
      });
    });
  } else {
    const page = q.data.split(":")[1];
    bot.editMessageText(`<blockquote expandable>⏳ Memproses daftar admin panel halaman ${page}...</blockquote>`, {
      chat_id: chatId,
      message_id: q.message.message_id,
      parse_mode: "HTML"
    }).then(() => {
      bot.processUpdate({
        update_id: Date.now(),
        message: { ...q.message, from: { id: senderId }, text: `/listadmin ${page}` }
      });
    });
  }
});
bot.onText(/^\/clearall(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id.toString(); // pastikan string

  // ================= VALIDASI OWNER =================
  if (!settings.isOwner(senderId)) {
    return bot.sendMessage(
        chatId,
        `<blockquote expandable>◇ Akses ditolak!\nHanya OWNER yang bisa menggunakan command ini.</blockquote>`,
        { parse_mode: "HTML" }
    );
}

  const excludedRaw = match[1];

  if (!excludedRaw)
    return bot.sendMessage(
      chatId,
      `<blockquote expandable>◇ Format salah: <code>/clearall [id yg di kecualikan]</code>\nContoh: /clearall 1,2,3</blockquote>`,
      { parse_mode: "HTML" }
    );

  const excludedIds = excludedRaw
    .split(",")
    .map(x => x.trim())
    .filter(x => /^\d+$/.test(x));

  if (!excludedIds.length)
    return bot.sendMessage(
      chatId,
      `<blockquote expandable>◇ ID pengecualian tidak valid</blockquote>`,
      { parse_mode: "HTML" }
    );

  // ================= AMBIL DARI SETTINGS =================
  const panelDomain = settings.domain.replace(/\/$/, "");
  const PLTA = settings.plta;

  if (!panelDomain || !PLTA)
    return bot.sendMessage(
      chatId,
      `<blockquote expandable>◇ Domain / PLTA belum diset di settings</blockquote>`,
      { parse_mode: "HTML" }
    );

  const infoMsg = await bot.sendMessage(
    chatId,
    `<blockquote expandable>⏳ Menghapus semua server kecuali ID ${excludedIds.join(", ")}....</blockquote>`,
    { parse_mode: "HTML" }
  );

  try {
    // ================= AMBIL SEMUA SERVER =================
    let servers = [];
    let page = 1;
    let more = true;

    while (more) {
      const res = await axios.get(
        `${panelDomain}/api/application/servers?page=${page}`,
        { headers: { Authorization: `Bearer ${PLTA}` } }
      );

      servers.push(...res.data.data);
      more = res.data.meta.pagination.current_page < res.data.meta.pagination.total_pages;
      page++;
    }

    let serverDeleted = 0;
    let serverFailed = 0;

    for (const srv of servers) {
      const sid = String(srv.attributes.id);
      if (excludedIds.includes(sid)) continue;

      try {
        await axios.delete(
          `${panelDomain}/api/application/servers/${sid}`,
          { headers: { Authorization: `Bearer ${PLTA}` } }
        );
        serverDeleted++;
      } catch {
        serverFailed++;
      }
    }

    // ================= AMBIL SEMUA USER =================
    let users = [];
    page = 1;
    more = true;

    while (more) {
      const res = await axios.get(
        `${panelDomain}/api/application/users?page=${page}&include=servers`,
        { headers: { Authorization: `Bearer ${PLTA}` } }
      );

      users.push(...res.data.data);
      more = res.data.meta.pagination.current_page < res.data.meta.pagination.total_pages;
      page++;
    }

    let userDeleted = 0;
    let userSkipped = 0;

    for (const usr of users) {
      const uid = String(usr.attributes.id);
      if (excludedIds.includes(uid)) continue;

      const serverCount = usr.attributes.relationships.servers.data.length;
      if (serverCount > 0) {
        userSkipped++;
        continue;
      }

      try {
        await axios.delete(
          `${panelDomain}/api/application/users/${uid}`,
          { headers: { Authorization: `Bearer ${PLTA}` } }
        );
        userDeleted++;
      } catch {}
    }

    await bot.editMessageText(
`<blockquote expandable>◉ PROSES SELESAI
━━━━━━━━━━━━━━━━━━
⌫ Server terhapus : ${serverDeleted}
◇ Server gagal   : ${serverFailed}

◉ User terhapus  : ${userDeleted}
⏭ User dilewati  : ${userSkipped}

⟠ ID dikecualikan:
${excludedIds.join(", ")}
━━━━━━━━━━━━━━━━━━
</blockquote>`,
      {
        chat_id: chatId,
        message_id: infoMsg.message_id,
        parse_mode: "HTML"
      }
    );

  } catch (err) {
    await bot.editMessageText(
      `<blockquote expandable>◇ ERROR\n${err.message}</blockquote>`,
      {
        chat_id: chatId,
        message_id: infoMsg.message_id,
        parse_mode: "HTML"
      }
    );
  }
});
bot.onText(/^\/suspend\s+(.+)/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const input = match[1].trim();

  if (!input) {
    return bot.sendMessage(chatId, "◇ Format salah!\nContoh: /suspend <uuid / id>");
  }

  // ⟠ Ambil daftar owner dari file
  const ownerUsers = JSON.parse(fs.readFileSync(OWNER_FILE));
  const isOwner = ownerUsers.includes(String(msg.from.id));

  if (!isOwner) {
    return bot.sendMessage(chatId, "⌖ Perintah ini khusus owner.");
  }

  try {
    await bot.sendMessage(chatId, "⏳ Mencari server...");

    // ⟡ Ambil semua server dari API
    const res = await fetch(`${domain}/api/application/servers`, {
      headers: {
        Accept: "application/json",
        Authorization: `Bearer ${plta}`,
      },
    });

    const data = await res.json();
    const servers = data.data || [];

    // ⌕ Cari server berdasarkan UUID atau ID
    let server = servers.find(s => s.attributes.uuid === input);
    if (!server) server = servers.find(s => String(s.attributes.id) === input);

    if (!server) return bot.sendMessage(chatId, "◇ Server tidak ditemukan!");

    const s = server.attributes;

    // ⊘ Cek apakah sudah suspend
    if (s.suspended) {
      return bot.sendMessage(chatId, "⚠ Server sudah dalam keadaan suspend!");
    }

    await bot.sendMessage(chatId, "⊘ Menyuspend server...");

    // ⟡ Suspend server melalui API
    const suspendRes = await fetch(`${domain}/api/application/servers/${s.id}/suspend`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        Authorization: `Bearer ${plta}`,
      },
    });

    if (!suspendRes.ok) return bot.sendMessage(chatId, "◇ Gagal suspend server!");

    // ◉ Hasil
    const result = `<blockquote expandable>⊘ <b>SERVER BERHASIL DI SUSPEND</b>

⌇ Server ID: <code>${s.id}</code>
⌬ UUID: <code>${s.uuid}</code>
◈ Nama: <b>${s.name}</b>
◉ User ID: <code>${s.user}</code>
</blockquote>`;

    await bot.sendMessage(chatId, result, { parse_mode: "HTML" });

  } catch (err) {
    console.error("SUSPEND ERROR:", err);
    bot.sendMessage(chatId, "◇ Terjadi kesalahan saat suspend server!");
  }
});
bot.onText(/^\/infoserver\s+(.+)/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const input = match[1].trim();

  if (!input) {
    return bot.sendMessage(chatId, "◇ Format salah!\nContoh: /infoserver <uuid / id>");
  }

  // ⟠ Hanya grup atau owner
  if ((msg.chat.type !== "group" && msg.chat.type !== "supergroup") && !settings.isOwner(msg.from.id)) {
    return bot.sendMessage(chatId, "◇ Hanya bisa di grup!");
  }

  // ⟠ Cek owner
  const ownerUsers = JSON.parse(fs.readFileSync(OWNER_FILE));
  if (!ownerUsers.includes(String(msg.from.id))) {
    return bot.sendMessage(chatId, "⌖ Perintah ini khusus owner.");
  }

  try {
    await bot.sendMessage(chatId, "⏳ Mengambil data server...");

    // ⟡ GET ALL SERVER
    const res = await fetch(`${domain}/api/application/servers`, {
      headers: {
        Accept: "application/json",
        Authorization: `Bearer ${plta}`,
      },
    });

    const data = await res.json();
    const servers = data.data || [];

    // ⌕ CARI BERDASARKAN UUID ATAU ID
    let server = servers.find(s => s.attributes.uuid === input);

    if (!server) {
      server = servers.find(s => String(s.attributes.id) === input);
    }

    if (!server) {
      return bot.sendMessage(chatId, "◇ Server tidak ditemukan!");
    }

    const s = server.attributes;

    // ⟡ STATUS REALTIME
    let status = s.status || "unknown";
    try {
      const f2 = await fetch(
        `${domain}/api/client/servers/${s.uuid.split("-")[0]}/resources`,
        {
          headers: {
            Accept: "application/json",
            Authorization: `Bearer ${pltc}`,
          },
        }
      );

      const r2 = await f2.json();
      if (r2?.attributes?.current_state) {
        status = r2.attributes.current_state;
      }
    } catch {}

    // ⟡ DATA USER
    let email = "unknown";
    let username = "unknown";

    try {
      const ures = await fetch(`${domain}/api/application/users/${s.user}`, {
        headers: {
          Accept: "application/json",
          Authorization: `Bearer ${plta}`,
        },
      });

      const udata = await ures.json();
      if (udata?.attributes) {
        email = udata.attributes.email;
        username = udata.attributes.username;
      }
    } catch {}

    // ⟡ OUTPUT FINAL
    const result = `<blockquote expandable>▭ <b>INFORMASI SERVER</b>

⌇ Server ID: <code>${s.id}</code>
⌬ UUID: <code>${s.uuid}</code>
◈ Nama: <b>${s.name}</b>

◉ User ID: <code>${s.user}</code>
◉ Username: <b>${username}</b>
✉ Email: <code>${email}</code>

⊙ Status: <b>${status}</b>
⌘ Node: <b>${s.node}</b>

⟡ Memory: <b>${s.limits.memory} MB</b>
⌗ CPU: <b>${s.limits.cpu}%</b>
⟡ Disk: <b>${s.limits.disk} MB</b>
</blockquote>`;

    await bot.sendMessage(chatId, result, { parse_mode: "HTML" });

  } catch (err) {
    console.error("INFOSERVER ERROR:", err);
    bot.sendMessage(chatId, "◇ Gagal mengambil informasi server!");
  }
});
bot.onText(/^\/unsus$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (!settings.isOwner(userId)) {
    return bot.sendMessage(chatId, `<blockquote expandable>◇ Hanya OWNER yang dapat menggunakan command ini.</blockquote>`, { parse_mode: "HTML" });
  }

  bot.sendMessage(chatId, `<blockquote expandable>⟲ Memulai proses unsuspend semua server...</blockquote>`, { parse_mode: "HTML" });

  try {
    const res = await axios.get(`${domain}/api/application/servers`, {
      headers: { Authorization: `Bearer ${plta}`, Accept: "Application/vnd.pterodactyl.v1+json" }
    });

    for (let srv of res.data.data) {
      const { id, name } = srv.attributes;

      try {
        await axios.post(`${domain}/api/application/servers/${id}/unsuspend`, {}, {
          headers: { Authorization: `Bearer ${plta}`, Accept: "Application/vnd.pterodactyl.v1+json" }
        });
        console.log(`◉ SERVER DI UNSUSPEND [${name} | ID: ${id}]`);
      } catch (err) {
        console.error(`◇ Gagal unsuspend server [${name} | ID: ${id}]`, err.response?.data || err.message);
      }
    }

    bot.sendMessage(chatId, `<blockquote expandable>◉ Proses unsuspend semua server selesai!</blockquote>`, { parse_mode: "HTML" });

  } catch (err) {
    console.error("Error fetch servers:", err.response?.data || err.message);
    bot.sendMessage(chatId, `<blockquote expandable>◇ Terjadi kesalahan saat mengambil data server.</blockquote>`, { parse_mode: "HTML" });
  }
});
bot.onText(/\/clearusr$/, async (msg) => {
  const chatId = msg.chat.id;

  // ⟠ only OWNER_UID
  if (!settings.isOwner(msg.from.id)) {
    return bot.sendMessage(chatId, "akses ditolak");
  }

  try {
    const res = await axios.get(`${domain}/api/application/users`, {
      headers: {
        Authorization: `Bearer ${plta}`,
        Accept: "application/json"
      }
    });

    const users = res.data?.data || [];

    if (!users.length) {
      return bot.sendMessage(chatId, "tidak ada user");
    }

    let berhasil = 0;
    let gagal = 0;

    const proses = await bot.sendMessage(chatId, "⏳ memproses clear user...");

    for (const u of users) {
      const id = u.attributes?.id;

      if (id === 1) continue;

      try {
        await axios.delete(`${domain}/api/application/users/${id}`, {
          headers: {
            Authorization: `Bearer ${plta}`,
            Accept: "application/json"
          }
        });

        berhasil++;
      } catch {
        gagal++;
      }
    }

    await bot.editMessageText(
`╭───〔 CLEAR USER PANEL 〕───╮

  ◉ SUKSES CLEAR USER

  ◉ BERHASIL : ${berhasil}
  ◇ GAGAL    : ${gagal}

`,
      {
        chat_id: chatId,
        message_id: proses.message_id
      }
    );

  } catch {
    bot.sendMessage(chatId, "gagal mengambil data user");
  }
});

}
