// Owner-only panel utilities: /mypanel, /autoegg, /joinfirst
const fs = require("fs");
const path = require("path");
const settings = require("../settings.js");
const panelLog = require("./data/panelLog.js");
const panelStore = require("./data/panelStore.js");

const JOIN_FILE = path.join(process.cwd(), "db", "joinFirst.json");
const MAX_JOIN = 5;
const EGG_STATE_FILE = path.join(process.cwd(), 'db', 'autoEgg.json');
function isAutoEgg() { try { return !!JSON.parse(fs.readFileSync(EGG_STATE_FILE,'utf8')).enabled; } catch { return false; } }
function setAutoEgg(v) { fs.mkdirSync(path.dirname(EGG_STATE_FILE),{recursive:true}); fs.writeFileSync(EGG_STATE_FILE, JSON.stringify({enabled:!!v,updatedAt:new Date().toISOString()},null,2)); }

function esc(v) {
  return String(v ?? "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
}
function loadJoin() {
  try {
    const d = JSON.parse(fs.readFileSync(JOIN_FILE, "utf8"));
    return Array.isArray(d) ? d.slice(0, MAX_JOIN) : [];
  } catch { return []; }
}
function saveJoin(rows) {
  fs.mkdirSync(path.dirname(JOIN_FILE), { recursive:true });
  fs.writeFileSync(JOIN_FILE, JSON.stringify(rows.slice(0,MAX_JOIN), null, 2));
}
function isOwner(id) { return settings.isOwner(id); }

async function editPanelCard(bot, msg, text, keyboard = []) {
  const opts = { chat_id: msg.chat.id, message_id: msg.message_id, parse_mode: "HTML", reply_markup: { inline_keyboard: keyboard } };
  try { return await bot.editMessageText(text, opts); }
  catch (e) {
    const d=String(e?.response?.body?.description||e?.message||"");
    if (/message is not modified/i.test(d)) return null;
    try { return await bot.editMessageCaption(text, opts); } catch {}
    // Command /mypanel tidak berasal dari dashboard sehingga memang belum ada kartu untuk diedit.
    if (msg.__allowSend) return bot.sendMessage(msg.chat.id, text, {parse_mode:"HTML", reply_markup:{inline_keyboard:keyboard}});
    throw e;
  }
}

async function panelOnline(version) {
  try {
    const p=panelStore.getPanel(version);
    if(!p?.domain || !p?.plta) return false;
    const r=await fetch(`${String(p.domain).replace(/\/$/,"")}/api/application/users?per_page=1`,{headers:{Authorization:`Bearer ${p.plta}`,Accept:'application/json'},signal:AbortSignal.timeout(5000)});
    return r.ok;
  } catch { return false; }
}

async function mypanel(bot, msg) {
  const all = panelLog.getAll().filter(x => String(x.creatorTgId) === String(msg.from.id) || String(x.targetTgId) === String(msg.from.id));
  const versions=[...new Set(all.map(x=>String(x.panelVersion||'')).filter(Boolean))];
  const onlineSet=new Set();
  await Promise.all(versions.map(async v=>{ if(await panelOnline(v)) onlineSet.add(v); }));
  const rows=all.filter(x=>onlineSet.has(String(x.panelVersion||'')));
  if (!rows.length) return editPanelCard(bot,msg,
    `<blockquote expandable><b>MY PANEL</b>\n\nTidak ada server panel yang sedang terhubung untuk akun kamu.\n\n<i>Menu My Panel hanya menampilkan server yang konfigurasi API-nya aktif dan dapat dihubungi.</i></blockquote>`,
    [[{text:'Dashboard',callback_data:'back'}]]);

  const groups=new Map();
  for(const r of rows){ const k=String(r.panelVersion||'server'); if(!groups.has(k))groups.set(k,[]); groups.get(k).push(r); }
  const body=[...groups.entries()].map(([ver,list],i)=>{
    const accounts=new Set(list.map(x=>String(x.ptUserId||x.panelEmail||'')).filter(Boolean));
    return `<b>Server ${i+1} • ${esc(ver)}</b>\n├ Server panel: <b>${list.length}</b>\n└ Akun: <b>${accounts.size}</b>`;
  }).join('\n\n');
  const keyboard=[...groups.entries()].map(([ver,list],i)=>[{text:`Server ${i+1} • ${list.length} panel`,callback_data:`mypanel:server:${ver}`}]);
  keyboard.push([{text:'Refresh',callback_data:'mypanel:refresh'}],[{text:'‹‹‹',callback_data:'back'}]);
  return editPanelCard(bot,msg,`<b>╭━━〔 MY PANEL 〕━━╮</b>\n\n<blockquote expandable>${body}</blockquote>\n\nPilih server untuk melihat akun dan jumlah panel di dalamnya.`,keyboard);
}

function joinListText(rows) {
  let body = "";
  for (let i=0;i<MAX_JOIN;i++) {
    const s=rows[i];
    body += s
      ? `<b>${i+1}. ${esc(s.title || s.username || s.id)}</b>\n├ <b>ID</b> : <code>${esc(s.id)}</code>\n└ <b>Bot admin</b> : ${s.ready ? "YA" : "BELUM"}\n\n`
      : `<b>${i+1}. KOSONG</b>\n└ Slot siap digunakan\n\n`;
  }
  return `<b>╭━━〔 FIRST JOIN 〕━━╮</b>\n<blockquote expandable>${body}</blockquote><i>Maksimal ${MAX_JOIN} grup/channel.</i>`;
}

async function joinfirst(bot,msg) {
  if (!isOwner(msg.from.id)) return bot.sendMessage(msg.chat.id,
    `<blockquote expandable><b>AKSES DITOLAK</b>\n\nFirst Join hanya dapat diatur oleh owner.</blockquote>`,
    {parse_mode:"HTML"});
  const args=(msg.text||"").trim().split(/\s+/).slice(1);
  const rows=loadJoin();
  if (args[0] && /^del|hapus$/i.test(args[0])) {
    const n=Number(args[1]);
    if (!Number.isInteger(n) || n<1 || n>MAX_JOIN) return bot.sendMessage(msg.chat.id, `<blockquote expandable><b>FORMAT SALAH</b>\n\nGunakan <code>/joinfirst del 1</code> sampai <code>/joinfirst del 5</code>.</blockquote>`,{parse_mode:"HTML"});
    rows.splice(n-1,1); saveJoin(rows);
    return bot.sendMessage(msg.chat.id, joinListText(loadJoin()), {parse_mode:"HTML"});
  }
  if (args.length) {
    if (rows.length>=MAX_JOIN) return bot.sendMessage(msg.chat.id, `<blockquote expandable><b>FIRST JOIN PENUH</b>\n\nMaksimal <b>${MAX_JOIN}</b> slot. Hapus salah satu dengan <code>/joinfirst del nomor</code>.</blockquote>`,{parse_mode:"HTML"});
    const raw=args[0];
    let ref=raw;
    const m=raw.match(/(?:https?:\/\/)?t\.me\/(.+)/i);
    if(m) ref="@"+m[1].replace(/^@/,"").split(/[/?]/)[0];
    try {
      const chat=await bot.getChat(ref);
      if (!chat) throw new Error("chat not found");
      const me=await bot.getMe();
      let ready=false; try { const mm=await bot.getChatMember(chat.id,me.id); ready=["administrator","creator"].includes(mm.status); } catch {}
      rows.push({id:String(chat.id),title:chat.title||chat.username||String(chat.id),username:chat.username||null,link:chat.username?`https://t.me/${chat.username}`:(raw.startsWith("http")?raw:null),ready});
      saveJoin(rows);
      return bot.sendMessage(msg.chat.id, joinListText(loadJoin()),{parse_mode:"HTML"});
    } catch(e) {
      return bot.sendMessage(msg.chat.id, `<blockquote expandable><b>FIRST JOIN GAGAL</b>\n\nBot tidak bisa membaca <code>${esc(raw)}</code>.\nPastikan bot sudah masuk dan menjadi admin di sana.</blockquote>`,{parse_mode:"HTML"});
    }
  }
  return bot.sendMessage(msg.chat.id, joinListText(rows), {
    parse_mode:"HTML",
    reply_markup:{inline_keyboard:[
      [{text:"Cara tambah slot",callback_data:"ownerjf:help"}],
      ...rows.map((s,i)=>s?[{text:`Hapus Slot ${i+1}`,callback_data:`ownerjf:del:${i}`}]:[]),
    ]}
  });
}

const eggCache = new Map();
async function resolveAutoEgg(panel, runtime) {
  if (!isAutoEgg()) return null;
  const key = `${panel.domain}|${runtime}`;
  const cached = eggCache.get(key);
  if (cached && cached.exp>Date.now()) return cached.egg;
  const base=String(panel.domain||"").replace(/\/+$/,"");
  const headers={Authorization:`Bearer ${panel.plta}`,Accept:"application/json","Content-Type":"application/json"};
  const get=async url=>{const r=await fetch(url,{headers,signal:AbortSignal.timeout(15000)});const j=await r.json().catch(()=>null);if(!r.ok)throw new Error(j?.errors?.[0]?.detail||`HTTP ${r.status}`);return j;};
  const nests=(await get(`${base}/api/application/nests?per_page=100`)).data||[];
  const eggs=[];
  for(const n of nests){
    const nid=n.attributes?.id;if(nid==null)continue;
    const er=(await get(`${base}/api/application/nests/${nid}/eggs?per_page=100`)).data||[];
    for(const e of er) eggs.push({id:e.attributes?.id,name:String(e.attributes?.name||"")});
  }
  const re=runtime==="python" ? /python/i : /(node\.?js|nodejs|node|npm)/i;
  const found=eggs.find(e=>re.test(e.name));
  if(found) eggCache.set(key,{egg:String(found.id),exp:Date.now()+300000});
  return found ? String(found.id) : null;
}

async function autoegg(bot,msg) {
  if (!isOwner(msg.from.id)) return bot.sendMessage(msg.chat.id,
    `<blockquote expandable><b>AKSES DITOLAK</b>\n\n<code>/autoegg</code> hanya untuk owner.</blockquote>`,
    {parse_mode:"HTML"});
  const arg=String((msg.text||"").split(/\s+/)[1]||"").toLowerCase();
  if (["off","0","mati","disable"].includes(arg)) {
    setAutoEgg(false);
    return bot.sendMessage(msg.chat.id, `<blockquote expandable><b>AUTO EGG</b>\n\nStatus: <b>OFF</b>\nMode kembali menggunakan Egg manual dari konfigurasi panel.</blockquote>`, {parse_mode:"HTML"});
  }
  if (arg==="status") return bot.sendMessage(msg.chat.id,
    `<blockquote expandable><b>AUTO EGG</b>\n\nStatus: <b>${isAutoEgg() ? "ON" : "OFF"}</b>\nSlot panel: <b>${panelStore.PANEL_KEYS.length}</b></blockquote>`, {parse_mode:"HTML"});

  const msgLoading=await bot.sendMessage(msg.chat.id, `<blockquote expandable><b>AUTO EGG</b>\n\nSedang membaca konfigurasi Egg panel...</blockquote>`, {parse_mode:"HTML"});
  let changed=0, failed=0;
  // AutoEgg di sini memilih Egg berdasarkan nama, bukan menebak ID.
  // Hanya slot yang sudah memiliki domain + PLTA yang diproses.
  for (const key of panelStore.PANEL_KEYS) {
    try {
      const p=panelStore.getPanel(key);
      if (!p.domain || !p.plta) { failed++; continue; }
      const base=String(p.domain).replace(/\/+$/,"");
      const headers={Authorization:`Bearer ${p.plta}`,Accept:"application/json","Content-Type":"application/json"};
      const get=async url=>{
        const r=await fetch(url,{headers,signal:AbortSignal.timeout(20000)});
        const j=await r.json().catch(()=>null);
        if(!r.ok) throw new Error(j?.errors?.[0]?.detail||`HTTP ${r.status}`);
        return j;
      };
      const nests=(await get(`${base}/api/application/nests?per_page=100`)).data||[];
      const eggs=[];
      for(const n of nests){
        const nid=n.attributes?.id;
        if(nid==null) continue;
        const er=(await get(`${base}/api/application/nests/${nid}/eggs?per_page=100`)).data||[];
        for(const e of er) eggs.push({id:e.attributes?.id,name:String(e.attributes?.name||""),nest:String(n.attributes?.name||"")});
      }
      const node=eggs.find(e=>/(node\.?js|nodejs|node|npm)/i.test(e.name));
      const python=eggs.find(e=>/python/i.test(e.name));
      if(node || python) {
        panelStore.setPanel(key,{domain:p.domain,plta:p.plta,pltc:p.pltc,eggs:node?.id??p.eggs,eggsPython:python?.id??p.eggsPython});
        changed++;
      } else failed++;
    } catch { failed++; }
  }
  setAutoEgg(true);
  try { await bot.editMessageText(`<b>╭━━〔 AUTO EGG AKTIF 〕━━╮</b>\n\n<blockquote expandable><b>Slot diperbarui</b> : ${changed}\n<b>Gagal / dilewati</b> : ${failed}\n<b>Mode</b> : <b>ON</b></blockquote>\n<i>Node.js dan Python dipilih otomatis berdasarkan nama Egg yang tersedia.</i>`,{chat_id:msg.chat.id,message_id:msgLoading.message_id,parse_mode:"HTML"}); } catch {}
}

function register(bot) {
  bot.onText(/^\/mypanel(?:@\w+)?$/i, msg=>void mypanel(bot,{...msg,__allowSend:true}));
  bot.onText(/^\/autoegg(?:@\w+)?(?:\s+\S+)?$/i, msg=>void autoegg(bot,msg));
  bot.onText(/^\/joinfirst(?:@\w+)?$/i, msg=>void joinfirst(bot,msg));

  bot.on("callback_query", async q=>{
    if(!q?.data) return;
    try {
      if(q.data==="mypanel:refresh") {
        await bot.answerCallbackQuery(q.id,{text:"Panel diperbarui"});
        await mypanel(bot,{from:q.from,chat:q.message.chat,message_id:q.message.message_id});
        return;
      }
      if(q.data==="mypanel:back") {
        await bot.answerCallbackQuery(q.id);
        return;
      }
      if(q.data.startsWith("mypanel:server:")) {
        await bot.answerCallbackQuery(q.id).catch(()=>{});
        const ver=q.data.slice("mypanel:server:".length);
        const rows=panelLog.getAll().filter(x => (String(x.creatorTgId)===String(q.from.id)||String(x.targetTgId)===String(q.from.id)) && String(x.panelVersion)===ver);
        const acc=new Map();
        for(const r of rows){ const id=String(r.ptUserId||r.panelEmail||'unknown'); if(!acc.has(id))acc.set(id,[]); acc.get(id).push(r); }
        const body=[...acc.entries()].map(([id,list],i)=>`<b>Akun ${i+1}</b>\n├ ID: <code>${esc(id)}</code>\n└ ${list.length} panel`).join('\n\n') || 'Belum ada akun.';
        return editPanelCard(bot,{from:q.from,chat:q.message.chat,message_id:q.message.message_id},`<b>SERVER PANEL</b>\n\n<blockquote expandable>${body}</blockquote>\n\n<b>Tambahkan ke Akun</b> akan membuat server baru pada login Pterodactyl lama. <b>Akun Baru</b> membuat login baru.`,[
          [{text:'Tambahkan ke Akun',callback_data:`mypanel:add:${ver}`},{text:'Akun Baru',callback_data:`mypanel:new:${ver}`}],
          [{text:'‹‹‹',callback_data:'mypanel:refresh'}]
        ]);
      }
      if(q.data.startsWith("mypanel:add:") || q.data.startsWith("mypanel:new:")) {
        await bot.answerCallbackQuery(q.id).catch(()=>{});
        const parts=q.data.split(':'); const mode=parts[1], ver=parts.slice(2).join(':');
        global.__LIANIX_UNLI_PREFERRED_SERVER__ ||= new Map();
        global.__LIANIX_UNLI_PREFERRED_SERVER__.set(String(q.from.id),{version:ver,mode,expires:Date.now()+5*60*1000});
        return editPanelCard(bot,{from:q.from,chat:q.message.chat,message_id:q.message.message_id},`<b>${mode==='add'?'TAMBAHKAN KE AKUN':'AKUN BARU'}</b>\n\n<blockquote expandable>Server tujuan sudah dipilih: <b>${esc(ver)}</b>.\n\nSekarang kirim <code>/unli namaserver</code>. Bot akan langsung memakai server ini dan ${mode==='add'?'menampilkan akun lama yang bisa dipilih':'membuat akun Pterodactyl baru'}.</blockquote>`,[[{text:'‹‹‹',callback_data:`mypanel:server:${ver}`}]]);
      }
      if(q.data==="ownerfeat:autoegg") {
        if(!isOwner(q.from.id)) return bot.answerCallbackQuery(q.id,{text:"Khusus owner",show_alert:true});
        await bot.answerCallbackQuery(q.id);
        await autoegg(bot,{from:q.from,chat:q.message.chat,message_id:q.message.message_id,text:"/autoegg"});
        return;
      }
      if(q.data==="ownerfeat:joinfirst") {
        if(!isOwner(q.from.id)) return bot.answerCallbackQuery(q.id,{text:"Khusus owner",show_alert:true});
        await bot.answerCallbackQuery(q.id);
        await bot.sendMessage(q.message.chat.id, joinListText(loadJoin()), {parse_mode:"HTML", reply_markup:{inline_keyboard:[
          [{text:"＋ Tambah Slot",callback_data:"ownerjf:add"}],
          ...loadJoin().map((x,i)=>x?[{text:`Hapus Slot ${i+1}`,callback_data:`ownerjf:del:${i}`}]:[]),
          [{text:"‹‹‹",callback_data:"ownermenu"}]
        ]}});
        return;
      }
      if(!q.data.startsWith("ownerjf:") || !isOwner(q.from.id)) return;
      const rows=loadJoin(), [_,act,arg]=q.data.split(":");
      if(act==="del") {
        rows.splice(Number(arg),1); saveJoin(rows);
        await bot.answerCallbackQuery(q.id,{text:"Slot dihapus"});
        await bot.editMessageText(joinListText(loadJoin()),{chat_id:q.message.chat.id,message_id:q.message.message_id,parse_mode:"HTML",reply_markup:{inline_keyboard:[
          [{text:"＋ Tambah Slot",callback_data:"ownerjf:add"}],
          ...loadJoin().map((x,i)=>x?[{text:`Hapus Slot ${i+1}`,callback_data:`ownerjf:del:${i}`}]:[]),
          [{text:"‹‹‹",callback_data:"ownermenu"}]
        ]}});
      } else if(act==="add") {
        await bot.answerCallbackQuery(q.id,{text:"Kirim /joinfirst @channel atau link t.me/...",show_alert:true});
      }
    } catch(e) { try { await bot.answerCallbackQuery(q.id,{text:"Gagal memproses tombol",show_alert:true}); } catch {} }
  });
}
module.exports=register;
module.exports.register=register;
module.exports.loadJoin=loadJoin;
module.exports.saveJoin=saveJoin;
module.exports.MAX_JOIN=MAX_JOIN;
module.exports.__mypanel=mypanel;
module.exports.isAutoEgg=isAutoEgg;
module.exports.resolveAutoEgg=resolveAutoEgg;
module.exports.setAutoEgg=setAutoEgg;
