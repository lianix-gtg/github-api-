/*
 * ============================================================
 * 🖥️ CREATE PANEL / AKSES RESELLER
 * ============================================================
 * Validasi role dan kartu "AKSES TERBATAS" ada di file ini.
 * Jika ingin mengubah tampilan pesan akses, cari komentar "UI AKSES TERBATAS".
 */
// src/panelCreate.js
// ============================================================
//  SISTEM CREATE PANEL UNLI -- versi konsolidasi.
//
//  Dulu: /unli, /unliv2, /unliv3 ... /unliv20 masing-masing punya
//  blok kode sendiri di panel.js (nyaris identik, copy-paste ~150
//  baris x 20 = ribuan baris). Sekarang: SATU implementasi generik,
//  dijalanin 20x lewat loop pakai daftar versi di bawah. Nambah versi
//  baru (V21 dst) tinggal nambah 1 baris di PANEL_VERSIONS, gak perlu
//  copy-paste blok baru lagi.
//
//  Alur (sama seperti sebelumnya, tampilannya dirapikan):
//   1. User ketik /unli / /unliv2 / dst -> validasi (join channel,
//      status create panel, reseller access, format, target sudah
//      start bot).
//   2. Bot nanya runtime lewat tombol (Node.js / Python).
//   3. User pilih -> panel dibuat via API Pterodactyl -> hasil
//      dikirim ke chat asal (kartu ringkas) DAN ke DM target user
//      (kartu lengkap dengan tombol Login).
// ============================================================

const ownerFeatures = require('./ownerFeatures.js');
/**
 * safeReply — sendMessage with reply_to_message_id fallback.
 * Jika pesan asli sudah dihapus, retry tanpa reply daripada throw error.
 */
async function safeReply(bot, chatId, text, opts = {}) {
  try {
    return await bot.sendMessage(chatId, text, opts);
  } catch (err) {
    const desc = String(err?.response?.body?.description || err?.message || '');
    if (/message to be replied not found/i.test(desc) && opts.reply_to_message_id) {
      const { reply_to_message_id: _, ...safeOpts } = opts;
      return await bot.sendMessage(chatId, text, safeOpts);
    }
    throw err;
  }
}

const fs = require("fs");
const roleAccess = require("./roleAccess");
const settings = require("../settings.js");
const channelStore = require("./data/channelStore.js");
const ownerStore = require("./data/ownerStore.js");
const panelStore = require("./data/panelStore.js");
const theme      = require("./theme.js");
const panelLog   = require("./data/panelLog.js");
const { getUserRoleLabel } = require("./limit.js");
const featureLocks = require("./featureLocks.js");

// ===== WAJIB JOIN: VALIDASI CHANNEL & ADMIN BOT =====
// Hanya channel yang benar-benar bisa dicek dan bot-nya berstatus admin/creator
// yang boleh ditampilkan kepada user. Channel yang bot-nya belum admin tidak
// dibocorkan ke user; owner/admin mendapat notifikasi agar memperbaikinya.
const __joinAdminNoticeAt = new Map();

function __ownerIds() {
  try {
    return [...new Set(ownerStore.getOwnerIds().map(String).filter(Boolean))];
  } catch (_) {
    return ownerStore.getOwnerIds().map(String).filter(Boolean);
  }
}

function __channelUrl(username) {
  const u = String(username || "").replace(/^@/, "").trim();
  return u ? `https://t.me/${u}` : "";
}

async function __notifyChannelNeedsAdmin(bot, channel, reason) {
  const key = `${channel?.id || ""}:${channel?.username || ""}`;
  const now = Date.now();
  // Jangan spam owner jika command / verify dipanggil berkali-kali.
  if (__joinAdminNoticeAt.has(key) && now - __joinAdminNoticeAt.get(key) < 10 * 60 * 1000) return;
  __joinAdminNoticeAt.set(key, now);

  const username = String(channel?.username || "-");
  const url = __channelUrl(username);
  const text =
    `<blockquote expandable>` +
    `⚠️ <b>CHANNEL WAJIB JOIN PERLU ADMIN</b>\n\n` +
    `Channel : <code>${username.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")}</code>\n` +
    `Status  : <b>Bot belum menjadi admin</b>\n` +
    `Detail  : ${String(reason || "Tidak dapat memverifikasi status admin bot.").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")}\n\n` +
    `Jadikan bot sebagai <b>Administrator</b> di channel tersebut agar channel bisa digunakan sebagai wajib join.` +
    `</blockquote>`;

  const markup = url
    ? { inline_keyboard: [[{ text: "BUKA CHANNEL ↗", url }]] }
    : undefined;

  for (const ownerId of __ownerIds()) {
    try {
      await bot.sendMessage(ownerId, text, {
        parse_mode: "HTML",
        ...(markup ? { reply_markup: markup } : {}),
      });
    } catch (_) {}
  }
}

async function __getJoinChannels(bot, userId) {
  const configured = channelStore.getChannels();
  if (!configured.length) return { channels: [], notJoined: [], unavailable: [] };

  let botId = null;
  try {
    const me = await bot.getMe();
    botId = me?.id;
  } catch (e) {
    return {
      channels: [],
      notJoined: [],
      unavailable: configured.map(ch => ({ ch, reason: `Bot getMe gagal: ${e?.message || e}` })),
    };
  }

  const channels = [];
  const unavailable = [];

  for (const ch of configured) {
    try {
      const botMember = await bot.getChatMember(ch.username, botId);
      const botIsAdmin = ["administrator", "creator"].includes(String(botMember?.status || ""));
      if (!botIsAdmin) {
        unavailable.push({ ch, reason: `status bot: ${botMember?.status || "unknown"}` });
        await __notifyChannelNeedsAdmin(bot, ch, `Status bot saat ini: ${botMember?.status || "unknown"}.`);
        continue;
      }
      channels.push(ch);
    } catch (e) {
      unavailable.push({ ch, reason: e?.message || "getChatMember gagal" });
      await __notifyChannelNeedsAdmin(bot, ch, "Bot tidak dapat memverifikasi channel. Pastikan bot sudah menjadi Administrator.");
    }
  }

  const notJoined = [];
  for (const ch of channels) {
    try {
      const member = await bot.getChatMember(ch.username, userId);
      const status = String(member?.status || "");
      const joined =
        ["member", "administrator", "creator"].includes(status) ||
        (status === "restricted" && member?.is_member === true);

      if (!joined) notJoined.push(ch);
    } catch (e) {
      // Jika bot sudah admin tetapi status user gagal dibaca, jangan menganggap
      // user belum join. Laporkan ke owner dan jangan menampilkan channel secara
      // keliru sebagai "belum join".
      unavailable.push({ ch, reason: `Gagal cek user: ${e?.message || e}` });
    }
  }

  return { channels, notJoined, unavailable };
}

function __joinKeyboard(channels, userId) {
  const rows = channels.map(ch => {
    const url = __channelUrl(ch.username);
    return url ? [{ text: "JOIN CHANNEL ↗", url }] : [];
  }).filter(row => row.length);

  rows.push([{ text: "✅ CEK / VERIFY JOIN", callback_data: `create_verify_join:${userId}` }]);
  return { inline_keyboard: rows };
}

// ===== HELPERS =====
function nowWib() {
  return new Date().toLocaleString("id-ID", {
    timeZone: "Asia/Jakarta",
    day: "2-digit", month: "2-digit", year: "numeric",
    hour: "2-digit", minute: "2-digit", second: "2-digit",
  }).replace(/\./g, "/");
}

// ===== HEALTH CHECK =====
// Ping domain + test API key. Return { ok, domainReachable, apiResponsive, detail }.
async function checkPanelHealth(panel) {
  const r = { domainReachable: false, apiResponsive: false, detail: "" };
  if (!panel || !panel.domain || !panel.plta) {
    r.detail = "Belum dikonfigurasi";
    return r;
  }
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 8000);
    const res = await fetch(`${panel.domain}/api/application/servers?per_page=1`, {
      headers: { Accept: "application/json", Authorization: `Bearer ${panel.plta}` },
      signal: ctrl.signal,
    });
    clearTimeout(t);
    r.domainReachable = true;
    let json = null;
    try { json = await res.json(); } catch (_) {}
    if (!json) { r.detail = "Response bukan JSON valid"; return r; }
    if (json.errors) {
      r.detail = `API error: ${json.errors[0]?.detail || JSON.stringify(json.errors[0])}`;
      return r;
    }
    r.apiResponsive = true;
    r.detail = "OK";
  } catch (e) {
    r.detail = e.name === "AbortError" ? "Timeout (>8 detik)" : `fetch failed: ${e.message}`;
  }
  return r;
}

// ===== ERROR CARD (collapsible) =====
function buildErrorCard(serverLabel, health) {
  const dom = health.domainReachable ? "Terhubung" : "Tidak terhubung";
  const api = health.apiResponsive   ? "Merespons"  : "Tidak merespons";
  return (
    `<b>◇ SERVER PANEL TIDAK TERHUBUNG</b>\n\n` +
    `<blockquote expandable><b>∨ STATUS KONEKSI</b>\n\n` +
    `<b>Server</b>            : ${serverLabel}\n` +
    `<b>Domain Panel</b>   : ${dom}\n` +
    `<b>API Panel</b>       : ${api}\n` +
    `<b>Panel Dibuat</b>   : Tidak\n` +
    `<b>Detail</b>             : ${panelHtmlEscape(health.detail)}</blockquote>\n\n` +
    `<b>◈ CATATAN</b>\n` +
    `Jika gagal, cek VPS, Wings, domain, API, dan konfigurasi Egg/Location.`
  );
}

// Daftar versi panel "unli" yang didukung -- key harus cocok sama slot
// di db/panels.json (lihat src/data/panelStore.js -> PANEL_KEYS).
const PANEL_VERSIONS = [
  { key: "1", label: "Panel Unli", cmd: "unli" },
  ...Array.from({ length: 19 }, (_, i) => {
    const n = i + 2;
    return { key: String(n), label: `Panel Unli V${n}`, cmd: `unliv${n}` };
  }),
];


// ===== PREMIUM PANEL UI =====
// UI-only helpers: mempercantik pemilihan server/runtime tanpa mengubah alur create.
function panelUiEscape(value) {
  return String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

// Telegram HTML-safe escape for values inserted into dynamic messages.
function panelHtmlEscape(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/\"/g, "&quot;");
}

// Finalizer: provisioning must never remain visible after a successful API create.
async function finalizeCreateMessage({ bot, chatId, messageId, text, replyMarkup }) {
  // Prinsip: SATU kartu proses harus selalu berakhir menjadi kartu selesai.
  // Jangan membuat pesan baru kecuali kartu lama benar-benar tidak bisa diedit.
  const attempts = [
    { parse_mode: "HTML", reply_markup: replyMarkup },
    { parse_mode: "HTML" },
    {},
  ];
  let lastError = null;
  for (const opts of attempts) {
    try {
      await bot.editMessageText(text, { chat_id: chatId, message_id: messageId, ...opts });
      return true;
    } catch (err) {
      lastError = err;
      const desc = String(err?.response?.body?.description || err?.message || "");
      // Ini bukan error aplikasi: pesan memang sudah tidak ada / isinya sama.
      if (/message is not modified/i.test(desc)) return true;
      if (/message to edit not found|message can't be edited/i.test(desc)) break;
    }
  }

  // Jika kartu lama benar-benar tidak bisa diedit, hapus kartu provisioning.
  // Hanya setelah itu kirim kartu final agar tidak ada dua kartu bersamaan.
  let removed = false;
  try {
    await bot.deleteMessage(chatId, messageId);
    removed = true;
  } catch (err) {
    const desc = String(err?.response?.body?.description || err?.message || "");
    if (/message to delete not found/i.test(desc)) removed = true;
  }

  try {
    await bot.sendMessage(chatId, text, { parse_mode: "HTML", reply_markup });
    return true;
  } catch (err) {
    console.error("[panelCreate] final status send failed:", err?.message || err, "previous:", lastError?.message || lastError, "removed:", removed);
    return false;
  }
}

function panelStatusMark(ok, configured = true) {
  if (!configured) return "○";
  return ok ? "●" : "×";
}
function panelStatusLabel(ok, configured = true) {
  if (!configured) return "Belum diatur";
  return ok ? "ONLINE" : "OFFLINE";
}
function panelServerButton(label, key, ok) {
  return {
    text: `${ok ? "●" : "○"} ${label}`,
    callback_data: `unliserver_${key}`,
  };
}
function panelRuntimeText(versionInfo, username) {
  return (
    `<b>╭━━〔 RUNTIME PANEL 〕━━╮</b>\n` +
    `<blockquote expandable>` +
    `◈ <b>SERVER</b>\n` +
    `├ Name     : <b>${panelHtmlEscape(versionInfo.label)}</b>\n` +
    `├ Capacity : <b>Unlimited</b>\n` +
    `╰ Status   : <b>READY</b>` +
    `</blockquote>\n\n` +
    `<blockquote expandable>` +
    `◈ <b>ACCOUNT</b>\n` +
    `├ Username : <code>${panelHtmlEscape(username)}</code>\n` +
    `╰ Runtime  : <b>pilih salah satu di bawah</b>` +
    `</blockquote>\n\n` +
    `<i>Node.js cocok untuk bot/web JavaScript. Python cocok untuk aplikasi Python.</i>`
  );
}

function registerPanelCreateHandlers(bot, deps) {
  const { sendPanelToChannel, loadPanelRes, RESS_FILE, OWNER_UID } = deps;

  const createProcess = {};
  const pendingChoice = {}; // userId -> { version, chatId, username, targetId, msg, choiceMessageId, timeout }
  const CHOICE_TIMEOUT_MS = 2 * 60 * 1000; // 2 menit

  function versionByKey(key) {
    return PANEL_VERSIONS.find((v) => v.key === key);
  }

  // ===== TAHAP 1: /unliv2 ... /unliv20 (langsung ke panel tertentu) =====
  // /unli (V1) dihandle terpisah sebagai server picker di bawah.
  for (const version of PANEL_VERSIONS) {
    if (version.key === "1") continue; // handled by server picker
    const rx = new RegExp(`^\\/${version.cmd}(?:\\s+(.+))?$`, "i");

    bot.onText(rx, async (msg, match) => {
      const chatId = msg.chat.id;
      const userId = msg.from.id;
      const text = match[1] ? match[1].trim() : "";

      if (createProcess[userId]) {
        return;
      }
      createProcess[userId] = true;

      let targetUser = msg.from;
      if (msg.reply_to_message) targetUser = msg.reply_to_message.from;
      const firstName = targetUser.first_name || "User";

      try {
        // ----- Wajib join channel -----
        // Gunakan satu helper yang sama dengan /unli agar SEMUA versi
        // /unliv2 ... /unliv20 memiliki aturan identik:
        // - channel hanya aktif jika bot administrator/creator;
        // - channel yang sudah diikuti user tidak ditampilkan;
        // - restricted + is_member=true dihitung sudah join;
        // - channel yang gagal diverifikasi tidak dianggap belum join.
        const joinState = await __getJoinChannels(bot, userId);
        if (joinState.notJoined.length) {
          delete createProcess[userId];
          const list = joinState.notJoined.map((ch, i) => `${i + 1}. <b>${ch.username}</b>`).join("\n");
          return bot.sendMessage(
            chatId,
            `<blockquote expandable><b>LIANIX ACCESS</b>\n` +
            `<i>Akses fitur ini membutuhkan verifikasi channel.</i>\n\n` +
            `<b>CHANNEL WAJIB</b>\n${list}\n\n` +
            `<i>Channel yang sudah kamu join tidak akan ditampilkan lagi.</i></blockquote>`,
            {
              parse_mode: "HTML",
              reply_markup: __joinKeyboard(joinState.notJoined, userId),
            }
          );
        }

        const panelStatus = loadPanelRes();
        if (!panelStatus.status) {
          delete createProcess[userId];
          return bot.sendMessage(chatId, `<blockquote expandable>◈ <b>Create panel sedang dinonaktifkan.</b>\nHubungi admin untuk info lebih lanjut.</blockquote>`, { parse_mode: "HTML" });
        }

        // Fix: cek OWNER pakai ID numerik asli (settings.ownerId), bukan
        // path file (bug lama -- pengecualian owner sebelumnya gak pernah kena).
        if (msg.chat.type !== "group" && msg.chat.type !== "supergroup" && userId !== OWNER_UID) {
          delete createProcess[userId];
          return bot.sendMessage(chatId, `<blockquote expandable>◈ <b>Khusus Grup</b>\nFitur ini hanya bisa dipakai di dalam grup.</blockquote>`, { parse_mode: "HTML" });
        }

        // 🎨 UI AKSES TERBATAS #1 — ubah teks kartu akses reseller di blok berikut.
      // 🎨 UI AKSES TERBATAS #2 — blok kedua untuk flow /unli.
      const ressUsers = JSON.parse(fs.readFileSync(RESS_FILE));
        if (!roleAccess.hasActiveRole("reseller", userId)) {
          delete createProcess[userId];
          return bot.sendMessage(chatId, roleAccess.restrictedResellerText(), {
            parse_mode: "HTML",
            reply_markup: roleAccess.restrictedResellerKeyboard(),
          });
        }

        if (!text) {
          delete createProcess[userId];
          return bot.sendMessage(chatId, `<blockquote expandable>◈ <b>Format Perintah</b>\n/${version.cmd} namapanel\n/${version.cmd} namapanel,idtele</blockquote>`, { parse_mode: "HTML" });
        }

        let [username, targetIdRaw] = text.split(",");
        username = username.trim();
        const targetId = targetIdRaw ? parseInt(targetIdRaw.trim()) : targetUser.id;

        if (!username) {
          delete createProcess[userId];
          return bot.sendMessage(chatId, "<blockquote expandable>◈ <b>Input Tidak Valid</b>\nUsername tidak boleh kosong.</blockquote>");
        }

        try {
          const targetChat = await bot.getChat(targetId);
          if (!targetChat) throw new Error("chat not found");
        } catch {
          delete createProcess[userId];
          return bot.sendMessage(chatId, `<blockquote expandable>◇ <b>Belum Start Bot</b>\n${msg.reply_to_message ? firstName : "Kamu"} belum start bot di private chat.</blockquote>`, { parse_mode: "HTML" });
        }

        // ----- Health check panel sebelum lanjut -----
        const currentPanel = panelStore.getPanel(version.key);
        const loadMsg = await safeReply(bot, chatId, `↻ <i>Mengecek koneksi ${version.label}…</i>`, {
          reply_to_message_id: msg.message_id,
        });
        const health = await checkPanelHealth(currentPanel);
        if (!health.apiResponsive) {
          delete createProcess[userId];
          return bot.editMessageText(buildErrorCard(version.label, health), {
            chat_id: chatId,
            message_id: loadMsg.message_id,
            parse_mode: "HTML",
          });
        }
        await bot.deleteMessage(chatId, loadMsg.message_id).catch(() => {});

        const choiceMsg = await safeReply(bot, 
          chatId,
          `<b>╭─〔 CREATE PANEL 〕─╮</b>\n` +
          `<blockquote expandable>` +
          `<b>Server</b>     : ${version.label}\n` +
          `<b>Username</b>   : <code>${username}</code>\n` +
          `<b>Resources</b>  : Unlimited RAM • Disk • CPU\n` +
          `\n` +
          `<b>Runtime</b>     : pilih salah satu di bawah` +
          `</blockquote>`,
          {
            parse_mode: "HTML",
            reply_to_message_id: msg.message_id,
            reply_markup: {
              inline_keyboard: [
                [{ text: "〔 Node.js 〕", callback_data: "unlitype_node" }, { text: "〔 Python 〕", callback_data: "unlitype_python" }],
                [{ text: "〔 × Batal 〕", callback_data: "unlitype_cancel" }],
              ],
            },
          }
        );

        if (pendingChoice[userId] && pendingChoice[userId].timeout) {
          clearTimeout(pendingChoice[userId].timeout);
        }

        const timeout = setTimeout(async () => {
          if (!pendingChoice[userId]) return;
          delete pendingChoice[userId];
          delete createProcess[userId];
          try {
            await bot.editMessageText("<blockquote expandable>◇ <b>Waktu Habis</b>\nWaktu pilih runtime habis, proses dibatalkan otomatis.</blockquote>", {
              chat_id: chatId,
              message_id: choiceMsg.message_id,
            });
          } catch {}
        }, CHOICE_TIMEOUT_MS);

        pendingChoice[userId] = {
          version: version.key,
          chatId,
          username,
          targetId,
          msg,
          choiceMessageId: choiceMsg.message_id,
          timeout,
        };
      } catch (err) {
        delete createProcess[userId];
        console.error(`[${version.cmd}] Error di tahap awal:`, err.message);
        return bot.sendMessage(chatId, `<blockquote expandable>◇ <b>Terjadi Kesalahan</b>\n${panelHtmlEscape(err.message)}</blockquote>`, { parse_mode: "HTML" });
      }
    });
  }

  // ===== /unli — SERVER PICKER: cek semua panel, tampilkan yang aktif =====
  const pendingServerChoice = {}; // userId -> { username, targetId, msg, loadingMsgId, chatId }
  const pendingAccountChoice = {}; // userId -> selected server + account selection state

  function existingAccountsFor(panelVersion, targetId) {
    const rows = panelLog.getAll().filter(e =>
      String(e.panelVersion) === String(panelVersion) &&
      String(e.targetTgId || e.creatorTgId) === String(targetId) &&
      e.ptUserId
    );
    const uniq = new Map();
    for (const e of rows) if (!uniq.has(String(e.ptUserId))) uniq.set(String(e.ptUserId), e);
    return [...uniq.values()].slice(0, 8);
  }

  async function showRuntimeForAccount(q, pending, versionInfo, existingPtUserId = null) {
    const userId = String(q.from.id);
    const accountText = existingPtUserId
      ? `\n├ Akun     : <b>Akun lama #${panelHtmlEscape(existingPtUserId)}</b>`
      : `\n├ Akun     : <b>Akun baru</b>`;
    const choiceMsg = await bot.editMessageText(
      `<b>╭━━〔 CREATE PANEL 〕━━╮</b>\n` +
      `<blockquote expandable>◈ <b>TUJUAN</b>\n` +
      `├ Server   : <b>${panelHtmlEscape(versionInfo.label)}</b>\n` +
      `├ Nama     : <code>${panelHtmlEscape(pending.username)}</code>${accountText}\n` +
      `╰ Runtime  : <b>pilih di bawah</b></blockquote>`,
      { chat_id:q.message.chat.id, message_id:q.message.message_id, parse_mode:'HTML', reply_markup:{inline_keyboard:[
        [{text:'Node.js',callback_data:'unlitype_node'},{text:'Python',callback_data:'unlitype_python'}],
        [{text:'‹‹‹',callback_data:'unliaccount_back'},{text:'Batal',callback_data:'unlitype_cancel'}]
      ]}}
    );
    if (pendingChoice[userId]?.timeout) clearTimeout(pendingChoice[userId].timeout);
    const timeout=setTimeout(()=>{ delete pendingChoice[userId]; delete pendingAccountChoice[userId]; delete createProcess[userId]; }, CHOICE_TIMEOUT_MS);
    pendingChoice[userId]={ version:versionInfo.key, chatId:pending.chatId, username:pending.username, targetId:pending.targetId, msg:pending.msg, choiceMessageId:choiceMsg.message_id, existingPtUserId, timeout };
  }

  async function showAccountMode(q, pending, versionInfo) {
    const userId=String(q.from.id);
    const accounts=existingAccountsFor(versionInfo.key, pending.targetId);
    pendingAccountChoice[userId]={...pending, version:versionInfo.key, accounts};
    if (!accounts.length) return showRuntimeForAccount(q,pending,versionInfo,null);
    return bot.editMessageText(
      `<b>╭━━〔 PILIH AKUN TUJUAN 〕━━╮</b>\n`+
      `<blockquote expandable>Server : <b>${panelHtmlEscape(versionInfo.label)}</b>\nNama server baru : <code>${panelHtmlEscape(pending.username)}</code>\n\n`+
      `User ini sudah memiliki <b>${accounts.length}</b> akun panel yang dikenali pada server ini.\n`+
      `<b>Tambahkan ke Akun</b> = server baru masuk ke login lama.\n`+
      `<b>Akun Baru</b> = buat login Pterodactyl baru.</blockquote>`,
      {chat_id:q.message.chat.id,message_id:q.message.message_id,parse_mode:'HTML',reply_markup:{inline_keyboard:[
        [{text:'Tambahkan ke Akun',callback_data:'unliaccount_add'},{text:'Akun Baru',callback_data:'unliaccount_new'}],
        [{text:'‹‹‹',callback_data:'unliaccount_back_server'}]
      ]}}
    );
  }

  bot.onText(/^\/unli(?:\s+(.+))?$/, async (msg, match) => {
    const chatId = msg.chat.id;
      if (featureLocks.isUnliLocked() && String(msg.from?.id) !== String(OWNER_UID)) {
        return bot.sendMessage(chatId, "<blockquote expandable>🔒 <b>CREATE UNLI SEDANG DI-LOCK</b>\n\nAdmin sedang menutup akses Unlimited Panel. Silakan coba lagi nanti.</blockquote>", { parse_mode: "HTML" });
      }

    const userId = msg.from.id;
    const text   = match[1] ? match[1].trim() : "";

    if (createProcess[userId]) {
      return;
    }
    createProcess[userId] = true;

    let targetUser = msg.from;
    if (msg.reply_to_message) targetUser = msg.reply_to_message.from;
    const firstName = targetUser.first_name || "User";

    try {
      // Wajib join:
      // 1) channel hanya ditampilkan jika BOT adalah admin/creator;
      // 2) channel yang user sudah join tidak ditampilkan;
      // 3) setelah semua channel terverifikasi, keyboard verify dihapus.
      const joinState = await __getJoinChannels(bot, userId);
      if (joinState.notJoined.length) {
        delete createProcess[userId];
        const list = joinState.notJoined.map((ch, i) => `${i + 1}. <b>${ch.username}</b>`).join("\n");
        return bot.sendMessage(chatId,
          `<blockquote expandable><b>LIANIX ACCESS</b>\n` +
          `<i>Verifikasi channel diperlukan sebelum fitur dapat digunakan.</i>\n\n` +
          `<b>CHANNEL WAJIB</b>\n${list}\n\n` +
          `<i>Channel yang sudah kamu join tidak akan ditampilkan lagi.</i></blockquote>`,
          {
            parse_mode: "HTML",
            reply_markup: __joinKeyboard(joinState.notJoined, userId),
          }
        );
      }

      const panelStatus = loadPanelRes();
      if (!panelStatus.status) {
        delete createProcess[userId];
        return bot.sendMessage(chatId, `<blockquote expandable>◈ <b>Create panel sedang dinonaktifkan.</b>\nHubungi admin untuk info lebih lanjut.</blockquote>`, { parse_mode: "HTML" });
      }

      if (msg.chat.type !== "group" && msg.chat.type !== "supergroup" && userId !== OWNER_UID) {
        delete createProcess[userId];
        return bot.sendMessage(chatId, `<blockquote expandable>◈ <b>Khusus Grup</b>\nFitur ini hanya bisa dipakai di dalam grup.</blockquote>`, { parse_mode: "HTML" });
      }

      const ressUsers = JSON.parse(fs.readFileSync(RESS_FILE));
      if (!roleAccess.hasActiveRole("reseller", userId)) {
        delete createProcess[userId];
        return bot.sendMessage(chatId, roleAccess.restrictedResellerText(), {
          parse_mode: "HTML",
          reply_markup: roleAccess.restrictedResellerKeyboard(),
        });
      }

      if (!text) {
        delete createProcess[userId];
        return bot.sendMessage(chatId,
          `<blockquote expandable><b>CREATE PANEL • PANDUAN</b>\n\n` +
          `<b>Format:</b>\n<code>/unli namaserver</code>\n<code>/unli namaserver,idtelegram</code>\n\n` +
          `<b>Nama server</b> adalah nama panel/server yang ingin dibuat, contoh <code>yunbotku</code>.\n` +
          `<b>ID Telegram</b> opsional; isi jika panel dibuat untuk orang lain. User target harus sudah /start bot.\n\n` +
          `<b>Alur:</b>\n1. Bot mengecek server panel yang online.\n2. Pilih server tujuan.\n3. Jika user sudah punya akun di server itu, pilih <b>Tambahkan ke Akun</b> atau <b>Akun Baru</b>.\n4. Pilih runtime Node.js/Python.\n5. Bot membuat server dan mengubah kartu proses yang sama menjadi hasil akhir.\n\n` +
          `<i>Contoh: <code>/unli yunbotku</code></i></blockquote>`,
          { parse_mode: "HTML" });
      }

      let [username, targetIdRaw] = text.split(",");
      username = username.trim();
      const targetId = targetIdRaw ? parseInt(targetIdRaw.trim()) : targetUser.id;

      if (!username) {
        delete createProcess[userId];
        return bot.sendMessage(chatId, "<blockquote expandable>◈ <b>Input Tidak Valid</b>\nUsername tidak boleh kosong.</blockquote>");
      }

      try {
        const targetChat = await bot.getChat(targetId);
        if (!targetChat) throw new Error("chat not found");
      } catch {
        delete createProcess[userId];
        return bot.sendMessage(chatId, `<blockquote expandable>◇ <b>Belum Start Bot</b>\n${msg.reply_to_message ? firstName : "Kamu"} belum start bot di private chat.</blockquote>`, { parse_mode: "HTML" });
      }

      // ----- Cek semua panel secara paralel -----
      const loadMsg = await safeReply(bot, chatId, "↻ Mengecek koneksi semua server panel...", {
        reply_to_message_id: msg.message_id,
      });

      const checks = await Promise.all(
        PANEL_VERSIONS.map(async (v) => {
          const panel = panelStore.getPanel(v.key);
          if (!panel.domain || !panel.plta) return { v, ok: false, configured: false, health: { domainReachable: false, apiResponsive: false, detail: "Belum dikonfigurasi" } };
          const health = await checkPanelHealth(panel);
          return { v, ok: health.apiResponsive, configured: true, health };
        })
      );

      const connected = checks.filter(c => c.ok);
      const failedConfigured = checks.filter(c => !c.ok && c.configured);

      if (connected.length === 0) {
        delete createProcess[userId];
        // Tampilkan error semua server
        const errText =
          `<b>◇ SEMUA SERVER PANEL TIDAK TERHUBUNG</b>\n\n` +
          failedConfigured.map(c =>
            `<blockquote expandable><b>∨ ${c.v.label}</b>\n` +
            `<b>Domain Panel</b>  : ${c.health.domainReachable ? "Terhubung" : "Tidak terhubung"}\n` +
            `<b>API Panel</b>     : ${c.health.apiResponsive ? "Merespons" : "Tidak merespons"}\n` +
            `<b>Detail</b>          : ${panelHtmlEscape(c.health.detail)}</blockquote>`
          ).join("\n") +
          `\n\n<b>◈ CATATAN</b>\nJika gagal, cek VPS, Wings, domain, API, dan konfigurasi Egg/Location.`;
        return bot.editMessageText(errText, {
          chat_id: chatId, message_id: loadMsg.message_id, parse_mode: "HTML",
        });
      }

      // Jika proses berasal dari My Panel, server/mode sudah dipilih sebelumnya.
      const prefMap = global.__LIANIX_UNLI_PREFERRED_SERVER__;
      const pref = prefMap instanceof Map ? prefMap.get(String(userId)) : null;
      if (pref && pref.expires > Date.now()) {
        const chosen = connected.find(c => String(c.v.key) === String(pref.version));
        if (chosen) {
          prefMap.delete(String(userId));
          const pending={username,targetId,msg,chatId,loadingMsgId:loadMsg.message_id};
          const fakeQ={from:msg.from,message:{chat:{id:chatId},message_id:loadMsg.message_id}};
          if (pref.mode === 'new') return showRuntimeForAccount(fakeQ,pending,chosen.v,null);
          return showAccountMode(fakeQ,pending,chosen.v);
        }
        prefMap.delete(String(userId));
      }

      // ----- Tampilkan server picker -----
      const roleLabel = roleAccess.hasActiveRole("reseller", userId) ? "RESELLER" : "USER";
      const serverList = connected.map(c => c.v.label).join(", ");

      const pickerText =
        `<b>╭━━〔 CREATE PANEL 〕━━╮</b>\n` +
        `<blockquote expandable>` +
        `◈ <b>REQUEST</b>\n` +
        `├ Username : <code>${panelHtmlEscape(username)}</code>\n` +
        `├ Package  : <b>Unlimited</b>\n` +
        `╰ Role     : <b>${roleLabel}</b>` +
        `</blockquote>\n\n` +
        `<b>◈ SERVER SELECTION</b>\n` +
        `<i>Pilih node panel yang akan menerima server baru.</i>\n\n` +
        `<blockquote expandable>` +
        connected.map(c => `${panelStatusMark(c.ok, c.configured)} <b>${panelUiEscape(c.v.label)}</b> — ${panelStatusLabel(c.ok, c.configured)}`).join("\n") +
        `</blockquote>` +
        (failedConfigured.length
          ? `\n<b>⚠ SERVER ISSUE</b>\n<blockquote expandable>${failedConfigured.map(c => `× <b>${panelUiEscape(c.v.label)}</b> — ${panelUiEscape(c.health.detail)}`).join("\n")}</blockquote>`
          : "") +
        `\n\n<i>Server yang offline tidak bisa dipilih.</i>`;

      const serverButtons = connected.map(c => panelServerButton(c.v.label, c.v.key, c.ok));
      const keyboard = [];
      for (let i = 0; i < serverButtons.length; i += 2) keyboard.push(serverButtons.slice(i, i + 2));
      keyboard.push([{ text: "‹‹‹", callback_data: "unliserver_cancel" }]);

      await bot.editMessageText(pickerText, {
        chat_id: chatId,
        message_id: loadMsg.message_id,
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: keyboard },
      });

      pendingServerChoice[String(userId)] = {
        username, targetId, msg, chatId,
        loadingMsgId: loadMsg.message_id,
      };

    } catch (err) {
      delete createProcess[userId];
      console.error("[unli] Error picker:", err.message);
      return bot.sendMessage(chatId, `<blockquote expandable>◇ <b>Terjadi Kesalahan</b>\n${panelHtmlEscape(err.message)}</blockquote>`, { parse_mode: "HTML" });
    }
  });

  // ===== CALLBACK: CEK / VERIFY WAJIB JOIN =====
  bot.on("callback_query", async (q) => {
    const data = String(q.data || "");
    if (!data.startsWith("create_verify_join:")) return;

    const targetId = data.split(":")[1];
    if (String(q.from.id) !== String(targetId)) {
      return bot.answerCallbackQuery(q.id, { text: "❌ Tombol ini bukan untukmu.", show_alert: true });
    }

    try {
      const joinState = await __getJoinChannels(bot, q.from.id);

      if (joinState.notJoined.length) {
        await bot.answerCallbackQuery(q.id, {
          text: `❌ Masih belum join ${joinState.notJoined.length} channel.`,
          show_alert: true,
        });

        const markup = __joinKeyboard(joinState.notJoined, targetId);
        try {
          await bot.editMessageReplyMarkup(markup, {
            chat_id: q.message.chat.id,
            message_id: q.message.message_id,
          });
        } catch (_) {
          // Jika pesan/markup sudah berubah, kirim kartu verifikasi baru agar
          // tombol tetap tersedia dan tidak membuat callback terlihat macet.
          try {
            await bot.sendMessage(
              q.message.chat.id,
              `<blockquote expandable><b>CHANNEL MASIH BELUM LENGKAP</b>\n\n` +
              `${joinState.notJoined.map((ch, i) => `${i + 1}. <b>${ch.username}</b>`).join("\n")}\n\n` +
              `<i>Join channel yang tersisa lalu tekan Verify lagi.</i></blockquote>`,
              { parse_mode: "HTML", reply_markup: markup }
            );
          } catch (_) {}
        }
        return;
      }

      await bot.answerCallbackQuery(q.id, {
        text: "✅ Semua channel sudah terverifikasi!",
        show_alert: true,
      });

      // Semua sudah join: hapus seluruh tombol dari pesan lama.
      // Jangan sisakan tombol VERIFY yang membuat user mengira masih belum join.
      try {
        await bot.editMessageReplyMarkup(
          { inline_keyboard: [] },
          { chat_id: q.message.chat.id, message_id: q.message.message_id }
        );
      } catch (_) {}

      try {
        await bot.editMessageText(
          "<blockquote expandable>✅ <b>JOIN TERVERIFIKASI</b>\n\n" +
          "Semua channel wajib sudah kamu ikuti.\n" +
          "Silakan ulangi perintah sebelumnya.</blockquote>",
          {
            chat_id: q.message.chat.id,
            message_id: q.message.message_id,
            parse_mode: "HTML",
          }
        );
      } catch (_) {
        // Fallback jika pesan awal berupa caption.
        try {
          await bot.editMessageCaption(
            "<blockquote expandable>✅ <b>JOIN TERVERIFIKASI</b>\n\n" +
            "Semua channel wajib sudah kamu ikuti.\n" +
            "Silakan ulangi perintah sebelumnya.</blockquote>",
            {
              chat_id: q.message.chat.id,
              message_id: q.message.message_id,
              parse_mode: "HTML",
            }
          );
        } catch (_) {}
      }
    } catch (e) {
      console.error("[join-verify] Error:", e);
      return bot.answerCallbackQuery(q.id, {
        text: "❌ Gagal mengecek status join. Coba lagi.",
        show_alert: true,
      }).catch(() => {});
    }
  });

  // ===== CALLBACK: pilih server dari picker =====
  bot.on("callback_query", async (q) => {
    if (!q.data || !q.data.startsWith("unliserver_")) return;
    const action = q.data.slice("unliserver_".length);
    const userId = String(q.from.id);
    const pending = pendingServerChoice[userId];

    if (!pending) {
      return bot.answerCallbackQuery(q.id, { text: "◈ Session expired. Ketik /unli lagi.", show_alert: true });
    }
    if (String(q.from.id) !== String(pending.msg.from.id)) {
      return bot.answerCallbackQuery(q.id, { text: "◈ Ini bukan proses kamu.", show_alert: true });
    }

    delete pendingServerChoice[userId];

    if (action === "cancel") {
      delete createProcess[userId];
      await bot.answerCallbackQuery(q.id);
      return bot.editMessageText("<blockquote expandable>◇ <b>Dibatalkan</b>\nProses telah dibatalkan.</blockquote>", {
        chat_id: q.message.chat.id, message_id: q.message.message_id,
      });
    }

    if (action === "back") {
      // Kembalikan user ke daftar server yang aktif dengan menjalankan picker ulang.
      delete createProcess[userId];
      await bot.answerCallbackQuery(q.id, { text: "Memuat daftar server…" });
      return bot.editMessageText(
        `<blockquote expandable><b>↻ SERVER PICKER</b>\nSilakan ketik <code>/unli ${panelUiEscape(pending.username)}</code> untuk memilih server lagi.</blockquote>`,
        { chat_id: q.message.chat.id, message_id: q.message.message_id, parse_mode: "HTML" }
      );
    }

    const versionInfo = versionByKey(action);
    if (!versionInfo) {
      delete createProcess[userId];
      return bot.answerCallbackQuery(q.id, { text: "◇ Server tidak dikenali.", show_alert: true });
    }

    await bot.answerCallbackQuery(q.id, { text: `${versionInfo.label} dipilih` });
    return showAccountMode(q, pending, versionInfo);
  });

  bot.on("callback_query", async (q) => {
    const d=String(q.data||'');
    if (!d.startsWith('unliaccount_')) return;
    const uid=String(q.from.id);
    const pnd=pendingAccountChoice[uid];
    if (!pnd) return bot.answerCallbackQuery(q.id,{text:'Session expired. Ketik /unli lagi.',show_alert:true}).catch(()=>{});
    const v=versionByKey(pnd.version);
    if (!v) return;
    await bot.answerCallbackQuery(q.id).catch(()=>{});
    if (d==='unliaccount_new') return showRuntimeForAccount(q,pnd,v,null);
    if (d==='unliaccount_add') {
      const allLogs=panelLog.getAll(); const rows=pnd.accounts.map((a)=>{ const count=allLogs.filter(x=>String(x.panelVersion)===String(pnd.version)&&String(x.ptUserId)===String(a.ptUserId)).length||1; return [{text:`${a.panelEmail || ('Akun #'+a.ptUserId)} • ${count} panel`,callback_data:`unliaccount_use:${a.ptUserId}`}]; });
      rows.push([{text:'‹‹‹',callback_data:'unliaccount_back'}]);
      return bot.editMessageText(`<b>╭━━〔 PILIH AKUN TUJUAN 〕━━╮</b>\n<blockquote expandable>Pilih login Pterodactyl yang akan menerima server <code>${panelHtmlEscape(pnd.username)}</code>.\nServer baru akan muncul bersama server lama di akun yang sama.</blockquote>`,{chat_id:q.message.chat.id,message_id:q.message.message_id,parse_mode:'HTML',reply_markup:{inline_keyboard:rows}});
    }
    if (d.startsWith('unliaccount_use:')) {
      const id=d.split(':')[1];
      if (!pnd.accounts.some(a=>String(a.ptUserId)===String(id))) return bot.answerCallbackQuery(q.id,{text:'Akun tidak valid.',show_alert:true});
      return showRuntimeForAccount(q,pnd,v,Number(id));
    }
    if (d==='unliaccount_back') return showAccountMode(q,pnd,v);
    if (d==='unliaccount_back_server') {
      delete pendingAccountChoice[uid]; delete createProcess[uid];
      return bot.editMessageText(`<blockquote expandable><b>KEMBALI KE SERVER</b>\nKetik ulang <code>/unli ${panelHtmlEscape(pnd.username)}</code> untuk memilih server lain.</blockquote>`,{chat_id:q.message.chat.id,message_id:q.message.message_id,parse_mode:'HTML'});
    }
  });

  async function runCreate(runtime, ctx) {
    const { chatId, username, targetId, msg, choiceMessageId, version, existingPtUserId = null } = ctx;
    const userId = msg.from.id;
    const versionInfo = versionByKey(version);
    const currentPanel = panelStore.getPanel(version);
    // Jamin kartu provisioning selalu punya terminal state. Jika ada return/throw
    // dari jalur mana pun, finally akan menutup kartu yang masih berstatus proses.
    let provisioningFinalized = false;
    let finalStateText = null;
    let finalStateMarkup = { inline_keyboard: [] };

    const finishProvisioning = async (text, markup = { inline_keyboard: [] }) => {
      if (provisioningFinalized) return;
      provisioningFinalized = true;
      finalStateText = text;
      finalStateMarkup = markup;
      try {
        await finalizeCreateMessage({
          bot, chatId, messageId: choiceMessageId, text, replyMarkup: markup
        });
      } catch (e) {
        console.warn(`[${version}] finalisasi kartu provisioning gagal:`, e?.message || e);
      }
    };

    try {
      const isPython = runtime === "python";

      // Setelah runtime dipilih, tampilkan indikator sederhana dulu.
      // Kartu yang sama baru diganti menjadi HASIL BERHASIL/GAGAL ketika proses selesai.
      await bot.editMessageText("⏳", {
        chat_id: chatId, message_id: choiceMessageId
      }).catch(() => {});

      let egg = isPython
        ? (currentPanel.eggsPython || settings.eggsPython || "22")
        : (currentPanel.eggs      || settings.eggs       || "20");
      if (ownerFeatures.isAutoEgg()) {
        try {
          const detectedEgg = await ownerFeatures.resolveAutoEgg(currentPanel, isPython ? "python" : "node");
          if (detectedEgg) egg = detectedEgg;
        } catch (autoEggErr) {
          console.warn("[AutoEgg] gagal membaca Egg otomatis:", autoEggErr.message);
        }
      }

      // Validasi dasar egg ID sebelum lanjut
      if (!egg || isNaN(parseInt(egg)) || parseInt(egg) <= 0) {
        await bot.editMessageText(
          `<blockquote expandable>◈ <b>Konfigurasi Panel Bermasalah</b>\nEgg ID belum disetel atau tidak valid.\n\nSolusi: Owner perlu atur Egg ID di menu Dev Panel → Pengaturan Panel lalu coba lagi.</blockquote>`,
          { chat_id: chatId, message_id: choiceMessageId, parse_mode: "HTML" }
        );
        delete createProcess[userId];
        return;
      }
      const loc = settings.loc;
      const startAlloc = settings.allocation;

      // Pterodactyl mewajibkan docker_image saat membuat server.
      // Sebelumnya settings.dockerImagePython belum didefinisikan sehingga
      // JSON mengirim nilai undefined dan API membalas "The docker image field is required."
      const dockerImage = isPython
        ? (settings.dockerImagePython || process.env.PYTHON_DOCKER_IMAGE || "ghcr.io/parkervcp/yolks:python_3.12")
        : "ghcr.io/parkervcp/yolks:nodejs_20";

      if (!dockerImage || typeof dockerImage !== "string" || !dockerImage.trim()) {
        await finishProvisioning(`<blockquote expandable>◈ <b>CREATE PANEL GAGAL</b>\nDocker image untuk runtime ${isPython ? "Python" : "Node.js"} belum disetel.</blockquote>`);
        delete createProcess[userId];
        return;
      }

      const startupNode =
        'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
      const startupPython =
        'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ -f /home/container/requirements.txt ]]; then pip install --user -r requirements.txt; fi; python3 ${PY_FILE}';
      const startup = isPython ? startupPython : startupNode;

      const environment = isPython
        ? { PY_FILE: "main.py", REQUIREMENTS_FILE: "requirements.txt", USER_UPLOAD: "1", AUTO_UPDATE: "0" }
        : { INST: "npm", USER_UPLOAD: "0", AUTO_UPDATE: "0", CMD_RUN: "npm start" };

      let portRange = [];
      if (startAlloc && !isNaN(startAlloc)) {
        const start = parseInt(startAlloc);
        portRange = [`${start}-${start}`];
      }

      let finalUsername = username;
      let attempt = 0;
      let isCreated = false;

      while (!isCreated && attempt < 10) {
        let email = `${finalUsername}@gmail.com`;
        let password = finalUsername + Math.random().toString(36).slice(2, 5);
        let user = null;

        if (existingPtUserId) {
          const ur = await fetch(`${currentPanel.domain}/api/application/users/${existingPtUserId}`, { headers:{Accept:'application/json',Authorization:`Bearer ${currentPanel.plta}`} });
          const uj = await ur.json().catch(()=>({}));
          if (!ur.ok || uj.errors || !uj.attributes) {
            await finishProvisioning(`<blockquote expandable><b>CREATE PANEL GAGAL</b>\nAkun tujuan #${panelHtmlEscape(existingPtUserId)} sudah tidak tersedia pada server panel. Pilih Akun Baru atau ulangi proses.</blockquote>`);
            return;
          }
          user=uj.attributes; email=user.email || email; password=null;
        }

        const response = existingPtUserId ? null : await fetch(`${currentPanel.domain}/api/application/users`, {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: `Bearer ${currentPanel.plta}`,
          },
          body: JSON.stringify({
            email,
            username: finalUsername,
            first_name: finalUsername,
            last_name: finalUsername,
            language: "en",
            password,
          }),
        });

        const data = existingPtUserId ? { attributes:user } : await response.json();

        if (!existingPtUserId && data.errors) {
          const errStr = JSON.stringify(data.errors).toLowerCase();
          if (errStr.includes("unique") || errStr.includes("username")) {
            finalUsername += finalUsername.slice(-1);
            attempt++;
            continue;
          }
          await finishProvisioning(`<blockquote expandable>◈ <b>CREATE PANEL GAGAL</b>\nGagal membuat akun panel.\n${panelHtmlEscape(data.errors[0].detail || data.errors[0].code || "Terjadi kesalahan pada pembuatan akun.")}</blockquote>`);
          delete createProcess[userId];
          return;
        }

        user = data.attributes;

        const response2 = await fetch(`${panelHtmlEscape(currentPanel.domain)}/api/application/servers`, {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: `Bearer ${currentPanel.plta}`,
          },
          body: JSON.stringify({
            name: finalUsername + "unli",
            description: "",
            user: user.id,
            egg: parseInt(egg),
            docker_image: dockerImage.trim(),
            startup,
            environment,
            limits: { memory: 0, swap: 0, disk: 0, io: 500, cpu: 0 },
            feature_limits: { databases: 5, backups: 5, allocations: 1 },
            deploy: { locations: [parseInt(loc)], dedicated_ip: false, port_range: portRange },
          }),
        });

        const data2 = await response2.json();

        if (data2.errors) {
          const err2    = data2.errors[0] || {};
          const field2  = (err2.meta && err2.meta.source_field) ? err2.meta.source_field : '';
          const detail2 = err2.detail || err2.code || 'Terjadi kesalahan tidak dikenal.';
          let errMsg2;
          if (field2 === 'egg' || detail2.toLowerCase().includes('egg')) {
            errMsg2 = `<blockquote expandable>◈ <b>Gagal Membuat Server</b>\nEgg ID tidak valid di panel ini.\n\nSolusi: Owner perlu setel ulang Egg ID yang benar melalui menu Dev Panel → Pengaturan Panel.</blockquote>`;
          } else if (field2 === 'location' || detail2.toLowerCase().includes('location')) {
            errMsg2 = `<blockquote expandable>◈ <b>Gagal Membuat Server</b>\nLocation ID tidak ditemukan di panel.\n\nSolusi: Hubungi owner untuk cek pengaturan Location ID.</blockquote>`;
          } else {
            errMsg2 = `<blockquote expandable>◈ <b>Gagal Membuat Server</b>\n${detail2}</blockquote>`;
          }
          // Jangan pernah meninggalkan kartu CREATING PANEL setelah API gagal.
          await finishProvisioning(panelHtmlEscape(detail2).toLowerCase().includes('egg') || field2 === 'egg'
            ? `<blockquote expandable>◈ <b>CREATE PANEL GAGAL</b>\nEgg ID tidak valid di panel ini.</blockquote>`
            : field2 === 'location' || panelHtmlEscape(detail2).toLowerCase().includes('location')
              ? `<blockquote expandable>◈ <b>CREATE PANEL GAGAL</b>\nLocation ID tidak ditemukan di panel.</blockquote>`
              : `<blockquote expandable>◈ <b>CREATE PANEL GAGAL</b>\n${panelHtmlEscape(detail2)}</blockquote>`);
          delete createProcess[userId];
          return;
        }

        const server = data2.attributes;
        isCreated = true;
        const runtimeLabel = isPython ? "Python" : "Node.js";

        // SERVER SUDAH BERHASIL DIBUAT. Lepaskan lock/proses UI SEKARANG,
        // jangan menunggu DM, logging, atau pengiriman channel. Sebelumnya
        // createProcess baru dibersihkan di akhir runCreate sehingga ketika
        // DM/channel lambat, user masih melihat "proses berjalan".
        if (pendingChoice[userId]?.timeout) {
          clearTimeout(pendingChoice[userId].timeout);
        }
        delete pendingChoice[userId];
        delete createProcess[userId];

        // IMPORTANT: terminal state dipasang SEGERA setelah Pterodactyl sukses.
        await finishProvisioning(
          `<blockquote expandable>` +
          `<b>LIANIX CPANEL</b>\n` +
          `◈ <b>CREATE PANEL BERHASIL</b>\n` +
          `◈ <b>Server :</b> ${panelHtmlEscape(versionInfo.label)}\n` +
          `◈ <b>Runtime :</b> ${runtimeLabel}\n` +
          `◈ <b>Nama :</b> <code>${panelHtmlEscape(finalUsername)}</code>\n` +
          `◈ <b>Akun :</b> <b>${existingPtUserId ? "Ditambahkan ke akun lama" : "Akun baru"}</b>\n` +
          `◈ <b>Status :</b> <b>Panel sudah dibuat</b>\n` +
          `◈ <b>Proses :</b> <b>SELESAI</b>` +
          `</blockquote>`,
          { inline_keyboard: [] }
        );

        // ── Catat log pembuat panel ──
        try {
          const identifier = server.identifier || (server.uuid || "").split("-")[0];
          if (identifier) {
            panelLog.save({
              identifier,
              ptServerId:        server.id,
              ptUserId:          user.id,
              serverName:        server.name,
              panelEmail:        email,
              panelVersion:      version,
              runtime:           runtimeLabel,
              domain:            currentPanel.domain,
              creatorTgId:       msg.from.id,
              creatorTgUsername: msg.from.username ? `@${msg.from.username}` : "",
              creatorTgName:     msg.from.first_name || "",
              targetTgId:        targetId,
            });
          }
        } catch (logErr) {
          console.error("[panelLog] Gagal simpan:", logErr.message);
        }

        // ----- Kartu LENGKAP ke DM target dulu, baru grup -----
        const creatorRole = getUserRoleLabel(userId);
        const tgName   = msg.from.first_name || "User";
        const tgHandle = msg.from.username ? `@${msg.from.username}` : `ID:${userId}`;

        const panelCaption =
          `<b>╭━━〔 PANEL READY 〕━━╮</b>\n\n` +

          `<blockquote expandable>` +
          `<b>◈ DATA PANEL</b>\n` +
          `├ <b>Name</b>     : <code>${panelHtmlEscape(finalUsername)}</code>\n` +
          `├ <b>Email</b>    : <tg-spoiler>${panelHtmlEscape(email)}</tg-spoiler>\n` +
          `├ <b>Server</b>   : <b>${panelHtmlEscape(versionInfo.label)}</b>\n` +
          `├ <b>ID Panel</b> : <code>${panelHtmlEscape(user.id)}</code>\n` +
          `╰ <b>Paket</b>    : <b>Unlimited</b>` +
          `</blockquote>\n\n` +

          `<blockquote expandable>` +
          `<b>◈ AKUN PANEL</b>\n` +
          `├ <b>Username</b> : <code>${panelHtmlEscape(existingPtUserId ? (user.username || finalUsername) : finalUsername)}</code>\n` +
          (existingPtUserId ? `├ <b>Password</b> : <i>Gunakan password akun lama</i>\n` : `├ <b>Password</b> : <tg-spoiler>${panelHtmlEscape(password)}</tg-spoiler>\n`) +
          `╰ <b>Login</b>    : ${panelHtmlEscape(currentPanel.domain)}` +
          `</blockquote>\n\n` +

          `<blockquote expandable>` +
          `<b>◈ RULES PANEL</b>\n` +
          `├ Sensor domain\n` +
          `├ No DDOS / Share Free\n` +
          `╰ Garansi sesuai ketentuan store` +
          `</blockquote>`;

        const dmButtons = {
          inline_keyboard: [
            existingPtUserId
              ? [{ text: "Salin User", copy_text: { text: String(user.username || finalUsername) } }]
              : [{ text: "Salin User", copy_text: { text: finalUsername } }, { text: "Salin Sandi", copy_text: { text: password } }],
            [{ text: "Buka Panel", url: currentPanel.domain }],
          ],
        };

        let dmOk = false;
        let dmErrMsg = "";
        try {
          await bot.sendPhoto(targetId, settings.notifChannelImage, {
            caption: panelCaption,
            parse_mode: "HTML",
            reply_markup: dmButtons,
          });
          dmOk = true;
        } catch (err) {
          console.error(`[${version}] Gagal sendPhoto ke targetId:`, targetId, "->", err.message);
          const desc = (err.response && err.response.body && err.response.body.description) || err.message || "";
          const belumStart = /can't initiate conversation|bot was blocked|chat not found/i.test(desc);
          if (belumStart) {
            dmErrMsg = "User belum start bot / bot diblokir";
          } else {
            try {
              await bot.sendMessage(targetId, panelCaption, {
                parse_mode: "HTML",
                reply_markup: dmButtons,
              });
              dmOk = true;
            } catch (err2) {
              dmErrMsg = err2.message || "unknown error";
            }
          }
        }

        const dmStatusText = dmOk
          ? "✦ Terkirim ke private chat"
          : `◇ Gagal — ${dmErrMsg}`;

        // ----- Kartu RINGKAS di grup — NOTA CREATE PANEL -----
        const notaText =
          `<b>╭━━〔 PANEL READY 〕━━╮</b>\n\n` +
          `<blockquote expandable>` +
          `<b>◆ NOTA CREATE PANEL</b>\n` +
          `├ <b>Tanggal</b>      : <code>${panelHtmlEscape(nowWib())}</code>\n` +
          `├ <b>Jenis</b>        : ${runtimeLabel}\n` +
          `├ <b>Server</b>       : ${versionInfo.label}\n` +
          `├ <b>Username</b>     : <code>${panelHtmlEscape(finalUsername)}</code>\n` +
          `├ <b>Server ID</b>    : <code>${panelHtmlEscape(user.id)}</code>\n` +
          `├ <b>Dibuat oleh</b>  : ${panelHtmlEscape(tgHandle)} / <code>${panelHtmlEscape(userId)}</code>\n` +
          `├ <b>Nama</b>         : ${panelHtmlEscape(tgName)}\n` +
          `├ <b>Role pembuat</b> : <b>${creatorRole}</b>\n` +
          `╰ <b>Status DM</b>    : <b>${panelHtmlEscape(dmStatusText)}</b>` +
          `</blockquote>\n\n` +
          (dmOk
            ? `❆ <b>Data login sudah dikirim ke user.</b>`
            : `◈ <b>Panel dibuat tapi DM gagal.</b> Suruh user /start bot lalu kirim ulang.`);

        // Kartu provisioning sudah ditutup tepat setelah server berhasil dibuat.
        // Pengiriman DM/channel di bawah ini tidak boleh menghalangi status utama.

        await sendPanelToChannel(bot, {
          type: `${versionInfo.label.toUpperCase()} (${runtimeLabel})`,
          username: finalUsername,
          uid: user.id,
          domainUrl: currentPanel.domain,
          createdBy: msg.from.username ? `@${msg.from.username}` : msg.from.id,
          runtimeLabel,
          serverLabel: versionInfo.label,
          targetTgId: targetId,
        });

        if (!dmOk) {
          console.warn(`[panelCreate] DM gagal ke ${targetId}: ${dmErrMsg}; hasil utama tetap pada satu kartu proses.`);
        }
      }

      if (!isCreated) {
        await finishProvisioning("<blockquote expandable>◇ <b>CREATE PANEL GAGAL</b>\nGagal membuat username unik setelah beberapa percobaan. Coba lagi dengan nama berbeda.</blockquote>");
      }
    } catch (error) {
      console.error(`[${version}] Error API:`, error?.message || error);
      await finishProvisioning(`<blockquote expandable>◇ <b>CREATE PANEL GAGAL</b>\n${panelHtmlEscape(error?.message || "Terjadi kesalahan saat membuat panel.")}</blockquote>`);
    } finally {
      // Last-resort safety net: tidak boleh ada kartu Provisioning yang tertinggal,
      // termasuk jika ada exception/return yang belum tertangani di jalur atas.
      if (!provisioningFinalized) {
        await finishProvisioning("<blockquote expandable>◇ <b>CREATE PANEL GAGAL</b>\nProses berhenti sebelum menerima status berhasil dari server panel.</blockquote>");
      }
      delete createProcess[userId];
      if (pendingChoice[userId]?.timeout) clearTimeout(pendingChoice[userId].timeout);
      delete pendingChoice[userId];
      delete pendingAccountChoice[String(userId)];
    }
  }

  // ===== CALLBACK: tombol pilih runtime (shared buat semua versi) =====
  bot.on("callback_query", async (q) => {
    const data = q.data;
    if (!data || !data.startsWith("unlitype_")) return;

    const userId = q.from.id;
    const pending = pendingChoice[userId];

    if (!pending) {
      return bot.answerCallbackQuery(q.id, { text: "◈ Proses ini sudah tidak berlaku (expired/sudah diproses).", show_alert: true });
    }
    if (q.from.id !== pending.msg.from.id) {
      return bot.answerCallbackQuery(q.id, { text: "◈ Ini bukan proses kamu.", show_alert: true });
    }

    clearTimeout(pending.timeout);
    delete pendingChoice[userId];

    const choice = data.replace("unlitype_", "");

    if (choice === "cancel") {
      delete createProcess[userId];
      await bot.answerCallbackQuery(q.id);
      return bot.editMessageText("<blockquote expandable>◇ <b>Dibatalkan</b>\nProses telah dibatalkan.</blockquote>", { chat_id: pending.chatId, message_id: pending.choiceMessageId });
    }

    await bot.answerCallbackQuery(q.id, { text: choice === "python" ? "◉ Python dipilih" : "◉ Node.js dipilih" });
    runCreate(choice, pending);
  });
}

module.exports = { registerPanelCreateHandlers, PANEL_VERSIONS };