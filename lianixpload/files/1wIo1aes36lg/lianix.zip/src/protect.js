const settings = require("../settings");
const { Client } = require("ssh2");
const { getUserRole } = require("./limit.js");

const OWNER_UID = settings.ownerId;
const ID_OWNER = settings.ownerId.toString();

const installScripts = [
  { cmd: 'installprotect1', file: ['pr1.sh', 'pr23.sh', 'tele.sh', 'pr24.sh', 'pr26.sh', 'antihackvps.sh'] },
  { cmd: 'installprotect2', file: ['pr2.sh'] },
  { cmd: 'installprotect3', file: ['pr3.sh'] },  
  { cmd: 'installprotect4', file: ['pr4.sh', 'pr16.sh', 'pr19.sh', 'pr20.sh', 'pr21.sh'] },
  { cmd: 'installprotect5', file: ['pr5.sh', 'pr15.sh'] },
  { cmd: 'installprotect6', file: ['pr6.sh'] },
  { cmd: 'installprotect7', file: ['pr7.sh'] },
  { cmd: 'installprotect8', file: ['pr8.sh'] },
  { cmd: 'installprotect9', file: ['pr9.sh'] },
  { cmd: 'installprotect10', file: ['pr10.sh'] },
  { cmd: 'installprotect11', file: ['pr11.sh'] }, 
  { cmd: 'installprotect12', file: ['pr12.sh'] }, 
  { cmd: 'installprotect13', file: ['pr18.sh'] }
];

const uninstallScripts = [
  { cmd: 'uninstallprotect1', file: 'un1.sh' },
  { cmd: 'uninstallprotect2', file: 'un2.sh' },
  { cmd: 'uninstallprotect3', file: 'un3.sh' },
  { cmd: 'uninstallprotect4', file: 'un4.sh' },
  { cmd: 'uninstallprotect5', file: 'un5.sh' },
  { cmd: 'uninstallprotect6', file: 'un6.sh' },
  { cmd: 'uninstallprotect7', file: 'un7.sh' },
  { cmd: 'uninstallprotect8', file: 'un8.sh' },
  { cmd: 'uninstallprotect9', file: 'un9.sh' },
  { cmd: 'uninstallprotect10', file: 'un10.sh' },
  { cmd: 'uninstallprotect11', file: 'un11.sh' },
  { cmd: 'uninstallprotect12', file: 'un12.sh' },
  { cmd: 'uninstallprotect13', file: 'un13.sh' },
  { cmd: 'uninstallprotect14', file: 'un14.sh' },
  { cmd: 'uninstallprotect15', file: 'un15.sh' },  
  { cmd: 'uninstallwelcome', file: 'unwelcome.sh' },
];

function escapeHTML(text) {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

// ─── DINONAKTIFKAN: sumber script tidak terverifikasi ──────
// Salah satu script yang dipakai command2 di bawah ini (pr1.sh dari
// repo rexzy223/pro) terbukti backdoor: ganti password root VPS lalu
// kirim diam-diam ke Telegram milik pembuat script. Karena SEMUA
// command di bawah ini punya pola sama (curl script orang lain lalu
// bash sebagai root, tanpa review), semuanya dianggap tidak aman
// sampai diganti dengan script sendiri / resmi.
function unsafeSourceDisabledMsg(cmd) {
  return (
    `⚠ *Command /${cmd} dinonaktifkan.*\n\n` +
    `Sebelumnya command ini menjalankan script dari repository pihak ketiga ` +
    `(bukan milik kita) langsung sebagai *root* di VPS. Salah satu script itu ` +
    `terbukti berisi backdoor (ganti password root & kirim ke luar diam\\-diam), ` +
    `jadi semua command dengan pola serupa dimatikan demi keamanan.\n\n` +
    `Fitur ini akan aktif lagi setelah dibangun ulang pakai cara resmi ` +
    `\\(API panel/script sendiri\\), bukan repo orang lain.`
  );
}

// ─── Anti-spam cooldown ─────────────────────
// Mencegah command yang buka koneksi SSH dipanggil bertubi-tubi
// sampai membuat banyak koneksi bersamaan dan bikin bot ngambek/crash.
const PROTECT_COOLDOWN_MS = 15000;
const protectCooldowns = new Map();

function isOnCooldown(chatId) {
  const last = protectCooldowns.get(chatId);
  if (!last) return 0;
  const remaining = PROTECT_COOLDOWN_MS - (Date.now() - last);
  return remaining > 0 ? remaining : 0;
}

function setCooldown(chatId) {
  protectCooldowns.set(chatId, Date.now());
}

function politeCooldownMessage(remainingMs) {
  const sisa = Math.ceil(remainingMs / 1000);
  return `⏳ Mohon tunggu sebentar ya, proses sebelumnya masih berjalan. Coba lagi dalam ${sisa} detik ⟡`;
}

// ─── Instalasi ──────────────────────────────
module.exports = (bot) => {
installScripts.forEach(({ cmd, file }) => {
  bot.onText(new RegExp(`^\\/${cmd}(?:\\s+(.+))?$`), async (msg, match) => {
    const chatId = msg.chat.id;
    return bot.sendMessage(chatId, unsafeSourceDisabledMsg(cmd), { parse_mode: "MarkdownV2" });
    // eslint-disable-next-line no-unreachable
    const userId = String(msg.from.id);
    const input = match?.[1];

    const roleGeneric = getUserRole(userId);
    if (userId !== String(ID_OWNER) && roleGeneric !== "ceo") {
      return bot.sendMessage(chatId, "⟡ Maaf, fitur install protection ini khusus untuk role CEO ya.");
    }

    const cooldownLeft = isOnCooldown(chatId);
    if (cooldownLeft) {
      return bot.sendMessage(chatId, politeCooldownMessage(cooldownLeft));
    }

    if (!input || !input.includes("|"))
      return bot.sendMessage(
        chatId,
        `ℹ Formatnya belum pas nih.\nGunakan:\n\`/${cmd} ipvps|pwvps\``,
        { parse_mode: "Markdown" }
      );

    const [ipvps, pwvps] = input.split("|").map(v => v.trim());
    if (!ipvps || !pwvps) return;

    const files = Array.isArray(file) ? file : [file];
    const conn = new Client();
    let finished = false;

    bot.sendMessage(
      chatId,
      `⏳ Menghubungkan ke VPS *${ipvps}*\n▶ Menjalankan /${cmd}...`,
      { parse_mode: "Markdown" }
    );

    conn.on("ready", async () => {
      try {
        for (const f of files) {
          let output = "";
          const scriptURL = `https://raw.githubusercontent.com/rexzy223/pro/main/${f}`;

          await new Promise(resolve => {
            const execTimeout = setTimeout(resolve, 60000);

            conn.exec(
              `set -e; curl -fsSL "${scriptURL}" -o /tmp/${f} && chmod +x /tmp/${f} && bash /tmp/${f}`,
              (err, stream) => {
                if (err) {
                  clearTimeout(execTimeout);
                  return resolve();
                }

                stream.on("data", d => (output += d.toString()));
                stream.stderr.on("data", d => (output += d.toString()));

                stream.on("close", () => {
                  clearTimeout(execTimeout);

                  const cleanOutput =
                    output.trim().slice(-3800) || "(tidak ada output)";

                  bot.sendMessage(
                    chatId,
                    `✔ *Instalasi /${cmd} selesai*\n\n⬢ Output terakhir:\n\`\`\`\n${cleanOutput}\n\`\`\``,
                    { parse_mode: "Markdown" }
                  );

                  resolve();
                });
              }
            );
          });
        }

        finished = true;
        conn.end();
      } catch {
        if (finished) return;
        finished = true;
        conn.end();
        bot.sendMessage(chatId, `✕ Gagal menjalankan /${cmd}`);
      }
    });

    conn.on("error", err => {
      if (finished) return;
      finished = true;
      bot.sendMessage(
        chatId,
        `✕ Gagal koneksi VPS\n\`\`\`\n${err.message}\n\`\`\``,
        { parse_mode: "Markdown" }
      );
    });

    conn.connect({
      host: ipvps,
      port: 22,
      username: "root",
      password: pwvps,
      readyTimeout: 20000
    });
  });
});

bot.onText(/^\/installprotectall (.+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  return bot.sendMessage(chatId, unsafeSourceDisabledMsg("installprotectall"), { parse_mode: "MarkdownV2" });
  // eslint-disable-next-line no-unreachable
  const userId = msg.from.id.toString();
  const input = match[1];

  const roleAll = getUserRole(userId);
  if (userId !== String(ID_OWNER) && roleAll !== "ceo") {
    return bot.sendMessage(chatId, "⟡ Maaf, fitur install protection ini khusus untuk role CEO ya.");
  }

  const cooldownLeftAll = isOnCooldown(chatId);
  if (cooldownLeftAll) {
    return bot.sendMessage(chatId, politeCooldownMessage(cooldownLeftAll));
  }

  if (!input || !input.includes("|"))
    return bot.sendMessage(
      chatId,
      "ℹ Formatnya belum pas.\nGunakan:\n`/installprotectall ipvps|pwvps`",
      { parse_mode: "Markdown" }
    );

  setCooldown(chatId);
  const [ipvps, pwvps] = input.split("|").map(v => v.trim());
  if (!ipvps || !pwvps) return;

  const conn = new Client();
  let finished = false;

  const total = installScripts.length;
  let current = 0;

  bot.sendMessage(
    chatId,
    `⏳ Menghubungkan ke VPS *${ipvps}*...\n⌗ Progress: 0/${total}`,
    { parse_mode: "Markdown" }
  );

  conn.on("ready", async () => {
    try {
      for (const { cmd, file } of installScripts) {
        current++;

        bot.sendMessage(
          chatId,
          `⟳ *[${current}/${total}]* Menjalankan /${cmd}`,
          { parse_mode: "Markdown" }
        );

        const files = Array.isArray(file) ? file : [file];

        for (const f of files) {
          let output = "";

          const repo = "https://raw.githubusercontent.com/rexzy223/pro/main/";
          const scriptURL = `${repo}${f}`;

          await new Promise(resolve => {
            const execTimeout = setTimeout(() => {
              bot.sendMessage(
                chatId,
                `⚠ *[${current}/${total}]* Timeout /${cmd}`,
                { parse_mode: "Markdown" }
              );
              resolve();
            }, 60000);

            conn.exec(
              `curl -fsSL "${scriptURL}" -o /tmp/${f} && chmod +x /tmp/${f} && bash /tmp/${f}`,
              (err, stream) => {
                if (err) {
                  clearTimeout(execTimeout);
                  bot.sendMessage(
                    chatId,
                    `✕ *[${current}/${total}]* Error /${cmd}`,
                    { parse_mode: "Markdown" }
                  );
                  return resolve();
                }

                stream.on("data", d => (output += d.toString()));
                stream.stderr.on("data", d => (output += d.toString()));

                stream.on("close", () => {
                  clearTimeout(execTimeout);

                  const cleanOutput =
                    output.trim().slice(-2000) || "(tidak ada output)";

                  bot.sendMessage(
                    chatId,
                    `✔ *[${current}/${total}]* /${cmd} selesai\n\`\`\`\n${cleanOutput}\n\`\`\``,
                    { parse_mode: "Markdown" }
                  );

                  resolve();
                });
              }
            );
          });
        }
      }

      finished = true;
      conn.end();

      bot.sendMessage(
        chatId,
        `⟡ *SELESAI SEMUA*\n⌗ Total: ${total}/${total}`,
        { parse_mode: "Markdown" }
      );

    } catch (e) {
      if (finished) return;
      finished = true;
      conn.end();

      bot.sendMessage(
        chatId,
        `✕ Error global:\n\`\`\`\n${e.message}\n\`\`\``,
        { parse_mode: "Markdown" }
      );
    }
  });

  conn.on("error", err => {
    if (finished) return;
    finished = true;

    bot.sendMessage(
      chatId,
      `✕ Gagal konek VPS\n\`\`\`\n${err.message}\n\`\`\``,
      { parse_mode: "Markdown" }
    );
  });

  conn.connect({
    host: ipvps,
    port: 22,
    username: "root",
    password: pwvps,
    readyTimeout: 20000
  });
});
bot.onText(/^\/installwelcome(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  return bot.sendMessage(chatId, unsafeSourceDisabledMsg("installwelcome"), { parse_mode: "MarkdownV2" });
  // eslint-disable-next-line no-unreachable
  const userId = msg.from.id.toString();

  const cdLeft = isOnCooldown(chatId);
  if (cdLeft) {
    return bot.sendMessage(chatId, politeCooldownMessage(cdLeft));
  }

  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      "⬡ *Cara penggunaan:*\n`/installwelcome ipvps|pwvps`",
      { parse_mode: "Markdown" }
    );
  }

  const input = match[1];

  if (!input.includes("|")) {
    return bot.sendMessage(
      chatId,
      "ℹ Formatnya belum pas.\nGunakan:\n`/installwelcome ipvps|pwvps`",
      { parse_mode: "Markdown" }
    );
  }

  const [ipvps, pwvps] = input.split("|").map(v => v.trim());
  if (!ipvps || !pwvps) {
    return bot.sendMessage(
      chatId,
      "ℹ Formatnya belum pas.\nGunakan:\n`/installwelcome ipvps|pwvps`",
      { parse_mode: "Markdown" }
    );
  }

  const conn = new Client();
  const scriptURL =
    "https://raw.githubusercontent.com/rexzzyphn/pr/refs/heads/main/welcome.sh";

  await bot.sendMessage(
    chatId,
    `⏳ Menghubungkan ke VPS *${ipvps}* dan memulai instalasi Welcome...`,
    { parse_mode: "Markdown" }
  );

  conn.on("ready", () => {
    bot.sendMessage(
      chatId,
      "⊙ *Koneksi berhasil!* Instalasi berjalan...",
      { parse_mode: "Markdown" }
    );

    conn.exec(`curl -fsSL ${scriptURL} | bash`, (err, stream) => {
      if (err) {
        conn.end();
        return bot.sendMessage(
          chatId,
          `✕ Gagal mengeksekusi perintah:\n\`\`\`\n${err.message}\n\`\`\``,
          { parse_mode: "Markdown" }
        );
      }

      let output = "";
      stream.on("data", d => (output += d.toString()));
      stream.stderr.on("data", d => (output += d.toString()));

      stream.on("close", () => {
        conn.end();
        const cleanOutput =
          output.trim().slice(-3800) || "(tidak ada output)";

        bot.sendMessage(
          chatId,
          `✔ *Instalasi selesai!*\n\n⬢ Output terakhir:\n\`\`\`\n${cleanOutput}\n\`\`\``,
          { parse_mode: "Markdown" }
        );
      });
    });
  });

  conn.on("error", err => {
    bot.sendMessage(
      chatId,
      `⚠ Belum berhasil terhubung ke VPS.\nCoba periksa lagi IP & Password-nya ya.\n\n\`\`\`\n${err.message}\n\`\`\``,
      { parse_mode: "Markdown" }
    );
  });

  conn.connect({
    host: ipvps,
    port: 22,
    username: "root",
    password: pwvps
  });
});
bot.onText(/^\/installprotect18(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  return bot.sendMessage(chatId, unsafeSourceDisabledMsg("installprotect18"), { parse_mode: "MarkdownV2" });
  // eslint-disable-next-line no-unreachable
  const userId = msg.from.id.toString();

  const roleProtect = getUserRole(userId);
  if (userId !== ID_OWNER && roleProtect !== "ceo") {
    return bot.sendMessage(chatId, "⟡ Maaf, fitur install protection ini khusus untuk role CEO ya.");
  }

  const cdLeft = isOnCooldown(chatId);
  if (cdLeft) {
    return bot.sendMessage(chatId, politeCooldownMessage(cdLeft));
  }

  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      "⬡ *Cara penggunaan:*\n`/installprotect18 ipvps|pwvps`",
      { parse_mode: "Markdown" }
    );
  }

  const input = match[1];

  if (!input.includes("|")) {
    return bot.sendMessage(
      chatId,
      "ℹ Formatnya belum pas.\nGunakan:\n`/installprotect18 ipvps|pwvps`",
      { parse_mode: "Markdown" }
    );
  }

  const [ipvps, pwvps] = input.split("|").map(v => v.trim());
  if (!ipvps || !pwvps) {
    return bot.sendMessage(
      chatId,
      "ℹ Formatnya belum pas.\nGunakan:\n`/installwelcome ipvps|pwvps`",
      { parse_mode: "Markdown" }
    );
  }

  const conn = new Client();
  const scriptURL =
    "https://raw.githubusercontent.com/rexzy223/pro/refs/heads/main/pr25.sh";

  await bot.sendMessage(
    chatId,
    `⏳ Menghubungkan ke VPS *${ipvps}* dan memulai instalasi Anti Create Admin...`,
    { parse_mode: "Markdown" }
  );

  conn.on("ready", () => {
    bot.sendMessage(
      chatId,
      "⊙ *Koneksi berhasil!* Instalasi berjalan...",
      { parse_mode: "Markdown" }
    );

    conn.exec(`curl -fsSL ${scriptURL} | bash`, (err, stream) => {
      if (err) {
        conn.end();
        return bot.sendMessage(
          chatId,
          `✕ Gagal mengeksekusi perintah:\n\`\`\`\n${err.message}\n\`\`\``,
          { parse_mode: "Markdown" }
        );
      }

      let output = "";
      stream.on("data", d => (output += d.toString()));
      stream.stderr.on("data", d => (output += d.toString()));

      stream.on("close", () => {
        conn.end();
        const cleanOutput =
          output.trim().slice(-3800) || "(tidak ada output)";

        bot.sendMessage(
          chatId,
          `✔ *Instalasi selesai!*\n\n⬢ Output terakhir:\n\`\`\`\n${cleanOutput}\n\`\`\``,
          { parse_mode: "Markdown" }
        );
      });
    });
  });

  conn.on("error", err => {
    bot.sendMessage(
      chatId,
      `⚠ Belum berhasil terhubung ke VPS.\nCoba periksa lagi IP & Password-nya ya.\n\n\`\`\`\n${err.message}\n\`\`\``,
      { parse_mode: "Markdown" }
    );
  });

  conn.connect({
    host: ipvps,
    port: 22,
    username: "root",
    password: pwvps
  });
});
bot.onText(/^\/installprotect14(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  return bot.sendMessage(chatId, unsafeSourceDisabledMsg("installprotect14"), { parse_mode: "MarkdownV2" });
  // eslint-disable-next-line no-unreachable
  const userId = msg.from.id.toString();

  const roleProtect = getUserRole(userId);
  if (userId !== ID_OWNER && roleProtect !== "ceo") {
    return bot.sendMessage(chatId, "⟡ Maaf, fitur install protection ini khusus untuk role CEO ya.");
  }

  const cdLeft = isOnCooldown(chatId);
  if (cdLeft) {
    return bot.sendMessage(chatId, politeCooldownMessage(cdLeft));
  }

  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      "⬡ *Cara penggunaan:* /installprotect14 ipvps|pwvps",
      { parse_mode: "Markdown" }
    );
  }

  const input = match[1];

  if (!input.includes("|")) {
    return bot.sendMessage(
      chatId,
      "ℹ Formatnya belum pas.\nGunakan:\n`/installprotect14 ipvps|pwvps`",
      { parse_mode: "Markdown" }
    );
  }

  const [ipvps, pwvps] = input.split("|").map(v => v.trim());
  if (!ipvps || !pwvps) {
    return bot.sendMessage(
      chatId,
      "ℹ Formatnya belum pas.\nGunakan:\n`/installprotect13 ipvps|pwvps`",
      { parse_mode: "Markdown" }
    );
  }

  const conn = new Client();
  const scriptURL =
    "https://raw.githubusercontent.com/rexzzyphn/pr/refs/heads/main/pr13.sh";

  await bot.sendMessage(
    chatId,
    `⏳ Menghubungkan ke VPS *${ipvps}* dan memulai instalasi Protect 14...`,
    { parse_mode: "Markdown" }
  );

  conn.on("ready", () => {
    bot.sendMessage(
      chatId,
      "⊙ *Koneksi berhasil!* Instalasi berjalan...",
      { parse_mode: "Markdown" }
    );

    conn.exec(`curl -fsSL ${scriptURL} | bash`, (err, stream) => {
      if (err) {
        conn.end();
        return bot.sendMessage(
          chatId,
          `✕ Gagal mengeksekusi perintah:\n\n\`\`\`\n${err.message}\n\`\`\``,
          { parse_mode: "Markdown" }
        );
      }

      let output = "";
      stream.on("data", d => (output += d.toString()));
      stream.stderr.on("data", d => (output += d.toString()));

      stream.on("close", () => {
        conn.end();
        const cleanOutput =
          output.trim().slice(-3800) || "(tidak ada output)";

        bot.sendMessage(
          chatId,
          `✔ *Instalasi selesai!*\n\n⬢ Output terakhir:\n\n\`\`\`\n${cleanOutput}\n\`\`\``,
          { parse_mode: "Markdown" }
        );
      });
    });
  });

  conn.on("error", err => {
    bot.sendMessage(
      chatId,
      `⚠ Belum berhasil terhubung ke VPS.\nCoba periksa lagi IP & Password-nya ya.\n\n\`\`\`\n${err.message}\n\`\`\``,
      { parse_mode: "Markdown" }
    );
  });

  conn.connect({
    host: ipvps,
    port: 22,
    username: "root",
    password: pwvps
  });
});

bot.onText(/^\/installprotect15(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  return bot.sendMessage(chatId, unsafeSourceDisabledMsg("installprotect15"), { parse_mode: "MarkdownV2" });
  // eslint-disable-next-line no-unreachable
  const userId = msg.from.id.toString();

  const roleProtect = getUserRole(userId);
  if (userId !== ID_OWNER && roleProtect !== "ceo") {
    return bot.sendMessage(chatId, "⟡ Maaf, fitur install protection ini khusus untuk role CEO ya.");
  }

  const cdLeft = isOnCooldown(chatId);
  if (cdLeft) {
    return bot.sendMessage(chatId, politeCooldownMessage(cdLeft));
  }

  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      "⬡ *Cara penggunaan:* /installprotect15 ipvps|pwvps",
      { parse_mode: "Markdown" }
    );
  }

  const input = match[1];

  if (!input.includes("|")) {
    return bot.sendMessage(
      chatId,
      "ℹ Formatnya belum pas.\nGunakan:\n`/installprotect15 ipvps|pwvps`",
      { parse_mode: "Markdown" }
    );
  }

  const [ipvps, pwvps] = input.split("|").map(v => v.trim());
  if (!ipvps || !pwvps) {
    return bot.sendMessage(
      chatId,
      "ℹ Formatnya belum pas.\nGunakan:\n`/installprotect15 ipvps|pwvps`",
      { parse_mode: "Markdown" }
    );
  }

  const conn = new Client();
  const scriptURL =
    "https://raw.githubusercontent.com/rexzzyphn/pr/refs/heads/main/pr14.sh";

  await bot.sendMessage(
    chatId,
    `⏳ Menghubungkan ke VPS *${ipvps}* dan memulai instalasi Protect 15...`,
    { parse_mode: "Markdown" }
  );

  conn.on("ready", () => {
    bot.sendMessage(
      chatId,
      "⊙ *Koneksi berhasil!* Instalasi berjalan...",
      { parse_mode: "Markdown" }
    );

    conn.exec(`curl -fsSL ${scriptURL} | bash`, (err, stream) => {
      if (err) {
        conn.end();
        return bot.sendMessage(
          chatId,
          `✕ Gagal mengeksekusi perintah:\n\n\`\`\`\n${err.message}\n\`\`\``,
          { parse_mode: "Markdown" }
        );
      }

      let output = "";
      stream.on("data", d => (output += d.toString()));
      stream.stderr.on("data", d => (output += d.toString()));

      stream.on("close", () => {
        conn.end();
        const cleanOutput =
          output.trim().slice(-3800) || "(tidak ada output)";

        bot.sendMessage(
          chatId,
          `✔ *Instalasi selesai!*\n\n⬢ Output terakhir:\n\n\`\`\`\n${cleanOutput}\n\`\`\``,
          { parse_mode: "Markdown" }
        );
      });
    });
  });

  conn.on("error", err => {
    bot.sendMessage(
      chatId,
      `⚠ Belum berhasil terhubung ke VPS.\nCoba periksa lagi IP & Password-nya ya.\n\n\`\`\`\n${err.message}\n\`\`\``,
      { parse_mode: "Markdown" }
    );
  });

  conn.connect({
    host: ipvps,
    port: 22,
    username: "root",
    password: pwvps
  });
});
bot.onText(/^\/installprotect16(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  return bot.sendMessage(chatId, unsafeSourceDisabledMsg("installprotect16"), { parse_mode: "MarkdownV2" });
  // eslint-disable-next-line no-unreachable
  const userId = msg.from.id.toString();

  const roleProtect = getUserRole(userId);
  if (userId !== ID_OWNER && roleProtect !== "ceo") {
    return bot.sendMessage(chatId, "⟡ Maaf, fitur install protection ini khusus untuk role CEO ya.");
  }

  const cdLeft = isOnCooldown(chatId);
  if (cdLeft) {
    return bot.sendMessage(chatId, politeCooldownMessage(cdLeft));
  }

  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      "⬡ *Cara penggunaan:* /installprotect16 ipvps|pwvps",
      { parse_mode: "Markdown" }
    );
  }

  const input = match[1];

  if (!input.includes("|")) {
    return bot.sendMessage(
      chatId,
      "✕ Salah format!\nGunakan:\n`/installprotect16 ipvps|pwvps`",
      { parse_mode: "Markdown" }
    );
  }

  const [ipvps, pwvps] = input.split("|").map(v => v.trim());
  if (!ipvps || !pwvps) {
    return bot.sendMessage(
      chatId,
      "✕ Salah format!\nGunakan:\n`/installprotect16 ipvps|pwvps`",
      { parse_mode: "Markdown" }
    );
  }

  const conn = new Client();
  const scriptURL =
    "https://raw.githubusercontent.com/rexzzyphn/pr/refs/heads/main/pr17.sh";

  await bot.sendMessage(
    chatId,
    `⏳ Menghubungkan ke VPS *${ipvps}* dan memulai instalasi Protect 16...`,
    { parse_mode: "Markdown" }
  );

  conn.on("ready", () => {
    bot.sendMessage(
      chatId,
      "⊙ *Koneksi berhasil!* Instalasi berjalan...",
      { parse_mode: "Markdown" }
    );

    conn.exec(`curl -fsSL ${scriptURL} | bash`, (err, stream) => {
      if (err) {
        conn.end();
        return bot.sendMessage(
          chatId,
          `✕ Gagal mengeksekusi perintah:\n\n\`\`\`\n${err.message}\n\`\`\``,
          { parse_mode: "Markdown" }
        );
      }

      let output = "";
      stream.on("data", d => (output += d.toString()));
      stream.stderr.on("data", d => (output += d.toString()));

      stream.on("close", () => {
        conn.end();
        const cleanOutput =
          output.trim().slice(-3800) || "(tidak ada output)";

        bot.sendMessage(
          chatId,
          `✔ *Instalasi selesai!*\n\n⬢ Output terakhir:\n\n\`\`\`\n${cleanOutput}\n\`\`\``,
          { parse_mode: "Markdown" }
        );
      });
    });
  });

  conn.on("error", err => {
    bot.sendMessage(
      chatId,
      `⚠ Belum berhasil terhubung ke VPS.\nCoba periksa lagi IP & Password-nya ya.\n\n\`\`\`\n${err.message}\n\`\`\``,
      { parse_mode: "Markdown" }
    );
  });

  conn.connect({
    host: ipvps,
    port: 22,
    username: "root",
    password: pwvps
  });
});
bot.onText(/^\/installprotect17(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  return bot.sendMessage(chatId, unsafeSourceDisabledMsg("installprotect17"), { parse_mode: "MarkdownV2" });
  // eslint-disable-next-line no-unreachable
  const userId = msg.from.id.toString();

  const role17 = getUserRole(userId);
  if (userId !== ID_OWNER && role17 !== "ceo") {
    return bot.sendMessage(chatId, "⟡ Maaf, fitur install protection ini khusus untuk role CEO ya.");
  }

  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      `⬡ *CARA PENGGUNAAN*: \`/installprotect17 ipvps|passwordvps\``,
      { parse_mode: "Markdown" }
    );
  }

  const cdLeft17 = isOnCooldown(chatId);
  if (cdLeft17) {
    return bot.sendMessage(chatId, politeCooldownMessage(cdLeft17));
  }
  setCooldown(chatId);

  const [ipVps, pwVps] = match[1].split("|");

  const { NodeSSH } = require("node-ssh");
  const fs = require("fs");
  const path = require("path");
  const ssh = new NodeSSH();

  await bot.sendMessage(
    chatId,
    "⬡ *Memulai instalasi semua proteksi...*\nHarap tunggu beberapa saat ⏳",
    { parse_mode: "Markdown" }
  );

  try {
    await ssh.connect({
      host: ipVps,
      username: "root",
      password: pwVps,
      port: 22,
    });

    const protectFiles = [
      {
        name: "PROTECT1 (Anti Intip Server In Settings)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Admin/Servers/ServerController.php",
        file: "ServerController.php",
        code: `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin\\Servers;

use Illuminate\\View\\View;
use Illuminate\\Http\\Request;
use Illuminate\\Support\\Facades\\Auth;
use Pterodactyl\\Models\\Server;
use Pterodactyl\\Models\\User;
use Pterodactyl\\Models\\Nest;
use Pterodactyl\\Models\\Location;
use Spatie\\QueryBuilder\\QueryBuilder;
use Spatie\\QueryBuilder\\AllowedFilter;
use Pterodactyl\\Http\\Controllers\\Controller;
use Pterodactyl\\Models\\Filters\\AdminServerFilter;
use Illuminate\\Contracts\\View\\Factory as ViewFactory;

class ServerController extends Controller
{
    /**
     * Konstruktor
     */
    public function __construct(private ViewFactory $view)
    {
    }

/**
 * ☰ Daftar server — hanya tampilkan milik sendiri kecuali admin ID 1
 */
public function index(Request $request): View
{
    $user = Auth::user();

    // Ambil query dasar
$query = Server::query()
    ->with(['node', 'user', 'allocation'])
    ->orderBy('id', 'asc'); // server baru di bawah

    // NDyProtect v1.5 — Batasi query utama
    if ($user->id !== 1) {
        $query->where('owner_id', $user->id);
    }

    // Gunakan QueryBuilder tapi tetap batasi hasil user
    $servers = QueryBuilder::for($query)
        ->allowedFilters([
            AllowedFilter::exact('owner_id'),
            AllowedFilter::custom('*', new AdminServerFilter()),
        ])
        ->when($request->has('filter') && isset($request->filter['search']), function ($q) use ($request) {
            $search = $request->filter['search'];
            $q->where(function ($sub) use ($search) {
                $sub->where('name', 'like', "%{$search}%")
                    ->orWhere('uuidShort', 'like', "%{$search}%")
                    ->orWhere('uuid', 'like', "%{$search}%");
            });
        })
        ->paginate(config('pterodactyl.paginate.admin.servers'))
        ->appends($request->query());

    return $this->view->make('admin.servers.index', ['servers' => $servers]);
}

    public function create(): View
    {
        $user = Auth::user();

        if ($user->id === 1) {
            // Admin ID 1 bisa pilih owner siapa pun
            $users = User::all();
            $lock_owner = false;
            $auto_owner = null;
        } else {
            // User biasa hanya bisa membuat server untuk dirinya sendiri
            $users = collect([$user]);
            $lock_owner = true;
            $auto_owner = $user;
        }

        return $this->view->make('admin.servers.new', [
            'users' => $users,
            'lock_owner' => $lock_owner,
            'auto_owner' => $auto_owner,
            'locations' => Location::with('nodes')->get(),
            'nests' => Nest::with('eggs')->get(),
        ]);
    }

    /**
     * ⌕ Detail/Edit Server — hanya pemilik server atau admin ID 1
     */
    public function view(Server $server): View
    {
        $user = Auth::user();

        if ($user->id !== 1 && $server->owner_id !== $user->id) {
            abort(403, '⊘ Akses ditolak: Hanya admin ID 1 yang dapat melihat atau mengedit server ini.');
        }

        return $this->view->make('admin.servers.view', ['server' => $server]);
    }

    /**
     * ⚒ Update Server — hanya pemilik server atau admin ID 1
     */
    public function update(Request $request, Server $server)
    {
        $user = Auth::user();

        if ($user->id !== 1 && $server->owner_id !== $user->id) {
            abort(403, '⊘ Akses ditolak: Hanya admin ID 1 yang dapat mengubah server ini.');
        }

        // Lindungi agar user biasa tidak bisa ubah owner_id
        $data = $request->except(['owner_id']);

        $server->update($data);

        return redirect()->route('admin.servers.view', $server->id)
            ->with('success', '✔ Server berhasil diperbarui.');
    }

    /**
     * ✕ Hapus Server — hanya Admin ID 1
     */
    public function destroy(Server $server)
    {
        $user = Auth::user();

        if ($user->id !== 1) {
            abort(403, '⊘ Akses ditolak: Hanya admin ID 1 yang dapat menghapus server ini.');
        }

        $server->delete();

        return redirect()->route('admin.servers')
            ->with('success', '⌫ Server berhasil dihapus.');
    }
}`
      },
      {
        name: "PROTECT1 (Otomatis Isi Server Owner)",
        path: "/var/www/pterodactyl/resources/views/admin/servers/new.blade.php",
        file: "new.blade.php",
        code: `@extends('layouts.admin')

@section('title')
    New Server
@endsection

@section('content-header')
    <h1>Create Server<small>Add a new server to the panel.</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li><a href="{{ route('admin.servers') }}">Servers</a></li>
        <li class="active">Create Server</li>
    </ol>
@endsection

@section('content')
<form action="{{ route('admin.servers.new') }}" method="POST">
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Core Details</h3>
                </div>

                <div class="box-body row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="pName">Server Name</label>
                            <input type="text" class="form-control" id="pName" name="name" value="{{ old('name') }}" placeholder="Server Name">
                            <p class="small text-muted no-margin">Character limits: <code>a-z A-Z 0-9 _ - .</code> and <code>[Space]</code>.</p>
                        </div>

<div class="form-group">
    <label for="pUserId">Server Owner</label>

    @if(Auth::user()->id == 1)
        {{-- Admin ID 1: bisa isi manual --}}
        <select id="pUserId" name="owner_id" class="form-control">
            <option value="">Select a User</option>
            @foreach(\\Pterodactyl\\Models\\User::all() as $user)
                <option value="{{ $user->id }}" @selected(old('owner_id') == $user->id)>
                    {{ $user->username }} ({{ $user->email }})
                </option>
            @endforeach
        </select>
        <p class="small text-muted no-margin">As admin, you can manually choose the server owner.</p>
    @else
        {{-- Selain admin ID 1: otomatis --}}
        <input type="hidden" id="pUserId" name="owner_id" value="{{ Auth::user()->id }}">
        <input type="text" class="form-control" value="{{ Auth::user()->email }}" disabled>
        <p class="small text-muted no-margin">This server will be owned by your account automatically.</p>
    @endif
</div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="pDescription" class="control-label">Server Description</label>
                            <textarea id="pDescription" name="description" rows="3" class="form-control">{{ old('description') }}</textarea>
                            <p class="text-muted small">A brief description of this server.</p>
                        </div>

                        <div class="form-group">
                            <div class="checkbox checkbox-primary no-margin-bottom">
                                <input id="pStartOnCreation" name="start_on_completion" type="checkbox" {{ \\Pterodactyl\\Helpers\\Utilities::checked('start_on_completion', 1) }} />
                                <label for="pStartOnCreation" class="strong">Start Server when Installed</label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="overlay" id="allocationLoader" style="display:none;"><i class="fa fa-refresh fa-spin"></i></div>
                <div class="box-header with-border">
                    <h3 class="box-title">Allocation Management</h3>
                </div>

                <div class="box-body row">
                    <div class="form-group col-sm-4">
                        <label for="pNodeId">Node</label>
                        <select name="node_id" id="pNodeId" class="form-control">
                            @foreach($locations as $location)
                                <optgroup label="{{ $location->long }} ({{ $location->short }})">
                                @foreach($location->nodes as $node)

                                <option value="{{ $node->id }}"
                                    @if($location->id === old('location_id')) selected @endif
                                >{{ $node->name }}</option>

                                @endforeach
                                </optgroup>
                            @endforeach
                        </select>

                        <p class="small text-muted no-margin">The node which this server will be deployed to.</p>
                    </div>

                    <div class="form-group col-sm-4">
                        <label for="pAllocation">Default Allocation</label>
                        <select id="pAllocation" name="allocation_id" class="form-control"></select>
                        <p class="small text-muted no-margin">The main allocation that will be assigned to this server.</p>
                    </div>

                    <div class="form-group col-sm-4">
                        <label for="pAllocationAdditional">Additional Allocation(s)</label>
                        <select id="pAllocationAdditional" name="allocation_additional[]" class="form-control" multiple></select>
                        <p class="small text-muted no-margin">Additional allocations to assign to this server on creation.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="overlay" id="allocationLoader" style="display:none;"><i class="fa fa-refresh fa-spin"></i></div>
                <div class="box-header with-border">
                    <h3 class="box-title">Application Feature Limits</h3>
                </div>

                <div class="box-body row">
                    <div class="form-group col-xs-6">
                        <label for="pDatabaseLimit" class="control-label">Database Limit</label>
                        <div>
                            <input type="text" id="pDatabaseLimit" name="database_limit" class="form-control" value="{{ old('database_limit', 0) }}"/>
                        </div>
                        <p class="text-muted small">The total number of databases a user is allowed to create for this server.</p>
                    </div>
                    <div class="form-group col-xs-6">
                        <label for="pAllocationLimit" class="control-label">Allocation Limit</label>
                        <div>
                            <input type="text" id="pAllocationLimit" name="allocation_limit" class="form-control" value="{{ old('allocation_limit', 0) }}"/>
                        </div>
                        <p class="text-muted small">The total number of allocations a user is allowed to create for this server.</p>
                    </div>
                    <div class="form-group col-xs-6">
                        <label for="pBackupLimit" class="control-label">Backup Limit</label>
                        <div>
                            <input type="text" id="pBackupLimit" name="backup_limit" class="form-control" value="{{ old('backup_limit', 0) }}"/>
                        </div>
                        <p class="text-muted small">The total number of backups that can be created for this server.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Resource Management</h3>
                </div>

                <div class="box-body row">
                    <div class="form-group col-xs-6">
                        <label for="pCPU">CPU Limit</label>

                        <div class="input-group">
                            <input type="text" id="pCPU" name="cpu" class="form-control" value="{{ old('cpu', 0) }}" />
                            <span class="input-group-addon">%</span>
                        </div>

                        <p class="text-muted small">If you do not want to limit CPU usage, set the value to <code>0</code>. To determine a value, take the number of threads and multiply it by 100. For example, on a quad core system without hyperthreading <code>(4 * 100 = 400)</code> there is <code>400%</code> available. To limit a server to using half of a single thread, you would set the value to <code>50</code>. To allow a server to use up to two threads, set the value to <code>200</code>.<p>
                    </div>

                    <div class="form-group col-xs-6">
                        <label for="pThreads">CPU Pinning</label>

                        <div>
                            <input type="text" id="pThreads" name="threads" class="form-control" value="{{ old('threads') }}" />
                        </div>

                        <p class="text-muted small"><strong>Advanced:</strong> Enter the specific CPU threads that this process can run on, or leave blank to allow all threads. This can be a single number, or a comma separated list. Example: <code>0</code>, <code>0-1,3</code>, or <code>0,1,3,4</code>.</p>
                    </div>
                </div>

                <div class="box-body row">
                    <div class="form-group col-xs-6">
                        <label for="pMemory">Memory</label>

                        <div class="input-group">
                            <input type="text" id="pMemory" name="memory" class="form-control" value="{{ old('memory') }}" />
                            <span class="input-group-addon">MiB</span>
                        </div>

                        <p class="text-muted small">The maximum amount of memory allowed for this container. Setting this to <code>0</code> will allow unlimited memory in a container.</p>
                    </div>

                    <div class="form-group col-xs-6">
                        <label for="pSwap">Swap</label>

                        <div class="input-group">
                            <input type="text" id="pSwap" name="swap" class="form-control" value="{{ old('swap', 0) }}" />
                            <span class="input-group-addon">MiB</span>
                        </div>

                        <p class="text-muted small">Setting this to <code>0</code> will disable swap space on this server. Setting to <code>-1</code> will allow unlimited swap.</p>
                    </div>
                </div>

                <div class="box-body row">
                    <div class="form-group col-xs-6">
                        <label for="pDisk">Disk Space</label>

                        <div class="input-group">
                            <input type="text" id="pDisk" name="disk" class="form-control" value="{{ old('disk') }}" />
                            <span class="input-group-addon">MiB</span>
                        </div>

                        <p class="text-muted small">This server will not be allowed to boot if it is using more than this amount of space. If a server goes over this limit while running it will be safely stopped and locked until enough space is available. Set to <code>0</code> to allow unlimited disk usage.</p>
                    </div>

                    <div class="form-group col-xs-6">
                        <label for="pIO">Block IO Weight</label>

                        <div>
                            <input type="text" id="pIO" name="io" class="form-control" value="{{ old('io', 500) }}" />
                        </div>

                        <p class="text-muted small"><strong>Advanced</strong>: The IO performance of this server relative to other <em>running</em> containers on the system. Value should be between <code>10</code> and <code>1000</code>. Please see <a href="https://docs.docker.com/engine/reference/run/#block-io-bandwidth-blkio-constraint" target="_blank">this documentation</a> for more information about it.</p>
                    </div>
                    <div class="form-group col-xs-12">
                        <div class="checkbox checkbox-primary no-margin-bottom">
                            <input type="checkbox" id="pOomDisabled" name="oom_disabled" value="0" {{ \\Pterodactyl\\Helpers\\Utilities::checked('oom_disabled', 0) }} />
                            <label for="pOomDisabled" class="strong">Enable OOM Killer</label>
                        </div>

                        <p class="small text-muted no-margin">Terminates the server if it breaches the memory limits. Enabling OOM killer may cause server processes to exit unexpectedly.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Nest Configuration</h3>
                </div>

                <div class="box-body row">
                    <div class="form-group col-xs-12">
                        <label for="pNestId">Nest</label>

                        <select id="pNestId" name="nest_id" class="form-control">
                            @foreach($nests as $nest)
                                <option value="{{ $nest->id }}"
                                    @if($nest->id === old('nest_id'))
                                        selected="selected"
                                    @endif
                                >{{ $nest->name }}</option>
                            @endforeach
                        </select>

                        <p class="small text-muted no-margin">Select the Nest that this server will be grouped under.</p>
                    </div>

                    <div class="form-group col-xs-12">
                        <label for="pEggId">Egg</label>
                        <select id="pEggId" name="egg_id" class="form-control"></select>
                        <p class="small text-muted no-margin">Select the Egg that will define how this server should operate.</p>
                    </div>
                    <div class="form-group col-xs-12">
                        <div class="checkbox checkbox-primary no-margin-bottom">
                            <input type="checkbox" id="pSkipScripting" name="skip_scripts" value="1" {{ \\Pterodactyl\\Helpers\\Utilities::checked('skip_scripts', 0) }} />
                            <label for="pSkipScripting" class="strong">Skip Egg Install Script</label>
                        </div>

                        <p class="small text-muted no-margin">If the selected Egg has an install script attached to it, the script will run during the install. If you would like to skip this step, check this box.</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Docker Configuration</h3>
                </div>

                <div class="box-body row">
                    <div class="form-group col-xs-12">
                        <label for="pDefaultContainer">Docker Image</label>
                        <select id="pDefaultContainer" name="image" class="form-control"></select>
                        <input id="pDefaultContainerCustom" name="custom_image" value="{{ old('custom_image') }}" class="form-control" placeholder="Or enter a custom image..." style="margin-top:1rem"/>
                        <p class="small text-muted no-margin">This is the default Docker image that will be used to run this server. Select an image from the dropdown above, or enter a custom image in the text field above.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Startup Configuration</h3>
                </div>

                <div class="box-body row">
                    <div class="form-group col-xs-12">
                        <label for="pStartup">Startup Command</label>
                        <input type="text" id="pStartup" name="startup" value="{{ old('startup') }}" class="form-control" />
                        <p class="small text-muted no-margin">The following data substitutes are available for the startup command: <code>@{{SERVER_MEMORY}}</code>, <code>@{{SERVER_IP}}</code>, and <code>@{{SERVER_PORT}}</code>. They will be replaced with the allocated memory, server IP, and server port respectively.</p>
                    </div>
                </div>

                <div class="box-header with-border" style="margin-top:-10px;">
                    <h3 class="box-title">Service Variables</h3>
                </div>

                <div class="box-body row" id="appendVariablesTo"></div>

                <div class="box-footer">
                    {!! csrf_field() !!}
                    <input type="submit" class="btn btn-success pull-right" value="Create Server" />
                </div>
            </div>
        </div>
    </div>
</form>
@endsection

@section('footer-scripts')
    @parent
    {!! Theme::js('vendor/lodash/lodash.js') !!}

    <script type="application/javascript">
        // Persist 'Service Variables'
        function serviceVariablesUpdated(eggId, ids) {
            @if (old('egg_id'))
                // Check if the egg id matches.
                if (eggId != '{{ old('egg_id') }}') {
                    return;
                }

                @if (old('environment'))
                    @foreach (old('environment') as $key => $value)
                        $('#' + ids['{{ $key }}']).val('{{ $value }}');
                    @endforeach
                @endif
            @endif
            @if(old('image'))
                $('#pDefaultContainer').val('{{ old('image') }}');
            @endif
        }
        // END Persist 'Service Variables'
    </script>

    {!! Theme::js('js/admin/new-server.js?v=20220530') !!}

    <script type="application/javascript">
        $(document).ready(function() {
// Persist 'Server Owner' select2
// (Removed because Server Owner now auto-fills based on logged-in user)
// END Persist 'Server Owner' select2

            // Persist 'Node' select2
            @if (old('node_id'))
                $('#pNodeId').val('{{ old('node_id') }}').change();

                // Persist 'Default Allocation' select2
                @if (old('allocation_id'))
                    $('#pAllocation').val('{{ old('allocation_id') }}').change();
                @endif
                // END Persist 'Default Allocation' select2

                // Persist 'Additional Allocations' select2
                @if (old('allocation_additional'))
                    const additional_allocations = [];

                    @for ($i = 0; $i < count(old('allocation_additional')); $i++)
                        additional_allocations.push('{{ old('allocation_additional.'.$i)}}');
                    @endfor

                    $('#pAllocationAdditional').val(additional_allocations).change();
                @endif
                // END Persist 'Additional Allocations' select2
            @endif
            // END Persist 'Node' select2

            // Persist 'Nest' select2
            @if (old('nest_id'))
                $('#pNestId').val('{{ old('nest_id') }}').change();

                // Persist 'Egg' select2
                @if (old('egg_id'))
                    $('#pEggId').val('{{ old('egg_id') }}').change();
                @endif
                // END Persist 'Egg' select2
            @endif
            // END Persist 'Nest' select2
        });
    </script>
@endsection
`
      },
      {
        name: "PROTECT1 (Anti Update Detail Server)",
        path: "/var/www/pterodactyl/app/Services/Servers/DetailsModificationService.php",
        file: "DetailsModificationService.php",
        code: `<?php

namespace Pterodactyl\\Services\\Servers;

use Illuminate\\Support\\Arr;
use Illuminate\\Support\\Facades\\Auth;
use Pterodactyl\\Models\\Server;
use Illuminate\\Database\\ConnectionInterface;
use Pterodactyl\\Traits\\Services\\ReturnsUpdatedModels;
use Pterodactyl\\Repositories\\Wings\\DaemonServerRepository;
use Pterodactyl\\Exceptions\\DisplayException;
use Pterodactyl\\Exceptions\\Http\\Connection\\DaemonConnectionException;

class DetailsModificationService
{
    use ReturnsUpdatedModels;

    public function __construct(
        private ConnectionInterface $connection,
        private DaemonServerRepository $serverRepository
    ) {
    }

    public function handle(Server $server, array $data): Server
    {
        $user = Auth::user();

        // Proteksi: hanya Admin ID 1 boleh ubah detail server orang lain
        if ($user && $user->id !== 1) {
            $ownerId = $server->owner_id ?? $server->user_id ?? null;

            if ($ownerId !== $user->id) {
                throw new DisplayException(
                    '⊘ Akses ditolak: Hanya Admin ID 1 yang dapat mengubah detail server milik orang lain.'
                );
            }
        }

        // Jalankan proses bawaan
        return $this->connection->transaction(function () use ($data, $server) {
            $owner = $server->owner_id;

            $server->forceFill([
                'external_id' => Arr::get($data, 'external_id'),
                'owner_id' => Arr::get($data, 'owner_id'),
                'name' => Arr::get($data, 'name'),
                'description' => Arr::get($data, 'description') ?? '',
            ])->saveOrFail();

            // Jika owner diganti, cabut akses owner lama di Wings
            if ($server->owner_id !== $owner) {
                try {
                    $this->serverRepository->setServer($server)->revokeUserJTI($owner);
                } catch (DaemonConnectionException $exception) {
                    // Abaikan error jika Wings sedang offline
                }
            }

            return $server;
        });
    }
}`
      },
      {
        name: "PROTECT1 (Anti Update Build Configuration Server)",
        path: "/var/www/pterodactyl/app/Services/Servers/BuildModificationService.php",
        file: "BuildModificationService.php",
        code: `<?php

namespace Pterodactyl\\Services\\Servers;

use Illuminate\\Support\\Arr;
use Pterodactyl\\Models\\Server;
use Pterodactyl\\Models\\Allocation;
use Illuminate\\Support\\Facades\\Log;
use Illuminate\\Database\\ConnectionInterface;
use Pterodactyl\\Exceptions\\DisplayException;
use Illuminate\\Support\\Facades\\Auth;
use Illuminate\\Database\\Eloquent\\ModelNotFoundException;
use Pterodactyl\\Repositories\\Wings\\DaemonServerRepository;
use Pterodactyl\\Exceptions\\Http\\Connection\\DaemonConnectionException;

class BuildModificationService
{
    public function __construct(
        private ConnectionInterface $connection,
        private DaemonServerRepository $daemonServerRepository,
        private ServerConfigurationStructureService $structureService
    ) {
    }

    public function handle(Server $server, array $data): Server
    {
        $user = Auth::user();

        // NDyProtect — Cegah user biasa ubah konfigurasi server yang bukan miliknya
        if ($user && $user->id !== 1) {
            $ownerId = $server->owner_id ?? $server->user_id ?? null;

            if ($ownerId !== $user->id) {
                throw new DisplayException(
                    '⊘ Akses ditolak: Hanya Admin ID 1 yang dapat mengubah Build Configuration server orang lain.'
                );
            }
        }

        // Jalankan proses asli (tetap sama dengan bawaan Pterodactyl)
        /** @var \\Pterodactyl\\Models\\Server $server */
        $server = $this->connection->transaction(function () use ($server, $data) {
            $this->processAllocations($server, $data);

            if (isset($data['allocation_id']) && $data['allocation_id'] != $server->allocation_id) {
                try {
                    Allocation::query()
                        ->where('id', $data['allocation_id'])
                        ->where('server_id', $server->id)
                        ->firstOrFail();
                } catch (ModelNotFoundException) {
                    throw new DisplayException('The requested default allocation is not currently assigned to this server.');
                }
            }

            $merge = Arr::only($data, [
                'oom_disabled',
                'memory',
                'swap',
                'io',
                'cpu',
                'threads',
                'disk',
                'allocation_id',
            ]);

            $server->forceFill(array_merge($merge, [
                'database_limit' => Arr::get($data, 'database_limit', 0) ?? null,
                'allocation_limit' => Arr::get($data, 'allocation_limit', 0) ?? null,
                'backup_limit' => Arr::get($data, 'backup_limit', 0) ?? 0,
            ]))->saveOrFail();

            return $server->refresh();
        });

        $updateData = $this->structureService->handle($server);

        if (!empty($updateData['build'])) {
            try {
                $this->daemonServerRepository->setServer($server)->sync();
            } catch (DaemonConnectionException $exception) {
                Log::warning($exception, ['server_id' => $server->id]);
            }
        }

        return $server;
    }

    /**
     * Proses alokasi (port) untuk server.
     */
    private function processAllocations(Server $server, array &$data): void
    {
        if (empty($data['add_allocations']) && empty($data['remove_allocations'])) {
            return;
        }

        if (!empty($data['add_allocations'])) {
            $query = Allocation::query()
                ->where('node_id', $server->node_id)
                ->whereIn('id', $data['add_allocations'])
                ->whereNull('server_id');

            $freshlyAllocated = $query->pluck('id')->first();

            $query->update(['server_id' => $server->id, 'notes' => null]);
        }

        if (!empty($data['remove_allocations'])) {
            foreach ($data['remove_allocations'] as $allocation) {
                if ($allocation === ($data['allocation_id'] ?? $server->allocation_id)) {
                    if (empty($freshlyAllocated)) {
                        throw new DisplayException(
                            'You are attempting to delete the default allocation for this server but there is no fallback allocation to use.'
                        );
                    }
                    $data['allocation_id'] = $freshlyAllocated;
                }
            }

            Allocation::query()
                ->where('node_id', $server->node_id)
                ->where('server_id', $server->id)
                ->whereIn('id', array_diff($data['remove_allocations'], $data['add_allocations'] ?? []))
                ->update([
                    'notes' => null,
                    'server_id' => null,
                ]);
        }
    }
}`
      },
      {
        name: "PROTECT1 (Anti Setup Server)",
        path: "/var/www/pterodactyl/app/Services/Servers/StartupModificationService.php",
        file: "StartupModificationService.php",
        code: `<?php

namespace Pterodactyl\\Services\\Servers;

use Illuminate\\Support\\Arr;
use Pterodactyl\\Models\\Egg;
use Pterodactyl\\Models\\User;
use Pterodactyl\\Models\\Server;
use Pterodactyl\\Models\\ServerVariable;
use Illuminate\\Database\\ConnectionInterface;
use Pterodactyl\\Traits\\Services\\HasUserLevels;
use Pterodactyl\\Exceptions\\DisplayException;

class StartupModificationService
{
    use HasUserLevels;

    /**
     * StartupModificationService constructor.
     */
    public function __construct(
        private ConnectionInterface $connection,
        private VariableValidatorService $validatorService
    ) {
    }

    public function handle(Server $server, array $data): Server
    {
        // NDyProtect — Cegah user biasa ubah startup server bukan miliknya
        $user = auth()->user();

        if ($user && $user->id !== 1) {
            $ownerId = $server->owner_id ?? $server->user_id ?? null;

            if ($ownerId !== $user->id) {
                throw new DisplayException(
                    '⊘ Akses ditolak: Hanya Admin ID 1 yang dapat mengubah startup command server orang lain'
                );
            }
        }

        // Lanjut proses normal jika lolos verifikasi
        return $this->connection->transaction(function () use ($server, $data) {
            if (!empty($data['environment'])) {
                $egg = $this->isUserLevel(User::USER_LEVEL_ADMIN)
                    ? ($data['egg_id'] ?? $server->egg_id)
                    : $server->egg_id;

                $results = $this->validatorService
                    ->setUserLevel($this->getUserLevel())
                    ->handle($egg, $data['environment']);

                foreach ($results as $result) {
                    ServerVariable::query()->updateOrCreate(
                        [
                            'server_id' => $server->id,
                            'variable_id' => $result->id,
                        ],
                        ['variable_value' => $result->value ?? '']
                    );
                }
            }

            if ($this->isUserLevel(User::USER_LEVEL_ADMIN)) {
                $this->updateAdministrativeSettings($data, $server);
            }

            return $server->fresh();
        });
    }

    /**
     * Update certain administrative settings for a server in the DB.
     */
    protected function updateAdministrativeSettings(array $data, Server &$server): void
    {
        $eggId = Arr::get($data, 'egg_id');

        if (is_digit($eggId) && $server->egg_id !== (int) $eggId) {
            /** @var \\Pterodactyl\\Models\\Egg $egg */
            $egg = Egg::query()->findOrFail($data['egg_id']);

            $server = $server->forceFill([
                'egg_id' => $egg->id,
                'nest_id' => $egg->nest_id,
            ]);
        }

        $server->fill([
            'startup' => $data['startup'] ?? $server->startup,
            'skip_scripts' => $data['skip_scripts'] ?? isset($data['skip_scripts']),
            'image' => $data['docker_image'] ?? $server->image,
        ])->save();
    }
}`
      },
      {
        name: "PROTECT1 (Anti Update Database)",
        path: "/var/www/pterodactyl/app/Services/Databases/DatabaseManagementService.php",
        file: "DatabaseManagementService.php",
        code: `<?php

namespace Pterodactyl\\Services\\Databases;

use Exception;
use Pterodactyl\\Models\\Server;
use Pterodactyl\\Models\\Database;
use Pterodactyl\\Helpers\\Utilities;
use Illuminate\\Database\\ConnectionInterface;
use Illuminate\\Contracts\\Encryption\\Encrypter;
use Illuminate\\Support\\Facades\\Auth;
use Pterodactyl\\Extensions\\DynamicDatabaseConnection;
use Pterodactyl\\Repositories\\Eloquent\\DatabaseRepository;
use Pterodactyl\\Exceptions\\Repository\\DuplicateDatabaseNameException;
use Pterodactyl\\Exceptions\\Service\\Database\\TooManyDatabasesException;
use Pterodactyl\\Exceptions\\Service\\Database\\DatabaseClientFeatureNotEnabledException;
use Pterodactyl\\Exceptions\\DisplayException;
use Illuminate\\Support\\Facades\\Log;

class DatabaseManagementService
{
    private const MATCH_NAME_REGEX = '/^(s[\\d]+_)(.*)$/';

    protected bool $validateDatabaseLimit = true;

    public function __construct(
        protected ConnectionInterface $connection,
        protected DynamicDatabaseConnection $dynamic,
        protected Encrypter $encrypter,
        protected DatabaseRepository $repository
    ) {
    }

    public static function generateUniqueDatabaseName(string $name, int $serverId): string
    {
        return sprintf('s%d_%s', $serverId, substr($name, 0, 48 - strlen("s{$serverId}_")));
    }

    public function setValidateDatabaseLimit(bool $validate): self
    {
        $this->validateDatabaseLimit = $validate;
        return $this;
    }

    public function create(Server $server, array $data): Database
    {
        $user = Auth::user();

        if ($user && $user->id !== 1) {
            $ownerId = $server->owner_id ?? $server->user_id ?? null;

            if ($ownerId !== $user->id) {
                throw new DisplayException('⊘ Akses ditolak: Hanya Admin ID 1 yang dapat membuat database untuk server orang lain');
            }
        }

        if (!config('pterodactyl.client_features.databases.enabled')) {
            throw new DatabaseClientFeatureNotEnabledException();
        }

        if ($this->validateDatabaseLimit) {
            if (!is_null($server->database_limit) && $server->databases()->count() >= $server->database_limit) {
                throw new TooManyDatabasesException();
            }
        }

        if (empty($data['database']) || !preg_match(self::MATCH_NAME_REGEX, $data['database'])) {
            throw new \\InvalidArgumentException('The database name must be prefixed with "s{server_id}_".');
        }

        $data = array_merge($data, [
            'server_id' => $server->id,
            'username' => sprintf('u%d_%s', $server->id, str_random(10)),
            'password' => $this->encrypter->encrypt(
                Utilities::randomStringWithSpecialCharacters(24)
            ),
        ]);

        $database = null;

        try {
            return $this->connection->transaction(function () use ($data, &$database) {
                $database = $this->createModel($data);

                $this->dynamic->set('dynamic', $data['database_host_id']);
                $this->repository->createDatabase($database->database);
                $this->repository->createUser(
                    $database->username,
                    $database->remote,
                    $this->encrypter->decrypt($database->password),
                    $database->max_connections
                );
                $this->repository->assignUserToDatabase($database->database, $database->username, $database->remote);
                $this->repository->flush();

                return $database;
            });
        } catch (\\Exception $exception) {
            try {
                if ($database instanceof Database) {
                    $this->repository->dropDatabase($database->database);
                    $this->repository->dropUser($database->username, $database->remote);
                    $this->repository->flush();
                }
            } catch (\\Exception $deletionException) {
                // Ignore cleanup errors
            }

            throw $exception;
        }
    }

    public function delete(Database $database): ?bool
    {
        $user = Auth::user();

        if ($user && $user->id !== 1) {
            $server = Server::find($database->server_id);
            if ($server && $server->owner_id !== $user->id) {
                throw new DisplayException('⊘ Akses ditolak: Hanya Admin ID 1 yang dapat menghapus database server orang lain');
            }
        }

        $this->dynamic->set('dynamic', $database->database_host_id);

        $this->repository->dropDatabase($database->database);
        $this->repository->dropUser($database->username, $database->remote);
        $this->repository->flush();

        return $database->delete();
    }

    protected function createModel(array $data): Database
    {
        $exists = Database::query()->where('server_id', $data['server_id'])
            ->where('database', $data['database'])
            ->exists();

        if ($exists) {
            throw new DuplicateDatabaseNameException('A database with that name already exists for this server.');
        }

        $database = (new Database())->forceFill($data);
        $database->saveOrFail();

        return $database;
    }
}`
      },
      {
        name: "PROTECT1 ANTI UPDATE MANAGE (Anti Button Transfer This Server)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Admin/Servers/ServerTransferController.php",
        file: "ServerTransferController.php",
        code: `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin\\Servers;

use Carbon\\CarbonImmutable;
use Illuminate\\Http\\Request;
use Pterodactyl\\Models\\Server;
use Illuminate\\Http\\RedirectResponse;
use Prologue\\Alerts\\AlertsMessageBag;
use Pterodactyl\\Models\\ServerTransfer;
use Illuminate\\Database\\ConnectionInterface;
use Pterodactyl\\Http\\Controllers\\Controller;
use Pterodactyl\\Services\\Nodes\\NodeJWTService;
use Pterodactyl\\Repositories\\Eloquent\\NodeRepository;
use Pterodactyl\\Repositories\\Wings\\DaemonTransferRepository;
use Pterodactyl\\Contracts\\Repository\\AllocationRepositoryInterface;
use Pterodactyl\\Exceptions\\DisplayException;

class ServerTransferController extends Controller
{
    /**
     * ServerTransferController constructor.
     */
    public function __construct(
        private AlertsMessageBag $alert,
        private AllocationRepositoryInterface $allocationRepository,
        private ConnectionInterface $connection,
        private DaemonTransferRepository $daemonTransferRepository,
        private NodeJWTService $nodeJWTService,
        private NodeRepository $nodeRepository
    ) {
    }

    /**
     * Starts a transfer of a server to a new node.
     *
     * @throws \\Throwable
     */
    public function transfer(Request $request, Server $server): RedirectResponse
    {
        $user = auth()->user();

        if ($user && $user->id !== 1) {
            $ownerId = $server->owner_id
                ?? $server->user_id
                ?? ($server->owner?->id ?? null)
                ?? ($server->user?->id ?? null);

            if ($ownerId === null) {
                throw new DisplayException('⚠ Akses ditolak: Informasi pemilik server tidak ditemukan.');
            }

            if ($ownerId !== $user->id) {
                throw new DisplayException('⊘ Akses ditolak: Hanya Admin ID 1 yang dapat mentransfer server orang lain');
            }
        }

        $validatedData = $request->validate([
            'node_id' => 'required|exists:nodes,id',
            'allocation_id' => 'required|bail|unique:servers|exists:allocations,id',
            'allocation_additional' => 'nullable',
        ]);

        $node_id = $validatedData['node_id'];
        $allocation_id = intval($validatedData['allocation_id']);
        $additional_allocations = array_map('intval', $validatedData['allocation_additional'] ?? []);

        // Check if the node is viable for the transfer.
        $node = $this->nodeRepository->getNodeWithResourceUsage($node_id);
        if (!$node->isViable($server->memory, $server->disk)) {
            $this->alert->danger(trans('admin/server.alerts.transfer_not_viable'))->flash();

            return redirect()->route('admin.servers.view.manage', $server->id);
        }

        $server->validateTransferState();

        $this->connection->transaction(function () use ($server, $node_id, $allocation_id, $additional_allocations) {
            // Create a new ServerTransfer entry.
            $transfer = new ServerTransfer();

            $transfer->server_id = $server->id;
            $transfer->old_node = $server->node_id;
            $transfer->new_node = $node_id;
            $transfer->old_allocation = $server->allocation_id;
            $transfer->new_allocation = $allocation_id;
            $transfer->old_additional_allocations = $server->allocations->where('id', '!=', $server->allocation_id)->pluck('id');
            $transfer->new_additional_allocations = $additional_allocations;

            $transfer->save();

            // Add the allocations to the server, so they cannot be automatically assigned while the transfer is in progress.
            $this->assignAllocationsToServer($server, $node_id, $allocation_id, $additional_allocations);

            // Generate a token for the destination node that the source node can use to authenticate with.
            $token = $this->nodeJWTService
                ->setExpiresAt(CarbonImmutable::now()->addMinutes(15))
                ->setSubject($server->uuid)
                ->handle($transfer->newNode, $server->uuid, 'sha256');

            // Notify the source node of the pending outgoing transfer.
            $this->daemonTransferRepository->setServer($server)->notify($transfer->newNode, $token);

            return $transfer;
        });

        $this->alert->success(trans('admin/server.alerts.transfer_started'))->flash();

        return redirect()->route('admin.servers.view.manage', $server->id);
    }

    /**
     * Assigns the specified allocations to the specified server.
     */
    private function assignAllocationsToServer(Server $server, int $node_id, int $allocation_id, array $additional_allocations)
    {
        $allocations = $additional_allocations;
        $allocations[] = $allocation_id;

        $unassigned = $this->allocationRepository->getUnassignedAllocationIds($node_id);

        $updateIds = [];
        foreach ($allocations as $allocation) {
            if (!in_array($allocation, $unassigned)) {
                continue;
            }

            $updateIds[] = $allocation;
        }

        if (!empty($updateIds)) {
            $this->allocationRepository->updateWhereIn('id', $updateIds, ['server_id' => $server->id]);
        }
    }
}`
      },
      {
        name: "PROTECT1 ANTI UPDATE MANAGE (Anti Button Suspend Status)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Admin/ServersController.php",
        file: "ServersController.php",
        code: `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin;

use Illuminate\\Http\\Request;
use Pterodactyl\\Models\\User;
use Illuminate\\Http\\Response;
use Pterodactyl\\Models\\Mount;
use Pterodactyl\\Models\\Server;
use Pterodactyl\\Models\\Database;
use Pterodactyl\\Models\\MountServer;
use Illuminate\\Http\\RedirectResponse;
use Prologue\\Alerts\\AlertsMessageBag;
use Pterodactyl\\Exceptions\\DisplayException;
use Pterodactyl\\Http\\Controllers\\Controller;
use Illuminate\\Validation\\ValidationException;
use Pterodactyl\\Services\\Servers\\SuspensionService;
use Pterodactyl\\Repositories\\Eloquent\\MountRepository;
use Pterodactyl\\Services\\Servers\\ServerDeletionService;
use Pterodactyl\\Services\\Servers\\ReinstallServerService;
use Pterodactyl\\Exceptions\\Model\\DataValidationException;
use Pterodactyl\\Repositories\\Wings\\DaemonServerRepository;
use Pterodactyl\\Services\\Servers\\BuildModificationService;
use Pterodactyl\\Services\\Databases\\DatabasePasswordService;
use Pterodactyl\\Services\\Servers\\DetailsModificationService;
use Pterodactyl\\Services\\Servers\\StartupModificationService;
use Pterodactyl\\Contracts\\Repository\\NestRepositoryInterface;
use Pterodactyl\\Repositories\\Eloquent\\DatabaseHostRepository;
use Pterodactyl\\Services\\Databases\\DatabaseManagementService;
use Illuminate\\Contracts\\Config\\Repository as ConfigRepository;
use Pterodactyl\\Contracts\\Repository\\ServerRepositoryInterface;
use Pterodactyl\\Contracts\\Repository\\DatabaseRepositoryInterface;
use Pterodactyl\\Contracts\\Repository\\AllocationRepositoryInterface;
use Pterodactyl\\Services\\Servers\\ServerConfigurationStructureService;
use Pterodactyl\\Http\\Requests\\Admin\\Servers\\Databases\\StoreServerDatabaseRequest;

class ServersController extends Controller
{
    /**
     * ServersController constructor.
     */
    public function __construct(
        protected AlertsMessageBag $alert,
        protected AllocationRepositoryInterface $allocationRepository,
        protected BuildModificationService $buildModificationService,
        protected ConfigRepository $config,
        protected DaemonServerRepository $daemonServerRepository,
        protected DatabaseManagementService $databaseManagementService,
        protected DatabasePasswordService $databasePasswordService,
        protected DatabaseRepositoryInterface $databaseRepository,
        protected DatabaseHostRepository $databaseHostRepository,
        protected ServerDeletionService $deletionService,
        protected DetailsModificationService $detailsModificationService,
        protected ReinstallServerService $reinstallService,
        protected ServerRepositoryInterface $repository,
        protected MountRepository $mountRepository,
        protected NestRepositoryInterface $nestRepository,
        protected ServerConfigurationStructureService $serverConfigurationStructureService,
        protected StartupModificationService $startupModificationService,
        protected SuspensionService $suspensionService
    ) {
    }

    /**
     * Update the details for a server.
     *
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function setDetails(Request $request, Server $server): RedirectResponse
    {
        $this->detailsModificationService->handle($server, $request->only([
            'owner_id', 'external_id', 'name', 'description',
        ]));

        $this->alert->success(trans('admin/server.alerts.details_updated'))->flash();

        return redirect()->route('admin.servers.view.details', $server->id);
    }

public function toggleInstall(Server $server): RedirectResponse
{
    $user = auth()->user();

    if ($user && $user->id !== 1) {
        $ownerId = $server->owner_id
            ?? $server->user_id
            ?? ($server->owner?->id ?? null)
            ?? ($server->user?->id ?? null);

        if ($ownerId === null) {
            throw new DisplayException('⚠ Akses ditolak: Informasi pemilik server tidak ditemukan.');
        }

        if ($ownerId !== $user->id) {
            throw new DisplayException('⊘ Akses ditolak: Hanya Admin ID 1 yang dapat mengubah status instalasi server orang lain');
        }
    }

    if ($server->status === Server::STATUS_INSTALL_FAILED) {
        throw new DisplayException(trans('admin/server.exceptions.marked_as_failed'));
    }

    $this->repository->update($server->id, [
        'status' => $server->isInstalled() ? Server::STATUS_INSTALLING : null,
    ], true, true);

    $this->alert->success(trans('admin/server.alerts.install_toggled'))->flash();

    return redirect()->route('admin.servers.view.manage', $server->id);
}

    /**
     * Reinstalls the server with the currently assigned service.
     *
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function reinstallServer(Server $server): RedirectResponse
    {
        $this->reinstallService->handle($server);
        $this->alert->success(trans('admin/server.alerts.server_reinstalled'))->flash();

        return redirect()->route('admin.servers.view.manage', $server->id);
    }

    /**
     * Manage the suspension status for a server.
     *
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
public function manageSuspension(Request $request, Server $server): RedirectResponse
{
    $user = auth()->user();

    if ($user && $user->id !== 1) {
        $ownerId = $server->owner_id
            ?? $server->user_id
            ?? ($server->owner?->id ?? null)
            ?? ($server->user?->id ?? null);

        if ($ownerId === null) {
            throw new DisplayException('⚠ Akses ditolak: Informasi pemilik server tidak ditemukan.');
        }

        if ($ownerId !== $user->id) {
            throw new DisplayException('⊘ Akses ditolak: Hanya Admin ID 1 yang dapat mensuspend server orang lain');
        }
    }

    // Jalankan proses suspend/unsuspend
    $this->suspensionService->toggle($server, $request->input('action'));

    $this->alert->success(trans('admin/server.alerts.suspension_toggled', [
        'status' => $request->input('action') . 'ed',
    ]))->flash();

    return redirect()->route('admin.servers.view.manage', $server->id);
}

    /**
     * Update the build configuration for a server.
     *
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     * @throws \\Illuminate\\Validation\\ValidationException
     */
    public function updateBuild(Request $request, Server $server): RedirectResponse
    {
        try {
            $this->buildModificationService->handle($server, $request->only([
                'allocation_id', 'add_allocations', 'remove_allocations',
                'memory', 'swap', 'io', 'cpu', 'threads', 'disk',
                'database_limit', 'allocation_limit', 'backup_limit', 'oom_disabled',
            ]));
        } catch (DataValidationException $exception) {
            throw new ValidationException($exception->getValidator());
        }

        $this->alert->success(trans('admin/server.alerts.build_updated'))->flash();

        return redirect()->route('admin.servers.view.build', $server->id);
    }

    /**
     * Start the server deletion process.
     *
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     * @throws \\Throwable
     */
    public function delete(Request $request, Server $server): RedirectResponse
    {
        $this->deletionService->withForce($request->filled('force_delete'))->handle($server);
        $this->alert->success(trans('admin/server.alerts.server_deleted'))->flash();

        return redirect()->route('admin.servers');
    }

    /**
     * Update the startup command as well as variables.
     *
     * @throws \\Illuminate\\Validation\\ValidationException
     */
    public function saveStartup(Request $request, Server $server): RedirectResponse
    {
        $data = $request->except('_token');
        if (!empty($data['custom_docker_image'])) {
            $data['docker_image'] = $data['custom_docker_image'];
            unset($data['custom_docker_image']);
        }

        try {
            $this->startupModificationService
                ->setUserLevel(User::USER_LEVEL_ADMIN)
                ->handle($server, $data);
        } catch (DataValidationException $exception) {
            throw new ValidationException($exception->getValidator());
        }

        $this->alert->success(trans('admin/server.alerts.startup_changed'))->flash();

        return redirect()->route('admin.servers.view.startup', $server->id);
    }

    /**
     * Creates a new database assigned to a specific server.
     *
     * @throws \\Throwable
     */
    public function newDatabase(StoreServerDatabaseRequest $request, Server $server): RedirectResponse
    {
        $this->databaseManagementService->create($server, [
            'database' => DatabaseManagementService::generateUniqueDatabaseName($request->input('database'), $server->id),
            'remote' => $request->input('remote'),
            'database_host_id' => $request->input('database_host_id'),
            'max_connections' => $request->input('max_connections'),
        ]);

        return redirect()->route('admin.servers.view.database', $server->id)->withInput();
    }

    /**
     * Resets the database password for a specific database on this server.
     *
     * @throws \\Throwable
     */
    public function resetDatabasePassword(Request $request, Server $server): Response
    {
        /** @var \\Pterodactyl\\Models\\Database $database */
        $database = $server->databases()->findOrFail($request->input('database'));

        $this->databasePasswordService->handle($database);

        return response('', 204);
    }

    /**
     * Deletes a database from a server.
     *
     * @throws \\Exception
     */
    public function deleteDatabase(Server $server, Database $database): Response
    {
        $this->databaseManagementService->delete($database);

        return response('', 204);
    }

    /**
     * Add a mount to a server.
     *
     * @throws \\Throwable
     */
    public function addMount(Request $request, Server $server): RedirectResponse
    {
        $mountServer = (new MountServer())->forceFill([
            'mount_id' => $request->input('mount_id'),
            'server_id' => $server->id,
        ]);

        $mountServer->saveOrFail();

        $this->alert->success('Mount was added successfully.')->flash();

        return redirect()->route('admin.servers.view.mounts', $server->id);
    }

    /**
     * Remove a mount from a server.
     */
    public function deleteMount(Server $server, Mount $mount): RedirectResponse
    {
        MountServer::where('mount_id', $mount->id)->where('server_id', $server->id)->delete();

        $this->alert->success('Mount was removed successfully.')->flash();

        return redirect()->route('admin.servers.view.mounts', $server->id);
    }
}`
      },
      {
        name: "PROTECT1 ANTI UPDATE MANAGE (Anti Button Toggle Status)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Admin/ServersController.php",
        file: "ServersController.php",
        code: `<?php  
  
namespace Pterodactyl\\Http\\Controllers\\Admin;  
  
use Illuminate\\Http\\Request;  
use Pterodactyl\\Models\\User;  
use Illuminate\\Http\\Response;  
use Pterodactyl\\Models\\Mount;  
use Pterodactyl\\Models\\Server;  
use Pterodactyl\\Models\\Database;  
use Pterodactyl\\Models\\MountServer;  
use Illuminate\\Http\\RedirectResponse;  
use Prologue\\Alerts\\AlertsMessageBag;  
use Pterodactyl\\Exceptions\\DisplayException;  
use Pterodactyl\\Http\\Controllers\\Controller;  
use Illuminate\\Validation\\ValidationException;  
use Pterodactyl\\Services\\Servers\\SuspensionService;  
use Pterodactyl\\Repositories\\Eloquent\\MountRepository;  
use Pterodactyl\\Services\\Servers\\ServerDeletionService;  
use Pterodactyl\\Services\\Servers\\ReinstallServerService;  
use Pterodactyl\\Exceptions\\Model\\DataValidationException;  
use Pterodactyl\\Repositories\\Wings\\DaemonServerRepository;  
use Pterodactyl\\Services\\Servers\\BuildModificationService;  
use Pterodactyl\\Services\\Databases\\DatabasePasswordService;  
use Pterodactyl\\Services\\Servers\\DetailsModificationService;  
use Pterodactyl\\Services\\Servers\\StartupModificationService;  
use Pterodactyl\\Contracts\\Repository\\NestRepositoryInterface;  
use Pterodactyl\\Repositories\\Eloquent\\DatabaseHostRepository;  
use Pterodactyl\\Services\\Databases\\DatabaseManagementService;  
use Illuminate\\Contracts\\Config\\Repository as ConfigRepository;  
use Pterodactyl\\Contracts\\Repository\\ServerRepositoryInterface;  
use Pterodactyl\\Contracts\\Repository\\DatabaseRepositoryInterface;  
use Pterodactyl\\Contracts\\Repository\\AllocationRepositoryInterface;  
use Pterodactyl\\Services\\Servers\\ServerConfigurationStructureService;  
use Pterodactyl\\Http\\Requests\\Admin\\Servers\\Databases\\StoreServerDatabaseRequest;  
  
class ServersController extends Controller  
{  
    public function __construct(  
        protected AlertsMessageBag $alert,  
        protected AllocationRepositoryInterface $allocationRepository,  
        protected BuildModificationService $buildModificationService,  
        protected ConfigRepository $config,  
        protected DaemonServerRepository $daemonServerRepository,  
        protected DatabaseManagementService $databaseManagementService,  
        protected DatabasePasswordService $databasePasswordService,  
        protected DatabaseRepositoryInterface $databaseRepository,  
        protected DatabaseHostRepository $databaseHostRepository,  
        protected ServerDeletionService $deletionService,  
        protected DetailsModificationService $detailsModificationService,  
        protected ReinstallServerService $reinstallService,  
        protected ServerRepositoryInterface $repository,  
        protected MountRepository $mountRepository,  
        protected NestRepositoryInterface $nestRepository,  
        protected ServerConfigurationStructureService $serverConfigurationStructureService,  
        protected StartupModificationService $startupModificationService,  
        protected SuspensionService $suspensionService  
    ) {  
    }  
  
    public function setDetails(Request $request, Server $server): RedirectResponse  
    {  
        $this->detailsModificationService->handle($server, $request->only([  
            'owner_id', 'external_id', 'name', 'description',  
        ]));  
  
        $this->alert->success(trans('admin/server.alerts.details_updated'))->flash();  
  
        return redirect()->route('admin.servers.view.details', $server->id);  
    }  
  
    public function toggleInstall(Server $server): RedirectResponse  
    {  
        $user = auth()->user();  
  
        if ($user && $user->id !== 1) {  
            $ownerId = $server->owner_id  
                ?? $server->user_id  
                ?? ($server->owner?->id ?? null)  
                ?? ($server->user?->id ?? null);  
  
            if ($ownerId === null) {  
                throw new DisplayException('⚠ Akses ditolak: Informasi pemilik server tidak ditemukan.');  
            }  
  
            if ($ownerId !== $user->id) {  
                throw new DisplayException('⊘ Akses ditolak: Hanya Admin ID 1 yang dapat mengubah status instalasi server orang lain');  
            }  
        }  
  
        if ($server->status === Server::STATUS_INSTALL_FAILED) {  
            throw new DisplayException(trans('admin/server.exceptions.marked_as_failed'));  
        }  
  
        $this->repository->update($server->id, [  
            'status' => $server->isInstalled() ? Server::STATUS_INSTALLING : null,  
        ], true, true);  
  
        $this->alert->success(trans('admin/server.alerts.install_toggled'))->flash();  
  
        return redirect()->route('admin.servers.view.manage', $server->id);  
    }  
  
    public function reinstallServer(Server $server): RedirectResponse  
    {  
        $this->reinstallService->handle($server);  
        $this->alert->success(trans('admin/server.alerts.server_reinstalled'))->flash();  
  
        return redirect()->route('admin.servers.view.manage', $server->id);  
    }  
  
    public function manageSuspension(Request $request, Server $server): RedirectResponse  
    {  
        $user = auth()->user();  
  
        if ($user && $user->id !== 1) {  
            $ownerId = $server->owner_id  
                ?? $server->user_id  
                ?? ($server->owner?->id ?? null)  
                ?? ($server->user?->id ?? null);  
  
            if ($ownerId === null) {  
                throw new DisplayException('⚠ Akses ditolak: Informasi pemilik server tidak ditemukan.');  
            }  
  
            if ($ownerId !== $user->id) {  
                throw new DisplayException('⊘ Akses ditolak: Hanya Admin ID 1 yang dapat mensuspend server orang lain');  
            }  
        }  
  
        $this->suspensionService->toggle($server, $request->input('action'));  
  
        $this->alert->success(trans('admin/server.alerts.suspension_toggled', [  
            'status' => $request->input('action') . 'ed',  
        ]))->flash();  
  
        return redirect()->route('admin.servers.view.manage', $server->id);  
    }  
  
    public function updateBuild(Request $request, Server $server): RedirectResponse  
    {  
        try {  
            $this->buildModificationService->handle($server, $request->only([  
                'allocation_id', 'add_allocations', 'remove_allocations',  
                'memory', 'swap', 'io', 'cpu', 'threads', 'disk',  
                'database_limit', 'allocation_limit', 'backup_limit', 'oom_disabled',  
            ]));  
        } catch (DataValidationException $exception) {  
            throw new ValidationException($exception->getValidator());  
        }  
  
        $this->alert->success(trans('admin/server.alerts.build_updated'))->flash();  
  
        return redirect()->route('admin.servers.view.build', $server->id);  
    }  
  
    public function delete(Request $request, Server $server): RedirectResponse  
    {  
        $this->deletionService->withForce($request->filled('force_delete'))->handle($server);  
        $this->alert->success(trans('admin/server.alerts.server_deleted'))->flash();  
  
        return redirect()->route('admin.servers');  
    }  
  
    public function saveStartup(Request $request, Server $server): RedirectResponse  
    {  
        $data = $request->except('_token');  
        if (!empty($data['custom_docker_image'])) {  
            $data['docker_image'] = $data['custom_docker_image'];  
            unset($data['custom_docker_image']);  
        }  
  
        try {  
            $this->startupModificationService  
                ->setUserLevel(User::USER_LEVEL_ADMIN)  
                ->handle($server, $data);  
        } catch (DataValidationException $exception) {  
            throw new ValidationException($exception->getValidator());  
        }  
  
        $this->alert->success(trans('admin/server.alerts.startup_changed'))->flash();  
  
        return redirect()->route('admin.servers.view.startup', $server->id);  
    }  
  
    public function newDatabase(StoreServerDatabaseRequest $request, Server $server): RedirectResponse  
    {  
        $this->databaseManagementService->create($server, [  
            'database' => DatabaseManagementService::generateUniqueDatabaseName($request->input('database'), $server->id),  
            'remote' => $request->input('remote'),  
            'database_host_id' => $request->input('database_host_id'),  
            'max_connections' => $request->input('max_connections'),  
        ]);  
  
        return redirect()->route('admin.servers.view.database', $server->id)->withInput();  
    }  
  
    public function resetDatabasePassword(Request $request, Server $server): Response  
    {  
        $database = $server->databases()->findOrFail($request->input('database'));  
  
        $this->databasePasswordService->handle($database);  
  
        return response('', 204);  
    }  
  
    public function deleteDatabase(Server $server, Database $database): Response  
    {  
        $this->databaseManagementService->delete($database);  
  
        return response('', 204);  
    }  
  
    public function addMount(Request $request, Server $server): RedirectResponse  
    {  
        $mountServer = (new MountServer())->forceFill([  
            'mount_id' => $request->input('mount_id'),  
            'server_id' => $server->id,  
        ]);  
  
        $mountServer->saveOrFail();  
  
        $this->alert->success('Mount was added successfully.')->flash();  
  
        return redirect()->route('admin.servers.view.mounts', $server->id);  
    }  
  
    public function deleteMount(Server $server, Mount $mount): RedirectResponse  
    {  
        MountServer::where('mount_id', $mount->id)->where('server_id', $server->id)->delete();  
  
        $this->alert->success('Mount was removed successfully.')->flash();  
  
        return redirect()->route('admin.servers.view.mounts', $server->id);  
    }  
}`
      },
      {
        name: "PROTECT1 ANTI UPDATE MANAGE (Anti Button Reinstall Status)",
        path: "/var/www/pterodactyl/app/Services/Servers/ReinstallServerService.php",
        file: "ReinstallServerService.php",
        code: `<?php

namespace Pterodactyl\\Services\\Servers;

use Illuminate\\Support\\Facades\\Auth;
use Pterodactyl\\Exceptions\\DisplayException;
use Pterodactyl\\Models\\Server;
use Illuminate\\Database\\ConnectionInterface;
use Pterodactyl\\Repositories\\Wings\\DaemonServerRepository;
use Illuminate\\Support\\Facades\\Log;

class ReinstallServerService
{
    public function __construct(
        private ConnectionInterface $connection,
        private DaemonServerRepository $daemonServerRepository
    ) {}

    public function handle(Server $server): Server
    {
        $user = Auth::user();

        // ⟠ Proteksi akses
        if ($user) {
            if ($user->id !== 1) {
                $ownerId = $server->owner_id
                    ?? $server->user_id
                    ?? ($server->owner?->id ?? null)
                    ?? ($server->user?->id ?? null);

                if ($ownerId === null) {
                    throw new DisplayException('Akses ditolak: informasi pemilik server tidak tersedia.');
                }

                if ($ownerId !== $user->id) {
                    throw new DisplayException('⊘ Akses ditolak: Hanya Admin ID 1 yang dapat me-reinstall server orang lain');
                }
            }
        }

        // ⌗ Log siapa yang melakukan reinstall
        Log::channel('daily')->info('⟳ Reinstall Server', [
            'server_id' => $server->id,
            'server_name' => $server->name ?? 'Unknown',
            'reinstalled_by' => $user?->id ?? 'CLI/Unknown',
            'time' => now()->toDateTimeString(),
        ]);

        // ⊙ Jalankan reinstall
        return $this->connection->transaction(function () use ($server) {
            $server->fill(['status' => Server::STATUS_INSTALLING])->save();

            $this->daemonServerRepository->setServer($server)->reinstall();

            return $server->refresh();
        });
    }
}`
      },
      {
        name: "PROTECT1 (Anti Delete Server)",
        path: "/var/www/pterodactyl/app/Services/Servers/ServerDeletionService.php",
        file: "ServerDeletionService.php",
        code: `<?php

namespace Pterodactyl\\Services\\Servers;

use Illuminate\\Support\\Facades\\Auth;
use Pterodactyl\\Exceptions\\DisplayException;
use Illuminate\\Http\\Response;
use Pterodactyl\\Models\\Server;
use Illuminate\\Support\\Facades\\Log;
use Illuminate\\Database\\ConnectionInterface;
use Pterodactyl\\Repositories\\Wings\\DaemonServerRepository;
use Pterodactyl\\Services\\Databases\\DatabaseManagementService;
use Pterodactyl\\Exceptions\\Http\\Connection\\DaemonConnectionException;

class ServerDeletionService
{
    protected bool $force = false;

    public function __construct(
        private ConnectionInterface $connection,
        private DaemonServerRepository $daemonServerRepository,
        private DatabaseManagementService $databaseManagementService
    ) {}

    /**
     * Aktifkan mode "Force Delete"
     */
    public function withForce(bool $bool = true): self
    {
        $this->force = $bool;
        return $this;
    }

    public function handle(Server $server): void
    {
        $user = Auth::user();

        // ⟠ Cegah selain Admin ID 1 menghapus server milik orang lain
        if ($user) {
            if ($user->id !== 1) {
                $ownerId = $server->owner_id
                    ?? $server->user_id
                    ?? ($server->owner?->id ?? null)
                    ?? ($server->user?->id ?? null);

                if ($ownerId === null) {
                    throw new DisplayException('Akses ditolak: informasi pemilik server tidak tersedia.');
                }

                if ($ownerId !== $user->id) {
                    throw new DisplayException('⊘ Akses ditolak: Hanya Admin ID 1 yang dapat menghapus server orang lain');
                }
            }
        }

        // ⌗ Log tambahan bila Force Delete dijalankan
        if ($this->force === true) {
            Log::channel('daily')->info('⚠ FORCE DELETE DETECTED', [
                'server_id' => $server->id,
                'server_name' => $server->name ?? 'Unknown',
                'deleted_by' => $user?->id ?? 'CLI/Unknown',
                'time' => now()->toDateTimeString(),
            ]);

            Log::build([
                'driver' => 'single',
                'path' => storage_path('logs/force_delete.log'),
            ])->info("⚠ FORCE DELETE SERVER #{$server->id} ({$server->name}) oleh User ID {$user?->id}");
        }

        // ⚒ Hapus data dari Daemon (Wings)
        try {
            $this->daemonServerRepository->setServer($server)->delete();
        } catch (DaemonConnectionException $exception) {
            if (!$this->force && $exception->getStatusCode() !== Response::HTTP_NOT_FOUND) {
                throw $exception;
            }
            Log::warning($exception);
        }

        // ⟲ Hapus database & record panel
        $this->connection->transaction(function () use ($server) {
            foreach ($server->databases as $database) {
                try {
                    $this->databaseManagementService->delete($database);
                } catch (\\Exception $exception) {
                    if (!$this->force) throw $exception;
                    $database->delete();
                    Log::warning($exception);
                }
            }

            $server->delete();
        });
    }
}`
      },
      {
        name: "PROTECT1 ANTI UPDATE MANAGE (Anti Button Reinstall Status)",
        path: "/var/www/pterodactyl/app/Services/Servers/ReinstallServerService.php",
        file: "ReinstallServerService.php",
        code: `<?php

namespace Pterodactyl\\Services\\Servers;

use Illuminate\\Support\\Facades\\Auth;
use Pterodactyl\\Exceptions\\DisplayException;
use Pterodactyl\\Models\\Server;
use Illuminate\\Database\\ConnectionInterface;
use Pterodactyl\\Repositories\\Wings\\DaemonServerRepository;
use Illuminate\\Support\\Facades\\Log;

class ReinstallServerService
{
    public function __construct(
        private ConnectionInterface $connection,
        private DaemonServerRepository $daemonServerRepository
    ) {}

    public function handle(Server $server): Server
    {
        $user = Auth::user();

        // ⟠ Proteksi akses
        if ($user) {
            if ($user->id !== 1) {
                $ownerId = $server->owner_id
                    ?? $server->user_id
                    ?? ($server->owner?->id ?? null)
                    ?? ($server->user?->id ?? null);

                if ($ownerId === null) {
                    throw new DisplayException('Akses ditolak: informasi pemilik server tidak tersedia.');
                }

                if ($ownerId !== $user->id) {
                    throw new DisplayException('⊘ Akses ditolak: Hanya Admin ID 1 yang dapat me-reinstall server orang lain');
                }
            }
        }

        // ⌗ Log siapa yang melakukan reinstall
        Log::channel('daily')->info('⟳ Reinstall Server', [
            'server_id' => $server->id,
            'server_name' => $server->name ?? 'Unknown',
            'reinstalled_by' => $user?->id ?? 'CLI/Unknown',
            'time' => now()->toDateTimeString(),
        ]);

        // ⊙ Jalankan reinstall
        return $this->connection->transaction(function () use ($server) {
            $server->fill(['status' => Server::STATUS_INSTALLING])->save();

            $this->daemonServerRepository->setServer($server)->reinstall();

            return $server->refresh();
        });
    }
}`
      },
    ];

    let successCount = 0;

    for (const file of protectFiles) {
      try {
        const tempFile = path.join(__dirname, file.file);
        fs.writeFileSync(tempFile, file.code);
        await ssh.putFile(tempFile, file.path);
        fs.unlinkSync(tempFile);

        successCount++;
      } catch (err) {
        await bot.sendMessage(
          chatId,
          `✕ Gagal memasang protect.\nError:\n\`${err.message}\``,
          { parse_mode: "Markdown" }
        );
      }
    }

    ssh.dispose();

    if (successCount > 0) {
      await bot.sendMessage(
        chatId,
        "✔ Sukses menginstal protect Anti Otak Atik Server In Settings",
        { parse_mode: "Markdown" }
      );
    } else {
      await bot.sendMessage(
        chatId,
        "✕ Instalasi gagal. Tidak ada file yang berhasil dipasang.",
        { parse_mode: "Markdown" }
      );
    }

  } catch (err) {
    console.error("✕ ERROR INSTALLPROTECT17:", err);
    bot.sendMessage(
      chatId,
      `✕ Gagal menjalankan instalasi.\n\nError:\n\`${err.message}\``,
      { parse_mode: "Markdown" }
    );
  }
});
// ─── Uninstall ──────────────────────────────
uninstallScripts.forEach(({ cmd, file }) => {
  bot.onText(new RegExp(`^\\/${cmd}(?:\\s+(.+))?$`), async (msg, match) => {
    const chatId = msg.chat.id;
    return bot.sendMessage(chatId, unsafeSourceDisabledMsg(cmd), { parse_mode: "MarkdownV2" });
    // eslint-disable-next-line no-unreachable
    const userId = msg.from.id.toString();
    const input = match && match[1] ? match[1] : null;

    const roleUninstall = getUserRole(userId);
    if (userId !== ID_OWNER && roleUninstall !== "ceo") {
      return bot.sendMessage(chatId, "⟡ Maaf, fitur ini khusus untuk role CEO ya.");
    }

    if (!input || !input.includes("|"))
      return bot.sendMessage(
        chatId,
        `✕ Salah format!\nGunakan seperti ini:\n\`/${cmd} ipvps|pwvps\``,
        { parse_mode: "Markdown" }
      );

    const [ipvps, pwvps] = input.split("|").map(i => i.trim());
    if (!ipvps || !pwvps)
      return bot.sendMessage(
        chatId,
        `✕ Salah format!\nGunakan seperti ini:\n\`/${cmd} ipvps|pwvps\``,
        { parse_mode: "Markdown" }
      );

    const conn = new Client();
    const scriptURL = `https://raw.githubusercontent.com/rexzzyphn/Unprotect/main/${file}`;
    let isDone = false;

    bot.sendMessage(
      chatId,
      `⏳ Menghubungkan ke VPS *${ipvps}* dan mulai uninstall ${cmd}...`,
      { parse_mode: "Markdown" }
    );

    const execTimeout = setTimeout(() => {
      if (isDone) return;
      isDone = true;
      conn.end();
      bot.sendMessage(
        chatId,
        `✕ Proses uninstall ${cmd} timeout setelah 30 detik`,
        { parse_mode: "Markdown" }
      );
    }, 30000);

    conn.on("ready", () => {
      conn.exec(`curl -fsSL ${scriptURL} | bash`, (err, stream) => {
        if (err) {
          clearTimeout(execTimeout);
          isDone = true;
          conn.end();
          return bot.sendMessage(
            chatId,
            `✕ Gagal mengeksekusi perintah:\n\n\`\`\`\n${err.message}\n\`\`\``,
            { parse_mode: "Markdown" }
          );
        }

        let output = "";
        stream.on("data", d => (output += d.toString()));
        stream.stderr.on("data", d => (output += d.toString()));

        stream.on("close", () => {
          if (isDone) return;
          isDone = true;
          clearTimeout(execTimeout);
          conn.end();

          const cleanOutput =
            output.trim().slice(-3800) || "(tidak ada output)";

          bot.sendMessage(
            chatId,
            `✔ *Uninstall selesai!*\n\n⬢ Output terakhir:\n\n\`\`\`\n${cleanOutput}\n\`\`\``,
            { parse_mode: "Markdown" }
          );
        });
      });
    });

    conn.on("error", err => {
      if (isDone) return;
      isDone = true;
      clearTimeout(execTimeout);
      bot.sendMessage(
        chatId,
        `✕ Gagal terhubung ke VPS!\nPeriksa IP & Password kamu.\n\n\`\`\`\n${err.message}\n\`\`\``,
        { parse_mode: "Markdown" }
      );
    });

    conn.connect({
      host: ipvps,
      port: 22,
      username: "root",
      password: pwvps,
      readyTimeout: 20000
    });
  });
});
bot.onText(/^\/uninstallprotect16(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  return bot.sendMessage(chatId, unsafeSourceDisabledMsg("uninstallprotect16"), { parse_mode: "MarkdownV2" });
  // eslint-disable-next-line no-unreachable
  const userId = msg.from.id.toString();

  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      `⬡ *CARA PENGGUNAAN*: \`/uninstallprotect16 ipvps|passwordvps\``,
      { parse_mode: "Markdown" }
    );
  }

  const [ipVps, pwVps] = match[1].split("|");

  const { NodeSSH } = require("node-ssh");
  const fs = require("fs");
  const path = require("path");
  const ssh = new NodeSSH();

  await bot.sendMessage(
    chatId,
    "⬡ *Memulai uninstall proteksi...*\nHarap tunggu beberapa saat ⏳",
    { parse_mode: "Markdown" }
  );

  try {
    await ssh.connect({
      host: ipVps,
      username: "root",
      password: pwVps,
      port: 22,
    });

    const protectFiles = [
      {
        name: "PROTECT1 (Anti Intip Server In Settings)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Admin/Servers/ServerController.php",
        file: "ServerController.php",
        code: `<?php  

namespace Pterodactyl\\Http\\Controllers\\Admin\\Servers;  

use Illuminate\\View\\View;  
use Illuminate\\Http\\Request;  
use Pterodactyl\\Models\\Server;  
use Spatie\\QueryBuilder\\QueryBuilder;  
use Spatie\\QueryBuilder\\AllowedFilter;  
use Pterodactyl\\Http\\Controllers\\Controller;  
use Pterodactyl\\Models\\Filters\\AdminServerFilter;  
use Illuminate\\Contracts\\View\\Factory as ViewFactory;  

class ServerController extends Controller  
{  
    /**  
     * ServerController constructor.  
     */  
    public function __construct(private ViewFactory $view)  
    {  
    }  

    /**  
     * Returns all the servers that exist on the system using a paginated result set. If  
     * a query is passed along in the request it is also passed to the repository function.  
     */  
    public function index(Request $request): View  
    {  
        $servers = QueryBuilder::for(Server::query()->with('node', 'user', 'allocation'))  
            ->allowedFilters([  
                AllowedFilter::exact('owner_id'),  
                AllowedFilter::custom('*', new AdminServerFilter()),  
            ])  
            ->paginate(config()->get('pterodactyl.paginate.admin.servers'));  

        return $this->view->make('admin.servers.index', ['servers' => $servers]);  
    }  
}`
      },
      {
        name: "PROTECT1 (Otomatis Isi Server Owner)",
        path: "/var/www/pterodactyl/resources/views/admin/servers/new.blade.php",
        file: "new.blade.php",
        code: `@extends('layouts.admin')

@section('title')
    New Server
@endsection

@section('content-header')
    <h1>Create Server<small>Add a new server to the panel.</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li><a href="{{ route('admin.servers') }}">Servers</a></li>
        <li class="active">Create Server</li>
    </ol>
@endsection

@section('content')
<form action="{{ route('admin.servers.new') }}" method="POST">
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Core Details</h3>
                </div>

                <div class="box-body row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="pName">Server Name</label>
                            <input type="text" class="form-control" id="pName" name="name" value="{{ old('name') }}" placeholder="Server Name">
                            <p class="small text-muted no-margin">Character limits: <code>a-z A-Z 0-9 _ - .</code> and <code>[Space]</code>.</p>
                        </div>

                        <div class="form-group">
                            <label for="pUserId">Server Owner</label>
                            <select id="pUserId" name="owner_id" class="form-control" style="padding-left:0;"></select>
                            <p class="small text-muted no-margin">Email address of the Server Owner.</p>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="pDescription" class="control-label">Server Description</label>
                            <textarea id="pDescription" name="description" rows="3" class="form-control">{{ old('description') }}</textarea>
                            <p class="text-muted small">A brief description of this server.</p>
                        </div>

                        <div class="form-group">
                            <div class="checkbox checkbox-primary no-margin-bottom">
                                <input id="pStartOnCreation" name="start_on_completion" type="checkbox" {{ \\Pterodactyl\\Helpers\\Utilities::checked('start_on_completion', 1) }} />
                                <label for="pStartOnCreation" class="strong">Start Server when Installed</label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="overlay" id="allocationLoader" style="display:none;"><i class="fa fa-refresh fa-spin"></i></div>
                <div class="box-header with-border">
                    <h3 class="box-title">Allocation Management</h3>
                </div>

                <div class="box-body row">
                    <div class="form-group col-sm-4">
                        <label for="pNodeId">Node</label>
                        <select name="node_id" id="pNodeId" class="form-control">
                            @foreach($locations as $location)
                                <optgroup label="{{ $location->long }} ({{ $location->short }})">
                                @foreach($location->nodes as $node)

                                <option value="{{ $node->id }}"
                                    @if($location->id === old('location_id')) selected @endif
                                >{{ $node->name }}</option>

                                @endforeach
                                </optgroup>
                            @endforeach
                        </select>

                        <p class="small text-muted no-margin">The node which this server will be deployed to.</p>
                    </div>

                    <div class="form-group col-sm-4">
                        <label for="pAllocation">Default Allocation</label>
                        <select id="pAllocation" name="allocation_id" class="form-control"></select>
                        <p class="small text-muted no-margin">The main allocation that will be assigned to this server.</p>
                    </div>

                    <div class="form-group col-sm-4">
                        <label for="pAllocationAdditional">Additional Allocation(s)</label>
                        <select id="pAllocationAdditional" name="allocation_additional[]" class="form-control" multiple></select>
                        <p class="small text-muted no-margin">Additional allocations to assign to this server on creation.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="overlay" id="allocationLoader" style="display:none;"><i class="fa fa-refresh fa-spin"></i></div>
                <div class="box-header with-border">
                    <h3 class="box-title">Application Feature Limits</h3>
                </div>

                <div class="box-body row">
                    <div class="form-group col-xs-6">
                        <label for="pDatabaseLimit" class="control-label">Database Limit</label>
                        <div>
                            <input type="text" id="pDatabaseLimit" name="database_limit" class="form-control" value="{{ old('database_limit', 0) }}"/>
                        </div>
                        <p class="text-muted small">The total number of databases a user is allowed to create for this server.</p>
                    </div>
                    <div class="form-group col-xs-6">
                        <label for="pAllocationLimit" class="control-label">Allocation Limit</label>
                        <div>
                            <input type="text" id="pAllocationLimit" name="allocation_limit" class="form-control" value="{{ old('allocation_limit', 0) }}"/>
                        </div>
                        <p class="text-muted small">The total number of allocations a user is allowed to create for this server.</p>
                    </div>
                    <div class="form-group col-xs-6">
                        <label for="pBackupLimit" class="control-label">Backup Limit</label>
                        <div>
                            <input type="text" id="pBackupLimit" name="backup_limit" class="form-control" value="{{ old('backup_limit', 0) }}"/>
                        </div>
                        <p class="text-muted small">The total number of backups that can be created for this server.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Resource Management</h3>
                </div>

                <div class="box-body row">
                    <div class="form-group col-xs-6">
                        <label for="pCPU">CPU Limit</label>

                        <div class="input-group">
                            <input type="text" id="pCPU" name="cpu" class="form-control" value="{{ old('cpu', 0) }}" />
                            <span class="input-group-addon">%</span>
                        </div>

                        <p class="text-muted small">If you do not want to limit CPU usage, set the value to <code>0</code>. To determine a value, take the number of threads and multiply it by 100. For example, on a quad core system without hyperthreading <code>(4 * 100 = 400)</code> there is <code>400%</code> available. To limit a server to using half of a single thread, you would set the value to <code>50</code>. To allow a server to use up to two threads, set the value to <code>200</code>.<p>
                    </div>

                    <div class="form-group col-xs-6">
                        <label for="pThreads">CPU Pinning</label>

                        <div>
                            <input type="text" id="pThreads" name="threads" class="form-control" value="{{ old('threads') }}" />
                        </div>

                        <p class="text-muted small"><strong>Advanced:</strong> Enter the specific CPU threads that this process can run on, or leave blank to allow all threads. This can be a single number, or a comma separated list. Example: <code>0</code>, <code>0-1,3</code>, or <code>0,1,3,4</code>.</p>
                    </div>
                </div>

                <div class="box-body row">
                    <div class="form-group col-xs-6">
                        <label for="pMemory">Memory</label>

                        <div class="input-group">
                            <input type="text" id="pMemory" name="memory" class="form-control" value="{{ old('memory') }}" />
                            <span class="input-group-addon">MiB</span>
                        </div>

                        <p class="text-muted small">The maximum amount of memory allowed for this container. Setting this to <code>0</code> will allow unlimited memory in a container.</p>
                    </div>

                    <div class="form-group col-xs-6">
                        <label for="pSwap">Swap</label>

                        <div class="input-group">
                            <input type="text" id="pSwap" name="swap" class="form-control" value="{{ old('swap', 0) }}" />
                            <span class="input-group-addon">MiB</span>
                        </div>

                        <p class="text-muted small">Setting this to <code>0</code> will disable swap space on this server. Setting to <code>-1</code> will allow unlimited swap.</p>
                    </div>
                </div>

                <div class="box-body row">
                    <div class="form-group col-xs-6">
                        <label for="pDisk">Disk Space</label>

                        <div class="input-group">
                            <input type="text" id="pDisk" name="disk" class="form-control" value="{{ old('disk') }}" />
                            <span class="input-group-addon">MiB</span>
                        </div>

                        <p class="text-muted small">This server will not be allowed to boot if it is using more than this amount of space. If a server goes over this limit while running it will be safely stopped and locked until enough space is available. Set to <code>0</code> to allow unlimited disk usage.</p>
                    </div>

                    <div class="form-group col-xs-6">
                        <label for="pIO">Block IO Weight</label>

                        <div>
                            <input type="text" id="pIO" name="io" class="form-control" value="{{ old('io', 500) }}" />
                        </div>

                        <p class="text-muted small"><strong>Advanced</strong>: The IO performance of this server relative to other <em>running</em> containers on the system. Value should be between <code>10</code> and <code>1000</code>. Please see <a href="https://docs.docker.com/engine/reference/run/#block-io-bandwidth-blkio-constraint" target="_blank">this documentation</a> for more information about it.</p>
                    </div>
                    <div class="form-group col-xs-12">
                        <div class="checkbox checkbox-primary no-margin-bottom">
                            <input type="checkbox" id="pOomDisabled" name="oom_disabled" value="0" {{ \\Pterodactyl\\Helpers\\Utilities::checked('oom_disabled', 0) }} />
                            <label for="pOomDisabled" class="strong">Enable OOM Killer</label>
                        </div>

                        <p class="small text-muted no-margin">Terminates the server if it breaches the memory limits. Enabling OOM killer may cause server processes to exit unexpectedly.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Nest Configuration</h3>
                </div>

                <div class="box-body row">
                    <div class="form-group col-xs-12">
                        <label for="pNestId">Nest</label>

                        <select id="pNestId" name="nest_id" class="form-control">
                            @foreach($nests as $nest)
                                <option value="{{ $nest->id }}"
                                    @if($nest->id === old('nest_id'))
                                        selected="selected"
                                    @endif
                                >{{ $nest->name }}</option>
                            @endforeach
                        </select>

                        <p class="small text-muted no-margin">Select the Nest that this server will be grouped under.</p>
                    </div>

                    <div class="form-group col-xs-12">
                        <label for="pEggId">Egg</label>
                        <select id="pEggId" name="egg_id" class="form-control"></select>
                        <p class="small text-muted no-margin">Select the Egg that will define how this server should operate.</p>
                    </div>
                    <div class="form-group col-xs-12">
                        <div class="checkbox checkbox-primary no-margin-bottom">
                            <input type="checkbox" id="pSkipScripting" name="skip_scripts" value="1" {{ \\Pterodactyl\\Helpers\\Utilities::checked('skip_scripts', 0) }} />
                            <label for="pSkipScripting" class="strong">Skip Egg Install Script</label>
                        </div>

                        <p class="small text-muted no-margin">If the selected Egg has an install script attached to it, the script will run during the install. If you would like to skip this step, check this box.</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Docker Configuration</h3>
                </div>

                <div class="box-body row">
                    <div class="form-group col-xs-12">
                        <label for="pDefaultContainer">Docker Image</label>
                        <select id="pDefaultContainer" name="image" class="form-control"></select>
                        <input id="pDefaultContainerCustom" name="custom_image" value="{{ old('custom_image') }}" class="form-control" placeholder="Or enter a custom image..." style="margin-top:1rem"/>
                        <p class="small text-muted no-margin">This is the default Docker image that will be used to run this server. Select an image from the dropdown above, or enter a custom image in the text field above.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Startup Configuration</h3>
                </div>

                <div class="box-body row">
                    <div class="form-group col-xs-12">
                        <label for="pStartup">Startup Command</label>
                        <input type="text" id="pStartup" name="startup" value="{{ old('startup') }}" class="form-control" />
                        <p class="small text-muted no-margin">The following data substitutes are available for the startup command: <code>@{{SERVER_MEMORY}}</code>, <code>@{{SERVER_IP}}</code>, and <code>@{{SERVER_PORT}}</code>. They will be replaced with the allocated memory, server IP, and server port respectively.</p>
                    </div>
                </div>

                <div class="box-header with-border" style="margin-top:-10px;">
                    <h3 class="box-title">Service Variables</h3>
                </div>

                <div class="box-body row" id="appendVariablesTo"></div>

                <div class="box-footer">
                    {!! csrf_field() !!}
                    <input type="submit" class="btn btn-success pull-right" value="Create Server" />
                </div>
            </div>
        </div>
    </div>
</form>
@endsection

@section('footer-scripts')
    @parent
    {!! Theme::js('vendor/lodash/lodash.js') !!}

    <script type="application/javascript">
        // Persist 'Service Variables'
        function serviceVariablesUpdated(eggId, ids) {
            @if (old('egg_id'))
                // Check if the egg id matches.
                if (eggId != '{{ old('egg_id') }}') {
                    return;
                }

                @if (old('environment'))
                    @foreach (old('environment') as $key => $value)
                        $('#' + ids['{{ $key }}']).val('{{ $value }}');
                    @endforeach
                @endif
            @endif
            @if(old('image'))
                $('#pDefaultContainer').val('{{ old('image') }}');
            @endif
        }
        // END Persist 'Service Variables'
    </script>

    {!! Theme::js('js/admin/new-server.js?v=20220530') !!}

    <script type="application/javascript">
        $(document).ready(function() {
            // Persist 'Server Owner' select2
            @if (old('owner_id'))
                $.ajax({
                    url: '/admin/users/accounts.json?user_id={{ old('owner_id') }}',
                    dataType: 'json',
                }).then(function (data) {
                    initUserIdSelect([ data ]);
                });
            @else
                initUserIdSelect();
            @endif
            // END Persist 'Server Owner' select2

            // Persist 'Node' select2
            @if (old('node_id'))
                $('#pNodeId').val('{{ old('node_id') }}').change();

                // Persist 'Default Allocation' select2
                @if (old('allocation_id'))
                    $('#pAllocation').val('{{ old('allocation_id') }}').change();
                @endif
                // END Persist 'Default Allocation' select2

                // Persist 'Additional Allocations' select2
                @if (old('allocation_additional'))
                    const additional_allocations = [];

                    @for ($i = 0; $i < count(old('allocation_additional')); $i++)
                        additional_allocations.push('{{ old('allocation_additional.'.$i)}}');
                    @endfor

                    $('#pAllocationAdditional').val(additional_allocations).change();
                @endif
                // END Persist 'Additional Allocations' select2
            @endif
            // END Persist 'Node' select2

            // Persist 'Nest' select2
            @if (old('nest_id'))
                $('#pNestId').val('{{ old('nest_id') }}').change();

                // Persist 'Egg' select2
                @if (old('egg_id'))
                    $('#pEggId').val('{{ old('egg_id') }}').change();
                @endif
                // END Persist 'Egg' select2
            @endif
            // END Persist 'Nest' select2
        });
    </script>
@endsection
`
      },
      {
        name: "PROTECT1 (Anti Update Detail Server)",
        path: "/var/www/pterodactyl/app/Services/Servers/DetailsModificationService.php",
        file: "DetailsModificationService.php",
        code: `<?php

namespace Pterodactyl\\Services\\Servers;

use Illuminate\\Support\\Arr;
use Pterodactyl\\Models\\Server;
use Illuminate\\Database\\ConnectionInterface;
use Pterodactyl\\Traits\\Services\\ReturnsUpdatedModels;
use Pterodactyl\\Repositories\\Wings\\DaemonServerRepository;
use Pterodactyl\\Exceptions\\Http\\Connection\\DaemonConnectionException;

class DetailsModificationService
{
    use ReturnsUpdatedModels;

    /**
     * DetailsModificationService constructor.
     */
    public function __construct(private ConnectionInterface $connection, private DaemonServerRepository $serverRepository)
    {
    }

    /**
     * Update the details for a single server instance.
     *
     * @throws \\Throwable
     */
    public function handle(Server $server, array $data): Server
    {
        return $this->connection->transaction(function () use ($data, $server) {
            $owner = $server->owner_id;

            $server->forceFill([
                'external_id' => Arr::get($data, 'external_id'),
                'owner_id' => Arr::get($data, 'owner_id'),
                'name' => Arr::get($data, 'name'),
                'description' => Arr::get($data, 'description') ?? '',
            ])->saveOrFail();

            // If the owner_id value is changed we need to revoke any tokens that exist for the server
            // on the Wings instance so that the old owner no longer has any permission to access the
            // websockets.
            if ($server->owner_id !== $owner) {
                try {
                    $this->serverRepository->setServer($server)->revokeUserJTI($owner);
                } catch (DaemonConnectionException $exception) {
                    // Do nothing. A failure here is not ideal, but it is likely to be caused by Wings
                    // being offline, or in an entirely broken state. Remember, these tokens reset every
                    // few minutes by default, we're just trying to help it along a little quicker.
                }
            }

            return $server;
        });
    }
}`
      },
      {
        name: "PROTECT1 (Anti Update Build Configuration Server)",
        path: "/var/www/pterodactyl/app/Services/Servers/BuildModificationService.php",
        file: "BuildModificationService.php",
        code: `<?php

namespace Pterodactyl\\Services\\Servers;

use Illuminate\\Support\\Arr;
use Pterodactyl\\Models\\Server;
use Pterodactyl\\Models\\Allocation;
use Illuminate\\Support\\Facades\\Log;
use Illuminate\\Database\\ConnectionInterface;
use Pterodactyl\\Exceptions\\DisplayException;
use Illuminate\\Database\\Eloquent\\ModelNotFoundException;
use Pterodactyl\\Repositories\\Wings\\DaemonServerRepository;
use Pterodactyl\\Exceptions\\Http\\Connection\\DaemonConnectionException;

class BuildModificationService
{
    /**
     * BuildModificationService constructor.
     */
    public function __construct(
        private ConnectionInterface $connection,
        private DaemonServerRepository $daemonServerRepository,
        private ServerConfigurationStructureService $structureService
    ) {
    }

    /**
     * Change the build details for a specified server.
     *
     * @throws \\Throwable
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     */
    public function handle(Server $server, array $data): Server
    {
        /** @var \\Pterodactyl\\Models\\Server $server */
        $server = $this->connection->transaction(function () use ($server, $data) {
            $this->processAllocations($server, $data);

            if (isset($data['allocation_id']) && $data['allocation_id'] != $server->allocation_id) {
                try {
                    Allocation::query()->where('id', $data['allocation_id'])->where('server_id', $server->id)->firstOrFail();
                } catch (ModelNotFoundException) {
                    throw new DisplayException('The requested default allocation is not currently assigned to this server.');
                }
            }

            // If any of these values are passed through in the data array go ahead and set
            // them correctly on the server model.
            $merge = Arr::only($data, ['oom_disabled', 'memory', 'swap', 'io', 'cpu', 'threads', 'disk', 'allocation_id']);

            $server->forceFill(array_merge($merge, [
                'database_limit' => Arr::get($data, 'database_limit', 0) ?? null,
                'allocation_limit' => Arr::get($data, 'allocation_limit', 0) ?? null,
                'backup_limit' => Arr::get($data, 'backup_limit', 0) ?? 0,
            ]))->saveOrFail();

            return $server->refresh();
        });

        $updateData = $this->structureService->handle($server);

        // Because Wings always fetches an updated configuration from the Panel when booting
        // a server this type of exception can be safely "ignored" and just written to the logs.
        // Ideally this request succeeds, so we can apply resource modifications on the fly, but
        // if it fails we can just continue on as normal.
        if (!empty($updateData['build'])) {
            try {
                $this->daemonServerRepository->setServer($server)->sync();
            } catch (DaemonConnectionException $exception) {
                Log::warning($exception, ['server_id' => $server->id]);
            }
        }

        return $server;
    }

    /**
     * Process the allocations being assigned in the data and ensure they are available for a server.
     *
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     */
    private function processAllocations(Server $server, array &$data): void
    {
        if (empty($data['add_allocations']) && empty($data['remove_allocations'])) {
            return;
        }

        // Handle the addition of allocations to this server. Only assign allocations that are not currently
        // assigned to a different server, and only allocations on the same node as the server.
        if (!empty($data['add_allocations'])) {
            $query = Allocation::query()
                ->where('node_id', $server->node_id)
                ->whereIn('id', $data['add_allocations'])
                ->whereNull('server_id');

            // Keep track of all the allocations we're just now adding so that we can use the first
            // one to reset the default allocation to.
            $freshlyAllocated = $query->pluck('id')->first();

            $query->update(['server_id' => $server->id, 'notes' => null]);
        }

        if (!empty($data['remove_allocations'])) {
            foreach ($data['remove_allocations'] as $allocation) {
                // If we are attempting to remove the default allocation for the server, see if we can reassign
                // to the first provided value in add_allocations. If there is no new first allocation then we
                // will throw an exception back.
                if ($allocation === ($data['allocation_id'] ?? $server->allocation_id)) {
                    if (empty($freshlyAllocated)) {
                        throw new DisplayException('You are attempting to delete the default allocation for this server but there is no fallback allocation to use.');
                    }

                    // Update the default allocation to be the first allocation that we are creating.
                    $data['allocation_id'] = $freshlyAllocated;
                }
            }

            // Remove any of the allocations we got that are currently assigned to this server on
            // this node. Also set the notes to null, otherwise when re-allocated to a new server those
            // notes will be carried over.
            Allocation::query()->where('node_id', $server->node_id)
                ->where('server_id', $server->id)
                // Only remove the allocations that we didn't also attempt to add to the server...
                ->whereIn('id', array_diff($data['remove_allocations'], $data['add_allocations'] ?? []))
                ->update([
                    'notes' => null,
                    'server_id' => null,
                ]);
        }
    }
}
`
      },
      {
        name: "PROTECT1 (Anti Setup Server)",
        path: "/var/www/pterodactyl/app/Services/Servers/StartupModificationService.php",
        file: "StartupModificationService.php",
        code: `<?php

namespace Pterodactyl\\Services\\Servers;

use Illuminate\\Support\\Arr;
use Pterodactyl\\Models\\Egg;
use Pterodactyl\\Models\\User;
use Pterodactyl\\Models\\Server;
use Pterodactyl\\Models\\ServerVariable;
use Illuminate\\Database\\ConnectionInterface;
use Pterodactyl\\Traits\\Services\\HasUserLevels;

class StartupModificationService
{
    use HasUserLevels;

    /**
     * StartupModificationService constructor.
     */
    public function __construct(private ConnectionInterface $connection, private VariableValidatorService $validatorService)
    {
    }

    /**
     * Process startup modification for a server.
     *
     * @throws \\Throwable
     */
    public function handle(Server $server, array $data): Server
    {
        return $this->connection->transaction(function () use ($server, $data) {
            if (!empty($data['environment'])) {
                $egg = $this->isUserLevel(User::USER_LEVEL_ADMIN) ? ($data['egg_id'] ?? $server->egg_id) : $server->egg_id;

                $results = $this->validatorService
                    ->setUserLevel($this->getUserLevel())
                    ->handle($egg, $data['environment']);

                foreach ($results as $result) {
                    ServerVariable::query()->updateOrCreate(
                        [
                            'server_id' => $server->id,
                            'variable_id' => $result->id,
                        ],
                        ['variable_value' => $result->value ?? '']
                    );
                }
            }

            if ($this->isUserLevel(User::USER_LEVEL_ADMIN)) {
                $this->updateAdministrativeSettings($data, $server);
            }

            return $server->fresh();
        });
    }

    /**
     * Update certain administrative settings for a server in the DB.
     */
    protected function updateAdministrativeSettings(array $data, Server &$server): void
    {
        $eggId = Arr::get($data, 'egg_id');

        if (is_digit($eggId) && $server->egg_id !== (int) $eggId) {
            /** @var \\Pterodactyl\\Models\\Egg $egg */
            $egg = Egg::query()->findOrFail($data['egg_id']);

            $server = $server->forceFill([
                'egg_id' => $egg->id,
                'nest_id' => $egg->nest_id,
            ]);
        }

        $server->fill([
            'startup' => $data['startup'] ?? $server->startup,
            'skip_scripts' => $data['skip_scripts'] ?? isset($data['skip_scripts']),
            'image' => $data['docker_image'] ?? $server->image,
        ])->save();
    }
}`
      },
      {
        name: "PROTECT1 (Anti Update Database)",
        path: "/var/www/pterodactyl/app/Services/Databases/DatabaseManagementService.php",
        file: "DatabaseManagementService.php",
        code: `<?php

namespace Pterodactyl\\Services\\Databases;

use Exception;
use Pterodactyl\\Models\\Server;
use Pterodactyl\\Models\\Database;
use Pterodactyl\\Helpers\\Utilities;
use Illuminate\\Database\\ConnectionInterface;
use Illuminate\\Contracts\\Encryption\\Encrypter;
use Pterodactyl\\Extensions\\DynamicDatabaseConnection;
use Pterodactyl\\Repositories\\Eloquent\\DatabaseRepository;
use Pterodactyl\\Exceptions\\Repository\\DuplicateDatabaseNameException;
use Pterodactyl\\Exceptions\\Service\\Database\\TooManyDatabasesException;
use Pterodactyl\\Exceptions\\Service\\Database\\DatabaseClientFeatureNotEnabledException;

class DatabaseManagementService
{
    /**
     * The regex used to validate that the database name passed through to the function is
     * in the expected format.
     *
     * @see \\Pterodactyl\\Services\\Databases\\DatabaseManagementService::generateUniqueDatabaseName()
     */
    private const MATCH_NAME_REGEX = '/^(s[\\d]+_)(.*)$/';

    /**
     * Determines if the service should validate the user's ability to create an additional
     * database for this server. In almost all cases this should be true, but to keep things
     * flexible you can also set it to false and create more databases than the server is
     * allocated.
     */
    protected bool $validateDatabaseLimit = true;

    public function __construct(
        protected ConnectionInterface $connection,
        protected DynamicDatabaseConnection $dynamic,
        protected Encrypter $encrypter,
        protected DatabaseRepository $repository
    ) {
    }

    /**
     * Generates a unique database name for the given server. This name should be passed through when
     * calling this handle function for this service, otherwise the database will be created with
     * whatever name is provided.
     */
    public static function generateUniqueDatabaseName(string $name, int $serverId): string
    {
        // Max of 48 characters, including the s123_ that we append to the front.
        return sprintf('s%d_%s', $serverId, substr($name, 0, 48 - strlen("s{$serverId}_")));
    }

    /**
     * Set whether this class should validate that the server has enough slots
     * left before creating the new database.
     */
    public function setValidateDatabaseLimit(bool $validate): self
    {
        $this->validateDatabaseLimit = $validate;

        return $this;
    }

    /**
     * Create a new database that is linked to a specific host.
     *
     * @throws \\Throwable
     * @throws \\Pterodactyl\\Exceptions\\Service\\Database\\TooManyDatabasesException
     * @throws \\Pterodactyl\\Exceptions\\Service\\Database\\DatabaseClientFeatureNotEnabledException
     */
    public function create(Server $server, array $data): Database
    {
        if (!config('pterodactyl.client_features.databases.enabled')) {
            throw new DatabaseClientFeatureNotEnabledException();
        }

        if ($this->validateDatabaseLimit) {
            // If the server has a limit assigned and we've already reached that limit, throw back
            // an exception and kill the process.
            if (!is_null($server->database_limit) && $server->databases()->count() >= $server->database_limit) {
                throw new TooManyDatabasesException();
            }
        }

        // Protect against developer mistakes...
        if (empty($data['database']) || !preg_match(self::MATCH_NAME_REGEX, $data['database'])) {
            throw new \\InvalidArgumentException('The database name passed to DatabaseManagementService::handle MUST be prefixed with "s{server_id}_".');
        }

        $data = array_merge($data, [
            'server_id' => $server->id,
            'username' => sprintf('u%d_%s', $server->id, str_random(10)),
            'password' => $this->encrypter->encrypt(
                Utilities::randomStringWithSpecialCharacters(24)
            ),
        ]);

        $database = null;

        try {
            return $this->connection->transaction(function () use ($data, &$database) {
                $database = $this->createModel($data);

                $this->dynamic->set('dynamic', $data['database_host_id']);

                $this->repository->createDatabase($database->database);
                $this->repository->createUser(
                    $database->username,
                    $database->remote,
                    $this->encrypter->decrypt($database->password),
                    $database->max_connections
                );
                $this->repository->assignUserToDatabase($database->database, $database->username, $database->remote);
                $this->repository->flush();

                return $database;
            });
        } catch (\\Exception $exception) {
            try {
                if ($database instanceof Database) {
                    $this->repository->dropDatabase($database->database);
                    $this->repository->dropUser($database->username, $database->remote);
                    $this->repository->flush();
                }
            } catch (\\Exception $deletionException) {
                // Do nothing here. We've already encountered an issue before this point so no
                // reason to prioritize this error over the initial one.
            }

            throw $exception;
        }
    }

    /**
     * Delete a database from the given host server.
     *
     * @throws \\Exception
     */
    public function delete(Database $database): ?bool
    {
        $this->dynamic->set('dynamic', $database->database_host_id);

        $this->repository->dropDatabase($database->database);
        $this->repository->dropUser($database->username, $database->remote);
        $this->repository->flush();

        return $database->delete();
    }

    /**
     * Create the database if there is not an identical match in the DB. While you can technically
     * have the same name across multiple hosts, for the sake of keeping this logic easy to understand
     * and avoiding user confusion we will ignore the specific host and just look across all hosts.
     *
     * @throws \\Pterodactyl\\Exceptions\\Repository\\DuplicateDatabaseNameException
     * @throws \\Throwable
     */
    protected function createModel(array $data): Database
    {
        $exists = Database::query()->where('server_id', $data['server_id'])
            ->where('database', $data['database'])
            ->exists();

        if ($exists) {
            throw new DuplicateDatabaseNameException('A database with that name already exists for this server.');
        }

        $database = (new Database())->forceFill($data);
        $database->saveOrFail();

        return $database;
    }
}
`
      },
      {
        name: "PROTECT1 ANTI UPDATE MANAGE (Anti Button Transfer This Server)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Admin/Servers/ServerTransferController.php",
        file: "ServerTransferController.php",
        code: `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin\\Servers;

use Carbon\\CarbonImmutable;
use Illuminate\\Http\\Request;
use Pterodactyl\\Models\\Server;
use Illuminate\\Http\\RedirectResponse;
use Prologue\\Alerts\\AlertsMessageBag;
use Pterodactyl\\Models\\ServerTransfer;
use Illuminate\\Database\\ConnectionInterface;
use Pterodactyl\\Http\\Controllers\\Controller;
use Pterodactyl\\Services\\Nodes\\NodeJWTService;
use Pterodactyl\\Repositories\\Eloquent\\NodeRepository;
use Pterodactyl\\Repositories\\Wings\\DaemonTransferRepository;
use Pterodactyl\\Contracts\\Repository\\AllocationRepositoryInterface;

class ServerTransferController extends Controller
{
    /**
     * ServerTransferController constructor.
     */
    public function __construct(
        private AlertsMessageBag $alert,
        private AllocationRepositoryInterface $allocationRepository,
        private ConnectionInterface $connection,
        private DaemonTransferRepository $daemonTransferRepository,
        private NodeJWTService $nodeJWTService,
        private NodeRepository $nodeRepository
    ) {
    }

    /**
     * Starts a transfer of a server to a new node.
     *
     * @throws \\Throwable
     */
    public function transfer(Request $request, Server $server): RedirectResponse
    {
        $validatedData = $request->validate([
            'node_id' => 'required|exists:nodes,id',
            'allocation_id' => 'required|bail|unique:servers|exists:allocations,id',
            'allocation_additional' => 'nullable',
        ]);

        $node_id = $validatedData['node_id'];
        $allocation_id = intval($validatedData['allocation_id']);
        $additional_allocations = array_map('intval', $validatedData['allocation_additional'] ?? []);

        // Check if the node is viable for the transfer.
        $node = $this->nodeRepository->getNodeWithResourceUsage($node_id);
        if (!$node->isViable($server->memory, $server->disk)) {
            $this->alert->danger(trans('admin/server.alerts.transfer_not_viable'))->flash();

            return redirect()->route('admin.servers.view.manage', $server->id);
        }

        $server->validateTransferState();

        $this->connection->transaction(function () use ($server, $node_id, $allocation_id, $additional_allocations) {
            // Create a new ServerTransfer entry.
            $transfer = new ServerTransfer();

            $transfer->server_id = $server->id;
            $transfer->old_node = $server->node_id;
            $transfer->new_node = $node_id;
            $transfer->old_allocation = $server->allocation_id;
            $transfer->new_allocation = $allocation_id;
            $transfer->old_additional_allocations = $server->allocations->where('id', '!=', $server->allocation_id)->pluck('id');
            $transfer->new_additional_allocations = $additional_allocations;

            $transfer->save();

            // Add the allocations to the server, so they cannot be automatically assigned while the transfer is in progress.
            $this->assignAllocationsToServer($server, $node_id, $allocation_id, $additional_allocations);

            // Generate a token for the destination node that the source node can use to authenticate with.
            $token = $this->nodeJWTService
                ->setExpiresAt(CarbonImmutable::now()->addMinutes(15))
                ->setSubject($server->uuid)
                ->handle($transfer->newNode, $server->uuid, 'sha256');

            // Notify the source node of the pending outgoing transfer.
            $this->daemonTransferRepository->setServer($server)->notify($transfer->newNode, $token);

            return $transfer;
        });

        $this->alert->success(trans('admin/server.alerts.transfer_started'))->flash();

        return redirect()->route('admin.servers.view.manage', $server->id);
    }

    /**
     * Assigns the specified allocations to the specified server.
     */
    private function assignAllocationsToServer(Server $server, int $node_id, int $allocation_id, array $additional_allocations)
    {
        $allocations = $additional_allocations;
        $allocations[] = $allocation_id;

        $unassigned = $this->allocationRepository->getUnassignedAllocationIds($node_id);

        $updateIds = [];
        foreach ($allocations as $allocation) {
            if (!in_array($allocation, $unassigned)) {
                continue;
            }

            $updateIds[] = $allocation;
        }

        if (!empty($updateIds)) {
            $this->allocationRepository->updateWhereIn('id', $updateIds, ['server_id' => $server->id]);
        }
    }
}
`
      },
      {
        name: "PROTECT1 ANTI UPDATE MANAGE (Anti Button Suspend Status)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Admin/ServersController.php",
        file: "ServersController.php",
        code: `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin;

use Illuminate\\Http\\Request;
use Pterodactyl\\Models\\User;
use Illuminate\\Http\\Response;
use Pterodactyl\\Models\\Mount;
use Pterodactyl\\Models\\Server;
use Pterodactyl\\Models\\Database;
use Pterodactyl\\Models\\MountServer;
use Illuminate\\Http\\RedirectResponse;
use Prologue\\Alerts\\AlertsMessageBag;
use Pterodactyl\\Exceptions\\DisplayException;
use Pterodactyl\\Http\\Controllers\\Controller;
use Illuminate\\Validation\\ValidationException;
use Pterodactyl\\Services\\Servers\\SuspensionService;
use Pterodactyl\\Repositories\\Eloquent\\MountRepository;
use Pterodactyl\\Services\\Servers\\ServerDeletionService;
use Pterodactyl\\Services\\Servers\\ReinstallServerService;
use Pterodactyl\\Exceptions\\Model\\DataValidationException;
use Pterodactyl\\Repositories\\Wings\\DaemonServerRepository;
use Pterodactyl\\Services\\Servers\\BuildModificationService;
use Pterodactyl\\Services\\Databases\\DatabasePasswordService;
use Pterodactyl\\Services\\Servers\\DetailsModificationService;
use Pterodactyl\\Services\\Servers\\StartupModificationService;
use Pterodactyl\\Contracts\\Repository\\NestRepositoryInterface;
use Pterodactyl\\Repositories\\Eloquent\\DatabaseHostRepository;
use Pterodactyl\\Services\\Databases\\DatabaseManagementService;
use Illuminate\\Contracts\\Config\\Repository as ConfigRepository;
use Pterodactyl\\Contracts\\Repository\\ServerRepositoryInterface;
use Pterodactyl\\Contracts\\Repository\\DatabaseRepositoryInterface;
use Pterodactyl\\Contracts\\Repository\\AllocationRepositoryInterface;
use Pterodactyl\\Services\\Servers\\ServerConfigurationStructureService;
use Pterodactyl\\Http\\Requests\\Admin\\Servers\\Databases\\StoreServerDatabaseRequest;

class ServersController extends Controller
{
    /**
     * ServersController constructor.
     */
    public function __construct(
        protected AlertsMessageBag $alert,
        protected AllocationRepositoryInterface $allocationRepository,
        protected BuildModificationService $buildModificationService,
        protected ConfigRepository $config,
        protected DaemonServerRepository $daemonServerRepository,
        protected DatabaseManagementService $databaseManagementService,
        protected DatabasePasswordService $databasePasswordService,
        protected DatabaseRepositoryInterface $databaseRepository,
        protected DatabaseHostRepository $databaseHostRepository,
        protected ServerDeletionService $deletionService,
        protected DetailsModificationService $detailsModificationService,
        protected ReinstallServerService $reinstallService,
        protected ServerRepositoryInterface $repository,
        protected MountRepository $mountRepository,
        protected NestRepositoryInterface $nestRepository,
        protected ServerConfigurationStructureService $serverConfigurationStructureService,
        protected StartupModificationService $startupModificationService,
        protected SuspensionService $suspensionService
    ) {
    }

    /**
     * Update the details for a server.
     *
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function setDetails(Request $request, Server $server): RedirectResponse
    {
        $this->detailsModificationService->handle($server, $request->only([
            'owner_id', 'external_id', 'name', 'description',
        ]));

        $this->alert->success(trans('admin/server.alerts.details_updated'))->flash();

        return redirect()->route('admin.servers.view.details', $server->id);
    }

    /**
     * Toggles the installation status for a server.
     *
* @throws \\Pterodactyl\\Exceptions\\DisplayException
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function toggleInstall(Server $server): RedirectResponse
    {
        if ($server->status === Server::STATUS_INSTALL_FAILED) {
            throw new DisplayException(trans('admin/server.exceptions.marked_as_failed'));
        }

        $this->repository->update($server->id, [
            'status' => $server->isInstalled() ? Server::STATUS_INSTALLING : null,
        ], true, true);

        $this->alert->success(trans('admin/server.alerts.install_toggled'))->flash();

        return redirect()->route('admin.servers.view.manage', $server->id);
    }

    /**
     * Reinstalls the server with the currently assigned service.
     *
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function reinstallServer(Server $server): RedirectResponse
    {
        $this->reinstallService->handle($server);
        $this->alert->success(trans('admin/server.alerts.server_reinstalled'))->flash();

        return redirect()->route('admin.servers.view.manage', $server->id);
    }

    /**
     * Manage the suspension status for a server.
     *
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function manageSuspension(Request $request, Server $server): RedirectResponse
    {
        $this->suspensionService->toggle($server, $request->input('action'));
        $this->alert->success(trans('admin/server.alerts.suspension_toggled', [
            'status' => $request->input('action') . 'ed',
        ]))->flash();

        return redirect()->route('admin.servers.view.manage', $server->id);
    }

    /**
     * Update the build configuration for a server.
     *
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     * @throws \\Illuminate\\Validation\\ValidationException
     */
    public function updateBuild(Request $request, Server $server): RedirectResponse
    {
        try {
            $this->buildModificationService->handle($server, $request->only([
                'allocation_id', 'add_allocations', 'remove_allocations',
                'memory', 'swap', 'io', 'cpu', 'threads', 'disk',
                'database_limit', 'allocation_limit', 'backup_limit', 'oom_disabled',
            ]));
        } catch (DataValidationException $exception) {
            throw new ValidationException($exception->getValidator());
        }

        $this->alert->success(trans('admin/server.alerts.build_updated'))->flash();

        return redirect()->route('admin.servers.view.build', $server->id);
    }

    /**
     * Start the server deletion process.
     *
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     * @throws \\Throwable
     */
    public function delete(Request $request, Server $server): RedirectResponse
    {
        $this->deletionService->withForce($request->filled('force_delete'))->handle($server);
        $this->alert->success(trans('admin/server.alerts.server_deleted'))->flash();

        return redirect()->route('admin.servers');
    }

    /**
     * Update the startup command as well as variables.
     *
     * @throws \\Illuminate\\Validation\\ValidationException
     */
    public function saveStartup(Request $request, Server $server): RedirectResponse
    {
        $data = $request->except('_token');
        if (!empty($data['custom_docker_image'])) {
            $data['docker_image'] = $data['custom_docker_image'];
            unset($data['custom_docker_image']);
        }

        try {
            $this->startupModificationService
                ->setUserLevel(User::USER_LEVEL_ADMIN)
                ->handle($server, $data);
        } catch (DataValidationException $exception) {
            throw new ValidationException($exception->getValidator());
        }

        $this->alert->success(trans('admin/server.alerts.startup_changed'))->flash();

        return redirect()->route('admin.servers.view.startup', $server->id);
    }

    /**
     * Creates a new database assigned to a specific server.
     *
     * @throws \\Throwable
     */
    public function newDatabase(StoreServerDatabaseRequest $request, Server $server): RedirectResponse
    {
        $this->databaseManagementService->create($server, [
            'database' => DatabaseManagementService::generateUniqueDatabaseName($request->input('database'), $server->id),
            'remote' => $request->input('remote'),
            'database_host_id' => $request->input('database_host_id'),
            'max_connections' => $request->input('max_connections'),
        ]);

        return redirect()->route('admin.servers.view.database', $server->id)->withInput();
    }

    /**
     * Resets the database password for a specific database on this server.
     *
     * @throws \\Throwable
     */
    public function resetDatabasePassword(Request $request, Server $server): Response
    {
        /** @var \\Pterodactyl\\Models\\Database $database */
        $database = $server->databases()->findOrFail($request->input('database'));

        $this->databasePasswordService->handle($database);

        return response('', 204);
    }

    /**
     * Deletes a database from a server.
     *
     * @throws \\Exception
     */
    public function deleteDatabase(Server $server, Database $database): Response
    {
        $this->databaseManagementService->delete($database);

        return response('', 204);
    }

    /**
     * Add a mount to a server.
     *
     * @throws \\Throwable
     */
    public function addMount(Request $request, Server $server): RedirectResponse
    {
        $mountServer = (new MountServer())->forceFill([
            'mount_id' => $request->input('mount_id'),
            'server_id' => $server->id,
        ]);

        $mountServer->saveOrFail();

        $this->alert->success('Mount was added successfully.')->flash();

        return redirect()->route('admin.servers.view.mounts', $server->id);
    }

    /**
     * Remove a mount from a server.
     */
    public function deleteMount(Server $server, Mount $mount): RedirectResponse
    {
        MountServer::where('mount_id', $mount->id)->where('server_id', $server->id)->delete();

        $this->alert->success('Mount was removed successfully.')->flash();

        return redirect()->route('admin.servers.view.mounts', $server->id);
    }
}
`
      },
      {
        name: "PROTECT1 ANTI UPDATE MANAGE (Anti Button Toggle Status)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Admin/ServersController.php",
        file: "ServersController.php",
        code: `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin;

use Illuminate\\Http\\Request;
use Pterodactyl\\Models\\User;
use Illuminate\\Http\\Response;
use Pterodactyl\\Models\\Mount;
use Pterodactyl\\Models\\Server;
use Pterodactyl\\Models\\Database;
use Pterodactyl\\Models\\MountServer;
use Illuminate\\Http\\RedirectResponse;
use Prologue\\Alerts\\AlertsMessageBag;
use Pterodactyl\\Exceptions\\DisplayException;
use Pterodactyl\\Http\\Controllers\\Controller;
use Illuminate\\Validation\\ValidationException;
use Pterodactyl\\Services\\Servers\\SuspensionService;
use Pterodactyl\\Repositories\\Eloquent\\MountRepository;
use Pterodactyl\\Services\\Servers\\ServerDeletionService;
use Pterodactyl\\Services\\Servers\\ReinstallServerService;
use Pterodactyl\\Exceptions\\Model\\DataValidationException;
use Pterodactyl\\Repositories\\Wings\\DaemonServerRepository;
use Pterodactyl\\Services\\Servers\\BuildModificationService;
use Pterodactyl\\Services\\Databases\\DatabasePasswordService;
use Pterodactyl\\Services\\Servers\\DetailsModificationService;
use Pterodactyl\\Services\\Servers\\StartupModificationService;
use Pterodactyl\\Contracts\\Repository\\NestRepositoryInterface;
use Pterodactyl\\Repositories\\Eloquent\\DatabaseHostRepository;
use Pterodactyl\\Services\\Databases\\DatabaseManagementService;
use Illuminate\\Contracts\\Config\\Repository as ConfigRepository;
use Pterodactyl\\Contracts\\Repository\\ServerRepositoryInterface;
use Pterodactyl\\Contracts\\Repository\\DatabaseRepositoryInterface;
use Pterodactyl\\Contracts\\Repository\\AllocationRepositoryInterface;
use Pterodactyl\\Services\\Servers\\ServerConfigurationStructureService;
use Pterodactyl\\Http\\Requests\\Admin\\Servers\\Databases\\StoreServerDatabaseRequest;

class ServersController extends Controller
{
    /**
     * ServersController constructor.
     */
    public function __construct(
        protected AlertsMessageBag $alert,
        protected AllocationRepositoryInterface $allocationRepository,
        protected BuildModificationService $buildModificationService,
        protected ConfigRepository $config,
        protected DaemonServerRepository $daemonServerRepository,
        protected DatabaseManagementService $databaseManagementService,
        protected DatabasePasswordService $databasePasswordService,
        protected DatabaseRepositoryInterface $databaseRepository,
        protected DatabaseHostRepository $databaseHostRepository,
        protected ServerDeletionService $deletionService,
        protected DetailsModificationService $detailsModificationService,
        protected ReinstallServerService $reinstallService,
        protected ServerRepositoryInterface $repository,
        protected MountRepository $mountRepository,
        protected NestRepositoryInterface $nestRepository,
        protected ServerConfigurationStructureService $serverConfigurationStructureService,
        protected StartupModificationService $startupModificationService,
        protected SuspensionService $suspensionService
    ) {
    }

    /**
     * Update the details for a server.
     *
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function setDetails(Request $request, Server $server): RedirectResponse
    {
        $this->detailsModificationService->handle($server, $request->only([
            'owner_id', 'external_id', 'name', 'description',
        ]));

        $this->alert->success(trans('admin/server.alerts.details_updated'))->flash();

        return redirect()->route('admin.servers.view.details', $server->id);
    }

    /**
     * Toggles the installation status for a server.
     *
* @throws \\Pterodactyl\\Exceptions\\DisplayException
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function toggleInstall(Server $server): RedirectResponse
    {
        if ($server->status === Server::STATUS_INSTALL_FAILED) {
            throw new DisplayException(trans('admin/server.exceptions.marked_as_failed'));
        }

        $this->repository->update($server->id, [
            'status' => $server->isInstalled() ? Server::STATUS_INSTALLING : null,
        ], true, true);

        $this->alert->success(trans('admin/server.alerts.install_toggled'))->flash();

        return redirect()->route('admin.servers.view.manage', $server->id);
    }

    /**
     * Reinstalls the server with the currently assigned service.
     *
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function reinstallServer(Server $server): RedirectResponse
    {
        $this->reinstallService->handle($server);
        $this->alert->success(trans('admin/server.alerts.server_reinstalled'))->flash();

        return redirect()->route('admin.servers.view.manage', $server->id);
    }

    /**
     * Manage the suspension status for a server.
     *
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function manageSuspension(Request $request, Server $server): RedirectResponse
    {
        $this->suspensionService->toggle($server, $request->input('action'));
        $this->alert->success(trans('admin/server.alerts.suspension_toggled', [
            'status' => $request->input('action') . 'ed',
        ]))->flash();

        return redirect()->route('admin.servers.view.manage', $server->id);
    }

    /**
     * Update the build configuration for a server.
     *
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     * @throws \\Illuminate\\Validation\\ValidationException
     */
    public function updateBuild(Request $request, Server $server): RedirectResponse
    {
        try {
            $this->buildModificationService->handle($server, $request->only([
                'allocation_id', 'add_allocations', 'remove_allocations',
                'memory', 'swap', 'io', 'cpu', 'threads', 'disk',
                'database_limit', 'allocation_limit', 'backup_limit', 'oom_disabled',
            ]));
        } catch (DataValidationException $exception) {
            throw new ValidationException($exception->getValidator());
        }

        $this->alert->success(trans('admin/server.alerts.build_updated'))->flash();

        return redirect()->route('admin.servers.view.build', $server->id);
    }

    /**
     * Start the server deletion process.
     *
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     * @throws \\Throwable
     */
    public function delete(Request $request, Server $server): RedirectResponse
    {
        $this->deletionService->withForce($request->filled('force_delete'))->handle($server);
        $this->alert->success(trans('admin/server.alerts.server_deleted'))->flash();

        return redirect()->route('admin.servers');
    }

    /**
     * Update the startup command as well as variables.
     *
     * @throws \\Illuminate\\Validation\\ValidationException
     */
    public function saveStartup(Request $request, Server $server): RedirectResponse
    {
        $data = $request->except('_token');
        if (!empty($data['custom_docker_image'])) {
            $data['docker_image'] = $data['custom_docker_image'];
            unset($data['custom_docker_image']);
        }

        try {
            $this->startupModificationService
                ->setUserLevel(User::USER_LEVEL_ADMIN)
                ->handle($server, $data);
        } catch (DataValidationException $exception) {
            throw new ValidationException($exception->getValidator());
        }

        $this->alert->success(trans('admin/server.alerts.startup_changed'))->flash();

        return redirect()->route('admin.servers.view.startup', $server->id);
    }

    /**
     * Creates a new database assigned to a specific server.
     *
     * @throws \\Throwable
     */
    public function newDatabase(StoreServerDatabaseRequest $request, Server $server): RedirectResponse
    {
        $this->databaseManagementService->create($server, [
            'database' => DatabaseManagementService::generateUniqueDatabaseName($request->input('database'), $server->id),
            'remote' => $request->input('remote'),
            'database_host_id' => $request->input('database_host_id'),
            'max_connections' => $request->input('max_connections'),
        ]);

        return redirect()->route('admin.servers.view.database', $server->id)->withInput();
    }

    /**
     * Resets the database password for a specific database on this server.
     *
     * @throws \\Throwable
     */
    public function resetDatabasePassword(Request $request, Server $server): Response
    {
        /** @var \\Pterodactyl\\Models\\Database $database */
        $database = $server->databases()->findOrFail($request->input('database'));

        $this->databasePasswordService->handle($database);

        return response('', 204);
    }

    /**
     * Deletes a database from a server.
     *
     * @throws \\Exception
     */
    public function deleteDatabase(Server $server, Database $database): Response
    {
        $this->databaseManagementService->delete($database);

        return response('', 204);
    }

    /**
     * Add a mount to a server.
     *
     * @throws \\Throwable
     */
    public function addMount(Request $request, Server $server): RedirectResponse
    {
        $mountServer = (new MountServer())->forceFill([
            'mount_id' => $request->input('mount_id'),
            'server_id' => $server->id,
        ]);

        $mountServer->saveOrFail();

        $this->alert->success('Mount was added successfully.')->flash();

        return redirect()->route('admin.servers.view.mounts', $server->id);
    }

    /**
     * Remove a mount from a server.
     */
    public function deleteMount(Server $server, Mount $mount): RedirectResponse
    {
        MountServer::where('mount_id', $mount->id)->where('server_id', $server->id)->delete();

        $this->alert->success('Mount was removed successfully.')->flash();

        return redirect()->route('admin.servers.view.mounts', $server->id);
    }
}`
      },
      {
        name: "PROTECT1 ANTI UPDATE MANAGE (Anti Button Reinstall Status)",
        path: "/var/www/pterodactyl/app/Services/Servers/ReinstallServerService.php",
        file: "ReinstallServerService.php",
        code: `<?php

namespace Pterodactyl\\Services\\Servers;

use Pterodactyl\\Models\\Server;
use Illuminate\\Database\\ConnectionInterface;
use Pterodactyl\\Repositories\\Wings\\DaemonServerRepository;

class ReinstallServerService
{
    /**
     * ReinstallService constructor.
     */
    public function __construct(
        private ConnectionInterface $connection,
        private DaemonServerRepository $daemonServerRepository
    ) {
    }

    /**
     * Reinstall a server on the remote daemon.
     *
     * @throws \\Throwable
     */
    public function handle(Server $server): Server
    {
        return $this->connection->transaction(function () use ($server) {
            $server->fill(['status' => Server::STATUS_INSTALLING])->save();

            $this->daemonServerRepository->setServer($server)->reinstall();

            return $server->refresh();
        });
    }
}`
      },
      {
        name: "PROTECT1 (Anti Delete Server)",
        path: "/var/www/pterodactyl/app/Services/Servers/ServerDeletionService.php",
        file: "ServerDeletionService.php",
        code: `<?php

namespace Pterodactyl\\Services\\Servers;

use Illuminate\\Http\\Response;
use Pterodactyl\\Models\\Server;
use Illuminate\\Support\\Facades\\Log;
use Illuminate\\Database\\ConnectionInterface;
use Pterodactyl\\Repositories\\Wings\\DaemonServerRepository;
use Pterodactyl\\Services\\Databases\\DatabaseManagementService;
use Pterodactyl\\Exceptions\\Http\\Connection\\DaemonConnectionException;

class ServerDeletionService
{
    protected bool $force = false;

    /**
     * ServerDeletionService constructor.
     */
    public function __construct(
        private ConnectionInterface $connection,
        private DaemonServerRepository $daemonServerRepository,
        private DatabaseManagementService $databaseManagementService
    ) {
    }

    /**
     * Set if the server should be forcibly deleted from the panel (ignoring daemon errors) or not.
     */
    public function withForce(bool $bool = true): self
    {
        $this->force = $bool;

        return $this;
    }

    /**
     * Delete a server from the panel and remove any associated databases from hosts.
     *
     * @throws \\Throwable
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     */
    public function handle(Server $server): void
    {
        try {
            $this->daemonServerRepository->setServer($server)->delete();
        } catch (DaemonConnectionException $exception) {
            if (!$this->force && $exception->getStatusCode() !== Response::HTTP_NOT_FOUND) {
                throw $exception;
            }

            Log::warning($exception);
        }

        $this->connection->transaction(function () use ($server) {
            foreach ($server->databases as $database) {
                try {
                    $this->databaseManagementService->delete($database);
                } catch (\\Exception $exception) {
                    if (!$this->force) {
                        throw $exception;
                    }

                    $database->delete();

                    Log::warning($exception);
                }
            }

            $server->delete();
        });
    }
}`
      },
    ];

    let successCount = 0;

    for (const file of protectFiles) {
      try {
        const tempFile = path.join(__dirname, file.file);
        fs.writeFileSync(tempFile, file.code);
        await ssh.putFile(tempFile, file.path);
        fs.unlinkSync(tempFile);

        successCount++;
      } catch (err) {
        await bot.sendMessage(
          chatId,
          `✕ Gagal menghapus protect.\nError:\n\`${err.message}\``,
          { parse_mode: "Markdown" }
        );
      }
    }

    ssh.dispose();

    if (successCount > 0) {
      await bot.sendMessage(
        chatId,
        "✔ Sukses uninstall protect Anti Otak Atik Server In Settings",
        { parse_mode: "Markdown" }
      );
    } else {
      await bot.sendMessage(
        chatId,
        "✕ uninstall gagal. Tidak ada file yang berhasil dihapus.",
        { parse_mode: "Markdown" }
      );
    }

  } catch (err) {
    console.error("✕ ERROR UNINSTALLPROTECT15:", err);
    bot.sendMessage(
      chatId,
      `✕ Gagal menjalankan uninstalasi.\n\nError:\n\`${err.message}\``,
      { parse_mode: "Markdown" }
    );
  }
});
bot.onText(/^\/uninstallprotectall (.+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  return bot.sendMessage(chatId, unsafeSourceDisabledMsg("uninstallprotectall"), { parse_mode: "MarkdownV2" });
  // eslint-disable-next-line no-unreachable
  const userId = msg.from.id.toString();
  const input = match[1];

  const roleProtect = getUserRole(userId);
  if (userId !== ID_OWNER && roleProtect !== "ceo") {
    return bot.sendMessage(chatId, "⟡ Maaf, fitur install protection ini khusus untuk role CEO ya.");
  }

  if (!input || !input.includes("|"))
    return bot.sendMessage(
      chatId,
      "✕ Salah format!\nGunakan seperti ini:\n`/uninstallprotectall ipvps|pwvps`",
      { parse_mode: "Markdown" }
    );

  const [ipvps, pwvps] = input.split("|").map(i => i.trim());
  if (!ipvps || !pwvps)
    return bot.sendMessage(
      chatId,
      "✕ Salah format!\nGunakan seperti ini:\n`/uninstallprotectall ipvps|pwvps`",
      { parse_mode: "Markdown" }
    );

  const conn = new Client();
  const allScripts = uninstallScripts.map(s => s.file);

  bot.sendMessage(
    chatId,
    `⏳ Menghubungkan ke VPS *${ipvps}* dan mulai uninstall Protect Panel 1-14...`,
    { parse_mode: "Markdown" }
  );

  conn.on("ready", async () => {
    bot.sendMessage(
      chatId,
      "⊙ *Koneksi berhasil!* Proses uninstall semua Protect Panel sedang berjalan...",
      { parse_mode: "Markdown" }
    );

    for (let file of allScripts) {
      const scriptURL = `https://raw.githubusercontent.com/rexzzyphn/Unprotect/refs/heads/main/${file}`;

      bot.sendMessage(
        chatId,
        `➤ Memulai uninstall *${file}*...`,
        { parse_mode: "Markdown" }
      );

      await new Promise(resolve => {
        const execTimeout = setTimeout(() => {
          bot.sendMessage(
            chatId,
            `✕ Proses *${file}* timeout setelah 30 detik`,
            { parse_mode: "Markdown" }
          );
          resolve();
        }, 30000);

        conn.exec(`curl -fsSL ${scriptURL} | bash`, (err, stream) => {
          if (err) {
            clearTimeout(execTimeout);
            bot.sendMessage(
              chatId,
              `✕ Gagal mengeksekusi *${file}*\n\n\`\`\`\n${err.message}\n\`\`\``,
              { parse_mode: "Markdown" }
            );
            return resolve();
          }

          let output = "";
          stream.on("data", data => (output += data.toString()));
          stream.stderr.on("data", data => (output += data.toString()));

          stream.on("close", () => {
            clearTimeout(execTimeout);
            const cleanOutput =
              output.trim().slice(-3800) || "(tidak ada output)";

            bot.sendMessage(
              chatId,
              `✔ *${file} selesai!*\n\n⬢ Output terakhir:\n\n\`\`\`\n${cleanOutput}\n\`\`\``,
              { parse_mode: "Markdown" }
            );
            resolve();
          });
        });
      });
    }

    conn.end();
    bot.sendMessage(
      chatId,
      "⟡ *Semua uninstall Protect Panel 1-14 selesai!*",
      { parse_mode: "Markdown" }
    );
  });

  conn.on("error", err => {
    bot.sendMessage(
      chatId,
      `✕ Gagal terhubung ke VPS!\nPeriksa IP & Password kamu.\n\n\`\`\`\n${err.message}\n\`\`\``,
      { parse_mode: "Markdown" }
    );
  });

  conn.connect({
    host: ipvps,
    port: 22,
    username: "root",
    password: pwvps
  });
});

bot.onText(/^\/(?:installstellar|instaltemastellar)(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  return bot.sendMessage(chatId, unsafeSourceDisabledMsg("installstellar"), { parse_mode: "MarkdownV2" });
  // eslint-disable-next-line no-unreachable
  const userId = msg.from.id.toString();
  const input = (match[1] || "").trim();

  const roleProtect = getUserRole(userId);
  if (userId !== ID_OWNER && roleProtect !== "ceo") {
    return bot.sendMessage(chatId, "⟡ Maaf, fitur install protection ini khusus untuk role CEO ya.");
  }

  let ipvps, passwd;

  if (!input) {
    return bot.sendMessage(
      chatId,
      `✕ Gunakan: /installstellar ip|pwvps`,
      { parse_mode: "Markdown" }
    );
  }

  if (!input.includes("|")) {
    return bot.sendMessage(
      chatId,
      "⚠ Format salah!\n\nGunakan format:\n`/installstellar ip|password`\n\nContoh:\n`/installstellar 1.2.3.4|root123`",
      { parse_mode: "Markdown" }
    );
  }

  const [ip, pw] = input.split("|");
  ipvps = ip.trim();
  passwd = pw.trim();

  if (!ipvps || !passwd) {
    return bot.sendMessage(
      chatId,
      "⚠ IP atau Password tidak boleh kosong!\nGunakan format: `/installstellar ip|password`",
      { parse_mode: "Markdown" }
    );
  }

  global.installtema = {
    vps: ipvps,
    pwvps: passwd
  };

  let port = 22;
  if (ipvps.includes(":")) {
    const [host, portNum] = ipvps.split(":");
    ipvps = host;
    port = parseInt(portNum, 10) || 22;
  }

  const connSettings = {
    host: ipvps,
    port: port,
    username: "root",
    password: passwd
  };

  const command = `bash <(curl -s https://raw.githubusercontent.com/rexzzyphn/Autoinstall-/refs/heads/main/bangkai.sh)`;
  const ress = new Client();

  await bot.sendMessage(
    chatId,
    `⟳ *Memproses install tema Stellar Pterodactyl...*\n⌂ IP: \`${ipvps}:${port}\`\n⏳ Tunggu 1–10 menit hingga proses selesai...`,
    { parse_mode: "Markdown" }
  );

  ress.on("ready", () => {
    ress.exec(command, (err, stream) => {
      if (err) {
        console.error("SSH exec error:", err);
        try { ress.end(); } catch {}
        return bot.sendMessage(chatId, "✕ Gagal menjalankan perintah di server.");
      }

      stream
        .on("close", async () => {
          await bot.sendMessage(
            chatId,
            "✔ *Berhasil install tema Stellar Pterodactyl!*",
            { parse_mode: "Markdown" }
          );
          ress.end();
        })
        .on("data", (data) => {
          console.log(`[${ipvps}] ${data.toString()}`);
          try {
            stream.write("1\n");
            stream.write("1\n");
            stream.write("yes\n");
            stream.write("x\n");
          } catch (e) {
            console.log("Write error:", e);
          }
        })
        .stderr.on("data", (data) => {
          console.log(`[STDERR ${ipvps}] ${data.toString()}`);
        });
    });
  });

  ress.on("error", (err) => {
    console.error("Connection Error:", err);
    try { ress.end(); } catch {}
    bot.sendMessage(chatId, "✕ Koneksi SSH gagal — periksa IP, port, atau password!");
  });

  try {
    ress.connect(connSettings);
  } catch (e) {
    console.error("SSH connect error:", e);
    bot.sendMessage(chatId, "✕ Terjadi kesalahan saat mencoba koneksi ke VPS!");
  }
});
bot.onText(/^\/(?:installbilling|instaltemabiling)(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  return bot.sendMessage(chatId, unsafeSourceDisabledMsg("installbilling"), { parse_mode: "MarkdownV2" });
  // eslint-disable-next-line no-unreachable
  const userId = msg.from.id.toString();
  const input = (match[1] || "").trim();

  const roleProtect = getUserRole(userId);
  if (userId !== ID_OWNER && roleProtect !== "ceo") {
    return bot.sendMessage(chatId, "⟡ Maaf, fitur install protection ini khusus untuk role CEO ya.");
  }

  let ipvps, passwd;

  if (!input) {
    return bot.sendMessage(
      chatId,
      `✕ Gunakan: /installbilling ip|pwvps`,
      { parse_mode: "Markdown" }
    );
  }

  if (!input.includes("|")) {
    return bot.sendMessage(
      chatId,
      "⚠ Format salah!\n\nGunakan format:\n`/installbilling ip|password`\n\nContoh:\n`/installbilling 1.2.3.4|root123`",
      { parse_mode: "Markdown" }
    );
  }

  const [ip, pw] = input.split("|");
  ipvps = ip.trim();
  passwd = pw.trim();

  if (!ipvps || !passwd) {
    return bot.sendMessage(
      chatId,
      "⚠ IP atau Password tidak boleh kosong!\nGunakan format: `/installbilling ip|password`",
      { parse_mode: "Markdown" }
    );
  }

  global.installtema = {
    vps: ipvps,
    pwvps: passwd
  };

  let port = 22;
  if (ipvps.includes(":")) {
    const [host, portNum] = ipvps.split(":");
    ipvps = host;
    port = parseInt(portNum, 10) || 22;
  }

  const connSettings = {
    host: ipvps,
    port: port,
    username: "root",
    password: passwd
  };

  const command = `bash <(curl -s https://raw.githubusercontent.com/rexzzyphn/Autoinstall-/refs/heads/main/bangkai.sh)`;
  const ress = new Client();

  await bot.sendMessage(
    chatId,
    `⟳ *Memproses install tema Billing Pterodactyl...*\n⌂ IP: \`${ipvps}:${port}\`\n⏳ Tunggu 1–10 menit hingga proses selesai...`,
    { parse_mode: "Markdown" }
  );

  ress.on("ready", () => {
    ress.exec(command, (err, stream) => {
      if (err) {
        console.error("SSH exec error:", err);
        try { ress.end(); } catch {}
        return bot.sendMessage(chatId, "✕ Gagal menjalankan perintah di server.");
      }

      stream
        .on("data", (data) => {
          console.log(`[${ipvps}] ${data.toString()}`);
          try {
            stream.write("1\n");
            stream.write("2\n");
            stream.write("yes\n");
            stream.write("x\n");
          } catch (e) {
            console.log("Write error:", e);
          }
        })
        .on("close", async () => {
          await bot.sendMessage(
            chatId,
            "✔ *Berhasil install tema Billing Pterodactyl!*",
            { parse_mode: "Markdown" }
          );
          ress.end();
        })
        .stderr.on("data", (data) => {
          console.log(`[STDERR ${ipvps}] ${data.toString()}`);
        });
    });
  });

  ress.on("error", (err) => {
    console.error("Connection Error:", err);
    try { ress.end(); } catch {}
    bot.sendMessage(chatId, "✕ Koneksi SSH gagal — periksa IP, port, atau password!");
  });

  try {
    ress.connect(connSettings);
  } catch (e) {
    console.error("SSH connect error:", e);
    bot.sendMessage(chatId, "✕ Terjadi kesalahan saat mencoba koneksi ke VPS!");
  }
});
bot.onText(/^\/(?:installenigma|installtemaenigma|instaltemaenigma)(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  return bot.sendMessage(chatId, unsafeSourceDisabledMsg("installenigma"), { parse_mode: "MarkdownV2" });
  // eslint-disable-next-line no-unreachable
  const userId = msg.from.id.toString();
  const input = (match[1] || "").trim();

  const roleProtect = getUserRole(userId);
  if (userId !== ID_OWNER && roleProtect !== "ceo") {
    return bot.sendMessage(chatId, "⟡ Maaf, fitur install protection ini khusus untuk role CEO ya.");
  }

  const DEFAULT_PHONE = "6285705607453";
  const DEFAULT_GROUP = "https://chat.whatsapp.com/DTr8VwNniNADGGVQ6YKgxJ";
  const DEFAULT_CHANNEL = "https://chat.whatsapp.com/DTr8VwNniNADGGVQ6YKgxJ";

  let ipvps, passwd, phone, groupLink, channelLink;

  if (!input) {
    return bot.sendMessage(
      chatId,
      `✕ Gunakan: /installenigma ip|pwvps`, 
      { parse_mode: "Markdown" }
    );
  }

  const parts = input.split("|").map(p => p.trim());
  if (parts.length < 2) {
    return bot.sendMessage(
      chatId,
      "⚠ Format salah!\n`/installenigma ip|password`",
      { parse_mode: "Markdown" }
    );
  }

  ipvps = parts[0];
  passwd = parts[1];
  phone = parts[2] || DEFAULT_PHONE;
  groupLink = parts[3] || DEFAULT_GROUP;
  channelLink = parts[4] || DEFAULT_CHANNEL;

  global.installtema = { vps: ipvps, pwvps: passwd, phone, group: groupLink, channel: channelLink };

  try {
    let digits = phone.replace(/\D+/g, "");
    if (digits.startsWith("0")) digits = "62" + digits.slice(1);
    else if (digits.startsWith("8")) digits = "62" + digits;
    phone = digits;
  } catch {
    phone = DEFAULT_PHONE;
  }

  let port = 22;
  if (ipvps.includes(":")) {
    const [host, portNum] = ipvps.split(":");
    ipvps = host;
    port = parseInt(portNum, 10) || 22;
  }

  const connSettings = { host: ipvps, port, username: "root", password: passwd };
  const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`;
  const ress = new Client();

  await bot.sendMessage(
    chatId,
    `⟳ *Memproses install tema Enigma...*\n⌂ \`${ipvps}:${port}\``,
    { parse_mode: "Markdown" }
  );

  ress.on("ready", () => {
    ress.exec(command, (err, stream) => {
      if (err) {
        try { ress.end(); } catch {}
        return bot.sendMessage(chatId, "✕ Gagal menjalankan perintah.");
      }

      stream
        .on("data", (data) => {
          console.log(`[${ipvps}] ${data.toString()}`);
          try {
            stream.write("skyzodev\n");
            stream.write("1\n");
            stream.write("3\n");
            stream.write(`https://wa.me/${phone}\n`);
            stream.write(`${groupLink}\n`);
            stream.write(`${channelLink}\n`);
            stream.write("yes\n");
            stream.write("x\n");
          } catch {}
        })
        .on("close", async () => {
          await bot.sendMessage(chatId, "✔ *Berhasil install tema Enigma!*", { parse_mode: "Markdown" });
          ress.end();
        });
    });
  });

  ress.on("error", () => {
    try { ress.end(); } catch {}
    bot.sendMessage(chatId, "✕ Koneksi SSH gagal!");
  });

  try {
    ress.connect(connSettings);
  } catch {
    bot.sendMessage(chatId, "✕ Gagal koneksi VPS!");
  }
});

bot.onText(/^\/(?:installnightcore|installtemanightcore|installnighcore)(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  return bot.sendMessage(chatId, unsafeSourceDisabledMsg("installnightcore"), { parse_mode: "MarkdownV2" });
  // eslint-disable-next-line no-unreachable
  const userId = msg.from.id.toString();
  const input = (match[1] || "").trim();

  const roleProtect = getUserRole(userId);
  if (userId !== ID_OWNER && roleProtect !== "ceo") {
    return bot.sendMessage(chatId, "⟡ Maaf, fitur install protection ini khusus untuk role CEO ya.");
  }

  let ipvps, passwd;

  if (!input) {
    return bot.sendMessage(
      chatId,
      `✕ Gunakan: /installnightcore ip|pwvps`,
      { parse_mode: "Markdown" }
    );
  }

  if (!input.includes("|")) {
    return bot.sendMessage(chatId, "⚠ Format salah!\n`/installnightcore ip|password`", {
      parse_mode: "Markdown",
    });
  }

  const [ip, pw] = input.split("|");
  ipvps = ip.trim();
  passwd = pw.trim();

  if (!ipvps || !passwd) {
    return bot.sendMessage(chatId, "⚠ IP atau Password kosong!", {
      parse_mode: "Markdown",
    });
  }

  global.installtema = { vps: ipvps, pwvps: passwd };

  let port = 22;
  if (ipvps.includes(":")) {
    const [host, portNum] = ipvps.split(":");
    ipvps = host;
    port = parseInt(portNum, 10) || 22;
  }

  const connSettings = {
    host: ipvps,
    port,
    username: "root",
    password: passwd,
    readyTimeout: 20000,
  };

  const command = "bash <(curl -s https://raw.githubusercontent.com/LeXcZxMoDz9/kontol/refs/heads/main/bangke.sh)";
  const ress = new Client();

  await bot.sendMessage(
    chatId,
    `⟳ *Memproses install tema Nightcore...*\n⌂ \`${ipvps}:${port}\``,
    { parse_mode: "Markdown" }
  );

  ress.on("ready", () => {
    ress.exec(command, (err, stream) => {
      if (err) {
        try { ress.end(); } catch {}
        return bot.sendMessage(chatId, "✕ Gagal menjalankan perintah.");
      }

      stream
        .on("data", (data) => {
          console.log(`[${ipvps}] ${data.toString()}`);
          try {
            stream.write("1C\n");
            stream.write("y\n");
            stream.write("yes\n");
            stream.write("y\n");
            stream.write("\n");
          } catch {}
        })
        .on("close", async () => {
          await bot.sendMessage(chatId, "✔ *Berhasil install tema Nightcore!*", {
            parse_mode: "Markdown",
          });
          ress.end();
        });
    });
  });

  ress.on("error", () => {
    try { ress.end(); } catch {}
    bot.sendMessage(chatId, "✕ Koneksi SSH gagal!");
  });

  try {
    ress.connect(connSettings);
  } catch {
    bot.sendMessage(chatId, "✕ Gagal koneksi VPS!");
  }
});
// === COMMAND INSTALL ELYSIUM THEME (NDy Official) ===
bot.onText(/^\/(?:installelysium|installtemaelysium)(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  return bot.sendMessage(chatId, unsafeSourceDisabledMsg("installelysium"), { parse_mode: "MarkdownV2" });
  // eslint-disable-next-line no-unreachable
  const userId = msg.from.id.toString();
  const input = (match[1] || "").trim();

  const roleProtect = getUserRole(userId);
  if (userId !== ID_OWNER && roleProtect !== "ceo") {
    return bot.sendMessage(chatId, "⟡ Maaf, fitur install protection ini khusus untuk role CEO ya.");
  }

  let ipvps, passwd;

  if (!input) {
    return bot.sendMessage(
      chatId,
      "✕ Gunakan: /installelysium ip|pwvps"
    );
  }

  if (!input.includes("|")) {
    return bot.sendMessage(chatId, "✕ Format salah\nGunakan: /installelysium ip|pwvps");
  }

  const [ip, pw] = input.split("|");
  ipvps = ip.trim();
  passwd = pw.trim();

  if (!ipvps || !passwd)
    return bot.sendMessage(chatId, "✕ IP atau password kosong!");

  let port = 22;
  if (ipvps.includes(":")) {
    const [host, p] = ipvps.split(":");
    ipvps = host;
    port = parseInt(p) || 22;
  }

  const connSettings = {
    host: ipvps,
    port,
    username: "root",
    password: passwd
  };

  const command = `bash <(curl -s https://raw.githubusercontent.com/Kelaoffc/Ndyoffc/refs/heads/main/installndyoffc.sh)`;
  const ssh = new Client();

  await bot.sendMessage(chatId, `⏳ Install Elysium...\nIP: ${ipvps}:${port}`);

  ssh.on("ready", () => {
    ssh.exec(command, (err, stream) => {
      if (err) return bot.sendMessage(chatId, "✕ Gagal eksekusi SSH");

      stream.on("data", () => {
        stream.write("metrickpack2\n");
        stream.write("1\n");
        stream.write("y\n");
        stream.write("yes\n");
        stream.write("23\n");
      });

      stream.on("close", () => {
        bot.sendMessage(chatId, "✔ Install Elysium selesai");
        ssh.end();
      });
    });
  });

  ssh.on("error", () => {
    bot.sendMessage(chatId, "✕ SSH gagal");
  });

  ssh.connect(connSettings);
});


// === COMMAND INSTALL NOOK THEME (NDy Official) ===
bot.onText(/^\/(?:installnook|installtemanook)(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  return bot.sendMessage(chatId, unsafeSourceDisabledMsg("installnook"), { parse_mode: "MarkdownV2" });
  // eslint-disable-next-line no-unreachable
  const userId = msg.from.id.toString();
  const input = (match[1] || "").trim();

  const roleProtect = getUserRole(userId);
  if (userId !== ID_OWNER && roleProtect !== "ceo") {
    return bot.sendMessage(chatId, "⟡ Maaf, fitur install protection ini khusus untuk role CEO ya.");
  }

  let ipvps, passwd;

  if (!input) {
    return bot.sendMessage(
      chatId,
      "✕ Gunakan: /installnook ip|pwvps"
    );
  }

  if (!input.includes("|")) {
    return bot.sendMessage(chatId, "✕ Format salah\nGunakan: /installnook ip|pwvps");
  }

  const [ip, pw] = input.split("|");
  ipvps = ip.trim();
  passwd = pw.trim();

  if (!ipvps || !passwd)
    return bot.sendMessage(chatId, "✕ IP atau password kosong!");

  let port = 22;
  if (ipvps.includes(":")) {
    const [host, p] = ipvps.split(":");
    ipvps = host;
    port = parseInt(p) || 22;
  }

  const connSettings = {
    host: ipvps,
    port,
    username: "root",
    password: passwd
  };

  const command = `bash <(curl -s https://raw.githubusercontent.com/Kelaoffc/Ndyoffc/refs/heads/main/installndyoffc.sh)`;
  const ssh = new Client();

  await bot.sendMessage(chatId, `⏳ Install Nook...\nIP: ${ipvps}:${port}`);

  ssh.on("ready", () => {
    ssh.exec(command, (err, stream) => {
      if (err) return bot.sendMessage(chatId, "✕ Gagal eksekusi SSH");

      stream.on("data", () => {
        stream.write("metrickpack2\n");
        stream.write("21\n");
        stream.write("yes\n");
        stream.write("y\n");
        stream.write("yes\n");
        stream.write("23\n");
      });

      stream.on("close", () => {
        bot.sendMessage(chatId, "✔ Install Nook selesai");
        ssh.end();
      });
    });
  });

  ssh.on("error", () => {
    bot.sendMessage(chatId, "✕ SSH gagal");
  });

  ssh.connect(connSettings);
});

bot.onText(/\/installreviactyl (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    return bot.sendMessage(chatId, unsafeSourceDisabledMsg("installreviactyl"), { parse_mode: "MarkdownV2" });
    // eslint-disable-next-line no-unreachable
    const input = match[1];

    if (!input || !input.includes("|")) {
        return bot.sendMessage(chatId,
            `<blockquote expandable>✕ Format salah!\n\nContoh:\n<code>/installreviactyl ipvps|pwvps</code></blockquote>`,
            { parse_mode: "HTML" }
        );
    }

    const [ipvps, passwd] = input.split("|").map(v => v.trim());

    if (!ipvps || !passwd) {
        return bot.sendMessage(chatId,
            `<blockquote expandable>✕ Format salah!\n\nContoh:\n<code>/installreviactyl ipvps|pwvps</code></blockquote>`,
            { parse_mode: "HTML" }
        );
    }

    const conn = new Client();
    const command = "bash <(curl -s https://raw.githubusercontent.com/Bangsano/themeinstaller/refs/heads/main/install.sh)";

    try {
        await bot.sendMessage(chatId,
            `<blockquote expandable>⏳ Menghubungkan ke VPS <b>${ipvps}</b>...\n⬢ Memulai instalasi tema Reviactyl...</blockquote>`,
            { parse_mode: "HTML" }
        );

        let processCompleted = false;

        const timeout = setTimeout(() => {
            if (!processCompleted) {
                try { conn.end(); } catch(e) {}
                bot.sendMessage(chatId,
                    `<blockquote expandable>⏱ <b>Waktu koneksi habis!</b> Periksa VPS dan coba lagi.</blockquote>`,
                    { parse_mode: "HTML" }
                );
            }
        }, 300000);

        conn.on("ready", () => {
            bot.sendMessage(chatId,
                `<blockquote expandable>⊙ <b>Proses instalasi tema Reviactyl...</b>\nTunggu 1-10 menit hingga selesai ✔</blockquote>`,
                { parse_mode: "HTML" }
            );

            conn.exec(command, (err, stream) => {
                if (err) {
                    processCompleted = true;
                    clearTimeout(timeout);
                    try { conn.end(); } catch(e) {}

                    return bot.sendMessage(chatId,
                        `<blockquote expandable>✕ <b>Gagal menjalankan script!</b>\n<code>${err.message}</code></blockquote>`,
                        { parse_mode: "HTML" }
                    );
                }

                stream.on("data", (data) => {
                    const text = data.toString().toLowerCase();

                    if (
                        text.includes("pilihan") ||
                        text.includes("option") ||
                        text.includes("select") ||
                        text.includes("input")
                    ) {
                        setTimeout(() => {
                            try {
                                stream.write("1\n");
                                stream.write("9\n");
                                stream.write("y\n");
                                stream.write("x\n");
                            } catch {}
                        }, 500);
                    }
                });

                stream.on("close", () => {
                    processCompleted = true;
                    clearTimeout(timeout);
                    try { conn.end(); } catch(e) {}

                    bot.sendMessage(chatId,
                        `<blockquote expandable>✔ <b>Berhasil install tema Reviactyl!</b>\n\n⟡ Tema sudah terpasang.\n⟳ Silakan refresh panel Anda.</blockquote>`,
                        { parse_mode: "HTML" }
                    );
                });
            });
        });

        conn.on("error", (err) => {
            processCompleted = true;
            clearTimeout(timeout);
            try { conn.end(); } catch(e) {}

            bot.sendMessage(chatId,
                `<blockquote expandable>✕ <b>Gagal terhubung ke VPS!</b>\n\nPeriksa:\n1. IP VPS benar\n2. Password root benar\n3. Port SSH 22 terbuka\n4. VPS aktif\n\n<b>Error:</b>\n<code>${err.message}</code></blockquote>`,
                { parse_mode: "HTML" }
            );
        });

        conn.connect({
            host: ipvps,
            port: 22,
            username: "root",
            password: passwd,
            readyTimeout: 20000,
        });

    } catch (e) {
        bot.sendMessage(chatId,
            `<blockquote expandable>✕ <b>Error:</b>\n<code>${e.message}</code></blockquote>`,
            { parse_mode: "HTML" }
        );
    }
});
// === COMMAND INSTALL WALLPAPER THEME (NDy Official) ===
bot.onText(/^\/(?:installwallpaper|installtemawallpaper)(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  return bot.sendMessage(chatId, unsafeSourceDisabledMsg("installwallpaper"), { parse_mode: "MarkdownV2" });
  // eslint-disable-next-line no-unreachable
  const userId = msg.from.id.toString();
  const input = (match[1] || "").trim();

  const roleProtect = getUserRole(userId);
  if (userId !== ID_OWNER && roleProtect !== "ceo") {
    return bot.sendMessage(chatId, "⟡ Maaf, fitur install protection ini khusus untuk role CEO ya.");
  }

  let ipvps, passwd, linkWallpaper;

  if (!input) {
    return bot.sendMessage(
      chatId,
      "✕ Gunakan: /installwallpaper ip|pwvps|linkwallpaper"
    );
  }

  const parts = input.split("|").map(v => v.trim());
  if (parts.length < 2)
    return bot.sendMessage(chatId, "✕ Format salah\nGunakan: /installwallpaper ip|pwvps|linkwallpaper");

  ipvps = parts[0];
  passwd = parts[1];
  linkWallpaper = parts[2] || "https://files.catbox.moe/7rprsx.jpg";

  if (!ipvps || !passwd)
    return bot.sendMessage(chatId, "✕ IP atau password kosong!");

  let port = 22;
  if (ipvps.includes(":")) {
    const [host, p] = ipvps.split(":");
    ipvps = host;
    port = parseInt(p) || 22;
  }

  const connSettings = {
    host: ipvps,
    port,
    username: "root",
    password: passwd
  };

  const command = `bash <(curl -s https://raw.githubusercontent.com/Kelaoffc/Ndyoffc/refs/heads/main/installndyoffc.sh)`;
  const ssh = new Client();

  await bot.sendMessage(chatId, `⏳ Install Wallpaper...\nIP: ${ipvps}:${port}`);

  ssh.on("ready", () => {
    ssh.exec(command, (err, stream) => {
      if (err) return bot.sendMessage(chatId, "✕ Gagal eksekusi SSH");

      stream.on("data", () => {
        stream.write("metrickpack2\n");
        stream.write("4\n");
        stream.write(`${linkWallpaper}\n`);
        stream.write("23\n");
      });

      stream.on("close", () => {
        bot.sendMessage(chatId, "✔ Install Wallpaper selesai");
        ssh.end();
      });
    });
  });

  ssh.on("error", () => {
    bot.sendMessage(chatId, "✕ SSH gagal");
  });

  ssh.connect(connSettings);
});


// === COMMAND UNINSTALL THEME PTERODACTYL ===
bot.onText(/^\/(?:uninstaltema|uninstalltemaptero)(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  return bot.sendMessage(chatId, unsafeSourceDisabledMsg("uninstalltema"), { parse_mode: "MarkdownV2" });
  // eslint-disable-next-line no-unreachable
  const userId = msg.from.id.toString();
  const input = (match[1] || "").trim();

  const roleProtect = getUserRole(userId);
  if (userId !== ID_OWNER && roleProtect !== "ceo") {
    return bot.sendMessage(chatId, "⟡ Maaf, fitur install protection ini khusus untuk role CEO ya.");
  }

  let ipvps, passwd;

  if (!input) {
    return bot.sendMessage(
      chatId,
      "✕ Gunakan: /uninstalltema ip|pwvps"
    );
  }

  if (!input.includes("|"))
    return bot.sendMessage(chatId, "✕ Format salah\nGunakan: /uninstalltema ip|pwvps");

  const [ip, pw] = input.split("|");
  ipvps = ip.trim();
  passwd = pw.trim();

  if (!ipvps || !passwd)
    return bot.sendMessage(chatId, "✕ IP atau password kosong!");

  let port = 22;
  if (ipvps.includes(":")) {
    const [host, p] = ipvps.split(":");
    ipvps = host;
    port = parseInt(p) || 22;
  }

  const connSettings = {
    host: ipvps,
    port,
    username: "root",
    password: passwd
  };

  const command = `bash <(curl -s https://raw.githubusercontent.com/rexzzyphn/Autoinstall-/refs/heads/main/bangkai.sh)`;
  const ssh = new Client();

  await bot.sendMessage(chatId, `⏳ Uninstall tema...\nIP: ${ipvps}:${port}`);

  ssh.on("ready", () => {
    ssh.exec(command, (err, stream) => {
      if (err) return bot.sendMessage(chatId, "✕ Gagal eksekusi SSH");

      stream.on("data", () => {
        stream.write("2\n");
        stream.write("y\n");
        stream.write("x\n");
      });

      stream.on("close", () => {
        bot.sendMessage(chatId, "✔ Uninstall tema selesai");
        ssh.end();
      });
    });
  });

  ssh.on("error", () => {
    bot.sendMessage(chatId, "✕ SSH gagal");
  });

  ssh.connect(connSettings);
});
const gantiPwState = {};

bot.onText(/^\/gantipwuser(?:\s+([\s\S]+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (!settings.isOwner(userId)) {
    return bot.sendMessage(
      chatId,
      `<blockquote expandable>✕ Hanya owner bot yang bisa menggunakan perintah ini.</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      `<blockquote expandable>✕ /gantipwuser id_user_panel|password_baru</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  const args = match[1].split("|").map(v => v.trim());
  if (args.length < 2) {
    return bot.sendMessage(
      chatId,
      `<blockquote expandable>✕ /gantipwuser id_user_panel|password_baru</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  const [userIdPanel, newPassword] = args;

  gantiPwState[chatId] = {
    step: "domain",
    userIdPanel,
    newPassword
  };

  bot.sendMessage(
    chatId,
    `<blockquote expandable>⟐ Kirim domain panel:</blockquote>`,
    { parse_mode: "HTML" }
  );
});

bot.on("message", async msg => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const text = msg.text;

  if (!settings.isOwner(userId)) return;
  if (!gantiPwState[chatId]) return;
  if (!text || text.startsWith("/")) return;

  const state = gantiPwState[chatId];

  try {
    if (state.step === "domain") {
      state.domain = text.replace(/\/$/, "");
      state.step = "plta";
      return bot.sendMessage(
        chatId,
        `<blockquote expandable>⚷ Kirim plta panel:</blockquote>`,
        { parse_mode: "HTML" }
      );
    }

    if (state.step === "plta") {
      state.apiKey = text;

      const { userIdPanel, newPassword, domain, apiKey } = state;

      bot.sendMessage(
        chatId,
        `<blockquote expandable>⏳ <b>Sedang memproses perubahan password...</b></blockquote>`,
        { parse_mode: "HTML" }
      );

      const userRes = await fetch(`${domain}/api/application/users/${userIdPanel}`, {
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`
        }
      });

      if (!userRes.ok) {
        const errTxt = await userRes.text();
        throw new Error(errTxt);
      }

      const userData = await userRes.json();
      const { username, email, first_name, last_name } = userData.attributes;

      const updateRes = await fetch(`${domain}/api/application/users/${userIdPanel}`, {
        method: "PATCH",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`
        },
        body: JSON.stringify({
          email,
          username,
          first_name,
          last_name,
          password: newPassword
        })
      });

      if (!updateRes.ok) {
        const errText = await updateRes.text();
        throw new Error(errText);
      }

      bot.sendMessage(
        chatId,
        `<blockquote expandable>✔ <b>Password Berhasil Diganti!</b>

◉ <b>User Panel ID:</b> <code>${userIdPanel}</code>
◉ <b>Username:</b> <code>${username}</code>
✉ <b>Email:</b> <code>${email}</code>
⚷ <b>Password Baru:</b> <code>${newPassword}</code>

↠ <a href="${domain}">Login Panel</a>

⌂ <i>REXZY BOT SYSTEM</i>
</blockquote>`,
        { parse_mode: "HTML", disable_web_page_preview: true }
      );

      delete gantiPwState[chatId];
    }
  } catch (err) {
    delete gantiPwState[chatId];
    bot.sendMessage(
      chatId,
      `<blockquote expandable>✕ <b>Gagal mengganti password!</b>\n\n<b>Error:</b>\n${err.message}</blockquote>`,
      { parse_mode: "HTML" }
    );
  }
});
};