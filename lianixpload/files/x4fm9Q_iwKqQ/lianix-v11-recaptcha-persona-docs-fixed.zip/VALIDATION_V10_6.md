# Validation V10.6

- `node scripts/validate-build.js` => PASS
- All JS under `assets/`, `netlify/functions/`, and `scripts/` => `node --check` PASS
- `_models.detectCapabilities()` test => image/document/file/url detection PASS
- `_model-runtime.runModelSource()` sandbox + attachment test => PASS
- `modelForm()` exists in `admin.html` before Save/Test calls => PASS
- `/api/model/run` route exists in Netlify config and `_redirects` => PASS
- `app-v106.js` is loaded after auth/user sync assets => PASS
- ZIP integrity checked after packaging.
