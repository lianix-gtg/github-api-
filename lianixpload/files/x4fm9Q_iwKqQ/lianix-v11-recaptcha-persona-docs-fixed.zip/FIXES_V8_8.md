# Lianix V8.8

- Fixed anti-inspect false-positive blackout. Removed viewport/outerWidth/resize/focus DevTools heuristics entirely.
- Blackout is now only triggered by explicit DevTools/view-source keyboard shortcuts intercepted by the page.
- Context menu is blocked without blacking out the page.
- LianixPload remains in Tools as a normal endpoint: POST /api/upload.
- The endpoint modal now shows method + endpoint immediately.
- File/image/audio/video endpoint parameters use a drag-and-drop picker with click-to-select fallback and selected filename/size feedback.
- Folder inputs continue to use the browser directory picker for reliable relative paths.
