# V7.9 Validation

Production build command:

```bash
npm run build
```

Runs only deterministic checks:
- `scripts/check-dependencies.js`
- `scripts/validate-build.js`

Auto Detect regression tests remain available separately:

```bash
npm test
npm run test:autodetect
```

Validated locally from the deploy root:
- dependency declaration check: PASS
- structural build validation: PASS
- `package.json`: valid JSON
- `netlify.toml`: valid project configuration
- Node build pin: 24.20.0
- ZIP root: flat (no wrapper directory)
