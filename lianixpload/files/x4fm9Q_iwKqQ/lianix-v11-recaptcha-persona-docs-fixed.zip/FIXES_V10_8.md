# V10.8 — Chat AI Visual Refresh

- Full Chat AI workspace visual refresh while preserving V10.7 AI/runtime logic.
- New warm cream/orange command-center styling.
- Redesigned sidebar, top bar, welcome area, composer, model selector, artifact panel, and mobile nav.
- Universal press feedback for interactive controls: ripple, icon bounce/rotation, button press scale.
- Dynamic buttons injected after load are automatically decorated through MutationObserver.
- Improved mobile layout and touch feedback.
- Added reduced-motion accessibility fallback.
