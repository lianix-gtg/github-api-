# Lianix V9.6 — Snippet UI, Biometric Setup, Model Manager & API Parameter Editor

## Snippets
- Rebuilt `/snippets` to follow the user-provided Code Snippets visual reference: fixed sidebar, mint/yellow/black cards, search, filter chips, Copy/View/Share actions.
- Removed the always-visible create form from the listing page.
- Added a compact bottom-right `+` floating button.
- Added `/snippets/new` as a dedicated create page.
- Public snippet list now includes a short safe content preview.

## Private snippet biometric flow
- Biometric authentication cannot be used until it is configured.
- Added `Atur Sidik Jari` beside the private snippet password controls.
- User must enter the correct snippet password to register WebAuthn/passkey.
- `Buka dengan Sidik Jari` stays disabled until the server reports at least one registered credential.
- Added WebAuthn status action to `/api/snippet/webauthn`.

## AI Models Admin
- Fixed `modelLevel is not defined`.
- Added deterministic mapping: green/ok -> online, yellow -> degraded, red/error -> error, no test -> untested.

## API Manager edit flow
- GitHub API list now has an `Edit` button for every discovered API.
- Edit loads the existing source + stored metadata back into the API Manager form.
- Existing parameters can be changed and republished to the same GitHub file.
- Parameter editor now supports: name, type, optional/required/conditional, default, placeholder, choices, and `requiredWhen` expression.
- Changing any parameter invalidates the old test receipt; Test must PASS again before Publish.
