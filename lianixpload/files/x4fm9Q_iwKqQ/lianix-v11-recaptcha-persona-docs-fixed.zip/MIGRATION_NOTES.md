# Migration notes

- User state is now mirrored to Firestore under `users/{uid}` so redeploying the site does not erase per-account state. Existing local browser state is migrated on the first login when no cloud state exists.
- The Tools page uses the supplied `index(1).html` design and reads endpoint definitions from `src/settings.json`.
- CMNTY proxy routes and the old AM bulk-create route were removed from public routing/deployment.
- The supplied upload was `index(1).html`; no replacement `index.js` or replacement AM Premium API source was included, so the old AM Premium automation is not reconnected to a new upstream.
- Deploy `firestore.rules` to the same Firebase project before production use.
