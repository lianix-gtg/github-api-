# Validation V7.7

- npm build validation: PASS
- dependency declaration scanner: PASS
- external packages used by web: 3 / 3 declared
- package.json JSON: PASS
- all Netlify Function JS syntax: PASS
- all scripts JS syntax: PASS
- GitHub auto dependency resolver syntax: PASS
- CommonJS/ESM dependency mode detection added
- Node built-in module detection uses `module.builtinModules`
- unknown npm package verification added before publish
- no node_modules bundled into deploy ZIP
- deploy ZIP root is flat
