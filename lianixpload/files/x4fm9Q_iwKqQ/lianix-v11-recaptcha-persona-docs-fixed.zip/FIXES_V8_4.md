# V8.4 — Chat LianixPload + 10 MB batch

- Chat attachment picker now accepts every file type and multiple files.
- `/upload` is LianixPload; `/upload1`–`/upload4` remain legacy alternative providers.
- Selection cap is 10 MB total per batch. Files are accepted in selection order until the cap is reached; remaining files are skipped.
- Upload Center and Tools Quick Upload use the same cumulative 10 MB batch rule.
- Files are uploaded sequentially so one failed file does not abort the whole batch.
- Current safe per-request file ceiling remains 3 MB because each file passes through a synchronous Netlify Function; the 10 MB cap is the total batch limit, not a single-request payload.
