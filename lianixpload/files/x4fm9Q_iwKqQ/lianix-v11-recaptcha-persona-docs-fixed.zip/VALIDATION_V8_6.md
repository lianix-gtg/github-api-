# Validation V8.6

- Sidebar Upload UI: present at `/upload`
- Quick drag-drop Upload inside `/tools`: present
- Canonical public endpoint: `POST /api/upload`
- Legacy compatibility endpoint: `POST /api/lianixpload`
- Short file URL: `/f/<id>`
- API key: `X-API-Key: lianix`
- Endpoint card category: Tools
- File parameter: multipart field `file`
- Production build: PASS
