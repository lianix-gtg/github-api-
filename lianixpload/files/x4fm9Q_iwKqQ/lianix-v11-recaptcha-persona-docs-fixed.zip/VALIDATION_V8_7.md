# Validation V8.7

- `npm run build`: PASS
- `_api-meta.js` syntax: PASS
- `admin-api-publish.js` syntax: PASS
- Netfgen stale metadata regression case added to `npm test`.
- Production build remains deterministic; heuristic regression tests remain under `npm test`.
