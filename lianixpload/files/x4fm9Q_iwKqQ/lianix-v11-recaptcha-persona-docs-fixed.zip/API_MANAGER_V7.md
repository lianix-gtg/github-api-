# Lianix API Manager V7.2

## Environment Variables
Wajib:
- `ADMIN_PASSWORD`
- `GITHUB_TOKEN` — fine-grained PAT dengan repository permission **Contents: Read and write**

Opsional:
- `GITHUB_OWNER=lianix-gtg`
- `GITHUB_REPO=github-api-`
- `GITHUB_BRANCH=main`

Set variable runtime dengan scope **Functions** di Netlify. Jangan simpan token di browser-side HTML/JS.

## Flow
1. Paste/upload JS scraper.
2. **Auto Detect** melakukan syntax parse dan infer parameter.
3. Admin boleh memperbaiki hasil parameter/metadata.
4. **Test** memvalidasi kode + metadata. Runtime Probe opsional untuk endpoint yang sudah hidup; POST multipart mendukung sample image/audio/video/file/folder maksimal 3 MB / 30 file.
5. Server mengeluarkan test receipt singkat yang terikat ke hash kode + metadata.
6. **Publish** ditolak jika belum Test, test sudah kedaluwarsa, atau kode/metadata berubah setelah Test.
7. Server menulis file GitHub menggunakan `GITHUB_TOKEN` dari ENV.
8. `/tools` membaca `/api/github-registry` dan merender hasil sync.

Canvas default ke folder `canvasweb`.

## Monitoring
- Built-in Netlify Functions mencatat usage server-side.
- Endpoint absolut dari registry dicatat melalui metrics endpoint setelah request UI.
- Usage keys menyimpan field agregasi di key sehingga statistik tidak perlu membaca ribuan Blob satu-per-satu.
- Health checker berjalan setiap 30 menit dan memakai concurrency + hard time budget agar tidak melewati limit Scheduled Function.
- Status: `online`, `degraded`, `error`, `untested`.
- Ranking tersedia untuk 1/7/30 hari.

## Safety
Kode JS draft tidak dieksekusi secara arbitrer di environment yang menyimpan secret. Auto Detect menggunakan parser AST. Runtime Probe hanya memanggil endpoint yang dapat di-resolve.
