# V9.4 — Netlify Native Canvas Bundler Fix

Netlify build log showed esbuild fallback for `brat`, `fakecall`, and `fakegc`.
All three functions depend on `@napi-rs/canvas`, a native Node-API addon.

`netlify.toml` now keeps `@napi-rs/canvas` external for those three functions only:

```toml
[functions.brat]
  external_node_modules = ["@napi-rs/canvas"]

[functions.fakecall]
  external_node_modules = ["@napi-rs/canvas"]

[functions.fakegc]
  external_node_modules = ["@napi-rs/canvas"]
```

This lets Netlify copy the package/native binaries intact instead of attempting to inline the native addon with esbuild.
