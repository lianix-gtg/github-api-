# Environment Variables — Netlify

Buka **Project configuration → Environment variables** dan pastikan variable runtime memiliki scope **Functions**.

| Key | Wajib? | Keterangan |
|---|---|---|
| `ADMIN_PASSWORD` | ✅ | Password `/yoenadmin`. Pakai password kuat. |
| `GITHUB_TOKEN` | ✅ untuk API Manager | Fine-grained GitHub PAT untuk repo `lianix-gtg/github-api-`, permission **Contents: Read and write**. Hanya dibaca Netlify Function. |
| `GITHUB_OWNER` | Opsional | Default `lianix-gtg`. |
| `GITHUB_REPO` | Opsional | Default `github-api-`. |
| `GITHUB_BRANCH` | Opsional | Default `main`. |
| `TELEGRAM_BOT_TOKEN` | Opsional | Token bot Telegram untuk notifikasi. |
| `TELEGRAM_CHAT_ID` | Opsional | Tujuan notifikasi Telegram. |

## Netlify Blobs
Project ini memakai `@netlify/blobs` dari Netlify Functions. Tidak perlu menaruh Personal Access Token Netlify di HTML maupun membuat `NETLIFY_API_TOKEN` khusus untuk aplikasi ini. Store dibuat saat function berjalan agar konteks Blobs dari Netlify dipakai otomatis.

## GitHub security
- Jangan pernah menaruh `GITHUB_TOKEN` di `tools.html`, `admin.html`, `settings.json`, atau repo publik.
- Fine-grained PAT cukup diberi akses hanya ke repository yang dibutuhkan.
- Permission untuk API Manager harus **Contents: Read and write**, karena Admin dapat create/update file.

## API Manager
1. Login `/yoenadmin`.
2. Paste/upload kode JS.
3. **Auto Detect**.
4. Koreksi metadata/parameter bila perlu.
5. Klik **Test** sampai PASS.
6. Baru **Publish GitHub** diizinkan.
7. `/tools` sync registry dan merender API baru.

Untuk Canvas, default publish diarahkan ke `canvasweb`.

## Public API key

Public API key sekarang dibuat sama untuk semua user sesuai konfigurasi project:

```text
X-API-Key: lianix
```

`/tools` mengisi key `lianix` otomatis pada TRY API dan code examples. Endpoint `/api/user/api-key` tetap tersedia untuk kompatibilitas dan selalu mengembalikan `lianix`; endpoint ini tidak memerlukan Firebase atau Netlify Blobs.

`API_INTERNAL_SECRET` tetap opsional untuk health-check internal. Jika kosong, server memakai secret server yang tersedia sebagai sumber token internal.


## Chat AI provider

`CMNTY_API_KEY` (dan opsional `CMNTY_API_KEY_2` s.d. `_10`) dapat dipasang untuk model-model CMNTY. Default Overchat memiliki fallback ke `/api/hackai` jika key CMNTY belum tersedia.

## Netlify Blobs compatibility

Function project ini memakai Lambda-compatible handlers. `_store.js` sekarang memanggil `connectLambda(event)` sebelum `getStore(name)`, sesuai mode tersebut. Tidak perlu menaruh site token Netlify di HTML. Jika konteks Blobs tidak tersedia, endpoint yang tidak kritis memakai fallback memory agar tidak berubah menjadi HTTP 500.

## Snippet private recovery
Recommended:

```env
SNIPPET_MASTER_KEY=use-a-long-random-secret-here
```

Private snippets are encrypted with the user's password and also with this server-only recovery key so the Admin Content manager can view/manage private snippets. If omitted, `ADMIN_PASSWORD` is used as the recovery key; keep it stable or set `SNIPPET_MASTER_KEY` before creating private snippets.

## V9.0 Email login code

Email login code is sent server-side. Configure these Netlify environment variables:

```env
RESEND_API_KEY=re_xxxxxxxxx
AUTH_EMAIL_FROM=Lianix <login@your-domain.com>
AUTH_CODE_SECRET=replace-with-a-long-random-secret
```

For production, `AUTH_EMAIL_FROM` should use a sender/domain verified with the email provider. `AUTH_CODE_SECRET` is used to HMAC login codes and sign the local email-code session.

The existing Google and GitHub login continue using Firebase. Email-code login is an application session and does not expose the OTP or provider API key to the browser.

## V9.1 Plan credentials + biometric snippet

Recommended additional secrets:

```env
PLAN_MASTER_KEY=use-a-long-random-plan-recovery-key
WEBAUTHN_SECRET=use-another-long-random-secret
```

- `PLAN_MASTER_KEY` encrypts the recoverable copy of Abyz/Gokil credential passwords. If omitted, `ADMIN_PASSWORD` is used.
- `WEBAUTHN_SECRET` signs short-lived WebAuthn challenges for private snippet biometric/passkey unlock. If omitted, `SNIPPET_MASTER_KEY` or `ADMIN_PASSWORD` is used.
- Keep these values stable after creating credentials/passkeys.
- WebAuthn requires HTTPS (localhost is the normal development exception) and a browser/device authenticator that supports user verification.

## reCAPTCHA Checkbox
Login/Register/OAuth memakai Google reCAPTCHA Checkbox dan diverifikasi server-side sebelum auth diteruskan.
Tambahkan Environment Variables berikut di Netlify:

- `RECAPTCHA_SITE_KEY` — public site key reCAPTCHA v2 Checkbox untuk domain `f24nt-ai.biz.id`.
- `RECAPTCHA_SECRET_KEY` — secret key pasangan site key (jangan pernah taruh di frontend/repo).

Daftarkan tipe challenge **reCAPTCHA v2 → “I'm not a robot” Checkbox** dan tambahkan domain produksi. Setelah mengubah environment variables, deploy ulang site.
