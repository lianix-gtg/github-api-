# V8.6 Upload API canonicalization

- Menu Upload tetap berada di sidebar Tools dan membuka UI drag-drop `/upload`.
- Endpoint publik canonical: `POST /api/upload`.
- Alias lama `POST /api/lianixpload` tetap dipertahankan agar kompatibel.
- Endpoint menggunakan `X-API-Key: lianix`.
- Response sukses berisi `success`, `id`, `filename`, `mime`, `size`, `url`, dan `path`.
- Short link file tetap `/f/<id>`.
- Card `LianixPload API` berada di kategori Tools dan bisa dipakai melalui TRY API.
