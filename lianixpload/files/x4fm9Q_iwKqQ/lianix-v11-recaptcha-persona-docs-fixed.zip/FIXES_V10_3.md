# Lianix V10.3 — Public Docs + Register First Auth

- Root `/` dan `/docs` dapat dibaca tanpa login.
- Interaksi pada docs saat belum login membuka auth gate.
- Pengguna baru diarahkan ke Register dulu, lalu transisi smooth ke Login.
- Registry akun server-side ditambahkan agar Login menolak akun aplikasi yang belum diregistrasikan.
- Google dan GitHub memakai logo SVG resmi/brand mark, bukan huruf/simbol placeholder.
- Logo Lianix baru dipakai pada auth, topnav docs, favicon/apple touch icon.
- Animasi logo brand dipertahankan dan dipakai pada auth/docs.
- OG preview diganti menjadi logo Lianix baru, tanpa teks domain.
- Wording docs diubah agar tidak lagi menawarkan Guest flow.

Validation:
- `node --check assets/global-auth.js`: PASS
- `node --check netlify/functions/account-registry.js`: PASS
- Full npm test membutuhkan dependency install; install tidak selesai dalam runtime validation window.
