# Validation V7.2

- Reconstructed broken `index.html` script tail and moved app logic to `/app-runtime.js`.
- Added fail-open boot watchdog so loading cannot permanently cover `/app`.
- Default text chat uses `/api/hackai` instead of missing model-specific local routes.
- Added `/app`/`/chat/*` routes in both `_redirects` and `netlify.toml`.
- ZIP is packaged flat at root to avoid one-level-too-deep Netlify deploys.
- Auto parameter types prioritize URL/link semantics before image/audio/video names.
- Folder/image/audio/video/file inputs render as file controls; URL renders as URL text field.
- Admin test supports multipart sample upload for file/media/folder on POST, with client+server size limits.
- Required file/folder validation added.
- All JavaScript functions and inline scripts pass `node --check` in the source audit.
- `netlify.toml` parses successfully.
- Function redirect targets and relative `require()` targets checked.
