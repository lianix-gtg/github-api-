# Lianix V8.0 — LianixPload

## LianixPload
- Endpoint upload: `POST /api/lianixpload`
- Header public API: `X-API-Key: lianix`
- Body: `multipart/form-data`, field `file`
- Semua tipe file diterima.
- Batas aman: 3 MB/file karena upload masuk lewat Netlify synchronous Function.
- File disimpan ke GitHub: `lianixpload/files/<id>/<filename>`
- Metadata: `lianixpload/meta/<id>.json`
- Public link: `https://<domain>/f/<id>`
- `/f/<id>` bekerja walaupun repository private karena byte diambil server-side dengan GitHub token.
- HTML/SVG/JavaScript/XML dipaksa sebagai attachment untuk mencegah same-origin script execution.
- Raster image/audio/video/PDF dapat disajikan inline.
- Jika metadata commit gagal setelah file commit, file di-rollback otomatis.

## GitHub watcher
Commit yang hanya mengubah `lianixpload/*` tidak me-refresh daftar API Tools. Commit registry/API tetap memicu live sync.

## Environment
Tetap gunakan:
- `GITHUB_TOKEN`
- `GITHUB_OWNER`
- `GITHUB_REPO`
- `GITHUB_BRANCH`
- `ADMIN_PASSWORD`

Token GitHub butuh Contents: Read and write.
