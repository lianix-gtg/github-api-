# V9.3 — Mandatory QRIS Payment Proof

- Manual QRIS now requires a screenshot/image proof before submission.
- Proof UI supports click and drag/drop and uploads through LianixPload.
- Screenshot limit follows LianixUpload: up to 10 MB with chunking when needed.
- Backend validates the proof exists in LianixPload, is non-empty, and has image/* MIME.
- Transaction stores proof id/url/download URL/filename/MIME/size/upload time.
- Admin transaction list shows proof preview and full-size link.
- Approve button is disabled when proof is missing in UI.
- Admin approval endpoint independently rejects approval if proof is missing/invalid.
- Telegram review notification includes proof URL.
