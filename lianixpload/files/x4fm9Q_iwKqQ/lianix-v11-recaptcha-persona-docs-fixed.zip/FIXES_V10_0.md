# Lianix V10.0 — Unified Auth + Durable Account Workspace

## Auth
- Semua halaman user utama memakai login wajib: Google, GitHub, atau kode email 6 digit.
- Guest/demo fallback di Chat AI tidak lagi menjadi jalur login.
- Auth UI dimodernkan dengan tema orange/cream, animasi logo, hover/sheens, dan responsive layout.
- Firebase loader dibuat tahan race-condition jika Firebase script sudah ada di halaman tetapi belum selesai load.

## Durable user data
- Chat, projects, profile, theme, selected model, settings, usage state, dan plan state di Chat AI disinkronkan ke `/api/user/data`.
- Netlify Blobs menjadi primary account store.
- Recovery mirror terenkripsi AES-256-GCM disimpan di GitHub `user-data/<uid-hash>.json`.
- Login email memiliki UID stabil berdasarkan email; Firebase Google/GitHub menggunakan UID Firebase stabil.
- Upload history juga disinkronkan ke account state.
- Plan Abyz/Gokil sekarang menggunakan account UID sebagai kunci utama, dengan device ID hanya sebagai fallback legacy.
- Logout melakukan forced sync; page hide melakukan best-effort forced backup.

## Cross-domain recovery
- Gunakan Firebase project yang sama dan tambahkan domain baru sebagai Authorized Domain untuk Google/GitHub login.
- Pertahankan `USER_DATA_MASTER_KEY` yang sama di deployment baru agar GitHub recovery backup lama tetap dapat didekripsi.
- Pertahankan GitHub repository/config yang sama jika ingin recovery lintas site/project Netlify.

## Docs / branding
- `/` membuka Docs/Landing langsung; `/docs` tetap kompatibel.
- Docs didesain ulang bergaya developer portfolio dengan orange/cream Lianix theme.
- Logo Lianix baru dianimasikan pada landing, auth, chat loader/sidebar dan AI response avatar.
- Tombol AI menuju `/app`; Get API Key menuju `/tools`.
- OG/Twitter preview seluruh halaman public memakai `/assets/lianix-og.png`; referensi OG domain F24nT lama dihapus.

## AI model runtime
- Admin Node.js Adapter sekarang benar-benar menjadi runtime model melalui `/api/model/run`.
- Adapter CommonJS dijalankan dalam VM sandbox tanpa `process`, `require`, atau ENV.
- Hanya local AI routes melalui `ctx.request()` yang diperbolehkan.
- Model-run dan file analyzer Chat sekarang membutuhkan sesi login user.
- Timer timeout adapter dibersihkan setelah sukses/gagal agar invocation tidak menggantung.

## Upload
- Hanya archive ZIP/RAR/7Z/TAR/GZ/TGZ yang memakai landing preview sebelum download.
- Image/audio/video/PDF tetap inline; file lain download normal.

## TRY API
- Output kosong sekarang tetap menampilkan HTTP status.
- JSON, URL, image, video, audio dan binary download punya renderer masing-masing.
- Error/timeout selalu membuka result pane, bukan spinner stuck.
