# V10.5 UI/Auth refresh
- Removed embedded legacy Chat auth UI; global auth is the single auth gate.
- F24nT AI name restored for AI while Lianix remains platform brand.
- Added new logo-break-to-candle-person intro on root and Chat.
- Root / remains public Docs; /app and feature routes require auth.
- Added moving real JavaScript/HTML/CSS/C++ logos.
- Added local clock and IP-based prayer-time cards.
- Added scroll reveal sections and unified motion/theme.
- Replaced legacy chat brand SVG with current Lianix logo asset.
