# Lianix Public API Key

Versi ini memakai satu public API key bersama:

```text
X-API-Key: lianix
```

Tools mengisi key tersebut otomatis. Tidak ada lagi pembuatan key per-user/Firebase untuk public API.
