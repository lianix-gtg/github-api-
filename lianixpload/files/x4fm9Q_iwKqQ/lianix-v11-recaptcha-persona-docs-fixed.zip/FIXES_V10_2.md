# Lianix V10.2 — Final Auth & Persistence Hardening

- Semua halaman workspace user memakai auth-lock sebelum first paint dan `assets/global-auth.js`.
- Login wajib: Google, GitHub, atau kode email 6 digit. Guest lama di `/app` tidak lagi menjadi jalur masuk workspace karena halaman tetap dikunci oleh unified auth.
- UI auth memakai logo Lianix orange/cream, animated buttons/sheens, responsive card, dan profile chip.
- `assets/account-page-sync.js` menyinkronkan cache lintas halaman (chat, artifacts, upload history, memory/profile) ke account store server-side.
- `/app` memakai `assets/user-data-sync.js` untuk chat/projects/theme/model/settings/usage/profile/artifacts/upload history.
- Logout melakukan forced sync sebelum session dibuang.
- Netlify Blobs menjadi primary store; recovery terenkripsi AES-256-GCM disimpan di GitHub `user-data/<uid-hash>.json`.
- Plan sekarang account-bound. Device ID hanya fallback legacy; credential plan dan QRIS yang di-approve disimpan ke key akun login.
- Payment status/submit memverifikasi ownership transaksi account-bound.
- Metadata OG public dibersihkan ke brand Lianix dan `/assets/lianix-og.png`.
- `/` tetap membuka Docs/Landing, `/docs` kompatibel.
- Validator build diperbaiki: PASS baru dicetak setelah seluruh pemeriksaan V10 selesai.
