# Lianix V7.2 — deploy notes

## Environment variables (Netlify)
- `ADMIN_PASSWORD`
- `GITHUB_TOKEN` (fine-grained token, repository Contents: Read/Write)
- `GITHUB_OWNER=lianix-gtg`
- `GITHUB_REPO=github-api-`
- `GITHUB_BRANCH=main`

Never place `GITHUB_TOKEN` in HTML or browser JavaScript.

## Important for Netlify deploy
This archive is flat: `index.html`, `_redirects`, `netlify.toml`, `package.json`, and `netlify/` are at the ZIP root.
For Netlify Functions, deploy the project as a build (Git-connected Netlify project, logged-in Netlify Drop that runs the build, or Netlify CLI), so dependencies and `netlify/functions` are bundled.

After deploy, these checks should NOT return 404:
- `/app` -> app HTML
- `/app-runtime.js` -> JavaScript
- `/api/status` -> function response
- `/api/github-registry` -> registry response
- `/api/hackai?text=test` -> function response (200/4xx/5xx is possible depending on upstream, but it must not be route 404)

## Parameter auto-detect
Semantic priority:
- `imgUrl`, `imageLink`, `link_img`, `audioUrl`, `videoLink` -> `url` (typed URL field)
- `folder`, `directory`, `dir` -> folder upload
- `image`, `img`, `photo` -> image upload
- `audio`, `voice`, `music` -> audio upload
- `video`, `movie`, `clip` -> video upload
- `file`, `pdf`, `zip`, `document` -> generic file upload
- numeric-looking params -> number
- detected fixed comparison choices -> select when 2+ choices are found

The analyzer also recognizes request query/body, event body/query parameters, `formData.get()`, `searchParams.get()`, `req.files`, and common `upload.single()/upload.array()` fields.
