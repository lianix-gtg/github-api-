# V7.9 Netlify Build Fix

- Production `npm run build` no longer executes heuristic Auto Detect regression tests.
- Auto Detect tests remain available as `npm test` / `npm run test:autodetect`.
- Netlify Node version is pinned to 24.20.0 to match the deployment runtime shown in the build log.
- Node engine range is aligned to `>=22.12 <25`.
- Production build now performs deterministic checks only: dependency declaration + static build validation.
