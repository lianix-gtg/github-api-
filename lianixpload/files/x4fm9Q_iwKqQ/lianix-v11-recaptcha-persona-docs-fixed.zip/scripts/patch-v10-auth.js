const fs=require('fs'),path=require('path');
const root=path.resolve(__dirname,'..');
const userPages=['docs.html','index.html','tools.html','upload.html','snippets.html','snippet.html','snippet-new.html','plan.html','dashboard.html','articles.html','artifacts.html','recents.html'];
for(const name of userPages){
  const p=path.join(root,name); if(!fs.existsSync(p)) continue;
  let s=fs.readFileSync(p,'utf8');
  // Mark page locked before first paint.
  s=s.replace(/<html([^>]*)>/i,(m,a)=>{ if(/class=/.test(a)) return m.replace(/class=["']([^"']*)["']/i,(x,c)=>`class="${c} lianix-auth-pending"`); return `<html${a} class="lianix-auth-pending">`; });
  if(!s.includes('/assets/lianix-shell.css')) s=s.replace(/<\/head>/i,'<link rel="stylesheet" href="/assets/lianix-shell.css">\n</head>');
  const inject=[];
  if(!s.includes('/assets/global-auth.js')) inject.push('<script src="/assets/global-auth.js"></script>');
  if(name==='index.html' && !s.includes('/assets/user-data-sync.js')) inject.push('<script src="/assets/user-data-sync.js"></script>');
  if(inject.length) s=s.replace(/<\/body>/i,inject.join('\n')+'\n</body>');
  fs.writeFileSync(p,s);
}
// Disable legacy chat auth overlay when unified auth is present.
let ip=path.join(root,'index.html'),s=fs.readFileSync(ip,'utf8');
if(!s.includes('window.__LIANIX_UNIFIED_AUTH=1')) s=s.replace(/<head>/i,'<head>\n<script>window.__LIANIX_UNIFIED_AUTH=1;</script>');
s=s.replace(/function showAuth\(\)\{document\.getElementById\("auth"\)\.style\.display="flex"\}/, 'function showAuth(){if(window.__LIANIX_UNIFIED_AUTH)return;document.getElementById("auth").style.display="flex"}');
fs.writeFileSync(ip,s);
