const assert = require('node:assert');
const { analyzeCode } = require('../netlify/functions/_api-meta');

const cli = `/* @lianix-meta\n{\"id\":\"netfgen\",\"name\":\"Netfgen\",\"inputs\":[{\"name\":\"auto -n <jumlah>\",\"type\":\"text\",\"required\":false}]}\n*/\n#!/usr/bin/env node\nconst axios = require(${JSON.stringify('axios')});
console.log(\`NFTOKEN scraper Node.js
Perintah:
 node nfscraper.js test [opsi]
 node nfscraper.js stats [opsi]
 node nfscraper.js auto -n <jumlah> [opsi]
 node nfscraper.js convert '<cookie>' [opsi]
 node nfscraper.js check '<cookie>' [opsi]
Opsi:
 --proxy-file <file> file proxy
 --proxy "h:p,h:p" daftar proxy langsung
 --ua "<string>" paksa User-Agent
 -n, --count <n> jumlah token (default 5)
 -p, --plan <plan> premium | standard | basic
 -o, --out <file> output (default tokens.txt)
 -c, --conc <n> konkuransi (default 25)\`);
`;
const m=analyzeCode(cli,{filename:'netfgen.js'});const by=Object.fromEntries(m.inputs.map(x=>[x.name,x]));
for(const n of ['command','cookie','proxyFile','proxy','ua','count','plan','out','conc'])assert(by[n],`missing ${n}`);
assert.equal(by.command.type,'select');assert.equal(by.command.required,false);assert.equal(by.command.default,'auto');assert(!by['auto -n <jumlah>'],'stale embedded input must be ignored');
assert.equal(by.count.type,'number');assert.equal(by.count.required,false);assert.equal(by.count.default,5);
assert.equal(by.plan.type,'select');assert.deepEqual(by.plan.choices,['premium','standard','basic']);
assert.equal(by.out.type,'text');assert.equal(by.out.default,'tokens.txt');
assert.equal(by.cookie.required,false);assert.equal(by.cookie.conditionalRequired,true);assert.deepEqual(by.cookie.requiredWhen.command,['convert','check']);
assert(m.dependencies.includes('axios'),'axios dependency not detected');

const comment=analyzeCode(`// parameter: imageLink:url:required, folder:folder:optional, quality:number:optional\nmodule.exports=async function scrape(imageLink, folder, quality){ return imageLink }`,{filename:'comment.js'});
const cb=Object.fromEntries(comment.inputs.map(x=>[x.name,x]));assert.equal(cb.imageLink.type,'url');assert.equal(cb.imageLink.required,true);assert.equal(cb.folder.type,'folder');assert.equal(cb.folder.required,false);assert.equal(cb.quality.type,'number');

const jsdoc = analyzeCode(`#!/usr/bin/env node
/**
 * @param {string} command - Perintah yang dijalankan (test|auto|stats|convert|check)
 * @param {Object} options - Opsi konfigurasi
 * @param {number} [options.count=5] - Jumlah token yang dihasilkan (untuk auto)
 * @param {string} [options.plan] - Plan token: premium|standard|basic
 * @param {string} [options.out=tokens.txt] - File output hasil token
 * @param {string} [options.proxyFile] - File berisi daftar proxy
 * @param {string} [options.proxy] - Daftar proxy langsung
 * @param {string} [options.ua] - Paksa User-Agent tertentu
 * @param {number} [options.concurrency=25] - Konkuransi scan proxy
 * @param {string} [cookie] - Cookie untuk convert/check
 */
function run(command, options){ return command + String(options?.count||5) }`,{filename:'nfscraper.js'});
const jb=Object.fromEntries(jsdoc.inputs.map(x=>[x.name,x]));
assert(jb.command&&jb.command.required===true,'JSDoc command must be required');
assert.equal(jb.command.type,'select');assert.deepEqual(jb.command.choices,['test','auto','stats','convert','check']);
assert(!jb.options,'Object options container must not become a form field');
assert.equal(jb.count.required,false);assert.equal(jb.count.default,5);assert.equal(jb.count.type,'number');
assert.equal(jb.plan.required,false);assert.equal(jb.plan.type,'select');assert.deepEqual(jb.plan.choices,['premium','standard','basic']);
assert.equal(jb.out.default,'tokens.txt');assert.equal(jb.concurrency.default,25);
assert.equal(jb.cookie.required,false);assert.equal(jb.cookie.conditionalRequired,true);assert.deepEqual(jb.cookie.requiredWhen.command,['convert','check']);

console.log('[AUTO DETECT TEST] PASS — CLI/help/JSDoc/comment/default/optional/dependency cases');
