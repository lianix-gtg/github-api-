const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
const declared = new Set([...Object.keys(pkg.dependencies || {}), ...Object.keys(pkg.optionalDependencies || {})]);
const builtins = new Set(require('module').builtinModules.flatMap(x => [x, x.replace(/^node:/,'')]));
const files = [];
function walk(dir) {
  for (const ent of fs.readdirSync(dir, { withFileTypes:true })) {
    if (['node_modules','.git'].includes(ent.name)) continue;
    const full = path.join(dir, ent.name);
    if (ent.isDirectory()) walk(full);
    else if (/\.(?:js|cjs|mjs)$/.test(ent.name)) files.push(full);
  }
}
walk(path.join(root,'netlify'));
walk(path.join(root,'scripts'));
const external = new Map();
const top = spec => spec.startsWith('@') ? spec.split('/').slice(0,2).join('/') : spec.split('/')[0];
for (const file of files) {
  const src = fs.readFileSync(file,'utf8');
  const patterns = [
    /require\(\s*['"]([^'"]+)['"]\s*\)/g,
    /require\.resolve\(\s*['"]([^'"]+)['"]\s*\)/g,
    /import\s+(?:[^'";]+?\s+from\s+)?['"]([^'"]+)['"]/g,
    /import\(\s*['"]([^'"]+)['"]\s*\)/g
  ];
  for (const rx of patterns) for (const m of src.matchAll(rx)) {
    const s = m[1]; if (!s || s.startsWith('.') || s.startsWith('/') || s.startsWith('node:')) continue;
    const name = top(s); if (builtins.has(name)) continue;
    if (!external.has(name)) external.set(name, []);
    external.get(name).push(path.relative(root,file));
  }
}
let failed = false;
for (const [name, where] of external) {
  if (!declared.has(name)) { console.error(`[DEPENDENCY CHECK] MISSING ${name} used by ${[...new Set(where)].join(', ')}`); failed = true; }
}
for (const name of declared) {
  try { require.resolve(name, { paths:[root] }); }
  catch (e) {
    // During a fresh Netlify build npm installs before this script. If node_modules exists, this is a real failure.
    if (fs.existsSync(path.join(root,'node_modules'))) { console.error(`[DEPENDENCY CHECK] NOT INSTALLED ${name}: ${e.message}`); failed = true; }
  }
}
if (failed) process.exit(1);
console.log(`[DEPENDENCY CHECK] PASS — ${external.size} external package(s) declared.`);
