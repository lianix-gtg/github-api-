# Lianix V7.6 — Live Delete Sync & Hardening

## Live GitHub deletion sync
- Added `/api/github-state` to read the current GitHub branch commit SHA with `Cache-Control: no-store`.
- `/tools` watches the branch every 10 seconds while the page is visible.
- If the GitHub SHA changes, the GitHub registry cache is cleared and Tools refreshes automatically.
- When TRY API modal is open, refresh is deferred until the modal closes so user input is not lost.
- Admin GitHub create/save/upload/move/delete and API Publish broadcast a localStorage sync signal, so an open Tools tab refreshes immediately.
- Session GitHub scan cache reduced to 5 seconds and is explicitly invalidated on repository changes.

## UI hardening
- Removed duplicate `new-chat-btn` DOM id in `/app` by renaming only the internal id of the second button. Visual design and behavior are unchanged.
- Build validator now checks duplicate DOM ids in `index.html` too.

## Validation
- Build validator PASS.
- 43/43 Netlify Function modules load with external packages stubbed for initialization-only testing.
- All Netlify Function JS passes `node --check`.
- 11 inline production HTML scripts pass JS syntax validation.
- JSON/TOML parsing PASS.
- Production DOM duplicate IDs: none.
- `/api/github-state` GET/405 behavior smoke-tested.
