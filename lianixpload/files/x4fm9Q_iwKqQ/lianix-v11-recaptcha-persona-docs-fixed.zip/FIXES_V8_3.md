# Lianix V8.3 — Upload, Runtime Metadata, Monitoring

- Added `/dashboard` live monitoring UI with smooth counters, API leaderboard, user/device leaderboard, and API health.
- Added `/api/public-stats` aggregate endpoint (7-day usage, health, top API, top user/device).
- Added stable client/device usage identity using `X-Lianix-Client`; public API key remains `lianix`.
- Added local `/api/brat` generator so Brat no longer depends on a missing GitHub backend.
- GitHub registry now analyzes JS server-side with `_api-meta.js`; Tools consumes that server metadata instead of relying only on the old browser parser.
- Strengthened lexical parameter fallback for exported scraper functions, destructuring, CLI flags, optional/default values, and names such as `netfgen`/`brat`.
- Tools main page now includes LianixPload Quick Upload drag/drop.
- Upload Center now accepts multiple files, all file types including ZIP/RAR/APK, and uploads sequentially with per-file short links/history.
- `/upload` and Tools send `X-Lianix-Client` so uploader/API usage contributes to user leaderboard.
