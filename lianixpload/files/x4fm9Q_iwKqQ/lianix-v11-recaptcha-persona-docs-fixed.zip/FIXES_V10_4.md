# Lianix V10.4
- Docs landing redesigned from uploaded video reference using Lianix branding and palette.
- All visible F24nT branding renamed to Lianix.
- New animated Lianix intro/logo motion replaces legacy loader mark.
- Chat UI refreshed with coherent orange/cream motion system.
- Auth persistence hardened so temporary registry/network errors do not force already-verified users to log in again.
- OG/favicon references normalized to new Lianix assets.
