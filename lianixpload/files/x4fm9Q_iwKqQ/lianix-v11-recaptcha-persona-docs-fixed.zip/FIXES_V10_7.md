# Lianix / F24nT AI V10.7

- Homepage canonicalized to `/`; `/docs` redirects to `/`.
- Docs lower-half redesigned with animated showcase cards, flow section, marquee, modern documentation cards and new footer.
- Hero identity animation rebuilt: complete Lianix mark breaks into fragments and reveals a moving person holding a floating Lianix balloon.
- Local time and prayer-time behavior from V10.6 retained.
- Chat UI refreshed with warm cream/orange workspace styling, improved composer, panels, artifacts and interaction states.
- Code Preview fixed so switching Code -> Preview restores/rebuilds iframe `srcdoc` reliably.
- Artifact Code/Preview switching hardened with a persistent source snapshot.
- Effort `Sedang`, `Tinggi`, `Ekstra`, and `Maks` automatically enable the high-level thinking/process mode.
- AI generation status now adapts to task type. Coding prompts show observable application stages such as analyzing requirements, composing code, syntax checks, and preparing preview.
- System activity is expandable and explicitly reports only application-level process metadata, not private model reasoning.
- Generic injected Try controls are guarded so unauthenticated use opens the unified auth instead of failing silently.
