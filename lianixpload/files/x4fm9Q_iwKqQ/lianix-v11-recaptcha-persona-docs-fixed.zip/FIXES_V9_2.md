# Lianix V9.2 — Manual QRIS

- Menghapus integrasi Xentral dari flow pembayaran.
- QRIS menggunakan asset `/assets/qris-manual.jpg` dari gambar QRIS yang diberikan owner.
- `POST /api/payment/create` membuat transaksi manual berstatus `pending`.
- `POST /api/payment/submit` mengubah status menjadi `review` setelah user menekan **Saya Sudah Bayar**.
- `POST /api/payment/status` hanya membaca status transaksi lokal; tidak memanggil payment gateway.
- Admin panel Transaksi memiliki tombol **Approve** dan **Tolak / Batal**.
- `POST /api/admin/transaction/action` hanya menerima session Admin yang valid.
- Approve mengaktifkan Abyz/Gokil di server sesuai jumlah hari transaksi.
- Reject tidak mengaktifkan plan.
- `/api/payment/cancel` publik ditolak dengan HTTP 403 karena keputusan pembayaran hanya boleh dilakukan Admin.
- QRIS diperbesar agar lebih mudah discan.
- Tidak membutuhkan `XENTRAL_API_KEY`.
