# Lianix V9.0 — AI Model Manager, Real Activity, ZIP Chat, Email Code Login

## AI Model Manager
- Added Admin > AI Models.
- Add, rename, edit, enable/disable, replace, and delete models.
- View the generated adapter JavaScript for each model.
- Test a model server-side with real latency measurement.
- Test states: green (normal), yellow (slow), red (failed/very slow).
- Test result persists in the GitHub-backed model registry so `/app` can show status and ms.
- Public `/api/models` dynamically feeds the chat model selector.

## Real AI activity
- Removed fake rotating thinking-stage text.
- Chat now shows observable application events only: preparing/uploading attachment, opening ZIP, sending model HTTP request, receiving response, latency, parse success/failure.
- Internal model chain-of-thought is not exposed or fabricated.

## Attachments and ZIP analysis
- Drag/drop multiple files directly onto the composer.
- Folder drops are packed to ZIP before attachment.
- Non-image files upload through LianixPload and receive `/f/<id>` URLs.
- ZIP analysis supports normal ZIP central-directory parsing and Store/DEFLATE entries.
- Archive safety caps: file count, total expanded size, extracted text count and per-entry size.
- ZIP content is read, never executed.

## Email code login and profiles
- Email login now uses a six-digit code delivered by email instead of an email password field.
- Code TTL, resend throttle, attempt limits, HMAC storage and signed local session added.
- Google/GitHub continue using Firebase and profile UI exposes provider, display name, email and avatar when available.

## Model registry safety
- Custom models are restricted to local `/api/...` endpoints.
- Admin model tests execute server-side.
- GitHub/API secrets remain server-side.
