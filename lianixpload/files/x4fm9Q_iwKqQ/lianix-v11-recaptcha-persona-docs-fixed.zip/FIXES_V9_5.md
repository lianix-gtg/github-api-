# Lianix V9.5 — JSDoc Parameter + Choice Button Fix

## Auto Detect
- Added full JSDoc `@param` parsing.
- `name` = required; `[name]` = optional; `[name=default]` = optional + default.
- Nested `options.count` is flattened to `count`; container `options` Object is not rendered as a user field when child options exist.
- Enum text such as `test|auto|stats` becomes `select` choices.
- JSDoc/comment explicit required/optional has higher priority than AST guesses and stale embedded metadata.
- `cookie untuk convert/check` becomes conditionally required when command is convert/check.
- Existing `parameter:` comment parser remains supported and has highest input-semantic priority.

## Tools/Admin choice controls
- Select parameters are rendered as explicit choice chips/buttons.
- The selected chip writes to a real hidden `data-param` field used by request serialization.
- Required/optional/conditional badges are visible.
- Default choice is pre-selected only when a real default exists.
- Conditional required validation runs after selected values are collected.
