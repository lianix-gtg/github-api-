# Lianix V10.1 — Unified Login + Durable Workspace

## Login wajib dan UI Auth
- Semua halaman workspace user memakai `assets/global-auth.js` dan initial auth-lock sebelum first paint.
- Login: Google, GitHub, atau kode email 6 digit. Guest tidak menjadi jalur workspace utama.
- `/app` dijembatani ke unified auth sehingga auth lama tidak muncul lagi sebagai layar kedua.
- Auth memakai logo Lianix baru, orange/cream theme, hover sheen, motion, profile chip, dan responsive mobile layout.

## Durable account data
- `/api/user/data` menyimpan workspace berdasarkan UID akun, bukan berdasarkan domain/browser.
- Primary: Netlify Blobs.
- Recovery: GitHub `user-data/<uid-hash>.json` terenkripsi AES-256-GCM.
- Chat, projects, artifacts, upload history, theme, model, settings, profile/avatar, usage, memory consent, sidebar state, dan plan UI disinkronkan.
- Logout melakukan forced sync dan tidak menghapus data server.
- Recents serta Upload melakukan hydrate dari account store setelah login.

## Domain/deploy migration
- Update deploy tidak mereset data.
- Pergantian custom domain pada Netlify site yang sama tidak mengubah account store.
- Untuk pindah Netlify site: gunakan Firebase project, GitHub repo, `USER_DATA_MASTER_KEY`, dan auth secrets yang sama agar recovery tetap dapat dibaca.
- Tambahkan domain baru ke Firebase Authorized Domains untuk login Google/GitHub.

## Branding / landing
- `/` membuka `docs.html`; `/docs` tetap kompatibel.
- Docs menjadi landing developer workspace dengan hero Lianix dan CTA ke AI (`/app`) dan Get API Key/Tools (`/tools`).
- Logo baru dipakai pada auth, landing, chat loader/sidebar, dan avatar AI.
- OG/Twitter asset memakai `/assets/lianix-og.png`; domain F24nT lama dihapus.
- Palette global legacy mint/yellow disatukan ke orange/cream Lianix.

## Route fixes
- Menambahkan `/api/auth/session`, `/api/user/data`, dan `/api/model/run` di `_redirects` dan `netlify.toml`.
- Validator build sekarang gagal jika auth script salah tersisip ke internal HTML template atau route persistence hilang.
