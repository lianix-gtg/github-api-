# F24nT AI / Lianix V10.6 — Model JS + Universal Attachment + System Audit

## AI Model Manager
- Fixed `modelForm is not defined`.
- Model JS is now an editable textarea in Admin > AI Models.
- Source is persisted in `app-models.json`, not just generated for display.
- Save/Test use the exact source shown in the editor.
- Capability auto-detection reads explicit comment metadata such as `parameter:` and `supports:` and verifies it against source usage.
- Source adapter is executed in a restricted server VM. It can use `ctx.request`, `ctx.fetch`, `ctx.attachments`, `ctx.capabilities`, and `ctx.trace` without exposing `process`, environment variables, or unrestricted `require`.

## Automatic attachments
- Every chat file is uploaded to Lianix storage before the AI request.
- Image previews remain normal images in the chat, but the AI pipeline receives the Lianix URL.
- TXT/code/ZIP contents are inspected server-side and attached as raw/summary context.
- Binary/document/media files still receive a stable Lianix URL even when text extraction is unavailable.
- Direct URLs in the message are added to the model attachment context.
- Custom model adapters receive normalized attachments automatically through `ctx.attachments`.
- File cards persist in conversation history.

## Long paste
- Desktop: long clipboard text is automatically converted to a TXT attachment.
- Mobile: long clipboard text asks whether to continue as TXT or normal text.
- Long plain text is no longer replaced by a temporary browser blob that the AI cannot read.

## Drag and drop
- Existing file/folder drag-drop remains supported.
- Folder drops are zipped.
- URL/link drops are captured as a text attachment and enter the same upload/analyze pipeline.

## System activity
- Added a collapsible System activity panel.
- Shows real application events: upload, parsing, capability routing, adapter compile/run, request endpoint, HTTP result, latency and errors.
- It deliberately does not expose or fabricate private model chain-of-thought.
