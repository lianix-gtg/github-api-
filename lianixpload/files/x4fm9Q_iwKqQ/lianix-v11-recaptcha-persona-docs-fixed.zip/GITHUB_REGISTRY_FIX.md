# Lianix GitHub Dynamic API — Fix Notes

## Root cause for `/canvasweb`
The current remote `registry.json` maps Canvas to:

```json
{
  "id": "canvas",
  "name": "Canvas",
  "folder": "canvas",
  "enabled": true,
  "icon": "canvas"
}
```

So the old loader scanned `/canvas`, not `/canvasweb`.

The patched web supports both `folder` and `folders`, and also keeps a Canvas compatibility alias for `/canvasweb`.
Recommended remote registry entry:

```json
{
  "id": "canvas",
  "name": "Canvas",
  "folders": ["canvas", "canvasweb"],
  "enabled": true,
  "icon": "canvas"
}
```

If you only want `/canvasweb`, use `"folder": "canvasweb"` instead.

## Recommended JS metadata
The loader now accepts both the old schema (`desc`, `path`, `params`) and the complete schema (`description`, `endpoint`, `inputs`, `outputs`).

Example:

```js
/**
 * @name Quote Canvas
 * @desc Generate a quote image
 * @method POST
 * @endpoint /api/quote-canvas
 * @param {text} text - Quote text [required]
 * @param {text} author - Author [optional]
 */

module.exports = {
  id: "quote-canvas",
  name: "Quote Canvas",
  description: "Generate a quote image",
  method: "POST",
  endpoint: "/api/quote-canvas",
  inputs: [
    { name: "text", type: "text", label: "Quote text", required: true },
    { name: "author", type: "text", label: "Author", required: false }
  ],
  outputs: [
    { type: "image", label: "Result" }
  ],
  category: "canvas",
  tags: ["canvas", "image"]
};
```

Supported input types in the patched UI: `text`, `textarea`, `number`, `select`, `file`, `image`, `audio`, `video`, `folder`.

## Important: rendering vs executing
GitHub auto-scan can render a card from metadata, but a path such as `/api/quote-canvas` still needs a real backend route. Merely pushing arbitrary JS into the registry repo does not automatically create a Netlify Function in an already-deployed site.

For an endpoint to work, use one of these models:

1. The metadata `endpoint` points to an already-live absolute API URL, or
2. The JS is included/deployed as a Netlify Function during the site build, or
3. Build a controlled server-side runner/router for registry modules.

The current patch fixes discovery/rendering and GitHub synchronization. It does not blindly execute remote JavaScript on the server.
