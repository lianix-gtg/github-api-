# V9.1 Security Access

- Added Abyz/Gokil username/password credential management in Admin.
- Password verification uses scrypt; an Admin-readable recovery copy is AES-256-GCM encrypted with PLAN_MASTER_KEY.
- Added plan login audit: server-derived IP, browser fingerprint, user-agent, time, success/failure.
- Added private snippet password recovery display/reset in Admin without storing plaintext passwords in GitHub.
- Added private snippet access audit for password unlock, raw, download, and biometric unlock.
- Added optional WebAuthn biometric/passkey unlock for private snippets with userVerification required.
- Added stable browser/device fingerprint helper for audit correlation.
