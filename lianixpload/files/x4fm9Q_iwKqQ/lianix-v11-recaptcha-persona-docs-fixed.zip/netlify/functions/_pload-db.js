const { makeStore, connectBlobs } = require('./_store');
const { getRaw } = require('./_github');

const STORE_NAME = 'lianixpload-db';
function store(){ return makeStore(STORE_NAME); }
function key(id){ return `files/${id}`; }
function validId(id){ return /^[A-Za-z0-9_-]{8,32}$/.test(String(id || '')); }

async function saveUpload(event, meta){
  if (!meta || !validId(meta.id)) throw new Error('Metadata upload tidak valid.');
  connectBlobs(event);
  await store().setJSON(key(meta.id), meta);
  return meta;
}

async function getUpload(event, id){
  if (!validId(id)) return null;
  connectBlobs(event);
  let meta = null;
  try { meta = await store().get(key(id), { type: 'json' }); } catch {}
  if (meta && meta.id === id) return meta;
  // Recovery mirror: database remains primary, GitHub metadata is only a durable recovery copy.
  try {
    const recovered = JSON.parse(await getRaw(`lianixpload/meta/${id}.json`, 7000));
    if (recovered && recovered.id === id) {
      try { await store().setJSON(key(id), recovered); } catch {}
      return recovered;
    }
  } catch {}
  return null;
}

async function deleteUpload(event, id){
  if (!validId(id)) return;
  connectBlobs(event);
  await store().delete(key(id));
}

module.exports = { STORE_NAME, validId, saveUpload, getUpload, deleteUpload };
