const {requireUser,userKey}=require('./_user-auth');
async function planKey(event,deviceId=''){try{const u=await requireUser(event);return {key:'account:'+userKey(u.uid),user:u,legacy:deviceId||null}}catch{if(deviceId)return {key:String(deviceId),user:null,legacy:null};const e=new Error('LOGIN_REQUIRED');e.statusCode=401;throw e}}
module.exports={planKey};
