// netlify/functions/winkv2.js
// Image Enhancer Ultra HD lewat wink.ai. Client kirim multipart/form-data field "image".
// Alur: get_maat_sign -> upload policy (qiniu) -> upload file -> meta_info -> calc_beans -> delivery -> poll hasil.

function json(statusCode, cors, body) {
  return { statusCode, headers: { ...cors, "Content-Type": "application/json" }, body: JSON.stringify(body) };
}

const BASE_URL = "https://wink.ai";
const STRATEGY_URL = "https://strategy.app.meitudata.com";
const CLIENT_ID = "1189857605";
const VERSION = "5.1.2";
const COUNTRY_CODE = "ID";
const CLIENT_LANGUAGE = "en_US";
const CLIENT_TIMEZONE = "Asia/Jakarta";
const TASK_TYPE = "12";
const CONTENT_TYPE = "1";
const EXT_VALUE = "2";

const UA = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36";

function randHex(n) {
  const bytes = [];
  for (let i = 0; i < n; i++) bytes.push(Math.floor(Math.random() * 256).toString(16).padStart(2, "0"));
  return bytes.join("");
}
function uuidv4() {
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, c => {
    const r = (Math.random() * 16) | 0, v = c === "x" ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

function makeTrace() { return `${randHex(16)}-${randHex(8)}-1`; }
function traceHeaders(transaction = "GET%20%2F%5Blocale%5D%2Fimage-enhancer%2Fupload") {
  const trace = makeTrace();
  return {
    "sentry-trace": trace,
    baggage: [
      "sentry-environment=release",
      "sentry-release=5.1.2%20(b60d25c477f43c6dfac4107810f26d442320f4f1)",
      "sentry-public_key=e1bf914f3448d9bc8a10c7e499d17d54",
      `sentry-trace_id=${trace.split("-")[0]}`,
      `sentry-transaction=${transaction}`,
      "sentry-sampled=true",
      "sentry-sample_rate=0.75"
    ].join(",")
  };
}

function baseParams(gnum, extra = {}) {
  return new URLSearchParams({
    client_id: CLIENT_ID, version: VERSION, country_code: COUNTRY_CODE, gnum,
    client_language: CLIENT_LANGUAGE, client_channel_id: "", client_timezone: CLIENT_TIMEZONE, ...extra
  });
}

function extToMime(filename) {
  const ext = (filename.split(".").pop() || "").toLowerCase();
  if (ext === "jpg" || ext === "jpeg") return "image/jpeg";
  if (ext === "png") return "image/png";
  if (ext === "webp") return "image/webp";
  return "application/octet-stream";
}
function fileSuffix(filename) {
  const ext = (filename.split(".").pop() || "").toLowerCase();
  return ext ? "." + (ext === "jpeg" ? "jpg" : ext) : ".jpg";
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

function parseMultipart(bodyBuffer, contentType) {
  const boundaryMatch = /boundary=(?:"([^"]+)"|([^;]+))/i.exec(contentType || "");
  const boundary = boundaryMatch ? (boundaryMatch[1] || boundaryMatch[2]) : null;
  if (!boundary) throw new Error("Boundary tidak ditemukan di Content-Type");
  const boundaryBuf = Buffer.from("--" + boundary);
  const parts = [];
  let start = bodyBuffer.indexOf(boundaryBuf);
  while (start !== -1) {
    const next = bodyBuffer.indexOf(boundaryBuf, start + boundaryBuf.length);
    if (next === -1) break;
    parts.push(bodyBuffer.slice(start + boundaryBuf.length, next));
    start = next;
  }
  for (const part of parts) {
    const headerEnd = part.indexOf("\r\n\r\n");
    if (headerEnd === -1) continue;
    const headerStr = part.slice(0, headerEnd).toString("utf-8");
    if (!/name="image"/i.test(headerStr)) continue;
    let content = part.slice(headerEnd + 4);
    if (content.slice(-2).toString() === "\r\n") content = content.slice(0, -2);
    const filenameMatch = /filename="([^"]*)"/i.exec(headerStr);
    return { filename: filenameMatch ? filenameMatch[1] : "image.jpg", buffer: content };
  }
  throw new Error('Field "image" tidak ditemukan di form-data');
}

async function getMaatSign(gnum, filename) {
  const params = baseParams(gnum, { suffix: fileSuffix(filename), type: "temp", count: "1" });
  const res = await fetch(`${BASE_URL}/api/file/get_maat_sign.json?${params}`, {
    headers: { accept: "*/*", origin: BASE_URL, referer: `${BASE_URL}/image-enhancer/upload`, "user-agent": UA, ...traceHeaders() }
  });
  const data = await res.json();
  if (!res.ok || data?.code !== 0) throw new Error(`get_maat_sign gagal: ${JSON.stringify(data)}`);
  return data.data;
}

async function getUploadPolicy(sign) {
  const params = new URLSearchParams({
    app: sign.app, count: String(sign.count), sig: sign.sig,
    sigTime: sign.sig_time, sigVersion: sign.sig_version, suffix: sign.suffix, type: sign.type
  });
  const res = await fetch(`${STRATEGY_URL}/upload/policy?${params}`, {
    headers: { accept: "*/*", origin: BASE_URL, referer: `${BASE_URL}/`, "user-agent": UA }
  });
  const data = await res.json();
  if (!res.ok || !Array.isArray(data) || !data[0]?.qiniu) throw new Error(`upload policy gagal: ${JSON.stringify(data)}`);
  return data[0].qiniu;
}

async function uploadToQiniu(policy, filename, buffer) {
  const form = new FormData();
  form.append("file", new Blob([buffer], { type: extToMime(filename) }), filename);
  form.append("token", policy.token);
  form.append("key", policy.key);
  form.append("fname", filename);
  const res = await fetch(policy.url, {
    method: "POST", body: form,
    headers: { origin: BASE_URL, referer: `${BASE_URL}/`, "user-agent": UA, accept: "*/*" }
  });
  const data = await res.json().catch(() => null);
  if (!res.ok || !data || (!data.url && !data.data)) throw new Error(`upload qiniu gagal: ${JSON.stringify(data)}`);
  return { file_key: policy.key, source_url: data.url || data.data || policy.data };
}

async function getMetaInfo(gnum, fileKey) {
  const body = baseParams(gnum, { file_key: fileKey });
  const res = await fetch(`${BASE_URL}/api/file/meta_info.json`, {
    method: "POST", body: body.toString(),
    headers: { "content-type": "application/x-www-form-urlencoded;charset=UTF-8", origin: BASE_URL, referer: `${BASE_URL}/image-enhancer/upload`, "user-agent": UA, ...traceHeaders() }
  });
  const data = await res.json();
  if (!res.ok || data?.code !== 0) throw new Error(`meta info gagal: ${JSON.stringify(data)}`);
  return data.data;
}

function typeParamsJson() {
  return JSON.stringify({ is_mirror: 0, orientation_tag: 1, j_420_trans: "1", return_ext: "2" });
}
function rightDetailJson() {
  return JSON.stringify({ source: "1", touch_type: "4", function_id: "630", material_id: "63011", url: "https://wink.ai/image-enhancer/upload" });
}

async function calcNeedBeans(gnum) {
  const itemList = JSON.stringify([{
    type: Number(TASK_TYPE), ext_value: EXT_VALUE, content_type: Number(CONTENT_TYPE),
    duration: 0, type_params: typeParamsJson(), right_detail: rightDetailJson()
  }]);
  const body = baseParams(gnum, { item_list: itemList });
  const res = await fetch(`${BASE_URL}/api/subscribe/batch_calc_need_beans.json`, {
    method: "POST", body: body.toString(),
    headers: { "content-type": "application/x-www-form-urlencoded;charset=UTF-8", origin: BASE_URL, referer: `${BASE_URL}/image-enhancer/upload`, "user-agent": UA, ...traceHeaders() }
  });
  const data = await res.json();
  if (!res.ok || data?.code !== 0) throw new Error(`calc beans gagal: ${JSON.stringify(data)}`);
  return data.data;
}

async function delivery(gnum, sourceUrl, taskName) {
  const body = baseParams(gnum, {
    type: TASK_TYPE, content_type: CONTENT_TYPE, source_url: sourceUrl,
    type_params: typeParamsJson(), right_detail: rightDetailJson(),
    ext_params: JSON.stringify({ task_name: taskName, records: TASK_TYPE }),
    with_prepare: "1"
  });
  const res = await fetch(`${BASE_URL}/api/meitu_ai/delivery.json`, {
    method: "POST", body: body.toString(),
    headers: { "content-type": "application/x-www-form-urlencoded;charset=UTF-8", origin: BASE_URL, referer: `${BASE_URL}/image-enhancer/upload`, "user-agent": UA, ...traceHeaders() }
  });
  const data = await res.json();
  if (!res.ok || data?.code !== 0) throw new Error(`delivery gagal: ${JSON.stringify(data)}`);
  const d = data.data || {};
  return { msg_id: d.msg_id || "", prepare_msg_id: d.prepare_msg_id || "" };
}

async function queryBatch(gnum, msgId) {
  const params = baseParams(gnum, { msg_ids: msgId });
  const res = await fetch(`${BASE_URL}/api/meitu_ai/query_batch.json?${params}`, {
    headers: { origin: BASE_URL, referer: `${BASE_URL}/image-enhancer/upload`, "user-agent": UA, ...traceHeaders("%2F%3Alocale%2Feditor%2Frecent-task") }
  });
  const data = await res.json();
  if (!res.ok || data?.code !== 0) throw new Error(`query batch gagal: ${JSON.stringify(data)}`);
  return data.data;
}

function extractResultUrl(data) {
  const item = data?.item_list?.[0];
  const media = item?.result?.media_info_list?.[0];
  return media?.media_data || "";
}
function extractNextMsgId(data, currentMsgId) {
  const item = data?.item_list?.[0];
  const resultValue = item?.result?.result || "";
  const realMsgId = item?.result?.msg_id || item?.msg_id || "";
  if (resultValue && resultValue !== currentMsgId && !resultValue.startsWith("http")) return resultValue;
  if (realMsgId && realMsgId !== currentMsgId && !realMsgId.startsWith("wpr_")) return realMsgId;
  return "";
}

async function waitResult(gnum, firstMsgId, maxTry = 12, delayMs = 2500) {
  let msgId = firstMsgId, last = null;
  for (let i = 1; i <= maxTry; i++) {
    const data = await queryBatch(gnum, msgId);
    last = data;
    const nextMsgId = extractNextMsgId(data, msgId);
    if (nextMsgId) { msgId = nextMsgId; await sleep(800); continue; }
    const url = extractResultUrl(data);
    const errorCode = data?.item_list?.[0]?.result?.error_code;
    const errorMsg = data?.item_list?.[0]?.result?.error_msg;
    if (url && url.startsWith("http") && errorCode === 0) return url;
    if (errorCode && errorCode !== 29901 && errorCode !== 0) throw new Error(`task gagal: ${errorCode} ${errorMsg || ""}`);
    await sleep(delayMs);
  }
  throw new Error("Waktu tunggu habis, hasil belum selesai. Coba lagi.");
}

exports.handler = async (event) => {
  const cors = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "POST,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type"
  };
  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers: cors, body: "" };
  if (event.httpMethod !== "POST") return json(405, cors, { status: false, error: "Gunakan metode POST dengan multipart/form-data field \"image\"" });

  try {
    const contentType = event.headers["content-type"] || event.headers["Content-Type"];
    const bodyBuffer = event.isBase64Encoded ? Buffer.from(event.body, "base64") : Buffer.from(event.body, "utf-8");
    const file = parseMultipart(bodyBuffer, contentType);
    const gnum = uuidv4();
    const taskName = `Enhancer-Ultra HD-${file.filename.replace(/\.[^.]+$/, "")}`;

    const sign = await getMaatSign(gnum, file.filename);
    const policy = await getUploadPolicy(sign);
    const uploaded = await uploadToQiniu(policy, file.filename, file.buffer);

    await getMetaInfo(gnum, uploaded.file_key);
    await calcNeedBeans(gnum);

    const task = await delivery(gnum, uploaded.source_url, taskName);
    const firstMsgId = task.msg_id || task.prepare_msg_id;
    if (!firstMsgId) throw new Error("delivery tidak mengembalikan msg_id");

    const resultUrl = await waitResult(gnum, firstMsgId);

    return json(200, cors, { status: true, code: 200, input: file.filename, result_url: resultUrl });
  } catch (err) {
    return json(500, cors, { status: false, code: 500, error: err.message });
  }
};


// LIANIX_USAGE_WRAPPER_V7
const { wrapHandler: __wrapLianixUsage } = require('./_usage');
exports.handler = __wrapLianixUsage(exports.handler, { apiId: 'winkv2', name: 'winkv2' });

// Lianix per-user public API key guard
const { withPublicApiKey } = require('./_user-api-key');
exports.handler = withPublicApiKey(exports.handler);
