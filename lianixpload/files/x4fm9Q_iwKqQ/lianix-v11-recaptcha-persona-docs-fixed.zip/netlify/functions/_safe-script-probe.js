const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');

function safeProbe(code,{filename='scraper.js',timeoutMs=1200}={}){
  const base={attempted:false,ok:false,stdout:'',stderr:'',mode:'isolated-help'};
  const unshare=['/usr/bin/unshare','/bin/unshare'].find(p=>{try{return fs.existsSync(p)}catch{return false}});
  if(!unshare)return{...base,reason:'OS sandbox (unshare) tidak tersedia; eksekusi kode dilewati demi keamanan.'};
  let dir='';
  try{
    dir=fs.mkdtempSync(path.join(os.tmpdir(),'lianix-probe-'));
    const safeName=path.basename(filename).replace(/[^A-Za-z0-9._-]/g,'_')||'scraper.js';
    const file=path.join(dir,safeName);fs.writeFileSync(file,String(code||''),{mode:0o400});
    // user/network namespace removes external network; Node permission mode denies child-process,
    // worker and all filesystem access except reading the submitted script itself.
    const major=Number(String(process.versions.node||'20').split('.')[0])||20;
    const permFlag=major>=22?'--permission':'--experimental-permission';
    const args=['-Urn',process.execPath,permFlag,`--allow-fs-read=${file}`,file,'--help'];
    const r=spawnSync(unshare,args,{cwd:dir,env:{PATH:process.env.PATH||'/usr/bin:/bin',NODE_NO_WARNINGS:'1',HOME:dir,TMPDIR:dir},encoding:'utf8',timeout:Math.max(300,Math.min(1800,timeoutMs)),maxBuffer:256*1024,killSignal:'SIGKILL'});
    const stderr=String(r.stderr||'').slice(0,8000),stdout=String(r.stdout||'').slice(0,16000);
    const timedOut=Boolean(r.error&&/timed out|ETIMEDOUT/i.test(r.error.message||''));
    // A CLI can deliberately exit non-zero for --help; useful stdout is still considered a successful probe.
    const useful=stdout.trim().length>0;
    return{attempted:true,ok:useful||r.status===0,stdout,stderr:[stderr,r.error?.message||''].filter(Boolean).join('\n').slice(0,8000),mode:'os-isolated-help',exitCode:r.status,timedOut};
  }catch(e){return{...base,attempted:true,error:e.message,stderr:e.message}}
  finally{if(dir){try{fs.rmSync(dir,{recursive:true,force:true})}catch{}}}
}
module.exports={safeProbe};
