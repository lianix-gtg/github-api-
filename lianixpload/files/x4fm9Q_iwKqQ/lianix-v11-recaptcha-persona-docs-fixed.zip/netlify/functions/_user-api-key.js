const crypto = require('node:crypto');

const PUBLIC_API_KEY = 'lianix';
const KEY_PREFIX = 'lianix';

function extractApiKey(event) {
  const h = event?.headers || {};
  return String(h['x-api-key'] || h['X-API-Key'] || '').trim();
}

async function verifyPublicApiKeyValue(apiKey) {
  return String(apiKey || '').trim() === PUBLIC_API_KEY
    ? { uid: 'public', apiKey: PUBLIC_API_KEY, displayName: 'Lianix Public' }
    : null;
}
async function verifyPublicApiKey(event) { return verifyPublicApiKeyValue(extractApiKey(event)); }

// Kept for backward compatibility with V7.3 callers; no storage/Firebase needed.
async function getOrCreateUserApiKey() { return { uid: 'public', apiKey: PUBLIC_API_KEY, createdAt: null, active: true }; }
async function rotateUserApiKey() { return getOrCreateUserApiKey(); }

function internalBypass(event) {
  const given = String(event?.headers?.['x-lianix-internal-token'] || event?.headers?.['X-Lianix-Internal-Token'] || '');
  const secret = String(process.env.API_INTERNAL_SECRET || process.env.GITHUB_TOKEN || process.env.ADMIN_PASSWORD || '');
  if (!given || !secret) return false;
  const expected = crypto.createHash('sha256').update('lianix-health:' + secret).digest('hex');
  if (given.length !== expected.length) return false;
  try { return crypto.timingSafeEqual(Buffer.from(given), Buffer.from(expected)); } catch { return false; }
}
function internalHealthToken() {
  const secret = String(process.env.API_INTERNAL_SECRET || process.env.GITHUB_TOKEN || process.env.ADMIN_PASSWORD || '');
  return secret ? crypto.createHash('sha256').update('lianix-health:' + secret).digest('hex') : '';
}
function corsHeaders(extra = {}) {
  return {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,PATCH,DELETE,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, X-API-Key, Authorization, X-Lianix-Health-Check, X-Lianix-Internal-Token, X-Lianix-Client, X-Lianix-User-Name',
    'Cache-Control': 'no-store',
    ...extra
  };
}
function withPublicApiKey(handler) {
  return async function protectedHandler(event, context) {
    if (event?.httpMethod === 'OPTIONS') return { statusCode: 204, headers: corsHeaders(), body: '' };
    if (!internalBypass(event)) {
      const user = await verifyPublicApiKey(event);
      if (!user) return { statusCode: 401, headers: corsHeaders(), body: JSON.stringify({ success: false, error: 'API_KEY_INVALID', message: 'X-API-Key wajib bernilai lianix.' }) };
      event.lianixApiUser = user;
    }
    const out = await handler(event, context);
    return { ...out, headers: { ...corsHeaders(), ...(out?.headers || {}) } };
  };
}
module.exports = { PUBLIC_API_KEY, KEY_PREFIX, getOrCreateUserApiKey, rotateUserApiKey, extractApiKey, verifyPublicApiKey, verifyPublicApiKeyValue, withPublicApiKey, internalHealthToken, corsHeaders };
