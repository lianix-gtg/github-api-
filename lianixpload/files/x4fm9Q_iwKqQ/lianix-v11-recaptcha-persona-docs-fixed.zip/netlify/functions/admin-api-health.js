const { verifyAdminToken } = require('./_admin-auth');
const { runHealthCheck } = require('./api-health-check');
const CORS={'Content-Type':'application/json','Access-Control-Allow-Origin':'*','Access-Control-Allow-Methods':'POST,OPTIONS','Access-Control-Allow-Headers':'Content-Type, Authorization'};
exports.handler=async(event)=>{if(event.httpMethod==='OPTIONS')return{statusCode:204,headers:CORS,body:''};if(event.httpMethod!=='POST')return{statusCode:405,headers:CORS,body:JSON.stringify({success:false,error:'Method not allowed'})};if(!await verifyAdminToken(event))return{statusCode:401,headers:CORS,body:JSON.stringify({success:false,error:'Tidak terautentikasi.'})};const r=await runHealthCheck();return{...r,headers:{...CORS,...(r.headers||{})}}};
