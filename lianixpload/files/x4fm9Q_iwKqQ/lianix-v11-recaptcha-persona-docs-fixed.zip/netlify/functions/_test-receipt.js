const crypto = require('crypto');

function canonicalMeta(meta = {}) {
  return {
    id: String(meta.id || ''),
    name: String(meta.name || ''),
    description: String(meta.description || ''),
    method: String(meta.method || 'GET').toUpperCase(),
    endpoint: String(meta.endpoint || ''),
    category: String(meta.category || ''),
    inputs: Array.isArray(meta.inputs) ? meta.inputs.map(p => ({
      name: String(p.name || p.key || ''),
      type: String(p.type || 'text'),
      required: p.required === true,
      placeholder: String(p.placeholder || ''),
      choices: Array.isArray(p.choices || p.options) ? (p.choices || p.options) : undefined,
      accept: p.accept || undefined,
      default: p.default !== undefined ? p.default : undefined,
      conditionalRequired: p.conditionalRequired === true || undefined,
      requiredWhen: p.requiredWhen && typeof p.requiredWhen === 'object' ? p.requiredWhen : undefined,
      description: p.description ? String(p.description) : undefined
    })) : [],
    outputs: Array.isArray(meta.outputs) ? meta.outputs.map(o => ({
      type: String(o.type || 'json'),
      label: String(o.label || 'Result')
    })) : [{ type: 'json', label: 'Result' }],
    dependencies: Array.isArray(meta.dependencies) ? [...new Set(meta.dependencies.map(String).filter(Boolean))].sort() : []
  };
}
function stable(v) {
  if (Array.isArray(v)) return '[' + v.map(stable).join(',') + ']';
  if (v && typeof v === 'object') return '{' + Object.keys(v).filter(k => v[k] !== undefined).sort().map(k => JSON.stringify(k)+':'+stable(v[k])).join(',') + '}';
  return JSON.stringify(v);
}
function digest(code, meta) {
  return crypto.createHash('sha256').update(String(code || '') + '\n' + stable(canonicalMeta(meta))).digest('hex');
}
function secret() {
  const s = process.env.ADMIN_PASSWORD;
  if (!s) throw new Error('ADMIN_PASSWORD belum dikonfigurasi.');
  return s;
}
function signTest(code, meta, ttlMs = 10 * 60 * 1000) {
  const payload = { h: digest(code, meta), exp: Date.now() + ttlMs };
  const encoded = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const sig = crypto.createHmac('sha256', secret()).update(encoded).digest('base64url');
  return `${encoded}.${sig}`;
}
function verifyTest(receipt, code, meta) {
  if (!receipt || typeof receipt !== 'string' || !receipt.includes('.')) return false;
  const [encoded, sig] = receipt.split('.', 2);
  const expected = crypto.createHmac('sha256', secret()).update(encoded).digest('base64url');
  if (sig.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return false;
  let payload;
  try { payload = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf8')); } catch { return false; }
  if (!payload || Number(payload.exp) < Date.now()) return false;
  return payload.h === digest(code, meta);
}
module.exports = { canonicalMeta, signTest, verifyTest };
