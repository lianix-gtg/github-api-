const C={
  'content-type':'application/json; charset=utf-8',
  'cache-control':'no-store, no-cache, must-revalidate',
  'access-control-allow-origin':'*',
  'access-control-allow-headers':'Content-Type',
  'access-control-allow-methods':'GET,POST,OPTIONS'
};
function out(statusCode,body){return{statusCode,headers:C,body:JSON.stringify(body)}}
function clean(v){
  let s=String(v??'').trim();
  // Netlify users sometimes paste env values with surrounding quotes.
  if((s.startsWith('"')&&s.endsWith('"'))||(s.startsWith("'")&&s.endsWith("'")))s=s.slice(1,-1).trim();
  return s.replace(/\\r?\\n/g,'').trim();
}
function ip(event){
  const h=event.headers||{};
  return String(h['x-nf-client-connection-ip']||h['x-forwarded-for']||h['client-ip']||'').split(',')[0].trim();
}
function getConfig(){
  const siteKey=clean(process.env.RECAPTCHA_SITE_KEY||'');
  const secret=clean(process.env.RECAPTCHA_SECRET_KEY||'');
  return {siteKey,secret};
}
exports.handler=async event=>{
  if(event.httpMethod==='OPTIONS')return{statusCode:204,headers:C,body:''};
  const {siteKey,secret}=getConfig();
  if(event.httpMethod==='GET'){
    if(!siteKey)return out(503,{ok:false,error:'RECAPTCHA_SITE_KEY_MISSING',message:'Site Key reCAPTCHA belum tersedia pada Functions/Runtime.'});
    return out(200,{ok:true,siteKey,type:'checkbox',secretConfigured:!!secret,source:'netlify'});
  }
  if(event.httpMethod!=='POST')return out(405,{ok:false,error:'METHOD_NOT_ALLOWED'});
  if(!siteKey)return out(503,{ok:false,error:'RECAPTCHA_SITE_KEY_MISSING',message:'Site Key reCAPTCHA belum tersedia di Netlify.'});
  if(!secret)return out(503,{ok:false,error:'RECAPTCHA_SECRET_KEY_MISSING',message:'Secret Key reCAPTCHA belum tersedia di Netlify Environment Variables.'});
  try{
    let body={};
    try{body=JSON.parse(event.body||'{}')}catch{return out(400,{ok:false,error:'BAD_JSON'})}
    const token=clean(body.token);
    if(!token)return out(400,{ok:false,error:'RECAPTCHA_REQUIRED',message:'Token reCAPTCHA kosong. Centang ulang.'});

    const form=new URLSearchParams();
    form.set('secret',secret);
    form.set('response',token);
    const remote=ip(event);if(remote)form.set('remoteip',remote);

    const r=await fetch('https://www.google.com/recaptcha/api/siteverify',{
      method:'POST',
      headers:{'content-type':'application/x-www-form-urlencoded;charset=UTF-8','accept':'application/json'},
      body:form.toString()
    });
    const d=await r.json().catch(()=>({}));
    const codes=Array.isArray(d['error-codes'])?d['error-codes']:[];
    if(!r.ok || d.success!==true){
      let message='Verifikasi reCAPTCHA gagal.';
      if(codes.includes('invalid-input-secret')) message='Secret Key reCAPTCHA tidak valid atau bukan pasangan Site Key ini.';
      else if(codes.includes('missing-input-secret')) message='Secret Key reCAPTCHA tidak terbaca di Netlify.';
      else if(codes.includes('invalid-input-response')) message='Token reCAPTCHA tidak valid. Centang ulang lalu coba lagi.';
      else if(codes.includes('timeout-or-duplicate')) message='Token reCAPTCHA sudah kedaluwarsa/terpakai. Centang ulang lalu coba lagi.';
      else if(codes.includes('bad-request')) message='Permintaan verifikasi reCAPTCHA tidak valid.';
      return out(403,{ok:false,error:'RECAPTCHA_FAILED',message,codes,hostname:d.hostname||null,challengeTs:d.challenge_ts||null});
    }
    return out(200,{ok:true,verified:true,hostname:d.hostname||null,challengeTs:d.challenge_ts||null});
  }catch(e){
    console.error('[recaptcha]',e);
    return out(502,{ok:false,error:'RECAPTCHA_VERIFY_ERROR',message:'Server gagal menghubungi Google reCAPTCHA. Coba lagi.'});
  }
};
