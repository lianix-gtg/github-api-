const { PUBLIC_API_KEY, corsHeaders } = require('./_user-api-key');
exports.handler = async (event) => {
  const headers = corsHeaders();
  if (event.httpMethod === 'OPTIONS') return { statusCode: 204, headers, body: '' };
  if (!['GET','POST'].includes(event.httpMethod)) return { statusCode: 405, headers, body: JSON.stringify({success:false,error:'Method not allowed'}) };
  return { statusCode: 200, headers, body: JSON.stringify({ success:true, data:{ apiKey:PUBLIC_API_KEY, shared:true } }) };
};
