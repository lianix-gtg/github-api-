// netlify/functions/_telegram.js
// Helper kirim notifikasi ke Telegram (bot -> chat/channel admin).
// Env var yang dipakai:
//   TELEGRAM_BOT_TOKEN  -> token bot dari @BotFather
//   TELEGRAM_CHAT_ID    -> id chat/channel tujuan notifikasi (mis. channel @aboutyoen atau chat id numerik pemilik @yoen0724)

async function sendTelegramNotify(text) {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;

  if (!token || !chatId) {
    console.warn("[telegram] TELEGRAM_BOT_TOKEN atau TELEGRAM_CHAT_ID belum diset di environment variable. Notifikasi dilewati.");
    return { skipped: true, reason: "missing_config" };
  }

  try {
    const res = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: chatId,
        text,
        parse_mode: "HTML",
        disable_web_page_preview: true
      }),
      signal: AbortSignal.timeout(10000)
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || data.ok === false) {
      console.warn("[telegram] Gagal mengirim notifikasi:", data.description || res.status);
      return { skipped: false, ok: false, error: data.description || `HTTP ${res.status}` };
    }
    return { skipped: false, ok: true };
  } catch (err) {
    console.warn("[telegram] Error mengirim notifikasi:", err.message);
    return { skipped: false, ok: false, error: err.message };
  }
}

module.exports = { sendTelegramNotify };
