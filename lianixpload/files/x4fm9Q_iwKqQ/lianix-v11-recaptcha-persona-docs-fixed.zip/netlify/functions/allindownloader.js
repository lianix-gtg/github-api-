// netlify/functions/allindownloader.js
// Download video dari berbagai platform (TikTok, IG, YT, dll) via allinonedownloader.com
// Client kirim: GET /api/allindownloader?url=<VIDEO_URL>

const https = require('https');
const http = require('http');
const crypto = require('crypto');
const { URLSearchParams } = require('url');

const CONFIG = {
    baseUrl: 'https://allinonedownloader.com',
    solverApi: 'https://api.ikyyxd.my.id/bypass/turnstile-cf-min',
    userAgent: 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36'
};

const AES_IV_HEX = 'afc4e290725a3bf0ac4d3ff826c43c10';

function cors() {
    return {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET,OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type'
    };
}
function json(code, body) {
    return { statusCode: code, headers: { ...cors(), 'Content-Type': 'application/json' }, body: JSON.stringify(body) };
}

// AES-CBC encrypt using Node crypto (no external dep)
function encryptUrl(url, tokenHex) {
    const key = Buffer.from(tokenHex, 'hex');
    const iv = Buffer.from(AES_IV_HEX, 'hex');
    // Zero-pad url to multiple of 16
    const data = Buffer.from(url, 'utf8');
    const padLen = 16 - (data.length % 16);
    const padded = Buffer.concat([data, Buffer.alloc(padLen === 16 ? 0 : padLen)]);
    const cipher = crypto.createCipheriv('aes-128-cbc', key, iv);
    cipher.setAutoPadding(false);
    return Buffer.concat([cipher.update(padded), cipher.final()]).toString('base64');
}

function httpGet(url, headers = {}) {
    return new Promise((resolve, reject) => {
        const lib = url.startsWith('https') ? https : http;
        const req = lib.get(url, { headers }, res => {
            const chunks = [];
            const setCookies = res.headers['set-cookie'] || [];
            res.on('data', c => chunks.push(c));
            res.on('end', () => resolve({ body: Buffer.concat(chunks).toString(), headers: res.headers, setCookies }));
        });
        req.on('error', reject);
        req.setTimeout(30000, () => { req.destroy(); reject(new Error('Timeout')); });
    });
}

function httpPost(url, formBody, headers = {}) {
    return new Promise((resolve, reject) => {
        const u = new URL(url);
        const opts = {
            hostname: u.hostname, path: u.pathname + u.search,
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'Content-Length': Buffer.byteLength(formBody), ...headers }
        };
        const lib = u.protocol === 'https:' ? https : http;
        const req = lib.request(opts, res => {
            const chunks = [];
            res.on('data', c => chunks.push(c));
            res.on('end', () => resolve({ body: Buffer.concat(chunks).toString(), headers: res.headers }));
        });
        req.on('error', reject);
        req.setTimeout(40000, () => { req.destroy(); reject(new Error('Timeout')); });
        req.write(formBody);
        req.end();
    });
}

exports.handler = async (event) => {
    if (event.httpMethod === 'OPTIONS') return { statusCode: 204, headers: cors(), body: '' };
    if (event.httpMethod !== 'GET') return json(405, { status: false, error: 'Method not allowed' });

    const qs = event.queryStringParameters || {};
    const targetUrl = qs.url;
    if (!targetUrl) return json(400, { status: false, error: "Parameter 'url' wajib diisi" });

    try {
        // 1. Get turnstile bypass token
        const solverRes = await httpGet(`${CONFIG.solverApi}?url=${encodeURIComponent(CONFIG.baseUrl + '/in/')}&sitekey=0x4AAAAAACm5JpnQ9wkl8EIR`);
        let solverData;
        try { solverData = JSON.parse(solverRes.body); } catch { return json(502, { status: false, error: 'Solver response invalid' }); }
        if (!solverData?.status || !solverData?.result?.token) return json(502, { status: false, error: 'Solver gagal mendapatkan token' });
        const ttoken = solverData.result.token;

        // 2. Load page, grab scc + token
        const pageHeaders = { 'User-Agent': CONFIG.userAgent, 'Accept': 'text/html', 'Referer': CONFIG.baseUrl };
        const pageRes = await httpGet(`${CONFIG.baseUrl}/in/`, pageHeaders);

        const sccMatch = pageRes.body.match(/id=["']scc["'][^>]*value=["']([^"']+)["']/i);
        if (!sccMatch) return json(502, { status: false, error: 'Endpoint dinamis (#scc) tidak ditemukan' });
        const endpointPath = sccMatch[1];

        const tokenMatch = pageRes.body.match(/id=["']token["'][^>]*value=["']([^"']+)["']/i);
        if (!tokenMatch) return json(502, { status: false, error: '#token tidak ditemukan di halaman' });
        const pageToken = tokenMatch[1];

        // 3. Encrypt URL
        const urlHash = encryptUrl(targetUrl, pageToken);

        // 4. Post to endpoint
        const cookieStr = pageRes.setCookies.map(c => c.split(';')[0]).join('; ');
        const form = new URLSearchParams({ url: targetUrl, token: pageToken, urlhash: urlHash, ttoken }).toString();
        const postHeaders = {
            'User-Agent': CONFIG.userAgent, 'Origin': CONFIG.baseUrl,
            'Referer': `${CONFIG.baseUrl}/in/`,
            'X-Requested-With': 'XMLHttpRequest',
            'Cookie': cookieStr
        };
        const postRes = await httpPost(`${CONFIG.baseUrl}${endpointPath}`, form, postHeaders);

        let result;
        try { result = JSON.parse(postRes.body); } catch { result = { raw: postRes.body }; }

        return json(200, { status: true, result });
    } catch (err) {
        return json(502, { status: false, error: err.message });
    }
};


// LIANIX_USAGE_WRAPPER_V7
const { wrapHandler: __wrapLianixUsage } = require('./_usage');
exports.handler = __wrapLianixUsage(exports.handler, { apiId: 'allindownloader', name: 'allindownloader' });

// Lianix per-user public API key guard
const { withPublicApiKey } = require('./_user-api-key');
exports.handler = withPublicApiKey(exports.handler);
