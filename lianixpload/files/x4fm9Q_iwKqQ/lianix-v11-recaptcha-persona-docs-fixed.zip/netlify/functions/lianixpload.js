// LianixPload — persistent GitHub-backed file uploader.
// POST multipart/form-data field "file". Any MIME type is accepted.
// Files are stored under lianixpload/files/ and metadata under lianixpload/meta/.

const { persistUpload, safeFilename } = require('./_pload-save');

const MAX_BYTES = 3 * 1024 * 1024; // keep safely below Netlify's synchronous payload ceiling
const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST,OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, X-API-Key',
  'Cache-Control': 'no-store',
  'Content-Type': 'application/json; charset=utf-8'
};
const json = (statusCode, body) => ({ statusCode, headers: CORS, body: JSON.stringify(body) });

function parseMultipart(bodyBuffer, contentType) {
  const m = /boundary=(?:"([^"]+)"|([^;]+))/i.exec(contentType || '');
  const boundary = m && (m[1] || m[2]);
  if (!boundary) throw Object.assign(new Error('Content-Type multipart/form-data tidak valid.'), { statusCode: 400 });
  const marker = Buffer.from(`--${boundary}`);
  let cursor = bodyBuffer.indexOf(marker);
  while (cursor !== -1) {
    const next = bodyBuffer.indexOf(marker, cursor + marker.length);
    if (next === -1) break;
    const part = bodyBuffer.subarray(cursor + marker.length, next);
    const headerEnd = part.indexOf('\r\n\r\n');
    if (headerEnd !== -1) {
      const headers = part.subarray(0, headerEnd).toString('utf8');
      if (/name="file"/i.test(headers)) {
        let content = part.subarray(headerEnd + 4);
        if (content.length >= 2 && content.subarray(content.length - 2).toString() === '\r\n') content = content.subarray(0, content.length - 2);
        const fm = /filename="([^"]*)"/i.exec(headers);
        const tm = /Content-Type:\s*([^\r\n]+)/i.exec(headers);
        return {
          filename: safeFilename(fm?.[1] || 'file'),
          contentType: String(tm?.[1] || 'application/octet-stream').trim().slice(0, 160),
          buffer: Buffer.from(content)
        };
      }
    }
    cursor = next;
  }
  throw Object.assign(new Error('Field multipart "file" tidak ditemukan.'), { statusCode: 400 });
}
async function handler(event) {
  if (event.httpMethod === 'OPTIONS') return { statusCode: 204, headers: CORS, body: '' };
  if (event.httpMethod !== 'POST') return json(405, { success: false, error: 'Gunakan POST multipart/form-data dengan field file.' });
  try {
    const contentType = event.headers?.['content-type'] || event.headers?.['Content-Type'] || '';
    if (!/^multipart\/form-data/i.test(contentType)) return json(415, { success: false, error: 'Content-Type wajib multipart/form-data.' });
    const raw = event.isBase64Encoded ? Buffer.from(event.body || '', 'base64') : Buffer.from(event.body || '', 'latin1');
    if (raw.length > MAX_BYTES + 512 * 1024) return json(413, { success: false, error: 'Payload terlalu besar. Maksimum file LianixPload 3 MB.' });
    const file = parseMultipart(raw, contentType);
    if (!file.buffer.length) return json(400, { success: false, error: 'File kosong tidak dapat diupload.' });
    if (file.buffer.length > MAX_BYTES) return json(413, { success: false, error: 'File terlalu besar. Maksimum 3 MB per file.' });

    const saved = await persistUpload(event, { filename: file.filename, mime: file.contentType, buffer: file.buffer });
    return json(201, saved);
  } catch (error) {
    console.error('[lianixpload]', error);
    const status = error.statusCode || (error.status === 401 || error.status === 403 ? 502 : 500);
    return json(status, { success: false, error: error.message || 'Upload gagal.' });
  }
}

exports.handler = handler;
const { wrapHandler } = require('./_usage');
exports.handler = wrapHandler(exports.handler, { apiId: 'lianixpload', name: 'LianixPload' });
const { withPublicApiKey } = require('./_user-api-key');
exports.handler = withPublicApiKey(exports.handler);
