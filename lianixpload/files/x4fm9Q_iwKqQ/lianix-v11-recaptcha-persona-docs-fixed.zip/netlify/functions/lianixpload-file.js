// Public download route for LianixPload: /f/:id
// Keeps the short Lianix URL and serves bytes from GitHub using server-side credentials.
const { OWNER, REPO, BRANCH, request } = require('./_github');
const { getUpload } = require('./_pload-db');

const BASE_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'X-Content-Type-Options': 'nosniff'
};
function text(statusCode, message) {
  return { statusCode, headers: { ...BASE_HEADERS, 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' }, body: message };
}
function safeDisposition(name, inline = false) {
  const fallback = String(name || 'file').replace(/[^\x20-\x7E]|["\\\r\n]/g, '_');
  return `${inline ? 'inline' : 'attachment'}; filename="${fallback}"; filename*=UTF-8''${encodeURIComponent(String(name || 'file'))}`;
}
function deliveryType(mime = '') {
  const m = String(mime).toLowerCase().split(';')[0].trim();
  const safeInline = /^(image\/(?:png|jpeg|gif|webp|avif)|audio\/|video\/|application\/pdf$)/.test(m);
  const active = /^(text\/html|image\/svg\+xml|application\/(?:javascript|x-javascript|xml|xhtml\+xml))$/.test(m);
  return { mime: active ? 'application/octet-stream' : (m || 'application/octet-stream'), inline: safeInline && !active };
}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function human(n){n=Number(n)||0;if(n<1024)return n+' B';if(n<1048576)return(n/1024).toFixed(1)+' KB';return(n/1048576).toFixed(2)+' MB'}
function previewPage(meta,id){const ext=(String(meta.filename||'').split('.').pop()||'FILE').toUpperCase();const isZip=/\.(zip|rar|7z|tar|gz|tgz)$/i.test(meta.filename||'');const label=isZip?`Download ${ext}`:'Download File';return `<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(meta.filename)} — LianixPload</title><style>*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;background:#fffdf3;color:#111;font-family:Inter,system-ui,sans-serif;padding:20px}.c{width:min(620px,100%);border:3px solid #000;border-radius:24px;background:#fff;box-shadow:9px 9px 0 #000;padding:28px}.ico{width:86px;height:86px;border:3px solid #000;border-radius:22px;background:#86E7A3;display:grid;place-items:center;font-size:34px;box-shadow:5px 5px 0 #000}.tag{display:inline-block;margin-top:22px;border:2px solid #000;border-radius:999px;padding:6px 10px;font:800 10px ui-monospace,monospace;background:#FFD93D}.name{font-size:clamp(26px,6vw,46px);font-weight:950;line-height:1.02;margin:12px 0;word-break:break-word}.meta{color:#666;font-weight:700}.btn{display:block;margin-top:24px;text-align:center;border:3px solid #000;border-radius:14px;background:#111;color:#fff;padding:15px;text-decoration:none;font-weight:950;box-shadow:5px 5px 0 #86E7A3}.small{margin-top:16px;font:700 11px ui-monospace,monospace;color:#777}</style></head><body><main class="c"><div class="ico">${isZip?'🗜️':'📦'}</div><div class="tag">LIANIXPLOAD • ${esc(ext)}</div><div class="name">${esc(meta.filename)}</div><div class="meta">${human(meta.size)} • ${esc(meta.mime||'application/octet-stream')}</div><a class="btn" href="/f/${encodeURIComponent(id)}/download">${esc(label)}</a><div class="small">File tidak didownload otomatis. Tekan tombol di atas saat siap.</div></main></body></html>`}
exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return { statusCode: 204, headers: { ...BASE_HEADERS, 'Access-Control-Allow-Methods': 'GET,HEAD,OPTIONS' }, body: '' };
  if (!['GET','HEAD'].includes(event.httpMethod)) return text(405, 'Method not allowed');
  try {
    const rawSplat=event.pathParameters?.splat||String(event.path||'').split('/f/')[1]||'';const parts=String(rawSplat).split('/').filter(Boolean);const id=parts[0]||'';const forceDownload=parts[1]==='download';
    if (!/^[A-Za-z0-9_-]{8,32}$/.test(id)) return text(404, 'File tidak ditemukan.');
    const meta = await getUpload(event, id); if (!meta) return text(404, 'File tidak ditemukan.'); if (!meta?.path || !meta?.filename) return text(500, 'Metadata file rusak.');
    const delivery=deliveryType(meta.mime||'');
    if(!forceDownload&&!delivery.inline){const html=previewPage(meta,id);return{statusCode:200,headers:{...BASE_HEADERS,'Content-Type':'text/html; charset=utf-8','Content-Security-Policy':"default-src 'none'; style-src 'unsafe-inline'; base-uri 'none'; form-action 'none'",'Cache-Control':'public,max-age=60'},body:html}}
    const rawUrl = `https://api.github.com/repos/${encodeURIComponent(OWNER)}/${encodeURIComponent(REPO)}/contents/${String(meta.path).split('/').map(encodeURIComponent).join('/')}?ref=${encodeURIComponent(BRANCH)}`;
    const res = await request(rawUrl, { headers: { Accept: 'application/vnd.github.raw+json' } }, 15000); if (!res.ok) return text(res.status === 404 ? 404 : 502, res.status === 404 ? 'File tidak ditemukan.' : `Storage error ${res.status}`);
    const headers = {...BASE_HEADERS,'Content-Type':delivery.mime,'Content-Disposition':safeDisposition(meta.filename,forceDownload?false:delivery.inline),'Content-Security-Policy':"default-src 'none'; sandbox",'Cache-Control':'public, max-age=31536000, immutable','ETag':meta.sha?`"${meta.sha}"`:undefined};for(const k of Object.keys(headers))if(headers[k]==null)delete headers[k];
    if(event.httpMethod==='HEAD')return{statusCode:200,headers:{...headers,'Content-Length':String(meta.size||0)},body:''};const buf=Buffer.from(await res.arrayBuffer());return{statusCode:200,headers:{...headers,'Content-Length':String(buf.length)},isBase64Encoded:true,body:buf.toString('base64')};
  } catch (error) { console.error('[lianixpload-file]', error); return text(502, 'File sementara tidak dapat diambil.'); }
};
