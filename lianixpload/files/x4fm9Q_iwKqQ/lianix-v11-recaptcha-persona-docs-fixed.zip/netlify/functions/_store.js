const { getStore, connectLambda } = require('@netlify/blobs');

// Resilient Netlify Blobs wrapper.
// On a normal Netlify Functions deploy, Blobs receives its site/token context automatically.
// On misconfigured/manual environments we fail over to an in-memory store instead of turning
// unrelated endpoints into HTTP 500 responses. The fallback is intentionally non-persistent.
const ROOT = globalThis.__LIANIX_MEMORY_STORES || (globalThis.__LIANIX_MEMORY_STORES = new Map());
const WARNED = globalThis.__LIANIX_BLOBS_WARNED || (globalThis.__LIANIX_BLOBS_WARNED = new Set());

function memoryNamespace(name) {
  if (!ROOT.has(name)) ROOT.set(name, new Map());
  return ROOT.get(name);
}
function memoryStore(name) {
  const map = memoryNamespace(name);
  return {
    async set(key, value) { map.set(String(key), String(value)); },
    async setJSON(key, value) { map.set(String(key), JSON.parse(JSON.stringify(value))); },
    async get(key, opts = {}) {
      if (!map.has(String(key))) return null;
      const value = map.get(String(key));
      if (opts.type === 'json') {
        if (typeof value === 'string') { try { return JSON.parse(value); } catch { return null; } }
        return JSON.parse(JSON.stringify(value));
      }
      return typeof value === 'string' ? value : JSON.stringify(value);
    },
    async delete(key) { map.delete(String(key)); },
    async list(opts = {}) {
      const prefix = String(opts.prefix || '');
      return { blobs: [...map.keys()].filter(k => k.startsWith(prefix)).map(key => ({ key })) };
    }
  };
}
function isConfigError(err) {
  const m = String(err?.message || err || '').toLowerCase();
  return m.includes('environment has not been configured') ||
    (m.includes('siteid') && m.includes('token')) || m.includes('netlify blobs');
}
function connectBlobs(event) {
  try { if (event && typeof connectLambda === 'function') connectLambda(event); }
  catch (err) { console.warn('[blobs] connectLambda skipped:', err.message); }
}
function makeStore(name) {
  const fallback = memoryStore(name);
  let real = null;
  try {
    const siteID = process.env.NETLIFY_BLOBS_SITE_ID || process.env.SITE_ID || '';
    const token = process.env.NETLIFY_BLOBS_TOKEN || process.env.NETLIFY_AUTH_TOKEN || '';
    // Environment/context mode must use the string form. Object form means manual/API access
    // and therefore requires both siteID + token.
    real = (siteID && token) ? getStore({ name, siteID, token }) : getStore(name);
  } catch (err) {
    if (!WARNED.has(name)) {
      WARNED.add(name);
      console.warn(`[blobs:${name}] persistent store unavailable; using non-persistent fallback: ${err.message}`);
    }
    return fallback;
  }
  const resilient = {};
  for (const method of ['set','setJSON','get','delete','list']) {
    resilient[method] = async (...args) => {
      try { return await real[method](...args); }
      catch (err) {
        if (!isConfigError(err)) throw err;
        if (!WARNED.has(name)) {
          WARNED.add(name);
          console.warn(`[blobs:${name}] runtime context missing; using non-persistent fallback.`);
        }
        return fallback[method](...args);
      }
    };
  }
  return resilient;
}
function txStore(){ return makeStore('f24nt-transactions'); }
function planStore(){ return makeStore('f24nt-user-plans'); }
async function saveTransaction(orderId,data){ await txStore().setJSON(orderId,data); }
async function getTransaction(orderId){ return await txStore().get(orderId,{type:'json'}); }
async function deleteTransaction(orderId){ await txStore().delete(orderId); }
async function setUserPlan(deviceId,planData){ await planStore().setJSON(deviceId,planData); }
async function getUserPlan(deviceId){ return await planStore().get(deviceId,{type:'json'}); }
module.exports={saveTransaction,getTransaction,deleteTransaction,setUserPlan,getUserPlan,makeStore,connectBlobs};
