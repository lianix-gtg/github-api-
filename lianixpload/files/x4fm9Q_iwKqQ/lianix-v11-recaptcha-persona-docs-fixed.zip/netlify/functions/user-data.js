const crypto=require('node:crypto');
const {makeStore,connectBlobs}=require('./_store');
const {requireUser,userKey}=require('./_user-auth');
const {getRaw,putFile}=require('./_github');
const STORE='lianix-user-data-v1';
const C={'Content-Type':'application/json','Cache-Control':'no-store','Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type, Authorization, X-Lianix-Email-Session','Access-Control-Allow-Methods':'GET,PUT,POST,PATCH,OPTIONS'};
const out=(s,b)=>({statusCode:s,headers:C,body:JSON.stringify(b)});
function secret(){return String(process.env.USER_DATA_MASTER_KEY||process.env.SNIPPET_MASTER_KEY||process.env.ADMIN_PASSWORD||'')}
function enc(obj){const key=crypto.createHash('sha256').update(secret()).digest(),iv=crypto.randomBytes(12),c=crypto.createCipheriv('aes-256-gcm',key,iv);const pt=Buffer.from(JSON.stringify(obj));const ct=Buffer.concat([c.update(pt),c.final()]);return {v:1,alg:'aes-256-gcm',iv:iv.toString('base64'),tag:c.getAuthTag().toString('base64'),data:ct.toString('base64')}}
function dec(x){const key=crypto.createHash('sha256').update(secret()).digest(),iv=Buffer.from(x.iv,'base64'),d=crypto.createDecipheriv('aes-256-gcm',key,iv);d.setAuthTag(Buffer.from(x.tag,'base64'));return JSON.parse(Buffer.concat([d.update(Buffer.from(x.data,'base64')),d.final()]).toString())}
function cleanState(s){
  const x=s&&typeof s==='object'?s:{};
  const text=JSON.stringify(x); if(Buffer.byteLength(text)>4.5*1024*1024) throw Object.assign(new Error('USER_DATA_TOO_LARGE'),{statusCode:413});
  return x;
}
async function ghRead(k){try{return dec(JSON.parse(await getRaw(`user-data/${k}.json`)))}catch(e){return null}}
async function ghWrite(k,data){if(!secret())return;await putFile(`user-data/${k}.json`,JSON.stringify(enc(data),null,2)+'\n',`user-data: backup ${k.slice(0,10)}`)}
exports.handler=async event=>{if(event.httpMethod==='OPTIONS')return{statusCode:204,headers:C,body:''};try{connectBlobs(event);const user=await requireUser(event),k=userKey(user.uid),st=makeStore(STORE),key=`u/${k}`;
 if(event.httpMethod==='GET'){
   let rec=await st.get(key,{type:'json'}).catch(()=>null);let recovered=false;
   if(!rec){rec=await ghRead(k);if(rec){recovered=true;await st.setJSON(key,rec).catch(()=>{})}}
   return out(200,{ok:true,user:{uid:user.uid,email:user.email||null,displayName:user.displayName||null,providerId:user.providerId||null},state:rec?.state||{},updatedAt:rec?.updatedAt||null,recovered});
 }
 if(event.httpMethod==='PUT'||event.httpMethod==='POST'||event.httpMethod==='PATCH'){
   const b=JSON.parse(event.body||'{}'),old=await st.get(key,{type:'json'}).catch(()=>null),base=old?.state||{},state=cleanState(event.httpMethod==='PATCH'?{...base,...(b.patch||{})}:b.state),now=new Date().toISOString(),rec={version:1,uidHash:k,state,updatedAt:now,lastBackupAt:old?.lastBackupAt||null};
   await st.setJSON(key,rec);
   const due=b.forceBackup||!rec.lastBackupAt||(Date.now()-Date.parse(rec.lastBackupAt)>10*60*1000);
   if(due){try{await ghWrite(k,rec);rec.lastBackupAt=now;await st.setJSON(key,rec)}catch(e){console.warn('[user-data] github backup:',e.message)}}
   return out(200,{ok:true,updatedAt:now,backedUp:!!due});
 }
 return out(405,{ok:false,error:'Method not allowed'});
 }catch(e){return out(e.statusCode||500,{ok:false,error:e.message})}};
