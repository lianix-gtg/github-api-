const { loadModels } = require('./_models');
exports.handler=async()=>{try{const models=(await loadModels()).filter(x=>x.enabled!==false);return{statusCode:200,headers:{'Content-Type':'application/json','Cache-Control':'no-store'},body:JSON.stringify({ok:true,models})}}catch(e){return{statusCode:500,headers:{'Content-Type':'application/json'},body:JSON.stringify({ok:false,error:e.message})}}};
