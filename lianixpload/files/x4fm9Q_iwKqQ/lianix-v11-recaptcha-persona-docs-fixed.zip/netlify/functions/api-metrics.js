const { connectBlobs } = require('./_store');
const { recordUsage, apiIdFromName } = require('./_usage');
const CORS={'Content-Type':'application/json','Access-Control-Allow-Origin':'*','Access-Control-Allow-Methods':'POST,OPTIONS','Access-Control-Allow-Headers':'Content-Type'};
const out=(statusCode,body)=>({statusCode,headers:CORS,body:JSON.stringify(body)});
function clean(s,n=120){return String(s||'').replace(/[^a-zA-Z0-9_./: -]/g,'').slice(0,n)}
exports.handler=async(event)=>{
  connectBlobs(event);
  if(event.httpMethod==='OPTIONS')return{statusCode:204,headers:CORS,body:''};
  if(event.httpMethod!=='POST')return out(405,{success:false});
  try{
    const p=JSON.parse(event.body||'{}');
    const id=apiIdFromName(clean(p.apiId||p.name||p.path||'unknown',80).replace(/[/: ]+/g,'-'));
    await recordUsage({apiId:id,name:clean(p.name,100),path:clean(p.path,160),ok:p.ok===true,status:Number(p.status)||0,latency:Number(p.latency)||0,userUid:(event?.headers?.['x-lianix-client']||event?.headers?.['X-Lianix-Client']||event?.lianixApiUser?.uid||null)});
    return out(200,{success:true});
  }catch(e){return out(200,{success:false});}
};

// Lianix per-user public API key guard
const { withPublicApiKey } = require('./_user-api-key');
exports.handler = withPublicApiKey(exports.handler);
