// netlify/functions/ai-proxy.js
// Proxy aman: menyembunyikan base URL API asli dari client.
// Client cukup panggil: /api/ai/<endpoint>?text=...  (lihat _redirects)

const CMNTY_BASE = "https://api.cmnty.biz.id";
const IKYYXD_BASE = "https://api.ikyyxd.my.id/ai";
const FAA_BASE = "https://api-faa.my.id/faa";
const REWIND_BASE = "https://api.rewind.ai/v1/chat/completions";

// Model yang tersedia lewat Rewind AI (lihat REWIND_MODEL_MAP di bawah untuk pemetaan endpoint -> model id)

// CMNTY multi-key rotation. Semua key dibaca dari environment variable Netlify
// (Site settings -> Environment variables), TIDAK PERNAH dikirim ke client.
// Isi CMNTY_API_KEY, CMNTY_API_KEY_2 ... CMNTY_API_KEY_10 di dashboard Netlify.
// Sistem otomatis pindah ke key berikutnya kalau key aktif kena limit/error.
const CMNTY_API_KEYS = Array.from({ length: 10 }, (_, i) => {
  const name = i === 0 ? "CMNTY_API_KEY" : `CMNTY_API_KEY_${i + 1}`;
  return process.env[name] || "";
}).filter(Boolean);

let _cmntyKeyIdx = 0;
const _cmntyKeyDisabledUntil = new Map(); // idx -> timestamp ms

function looksLikeLimitError(status, text) {
  if (status === 429 || status === 403) return true;
  const t = (text || "").toLowerCase();
  return t.includes("limit") || t.includes("quota") || t.includes("exceeded") || t.includes("apikey");
}

function nextAvailableKeyIdx(startIdx) {
  const now = Date.now();
  for (let step = 0; step < CMNTY_API_KEYS.length; step++) {
    const idx = (startIdx + step) % CMNTY_API_KEYS.length;
    if ((_cmntyKeyDisabledUntil.get(idx) || 0) <= now) return idx;
  }
  return startIdx;
}

// Whitelist endpoint yang boleh diteruskan (mencegah SSRF / open-proxy abuse)
const ROUTES = {
  overchat:    { base: CMNTY_BASE, path: "/ai/overchat" },
  claude:      { base: CMNTY_BASE, path: "/ai/claude" },
  gemini:      { base: CMNTY_BASE, path: "/ai/gemini-3-1-flash" },
  deepsearch:  { base: CMNTY_BASE, path: "/ai/deepsearch" },
  copilot:     { base: CMNTY_BASE, path: "/ai/copilot" },
  ideogram:    { base: CMNTY_BASE, path: "/ai/ideogram", raw: true },
  nanobanana:  { base: CMNTY_BASE, path: "/ai/nanobanana", upload: true },
  deepaiimage: { base: CMNTY_BASE, path: "/ai/deepai-image" },
  notrack:     { base: CMNTY_BASE, path: "/ai/notrack" },
  andisearch:  { base: CMNTY_BASE, path: "/ai/andisearch" },
  mistral:     { base: CMNTY_BASE, path: "/ai/mistral" },
  qwen3coder:  { base: CMNTY_BASE, path: "/ai/qwen3coder" },
  bibleai:     { base: CMNTY_BASE, path: "/ai/bibleai" },
  spotifyplay: { base: CMNTY_BASE, path: "/downloader/spotify-play" },
  beritacnbc:  { base: CMNTY_BASE, path: "/berita/antara" },
  playstore:   { base: CMNTY_BASE, path: "/search/playstore" },
  happymod:    { base: CMNTY_BASE, path: "/search/happymod" },
  happymood:   { base: CMNTY_BASE, path: "/search/happymood" },
  searchdiscord: { base: CMNTY_BASE, path: "/search/discord" },
  stickerly:   { base: CMNTY_BASE, path: "/search/stickerly" },
  sfile:       { base: CMNTY_BASE, path: "/search/sfile" },
  searchgithub: { base: CMNTY_BASE, path: "/search/github" },
  searchcapcut: { base: CMNTY_BASE, path: "/search/capcut" },
  bingimage:   { base: CMNTY_BASE, path: "/search/bingimage" },
  ayatquran:   { base: CMNTY_BASE, path: "/search/ayat-quran" },
  searchsekolah: { base: CMNTY_BASE, path: "/search/sekolah" },
  felo:        { base: CMNTY_BASE, path: "/ai/felo" },
  sufrsense:   { base: CMNTY_BASE, path: "/ai/sufrsense" },
  dolphin:     { base: CMNTY_BASE, path: "/ai/dolphin" },
  toanime:     { base: CMNTY_BASE, path: "/ai/toanime", upload: true },
  gptimage:      { base: IKYYXD_BASE, path: "/gptimage", raw: true },
  "google-gemma": { base: IKYYXD_BASE, path: "/google-gemma" },
  "gpt-5-mini":  { base: IKYYXD_BASE, path: "/gpt-5-mini" },

  // Endpoint tools tambahan (dipindah dari tools.html supaya apikey tidak bocor ke client)
  downloader:  { base: CMNTY_BASE, path: "/downloader/aiov2" },
  removebg:    { base: CMNTY_BASE, path: "/tools/removebg" },
  pinsearch:   { base: CMNTY_BASE, path: "/search/pinterest" },
  webphishing: { base: CMNTY_BASE, path: "/tools/webphishing" },
  webtozip:    { base: CMNTY_BASE, path: "/tools/webtozip" },

  // Tools kreatif tambahan (semua binary/blob output)
  record:            { base: CMNTY_BASE, path: "/tools/record", binary: true },
  canvasnulis:        { base: CMNTY_BASE, path: "/canvas/nulis", binary: true },
  notifwav2:         { base: CMNTY_BASE, path: "/canvas/notifwav2", binary: true },
  notifwa:           { base: CMNTY_BASE, path: "/canvas/notifwa", binary: true },
  canvasngl:          { base: CMNTY_BASE, path: "/canvas/ngl", binary: true },
  paymentreceiptv1:  { base: CMNTY_BASE, path: "/canvas/payment-receipt-v1", binary: true },
  paymentreceipt:    { base: CMNTY_BASE, path: "/canvas/payment-receipt", binary: true },
  twobuttons:        { base: CMNTY_BASE, path: "/canvas/twobuttons", binary: true },

  // Tools tambahan batch 2
  tweet:       { base: CMNTY_BASE, path: "/maker/tweet", binary: true },
  fakewindows: { base: CMNTY_BASE, path: "/maker/fake-windows", binary: true },
  simthree:    { base: CMNTY_BASE, path: "/tools/simthree" },
  web2apk:     { base: CMNTY_BASE, path: "/tools/web2apk" },
  photobooth:  { base: CMNTY_BASE, path: "/canvas/photo-booth", upload: true, binary: true },

  // FAA API (api-faa.my.id)
  blackbox:    { base: FAA_BASE, path: "/blackbox" },
  jeevesai:    { base: FAA_BASE, path: "/jeeves-ai" },
  gptpromt:    { base: FAA_BASE, path: "/gpt-promt" },
  powerbrainai:{ base: FAA_BASE, path: "/powerbrain-ai" },
  islamai:     { base: FAA_BASE, path: "/islam-ai" },
  text2imgpro: { base: FAA_BASE, path: "/ai-text2img-pro", raw: true },
  epsilonai:   { base: FAA_BASE, path: "/epsilon-ai" }
};

// Rewind AI — proxy multi-model, dipanggil lewat POST { messages, model, stream } + parsing SSE.
// Setiap model diberi endpoint sendiri dengan nama yang jelas menunjukkan model aslinya,
// supaya konsisten: endpoint "qwenai" -> model Qwen AI, "grokai" -> model Grok AI, dst.
const REWIND_MODEL_MAP = {
  qwenai:     "qwen/qwen-2.5-7b-instruct",
  grokai:     "x-ai/grok-4.20",
  llamaai:    "meta-llama/llama-4-scout",
  claudeai:   "anthropic/claude-haiku-4.5",
  nemotronai: "nvidia/nemotron-3-ultra-550b-a55b",
  glmai:      "z-ai/glm-4.7-flash"
};

// Rate limit sederhana per-IP (in-memory, reset saat cold start — cukup untuk anti-spam ringan)
const hits = new Map();
function rateLimited(ip) {
  const now = Date.now();
  const rec = hits.get(ip) || { n: 0, t: now };
  if (now - rec.t > 60000) { rec.n = 0; rec.t = now; }
  rec.n++;
  hits.set(ip, rec);
  return rec.n > 30; // max 30 req/menit/IP
}

async function callRewindAI(modelId, prompt) {
  const payload = {
    messages: [{ role: "user", content: prompt }],
    model: modelId,
    stream: true
  };
  const upstream = await fetch(REWIND_BASE, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36",
      "Origin": "https://rewind.ai",
      "Referer": "https://rewind.ai/"
    },
    body: JSON.stringify(payload),
    signal: AbortSignal.timeout(60000)
  });

  if (!upstream.ok || !upstream.body) {
    const errText = await upstream.text().catch(() => "");
    throw new Error(`Rewind AI HTTP ${upstream.status}: ${errText.slice(0, 300)}`);
  }

  // Parsing SSE (Server-Sent Events) dari body streaming, gabungkan jadi satu teks utuh.
  const reader = upstream.body.getReader();
  const decoder = new TextDecoder();
  let fullText = "";
  let buffer = "";

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop(); // simpan baris terakhir yang mungkin belum lengkap
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed || trimmed === "data: [DONE]") continue;
      if (trimmed.startsWith("data: ")) {
        try {
          const json = JSON.parse(trimmed.slice(6));
          const content = json.choices?.[0]?.delta?.content || "";
          fullText += content;
        } catch (e) { /* abaikan baris SSE yang tidak valid */ }
      }
    }
  }
  return fullText.trim();
}

async function handleRewindRoute(ep, event, cors) {
  const modelId = REWIND_MODEL_MAP[ep];
  let prompt = "";
  try {
    const body = event.body ? JSON.parse(event.body) : {};
    prompt = body.text || body.prompt || "";
  } catch (e) {
    // fallback: coba ambil dari query string kalau body bukan JSON valid
  }
  if (!prompt) {
    const qp = event.queryStringParameters || {};
    prompt = qp.text || qp.prompt || "";
  }
  if (!prompt) {
    return { statusCode: 400, headers: cors, body: JSON.stringify({ status: false, error: "Parameter 'text' (prompt) wajib diisi." }) };
  }

  try {
    const result = await callRewindAI(modelId, prompt);
    return {
      statusCode: 200,
      headers: { ...cors, "Content-Type": "application/json" },
      body: JSON.stringify({ status: true, model: modelId, prompt, result })
    };
  } catch (err) {
    return {
      statusCode: 502,
      headers: { ...cors, "Content-Type": "application/json" },
      body: JSON.stringify({ status: false, error: err.message })
    };
  }
}


async function fallbackToHackAI(event, qs, cors) {
  try {
    const params = new URLSearchParams(qs || '');
    const text = params.get('text') || params.get('prompt') || params.get('question') || '';
    if (!text) return { statusCode: 400, headers: cors, body: JSON.stringify({ status:false, error:"Parameter text wajib diisi." }) };
    const hack = require('./hackai');
    const result = await hack.handler({
      ...event,
      httpMethod: 'POST',
      path: '/api/hackai',
      body: JSON.stringify({ text }),
      isBase64Encoded: false,
      headers: { ...(event.headers || {}), 'content-type': 'application/json', 'x-lianix-health-check': '1' }
    }, {});
    return { ...result, headers: { ...cors, ...(result.headers || {}) } };
  } catch (err) {
    return { statusCode: 502, headers: cors, body: JSON.stringify({ status:false, error:'Fallback AI gagal: '+err.message }) };
  }
}

async function forwardResponse(upstream, ep, cors) {
  const ct = upstream.headers.get("content-type") || "";
  const isBinaryExpected = ct.startsWith("image/") || ct.startsWith("video/") || ep === "ideogram" || ep === "gptimage";

  if (isBinaryExpected && upstream.ok && !ct.includes("application/json")) {
    const buf = Buffer.from(await upstream.arrayBuffer());
    return {
      statusCode: upstream.status,
      headers: { ...cors, "Content-Type": ct || "application/octet-stream" },
      body: buf.toString("base64"),
      isBase64Encoded: true
    };
  }

  const text = await upstream.text();
  if (!upstream.ok) {
    return {
      statusCode: upstream.status,
      headers: { ...cors, "Content-Type": ct.includes("application/json") ? "application/json" : "text/plain" },
      body: ct.includes("application/json")
        ? text
        : JSON.stringify({ status: false, error: `Upstream HTTP ${upstream.status}: ${text.slice(0, 300)}` })
    };
  }
  return {
    statusCode: upstream.status,
    headers: { ...cors, "Content-Type": ct.includes("application/json") ? "application/json" : "text/plain" },
    body: text
  };
}

exports.handler = async (event) => {
  const cors = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, X-Cmnty-Own-Key"
  };
  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers: cors, body: "" };

  const ip = event.headers["x-nf-client-connection-ip"] || event.headers["client-ip"] || "unknown";
  if (rateLimited(ip)) {
    return { statusCode: 429, headers: cors, body: JSON.stringify({ error: "Terlalu banyak permintaan, coba lagi sebentar." }) };
  }

  const ownKeyHeader = (event.headers["x-cmnty-own-key"] || "").trim();

  const segs = event.path.split("/").filter(Boolean);
  // Ambil segmen terakhir yang BUKAN bagian infrastruktur Netlify (functions/.netlify/ai-proxy),
  // untuk berjaga-jaga jika splat redirect menambahkan segmen ekstra.
  let ep = segs[segs.length - 1];
  if (ep === "ai-proxy" || ep === "functions" || ep === ".netlify" || ep === "api" || ep === "ai") {
    // cari mundur segmen valid pertama yang cocok dengan ROUTES atau REWIND_MODEL_MAP
    for (let i = segs.length - 1; i >= 0; i--) {
      if (ROUTES[segs[i]] || REWIND_MODEL_MAP[segs[i]]) { ep = segs[i]; break; }
    }
  }
  const route = ROUTES[ep];
  if (!route && !REWIND_MODEL_MAP[ep]) {
    return { statusCode: 404, headers: cors, body: JSON.stringify({ error: "Endpoint tidak dikenal" }) };
  }

  // Rewind AI punya alur sendiri: POST + streaming SSE, bukan sekadar teruskan query string.
  if (!route && REWIND_MODEL_MAP[ep]) {
    return await handleRewindRoute(ep, event, cors);
  }

  try {
    // Ambil query string dari berbagai kemungkinan sumber Netlify Functions,
    // supaya tidak hilang jika salah satu field tidak tersedia di runtime tertentu.
    let qs = "";
    if (event.rawQuery) {
      qs = event.rawQuery;
    } else if (event.queryStringParameters && Object.keys(event.queryStringParameters).length) {
      qs = new URLSearchParams(event.queryStringParameters).toString();
    } else if (event.rawUrl) {
      const idx = event.rawUrl.indexOf("?");
      if (idx !== -1) qs = event.rawUrl.slice(idx + 1);
    }
    // Sisipkan apikey di server (client tidak pernah mengirim/melihat apikey ini).
    // Kalau qs kebetulan sudah punya apikey (mis. client lama masih kirim), timpa dengan yang dari env.
    const longRunning = ep === "web2apk" || ep === "record" || ep === "qwen3coder" || ep === "bibleai";
    const buildFetchOpts = () => {
      const opts = { method: event.httpMethod, signal: AbortSignal.timeout(longRunning ? 120000 : 60000) };
      if (route.upload && event.httpMethod === "POST") {
        opts.headers = {
          "Content-Type": event.headers["content-type"],
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
          "Accept": "*/*"
        };
        opts.body = event.isBase64Encoded ? Buffer.from(event.body, "base64") : event.body;
      } else {
        opts.headers = {
          Accept: "application/json",
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
        };
      }
      return opts;
    };

    // Bukan endpoint CMNTY -> jalan seperti biasa, tidak ada rotasi key.
    if (route.base !== CMNTY_BASE) {
      const targetUrl = route.base + route.path + (qs ? "?" + qs : "");
      const upstream = await fetch(targetUrl, buildFetchOpts());
      return await forwardResponse(upstream, ep, cors);
    }

    // Endpoint CMNTY dengan key milik user sendiri (khusus tools, tidak lewat rotasi server)
    if (ownKeyHeader) {
      const params = new URLSearchParams(qs);
      params.set("apikey", ownKeyHeader);
      const targetUrl = route.base + route.path + "?" + params.toString();
      const upstream = await fetch(targetUrl, buildFetchOpts());
      return await forwardResponse(upstream, ep, cors);
    }

    if (!CMNTY_API_KEYS.length) {
      // Default chat must remain usable even when CMNTY keys are not configured yet.
      if (ep === "overchat") return await fallbackToHackAI(event, qs, cors);
      return {
        statusCode: 503,
        headers: cors,
        body: JSON.stringify({
          error: "Provider ini membutuhkan CMNTY_API_KEY di Netlify Environment Variables.",
          endpoint: ep
        })
      };
    }

    let lastResult = null;
    let triedCount = 0;
    let idx = nextAvailableKeyIdx(_cmntyKeyIdx);
    while (triedCount < CMNTY_API_KEYS.length) {
      const params = new URLSearchParams(qs);
      params.set("apikey", CMNTY_API_KEYS[idx]);
      const targetUrl = route.base + route.path + "?" + params.toString();
      const upstream = await fetch(targetUrl, buildFetchOpts());
      const ct = upstream.headers.get("content-type") || "";
      const isBinaryExpected = ct.startsWith("image/") || ct.startsWith("video/") || route.binary || ep === "ideogram" || ep === "gptimage";

      if (isBinaryExpected && upstream.ok && !ct.includes("application/json")) {
        _cmntyKeyIdx = idx;
        const buf = Buffer.from(await upstream.arrayBuffer());
        return {
          statusCode: upstream.status,
          headers: { ...cors, "Content-Type": ct || "application/octet-stream" },
          body: buf.toString("base64"),
          isBase64Encoded: true
        };
      }

      const text = await upstream.text();
      if (!upstream.ok && looksLikeLimitError(upstream.status, text)) {
        _cmntyKeyDisabledUntil.set(idx, Date.now() + 24 * 60 * 60 * 1000);
        lastResult = { status: upstream.status, ct, text };
        triedCount++;
        idx = nextAvailableKeyIdx((idx + 1) % CMNTY_API_KEYS.length);
        continue;
      }

      _cmntyKeyIdx = idx;
      if (!upstream.ok) {
        return {
          statusCode: upstream.status,
          headers: { ...cors, "Content-Type": ct.includes("application/json") ? "application/json" : "text/plain" },
          body: ct.includes("application/json")
            ? text
            : JSON.stringify({ status: false, error: `Upstream HTTP ${upstream.status}: ${text.slice(0, 300)}` })
        };
      }
      return {
        statusCode: upstream.status,
        headers: { ...cors, "Content-Type": ct.includes("application/json") ? "application/json" : "text/plain" },
        body: text
      };
    }

    if (ep === "overchat") return await fallbackToHackAI(event, qs, cors);
    return {
      statusCode: lastResult ? lastResult.status : 429,
      headers: { ...cors, "Content-Type": "application/json" },
      body: JSON.stringify({
        status: false,
        error: `Semua ${CMNTY_API_KEYS.length} API key CMNTY sedang limit/error. Coba lagi nanti.`,
        debug: lastResult ? lastResult.text.slice(0, 300) : undefined
      })
    };
  } catch (err) {
    const isTimeout = err.name === "TimeoutError" || err.name === "AbortError";
    const isLongRunning = ep === "web2apk" || ep === "record";
    let message = err.message || "Gagal menghubungi server AI";
    if (isTimeout && isLongRunning) {
      message = "Proses ini butuh waktu lama di server (bisa 1-2 menit) dan melebihi batas waktu server hosting saat ini. Coba lagi nanti, atau proses ini mungkin butuh infrastruktur server yang mendukung waktu eksekusi lebih panjang.";
    } else if (isTimeout) {
      message = "Server upstream tidak merespons tepat waktu. Coba lagi.";
    }
    return {
      statusCode: 502,
      headers: cors,
      body: JSON.stringify({
        error: message,
        debug: { endpoint: ep, path: event.path }
      })
    };
  }
};
