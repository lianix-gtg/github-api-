const { verifyAdminToken } = require('./_admin-auth');
const { analyzeCode } = require('./_api-meta');
const { fetchTimeout } = require('./_github');
const { canonicalMeta, signTest } = require('./_test-receipt');
const CORS = { 'Content-Type':'application/json', 'Access-Control-Allow-Origin':'*', 'Access-Control-Allow-Methods':'POST,OPTIONS', 'Access-Control-Allow-Headers':'Content-Type, Authorization' };
const out = (statusCode, body) => ({ statusCode, headers:CORS, body:JSON.stringify(body) });
const FILE_TYPES = new Set(['file','image','audio','video','folder']);
function resolveUrl(endpoint) {
  if (/^https?:\/\//i.test(endpoint || '')) return endpoint;
  const base = process.env.URL || process.env.DEPLOY_PRIME_URL || '';
  if (!base || !String(endpoint||'').startsWith('/')) return '';
  return base.replace(/\/$/,'') + endpoint;
}
function isPackedFiles(v){return !!(v&&typeof v==='object'&&v.__lianixFiles===true&&Array.isArray(v.files))}
function conditionRequires(input,values){
  const rw=input?.requiredWhen;if(!rw||typeof rw!=='object')return false;
  return Object.entries(rw).every(([k,allowed])=>Array.isArray(allowed)?allowed.map(String).includes(String(values?.[k]??'')):String(values?.[k]??'')===String(allowed));
}
function isMissing(input,value,values){
  if(!input?.required&&!conditionRequires(input,values))return false;
  if(FILE_TYPES.has(String(input.type||'').toLowerCase()))return !isPackedFiles(value)||value.files.length===0;
  return value===undefined||value===null||value==='';
}
function hasSelectedFiles(meta,values){return (meta.inputs||[]).some(x=>FILE_TYPES.has(String(x.type||'').toLowerCase())&&isPackedFiles(values[x.name])&&values[x.name].files.length)}
function validatePackedFiles(meta,values){
  let bytes=0,count=0;
  for(const input of meta.inputs||[]){
    if(!FILE_TYPES.has(String(input.type||'').toLowerCase()))continue;
    const pack=values[input.name];if(!isPackedFiles(pack))continue;
    for(const f of pack.files){
      if(!f||typeof f.dataBase64!=='string')throw new Error(`File test ${input.name} tidak valid.`);
      count++;bytes+=Buffer.byteLength(f.dataBase64,'base64');
      if(count>30)throw new Error('File test maksimal 30 item.');
      if(bytes>3*1024*1024)throw new Error('Total file test maksimal 3 MB.');
    }
  }
}
function buildMultipart(meta,values){
  if(typeof FormData==='undefined'||typeof Blob==='undefined')throw new Error('Runtime FormData tidak tersedia di server.');
  const form=new FormData();
  for(const input of meta.inputs||[]){
    const name=input.name,v=values[name];if(v===undefined||v===null||v==='')continue;
    if(FILE_TYPES.has(String(input.type||'').toLowerCase())){
      if(!isPackedFiles(v))continue;
      for(const f of v.files){
        const buf=Buffer.from(f.dataBase64,'base64');
        const blob=new Blob([buf],{type:f.type||'application/octet-stream'});
        form.append(name,blob,f.relativePath||f.name||'upload.bin');
      }
    } else form.append(name,String(v));
  }
  return form;
}
exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return { statusCode:204, headers:CORS, body:'' };
  if (event.httpMethod !== 'POST') return out(405,{success:false,error:'Method not allowed'});
  if (!await verifyAdminToken(event)) return out(401,{success:false,error:'Tidak terautentikasi.'});
  try {
    const p = JSON.parse(event.body || '{}');
    if (!p.code || typeof p.code !== 'string') return out(400,{success:false,error:'Kode JS wajib diisi.'});
    const auto = analyzeCode(p.code, { filename:p.filename||'api.js', category:p.category||'tools' });
    const merged = canonicalMeta({ ...auto, ...(p.meta || {}), inputs:Array.isArray(p.meta?.inputs)?p.meta.inputs:auto.inputs, outputs:Array.isArray(p.meta?.outputs)?p.meta.outputs:auto.outputs });
    const values = p.values && typeof p.values === 'object' ? p.values : {};
    const missing = (merged.inputs||[]).filter(x => isMissing(x,values[x.name],values)).map(x=>x.name);
    if (missing.length) return out(400,{success:false,error:'Parameter test wajib belum diisi: '+missing.join(', '),data:{meta:merged,syntax:true}});
    validatePackedFiles(merged,values);
    const cleanValues=Object.fromEntries(Object.entries(values).filter(([k,v])=>{if(v===undefined||v===null||v==='')return false;if(isPackedFiles(v)&&!v.files.length)return false;return true}));
    const testUrl = resolveUrl(merged.endpoint);
    const result = { syntax:true, meta:merged, runtimeProbe:null };
    if (p.runProbe === true) {
      if (!testUrl) return out(422,{success:false,error:'Runtime probe tidak bisa dijalankan karena endpoint belum dapat di-resolve.',data:result});
      const started = Date.now();
      const method = String(merged.method || 'GET').toUpperCase();
      const hasFiles=hasSelectedFiles(merged,cleanValues);
      if(method==='GET'&&hasFiles)return out(422,{success:false,error:'GET tidak dapat mengirim file/folder. Ubah method menjadi POST atau gunakan parameter URL.',data:result});
      let url = testUrl; const options = { method, headers:{'X-Lianix-Test':'1'} };
      if (method === 'GET') {
        const u = new URL(url); Object.entries(cleanValues).forEach(([k,v])=>{ if(v!=='' && v!=null && typeof v !== 'object') u.searchParams.set(k,String(v)); }); url = u.toString();
      } else if(hasFiles) {
        options.body=buildMultipart(merged,cleanValues);
      } else {
        options.headers = {...options.headers,'Content-Type':'application/json'};
        options.body = JSON.stringify(cleanValues);
      }
      try {
        const r = await fetchTimeout(url, options, 15000);
        const text = await r.text().catch(()=> '');
        result.runtimeProbe = { ok:r.ok,status:r.status,latency:Date.now()-started,preview:text.slice(0,600),url };
        if (!r.ok) return out(422,{success:false,error:`Runtime probe gagal: HTTP ${r.status}`,data:result});
      } catch (e) {
        result.runtimeProbe = { ok:false,status:0,latency:Date.now()-started,error:e.name==='AbortError'?'Timeout 15 detik':e.message,url };
        return out(422,{success:false,error:`Runtime probe gagal: ${result.runtimeProbe.error}`,data:result});
      }
    }
    const receipt = signTest(p.code, merged);
    return out(200,{success:true,data:{...result,testReceipt:receipt,testedAt:Date.now()}});
  } catch (e) { return out(400,{success:false,error:e.message}); }
};
