const { makeStore, connectBlobs } = require('./_store');
const CORS={'Content-Type':'application/json','Access-Control-Allow-Origin':'*','Cache-Control':'public,max-age=0,s-maxage=30'};

async function mapLimit(items, limit, fn){
  const out=new Array(items.length); let next=0;
  async function worker(){
    while(true){const i=next++; if(i>=items.length) return; out[i]=await fn(items[i],i)}
  }
  await Promise.all(Array.from({length:Math.min(limit,items.length)},worker));
  return out;
}

exports.handler=async(event)=>{
  connectBlobs(event);
  try{
    const store=makeStore('f24nt-api-health');
    const {blobs=[]}=await store.list();
    const rows=await mapLimit(blobs.slice(0,500),20,async b=>{
      try{return await store.get(b.key,{type:'json'})}catch{return null}
    });
    const items=rows.filter(Boolean).sort((a,b)=>(b.checkedAt||0)-(a.checkedAt||0));
    return{statusCode:200,headers:CORS,body:JSON.stringify({success:true,data:items})};
  }catch(e){
    return{statusCode:200,headers:CORS,body:JSON.stringify({success:false,data:[],error:e.message})};
  }
};
