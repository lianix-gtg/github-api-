const { makeStore, connectBlobs } = require('./_store');
const { requireUser, userKey } = require('./_user-auth');

function out(statusCode, body){ return { statusCode, headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store'}, body:JSON.stringify(body) }; }

exports.handler = async (event) => {
  connectBlobs(event);
  if(event.httpMethod !== 'POST') return out(405,{ok:false,error:'METHOD_NOT_ALLOWED'});
  try{
    const user = await requireUser(event);
    const body = JSON.parse(event.body || '{}');
    const action = String(body.action || 'status');
    const store = makeStore('lianix-registered-accounts');
    const key = userKey(user.uid);
    const existing = await store.get(key,{type:'json'}).catch(()=>null);

    if(action === 'status') return out(200,{ok:true,registered:!!existing,user:existing || null});
    if(action === 'register'){
      if(existing) return out(200,{ok:true,registered:true,alreadyRegistered:true,user:existing});
      const rec = {
        uid:user.uid,
        email:user.email || null,
        displayName:user.displayName || (user.email ? String(user.email).split('@')[0] : 'Lianix User'),
        providerId:user.providerId || 'account',
        registeredAt:new Date().toISOString()
      };
      await store.setJSON(key,rec);
      return out(200,{ok:true,registered:true,user:rec});
    }
    return out(400,{ok:false,error:'UNKNOWN_ACTION'});
  }catch(e){
    return out(e.statusCode || 401,{ok:false,error:e.message || 'AUTH_REQUIRED'});
  }
};
