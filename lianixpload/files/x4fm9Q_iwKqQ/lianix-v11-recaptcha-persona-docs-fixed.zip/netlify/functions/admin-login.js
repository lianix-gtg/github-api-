const crypto = require('node:crypto');
const { createAdminToken } = require('./_admin-auth');

const CORS={
  'Content-Type':'application/json',
  'Access-Control-Allow-Origin':'*',
  'Access-Control-Allow-Methods':'POST,OPTIONS',
  'Access-Control-Allow-Headers':'Content-Type',
  'Cache-Control':'no-store'
};
const out=(statusCode,body)=>({statusCode,headers:CORS,body:JSON.stringify(body)});
function normalizeEnvPassword(v){ return String(v ?? '').replace(/\r?\n$/,''); }
function safeEqual(a,b){
  const aa=Buffer.from(String(a??''),'utf8'), bb=Buffer.from(String(b??''),'utf8');
  return aa.length===bb.length && crypto.timingSafeEqual(aa,bb);
}
exports.handler=async(event)=>{
  if(event.httpMethod==='OPTIONS')return{statusCode:204,headers:CORS,body:''};
  if(event.httpMethod!=='POST')return out(405,{success:false,error:'Method not allowed'});
  const adminPassword=normalizeEnvPassword(process.env.ADMIN_PASSWORD);
  if(!adminPassword)return out(500,{success:false,error:'ADMIN_PASSWORD belum dikonfigurasi di Netlify Environment Variables.'});
  let payload={};try{payload=JSON.parse(event.body||'{}')}catch{return out(400,{success:false,error:'Body tidak valid.'})}
  if(!safeEqual(String(payload.password??''),adminPassword))return out(401,{success:false,error:'Password salah.'});
  try{
    const token=createAdminToken();
    return out(200,{success:true,token,expiresIn:43200});
  }catch(e){return out(500,{success:false,error:e.message||'Gagal membuat session admin.'})}
};
