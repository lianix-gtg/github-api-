const { verifyAdminToken } = require('./_admin-auth');
const { analyzeCode } = require('./_api-meta');
const { safeProbe } = require('./_safe-script-probe');
const { parseCliText, parseParameterComments, mergeInputs } = require('./_cli-parameter-parser');
const { reviewWithFallback, mergeJeeves } = require('./_jeeves-parameter-review');

const CORS = { 'Content-Type':'application/json', 'Access-Control-Allow-Origin':'*', 'Access-Control-Allow-Methods':'POST,OPTIONS', 'Access-Control-Allow-Headers':'Content-Type, Authorization' };
const out = (statusCode, body) => ({ statusCode, headers:CORS, body:JSON.stringify(body) });
function basicMeta(p){
  const filename=String(p.filename||'api.js');
  const base=filename.replace(/\.js$/i,'').replace(/[^a-z0-9]+/gi,'-').replace(/^-|-$/g,'').toLowerCase()||'api';
  const comments=parseParameterComments(p.code||'');
  const cli=parseCliText(p.code||'');
  return {id:base,name:base.replace(/-/g,' ').replace(/\b\w/g,c=>c.toUpperCase()),description:p.description||'',method:'GET',endpoint:p.endpoint||`/api/${base}`,category:p.category||'tools',inputs:mergeInputs(comments,cli),outputs:[{type:'json',label:'Result'}],tags:[],dependencies:[],dependencyModes:{},dependencyVersions:{},installCommand:'',externalUrls:[],confidence:(comments.length||cli.length)?72:35,syntaxValid:false};
}
exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return { statusCode:204, headers:CORS, body:'' };
  if (event.httpMethod !== 'POST') return out(405,{success:false,error:'Method not allowed'});
  if (!await verifyAdminToken(event)) return out(401,{success:false,error:'Tidak terautentikasi.'});
  try {
    const p = JSON.parse(event.body || '{}');
    if (!p.code || typeof p.code !== 'string') return out(400,{success:false,error:'Kode JS wajib diisi.'});
    const trace=[]; const warnings=[];
    let meta;
    try{
      meta=analyzeCode(p.code,{filename:p.filename||'api.js',category:p.category||'tools',name:p.name,description:p.description,endpoint:p.endpoint});
      trace.push({stage:'AST + metadata + komentar',ok:true,parameters:meta.inputs.length});
    }catch(e){
      meta=basicMeta(p);warnings.push('AST belum bisa membaca seluruh source: '+e.message+' Hasil fallback tetap bisa diedit manual.');
      trace.push({stage:'AST + metadata + komentar',ok:false,parameters:meta.inputs.length,error:e.message});
    }

    let probe={attempted:false,ok:false,mode:'skipped',stdout:'',stderr:''};
    try{probe=safeProbe(p.code,{filename:p.filename||'api.js'})}catch(e){probe={attempted:true,ok:false,mode:'error',stdout:'',stderr:String(e.message||e)}}
    const probeInputs=parseCliText(probe.stdout||'');
    if(probeInputs.length){meta.inputs=mergeInputs(meta.inputs||[],probeInputs);meta.confidence=Math.min(99,Math.max(meta.confidence||0,86));}
    trace.push({stage:'Safe CLI --help probe',ok:probe.ok,parameters:probeInputs.length,preview:(probe.stdout||probe.stderr||'').slice(0,500)});

    let aiReview={ok:false,provider:'disabled',error:'AI review dinonaktifkan.',attempts:[]};
    if(p.useJeeves!==false){
      aiReview=await reviewWithFallback({code:p.code,meta,probe});
      if(aiReview.ok){meta.inputs=mergeJeeves(meta.inputs||[],aiReview.inputs);meta.confidence=Math.min(99,Math.max(meta.confidence||0,Number(aiReview.confidence)||88));}
      for(const a of aiReview.attempts||[]) trace.push({stage:`AI review · ${a.provider}`,ok:a.ok,parameters:a.ok?(aiReview.inputs?.length||0):0,error:a.error||''});
      if(!aiReview.ok) warnings.push('Semua AI reviewer sedang tidak tersedia. Auto Detect tetap memakai parser lokal + Safe Probe; parameter bisa diedit manual.');
      else if(aiReview.fallbackUsed) warnings.push(`Jeeves gagal; Auto Detect otomatis memakai ${aiReview.provider} sebagai fallback.`);
    }
    if((meta.inputs||[]).length===0)warnings.push('Belum ada parameter yang terbukti dari source/help. Tambahkan parameter manual jika API memang membutuhkan input.');
    if((meta.confidence||0)<80)warnings.push('Confidence auto-detect belum tinggi. Cek parameter sebelum publish.');
    if(!probe.ok)warnings.push('Safe Probe tidak selesai penuh; analyzer tetap memakai bukti statis/AI fallback.');
    meta.analysis={probe:{attempted:probe.attempted,ok:probe.ok,mode:probe.mode,stdout:(probe.stdout||'').slice(0,1200),stderr:(probe.stderr||'').slice(0,700)},ai:{ok:aiReview.ok,provider:aiReview.provider||'',fallbackUsed:!!aiReview.fallbackUsed,error:aiReview.error||'',notes:aiReview.notes||[],confidence:aiReview.confidence||0,attempts:aiReview.attempts||[]},trace};
    return out(200,{success:true,data:meta,warnings});
  } catch (e) { return out(400,{success:false,error:e.message}); }
};
