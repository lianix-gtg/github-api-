const { getUpload } = require('./_pload-db');
const HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET,OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Cache-Control': 'no-store',
  'Content-Type': 'application/json; charset=utf-8'
};
exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return { statusCode: 204, headers: HEADERS, body: '' };
  if (event.httpMethod !== 'GET') return { statusCode: 405, headers: HEADERS, body: JSON.stringify({success:false,error:'Method not allowed'}) };
  const id = String(event.queryStringParameters?.id || '').trim();
  const meta = await getUpload(event, id);
  if (!meta) return { statusCode: 404, headers: HEADERS, body: JSON.stringify({success:false,error:'File tidak ditemukan.'}) };
  return { statusCode: 200, headers: HEADERS, body: JSON.stringify({
    success: true,
    file: { id: meta.id, filename: meta.filename, mime: meta.mime, size: meta.size, createdAt: meta.createdAt, url: `/f/${meta.id}` }
  }) };
};
