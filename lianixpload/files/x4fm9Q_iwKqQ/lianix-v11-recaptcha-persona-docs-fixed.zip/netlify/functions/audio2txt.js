// netlify/functions/audio2txt.js
// Transkrip audio ke teks lewat audioconvert.ai. Client kirim multipart/form-data field "audio".
// Alur: warmup -> presign upload -> PUT ke OSS -> check-guest-quota -> submit transcribe -> poll hasil.

function json(statusCode, cors, body) {
  return { statusCode, headers: { ...cors, "Content-Type": "application/json" }, body: JSON.stringify(body) };
}

const BASE = "https://audioconvert.ai";
const PAGE_URL = `${BASE}/id`;
const JWT_SECRET = "auc995cx6se";
const LANGUAGE_CODE = "";
const SCENARIO = "auto";

const UA = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36";

const crypto = require("node:crypto");

function base64url(input) {
  return Buffer.from(input).toString("base64").replace(/=+$/g, "").replace(/\+/g, "-").replace(/\//g, "_");
}
function uuidv4() {
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, c => {
    const r = (Math.random() * 16) | 0, v = c === "x" ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}
function createGuestBearer(userId = uuidv4()) {
  const header = { alg: "HS256", typ: "JWT" };
  const payload = { userId };
  const encodedHeader = base64url(JSON.stringify(header));
  const encodedPayload = base64url(JSON.stringify(payload));
  const data = `${encodedHeader}.${encodedPayload}`;
  const signature = crypto.createHmac("sha256", JWT_SECRET).update(data).digest("base64")
    .replace(/=+$/g, "").replace(/\+/g, "-").replace(/\//g, "_");
  return { userId, token: `${data}.${signature}` };
}
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
function cleanUploadUrl(url) { return String(url || "").split("?")[0]; }

function parseMultipart(bodyBuffer, contentType, fieldName) {
  const boundaryMatch = /boundary=(?:"([^"]+)"|([^;]+))/i.exec(contentType || "");
  const boundary = boundaryMatch ? (boundaryMatch[1] || boundaryMatch[2]) : null;
  if (!boundary) throw new Error("Boundary tidak ditemukan di Content-Type");
  const boundaryBuf = Buffer.from("--" + boundary);
  const parts = [];
  let start = bodyBuffer.indexOf(boundaryBuf);
  while (start !== -1) {
    const next = bodyBuffer.indexOf(boundaryBuf, start + boundaryBuf.length);
    if (next === -1) break;
    parts.push(bodyBuffer.slice(start + boundaryBuf.length, next));
    start = next;
  }
  for (const part of parts) {
    const headerEnd = part.indexOf("\r\n\r\n");
    if (headerEnd === -1) continue;
    const headerStr = part.slice(0, headerEnd).toString("utf-8");
    if (!new RegExp(`name="${fieldName}"`, "i").test(headerStr)) continue;
    let content = part.slice(headerEnd + 4);
    if (content.slice(-2).toString() === "\r\n") content = content.slice(0, -2);
    const filenameMatch = /filename="([^"]*)"/i.exec(headerStr);
    return { filename: filenameMatch ? filenameMatch[1] : "audio.mp3", buffer: content };
  }
  throw new Error(`Field "${fieldName}" tidak ditemukan di form-data`);
}

async function warmup() {
  await fetch(PAGE_URL, {
    headers: {
      "user-agent": UA,
      accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
      referer: BASE
    }
  }).catch(() => {});
}

async function presign(guest, filename) {
  const url = `${BASE}/api/resource/upload/presign?filename=${encodeURIComponent(filename)}`;
  const res = await fetch(url, {
    headers: { "user-agent": UA, authorization: `Bearer ${guest.token}`, referer: PAGE_URL, accept: "*/*" }
  });
  const data = await res.json().catch(() => null);
  if (!res.ok || data?.code !== 100000 || !data?.data?.upload_url) throw new Error(`Presign gagal HTTP ${res.status}: ${JSON.stringify(data)}`);
  return data.data.upload_url;
}

async function uploadToOss(uploadUrl, buffer) {
  const res = await fetch(uploadUrl, {
    method: "PUT", body: buffer,
    headers: { "Content-Length": String(buffer.length) }
  });
  if (!res.ok) throw new Error(`Upload OSS gagal HTTP ${res.status}`);
  return cleanUploadUrl(uploadUrl);
}

async function checkGuestQuota(guest, durationMinutes) {
  const res = await fetch(`${BASE}/api/transcribe/check-guest-quota`, {
    method: "POST",
    body: JSON.stringify({ duration_minutes: durationMinutes }),
    headers: {
      "user-agent": UA, authorization: `Bearer ${guest.token}`, referer: PAGE_URL, origin: BASE,
      accept: "application/json", "content-type": "application/json"
    }
  });
  const data = await res.json().catch(() => null);
  if (!res.ok || data?.code !== 100000) throw new Error(`Check quota gagal HTTP ${res.status}: ${JSON.stringify(data)}`);
  if (!data?.data?.allowed) throw new Error(`Kuota tidak tersedia: ${JSON.stringify(data)}`);
  return data.data.allowed;
}

async function createTranscribe(guest, audioUrl, fileName) {
  const payload = { audio_url: audioUrl, language_code: LANGUAGE_CODE, file_name: fileName, scenario: SCENARIO };
  const res = await fetch(`${BASE}/api/transcribe/`, {
    method: "POST", body: JSON.stringify(payload),
    headers: {
      "user-agent": UA, authorization: `Bearer ${guest.token}`, referer: PAGE_URL, origin: BASE,
      accept: "application/json", "content-type": "application/json"
    }
  });
  const data = await res.json().catch(() => null);
  if (!res.ok || data?.code !== 100000 || !data?.data?.id) throw new Error(`Submit transcribe gagal HTTP ${res.status}: ${JSON.stringify(data)}`);
  return data.data;
}

async function getTranscribe(guest, taskId) {
  const res = await fetch(`${BASE}/api/transcribe/${taskId}`, {
    headers: { "user-agent": UA, authorization: `Bearer ${guest.token}`, referer: PAGE_URL, accept: "*/*" }
  });
  const data = await res.json().catch(() => null);
  return { status: res.status, data };
}

function extractText(data) {
  const d = data?.data ?? data;
  if (!d) return null;
  if (typeof d === "string") return d;
  const value = d.text ?? d.transcript ?? d.result ?? d.content ?? d.transcription ??
    (d.segments ? d.segments.map(x => x.text).filter(Boolean).join(" ") : null);
  if (typeof value === "string") return value;
  if (value && typeof value === "object") {
    return value.text ?? value.transcript ?? value.result ?? value.content ?? value.transcription ?? null;
  }
  return null;
}

async function pollResult(guest, taskId) {
  for (let i = 0; i < 12; i++) {
    const { data } = await getTranscribe(guest, taskId);
    if (data?.code === 100001 || data?.message === "Need Login") return { done: false, need_login: true, text: null };
    if (data?.code === 100000) {
      const task = data.data;
      const text = extractText(data);
      if (task?.status === "succeeded" || task?.status === "success" || task?.status === "completed" || text) {
        return { done: true, need_login: false, text };
      }
      if (task?.status === "failed" || task?.status === "error") {
        throw new Error(task?.error ?? data?.message ?? "Transkripsi gagal");
      }
    }
    await sleep(3000);
  }
  return { done: false, need_login: false, text: null };
}

exports.handler = async (event) => {
  const cors = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "POST,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type"
  };
  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers: cors, body: "" };
  if (event.httpMethod !== "POST") return json(405, cors, { status: false, error: "Gunakan metode POST dengan multipart/form-data field \"audio\"" });

  try {
    const contentType = event.headers["content-type"] || event.headers["Content-Type"];
    const bodyBuffer = event.isBase64Encoded ? Buffer.from(event.body, "base64") : Buffer.from(event.body, "utf-8");
    const file = parseMultipart(bodyBuffer, contentType, "audio");

    const guest = createGuestBearer();
    await warmup();

    const uploadUrl = await presign(guest, file.filename);
    const audioUrl = await uploadToOss(uploadUrl, file.buffer);

    // Estimasi durasi sederhana dari ukuran file (fallback 1 menit) karena ffprobe
    // tidak tersedia di lingkungan serverless ini.
    const estimatedMinutes = Math.max(1, Math.ceil(file.buffer.length / (1024 * 1024 * 1)));
    await checkGuestQuota(guest, estimatedMinutes);

    const task = await createTranscribe(guest, audioUrl, file.filename);
    const poll = await pollResult(guest, task.id);

    if (poll.need_login) return json(401, cors, { status: false, code: 401, input: file.filename, result: null, error: "Server minta login (guest quota habis). Coba lagi nanti." });
    if (!poll.text) return json(202, cors, { status: false, code: 202, input: file.filename, result: null, error: "Transkripsi belum selesai, coba lagi." });

    return json(200, cors, { status: true, code: 200, input: file.filename, result: poll.text });
  } catch (err) {
    return json(500, cors, { status: false, code: 500, error: err.message });
  }
};


// LIANIX_USAGE_WRAPPER_V7
const { wrapHandler: __wrapLianixUsage } = require('./_usage');
exports.handler = __wrapLianixUsage(exports.handler, { apiId: 'audio2txt', name: 'audio2txt' });

// Lianix per-user public API key guard
const { withPublicApiKey } = require('./_user-api-key');
exports.handler = withPublicApiKey(exports.handler);
