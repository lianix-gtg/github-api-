// netlify/functions/upscalevid.js
// Video Upscaler lewat unwatermark.ai (video-enhancer). Client kirim multipart/form-data field "video".
// Alur: minta upload url -> PUT file ke signed url -> create job -> poll job.

function json(statusCode, cors, body) {
  return { statusCode, headers: { ...cors, "Content-Type": "application/json" }, body: JSON.stringify(body) };
}

const API = "https://api.unwatermark.ai";
const WEB = "https://unblurimage.ai";
const RESOLUTION = "2k";
const IS_PREVIEW = "false";

const UA = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36";

function randomProductSerial() {
  const chars = "abcdefghijklmnopqrstuvwxyz0123456789";
  let out = "";
  for (let i = 0; i < 6; i++) out += chars[Math.floor(Math.random() * chars.length)];
  return out;
}
function uuidv4() {
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, c => {
    const r = (Math.random() * 16) | 0, v = c === "x" ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}
function extToMime(filename) {
  const ext = (filename.split(".").pop() || "").toLowerCase();
  if (ext === "mp4") return "video/mp4";
  if (ext === "mov") return "video/quicktime";
  if (ext === "webm") return "video/webm";
  if (ext === "mkv") return "video/x-matroska";
  return "application/octet-stream";
}
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
function cleanPublicUrl(url) { return String(url || "").split("?")[0]; }

function parseMultipart(bodyBuffer, contentType, fieldName) {
  const boundaryMatch = /boundary=(?:"([^"]+)"|([^;]+))/i.exec(contentType || "");
  const boundary = boundaryMatch ? (boundaryMatch[1] || boundaryMatch[2]) : null;
  if (!boundary) throw new Error("Boundary tidak ditemukan di Content-Type");
  const boundaryBuf = Buffer.from("--" + boundary);
  const parts = [];
  let start = bodyBuffer.indexOf(boundaryBuf);
  while (start !== -1) {
    const next = bodyBuffer.indexOf(boundaryBuf, start + boundaryBuf.length);
    if (next === -1) break;
    parts.push(bodyBuffer.slice(start + boundaryBuf.length, next));
    start = next;
  }
  for (const part of parts) {
    const headerEnd = part.indexOf("\r\n\r\n");
    if (headerEnd === -1) continue;
    const headerStr = part.slice(0, headerEnd).toString("utf-8");
    if (!new RegExp(`name="${fieldName}"`, "i").test(headerStr)) continue;
    let content = part.slice(headerEnd + 4);
    if (content.slice(-2).toString() === "\r\n") content = content.slice(0, -2);
    const filenameMatch = /filename="([^"]*)"/i.exec(headerStr);
    return { filename: filenameMatch ? filenameMatch[1] : "video.mp4", buffer: content };
  }
  throw new Error(`Field "${fieldName}" tidak ditemukan di form-data`);
}

function baseHeaders(extra = {}) {
  return {
    accept: "*/*", origin: WEB, referer: `${WEB}/`, "user-agent": UA,
    "product-code": "067003", "product-serial": randomProductSerial(),
    "x-request-id": uuidv4(), ...extra
  };
}

async function createUploadUrl(filename) {
  const form = new FormData();
  form.append("video_file_name", filename);
  const res = await fetch(`${API}/api/web/common/upload/video`, { method: "POST", body: form, headers: baseHeaders() });
  const data = await res.json().catch(() => null);
  if (!res.ok || data?.code !== 100000) throw new Error(`Gagal ambil upload url: ${JSON.stringify(data)}`);
  return data.result;
}

async function putFileToSignedUrl(uploadUrl, filename, buffer) {
  const res = await fetch(uploadUrl, {
    method: "PUT", body: buffer,
    headers: { "content-type": extToMime(filename), "content-length": String(buffer.length) }
  });
  if (!res.ok) throw new Error(`Upload file gagal HTTP ${res.status}`);
}

async function createJob(originalVideoUrl) {
  const form = new FormData();
  form.append("original_video_url", originalVideoUrl);
  form.append("resolution", RESOLUTION);
  form.append("is_preview", IS_PREVIEW);
  const res = await fetch(`${API}/api/web/unblurimage/v1/video-enhancer/create-job`, { method: "POST", body: form, headers: baseHeaders() });
  const data = await res.json().catch(() => null);
  if (!res.ok || !data?.result?.job_id) throw new Error(`Gagal create job: ${JSON.stringify(data)}`);
  return data.result;
}

async function getJob(jobId) {
  const res = await fetch(`${API}/api/web/unblurimage/v1/video-enhancer/get-job/${jobId}`, {
    headers: baseHeaders({ "content-type": "application/json; charset=UTF-8" })
  });
  const data = await res.json().catch(() => null);
  return { status: res.status, data };
}

async function waitJob(jobId, maxTry = 9, delayMs = 4000) {
  let last = null;
  for (let i = 1; i <= maxTry; i++) {
    const result = await getJob(jobId);
    last = result.data;
    const status = result.data?.result?.status;
    const outputUrl = result.data?.result?.output_url;
    if (Array.isArray(outputUrl) && outputUrl.length > 0) return result.data;
    if (status === 1) return result.data;
    await sleep(delayMs);
  }
  throw new Error("Waktu tunggu habis, hasil belum selesai. Coba lagi.");
}

exports.handler = async (event) => {
  const cors = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "POST,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type"
  };
  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers: cors, body: "" };
  if (event.httpMethod !== "POST") return json(405, cors, { status: false, error: "Gunakan metode POST dengan multipart/form-data field \"video\"" });

  try {
    const contentType = event.headers["content-type"] || event.headers["Content-Type"];
    const bodyBuffer = event.isBase64Encoded ? Buffer.from(event.body, "base64") : Buffer.from(event.body, "utf-8");
    const file = parseMultipart(bodyBuffer, contentType, "video");

    const upload = await createUploadUrl(file.filename);
    const signedUrl = upload.url;
    const publicUrl = cleanPublicUrl(upload.url);

    await putFileToSignedUrl(signedUrl, file.filename, file.buffer);

    const job = await createJob(publicUrl);
    const done = await waitJob(job.job_id);

    const resultUrl = done.result?.output_url?.[0] || "";
    if (!resultUrl) throw new Error("Server tidak mengembalikan hasil video.");

    return json(200, cors, { status: true, code: 200, input: file.filename, result_url: resultUrl });
  } catch (err) {
    return json(500, cors, { status: false, code: 500, error: err.message });
  }
};


// LIANIX_USAGE_WRAPPER_V7
const { wrapHandler: __wrapLianixUsage } = require('./_usage');
exports.handler = __wrapLianixUsage(exports.handler, { apiId: 'upscalevid', name: 'upscalevid' });

// Lianix per-user public API key guard
const { withPublicApiKey } = require('./_user-api-key');
exports.handler = withPublicApiKey(exports.handler);
