// Public cancellation is disabled. Manual payment decisions are admin-only.
function json(s,b){return{statusCode:s,headers:{'Content-Type':'application/json','Cache-Control':'no-store','Access-Control-Allow-Origin':'*','Access-Control-Allow-Methods':'POST, OPTIONS','Access-Control-Allow-Headers':'Content-Type'},body:JSON.stringify(b)}}
exports.handler=async(event)=>{if(event.httpMethod==='OPTIONS')return json(204,{});return json(403,{success:false,error:'Pembatalan QRIS manual hanya bisa dilakukan Admin dari Admin Panel.'})};
