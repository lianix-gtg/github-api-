// GET /api/user/plan?deviceId=legacy
// Account login is the primary key; deviceId is only a legacy fallback.
const { getUserPlan, connectBlobs } = require('./_store');
const { planKey } = require('./_plan-user-key');
exports.handler = async (event) => {
  connectBlobs(event);
  const CORS={"Content-Type":"application/json","Cache-Control":"no-store","Access-Control-Allow-Origin":"*","Access-Control-Allow-Methods":"GET, OPTIONS","Access-Control-Allow-Headers":"Content-Type, Authorization, X-Lianix-Email-Session"};
  if(event.httpMethod==='OPTIONS')return{statusCode:204,headers:CORS,body:''};
  if(event.httpMethod!=='GET')return{statusCode:405,headers:CORS,body:JSON.stringify({success:false,error:'Method not allowed'})};
  try{
    const deviceId=String(event.queryStringParameters?.deviceId||'').trim();
    const k=await planKey(event,deviceId);
    let planData=await getUserPlan(k.key);
    let migrated=false;
    if(!planData&&k.legacy&&k.legacy!==k.key){planData=await getUserPlan(k.legacy);migrated=!!planData;}
    if(!planData)return{statusCode:200,headers:CORS,body:JSON.stringify({success:true,data:{plan:null,active:false}})};
    const active=!!(planData.expiresAt&&planData.expiresAt>Date.now());
    return{statusCode:200,headers:CORS,body:JSON.stringify({success:true,data:{plan:active?planData.plan:null,active,expiresAt:planData.expiresAt||null,migrated}})};
  }catch(err){return{statusCode:err.statusCode||500,headers:CORS,body:JSON.stringify({success:false,error:err.message})}}
};
