// Lianix API — System Status endpoint
const os = require("os");

const startedAt = Date.now();

function formatUptime(seconds) {
  seconds = Math.max(0, Math.floor(seconds));
  const d = Math.floor(seconds / 86400);
  const h = Math.floor((seconds % 86400) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  const parts = [];
  if (d) parts.push(`${d}d`);
  if (h || d) parts.push(`${h}h`);
  if (m || h || d) parts.push(`${m}m`);
  parts.push(`${s}s`);
  return parts.join(" ");
}

exports.handler = async (event) => {
  const started = process.hrtime.bigint();
  const mem = process.memoryUsage();
  const total = os.totalmem();
  const free = os.freemem();
  const cores = os.cpus().length || 1;
  const load = os.loadavg ? os.loadavg() : [0, 0, 0];
  const latency = Number(process.hrtime.bigint() - started) / 1e6;

  return {
    statusCode: 200,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store",
      "Access-Control-Allow-Origin": "*"
    },
    body: JSON.stringify({
      status: true,
      api: {
        status: "online",
        environment: process.env.CONTEXT || process.env.NODE_ENV || "production",
        uptime: {
          seconds: Math.floor(process.uptime()),
          human: formatUptime(process.uptime())
        },
        latency: `${latency.toFixed(2)} ms`,
        timestamp: new Date().toISOString()
      },
      system: {
        memory: {
          used: `${(mem.rss / 1024 / 1024).toFixed(1)} MB`,
          total: `${(total / 1024 / 1024 / 1024).toFixed(2)} GB`,
          free: `${(free / 1024 / 1024 / 1024).toFixed(2)} GB`
        },
        cpu: {
          cores,
          load_avg: {
            "1m": Number(load[0] || 0),
            "5m": Number(load[1] || 0),
            "15m": Number(load[2] || 0)
          }
        },
        platform: process.platform,
        arch: process.arch
      }
    })
  };
};


// LIANIX_USAGE_WRAPPER_V7
const { wrapHandler: __wrapLianixUsage } = require('./_usage');
exports.handler = __wrapLianixUsage(exports.handler, { apiId: 'status', name: 'status' });
