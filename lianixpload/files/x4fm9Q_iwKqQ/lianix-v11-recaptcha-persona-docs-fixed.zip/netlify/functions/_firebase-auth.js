const DEFAULT_FIREBASE_WEB_API_KEY = 'AIzaSyDv5x_s-KWr6Fj-i0cpQc3T487pJiGTeyA';

function bearerFromEvent(event) {
  const raw = event?.headers?.authorization || event?.headers?.Authorization || '';
  const m = /^Bearer\s+(.+)$/i.exec(String(raw));
  return m ? m[1].trim() : '';
}

async function verifyFirebaseIdToken(idToken, timeoutMs = 8000) {
  if (!idToken) throw new Error('LOGIN_REQUIRED');
  const apiKey = process.env.FIREBASE_WEB_API_KEY || DEFAULT_FIREBASE_WEB_API_KEY;
  if (!apiKey) throw new Error('FIREBASE_WEB_API_KEY_MISSING');
  const ctrl = new AbortController();
  const tid = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=${encodeURIComponent(apiKey)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ idToken }),
      signal: ctrl.signal
    });
    const data = await res.json().catch(() => ({}));
    const user = data?.users?.[0];
    if (!res.ok || !user?.localId) {
      const err = new Error('INVALID_LOGIN');
      err.statusCode = 401;
      throw err;
    }
    return {
      uid: String(user.localId),
      email: user.email || null,
      displayName: user.displayName || null,
      providerUserInfo: Array.isArray(user.providerUserInfo) ? user.providerUserInfo : []
    };
  } catch (err) {
    if (err.name === 'AbortError') {
      const e = new Error('AUTH_TIMEOUT');
      e.statusCode = 504;
      throw e;
    }
    throw err;
  } finally {
    clearTimeout(tid);
  }
}

async function requireFirebaseUser(event) {
  return verifyFirebaseIdToken(bearerFromEvent(event));
}

module.exports = { bearerFromEvent, verifyFirebaseIdToken, requireFirebaseUser };
