const { createCanvas } = require('@napi-rs/canvas');
const { wrapHandler } = require('./_usage');
const { withPublicApiKey } = require('./_user-api-key');
const CORS={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Methods':'GET,OPTIONS','Access-Control-Allow-Headers':'Content-Type,X-API-Key,X-Lianix-Client,X-Lianix-User-Name'};
function json(s,b){return{statusCode:s,headers:{...CORS,'Content-Type':'application/json'},body:JSON.stringify(b)}}
function clamp(v,a,b,d){const n=Number(v);return Number.isFinite(n)?Math.max(a,Math.min(b,n)):d}
function safeColor(v,d){return /^#[0-9a-f]{6}$/i.test(String(v||''))?v:d}
async function base(event){
 if(event.httpMethod==='OPTIONS')return{statusCode:204,headers:CORS,body:''};
 if(event.httpMethod!=='GET')return json(405,{success:false,error:'Gunakan GET'});
 const q=event.queryStringParameters||{},text=String(q.text||'').trim();
 if(!text)return json(400,{success:false,error:'Parameter text wajib diisi.'});
 const width=clamp(q.width,320,1600,1024),height=clamp(q.height,180,1200,576),bg=safeColor(q.bg,'#8ACE00'),fg=safeColor(q.color,'#000000');
 const canvas=createCanvas(width,height),ctx=canvas.getContext('2d');ctx.fillStyle=bg;ctx.fillRect(0,0,width,height);ctx.fillStyle=fg;ctx.textAlign='center';ctx.textBaseline='middle';
 const words=text.split(/\s+/);let size=Math.floor(Math.min(height*.34,width*.16));ctx.font=`900 ${size}px Arial, sans-serif`;
 const lines=[];let line='';for(const w of words){const t=line?line+' '+w:w;if(ctx.measureText(t).width>width*.88&&line){lines.push(line);line=w}else line=t}if(line)lines.push(line);
 while(lines.length*size*1.02>height*.82&&size>24){size-=4;ctx.font=`900 ${size}px Arial, sans-serif`}
 const gap=size*1.02,start=height/2-gap*(lines.length-1)/2;lines.forEach((l,i)=>ctx.fillText(l,width/2,start+i*gap));
 const buf=await canvas.encode('png');return{statusCode:200,isBase64Encoded:true,headers:{...CORS,'Content-Type':'image/png','Cache-Control':'no-store','Content-Disposition':'inline; filename="brat.png"'},body:buf.toString('base64')};
}
exports.handler=withPublicApiKey(wrapHandler(base,{apiId:'brat',name:'Brat Generator'}));
