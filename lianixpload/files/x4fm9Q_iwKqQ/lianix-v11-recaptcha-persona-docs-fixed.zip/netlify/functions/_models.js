const { getRaw, putFile } = require('./_github');

const FILE = 'app-models.json';
const DEFAULTS = [
  {id:'f24nt',name:'F24nT AI',description:'Balanced · everyday tasks',endpoint:'/api/ai/overchat',method:'GET',param:'text',group:'Lianix',pro:false,enabled:true},
  {id:'f24nt-pro',name:'F24nT AI Pro',description:'Most powerful · complex tasks',endpoint:'/api/ai/overchat',method:'GET',param:'text',group:'Lianix',pro:true,enabled:true},
  {id:'f24nt-lite',name:'F24nT AI Lite',description:'Fastest · quick replies',endpoint:'/api/ai/overchat',method:'GET',param:'text',group:'Lianix',pro:false,enabled:true},
  {id:'claude',name:'Claude',description:'Reasoning & writing',endpoint:'/api/ai/claude',method:'GET',param:'text',group:'Claude',pro:true,enabled:true},
  {id:'gemini',name:'Gemini 3.1 Flash',description:'Google multimodal · image & text',endpoint:'/api/ai/gemini',method:'GET',param:'text',group:'Google',pro:true,enabled:true},
  {id:'mistral',name:'Mistral',description:'Fast general assistant',endpoint:'/api/ai/mistral',method:'GET',param:'text',group:'Other AI',pro:false,enabled:true},
  {id:'dolphin',name:'Dolphin AI',description:'Cepat, jawaban langsung',endpoint:'/api/ai/dolphin',method:'GET',param:'text',group:'Other AI',pro:false,enabled:true},
  {id:'jeeves',name:'Jeeves AI',description:'General assistant',endpoint:'/api/ai/jeevesai',method:'GET',param:'prompt',group:'Other AI',pro:false,enabled:true},
  {id:'qwen',name:'Qwen AI',description:'Qwen via Rewind',endpoint:'/api/ai/qwenai',method:'POST',param:'text',group:'Rewind',pro:false,enabled:true},
  {id:'grok',name:'Grok AI',description:'Grok via Rewind',endpoint:'/api/ai/grokai',method:'POST',param:'text',group:'Rewind',pro:true,enabled:true},
  {id:'llama',name:'Llama AI',description:'Llama via Rewind',endpoint:'/api/ai/llamaai',method:'POST',param:'text',group:'Rewind',pro:false,enabled:true},
  {id:'hackai',name:'HackAI',description:'Fallback general AI',endpoint:'/api/hackai',method:'POST',param:'text',group:'Fallback',pro:false,enabled:true}
];

function defaultSourceFor(m={}){
  const ep=JSON.stringify(String(m.endpoint||'/api/ai/overchat'));
  const method=JSON.stringify(String(m.method||'GET').toUpperCase()==='POST'?'POST':'GET');
  const param=JSON.stringify(String(m.param||'text'));
  return `// Lianix Model Adapter\n// parameter: prompt string required\n// parameter: attachments array optional\n// supports: text, files, documents, images, urls\n// Attachments are Lianix internal links. The chat UI still renders normal previews.\nmodule.exports = async function callModel(prompt, ctx) {\n  return ctx.request({\n    endpoint: ${ep},\n    method: ${method},\n    param: ${param},\n    prompt,\n    attachments: ctx.attachments\n  });\n};`;
}
function parseParameterComments(source){
  const out=[]; const text=String(source||'');
  const re=/^[ \t]*(?:\/\/|\*|#)[ \t]*(?:@?param(?:eter)?)[ \t]*[:=-]?[ \t]*([^\n\r*]+)/gim;
  let m; while((m=re.exec(text))){
    const line=String(m[1]||'').trim(); if(!line) continue;
    const parts=line.replace(/[{}\[\]]/g,' ').split(/[\s,|]+/).filter(Boolean);
    let name=''; for(const p of parts){if(/^[A-Za-z_$][\w$.-]*\??$/.test(p)&&!/^(string|number|boolean|array|object|required|optional)$/i.test(p)){name=p.replace(/\?$/,'');break}}
    if(name) out.push({name,required:/\brequired\b|\bwajib\b|\bmust\b/i.test(line),optional:/\boptional\b|\bopsional\b/i.test(line),raw:line});
  }
  return out;
}
function detectCapabilities(source, fallback={}){
  const s=String(source||''); const low=s.toLowerCase(); const params=parseParameterComments(s);
  const supportsLine=(s.match(/^[ \t]*(?:\/\/|\*)[ \t]*supports?[ \t]*[:=-][ \t]*([^\n\r*]+)/im)||[])[1]||'';
  const hay=(supportsLine+' '+params.map(x=>x.name).join(' ')+' '+low).toLowerCase();
  const has=(re)=>re.test(hay);
  const caps={
    text:true,
    images:has(/\b(image|images|imageurl|image_url|photo|foto|vision)\b/),
    documents:has(/\b(document|documents|doc|docs|pdf|txt|markdown|md)\b/),
    files:has(/\b(file|files|attachment|attachments|zip|archive|binary)\b/),
    urls:has(/\b(url|urls|link|links|uri)\b/),
    audio:has(/\b(audio|voice|mp3|wav)\b/),
    video:has(/\b(video|mp4|movie)\b/)
  };
  if(!s.trim()){
    caps.images=/gemini|vision/i.test(String(fallback.id||'')+' '+String(fallback.name||''));
    caps.documents=true; caps.files=true; caps.urls=true;
  }
  return {supports:caps,parameters:params,detectedFrom:params.length||supportsLine?'comments+source':'source'};
}
function sanitizeModel(m={}){
  const id=String(m.id||m.name||'').trim().toLowerCase().replace(/[^a-z0-9_-]+/g,'-').replace(/^-+|-+$/g,'').slice(0,60);
  const endpoint=String(m.endpoint||'').trim();
  if(!id) throw new Error('Model id wajib diisi.');
  if(!endpoint.startsWith('/api/')) throw new Error('Endpoint model wajib route lokal /api/... agar secret tidak bocor.');
  const source=String(m.source||'').trim().slice(0,50000);
  const base={id,name:String(m.name||id).trim().slice(0,80),description:String(m.description||'').trim().slice(0,180),endpoint,method:String(m.method||'GET').toUpperCase()==='POST'?'POST':'GET',param:String(m.param||'text').trim().replace(/[^a-zA-Z0-9_-]/g,'')||'text',group:String(m.group||'Other AI').trim().slice(0,50),pro:!!m.pro,enabled:m.enabled!==false,lastTest:m.lastTest||null};
  const finalSource=source||defaultSourceFor(base);
  return {...base,source:finalSource,capabilities:detectCapabilities(finalSource,base)};
}
async function loadModels(){
  try{const raw=await getRaw(FILE);const obj=JSON.parse(raw);const arr=Array.isArray(obj)?obj:obj.models;if(!Array.isArray(arr))throw new Error('models[] invalid');return arr.map(sanitizeModel);}catch(e){if(e.status===404||/404/.test(e.message))return DEFAULTS.map(sanitizeModel);console.warn('[models] fallback defaults:',e.message);return DEFAULTS.map(sanitizeModel);}
}
async function saveModels(models,message='admin: update app models'){
  const clean=models.map(sanitizeModel);await putFile(FILE,JSON.stringify({version:2,updatedAt:new Date().toISOString(),models:clean},null,2),message);return clean;
}
function adapterSource(m){return sanitizeModel(m).source}
module.exports={DEFAULTS,loadModels,saveModels,sanitizeModel,adapterSource,detectCapabilities,parseParameterComments,defaultSourceFor};
