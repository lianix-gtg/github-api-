// POST /api/payment/create
// Membuat transaksi QRIS MANUAL. Tidak memanggil payment gateway apa pun.
// Admin harus approve / reject transaksi dari Admin Panel.
const { saveTransaction, connectBlobs } = require('./_store');
const { planKey } = require('./_plan-user-key');

function orderId(){ return `LNX-${Date.now()}-${Math.random().toString(36).slice(2,7).toUpperCase()}`; }
function json(statusCode, body){ return {statusCode,headers:{'Content-Type':'application/json','Cache-Control':'no-store','Access-Control-Allow-Origin':'*','Access-Control-Allow-Methods':'POST, OPTIONS','Access-Control-Allow-Headers':'Content-Type, Authorization, X-Lianix-Email-Session'},body:JSON.stringify(body)}; }

exports.handler=async(event)=>{
  connectBlobs(event);
  if(event.httpMethod==='OPTIONS') return json(204,{});
  if(event.httpMethod!=='POST') return json(405,{success:false,error:'Method not allowed'});
  let p={}; try{p=JSON.parse(event.body||'{}')}catch{return json(400,{success:false,error:'Body JSON tidak valid.'})}
  const amount=Number(p.amount), plan=String(p.plan||'').toLowerCase(), days=Math.max(1,Math.min(3650,Number(p.days)||30)), deviceId=String(p.deviceId||'').trim();
  if(!Number.isFinite(amount)||amount<=0) return json(400,{success:false,error:"Field 'amount' wajib angka positif."});
  if(!['abyz','gokil'].includes(plan)) return json(400,{success:false,error:"Field 'plan' harus abyz atau gokil."});
  const pk=await planKey(event,deviceId);
  const id=orderId(); const now=Date.now(); const expiresAt=now+24*60*60*1000;
  const tx={order_id:id,provider:'manual_qris',amount,plan,days,deviceId,planKey:pk.key,accountUid:pk.user?.uid||null,status:'pending',created_at:new Date(now).toISOString(),updated_at:new Date(now).toISOString(),expires_at:new Date(expiresAt).toISOString(),qr_image_url:'/assets/qris-manual.jpg',reviewed:false,submitted:false};
  try{await saveTransaction(id,tx)}catch(e){return json(500,{success:false,error:'Gagal menyimpan transaksi: '+e.message})}
  return json(200,{success:true,data:{order_id:id,amount,plan,days,status:'pending',qr_image_url:'/assets/qris-manual.jpg',expires_at:tx.expires_at}});
};
