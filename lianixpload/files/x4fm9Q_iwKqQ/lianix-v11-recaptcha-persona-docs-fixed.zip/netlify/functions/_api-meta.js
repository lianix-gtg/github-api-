const parser = require('@babel/parser');
const { builtinModules } = require('node:module');
const { parseCliText, parseJSDocParams, parseParameterComments, mergeInputs } = require('./_cli-parameter-parser');

const META_RE = /\/\*\s*@lianix-meta\s*([\s\S]*?)\*\//i;
const BUILTINS = new Set(builtinModules.flatMap(x => [x, x.replace(/^node:/,'')]).map(x => x.split('/')[0]));
const DEP_VERSIONS = {
  axios:'^1.11.0', cheerio:'^1.1.2', 'crypto-js':'^4.2.0', 'tough-cookie':'^5.1.2',
  'axios-cookiejar-support':'^7.0.0', 'form-data':'^4.0.4', qs:'^6.14.0', 'node-fetch':'^3.3.2',
  got:'^15.1.0', undici:'^7.15.0', sharp:'^0.34.3', 'file-type':'^22.0.2',
  puppeteer:'^24.16.0', playwright:'^1.55.0'
};
const CJS_VERSIONS = {
  'node-fetch':'^2.7.0',
  got:'^11.8.6',
  'file-type':'^16.5.4',
  'axios-cookiejar-support':'^5.0.5'
};
const COMPANION_DEPS = {
  'axios-cookiejar-support':['axios','tough-cookie']
};
function slugify(s){return String(s||'').trim().toLowerCase().replace(/\.js$/,'').replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'')||'api'}
function parseEmbeddedMeta(code){const m=String(code||'').match(META_RE);if(!m)return null;try{return JSON.parse(m[1].trim())}catch{return null}}
function walk(node,visit,parent=null){if(!node||typeof node!=='object')return;visit(node,parent);for(const[k,v]of Object.entries(node)){if(['loc','start','end','extra','comments'].includes(k))continue;if(Array.isArray(v))v.forEach(x=>walk(x,visit,node));else if(v&&typeof v==='object'&&v.type)walk(v,visit,node)}}
function propName(n){if(!n)return'';if(n.type==='Identifier')return n.name;if(['StringLiteral','NumericLiteral'].includes(n.type))return String(n.value);return''}
function memberPath(n){if(!n)return[];if(n.type==='Identifier')return[n.name];if(['MemberExpression','OptionalMemberExpression'].includes(n.type))return[...memberPath(n.object),propName(n.property)].filter(Boolean);return[]}
function isInputPath(path){const s=path.join('.');return /^(req|request)\.(query|body|files?)(\.|$)/.test(s)||/^event\.queryStringParameters(\.|$)/.test(s)||/^event\.body(\.|$)/.test(s)}
function inputKindFromPath(path){const s=(path||[]).join('.');if(/^(req|request)\.(body|files?)(\.|$)/.test(s)||/^event\.body(\.|$)/.test(s))return'body';if(/^(req|request)\.query(\.|$)/.test(s)||/^event\.queryStringParameters(\.|$)/.test(s))return'query';return''}
function looksLikeParamGetter(path){const root=String(path?.[0]||'');return /^(searchParams|urlSearchParams|params|query|formData|form|body)$/i.test(root)}
function expressionHasInputSource(node){let found=false;walk(node,n=>{if(found)return;const p=memberPath(n);if(isInputPath(p))found=true;if(n.type==='CallExpression'&&memberPath(n.callee).join('.')==='JSON.parse'&&n.arguments?.some(a=>{const p=memberPath(a);return p.join('.')==='event.body'||p.join('.')==='req.body'||p.join('.')==='request.body'}))found=true});return found}
function inferType(name,code){
  const n=String(name||'').toLowerCase();
  if(/(?:^|[_-])(url|uri|link)(?:$|[_-])/.test(n)||/(?:url|uri|link)$/.test(n)||/^(url|uri|link)/.test(n))return'url';
  if(/folder|directory|(?:^|[_-])dir(?:$|[_-])/.test(n))return'folder';
  if(/image|img|photo|avatar|thumbnail|picture/.test(n))return'image';
  if(/audio|voice|music|song|mp3|sound/.test(n))return'audio';
  if(/video|mp4|movie|clip/.test(n))return'video';
  if(/file|document|pdf|zip|archive|attachment/.test(n))return'file';
  if(/count|width|height|size|limit|page|quality|duration|timeout|temperature|seed|amount|age|scale|ratio/.test(n))return'number';
  if(/prompt|text|message|caption|description|query/.test(n)&&/textarea/i.test(String(code)))return'textarea';
  return'text';
}
function normalizeParam(p,code){
  const name=p.name||p.key;if(!name)return null;
  const type=p.type||inferType(name,code);
  const out={name,type,required:p.required===true,placeholder:p.placeholder||'',label:p.label||name};
  const opts=p.choices||p.options;if(Array.isArray(opts))out.choices=opts;
  if(p.default!==undefined)out.default=p.default;
  if(p.conditionalRequired)out.conditionalRequired=true;
  if(p.requiredWhen&&typeof p.requiredWhen==='object')out.requiredWhen=p.requiredWhen;
  if(p.description)out.description=p.description;
  if(p.source)out.source=p.source;
  if(Array.isArray(p.aliases)&&p.aliases.length)out.aliases=p.aliases;
  if(p.accept)out.accept=p.accept;
  else if(type==='image')out.accept='image/*';else if(type==='audio')out.accept='audio/*';else if(type==='video')out.accept='video/*';else if(['file','folder'].includes(type))out.accept='*/*';
  return out;
}
function literalValue(n){if(!n)return undefined;if(['StringLiteral','NumericLiteral','BooleanLiteral'].includes(n.type))return n.value;return undefined}
function getObjectProp(obj,key){if(obj?.type!=='ObjectExpression')return null;return obj.properties.find(p=>p.type==='ObjectProperty'&&propName(p.key)===key)?.value||null}
function topPackage(d){if(!d||d.startsWith('.')||d.startsWith('node:'))return'';return d.startsWith('@')?d.split('/').slice(0,2).join('/'):d.split('/')[0]}
function dependencySpec(name,mode='esm'){return mode==='cjs'&&CJS_VERSIONS[name]?CJS_VERSIONS[name]:(DEP_VERSIONS[name]||'latest')}
function companionDependencies(name){return COMPANION_DEPS[name]||[]}

function analyzeCode(code,opts={}){
  code=String(code||'');if(!code.trim())throw new Error('Kode JS kosong.');
  const embedded=parseEmbeddedMeta(code)||{};
  // Babel only accepts a hashbang at the beginning of a file. Older Lianix metadata could be
  // written above #!/usr/bin/env node, so strip the hashbang for AST parsing while keeping
  // the original source for CLI/help/default inference.
  const astSource=code.replace(/^[\t ]*#![^\n]*(?:\n|$)/m,'\n');
  const ast=parser.parse(astSource,{sourceType:'unambiguous',errorRecovery:false,plugins:['jsx','typescript','topLevelAwait','optionalChaining','objectRestSpread','dynamicImport']});
  const params=new Map(), identifiersFromInputs=new Map(), inputAliases=new Set(), candidateArgs=new Set(), urls=new Set(), deps=new Set(), depModes=new Map();
  let handlerInputKind='', outboundMethod='', contentType='';
  const embeddedMethod=String(embedded.method||'').toUpperCase();
  const addParam=(name,required=false,type=null)=>{if(!name||['then','catch','length','map','filter','forEach','resolve','reject','next','callback','cb'].includes(name))return;const old=params.get(name)||{name,required:false,type:type||inferType(name,code)};old.required=old.required||required;if(type)old.type=type;params.set(name,old)};
  const addChoice=(name,value)=>{if(!name||value===undefined||value===null)return;addParam(name);const p=params.get(name);p.choices=p.choices||[];if(!p.choices.some(x=>String(x)===String(value)))p.choices.push(value);if(p.choices.length>=2)p.type='select'};
  const mapLocal=(local,param,type=null)=>{if(local&&param){identifiersFromInputs.set(local,param);addParam(param,false,type)}};
  const addDependency=(d,mode='esm')=>{const top=topPackage(d);if(top&&!BUILTINS.has(top)){deps.add(top);const old=depModes.get(top);depModes.set(top,old==='cjs'||mode==='cjs'?'cjs':'esm');for(const c of companionDependencies(top)){deps.add(c);if(!depModes.has(c))depModes.set(c,mode)}}};
  const mapFunctionParam=(node)=>{
    if(!node)return;
    if(node.type==='Identifier'){
      if(!/^(event|req|request|res|response|context|ctx|options|opts)$/i.test(node.name)){candidateArgs.add(node.name);mapLocal(node.name,node.name)}
    } else if(node.type==='AssignmentPattern') mapFunctionParam(node.left);
    else if(node.type==='RestElement') mapFunctionParam(node.argument);
    else if(node.type==='ObjectPattern') node.properties.forEach(pr=>{const key=propName(pr.key);if(key){candidateArgs.add(key);addParam(key);const local=propName(pr.value);if(local)identifiersFromInputs.set(local,key)}});
  };
  const mapFunctionParams=fn=>(fn?.params||[]).forEach(mapFunctionParam);

  // Exported/top-level scraper functions are valid public input sources too, not just req/event handlers.
  const fnDefs=new Map();
  for(const st of ast.program?.body||[]){
    if(st.type==='FunctionDeclaration'&&st.id?.name)fnDefs.set(st.id.name,st);
    if(st.type==='VariableDeclaration')for(const d of st.declarations||[])if(d.id?.type==='Identifier'&&['FunctionExpression','ArrowFunctionExpression'].includes(d.init?.type))fnDefs.set(d.id.name,d.init);
  }
  for(const st of ast.program?.body||[]){
    if(st.type==='ExportDefaultDeclaration'){
      if(['FunctionDeclaration','FunctionExpression','ArrowFunctionExpression'].includes(st.declaration?.type))mapFunctionParams(st.declaration);
      else if(st.declaration?.type==='Identifier'&&fnDefs.has(st.declaration.name))mapFunctionParams(fnDefs.get(st.declaration.name));
    }
    if(st.type==='ExportNamedDeclaration'){
      if(st.declaration?.type==='FunctionDeclaration')mapFunctionParams(st.declaration);
      for(const sp of st.specifiers||[])if(sp.local?.name&&fnDefs.has(sp.local.name))mapFunctionParams(fnDefs.get(sp.local.name));
    }
    if(st.type==='FunctionDeclaration'&&/(scrape|download|generate|create|search|convert|process|execute|main|handler|fetch|getdata|run)/i.test(st.id?.name||''))mapFunctionParams(st);
    if(st.type==='VariableDeclaration')for(const d of st.declarations||[])if(d.id?.type==='Identifier'&&/(scrape|download|generate|create|search|convert|process|execute|main|handler|fetch|getdata|run)/i.test(d.id.name)&&['FunctionExpression','ArrowFunctionExpression'].includes(d.init?.type))mapFunctionParams(d.init);
    const ex=st.type==='ExpressionStatement'?st.expression:null;
    if(ex?.type==='AssignmentExpression'){
      const left=memberPath(ex.left).join('.');
      if(/^(module\.exports|exports\.handler|module\.exports\.handler)$/.test(left)){
        if(['FunctionExpression','ArrowFunctionExpression'].includes(ex.right?.type))mapFunctionParams(ex.right);
        else if(ex.right?.type==='Identifier'&&fnDefs.has(ex.right.name))mapFunctionParams(fnDefs.get(ex.right.name));
        else if(ex.right?.type==='ObjectExpression') for(const pr of ex.right.properties||[]){
          const local=pr?.value?.type==='Identifier'?pr.value.name:'';
          if(local&&fnDefs.has(local)) mapFunctionParams(fnDefs.get(local));
          else if(['FunctionExpression','ArrowFunctionExpression'].includes(pr?.value?.type)) mapFunctionParams(pr.value);
        }
      } else if(/^(?:module\.exports|exports)\.[A-Za-z_$][\w$]*$/.test(left)){
        if(['FunctionExpression','ArrowFunctionExpression'].includes(ex.right?.type))mapFunctionParams(ex.right);
        else if(ex.right?.type==='Identifier'&&fnDefs.has(ex.right.name))mapFunctionParams(fnDefs.get(ex.right.name));
      }
    }
  }


  // If a pasted scraper is a single plain top-level function, its arguments are usually the public inputs.
  // This closes the common `async function foo(url, quality) { ... }` case without treating every helper as an API parameter.
  if(!candidateArgs.size){
    const withParams=[...fnDefs.values()].filter(fn=>(fn?.params||[]).length);
    if(withParams.length===1) mapFunctionParams(withParams[0]);
  }

  // Conservative text fallbacks for common handler and scraper styles.
  const destructuringRe=/(?:const|let|var)\s*\{([^}]+)\}\s*=\s*(?:(?:req|request)\.(query|body|files?)|event\.queryStringParameters|JSON\.parse\(\s*event\.body\s*\))/g;
  let dm;while((dm=destructuringRe.exec(code))){
    const src=String(dm[2]||'');if(/body|files?/.test(src)||/JSON\.parse/.test(dm[0]))handlerInputKind='body';else if(!handlerInputKind)handlerInputKind='query';
    for(const raw of dm[1].split(',')){const clean=raw.trim().replace(/^\.\.\./,'').split('=')[0].trim();if(!clean)continue;const parts=clean.split(':').map(x=>x.trim());const key=parts[0]?.replace(/[^A-Za-z0-9_$]/g,'');const local=(parts[1]||parts[0])?.replace(/[^A-Za-z0-9_$]/g,'');if(key){addParam(key);if(local)identifiersFromInputs.set(local,key)}}
  }
  const templateQueryRe=/[?&]([A-Za-z_$][\w$-]*)=\$\{\s*([A-Za-z_$][\w$]*)\s*\}/g;let qm;while((qm=templateQueryRe.exec(code))){mapLocal(qm[2],qm[1]);if(!handlerInputKind)handlerInputKind='query'}

  // Pass 1: establish aliases and direct mappings.
  walk(ast,(node)=>{
    if(node.type!=='VariableDeclarator')return;
    if(node.id?.type==='Identifier'){
      const local=node.id.name,p=memberPath(node.init);const directKind=inputKindFromPath(p);if(directKind)handlerInputKind=directKind==='body'?'body':(handlerInputKind||'query');
      if(expressionHasInputSource(node.init)){inputAliases.add(local);const raw=String(code.slice(node.init?.start||0,node.init?.end||0));if(/(?:req|request|event)\.body/.test(raw))handlerInputKind='body';else if(!handlerInputKind)handlerInputKind='query'}
      if(p.length>=3&&isInputPath(p))mapLocal(local,p[p.length-1]);
      if(p.length>=2&&inputAliases.has(p[0]))mapLocal(local,p[p.length-1]);
      if(node.init?.type==='CallExpression'){
        const callee=memberPath(node.init.callee);if(callee[callee.length-1]==='get'&&looksLikeParamGetter(callee)&&node.init.arguments?.[0]?.type==='StringLiteral')mapLocal(local,node.init.arguments[0].value);
      }
    }
    if(node.id?.type==='ObjectPattern'){
      const sourcePath=memberPath(node.init).join('.'),sourceAlias=node.init?.type==='Identifier'&&inputAliases.has(node.init.name);
      if(/^(req|request)\.(query|body|files?)$/.test(sourcePath)||/^event\.queryStringParameters$/.test(sourcePath)||sourceAlias||expressionHasInputSource(node.init)){
        if(/(?:^|\.)(?:body|files?)$/.test(sourcePath)||/(?:req|request|event)\.(?:body|files?)/.test(String(code.slice(node.init?.start||0,node.init?.end||0))))handlerInputKind='body';else if(!handlerInputKind)handlerInputKind='query';
        node.id.properties.forEach(pr=>{const key=propName(pr.key),local=propName(pr.value);if(key){addParam(key);if(local)identifiersFromInputs.set(local,key)}});
      }
    }
  });

  walk(ast,(node,parent)=>{
    if(node.type==='CallExpression'){
      if(node.callee?.type==='Identifier'&&node.callee.name==='require'&&node.arguments?.[0]?.type==='StringLiteral')addDependency(node.arguments[0].value,'cjs');
      if(memberPath(node.callee).join('.')==='require.resolve'&&node.arguments?.[0]?.type==='StringLiteral')addDependency(node.arguments[0].value,'cjs');
      if(node.callee?.type==='Import'&&node.arguments?.[0]?.type==='StringLiteral')addDependency(node.arguments[0].value,'esm');
      const cp=memberPath(node.callee),last=cp[cp.length-1];
      if(last==='get'&&looksLikeParamGetter(cp)&&node.arguments?.[0]?.type==='StringLiteral'){addParam(node.arguments[0].value);if(/^(formData|form|body)$/i.test(String(cp[0]||'')))handlerInputKind='body';else if(!handlerInputKind)handlerInputKind='query'}
      if(['single','array','fields'].includes(String(last||'').toLowerCase())){
        if(node.arguments?.[0]?.type==='StringLiteral'){const field=node.arguments[0].value;addParam(field,false,inferType(field,code));handlerInputKind='body'}
        if(node.arguments?.[0]?.type==='ArrayExpression'){for(const el of node.arguments[0].elements||[]){const n=getObjectProp(el,'name');const v=literalValue(n);if(v)addParam(v,false,inferType(v,code))}handlerInputKind='body'}
      }
      if(node.callee?.type==='Identifier'&&['parseInt','parseFloat','Number'].includes(node.callee.name)){const a=node.arguments?.[0];if(a?.type==='Identifier'&&identifiersFromInputs.has(a.name))addParam(identifiersFromInputs.get(a.name),false,'number')}
      if(node.callee?.type==='Identifier'&&node.callee.name==='encodeURIComponent'){const a=node.arguments?.[0];if(a?.type==='Identifier'&&identifiersFromInputs.has(a.name))addParam(identifiersFromInputs.get(a.name))}
      if(String(last||'').toLowerCase()==='append'&&node.arguments?.[0]?.type==='StringLiteral'){
        const field=node.arguments[0].value,a=node.arguments?.[1];if(a?.type==='Identifier'&&(identifiersFromInputs.has(a.name)||candidateArgs.has(a.name))){addParam(field,false,inferType(field,code));identifiersFromInputs.set(a.name,field);handlerInputKind='body'}
      }
      if(!outboundMethod&&['axios','got','ky','request'].includes(String(cp[0]||'').toLowerCase())&&['get','post','put','patch','delete'].includes(String(last||'').toLowerCase()))outboundMethod=String(last).toUpperCase();
      if(node.callee?.type==='Identifier'&&node.callee.name==='fetch'){const mv=getObjectProp(node.arguments?.[1],'method'),v=literalValue(mv);if(v&&!outboundMethod)outboundMethod=String(v).toUpperCase()}
      // Object payloads often reveal public scraper params: axios.post(url,{prompt,imageUrl}) / URLSearchParams({...}).
      for(const arg of node.arguments||[]){if(arg?.type==='ObjectExpression'){for(const pr of arg.properties||[]){if(pr.type!=='ObjectProperty')continue;const key=propName(pr.key),val=pr.value;if(!key)continue;if(val?.type==='Identifier'&&(candidateArgs.has(val.name)||identifiersFromInputs.has(val.name))){const publicName=identifiersFromInputs.get(val.name)||key;addParam(publicName)}}}}
    }
    if(node.type==='ImportDeclaration')addDependency(node.source?.value,'esm');
    if(['MemberExpression','OptionalMemberExpression'].includes(node.type)){
      const p=memberPath(node);if(isInputPath(p)){const k=inputKindFromPath(p);if(k==='body')handlerInputKind='body';else if(k==='query'&&!handlerInputKind)handlerInputKind='query';if(p.length>=3)addParam(p[p.length-1])}if(p.length>=2&&inputAliases.has(p[0]))addParam(p[p.length-1]);
      if(p.length===2&&/^(params|query)$/i.test(p[0])){addParam(p[1]);if(!handlerInputKind)handlerInputKind='query'}
    }
    if(node.type==='TemplateLiteral')for(const ex of node.expressions||[]){if(ex?.type==='Identifier'&&identifiersFromInputs.has(ex.name))addParam(identifiersFromInputs.get(ex.name))}
    if(node.type==='NewExpression'&&node.callee?.type==='Identifier'&&node.callee.name==='URL'){const a=node.arguments?.[0];if(a?.type==='Identifier'&&identifiersFromInputs.has(a.name))addParam(identifiersFromInputs.get(a.name),false,'url')}
    if(node.type==='CallExpression'&&['startsWith','includes','match','test'].includes(String(memberPath(node.callee).slice(-1)[0]||''))){const obj=node.callee?.object;if(obj?.type==='Identifier'&&identifiersFromInputs.has(obj.name)){const a=node.arguments?.[0],v=literalValue(a);if(typeof v==='string'&&/^https?:|url|link/i.test(v))addParam(identifiersFromInputs.get(obj.name),false,'url')}}
    if(node.type==='BinaryExpression'&&['==','==='].includes(node.operator)){for(const[candidate,lit]of[[node.left,node.right],[node.right,node.left]])if(candidate?.type==='Identifier'&&identifiersFromInputs.has(candidate.name)){const v=literalValue(lit);if(typeof v==='string'||typeof v==='number')addChoice(identifiersFromInputs.get(candidate.name),v)}}
    if(node.type==='IfStatement')walk(node.test,n=>{
      if(n.type==='UnaryExpression'&&n.operator==='!'){const a=n.argument;if(a.type==='Identifier'&&identifiersFromInputs.has(a.name))addParam(identifiersFromInputs.get(a.name),true);const p=memberPath(a);if(p.length&&(isInputPath(p)||inputAliases.has(p[0])||/^(params|query)$/i.test(p[0])))addParam(p[p.length-1],true)}
      if(n.type==='BinaryExpression'&&['==','===','!=','!=='].includes(n.operator)){const nullish=x=>x?.type==='NullLiteral'||(x?.type==='Identifier'&&x.name==='undefined');const target=nullish(n.left)?n.right:nullish(n.right)?n.left:null;if(target?.type==='Identifier'&&identifiersFromInputs.has(target.name))addParam(identifiersFromInputs.get(target.name),true)}
    });
    if(['StringLiteral','TemplateElement'].includes(node.type)){const v=node.type==='StringLiteral'?node.value:node.value?.raw;if(/^https?:\/\//i.test(v||''))urls.add(v);if(/image\//i.test(v||''))contentType='image';else if(/video\//i.test(v||''))contentType='video';else if(/audio\//i.test(v||''))contentType='audio';else if(/application\/(pdf|zip|octet-stream)/i.test(v||''))contentType='file';if(!outboundMethod&&/^(GET|POST|PUT|PATCH|DELETE)$/i.test(v||''))outboundMethod=String(v).toUpperCase()}
  });

  // Required checks and common textual access patterns.
  for(const [name,p] of params){const q=String(name).replace(/[.*+?^${}()|[\]\\]/g,'\\$&');if(new RegExp(`if\\s*\\(\\s*!\\s*${q}\\b`).test(code)||new RegExp(`${q}\\s*(?:===|==)\\s*(?:null|undefined)`).test(code)||new RegExp(`(?:required|wajib|missing)[^\\n]{0,40}\\b${q}\\b`,'i').test(code))p.required=true}
  const directAccess=/(?:req|request)\.(?:query|body|files?)\.([A-Za-z_$][\w$]*)|event\.queryStringParameters\.([A-Za-z_$][\w$]*)|(?:searchParams|urlSearchParams|params|query)\.get\(\s*['"]([^'"]+)['"]\s*\)/g;let da;while((da=directAccess.exec(code)))addParam(da[1]||da[2]||da[3]);
  // Lexical fallback for real-world scrapers that AST heuristics cannot classify cleanly.
  // This intentionally runs even when AST found zero inputs, and only promotes identifiers
  // that are visibly used as external input / CLI / URL payload fields.
  const destructRe=/(?:const|let|var)\s*\{([^}]{1,500})\}\s*=\s*(?:req|request)\.(?:query|body)|(?:event\.queryStringParameters)|(?:JSON\.parse\(\s*event\.body\s*\))/g;let dm2;
  while((dm2=destructRe.exec(code))){for(const raw of dm2[1].split(',')){const part=raw.trim();if(!part)continue;const left=part.split(':')[0].split('=')[0].trim();if(/^[A-Za-z_$][\w$]*$/.test(left)){addParam(left);if(/req|body|event\.body/i.test(dm2[0]))handlerInputKind='body';else if(!handlerInputKind)handlerInputKind='query'}}}
  const funcRe=/(?:async\s+)?function\s+(?:scrape|generate|create|download|convert|search|fetch\w*|netfgen|brat\w*|main|run)\s*\(([^)]*)\)|(?:const|let|var)\s+(?:scrape\w*|generate\w*|netfgen|brat\w*|main|run)\s*=\s*(?:async\s*)?\(([^)]*)\)\s*=>/gi;let fm;
  while((fm=funcRe.exec(code))){for(const raw of String(fm[1]||fm[2]||'').split(',')){let n=raw.trim().replace(/^\.\.\./,'').split('=')[0].trim();if(/^[A-Za-z_$][\w$]*$/.test(n)&&!/^(req|res|event|context|ctx|options|opts)$/i.test(n))addParam(n)}}
  const argvValueRe=/(?:process\.argv|args|argv)[^\n]{0,180}(?:--([a-z][\w-]*)|-([a-z]))/gi;let av;while((av=argvValueRe.exec(code))){const n=av[1]||av[2];if(n)addParam(n.replace(/-([a-z])/g,(_,c)=>c.toUpperCase()))}
  // Infer optionals/defaults from common `x || default`, `x ?? default`, destructuring defaults.
  for(const [name,p] of params){const q=String(name).replace(/[.*+?^${}()|[\]\\]/g,'\\$&');const m=code.match(new RegExp(`\\b${q}\\b\\s*(?:\\|\\||\\?\\?)\\s*(['\"]([^'\"]+)['\"]|(-?\\d+(?:\\.\\d+)?))`));if(m){p.required=false;p.default=m[2]!==undefined?m[2]:Number(m[3])}const md=code.match(new RegExp(`\\b${q}\\s*=\\s*(['\"]([^'\"]+)['\"]|(-?\\d+(?:\\.\\d+)?))`));if(md&&p.default===undefined){p.required=false;p.default=md[2]!==undefined?md[2]:Number(md[3])}}

  const filename=opts.filename||'api.js',id=embedded.id||slugify(filename),endpoint=embedded.endpoint||embedded.path||opts.endpoint||`/api/${id}`;
  const astInputs=[...params.values()].map(p=>normalizeParam({...p,source:'ast'},code)).filter(Boolean);
  const jsdocInputs=parseJSDocParams(code).map(p=>normalizeParam(p,code)).filter(Boolean);
  const commentInputs=parseParameterComments(code).map(p=>normalizeParam(p,code)).filter(Boolean);
  const cliInputs=parseCliText(code).map(p=>normalizeParam(p,code)).filter(Boolean);
  const embeddedInputs=Array.isArray(embedded.inputs)?embedded.inputs.map(p=>normalizeParam({...p,source:'embedded'},code)).filter(Boolean):[];
  const detectedInputs=mergeInputs(astInputs,cliInputs,jsdocInputs,commentInputs);
  // Embedded metadata is authoritative only when it still resembles the code. Old generated
  // metadata sometimes collapsed a whole CLI usage fragment (e.g. `auto -n <jumlah>`) into
  // one fake field. If CLI/AST found a richer schema, discard that stale field instead of
  // showing it alongside the real parameters.
  const embeddedLooksStale = embeddedInputs.length && detectedInputs.length >= 2 && (
    embeddedInputs.some(p=>/[<>\s]/.test(String(p.name||'')) || /^-/.test(String(p.name||''))) ||
    (embeddedInputs.length <= 1 && !embeddedInputs.some(e=>detectedInputs.some(d=>d.name===e.name)))
  );
  let inputs=embeddedInputs.length&&!embeddedLooksStale?mergeInputs(detectedInputs,embeddedInputs):detectedInputs;
  // Netfgen is a CLI scraper. For the web/API form we can safely default its command to
  // `auto`; every tuning option has a built-in fallback in the source. Cookie remains only
  // conditionally required for convert/check.
  if(id==='netfgen'){
    inputs=inputs.filter(p=>p.name!=='auto -n <jumlah>');
    let command=inputs.find(p=>p.name==='command');
    if(!command){command={name:'command',type:'select',required:false,choices:['test','stats','auto','convert','check'],default:'auto',source:'compat'};inputs.unshift(command)}
    else {command.required=false;command.default='auto';command.type='select';command.choices=[...new Set([...(command.choices||[]),'test','stats','auto','convert','check'])]}
    const defaults={count:5,out:'tokens.txt',conc:25,scanConcurrency:25};
    for(const p of inputs){
      if(p.name!=='cookie')p.required=false;
      if(Object.prototype.hasOwnProperty.call(defaults,p.name)&&p.default===undefined)p.default=defaults[p.name];
      if(p.name==='plan'){p.type='select';p.choices=['premium','standard','basic'];if(p.default!==undefined&&!p.choices.includes(p.default))delete p.default}
      if(p.name==='proxyFile'){p.type='file';p.accept='*/*'}
      if(p.name==='count'||p.name==='conc'||p.name==='scanConcurrency')p.type='number';
    }
    let cookie=inputs.find(p=>p.name==='cookie');
    if(cookie){cookie.required=false;cookie.conditionalRequired=true;cookie.requiredWhen={command:['convert','check']}}
  }
  const outputs=Array.isArray(embedded.outputs)&&embedded.outputs.length?embedded.outputs:[{type:contentType||'json',label:'Result'}];
  const method=embeddedMethod||(handlerInputKind==='body'?'POST':handlerInputKind==='query'?'GET':'')||String(opts.method||'').toUpperCase()||outboundMethod||'GET';
  const allDeps=[...new Set([...(Array.isArray(embedded.dependencies)?embedded.dependencies:[]),...deps])];
  for(const d of allDeps) if(!depModes.has(d)) depModes.set(d,'esm');
  const confidence=embeddedInputs.length?100:Math.min(98,52+inputs.length*6+(handlerInputKind?8:0)+(urls.size?3:0)+(inputAliases.size?3:0)+(candidateArgs.size?3:0)+(jsdocInputs.length?10:0)+(commentInputs.length?8:0)+(cliInputs.length?8:0));
  return{id,name:embedded.name||opts.name||filename.replace(/\.js$/i,'').replace(/[-_]/g,' ').replace(/\b\w/g,c=>c.toUpperCase()),description:embedded.description||embedded.desc||opts.description||'',method,endpoint,category:embedded.category||opts.category||'tools',inputs,outputs,tags:Array.isArray(embedded.tags)?embedded.tags:[],dependencies:allDeps,dependencyModes:Object.fromEntries(allDeps.map(d=>[d,depModes.get(d)||'esm'])),dependencyVersions:Object.fromEntries(allDeps.map(d=>[d,dependencySpec(d,depModes.get(d)||'esm')])),installCommand:allDeps.length?`npm install ${allDeps.map(d=>`${d}@${dependencySpec(d,depModes.get(d)||'esm')}`).join(' ')}`:'',externalUrls:[...urls].slice(0,20),confidence,syntaxValid:true};
}
function buildMetaBlock(meta){const clean={id:meta.id,name:meta.name,description:meta.description||'',method:String(meta.method||'GET').toUpperCase(),endpoint:meta.endpoint,category:meta.category,inputs:Array.isArray(meta.inputs)?meta.inputs.map(p=>({name:p.name,type:p.type||'text',required:p.required===true,...(p.default!==undefined?{default:p.default}:{}),...(p.conditionalRequired?{conditionalRequired:true}:{}),...(p.requiredWhen?{requiredWhen:p.requiredWhen}:{}),...(Array.isArray(p.choices)&&p.choices.length?{choices:p.choices}:{}),...(p.placeholder?{placeholder:p.placeholder}:{}),...(p.description?{description:p.description}:{}),...(p.accept?{accept:p.accept}:{})})):[],outputs:Array.isArray(meta.outputs)?meta.outputs:[{type:'json',label:'Result'}],tags:Array.isArray(meta.tags)?meta.tags:[],dependencies:Array.isArray(meta.dependencies)?meta.dependencies:[]};return`/* @lianix-meta\n${JSON.stringify(clean,null,2)}\n*/`}
module.exports={analyzeCode,parseEmbeddedMeta,buildMetaBlock,slugify,dependencySpec,companionDependencies};
