const { verifyAdminToken } = require('./_admin-auth');
const { OWNER, REPO, BRANCH, getJson, getRaw, putFile, putBase64File, deleteFile } = require('./_github');
const CORS={
  'Content-Type':'application/json',
  'Access-Control-Allow-Origin':'*',
  'Access-Control-Allow-Methods':'GET,POST,OPTIONS',
  'Access-Control-Allow-Headers':'Content-Type, Authorization',
  'Cache-Control':'no-store'
};
const out=(statusCode,body)=>({statusCode,headers:CORS,body:JSON.stringify(body)});
function cleanPath(v,{allowRoot=true}={}){
  let p=String(v||'').replace(/\\/g,'/').replace(/^\/+|\/+$/g,'');
  if(!p && allowRoot)return '';
  if(!p)throw new Error('Path wajib diisi.');
  const parts=p.split('/');
  if(parts.some(x=>!x||x==='.'||x==='..'))throw new Error('Path tidak valid.');
  if(parts[0]==='.git')throw new Error('Folder .git tidak dapat dikelola.');
  return parts.join('/');
}
async function listRecursive(path,acc=[],depth=0){
  if(depth>8)throw new Error('Folder terlalu dalam.');
  const data=await getJson(path);
  if(!Array.isArray(data)){acc.push({path:data.path||path,type:'file',sha:data.sha});return acc;}
  for(const item of data){
    if(acc.length>=100)throw new Error('Delete folder dibatasi maksimal 100 file per operasi.');
    if(item.type==='dir')await listRecursive(item.path,acc,depth+1);
    else if(item.type==='file')acc.push({path:item.path,type:'file',sha:item.sha});
  }
  return acc;
}
exports.handler=async(event)=>{
  if(event.httpMethod==='OPTIONS')return{statusCode:204,headers:CORS,body:''};
  if(!await verifyAdminToken(event))return out(401,{success:false,error:'Tidak terautentikasi.'});
  try{
    if(event.httpMethod==='GET'){
      const path=cleanPath(event.queryStringParameters?.path||'',{allowRoot:true});
      const data=await getJson(path);
      if(Array.isArray(data)){
        const items=data.map(x=>({name:x.name,path:x.path,type:x.type,size:x.size||0,sha:x.sha||'',downloadUrl:x.download_url||null})).sort((a,b)=>a.type===b.type?a.name.localeCompare(b.name):(a.type==='dir'?-1:1));
        return out(200,{success:true,data:{type:'dir',path,items,repository:{owner:OWNER,repo:REPO,branch:BRANCH}}});
      }
      if(data?.type==='file'){
        const content=await getRaw(path);
        return out(200,{success:true,data:{type:'file',path,name:data.name,size:data.size||0,sha:data.sha||'',content,repository:{owner:OWNER,repo:REPO,branch:BRANCH}}});
      }
      return out(404,{success:false,error:'Path tidak ditemukan.'});
    }
    if(event.httpMethod!=='POST')return out(405,{success:false,error:'Method not allowed'});
    const p=JSON.parse(event.body||'{}');
    const action=String(p.action||'').toLowerCase();
    if(action==='mkdir'){
      const path=cleanPath(p.path,{allowRoot:false});
      const result=await putFile(`${path}/.gitkeep`,'',p.message||`admin: create folder ${path}`);
      return out(200,{success:true,data:{action,path,commit:result.commit?.sha||null}});
    }
    if(action==='save'){
      const path=cleanPath(p.path,{allowRoot:false});
      const content=String(p.content??'');
      if(Buffer.byteLength(content,'utf8')>2*1024*1024)throw new Error('Editor dibatasi 2 MB per file.');
      const result=await putFile(path,content,p.message||`admin: save ${path}`);
      return out(200,{success:true,data:{action,path,commit:result.commit?.sha||null,htmlUrl:result.content?.html_url||null}});
    }
    if(action==='upload'){
      const path=cleanPath(p.path,{allowRoot:false});
      const b64=String(p.contentBase64||'').replace(/^data:[^,]+,/, '').replace(/\s+/g,'');
      const bytes=Math.floor(b64.length*3/4);
      if(!b64)throw new Error('File upload kosong.');
      if(bytes>3*1024*1024)throw new Error('Upload GitHub dari Admin dibatasi 3 MB per file.');
      const result=await putBase64File(path,b64,p.message||`admin: upload ${path}`);
      return out(200,{success:true,data:{action,path,commit:result.commit?.sha||null,htmlUrl:result.content?.html_url||null}});
    }
    if(action==='delete'){
      const path=cleanPath(p.path,{allowRoot:false});
      const info=await getJson(path);
      if(Array.isArray(info)){
        const files=await listRecursive(path);
        // GitHub Contents create/update/delete operations are intentionally serialized.
        for(const f of files)await deleteFile(f.path,p.message||`admin: delete ${path}`);
        return out(200,{success:true,data:{action,path,deleted:files.length}});
      }
      await deleteFile(path,p.message||`admin: delete ${path}`);
      return out(200,{success:true,data:{action,path,deleted:1}});
    }
    if(action==='move'){
      const from=cleanPath(p.from,{allowRoot:false}), to=cleanPath(p.to,{allowRoot:false});
      const info=await getJson(from);
      if(Array.isArray(info))throw new Error('Move folder belum didukung; pindahkan file satu per satu.');
      const content=await getRaw(from);
      await putFile(to,content,p.message||`admin: move ${from} -> ${to}`);
      await deleteFile(from,p.message||`admin: remove old ${from}`);
      return out(200,{success:true,data:{action,from,to}});
    }
    return out(400,{success:false,error:'Action harus mkdir, save, upload, delete, atau move.'});
  }catch(e){
    const code=e.status===404?404:e.status===409?409:400;
    return out(code,{success:false,error:e.message||String(e)});
  }
};
