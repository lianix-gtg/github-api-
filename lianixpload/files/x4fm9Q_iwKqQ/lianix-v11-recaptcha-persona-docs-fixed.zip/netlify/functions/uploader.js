// netlify/functions/uploader.js
// Proxy upload ke 4 layanan hosting file: Catbox, Kappa.lol, Uguu.se, Upload.ee.
// Client kirim multipart/form-data dengan field "file", pilih layanan lewat query ?service=1..4
// Semua pakai native fetch + FormData (Node 18+ di Netlify), tidak perlu dependency tambahan.

const UA = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36";

function json(statusCode, cors, body) {
  return { statusCode, headers: { ...cors, "Content-Type": "application/json" }, body: JSON.stringify(body) };
}

// Parse multipart/form-data secara manual (tanpa lib eksternal) untuk ambil 1 file field "file".
function parseMultipart(bodyBuffer, contentType) {
  const boundaryMatch = /boundary=(?:"([^"]+)"|([^;]+))/i.exec(contentType || "");
  const boundary = boundaryMatch ? (boundaryMatch[1] || boundaryMatch[2]) : null;
  if (!boundary) throw new Error("Boundary tidak ditemukan di Content-Type");
  const boundaryBuf = Buffer.from("--" + boundary);
  const parts = [];
  let start = bodyBuffer.indexOf(boundaryBuf);
  while (start !== -1) {
    const next = bodyBuffer.indexOf(boundaryBuf, start + boundaryBuf.length);
    if (next === -1) break;
    const partBuf = bodyBuffer.slice(start + boundaryBuf.length, next);
    parts.push(partBuf);
    start = next;
  }
  for (const part of parts) {
    const headerEnd = part.indexOf("\r\n\r\n");
    if (headerEnd === -1) continue;
    const headerStr = part.slice(0, headerEnd).toString("utf-8");
    if (!/name="file"/i.test(headerStr)) continue;
    let content = part.slice(headerEnd + 4);
    // Buang trailing \r\n sebelum boundary berikutnya
    if (content.slice(-2).toString() === "\r\n") content = content.slice(0, -2);
    const filenameMatch = /filename="([^"]*)"/i.exec(headerStr);
    const ctMatch = /Content-Type:\s*([^\r\n]+)/i.exec(headerStr);
    return {
      filename: filenameMatch ? filenameMatch[1] : "file",
      contentType: ctMatch ? ctMatch[1].trim() : "application/octet-stream",
      buffer: content
    };
  }
  throw new Error('Field file tidak ditemukan di form-data (pastikan nama field "file")');
}

async function uploadCatbox(file) {
  const form = new FormData();
  form.append("reqtype", "fileupload");
  form.append("fileToUpload", new Blob([file.buffer], { type: file.contentType }), file.filename);
  const res = await fetch("https://catbox.moe/user/api.php", {
    method: "POST",
    body: form,
    headers: { "User-Agent": UA, Accept: "*/*" }
  });
  const text = await res.text();
  const url = text.startsWith("https://") ? text.trim() : null;
  return { status: res.status === 200 && !!url, code: res.status, url, raw: url ? undefined : text.slice(0, 300) };
}

async function uploadKappa(file) {
  const form = new FormData();
  form.append("file", new Blob([file.buffer], { type: file.contentType }), file.filename);
  const res = await fetch("https://kappa.lol/api/upload", {
    method: "POST",
    body: form,
    headers: { "User-Agent": UA, Accept: "*/*", Origin: "https://kappa.lol", Referer: "https://kappa.lol/" }
  });
  const text = await res.text();
  let data; try { data = JSON.parse(text); } catch (_) { data = null; }
  const url = data?.link || null;
  return { status: !!url, code: res.status, url, raw: url ? undefined : text.slice(0, 300) };
}

async function uploadUguu(file) {
  const form = new FormData();
  form.append("files[]", new Blob([file.buffer], { type: file.contentType }), file.filename);
  const res = await fetch("https://uguu.se/upload.php", {
    method: "POST",
    body: form,
    headers: {
      "User-Agent": UA,
      Accept: "*/*",
      Origin: "https://uguu.se",
      Referer: "https://uguu.se/"
    }
  });
  const text = await res.text();
  let data; try { data = JSON.parse(text); } catch (_) { data = null; }
  const url = data?.files?.[0]?.url || null;
  return { status: res.status === 200 && data?.success === true && !!url, code: res.status, url, raw: url ? undefined : text.slice(0, 300) };
}

function decodeHtml(t = "") {
  return t.replaceAll("&amp;", "&").replaceAll("&quot;", '"').replaceAll("&#039;", "'").replaceAll("&lt;", "<").replaceAll("&gt;", ">");
}

function extractCookies(setCookieHeaders) {
  // Netlify/Node fetch bisa gabungkan banyak Set-Cookie jadi satu string dipisah koma di beberapa runtime;
  // ambil pasangan nama=nilai sebelum ";" pertama pada tiap potongan.
  if (!setCookieHeaders) return "";
  const parts = Array.isArray(setCookieHeaders) ? setCookieHeaders : [setCookieHeaders];
  return parts.map(c => c.split(";")[0]).join("; ");
}

async function uploadUploadEe(file) {
  const BASE = "https://www.upload.ee";
  const commonHeaders = {
    "User-Agent": UA,
    Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8"
  };

  const homeRes = await fetch(`${BASE}/?`, { headers: { ...commonHeaders, Referer: BASE } });
  const cookies = extractCookies(homeRes.headers.get("set-cookie"));

  const rnd = Date.now();
  const idRes = await fetch(`${BASE}/ubr_link_upload.php?rnd_id=${rnd}`, {
    headers: { ...commonHeaders, Accept: "*/*", Referer: `${BASE}/?`, Cookie: cookies }
  });
  const idBody = await idRes.text();
  const idMatch = idBody.match(/startUpload\("([^"]+)"/);
  if (!idMatch) throw new Error("Upload ID tidak ditemukan dari upload.ee");
  const uploadId = idMatch[1];

  const isImage = /^image\//.test(file.contentType);
  const form = new FormData();
  form.append("upfile_0", new Blob([file.buffer], { type: file.contentType }), file.filename);
  form.append("link", "");
  form.append("email", "");
  form.append("category", isImage ? "cat_picture" : "cat_file");
  form.append("big_resize", "none");
  form.append("small_resize", "120x90");

  const uploadUrl = `${BASE}/cgi-bin/ubr_upload.pl?X-Progress-ID=${uploadId}&upload_id=${uploadId}`;
  await fetch(uploadUrl, {
    method: "POST",
    body: form,
    headers: { ...commonHeaders, Origin: BASE, Referer: `${BASE}/?`, Cookie: cookies }
  });

  const finishedUrl = `${BASE}/?page=finished&upload_id=${uploadId}`;
  const finishedRes = await fetch(finishedUrl, { headers: { ...commonHeaders, Referer: uploadUrl, Cookie: cookies } });
  const finishedHtml = await finishedRes.text();

  const fileSrcMatch = finishedHtml.match(/id=["']file_src["'][^>]*value=["']([^"']+)["']/i);
  const viewMatch = finishedHtml.match(/View file:\s*<br\s*\/?>\s*<a href=["']?([^"'>\s]+)["']?/i);
  const rawUrl = fileSrcMatch?.[1] || viewMatch?.[1] || null;
  const viewUrl = rawUrl ? decodeHtml(rawUrl) : null;
  if (!viewUrl) throw new Error("View file URL tidak ditemukan dari upload.ee");

  let resultUrl = null;
  if (isImage) {
    resultUrl = decodeHtml(viewUrl).replace("/files/", "/image/").replace(/\.html$/, "");
  } else {
    const filePageRes = await fetch(viewUrl, { headers: { ...commonHeaders, Referer: finishedUrl, Cookie: cookies } });
    const fileHtml = await filePageRes.text();
    const dlMatch = fileHtml.match(/<a[^>]+id=["']d_l["'][^>]+href=["']([^"']+)["']/i);
    resultUrl = dlMatch ? decodeHtml(dlMatch[1]) : viewUrl;
  }

  return { status: !!resultUrl, code: finishedRes.status, url: resultUrl };
}

const SERVICES = {
  1: { name: "Catbox", fn: uploadCatbox },
  2: { name: "Kappa.lol", fn: uploadKappa },
  3: { name: "Uguu.se", fn: uploadUguu },
  4: { name: "Upload.ee", fn: uploadUploadEe }
};

exports.handler = async (event) => {
  const cors = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type"
  };
  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers: cors, body: "" };
  if (event.httpMethod !== "POST") return json(405, cors, { error: "Gunakan metode POST dengan multipart/form-data" });

  const qs = event.queryStringParameters || {};
  const service = SERVICES[qs.service];
  if (!service) {
    return json(400, cors, { error: "Parameter ?service= wajib diisi 1 (Catbox), 2 (Kappa.lol), 3 (Uguu.se), atau 4 (Upload.ee)" });
  }

  try {
    const contentType = event.headers["content-type"] || event.headers["Content-Type"];
    const bodyBuffer = event.isBase64Encoded ? Buffer.from(event.body, "base64") : Buffer.from(event.body, "utf-8");
    const file = parseMultipart(bodyBuffer, contentType);

    const result = await service.fn(file);
    return json(result.status ? 200 : 502, cors, {
      status: result.status,
      service: service.name,
      code: result.code,
      filename: file.filename,
      url: result.url,
      error: result.status ? undefined : (result.raw || "Upload gagal, coba lagi atau pilih layanan lain.")
    });
  } catch (err) {
    return json(500, cors, { status: false, service: service.name, error: err.message });
  }
};


// LIANIX_USAGE_WRAPPER_V7
const { wrapHandler: __wrapLianixUsage } = require('./_usage');
exports.handler = __wrapLianixUsage(exports.handler, { apiId: 'uploader', name: 'uploader' });

// Lianix per-user public API key guard
const { withPublicApiKey } = require('./_user-api-key');
exports.handler = withPublicApiKey(exports.handler);
