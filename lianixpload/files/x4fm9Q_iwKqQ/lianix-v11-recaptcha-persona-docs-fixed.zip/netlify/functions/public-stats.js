const { makeStore, connectBlobs } = require('./_store');
const CORS={'Content-Type':'application/json','Access-Control-Allow-Origin':'*','Cache-Control':'no-store'};
const out=(s,b)=>({statusCode:s,headers:CORS,body:JSON.stringify(b)});
function day(n=0){return new Date(Date.now()-n*86400000).toISOString().slice(0,10)}
function maskUser(id){id=String(id||'anon');if(id==='public')return'Public';return id.length<=8?id.slice(0,3)+'•••':id.slice(0,4)+'••••'+id.slice(-3)}
async function mapLimit(items,limit,fn){let i=0,r=new Array(items.length);async function w(){for(;;){let n=i++;if(n>=items.length)return;try{r[n]=await fn(items[n])}catch{r[n]=null}}}await Promise.all(Array.from({length:Math.min(limit,items.length||1)},w));return r}
exports.handler=async(event)=>{
 connectBlobs(event);if(event.httpMethod==='OPTIONS')return{statusCode:204,headers:CORS,body:''};if(event.httpMethod!=='GET')return out(405,{success:false});
 try{
  const usage=makeStore('f24nt-api-usage'), users=makeStore('f24nt-user-usage'), health=makeStore('f24nt-api-health');
  const apiMap={},userMap={};let total=0,ok=0,err=0;
  for(const d of [day(0),day(1),day(2),day(3),day(4),day(5),day(6)]){
    const {blobs=[]}=await usage.list({prefix:d+'/'});for(const b of blobs){const p=String(b.key).split('/');if(p.length<6)continue;const id=p[1],good=p[2]==='1',lat=Number(p[4])||0;const x=apiMap[id]||(apiMap[id]={apiId:id,count:0,success:0,error:0,totalLatency:0});x.count++;good?x.success++:x.error++;x.totalLatency+=lat;total++;good?ok++:err++;}
    const {blobs:ub=[]}=await users.list({prefix:d+'/'});for(const b of ub){const p=String(b.key).split('/');if(p.length<4)continue;const u=p[1];userMap[u]=(userMap[u]||0)+1;}
  }
  let healthItems=[];try{const {blobs=[]}=await health.list();const rows=await mapLimit(blobs.slice(0,300),20,b=>health.get(b.key,{type:'json'}));healthItems=rows.filter(Boolean).map(h=>({apiId:h.apiId,name:h.name||h.apiId,status:h.status||'unknown',latency:Number(h.latency)||0,checkedAt:h.checkedAt||h.at||0,httpStatus:h.httpStatus||0}));}catch{}
  const healthNames=new Map(healthItems.map(h=>[h.apiId,h.name]));
  const apis=Object.values(apiMap).map(x=>({...x,name:healthNames.get(x.apiId)||x.apiId,avgLatency:x.count?Math.round(x.totalLatency/x.count):0,successRate:x.count?Math.round(x.success/x.count*1000)/10:0})).sort((a,b)=>b.count-a.count);
  const leaderboard=Object.entries(userMap).map(([id,count])=>({id:maskUser(id),count})).sort((a,b)=>b.count-a.count).slice(0,10);
  return out(200,{success:true,updatedAt:Date.now(),summary:{total,success:ok,error:err,successRate:total?Math.round(ok/total*1000)/10:0,online:healthItems.filter(x=>String(x.status).toLowerCase()==='online').length,offline:healthItems.filter(x=>String(x.status).toLowerCase()==='error').length},apis:apis.slice(0,12),users:leaderboard,health:healthItems.slice(0,80)});
 }catch(e){return out(200,{success:false,error:e.message,summary:{total:0,success:0,error:0,successRate:0,online:0,offline:0},apis:[],users:[],health:[]})}
};
