// netlify/functions/removewm.js
// Remove Watermark dari gambar lewat ezremove.ai. Client kirim multipart/form-data field "image".
// Alur: create-job (upload langsung sebagai multipart) -> poll get-job.

function json(statusCode, cors, body) {
  return { statusCode, headers: { ...cors, "Content-Type": "application/json" }, body: JSON.stringify(body) };
}

const ORIGIN = "https://ezremove.ai";
const UA = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36";

function extToMime(filename) {
  const ext = (filename.split(".").pop() || "").toLowerCase();
  if (ext === "png") return "image/png";
  if (ext === "webp") return "image/webp";
  if (ext === "jpg" || ext === "jpeg") return "image/jpeg";
  return "application/octet-stream";
}
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

function parseMultipart(bodyBuffer, contentType, fieldName) {
  const boundaryMatch = /boundary=(?:"([^"]+)"|([^;]+))/i.exec(contentType || "");
  const boundary = boundaryMatch ? (boundaryMatch[1] || boundaryMatch[2]) : null;
  if (!boundary) throw new Error("Boundary tidak ditemukan di Content-Type");
  const boundaryBuf = Buffer.from("--" + boundary);
  const parts = [];
  let start = bodyBuffer.indexOf(boundaryBuf);
  while (start !== -1) {
    const next = bodyBuffer.indexOf(boundaryBuf, start + boundaryBuf.length);
    if (next === -1) break;
    parts.push(bodyBuffer.slice(start + boundaryBuf.length, next));
    start = next;
  }
  for (const part of parts) {
    const headerEnd = part.indexOf("\r\n\r\n");
    if (headerEnd === -1) continue;
    const headerStr = part.slice(0, headerEnd).toString("utf-8");
    if (!new RegExp(`name="${fieldName}"`, "i").test(headerStr)) continue;
    let content = part.slice(headerEnd + 4);
    if (content.slice(-2).toString() === "\r\n") content = content.slice(0, -2);
    const filenameMatch = /filename="([^"]*)"/i.exec(headerStr);
    return { filename: filenameMatch ? filenameMatch[1] : "image.jpg", buffer: content };
  }
  throw new Error(`Field "${fieldName}" tidak ditemukan di form-data`);
}

async function removeWatermark(filename, buffer) {
  const mime = extToMime(filename);
  const boundary = `----FormBoundary${Math.random().toString(36).slice(2)}`;
  const body = Buffer.concat([
    Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="image_file"; filename="${filename}"\r\nContent-Type: ${mime}\r\n\r\n`),
    buffer,
    Buffer.from(`\r\n--${boundary}--\r\n`)
  ]);

  const create = await fetch("https://api.ezremove.ai/api/ez-remove/watermark-remove/create-job", {
    method: "POST",
    body,
    headers: {
      "User-Agent": UA,
      "Accept": "application/json, text/plain, */*",
      "Origin": ORIGIN,
      "Referer": `${ORIGIN}/`,
      "product-serial": `sr-${Date.now()}`,
      "Content-Type": `multipart/form-data; boundary=${boundary}`
    }
  });

  if (!create.ok) throw new Error(`Create job gagal HTTP ${create.status}`);
  const createData = await create.json().catch(() => null);
  const jobId = createData?.result?.job_id;
  if (!jobId) throw new Error(`Server tidak mengembalikan job_id: ${JSON.stringify(createData)}`);

  for (let i = 0; i < 18; i++) {
    await sleep(2000);
    const check = await fetch(`https://api.ezremove.ai/api/ez-remove/watermark-remove/get-job/${jobId}`, {
      headers: {
        "User-Agent": UA,
        "Accept": "application/json, text/plain, */*",
        "Origin": ORIGIN,
        "Referer": `${ORIGIN}/`,
        "product-serial": `sr-${Date.now()}`
      }
    });
    if (!check.ok) throw new Error(`Check job gagal HTTP ${check.status}`);
    const checkData = await check.json().catch(() => null);
    const resultUrl = checkData?.result?.output?.[0];
    if (checkData?.code === 100000 && resultUrl) return resultUrl;
    if (checkData?.code !== 300001) throw new Error(`Job gagal: ${JSON.stringify(checkData)}`);
  }
  throw new Error("Waktu tunggu habis, hasil belum selesai. Coba lagi.");
}

exports.handler = async (event) => {
  const cors = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "POST,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type"
  };
  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers: cors, body: "" };
  if (event.httpMethod !== "POST") return json(405, cors, { status: false, error: "Gunakan metode POST dengan multipart/form-data field \"image\"" });

  try {
    const contentType = event.headers["content-type"] || event.headers["Content-Type"];
    const bodyBuffer = event.isBase64Encoded ? Buffer.from(event.body, "base64") : Buffer.from(event.body, "utf-8");
    const file = parseMultipart(bodyBuffer, contentType, "image");

    const resultUrl = await removeWatermark(file.filename, file.buffer);

    return json(200, cors, { status: true, code: 200, input: file.filename, result_url: resultUrl });
  } catch (err) {
    return json(500, cors, { status: false, code: 500, error: err.message });
  }
};


// LIANIX_USAGE_WRAPPER_V7
const { wrapHandler: __wrapLianixUsage } = require('./_usage');
exports.handler = __wrapLianixUsage(exports.handler, { apiId: 'removewm', name: 'removewm' });

// Lianix per-user public API key guard
const { withPublicApiKey } = require('./_user-api-key');
exports.handler = withPublicApiKey(exports.handler);
