// netlify/functions/admin-transactions.js
// GET /api/admin/transactions
// Header: Authorization: Bearer <admin_token>
// Mengembalikan daftar transaksi yang tersimpan (untuk dipantau admin).

const { verifyAdminToken } = require("./_admin-auth");
const { makeStore, connectBlobs } = require('./_store');

exports.handler = async (event) => {
  connectBlobs(event);
  const CORS = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization"
  };

  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers: CORS, body: "" };
  if (event.httpMethod !== "GET") {
    return { statusCode: 405, headers: CORS, body: JSON.stringify({ success: false, error: "Method not allowed" }) };
  }

  const ok = await verifyAdminToken(event);
  if (!ok) {
    return { statusCode: 401, headers: CORS, body: JSON.stringify({ success: false, error: "Tidak terautentikasi. Silakan login ulang." }) };
  }

  try {
    const store = makeStore("f24nt-transactions");
    const { blobs = [] } = await store.list();
    const queue = blobs.slice(0, 500);
    let next = 0;
    const rows = new Array(queue.length);
    async function worker() {
      while (true) {
        const i = next++;
        if (i >= queue.length) return;
        try { rows[i] = await store.get(queue[i].key, { type: "json" }); }
        catch { rows[i] = null; }
      }
    }
    await Promise.all(Array.from({ length: Math.min(20, queue.length) }, worker));
    const items = rows.filter(Boolean);
    items.sort((a, b) => new Date(b.created_at || b.createdAt || 0) - new Date(a.created_at || a.createdAt || 0));
    return { statusCode: 200, headers: CORS, body: JSON.stringify({ success: true, data: items.slice(0, 200) }) };
  } catch (err) {
    return { statusCode: 500, headers: CORS, body: JSON.stringify({ success: false, error: err.message }) };
  }
};
