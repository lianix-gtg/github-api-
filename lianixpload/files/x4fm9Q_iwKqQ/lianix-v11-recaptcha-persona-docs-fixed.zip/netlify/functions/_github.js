const OWNER = process.env.GITHUB_OWNER || 'lianix-gtg';
const REPO = process.env.GITHUB_REPO || 'github-api-';
const BRANCH = process.env.GITHUB_BRANCH || 'main';

function token() { return process.env.GITHUB_TOKEN || process.env.GH_TOKEN || ''; }
function headers(accept = 'application/vnd.github+json') {
  const h = {
    Accept: accept,
    'User-Agent': 'Lianix-Netlify-GitHub',
    'X-GitHub-Api-Version': '2022-11-28'
  };
  const t = token();
  if (t) h.Authorization = `Bearer ${t}`;
  return h;
}
function encodePath(p) { return String(p).split('/').filter(Boolean).map(encodeURIComponent).join('/'); }
async function fetchTimeout(url, opts = {}, ms = 12000) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), ms);
  try { return await fetch(url, { ...opts, signal: ctrl.signal }); }
  finally { clearTimeout(timer); }
}
async function request(url, opts = {}, ms = 12000) {
  const res = await fetchTimeout(url, { ...opts, headers: { ...headers(), ...(opts.headers || {}) } }, ms);
  return res;
}
function contentsUrl(path) {
  return `https://api.github.com/repos/${encodeURIComponent(OWNER)}/${encodeURIComponent(REPO)}/contents/${encodePath(path)}`;
}
async function getJson(path, ms = 12000) {
  const res = await request(`${contentsUrl(path)}?ref=${encodeURIComponent(BRANCH)}`, {}, ms);
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    const err = new Error(`GitHub HTTP ${res.status}${text ? ': ' + text.slice(0, 220) : ''}`);
    err.status = res.status;
    throw err;
  }
  return res.json();
}
async function getRaw(path, ms = 12000) {
  const res = await request(`${contentsUrl(path)}?ref=${encodeURIComponent(BRANCH)}`, {
    headers: { Accept: 'application/vnd.github.raw+json' }
  }, ms);
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    const err = new Error(`GitHub raw ${path}: HTTP ${res.status}${text ? ': ' + text.slice(0, 160) : ''}`);
    err.status = res.status;
    throw err;
  }
  return res.text();
}
async function putFile(path, content, message) {
  if (!token()) throw new Error('GITHUB_TOKEN belum diatur di Netlify Environment Variables.');
  let sha;
  try { sha = (await getJson(path)).sha; }
  catch (e) { if (e.status !== 404) throw e; }
  const payload = { message, content: Buffer.from(content, 'utf8').toString('base64'), branch: BRANCH };
  if (sha) payload.sha = sha;
  const res = await request(contentsUrl(path), {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  }, 18000);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.message || `GitHub publish HTTP ${res.status}`);
  return data;
}


async function putBase64File(path, contentBase64, message) {
  if (!token()) throw new Error('GITHUB_TOKEN belum diatur di Netlify Environment Variables.');
  let sha;
  try { sha = (await getJson(path)).sha; }
  catch (e) { if (e.status !== 404) throw e; }
  const clean = String(contentBase64 || '').replace(/^data:[^,]+,/, '').replace(/\s+/g, '');
  if (!clean) throw new Error('Isi file kosong.');
  const payload = { message, content: clean, branch: BRANCH };
  if (sha) payload.sha = sha;
  const res = await request(contentsUrl(path), {
    method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload)
  }, 18000);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.message || `GitHub upload HTTP ${res.status}`);
  return data;
}
async function deleteFile(path, message = `admin: delete ${path}`) {
  if (!token()) throw new Error('GITHUB_TOKEN belum diatur di Netlify Environment Variables.');
  const info = await getJson(path);
  if (!info || Array.isArray(info) || !info.sha) throw new Error(`File tidak ditemukan: ${path}`);
  const res = await request(contentsUrl(path), {
    method: 'DELETE',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ message, sha: info.sha, branch: BRANCH })
  }, 18000);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.message || `GitHub delete HTTP ${res.status}`);
  return data;
}
async function loadRegistry(ms = 12000) {
  const raw = await getRaw('registry.json', ms);
  const registry = JSON.parse(raw);
  if (!Array.isArray(registry.categories)) throw new Error('registry.json wajib punya categories[]');
  return registry;
}
function categoryFolders(category) {
  return [...new Set([
    ...(Array.isArray(category?.folders) ? category.folders : []),
    category?.folder,
    ...(category?.id === 'canvas' ? ['canvasweb'] : [])
  ].filter(Boolean))];
}
module.exports = { OWNER, REPO, BRANCH, headers, fetchTimeout, request, getJson, getRaw, putFile, putBase64File, deleteFile, loadRegistry, categoryFolders };
