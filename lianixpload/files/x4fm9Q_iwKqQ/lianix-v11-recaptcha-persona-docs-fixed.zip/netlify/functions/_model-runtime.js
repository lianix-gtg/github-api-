const vm=require('node:vm');
const { defaultSourceFor }=require('./_models');
function safeAttachment(a={}){return {name:String(a.name||'file').slice(0,240),url:String(a.url||'').slice(0,4000),mime:String(a.mime||'').slice(0,160),size:Number(a.size||0)||0,kind:String(a.kind||'file').slice(0,40),summary:String(a.summary||'').slice(0,120000)}}
function normalizeAttachments(input){return (Array.isArray(input)?input:[]).slice(0,20).map(safeAttachment)}
async function safeFetch(url,opts={}){const u=new URL(String(url));if(!/^https?:$/.test(u.protocol))throw Error('Adapter fetch hanya mendukung http/https.');const ctl=new AbortController(),timer=setTimeout(()=>ctl.abort(),Math.min(30000,Math.max(1000,Number(opts.timeoutMs)||20000)));try{return await fetch(u,{...opts,signal:ctl.signal,headers:{'User-Agent':'Lianix-Model-Adapter/10.6',...(opts.headers||{})}})}finally{clearTimeout(timer)}}

function injectAttachments(prompt,attachments){if(!attachments.length)return String(prompt||'');const rows=attachments.map((a,i)=>`[Attachment ${i+1}]\nname: ${a.name}\nurl: ${a.url}\nmime: ${a.mime}\nkind: ${a.kind}${a.summary?`\ncontent/summary:\n${a.summary}`:''}\n[/Attachment ${i+1}]`);return `${String(prompt||'')}\n\n${rows.join('\n\n')}`.trim()}
async function internalRequest(event,spec,trace){
  const endpoint=String(spec?.endpoint||''),method=String(spec?.method||'GET').toUpperCase()==='POST'?'POST':'GET',param=String(spec?.param||'text'),attachments=normalizeAttachments(spec?.attachments),prompt=String(spec?.prompt||'');
  const promptWithFiles=spec?.embedAttachments===false?prompt:injectAttachments(prompt,attachments);
  if(typeof trace==='function')trace('request.prepare',{endpoint,method,attachments:attachments.length});
  let out;
  const baseBody={...(spec?.body&&typeof spec.body==='object'?spec.body:{}),[param]:promptWithFiles,text:promptWithFiles,prompt:promptWithFiles,attachments};
  if(endpoint==='/api/hackai'){
    const h=require('./hackai');out=await h.handler({...event,httpMethod:'POST',path:'/api/hackai',body:JSON.stringify(baseBody),headers:{...(event.headers||{}),'content-type':'application/json','x-lianix-health-check':'1'}},{});
  }else if(endpoint.startsWith('/api/ai/')){
    const ep=endpoint.split('/').filter(Boolean).pop(),h=require('./ai-proxy');
    const qsObj={...(spec?.query&&typeof spec.query==='object'?spec.query:{}),[param]:promptWithFiles};
    const qs=method==='GET'?new URLSearchParams(Object.entries(qsObj).map(([k,v])=>[k,typeof v==='string'?v:JSON.stringify(v)])).toString():'';
    out=await h.handler({...event,httpMethod:method,path:`/api/ai/${ep}`,rawUrl:`https://local/api/ai/${ep}${qs?'?'+qs:''}`,queryStringParameters:method==='GET'?qsObj:{},body:method==='POST'?JSON.stringify(baseBody):null,headers:{...(event.headers||{}),'content-type':'application/json','x-lianix-health-check':'1'}},{});
  }else throw Error('Adapter hanya boleh request route lokal /api/ai/* atau /api/hackai');
  const status=Number(out?.statusCode||500);let body;try{body=JSON.parse(out?.body||'{}')}catch{body=out?.body||''}
  if(typeof trace==='function')trace('request.response',{endpoint,status});
  if(status<200||status>=300)throw Error(typeof body==='string'?body:(body.error||body.message||`HTTP ${status}`));return body
}
async function runModelSource(event,m,prompt,options={}){
  const source=String(m.source||defaultSourceFor(m)),attachments=normalizeAttachments(options.attachments);const module={exports:null};const logs=[];
  const push=(stage,detail={})=>{logs.push({stage,detail,at:Date.now()});if(typeof options.onTrace==='function')options.onTrace(stage,detail)};
  const sandbox={module,exports:{},fetch:safeFetch,crypto:globalThis.crypto,Buffer,TextEncoder,TextDecoder,AbortController,console:{log:(...x)=>push('adapter.log',{message:x.map(String).join(' ').slice(0,600)}),warn:(...x)=>push('adapter.warn',{message:x.map(String).join(' ').slice(0,600)}),error:(...x)=>push('adapter.error',{message:x.map(String).join(' ').slice(0,600)})},setTimeout,clearTimeout,URL,URLSearchParams};
  push('adapter.compile',{model:m.id,sourceBytes:Buffer.byteLength(source)});
  const context=vm.createContext(sandbox,{name:'lianix-model-adapter',codeGeneration:{strings:false,wasm:false}});new vm.Script(source,{filename:`model-${m.id}.js`}).runInContext(context,{timeout:900});
  const fn=module.exports||sandbox.module.exports;if(typeof fn!=='function')throw Error('Adapter JS wajib: module.exports = async function(prompt, ctx) {...}');
  const ctx=Object.freeze({attachments:Object.freeze(attachments),capabilities:Object.freeze(m.capabilities||{}),request:(spec)=>internalRequest(event,{...spec,attachments:spec?.attachments??attachments},push),fetch:safeFetch,trace:(label,detail)=>push('adapter.trace',{label:String(label||'').slice(0,120),detail:String(detail||'').slice(0,800)})});
  let timer;push('adapter.run',{attachments:attachments.length});try{const result=await Promise.race([Promise.resolve(fn(String(prompt||''),ctx)),new Promise((_,rej)=>{timer=setTimeout(()=>rej(Error('MODEL_TIMEOUT')),60000)})]);push('adapter.done',{});return {result,trace:logs}}finally{if(timer)clearTimeout(timer)}}
module.exports={runModelSource,injectAttachments,normalizeAttachments};
