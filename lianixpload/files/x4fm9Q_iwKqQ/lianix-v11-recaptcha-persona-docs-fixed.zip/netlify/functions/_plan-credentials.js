const crypto=require('node:crypto');
const {getJson,getRaw,putFile,deleteFile}=require('./_github');
const DIR='plan-credentials';
function master(){return String(process.env.PLAN_MASTER_KEY||process.env.ADMIN_PASSWORD||'')}
function id(){return crypto.randomBytes(6).toString('base64url')}
function clean(s,n=120){return String(s??'').replace(/[\u0000\r\n]/g,' ').trim().slice(0,n)}
function enc(text,keyText=master()){if(!keyText)throw new Error('PLAN_MASTER_KEY/ADMIN_PASSWORD belum tersedia.');const salt=crypto.randomBytes(16),iv=crypto.randomBytes(12),key=crypto.scryptSync(keyText,salt,32),c=crypto.createCipheriv('aes-256-gcm',key,iv),data=Buffer.concat([c.update(String(text),'utf8'),c.final()]);return{salt:salt.toString('base64'),iv:iv.toString('base64'),tag:c.getAuthTag().toString('base64'),data:data.toString('base64')}}
function dec(x,keyText=master()){const key=crypto.scryptSync(keyText,Buffer.from(x.salt,'base64'),32),d=crypto.createDecipheriv('aes-256-gcm',key,Buffer.from(x.iv,'base64'));d.setAuthTag(Buffer.from(x.tag,'base64'));return Buffer.concat([d.update(Buffer.from(x.data,'base64')),d.final()]).toString('utf8')}
function hashPassword(password,salt=crypto.randomBytes(16).toString('base64')){const h=crypto.scryptSync(String(password),Buffer.from(salt,'base64'),32).toString('base64');return{salt,hash:h}}
function verifyPassword(password,p){try{const x=hashPassword(password,p.passwordHash.salt).hash;return crypto.timingSafeEqual(Buffer.from(x),Buffer.from(p.passwordHash.hash))}catch{return false}}
function path(x){return`${DIR}/${x}.json`}
async function get(x){return JSON.parse(await getRaw(path(x)))}
async function list(){let a;try{a=await getJson(DIR)}catch(e){if(e.status===404)return[];throw e}const out=[];for(const f of (Array.isArray(a)?a:[]).filter(x=>x.type==='file'&&x.name.endsWith('.json'))){try{out.push(JSON.parse(await getRaw(f.path)))}catch{}}return out.sort((a,b)=>String(b.updatedAt).localeCompare(String(a.updatedAt)))}
async function save(input,old=null){const username=clean(input.username,80),password=String(input.password||'');if(!username)throw new Error('Username wajib.');if(!old&&!password)throw new Error('Password wajib.');const plan=input.plan==='gokil'?'gokil':'abyz';const r={version:1,id:old?.id||id(),username,plan,enabled:input.enabled!==false,createdAt:old?.createdAt||new Date().toISOString(),updatedAt:new Date().toISOString(),passwordHash:password?hashPassword(password):old.passwordHash,passwordEncrypted:password?enc(password):old.passwordEncrypted};await putFile(path(r.id),JSON.stringify(r,null,2)+'\n',`plan credential: save ${r.id}`);return r}
async function remove(x){return deleteFile(path(x),`plan credential: delete ${x}`)}
function adminView(r){let password='';try{password=dec(r.passwordEncrypted)}catch{}return{id:r.id,username:r.username,password,plan:r.plan,enabled:r.enabled!==false,createdAt:r.createdAt,updatedAt:r.updatedAt}}
module.exports={get,list,save,remove,verifyPassword,adminView};
