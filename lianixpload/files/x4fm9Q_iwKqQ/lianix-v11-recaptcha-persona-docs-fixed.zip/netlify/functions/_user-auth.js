const crypto = require('node:crypto');
const { bearerFromEvent, verifyFirebaseIdToken } = require('./_firebase-auth');

function emailSecret(){ return String(process.env.AUTH_CODE_SECRET||process.env.ADMIN_SESSION_SECRET||process.env.ADMIN_PASSWORD||''); }
function safeEq(a,b){ const x=Buffer.from(String(a||'')),y=Buffer.from(String(b||'')); return x.length===y.length&&crypto.timingSafeEqual(x,y); }
function parseEmailSession(token){
  if(!token) return null;
  const parts=String(token).split('.'); if(parts.length!==2||!emailSecret()) return null;
  const [p,sig]=parts; const expSig=crypto.createHmac('sha256',emailSecret()).update(p).digest('base64url');
  if(!safeEq(sig,expSig)) return null;
  let d; try{ d=JSON.parse(Buffer.from(p,'base64url').toString('utf8')); }catch{return null}
  if(!d?.email||!d?.exp||d.exp<Date.now()) return null;
  const email=String(d.email).trim().toLowerCase();
  return {uid:`email:${crypto.createHash('sha256').update(email).digest('hex').slice(0,20)}`,email,displayName:email.split('@')[0],providerId:'email-code'};
}
async function requireUser(event){
  const emailToken=event?.headers?.['x-lianix-email-session']||event?.headers?.['X-Lianix-Email-Session']||'';
  const eu=parseEmailSession(emailToken); if(eu) return eu;
  const bearer=bearerFromEvent(event); if(bearer){
    const u=await verifyFirebaseIdToken(bearer); const p=u.providerUserInfo?.[0]?.providerId||'firebase';
    return {...u,providerId:p};
  }
  const e=new Error('LOGIN_REQUIRED'); e.statusCode=401; throw e;
}
function userKey(uid){ return crypto.createHash('sha256').update(String(uid)).digest('hex').slice(0,40); }
module.exports={requireUser,parseEmailSession,userKey};
