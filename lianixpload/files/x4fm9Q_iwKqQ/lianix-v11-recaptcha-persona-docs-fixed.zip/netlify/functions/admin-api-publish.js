const { verifyAdminToken } = require('./_admin-auth');
const { analyzeCode, buildMetaBlock, slugify, dependencySpec } = require('./_api-meta');
const { loadRegistry, putFile, getRaw, categoryFolders, OWNER, REPO, BRANCH } = require('./_github');
const { canonicalMeta, verifyTest } = require('./_test-receipt');
const CORS = { 'Content-Type':'application/json', 'Access-Control-Allow-Origin':'*', 'Access-Control-Allow-Methods':'POST,OPTIONS', 'Access-Control-Allow-Headers':'Content-Type, Authorization' };
const out = (statusCode, body) => ({ statusCode, headers:CORS, body:JSON.stringify(body) });

async function resolveNpmSpec(name, suggested) {
  if (suggested && suggested !== 'latest') return suggested;
  if (!/^(@[a-z0-9._-]+\/[a-z0-9._-]+|[a-z0-9._-]+)$/i.test(name)) throw new Error(`Nama dependency tidak valid: ${name}`);
  const ctrl = new AbortController(); const timer = setTimeout(() => ctrl.abort(), 6000);
  try {
    const res = await fetch(`https://registry.npmjs.org/${encodeURIComponent(name)}`, { headers:{Accept:'application/json'}, signal:ctrl.signal });
    if (!res.ok) throw new Error(`npm registry HTTP ${res.status}`);
    const data = await res.json(); const v = data?.['dist-tags']?.latest;
    if (!v || !/^\d+\.\d+\.\d+/.test(v)) throw new Error('Versi latest tidak ditemukan');
    return `^${v}`;
  } finally { clearTimeout(timer); }
}

async function ensureRepoDependencies(dependencies = [], versions = {}) {
  const deps = [...new Set((dependencies || []).map(String).filter(Boolean))];
  if (!deps.length) return { updated: false, dependencies: [] };
  let pkg;
  try { pkg = JSON.parse(await getRaw('package.json')); }
  catch (e) {
    if (e.status !== 404) throw e;
    pkg = { name: 'lianix-api-registry', version: '1.0.0', private: true, dependencies: {} };
  }
  pkg.dependencies = pkg.dependencies && typeof pkg.dependencies === 'object' ? pkg.dependencies : {};
  const added = [];
  for (const dep of deps) {
    if (!pkg.dependencies[dep]) {
      let spec = versions[dep] || dependencySpec(dep);
      try { spec = await resolveNpmSpec(dep, spec); } catch (e) { if (spec === 'latest') throw new Error(`Dependency ${dep} tidak dapat diverifikasi di npm: ${e.message}`); }
      pkg.dependencies[dep] = spec; added.push(dep);
    }
  }
  if (!added.length) return { updated: false, dependencies: deps, added: [] };
  const ordered = Object.fromEntries(Object.entries(pkg.dependencies).sort(([a],[b]) => a.localeCompare(b)));
  pkg.dependencies = ordered;
  await putFile('package.json', JSON.stringify(pkg, null, 2) + '\n', `admin: auto-install dependencies (${added.join(', ')})`);
  return { updated: true, dependencies: deps, added };
}

let publishing = false;
exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return { statusCode:204, headers:CORS, body:'' };
  if (event.httpMethod !== 'POST') return out(405,{success:false,error:'Method not allowed'});
  if (!await verifyAdminToken(event)) return out(401,{success:false,error:'Tidak terautentikasi.'});
  if (publishing) return out(409,{success:false,error:'Publish lain sedang berjalan. Coba lagi setelah selesai.'});
  publishing = true;
  try {
    const p = JSON.parse(event.body || '{}');
    if (!p.code || typeof p.code !== 'string') return out(400,{success:false,error:'Kode JS wajib diisi.'});
    const auto = analyzeCode(p.code,{filename:p.filename||'api.js',category:p.category||'tools'});
    const meta = canonicalMeta({ ...auto, ...(p.meta || {}), inputs:Array.isArray(p.meta?.inputs)?p.meta.inputs:auto.inputs, outputs:Array.isArray(p.meta?.outputs)?p.meta.outputs:auto.outputs });
    if (!verifyTest(p.testReceipt, p.code, meta)) return out(412,{success:false,error:'API wajib di-Test ulang sebelum Publish, atau kode/metadata berubah setelah test.'});
    const registry = await loadRegistry();
    const cat = registry.categories.find(c => c.id === meta.category || c.name?.toLowerCase() === String(meta.category).toLowerCase());
    if (!cat) return out(400,{success:false,error:`Kategori '${meta.category}' tidak ditemukan di registry.json.`});
    const folders = categoryFolders(cat);
    let folder = p.folder && folders.includes(p.folder) ? p.folder : folders[0];
    if (cat.id === 'canvas' && folders.includes('canvasweb')) folder = (p.folder && folders.includes(p.folder)) ? p.folder : 'canvasweb';
    if (!folder) return out(400,{success:false,error:'Folder kategori tidak ditemukan.'});
    const base = slugify(p.filename || meta.id || meta.name);
    const filename = (base.endsWith('.js') ? base : `${base}.js`).replace(/\.js\.js$/i,'.js');
    meta.id = meta.id || base.replace(/\.js$/i,'');
    meta.category = cat.id;
    const cleaned = p.code.replace(/\/\*\s*@lianix-meta[\s\S]*?\*\//i,'').trimStart();
    // Keep Node hashbang on the first line. A metadata comment before `#!` makes CLI files
    // invalid when executed directly with Node.
    const hb = cleaned.match(/^(#![^\n]*)(?:\n|$)/);
    const finalCode = hb
      ? `${hb[1]}\n\n${buildMetaBlock(meta)}\n\n${cleaned.slice(hb[0].length).trimStart()}`
      : `${buildMetaBlock(meta)}\n\n${cleaned}`;
    const path = `${folder}/${filename}`;
    const dependencyInstall = await ensureRepoDependencies(meta.dependencies || auto.dependencies || [], auto.dependencyVersions || {});
    const result = await putFile(path, finalCode, `admin: publish ${meta.id}`);
    return out(200,{success:true,data:{path,filename,folder,meta,dependencyInstall,repository:{owner:OWNER,repo:REPO,branch:BRANCH},commit:result.commit?.sha||null,htmlUrl:result.content?.html_url||null}});
  } catch (e) { return out(500,{success:false,error:e.message}); }
  finally { publishing = false; }
};
