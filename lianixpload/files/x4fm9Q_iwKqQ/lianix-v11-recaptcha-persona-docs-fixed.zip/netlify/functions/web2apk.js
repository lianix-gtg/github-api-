// netlify/functions/web2apk.js
// Konversi website ke APK Android via rfweb2apk.rfdevv.com
// Client kirim: GET /api/web2apk?url=<URL>&appName=<NAME>&packageName=<PKG>&icon=<ICON_URL>

const https = require('https');
const http = require('http');

function cors() {
    return {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET,OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type'
    };
}
function json(code, body) {
    return { statusCode: code, headers: { ...cors(), 'Content-Type': 'application/json' }, body: JSON.stringify(body) };
}

const PROXY_API = 'https://api.ikyyxd.my.id/v2l/proxy-free/ikyy-xsample';
const DEVICE_PROFILES = [
    'Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36',
    'Mozilla/5.0 (Linux; Android 13; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
    'Mozilla/5.0 (Linux; Android 12; Redmi Note 12 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Mobile Safari/537.36'
];

function getUA() { return DEVICE_PROFILES[Math.floor(Math.random() * DEVICE_PROFILES.length)]; }

function httpGet(url, headers = {}) {
    return new Promise((resolve, reject) => {
        const lib = url.startsWith('https') ? https : http;
        const req = lib.get(url, { headers }, res => {
            const chunks = [];
            res.on('data', c => chunks.push(c));
            res.on('end', () => resolve({ body: Buffer.concat(chunks).toString(), status: res.statusCode }));
        });
        req.on('error', reject);
        req.setTimeout(20000, () => { req.destroy(); reject(new Error('Timeout')); });
    });
}

function httpGetBinary(url) {
    return new Promise((resolve, reject) => {
        const lib = url.startsWith('https') ? https : http;
        const req = lib.get(url, { headers: { 'User-Agent': getUA() } }, res => {
            const chunks = [];
            const ct = res.headers['content-type'] || 'image/png';
            res.on('data', c => chunks.push(c));
            res.on('end', () => resolve({ buffer: Buffer.concat(chunks), contentType: ct }));
        });
        req.on('error', reject);
        req.setTimeout(15000, () => { req.destroy(); reject(new Error('Icon download timeout')); });
    });
}

async function postMultipart(url, fields, files, proxyStr) {
    const boundary = '----FormBoundary' + Math.random().toString(36).slice(2);
    const parts = [];

    for (const [key, val] of Object.entries(fields)) {
        parts.push(
            `--${boundary}\r\nContent-Disposition: form-data; name="${key}"\r\n\r\n${val}`
        );
    }
    for (const f of files) {
        parts.push(
            `--${boundary}\r\nContent-Disposition: form-data; name="${f.name}"; filename="${f.filename}"\r\nContent-Type: ${f.contentType}\r\n\r\n`
        );
        parts.push(f.buffer);
    }
    parts.push(`--${boundary}--`);

    const bodyParts = parts.map(p => typeof p === 'string' ? Buffer.from(p + '\r\n') : Buffer.concat([p, Buffer.from('\r\n')]));
    const body = Buffer.concat(bodyParts);

    return new Promise((resolve, reject) => {
        const u = new URL(url);
        let proxyOpts = {};
        if (proxyStr) {
            const [h, p, user, pass] = proxyStr.split(':');
            if (h && p) proxyOpts = { agent: undefined }; // simplified — Netlify outbound doesn't support CONNECT proxies well
        }

        const opts = {
            hostname: u.hostname, path: u.pathname + u.search,
            method: 'POST',
            headers: {
                'Content-Type': `multipart/form-data; boundary=${boundary}`,
                'Content-Length': body.length,
                'User-Agent': getUA()
            }
        };
        const lib = u.protocol === 'https:' ? https : http;
        const req = lib.request(opts, res => {
            const chunks = [];
            res.on('data', c => chunks.push(c));
            res.on('end', () => resolve({ body: Buffer.concat(chunks).toString(), status: res.statusCode }));
        });
        req.on('error', reject);
        req.setTimeout(40000, () => { req.destroy(); reject(new Error('Build timeout')); });
        req.write(body);
        req.end();
    });
}

exports.handler = async (event) => {
    if (event.httpMethod === 'OPTIONS') return { statusCode: 204, headers: cors(), body: '' };
    if (event.httpMethod !== 'GET') return json(405, { status: false, error: 'Method not allowed' });

    const qs = event.queryStringParameters || {};
    const { url, appName, packageName, icon, versionName = '1.0', versionCode = '1', orientation = 'auto' } = qs;

    if (!url || !appName || !packageName) {
        return json(400, { status: false, error: "Parameter wajib: url, appName, packageName" });
    }

    try {
        // Download icon
        let iconBuffer, iconFilename = 'icon.png', iconCT = 'image/png';
        if (icon && icon.startsWith('http')) {
            try {
                const iconData = await httpGetBinary(icon);
                iconBuffer = iconData.buffer;
                iconCT = iconData.contentType;
                iconFilename = iconCT.includes('jpeg') ? 'icon.jpg' : 'icon.png';
            } catch {
                // fallback 1x1 transparent PNG
                iconBuffer = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==', 'base64');
            }
        } else {
            iconBuffer = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==', 'base64');
        }

        const fields = { appName, packageName, versionName, versionCode, url, splashType: 'image', orientation };
        const files = [{ name: 'icon', filename: iconFilename, contentType: iconCT, buffer: iconBuffer }];

        const res = await postMultipart('https://rfweb2apk.rfdevv.com/api/apk/build', fields, files, null);
        let data;
        try { data = JSON.parse(res.body); } catch { return json(502, { status: false, error: 'Response invalid', raw: res.body.slice(0, 300) }); }

        if (data.success) {
            return json(200, {
                status: true,
                buildId: data.buildId,
                fileName: data.fileName,
                size: data.size,
                downloadUrl: `https://rfweb2apk.rfdevv.com${data.downloadUrl}`,
                message: data.message
            });
        } else {
            return json(502, { status: false, error: data.message || 'Build failed' });
        }
    } catch (err) {
        return json(502, { status: false, error: err.message });
    }
};


// LIANIX_USAGE_WRAPPER_V7
const { wrapHandler: __wrapLianixUsage } = require('./_usage');
exports.handler = __wrapLianixUsage(exports.handler, { apiId: 'web2apk', name: 'web2apk' });

// Lianix per-user public API key guard
const { withPublicApiKey } = require('./_user-api-key');
exports.handler = withPublicApiKey(exports.handler);
