const crypto = require('node:crypto');

function secret() {
  return String(process.env.ADMIN_SESSION_SECRET || process.env.ADMIN_PASSWORD || '');
}
function sign(data) {
  return crypto.createHmac('sha256', secret()).update(data).digest('base64url');
}
function createAdminToken(ttlMs = 12 * 3600 * 1000) {
  if (!secret()) throw new Error('ADMIN_PASSWORD belum dikonfigurasi di Netlify Environment Variables.');
  const payload = Buffer.from(JSON.stringify({ v:1, exp:Date.now()+ttlMs }), 'utf8').toString('base64url');
  return `${payload}.${sign(payload)}`;
}
function safeEqual(a,b){
  const aa=Buffer.from(String(a||'')), bb=Buffer.from(String(b||''));
  return aa.length===bb.length && crypto.timingSafeEqual(aa,bb);
}
async function verifyAdminToken(event) {
  const authHeader = event?.headers?.authorization || event?.headers?.Authorization || '';
  const token = String(authHeader).replace(/^Bearer\s+/i,'').trim();
  if (!token || !secret()) return false;
  const [payload,sig,extra] = token.split('.');
  if (!payload || !sig || extra || !safeEqual(sig, sign(payload))) return false;
  try {
    const data=JSON.parse(Buffer.from(payload,'base64url').toString('utf8'));
    return data?.v===1 && Number(data.exp)>Date.now();
  } catch { return false; }
}
module.exports = { verifyAdminToken, createAdminToken };
