// netlify/functions/health.js
// Cek cepat: buka /api/health di browser — kalau muncul JSON {ok:true},
// berarti Netlify Functions aktif dan routing _redirects sudah benar.
exports.handler = async () => ({
  statusCode: 200,
  headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
  body: JSON.stringify({ ok: true, time: new Date().toISOString() })
});


// LIANIX_USAGE_WRAPPER_V7
const { wrapHandler: __wrapLianixUsage } = require('./_usage');
exports.handler = __wrapLianixUsage(exports.handler, { apiId: 'health', name: 'health' });
