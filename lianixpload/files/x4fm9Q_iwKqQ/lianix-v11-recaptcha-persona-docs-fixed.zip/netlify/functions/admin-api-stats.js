const { verifyAdminToken } = require('./_admin-auth');
const { makeStore, connectBlobs } = require('./_store');
const CORS={'Content-Type':'application/json','Access-Control-Allow-Origin':'*','Access-Control-Allow-Methods':'GET,OPTIONS','Access-Control-Allow-Headers':'Content-Type, Authorization'};
const out=(s,b)=>({statusCode:s,headers:CORS,body:JSON.stringify(b)});
function daysBack(n){const a=[];for(let i=0;i<n;i++){const d=new Date(Date.now()-i*86400000);a.push(d.toISOString().slice(0,10))}return a}
async function mapLimit(items,limit,fn){let n=0;const out=new Array(items.length);async function run(){while(true){const i=n++;if(i>=items.length)return;try{out[i]=await fn(items[i])}catch{out[i]=null}}}await Promise.all(Array.from({length:Math.min(limit,items.length)},run));return out}
function add(grouped,e){if(!e)return;const k=e.apiId||'unknown';const g=grouped[k]||(grouped[k]={apiId:k,name:e.name||k,count:0,success:0,error:0,totalLatency:0,lastAt:0});if(e.name&&(!g.name||g.name===k))g.name=e.name;g.count++;e.ok?g.success++:g.error++;g.totalLatency+=Number(e.latency)||0;g.lastAt=Math.max(g.lastAt,Number(e.at)||0)}
exports.handler=async(event)=>{
  connectBlobs(event);
  if(event.httpMethod==='OPTIONS')return{statusCode:204,headers:CORS,body:''};
  if(event.httpMethod!=='GET')return out(405,{success:false,error:'Method not allowed'});
  if(!await verifyAdminToken(event))return out(401,{success:false,error:'Tidak terautentikasi.'});
  try{
    const q=event.queryStringParameters||{},days=Math.max(1,Math.min(Number(q.days)||1,30)),store=makeStore('f24nt-api-usage'),grouped={};let total=0,success=0,error=0;const legacy=[];
    for(const day of daysBack(days)){
      const {blobs=[]}=await store.list({prefix:`${day}/`});
      for(const b of blobs){
        const parts=String(b.key).split('/');
        if(parts.length>=6){
          const apiId=parts[1],ok=parts[2]==='1',status=Number(parts[3])||0,latency=Number(parts[4])||0,at=Number((parts[5]||'').split('-')[0])||0;
          add(grouped,{apiId,ok,status,latency,at});total++;ok?success++:error++;
        }else legacy.push(b.key);
      }
    }
    // Backward compatibility for V7 keys. Read concurrently, capped only by actual legacy count.
    const old=await mapLimit(legacy,20,k=>store.get(k,{type:'json'}));for(const e of old){if(e){add(grouped,e);total++;e.ok?success++:error++;}}
    const healthStore=makeStore('f24nt-api-health');
    try{const {blobs:hb=[]}=await healthStore.list();const health=await mapLimit(hb,20,b=>healthStore.get(b.key,{type:'json'}));for(const h of health){if(!h)continue;const k=h.apiId||'unknown';if(!grouped[k])grouped[k]={apiId:k,name:h.name||k,count:0,success:0,error:0,totalLatency:0,lastAt:0};else if(h.name)grouped[k].name=h.name;}}catch{}
    const items=Object.values(grouped).map(g=>({...g,avgLatency:g.count?Math.round(g.totalLatency/g.count):0,successRate:g.count?Math.round(g.success/g.count*1000)/10:0})).sort((a,b)=>b.count-a.count);
    return out(200,{success:true,data:{days,total,success,error,items}});
  }catch(e){return out(500,{success:false,error:e.message})}
};
