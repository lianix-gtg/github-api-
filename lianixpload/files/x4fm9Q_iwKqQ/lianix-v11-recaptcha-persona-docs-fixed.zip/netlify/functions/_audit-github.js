const {putFile,getJson,getRaw}=require('./_github');const {rid}=require('./_security-audit');
async function write(dir,record){const id=rid();await putFile(`${dir}/${id}.json`,JSON.stringify({...record,id},null,2)+'\n',`audit: ${dir} ${id}`);return id}
async function list(dir,limit=100){let a;try{a=await getJson(dir)}catch(e){if(e.status===404)return[];throw e}const files=(Array.isArray(a)?a:[]).filter(x=>x.type==='file'&&x.name.endsWith('.json')).slice(-limit);const out=[];for(const f of files){try{out.push(JSON.parse(await getRaw(f.path)))}catch{}}return out.sort((a,b)=>String(b.at||'').localeCompare(String(a.at||'')))}
module.exports={write,list};
