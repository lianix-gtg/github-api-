// netlify/functions/hackai.js
// Proxy khusus untuk HackAI (heck.ai) — perlu 2 langkah: buat session lalu kirim pesan.
// Client memanggil: POST /api/hackai  body: { "text": "pesan", "sessionId": "opsional" }

const HEADERS = {
  "Content-Type": "application/json",
  Origin: "https://heck.ai",
  Referer: "https://heck.ai/",
  "User-Agent":
    "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36",
  Accept: "*/*"
};

async function createSession(title) {
  const res = await fetch("https://api.heckai.weight-wave.com/api/ha/v1/session/create", {
    method: "POST",
    headers: HEADERS,
    body: JSON.stringify({ title }),
    signal: AbortSignal.timeout(20000)
  });
  const raw = await res.text();
  if (!res.ok) {
    throw new Error(`Session create gagal (HTTP ${res.status}): ${raw.slice(0, 200)}`);
  }
  let data;
  try { data = JSON.parse(raw); } catch (e) {
    throw new Error("Session create: respons bukan JSON valid: " + raw.slice(0, 200));
  }
  if (!data?.id) throw new Error("Session create: field 'id' tidak ditemukan di respons: " + raw.slice(0, 200));
  return data.id;
}

async function sendMessage(sessionId, question) {
  const payload = {
    model: "openai/gpt-5.4-mini",
    question,
    language: "English",
    previousQuestion: null,
    previousAnswer: null,
    sessionId
  };
  const res = await fetch("https://api.heckai.weight-wave.com/api/ha/v1/chat", {
    method: "POST",
    headers: HEADERS,
    body: JSON.stringify(payload),
    signal: AbortSignal.timeout(60000)
  });
  const raw = await res.text();
  if (!res.ok) {
    throw new Error(`Chat gagal (HTTP ${res.status}): ${raw.slice(0, 300)}`);
  }

  const MARKERS = ["[ANSWER_START]", "[ANSWER_DONE]", "[RELATE_Q_START]", "[RELATE_Q_DONE]"];
  let fullText = "";
  let sawDataLine = false;

  for (const line of raw.split("\n")) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    // Terima "data:" atau "data: " (dengan/tanpa spasi), case-insensitive
    if (/^data\s*:/i.test(trimmed)) {
      sawDataLine = true;
      let content = trimmed.replace(/^data\s*:\s?/i, "");
      if (MARKERS.some(m => content.includes(m))) continue;
      fullText += content;
    }
  }

  fullText = fullText.trim();

  // Fallback: kalau tidak ada baris "data:" sama sekali, mungkin format respons
  // sudah berubah jadi JSON biasa atau plain text — coba parse langsung.
  if (!fullText) {
    if (!sawDataLine) {
      try {
        const parsed = JSON.parse(raw);
        const alt = parsed?.answer || parsed?.result || parsed?.message || parsed?.text;
        if (alt) return String(alt).trim();
      } catch (e) { /* bukan JSON, lanjut ke bawah */ }
      // Bukan format SSE maupun JSON yang dikenal — kembalikan raw agar terlihat isinya
      if (raw.trim()) return raw.trim().slice(0, 4000);
    }
    throw new Error("Respons HackAI kosong setelah parsing (format stream mungkin berubah).");
  }

  return fullText;
}

// Rate limit sederhana per-IP
const hits = new Map();
function rateLimited(ip) {
  const now = Date.now();
  const rec = hits.get(ip) || { n: 0, t: now };
  if (now - rec.t > 60000) { rec.n = 0; rec.t = now; }
  rec.n++;
  hits.set(ip, rec);
  return rec.n > 20;
}

exports.handler = async (event) => {
  const cors = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type"
  };
  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers: cors, body: "" };
  if (event.httpMethod !== "POST" && event.httpMethod !== "GET") {
    return { statusCode: 405, headers: cors, body: JSON.stringify({ error: "Method tidak didukung" }) };
  }

  const ip = event.headers["x-nf-client-connection-ip"] || event.headers["client-ip"] || "unknown";
  if (rateLimited(ip)) {
    return { statusCode: 429, headers: cors, body: JSON.stringify({ status: false, error: "Terlalu banyak permintaan, coba lagi sebentar." }) };
  }

  try {
    let text, sessionId;
    if (event.httpMethod === "POST") {
      const body = JSON.parse(event.body || "{}");
      text = body.text || body.question || body.prompt;
      sessionId = body.sessionId || null;
    } else {
      const qs = event.queryStringParameters || {};
      text = qs.text || qs.question || qs.prompt;
      sessionId = qs.sessionId || null;
    }

    if (!text) {
      return { statusCode: 400, headers: cors, body: JSON.stringify({ status: false, error: "Parameter 'text' wajib diisi" }) };
    }

    if (!sessionId) sessionId = await createSession(text);
    const result = await sendMessage(sessionId, text);

    return {
      statusCode: 200,
      headers: { ...cors, "Content-Type": "application/json" },
      body: JSON.stringify({ status: true, sessionId, result })
    };
  } catch (err) {
    return {
      statusCode: 502,
      headers: cors,
      body: JSON.stringify({ status: false, error: err.message || "Gagal menghubungi HackAI" })
    };
  }
};


// LIANIX_USAGE_WRAPPER_V7
const { wrapHandler: __wrapLianixUsage } = require('./_usage');
exports.handler = __wrapLianixUsage(exports.handler, { apiId: 'hackai', name: 'hackai' });
