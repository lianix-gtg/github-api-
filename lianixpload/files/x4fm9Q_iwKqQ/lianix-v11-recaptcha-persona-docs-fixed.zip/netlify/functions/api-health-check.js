const { loadRegistry, categoryFolders, getJson, getRaw, fetchTimeout } = require('./_github');
const { analyzeCode } = require('./_api-meta');
const { makeStore, connectBlobs } = require('./_store');
const { internalHealthToken } = require('./_user-api-key');

const TOTAL_BUDGET_MS = 24000; // Netlify scheduled functions max 30s; leave headroom.
const HTTP_TIMEOUT_MS = 4500;
const GH_TIMEOUT_MS = 5000;
const CONCURRENCY = 8;

function resolveEndpoint(ep){
  if(/^https?:\/\//i.test(ep||'')) return ep;
  const base=process.env.URL||process.env.DEPLOY_PRIME_URL||'';
  return base&&String(ep||'').startsWith('/')?base.replace(/\/$/,'')+ep:'';
}
function sampleValue(p){
  const t=String(p?.type||'text').toLowerCase();
  if(t==='url') return 'https://example.com';
  if(t==='number') return 1;
  if(t==='select') return Array.isArray(p.choices||p.options)&& (p.choices||p.options).length ? ((p.choices||p.options)[0]?.value ?? (p.choices||p.options)[0]) : 'test';
  return 'test';
}
function hasFileInput(meta){return (meta.inputs||[]).some(p=>['file','image','audio','video','folder'].includes(String(p.type||'').toLowerCase()));}
async function mapLimit(items, limit, worker, deadline){
  const results = new Array(items.length); let next=0;
  async function runner(){
    while(true){
      const i=next++; if(i>=items.length) return;
      if(Date.now() > deadline-1000){results[i]={skipped:true};continue;}
      try{results[i]=await worker(items[i],i)}catch(e){results[i]={error:e};}
    }
  }
  await Promise.all(Array.from({length:Math.min(limit,items.length)},runner));
  return results;
}
async function check(meta){
  const url=resolveEndpoint(meta.endpoint); const started=Date.now();
  if(!url) return {apiId:meta.id,name:meta.name,path:meta.endpoint,status:'untested',httpStatus:0,latency:0,checkedAt:Date.now(),error:'Endpoint tidak dapat di-resolve'};
  try{
    const method=String(meta.method||'GET').toUpperCase(); let testUrl=url; const headers={'X-Lianix-Health-Check':'1'}; const internalToken=internalHealthToken(); if(internalToken) headers['X-Lianix-Internal-Token']=internalToken; const options={method,headers};
    if(method==='GET'){
      const u=new URL(url); for(const p of meta.inputs||[]){if(p.required)u.searchParams.set(p.name,String(sampleValue(p)));} testUrl=u.toString();
    }else if(hasFileInput(meta)){
      // We cannot invent a valid file. OPTIONS verifies route reachability without fake media.
      options.method='OPTIONS';
    }else{
      const body={}; for(const p of meta.inputs||[]){if(p.required)body[p.name]=sampleValue(p);} headers['Content-Type']='application/json'; options.body=JSON.stringify(body);
    }
    const r=await fetchTimeout(testUrl,options,HTTP_TIMEOUT_MS);
    // 400/401/403/405/415/422 prove the route/server is reachable; 5xx means broken.
    const reachable = r.ok || [400,401,403,405,415,422].includes(r.status);
    const status = reachable ? (r.ok?'online':'degraded') : 'error';
    return {apiId:meta.id,name:meta.name,path:meta.endpoint,status,httpStatus:r.status,latency:Date.now()-started,checkedAt:Date.now(),error:status==='error'?`HTTP ${r.status}`:status==='degraded'?`Reachable, HTTP ${r.status}`:''};
  }catch(e){
    return {apiId:meta.id,name:meta.name,path:meta.endpoint,status:'error',httpStatus:0,latency:Date.now()-started,checkedAt:Date.now(),error:e.name==='AbortError'?'Timeout':e.message};
  }
}
async function discoverMetas(deadline){
  const registry=await loadRegistry(GH_TIMEOUT_MS); const jobs=[];
  for(const cat of registry.categories.filter(c=>c.enabled!==false)) for(const folder of categoryFolders(cat)) jobs.push({cat,folder});
  const listed=await mapLimit(jobs,CONCURRENCY,async j=>({j,list:await getJson(j.folder,GH_TIMEOUT_MS)}),deadline);
  const files=[];
  for(const x of listed){if(!x?.list||!Array.isArray(x.list))continue;for(const f of x.list.filter(v=>v.type==='file'&&/\.js$/i.test(v.name)))files.push({cat:x.j.cat,folder:x.j.folder,name:f.name});}
  const loaded=await mapLimit(files,CONCURRENCY,async f=>{
    const raw=await getRaw(`${f.folder}/${f.name}`,GH_TIMEOUT_MS); const m=analyzeCode(raw,{filename:f.name,category:f.cat.id}); m.sourceFolder=f.folder; return m;
  },deadline);
  const metas=loaded.filter(x=>x&&x.id&&!x.error&&!x.skipped);
  // Add built-ins from deployed settings while there is time. Failure does not break health checking.
  const base=process.env.URL||process.env.DEPLOY_PRIME_URL||'';
  if(base && Date.now()<deadline-3000){
    try{
      const sr=await fetchTimeout(base.replace(/\/$/,'')+'/src/settings.json',{headers:{'X-Lianix-Health-Check':'1'}},2500);
      if(sr.ok){const settings=await sr.json();for(const cat of settings.categories||[])for(const it of cat.items||[]){const id=String(it.path||it.name||'').replace(/^\/api\//,'').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');metas.push({id,name:it.name||id,endpoint:it.path,method:it.method||'GET',inputs:(it.params||[]).map(x=>({name:x.key||x.name,type:x.type||'text',required:x.required===true,options:x.options}))});}}
    }catch{}
  }
  return [...new Map(metas.map(m=>[m.id,m])).values()];
}
async function runHealthCheck(event){
  connectBlobs(event);
  const started=Date.now(), deadline=started+TOTAL_BUDGET_MS, store=makeStore('f24nt-api-health');
  try{
    const metas=await discoverMetas(deadline);
    const checked=await mapLimit(metas,CONCURRENCY,async m=>check(m),deadline);
    const results=checked.filter(x=>x&&x.apiId&&!x.skipped);
    await Promise.allSettled(results.map(r=>store.setJSON(r.apiId,r)));
    const partial=results.length<metas.length;
    return{statusCode:200,headers:{'Content-Type':'application/json'},body:JSON.stringify({success:true,checked:results.length,total:metas.length,partial,durationMs:Date.now()-started,data:results})};
  }catch(e){
    return{statusCode:500,headers:{'Content-Type':'application/json'},body:JSON.stringify({success:false,error:e.message,durationMs:Date.now()-started})};
  }
}
module.exports.runHealthCheck=runHealthCheck;
exports.handler=async(event)=>runHealthCheck(event);
