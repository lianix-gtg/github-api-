const crypto=require('node:crypto');
function ip(event){return String(event?.headers?.['x-nf-client-connection-ip']||event?.headers?.['x-forwarded-for']||event?.headers?.['client-ip']||'').split(',')[0].trim().slice(0,80)}
function ua(event){return String(event?.headers?.['user-agent']||'').slice(0,300)}
function fp(event,body={}){return String(body.fingerprint||event?.headers?.['x-lianix-fingerprint']||'').replace(/[^a-zA-Z0-9._:-]/g,'').slice(0,160)}
function now(){return new Date().toISOString()}
function rid(){return `${Date.now()}-${crypto.randomBytes(4).toString('hex')}`}
module.exports={ip,ua,fp,now,rid};
