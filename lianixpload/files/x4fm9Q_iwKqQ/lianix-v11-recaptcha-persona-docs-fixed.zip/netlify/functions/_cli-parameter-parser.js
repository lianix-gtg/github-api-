function cleanName(s){return String(s||'').trim().replace(/^--?/,'').replace(/[^A-Za-z0-9_$-]/g,'').replace(/-([a-z])/g,(_,c)=>c.toUpperCase())}
function infer(name, hint=''){
  const x=(String(name)+' '+String(hint)).toLowerCase();
  if(/proxy-file|folder|directory/.test(x)) return /folder|directory/.test(x)?'folder':'file';
  if(/(?:^|\s)(url|link|uri)|url|link/.test(x)) return 'url';
  if(/image|photo|gambar|img/.test(x)) return /url|link/.test(x)?'url':'image';
  if(/audio|voice|music|mp3/.test(x)) return /url|link/.test(x)?'url':'audio';
  if(/video|mp4|movie/.test(x)) return /url|link/.test(x)?'url':'video';
  if(/count|jumlah|conc|concurrency|limit|width|height|size|timeout|page|quality\s*\d/.test(x)) return 'number';
  if(/^(out|output|outputfile|outfile)$/i.test(String(name||''))) return 'text';
  if(/file|cookie-file|input-file/.test(x)) return 'file';
  return 'text';
}
function parseDefault(desc){
  const m=String(desc||'').match(/default\s*[:=]?\s*([^,;)\n]+)/i)||String(desc||'').match(/bawaan\s*[:=]?\s*([^,;)\n]+)/i);
  if(!m)return undefined;let v=m[1].trim().replace(/^['"]|['"]$/g,'');
  if(/^\d+(?:\.\d+)?$/.test(v))return Number(v);return v;
}
function enumChoices(desc){
  const s=String(desc||'');
  const m=s.match(/\b([\w-]+(?:\s*\|\s*[\w-]+){1,8})\b/);
  if(!m)return[];return m[1].split('|').map(x=>x.trim()).filter(Boolean);
}
function parseCliText(text){
  text=String(text||''); const out=[]; const commands=[]; const seen=new Map();
  const add=p=>{if(!p?.name)return;const old=seen.get(p.name)||{};seen.set(p.name,{...old,...p,required:Boolean(old.required||p.required),choices:[...new Set([...(old.choices||[]),...(p.choices||[])])].filter(Boolean)})};
  for(const line of text.split(/\r?\n/)){
    const cmd=line.match(/(?:node\s+\S+\s+)([A-Za-z][\w-]*)(?:\s|$)/);if(cmd&&!['node'].includes(cmd[1]))commands.push(cmd[1]);
    const m=line.match(/^\s*(?:(-[A-Za-z0-9]),?\s*)?(--[A-Za-z][\w-]*)(?:\s+(<[^>]+>|\[[^\]]+\]|"[^"]*"|'[^']*'))?\s*(.*)$/);
    if(m){
      const name=cleanName(m[2]),hint=m[3]||'',desc=m[4]||'';const def=parseDefault(desc);const choices=enumChoices(desc);let type=infer(name,`${hint} ${desc}`);if(choices.length>=2)type='select';
      add({name,type,required:false,default:def,choices,placeholder:hint.replace(/[<>\[\]'" ]/g,' ') .trim(),source:'cli-help',aliases:[m[1],m[2]].filter(Boolean),description:desc.trim()});
    }
  }
  const uniqueCmd=[...new Set(commands.filter(x=>!['opsi','options'].includes(x.toLowerCase())))];
  if(uniqueCmd.length>=2)add({name:'command',type:'select',required:true,choices:uniqueCmd,source:'cli-help',description:'Perintah CLI yang akan dijalankan'});
  // positional arguments from command usage: convert '<cookie>' / check '<cookie>'
  const positional=new Map();
  for(const line of text.split(/\r?\n/)){
    const m=line.match(/node\s+\S+\s+([\w-]+)\s+([^#\n]+)/);if(!m)continue;
    const command=m[1]; const pos=[...m[2].matchAll(/[<'"]([A-Za-z][\w-]*)[>'"]/g)].map(x=>x[1]);
    for(const p of pos)if(!/jumlah|count|n/i.test(p)){const k=cleanName(p),a=positional.get(k)||[];a.push(command);positional.set(k,a)}
  }
  for(const [p,commands] of positional)add({name:p,type:infer(p),required:false,conditionalRequired:true,requiredWhen:{command:[...new Set(commands)]},source:'cli-help',description:`Wajib jika command: ${[...new Set(commands)].join(', ')}.`});
  return [...seen.values()];
}

function jsdocType(raw,name,desc=''){
  const t=String(raw||'').toLowerCase();
  if(/number|int|float|double/.test(t))return'number';
  if(/boolean|bool/.test(t))return'select';
  if(/file|buffer|blob|stream/.test(t))return infer(name,`${raw} ${desc}`);
  if(/array/.test(t))return'textarea';
  return infer(name,`${raw} ${desc}`);
}
function parseJSDocParams(code){
  const src=String(code||''), out=[];
  const blocks=[...src.matchAll(/\/\*\*[\s\S]*?\*\//g)].map(m=>m[0]);
  for(const block of blocks){
    const rows=block.split(/\r?\n/).map(x=>x.replace(/^\s*\*?\s?/,'').trim());
    for(let i=0;i<rows.length;i++){
      const row=rows[i];
      const m=row.match(/^@param\s+(?:\{([^}]+)\}\s*)?(\[[^\]]+\]|[^\s]+)(?:\s*[-–]\s*|\s+)?(.*)$/i);
      if(!m)continue;
      const typeRaw=m[1]||'', token=m[2].trim(); let desc=(m[3]||'').trim();
      // Continue description lines until the next @tag.
      for(let j=i+1;j<rows.length&&!/^@\w+\b/.test(rows[j]);j++){if(rows[j]&&rows[j]!=='/')desc+=(desc?' ':'')+rows[j]}
      const optional=token.startsWith('[')&&token.endsWith(']');
      let inner=optional?token.slice(1,-1):token;
      let def;
      const eq=inner.indexOf('=');
      if(eq>=0){const rawDef=inner.slice(eq+1).trim();inner=inner.slice(0,eq).trim();if(rawDef){def=/^-?\d+(?:\.\d+)?$/.test(rawDef)?Number(rawDef):rawDef.replace(/^['"]|['"]$/g,'')}}
      // Flatten options.count -> count. A bare Object parent is a container, not a user field,
      // when nested children are documented in the same JSDoc block.
      const parts=inner.split('.').filter(Boolean);const name=cleanName(parts[parts.length-1]||inner);if(!name)continue;
      const hasChildren=rows.some(x=>new RegExp(`^@param\\s+(?:\\{[^}]+\\}\\s*)?\\[?${inner.replace(/[.*+?^${}()|[\\]\\\\]/g,'\\$&')}\\.`,'i').test(x));
      if(/^(object|record|map)$/i.test(typeRaw.trim())&&parts.length===1&&hasChildren)continue;
      const choices=enumChoices(desc); let type=jsdocType(typeRaw,name,desc);if(choices.length>=2)type='select';
      if(/boolean|bool/i.test(typeRaw)&&!choices.length){type='select';choices.push('true','false')}
      const describedDefault=parseDefault(desc);if(def===undefined&&describedDefault!==undefined)def=describedDefault;
      const conditional=/\b(?:untuk|when|jika)\s+(?:command\s*)?(?:=|:)?\s*([\w-]+(?:\s*(?:\/|\||,|atau|or)\s*[\w-]+)+)/i.exec(desc);
      const requiredWhen=conditional?{command:conditional[1].split(/\s*(?:\/|\||,|atau|or)\s*/i).filter(Boolean)}:undefined;
      out.push({name,type,required:!optional,default:def,choices,source:'jsdoc',description:desc,...(requiredWhen?{required:false,conditionalRequired:true,requiredWhen}:{}),jsdocPath:inner});
    }
  }
  return out;
}

function parseParameterComments(code){
  const out=[]; const src=String(code||'');
  const lines=src.split(/\r?\n/).slice(0,140);
  for(const line of lines){
    const m=line.match(/\bparameters?\s*:\s*(.+)$/i);if(!m)continue;
    for(const raw of m[1].split(/[,;]+/)){
      const item=raw.trim().replace(/\*\/?$/,'').trim();if(!item)continue;
      const parts=item.split(/\s*[:|]\s*/);const name=cleanName(parts[0]);if(!name)continue;
      const detail=parts.slice(1).join(' ');const optional=/optional|opsional|tidak wajib/i.test(detail),required=/required|wajib/i.test(detail)&&!optional;
      let type=infer(name,detail);for(const t of ['url','number','select','file','image','audio','video','folder','textarea','text'])if(new RegExp(`\\b${t}\\b`,'i').test(detail)){type=t;break}
      const def=parseDefault(detail),choices=enumChoices(detail);out.push({name,type,required,default:def,choices,source:'comment',description:detail});
    }
  }
  return out;
}
function mergeInputs(...groups){
  const map=new Map();
  const priority={ai:1,ast:2,'cli-help':3,embedded:4,jsdoc:5,comment:6};
  for(const group of groups)for(const p of group||[]){
    if(!p?.name)continue;const old=map.get(p.name)||{};const newPri=priority[p.source]||0,oldPri=priority[old.source]||0,useNew=newPri>=oldPri;
    const merged={...old,...(useNew?p:{})};
    // Explicit higher-priority docs are allowed to turn an AST-required guess into optional.
    if(useNew&&typeof p.required==='boolean')merged.required=p.required;else if(typeof old.required==='boolean')merged.required=old.required;else merged.required=Boolean(p.required);
    if(useNew&&p.conditionalRequired!==undefined)merged.conditionalRequired=Boolean(p.conditionalRequired);else if(old.conditionalRequired!==undefined)merged.conditionalRequired=Boolean(old.conditionalRequired);else merged.conditionalRequired=Boolean(p.conditionalRequired);
    if(useNew&&p.requiredWhen)merged.requiredWhen=p.requiredWhen;
    merged.choices=[...new Set([...(old.choices||[]),...(p.choices||[])])].filter(Boolean);
    if(merged.choices.length>=2&&(!merged.type||merged.type==='text'))merged.type='select';map.set(p.name,merged)
  }
  return [...map.values()];
}
module.exports={parseCliText,parseJSDocParams,parseParameterComments,mergeInputs};
