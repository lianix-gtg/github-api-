const { OWNER, REPO, BRANCH, request } = require('./_github');

const HEADERS = {
  'Content-Type': 'application/json; charset=utf-8',
  'Cache-Control': 'no-store, no-cache, must-revalidate',
  'Access-Control-Allow-Origin': '*'
};
function isApiRelevant(path = '') {
  const p = String(path).replace(/^\/+/, '');
  if (!p) return true;
  if (p === 'registry.json' || p === 'package.json') return true;
  if (/^(ai|downloader|tools|canvas|canvasweb|random)\//i.test(p)) return true;
  return false; // lianixpload/* and docs/assets do not force API-card reload
}

exports.handler = async function(event) {
  if (event.httpMethod === 'OPTIONS') return { statusCode: 204, headers: HEADERS, body: '' };
  if (event.httpMethod !== 'GET') return { statusCode: 405, headers: HEADERS, body: JSON.stringify({ ok:false, error:'Method not allowed' }) };
  try {
    const url = `https://api.github.com/repos/${encodeURIComponent(OWNER)}/${encodeURIComponent(REPO)}/commits/${encodeURIComponent(BRANCH)}`;
    const res = await request(url, {}, 6000);
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data.sha) throw new Error(data.message || `GitHub HTTP ${res.status}`);
    const files = Array.isArray(data.files) ? data.files.map(x => String(x.filename || '')).filter(Boolean) : [];
    return { statusCode: 200, headers: HEADERS, body: JSON.stringify({
      ok:true,
      sha:String(data.sha),
      apiRelevant: files.length === 0 ? true : files.some(isApiRelevant),
      changedFiles: files.slice(0, 30),
      repository:{ owner:OWNER, repo:REPO, branch:BRANCH },
      checkedAt:Date.now()
    }) };
  } catch (error) {
    console.error('[github-state]', error);
    return { statusCode: 502, headers: HEADERS, body: JSON.stringify({ ok:false, error:error.message || String(error) }) };
  }
};
