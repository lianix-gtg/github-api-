// netlify/functions/fakegc.js
// Generate fake WhatsApp iOS group chat image
// Client kirim: POST /api/fakegc multipart/form-data: image(file), name(text), members(text)

const https = require('https');
const http = require('http');
const { createCanvas, loadImage, GlobalFonts } = require('@napi-rs/canvas');
const path = require('path');
const fs = require('fs');
const os = require('os');

function cors() {
    return { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'POST,OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type' };
}
function json(code, body) {
    return { statusCode: code, headers: { ...cors(), 'Content-Type': 'application/json' }, body: JSON.stringify(body) };
}

const BG_URL = 'https://raw.githubusercontent.com/ryyntwx/Image-rinn/refs/heads/main/IMG-20260825-WA0312.jpg';
const UA = 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36';

function parseMultipart(bodyBuffer, contentType) {
    const boundaryMatch = /boundary=(?:"([^"]+)"|([^;]+))/i.exec(contentType || '');
    const boundary = boundaryMatch ? (boundaryMatch[1] || boundaryMatch[2]) : null;
    if (!boundary) throw new Error('Boundary tidak ditemukan');
    const boundaryBuf = Buffer.from('--' + boundary);
    const parts = [];
    let start = bodyBuffer.indexOf(boundaryBuf);
    while (start !== -1) {
        const next = bodyBuffer.indexOf(boundaryBuf, start + boundaryBuf.length);
        if (next === -1) break;
        parts.push(bodyBuffer.slice(start + boundaryBuf.length, next));
        start = next;
    }
    const fields = {};
    for (const part of parts) {
        const headerEnd = part.indexOf('\r\n\r\n');
        if (headerEnd === -1) continue;
        const headerStr = part.slice(0, headerEnd).toString('utf-8');
        let content = part.slice(headerEnd + 4);
        if (content.slice(-2).toString() === '\r\n') content = content.slice(0, -2);
        const nameMatch = /name="([^"]+)"/i.exec(headerStr);
        if (!nameMatch) continue;
        const key = nameMatch[1];
        const filenameMatch = /filename="([^"]*)"/i.exec(headerStr);
        const ctMatch = /Content-Type:\s*([^\r\n]+)/i.exec(headerStr);
        if (filenameMatch) {
            fields[key] = { buffer: content, filename: filenameMatch[1], contentType: ctMatch ? ctMatch[1].trim() : 'application/octet-stream' };
        } else {
            fields[key] = content.toString('utf-8');
        }
    }
    return fields;
}

function httpGetBinary(url) {
    return new Promise((resolve, reject) => {
        const lib = url.startsWith('https') ? https : http;
        const req = lib.get(url, { headers: { 'User-Agent': UA } }, res => {
            if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
                return resolve(httpGetBinary(res.headers.location));
            }
            const chunks = [];
            res.on('data', c => chunks.push(c));
            res.on('end', () => resolve(Buffer.concat(chunks)));
        });
        req.on('error', reject);
        req.setTimeout(15000, () => { req.destroy(); reject(new Error('Timeout')); });
    });
}

const FONT_URL = 'https://fonts.gstatic.com/s/inter/v13/UcC73FwrK3iLTeHuS_fvQtMwCp50KnMa1ZL7W0Q5nw.woff2';
const CACHE_DIR = '/tmp/lianix_canvas_cache';

async function ensureFont() {
    if (!fs.existsSync(CACHE_DIR)) fs.mkdirSync(CACHE_DIR, { recursive: true });
    const fontPath = path.join(CACHE_DIR, 'Inter.woff2');
    if (!fs.existsSync(fontPath)) {
        const buf = await httpGetBinary(FONT_URL);
        fs.writeFileSync(fontPath, buf);
    }
    GlobalFonts.registerFromPath(fontPath, 'Inter');
}

async function ensureBg() {
    const bgPath = path.join(CACHE_DIR, 'fakegc_bg.jpg');
    if (!fs.existsSync(bgPath)) {
        const buf = await httpGetBinary(BG_URL);
        fs.writeFileSync(bgPath, buf);
    }
    return bgPath;
}

exports.handler = async (event) => {
    if (event.httpMethod === 'OPTIONS') return { statusCode: 204, headers: cors(), body: '' };
    if (event.httpMethod !== 'POST') return json(405, { status: false, error: 'Method not allowed' });

    try {
        const bodyBuffer = Buffer.from(event.body, event.isBase64Encoded ? 'base64' : 'utf-8');
        const ct = event.headers['content-type'] || '';
        const fields = parseMultipart(bodyBuffer, ct);

        const name = fields.name;
        const members = fields.members;
        const imageField = fields.image;

        if (!name || !members || !imageField?.buffer) {
            return json(400, { status: false, error: 'Parameter wajib: image (file), name, members' });
        }

        await ensureFont();
        const bgPath = await ensureBg();

        const bgImg = await loadImage(fs.readFileSync(bgPath));
        const ppImg = await loadImage(imageField.buffer);

        const canvas = createCanvas(bgImg.width, bgImg.height);
        const ctx = canvas.getContext('2d');
        ctx.drawImage(bgImg, 0, 0, canvas.width, canvas.height);

        // Profile picture circle
        ctx.save();
        ctx.beginPath();
        ctx.arc(538, 362, 162, 0, Math.PI * 2, true);
        ctx.closePath();
        ctx.clip();
        ctx.drawImage(ppImg, 538 - 162, 362 - 162, 162 * 2, 162 * 2);
        ctx.restore();

        // Group name
        ctx.fillStyle = '#FFFFFF';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.font = '900 64px Inter, sans-serif';
        ctx.fillText(name, 540, 602);

        // Member count
        const prefix = 'Grup • ';
        ctx.font = '500 37px Inter, sans-serif';
        const prefixW = ctx.measureText(prefix).width;
        const totalW = prefixW + ctx.measureText(members).width;
        const startX = 548 - totalW / 2;

        ctx.fillStyle = '#8E8E93';
        ctx.textAlign = 'left';
        ctx.fillText(prefix, startX, 684);

        ctx.fillStyle = '#34C759';
        ctx.fillText(members, startX + prefixW, 684);

        const pngBuf = await canvas.encode('png');
        return {
            statusCode: 200,
            headers: { ...cors(), 'Content-Type': 'image/png', 'Content-Disposition': 'inline; filename="fakegc.png"' },
            body: pngBuf.toString('base64'),
            isBase64Encoded: true
        };
    } catch (err) {
        return json(500, { status: false, error: err.message });
    }
};


// LIANIX_USAGE_WRAPPER_V7
const { wrapHandler: __wrapLianixUsage } = require('./_usage');
exports.handler = __wrapLianixUsage(exports.handler, { apiId: 'fakegc', name: 'fakegc' });

// Lianix per-user public API key guard
const { withPublicApiKey } = require('./_user-api-key');
exports.handler = withPublicApiKey(exports.handler);
