// netlify/functions/pinvideo.js
// Cari video di Pinterest berdasarkan kata kunci.
// Client panggil: /api/pinvideo?q=<keyword>

function json(statusCode, cors, body) {
  return { statusCode, headers: { ...cors, "Content-Type": "application/json" }, body: JSON.stringify(body) };
}

const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0";

function parseCookies(setCookieHeaders) {
  if (!setCookieHeaders) return "";
  const parts = Array.isArray(setCookieHeaders) ? setCookieHeaders : [setCookieHeaders];
  return parts.map(c => c.split(";")[0]).join("; ");
}

async function searchPinterestVideos(q) {
  const initRes = await fetch("https://id.pinterest.com/", {
    headers: {
      "user-agent": UA,
      accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
      "accept-language": "en-US,en;q=0.9"
    }
  });
  const cookieString = parseCookies(initRes.headers.get("set-cookie"));

  const sourceUrl = "/search/videos/?q=" + encodeURIComponent(q) + "&rs=content_type_filter&filter_location=1";
  const dataPayload = JSON.stringify({
    options: {
      query: q, scope: "videos", appliedProductFilters: "---", domains: null, user: null,
      seoDrawerEnabled: false, applied_unified_filters: null, auto_correction_disabled: false,
      journey_depth: null, source_id: null, source_module_id: null, source_url: sourceUrl,
      static_feed: false, selected_one_bar_modules: null, query_pin_sigs: null, page_size: null,
      price_max: null, price_min: null, query_image_pins: null, request_params: null,
      top_pin_ids: null, article: null, corpus: null, customized_rerank_type: null,
      filters: null, rs: "content_type_filter", redux_normalize_feed: true
    },
    context: {}
  });

  const searchUrl = "https://id.pinterest.com/resource/BaseSearchResource/get/?source_url=" +
    encodeURIComponent(sourceUrl) + "&data=" + encodeURIComponent(dataPayload) + "&_=" + Date.now();

  const searchRes = await fetch(searchUrl, {
    headers: {
      "user-agent": UA,
      accept: "application/json, text/javascript, */*; q=0.01",
      "accept-language": "en-US,en;q=0.9",
      referer: "https://id.pinterest.com/search/videos/?q=" + encodeURIComponent(q) + "&rs=content_type_filter&filter_location=1",
      "x-requested-with": "XMLHttpRequest",
      "x-app-version": "8048c97",
      "x-pinterest-appstate": "active",
      "x-pinterest-source-url": sourceUrl,
      "x-pinterest-pws-handler": "www/search/[scope].js",
      cookie: cookieString
    }
  });

  const raw = await searchRes.text();
  let data;
  try { data = JSON.parse(raw); } catch (e) { throw new Error("Respons Pinterest tidak valid"); }

  const results = data?.resource_response?.data?.results || [];
  const videos = results
    .filter(p => p.videos?.video_list)
    .map(p => {
      const vList = p.videos.video_list;
      const videoUrl = vList.V_HLSV4?.url || vList.V_HLSV3_MOBILE?.url || null;
      return {
        id: p.id,
        title: p.grid_title || p.title || null,
        description: p.description || null,
        video: videoUrl,
        thumbnail: p.images?.orig?.url || null,
        duration: p.videos?.duration || null,
        link: "https://www.pinterest.com/pin/" + p.id,
        pinner: p.pinner?.full_name || null,
        username: p.pinner?.username || null,
        likes: p.reaction_counts?.["1"] || 0
      };
    })
    .filter(p => p.video);

  return {
    status: data?.resource_response?.status === "success",
    total: videos.length,
    result: videos
  };
}

exports.handler = async (event) => {
  const cors = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type"
  };
  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers: cors, body: "" };

  const qs = event.queryStringParameters || {};
  const q = (qs.q || "").trim();
  if (!q) return json(400, cors, { status: false, error: "Parameter ?q= wajib diisi (kata kunci pencarian)" });

  try {
    const out = await searchPinterestVideos(q);
    return json(out.status ? 200 : 502, cors, {
      status: out.status,
      input: q,
      total: out.total,
      result: out.result,
      error: out.status ? undefined : "Gagal mengambil hasil dari Pinterest, coba lagi."
    });
  } catch (err) {
    return json(500, cors, { status: false, input: q, error: err.message });
  }
};


// LIANIX_USAGE_WRAPPER_V7
const { wrapHandler: __wrapLianixUsage } = require('./_usage');
exports.handler = __wrapLianixUsage(exports.handler, { apiId: 'pinvideo', name: 'pinvideo' });

// Lianix per-user public API key guard
const { withPublicApiKey } = require('./_user-api-key');
exports.handler = withPublicApiKey(exports.handler);
