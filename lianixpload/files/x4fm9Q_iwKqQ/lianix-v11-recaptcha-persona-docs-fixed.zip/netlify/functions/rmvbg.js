// netlify/functions/rmvbg.js
// Hapus background gambar dari URL via xmz-rmvbg.vercel.app, hasil diupload ke CDN
// Client kirim: GET /api/rmvbg?url=<IMAGE_URL>

const https = require('https');
const http = require('http');

function cors() {
    return {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET,OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type'
    };
}
function json(code, body) {
    return { statusCode: code, headers: { ...cors(), 'Content-Type': 'application/json' }, body: JSON.stringify(body) };
}

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

function httpGetBinary(url) {
    return new Promise((resolve, reject) => {
        const lib = url.startsWith('https') ? https : http;
        const req = lib.get(url, { headers: { 'User-Agent': UA } }, res => {
            const chunks = [];
            res.on('data', c => chunks.push(c));
            res.on('end', () => resolve(Buffer.concat(chunks)));
        });
        req.on('error', reject);
        req.setTimeout(15000, () => { req.destroy(); reject(new Error('Download timeout')); });
    });
}

function postMultipart(url, fileBuffer, filename, contentType) {
    const boundary = '----RmvBgBoundary' + Date.now();
    const header = Buffer.from(
        `--${boundary}\r\nContent-Disposition: form-data; name="file"; filename="${filename}"\r\nContent-Type: ${contentType}\r\n\r\n`
    );
    const footer = Buffer.from(`\r\n--${boundary}--\r\n`);
    const body = Buffer.concat([header, fileBuffer, footer]);

    return new Promise((resolve, reject) => {
        const u = new URL(url);
        const opts = {
            hostname: u.hostname, path: u.pathname,
            method: 'POST',
            headers: {
                'Content-Type': `multipart/form-data; boundary=${boundary}`,
                'Content-Length': body.length,
                'User-Agent': UA
            }
        };
        const lib = u.protocol === 'https:' ? https : http;
        const req = lib.request(opts, res => {
            const chunks = [];
            res.on('data', c => chunks.push(c));
            res.on('end', () => resolve(Buffer.concat(chunks).toString()));
        });
        req.on('error', reject);
        req.setTimeout(40000, () => { req.destroy(); reject(new Error('Remove BG timeout')); });
        req.write(body);
        req.end();
    });
}

function postMultipartUpload(url, fileBuffer, filename) {
    const boundary = '----UploadBoundary' + Date.now();
    const header = Buffer.from(
        `--${boundary}\r\nContent-Disposition: form-data; name="file"; filename="${filename}"\r\nContent-Type: image/png\r\n\r\n`
    );
    const footer = Buffer.from(`\r\n--${boundary}--\r\n`);
    const body = Buffer.concat([header, fileBuffer, footer]);

    return new Promise((resolve, reject) => {
        const u = new URL(url);
        const opts = {
            hostname: u.hostname, path: u.pathname,
            method: 'POST',
            headers: {
                'Content-Type': `multipart/form-data; boundary=${boundary}`,
                'Content-Length': body.length,
                'User-Agent': UA
            }
        };
        const lib = u.protocol === 'https:' ? https : http;
        const req = lib.request(opts, res => {
            const chunks = [];
            res.on('data', c => chunks.push(c));
            res.on('end', () => resolve(Buffer.concat(chunks).toString()));
        });
        req.on('error', reject);
        req.setTimeout(30000, () => { req.destroy(); reject(new Error('Upload timeout')); });
        req.write(body);
        req.end();
    });
}

exports.handler = async (event) => {
    if (event.httpMethod === 'OPTIONS') return { statusCode: 204, headers: cors(), body: '' };
    if (event.httpMethod !== 'GET') return json(405, { status: false, error: 'Method not allowed' });

    const qs = event.queryStringParameters || {};
    const imageUrl = qs.url;
    if (!imageUrl) return json(400, { status: false, error: "Parameter 'url' wajib diisi" });

    try {
        // 1. Download image
        const imageBuffer = await httpGetBinary(imageUrl);
        const originalSizeKb = parseFloat((imageBuffer.length / 1024).toFixed(1));

        // 2. Remove background
        const rmRaw = await postMultipart('https://xmz-rmvbg.vercel.app/api/remove', imageBuffer, 'original.png', 'image/png');
        let rmData;
        try { rmData = JSON.parse(rmRaw); } catch { return json(502, { status: false, error: 'Remove BG response invalid' }); }
        if (!rmData?.success || !rmData?.result) return json(502, { status: false, error: 'Remove BG gagal: ' + (rmData?.message || 'unknown') });

        const noBgBuffer = Buffer.from(rmData.result, 'base64');
        const noBgSizeKb = parseFloat((noBgBuffer.length / 1024).toFixed(1));

        // 3. Upload result
        const upRaw = await postMultipartUpload('https://cdnn.ikyyxd.my.id/api/upload.php', noBgBuffer, 'no-bg-result.png');
        let upData;
        try { upData = JSON.parse(upRaw); } catch { return json(502, { status: false, error: 'Upload response invalid' }); }

        let directUrl = upData?.result?.url || upData?.url || (typeof upData === 'string' && upData.startsWith('http') ? upData : null);
        if (!directUrl) return json(502, { status: false, error: 'Gagal mendapatkan URL hasil upload', raw: upRaw.slice(0, 200) });

        return json(200, { status: true, originalSizeKb, noBgSizeKb, directUrl });
    } catch (err) {
        return json(502, { status: false, error: err.message });
    }
};


// LIANIX_USAGE_WRAPPER_V7
const { wrapHandler: __wrapLianixUsage } = require('./_usage');
exports.handler = __wrapLianixUsage(exports.handler, { apiId: 'rmvbg', name: 'rmvbg' });

// Lianix per-user public API key guard
const { withPublicApiKey } = require('./_user-api-key');
exports.handler = withPublicApiKey(exports.handler);
