const { mergeInputs } = require('./_cli-parameter-parser');
const JEEVES_URL = 'https://api-faa.my.id/faa/jeeves-ai';
const REWIND_URL = 'https://api.rewind.ai/v1/chat/completions';
const REWIND_MODEL = process.env.AUTODETECT_FREE_MODEL || 'qwen/qwen-2.5-7b-instruct';

function extractText(data){
  if(!data)return''; if(typeof data==='string')return data;
  const keys=['result','response','answer','text','message','content','data'];
  for(const k of keys){const v=data[k];if(typeof v==='string'&&v.trim())return v;if(v&&typeof v==='object'){const x=extractText(v);if(x)return x}}
  return'';
}
function findJson(text){
  text=String(text||'').trim().replace(/^```(?:json)?\s*/i,'').replace(/\s*```$/,'');
  try{return JSON.parse(text)}catch{}
  const starts=[];for(let i=0;i<text.length;i++)if(text[i]==='{')starts.push(i);
  for(const st of starts){let depth=0,quote='',esc=false;for(let i=st;i<text.length;i++){const c=text[i];if(quote){if(esc)esc=false;else if(c==='\\')esc=true;else if(c===quote)quote='';continue}if(c==='"'||c==="'"){quote=c;continue}if(c==='{')depth++;else if(c==='}'){depth--;if(depth===0){try{return JSON.parse(text.slice(st,i+1))}catch{}break}}}}
  return null;
}
function normalizeAiInputs(items){
  if(!Array.isArray(items))return[];
  const validTypes=new Set(['text','textarea','url','number','select','file','image','audio','video','folder']);
  return items.map(p=>{
    const name=String(p?.name||'').trim();if(!name)return null;
    let type=String(p.type||'text').toLowerCase();if(!validTypes.has(type))type='text';
    const out={name,type,required:p.required===true,source:'ai'};
    if(p.default!==undefined&&p.default!==null&&p.default!=='')out.default=p.default;
    if(p.conditionalRequired)out.conditionalRequired=true;
    if(p.requiredWhen&&typeof p.requiredWhen==='object')out.requiredWhen=p.requiredWhen;
    if(Array.isArray(p.choices))out.choices=p.choices.slice(0,30);
    if(p.placeholder)out.placeholder=String(p.placeholder).slice(0,160);
    if(p.description)out.description=String(p.description).slice(0,300);
    return out;
  }).filter(Boolean);
}
function redactSecrets(src){
  let s=String(src||'');
  s=s.replace(/((?:api[_-]?key|token|secret|password|passwd|authorization|cookie)\s*[:=]\s*)(["'`])[^"'`\n]{6,}\2/gi,'$1$2[REDACTED]$2');
  s=s.replace(/\b(?:sk|pk|ghp|github_pat|xox[baprs])-?[A-Za-z0-9_\-]{12,}\b/g,'[REDACTED_TOKEN]');
  s=s.replace(/Bearer\s+[A-Za-z0-9._~+\/-]{10,}/gi,'Bearer [REDACTED]');
  return s;
}
function buildPrompt({code,meta,probe}){
  const help=(probe?.stdout||'').slice(0,6000);
  const codeText=redactSecrets(code);
  const excerpt=(codeText.length<=9000?codeText:codeText.slice(0,6000)+'\n/* ...dipotong... */\n'+codeText.slice(-2500));
  return `Kamu adalah analyzer parameter JavaScript untuk Lianix. Tugasmu HANYA mengoreksi metadata input API/CLI dari kode berikut. Jangan jalankan kode, jangan beri tutorial scraping. Balas JSON valid saja.\n\nAturan tipe: url=link yang diketik; image/audio/video/file/folder=upload binary; number=angka; select=pilihan; text/textarea=teks. Bedakan required, optional, dan conditionalRequired. Jika ada default maka parameter biasanya optional. Jangan mengarang parameter yang tidak didukung kode/help/comment. Untuk CLI, deteksi command, positional arg, short/long flag, default, enum.\n\nJSON schema:\n{"inputs":[{"name":"","type":"text","required":false,"conditionalRequired":false,"default":"","choices":[],"description":""}],"notes":[],"confidence":0}\n\nHasil analyzer statis saat ini:\n${JSON.stringify({inputs:meta?.inputs||[],dependencies:meta?.dependencies||[],method:meta?.method,endpoint:meta?.endpoint},null,2)}\n\nOutput safe --help probe (jika ada):\n${help||'(tidak ada)'}\n\nKode (secret sudah disensor):\n${excerpt}`;
}
function parsedReview(txt,provider){
  const parsed=findJson(txt);if(!parsed)return{ok:false,provider,error:`Respons ${provider} tidak berisi JSON metadata yang valid.`};
  const inputs=normalizeAiInputs(parsed.inputs);
  return{ok:true,provider,inputs,notes:Array.isArray(parsed.notes)?parsed.notes.slice(0,12):[],confidence:Number(parsed.confidence)||0,rawPreview:String(txt||'').slice(0,600)};
}
async function reviewWithJeeves({code,meta,probe,timeoutMs=8000}){
  const prompt=buildPrompt({code,meta,probe});
  try{
    const u=JEEVES_URL+'?prompt='+encodeURIComponent(prompt);
    const r=await fetch(u,{headers:{Accept:'application/json','User-Agent':'Lianix-AutoDetect/1.1'},signal:AbortSignal.timeout(timeoutMs)});
    if(!r.ok)return{ok:false,provider:'Jeeves',error:`Jeeves HTTP ${r.status}`};
    const ct=r.headers.get('content-type')||'';const raw=ct.includes('json')?await r.json():await r.text();
    const txt=extractText(raw)||String(raw||'');return parsedReview(txt,'Jeeves');
  }catch(e){return{ok:false,provider:'Jeeves',error:e?.name==='TimeoutError'?'Jeeves timeout':(e?.message||String(e))}}
}
async function reviewWithFreeAI({code,meta,probe,timeoutMs=9000}){
  const prompt=buildPrompt({code,meta,probe});
  try{
    const r=await fetch(REWIND_URL,{method:'POST',headers:{'Content-Type':'application/json','Accept':'text/event-stream, application/json','User-Agent':'Lianix-AutoDetect/1.1','Origin':'https://rewind.ai','Referer':'https://rewind.ai/'},body:JSON.stringify({model:REWIND_MODEL,messages:[{role:'user',content:prompt}],stream:true}),signal:AbortSignal.timeout(timeoutMs)});
    if(!r.ok)return{ok:false,provider:'Free Qwen',error:`Free AI HTTP ${r.status}`};
    const ct=r.headers.get('content-type')||'';
    if(ct.includes('application/json')){
      const j=await r.json(); const txt=j?.choices?.[0]?.message?.content||extractText(j); return parsedReview(txt,'Free Qwen');
    }
    const text=await r.text(); let full='';
    for(const line of text.split(/\r?\n/)){
      const t=line.trim(); if(!t.startsWith('data:')||t==='data: [DONE]')continue;
      try{const j=JSON.parse(t.slice(5).trim());full+=j?.choices?.[0]?.delta?.content||j?.choices?.[0]?.message?.content||''}catch{}
    }
    return parsedReview(full||text,'Free Qwen');
  }catch(e){return{ok:false,provider:'Free Qwen',error:e?.name==='TimeoutError'?'Free AI timeout':(e?.message||String(e))}}
}
async function reviewWithFallback(opts){
  const attempts=[];
  const j=await reviewWithJeeves(opts);attempts.push({provider:j.provider||'Jeeves',ok:j.ok,error:j.error||''});
  if(j.ok)return{...j,attempts,fallbackUsed:false};
  const f=await reviewWithFreeAI(opts);attempts.push({provider:f.provider||'Free Qwen',ok:f.ok,error:f.error||''});
  if(f.ok)return{...f,attempts,fallbackUsed:true};
  return{ok:false,provider:'local',error:'Semua AI reviewer tidak tersedia.',attempts,fallbackUsed:true,inputs:[],notes:[],confidence:0};
}
function mergeJeeves(staticInputs,aiInputs){return mergeInputs(aiInputs||[],staticInputs||[])}
module.exports={reviewWithJeeves,reviewWithFreeAI,reviewWithFallback,mergeJeeves,redactSecrets};
