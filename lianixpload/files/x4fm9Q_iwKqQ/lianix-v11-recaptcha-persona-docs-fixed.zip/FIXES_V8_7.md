# Lianix V8.7 — Netfgen parameter compatibility

- Netfgen live source was inspected directly from `tools/netfgen.js`.
- Stale embedded metadata such as `auto -n <jumlah>` is ignored when AST/CLI detection finds a richer schema.
- Netfgen web defaults: `command=auto`, `count=5`, `out=tokens.txt`, `conc=25`.
- `plan`, `proxyFile`, `proxy`, and `ua` are optional.
- `cookie` is only conditionally required for `convert` and `check`.
- Analyzer tolerates legacy metadata placed above a Node hashbang.
- Admin publisher now preserves `#!/usr/bin/env node` as the first line and writes `@lianix-meta` after it.
