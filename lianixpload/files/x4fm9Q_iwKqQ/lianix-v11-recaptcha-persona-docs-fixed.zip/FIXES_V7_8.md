# Lianix V7.8 — Auto Detect + Jeeves Review

## Auto Detect pipeline
1. Parse embedded `@lianix-meta`.
2. Parse top-of-file `parameter:` comments.
3. Parse JavaScript AST.
4. Parse CLI help/usage (`process.argv` style tools).
5. Run an isolated `--help` Safe Probe when the OS sandbox is available.
6. Ask Jeeves AI to review the static result. Jeeves is advisory: evidence from code/help/comments wins.
7. Merge required, optional, default, conditional required, choices, type, dependencies.
8. Admin must still run Test before Publish.

## Optional parameters
Optional parameters may be left empty. Blank optional values are omitted from Runtime Probe instead of being sent as empty strings, so the scraper's own defaults continue to work.

Conditional inputs can carry `requiredWhen`, e.g. `cookie` is optional globally but required when `command` is `convert` or `check`.

## CLI example
For the NFTOKEN-style help text used during validation, the expected result is:
- `command`: required select: test, stats, auto, convert, check
- `cookie`: optional globally, conditionally required for convert/check
- `proxyFile`: optional file
- `proxy`: optional text
- `ua`: optional text
- `count`: optional number, default 5
- `plan`: optional select: premium, standard, basic
- `out`: optional text path, default tokens.txt
- `conc`: optional number, default 25

## Safe Probe
Safe Probe does not intentionally run a scraper with production credentials. It attempts `--help` inside a separate Linux user/network namespace with Node permission mode, sanitized environment, no child process/worker permission, no general filesystem permission, and a hard timeout. If this sandbox is unavailable, execution is skipped and the deterministic analyzers + Jeeves review still work.

## Jeeves AI
Admin has a `Jeeves AI review` checkbox enabled by default. The server sends a bounded excerpt, static metadata, and Safe Probe output to the existing Jeeves provider route. If Jeeves times out or returns invalid JSON, Auto Detect does not fail; it keeps the deterministic result and shows a warning.

## Dependencies
Existing dependency detection and GitHub package.json auto-update remain enabled. `axios` and other imported packages are detected independently of parameter analysis.
