# Lianix V8.1 — LianixPload Upload Center

- Added dedicated `/upload` page with drag/drop, real XHR upload progress, short-link result, copy/open actions, and local recent history.
- Added Upload button to Tools sidebar.
- GitHub is file/object storage only.
- Canonical metadata is stored in Netlify Blobs store `lianixpload-db`.
- Metadata is mirrored to `lianixpload/meta/<id>.json` for recovery and can rehydrate the database record.
- Added `/api/lianixpload/info?id=<id>` for database-backed metadata verification.
- `/f/<id>` now resolves metadata through the database helper before fetching file bytes from GitHub.
- Existing dangerous active-file protections remain enabled.
- Upload route remains protected by shared `X-API-Key: lianix`; public short links do not require the API key.
