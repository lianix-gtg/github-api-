(function () {
  'use strict';
  if (window.__lianixSecurityGuard) return;
  window.__lianixSecurityGuard = true;

  var locked = false;

  function blackout(reason) {
    if (locked) return;
    locked = true;
    try {
      document.documentElement.setAttribute('data-lianix-locked', '1');
      document.documentElement.style.background = '#000';
      document.documentElement.style.colorScheme = 'dark';
      var mount = function () {
        if (!document.body) return setTimeout(mount, 0);
        document.body.innerHTML = '';
        document.body.style.cssText = 'margin:0!important;background:#000!important;overflow:hidden!important;display:block!important;min-height:100vh!important;';
        var cover = document.createElement('div');
        cover.id = 'lianix-security-blackout';
        cover.setAttribute('aria-hidden', 'true');
        cover.style.cssText = 'position:fixed;inset:0;z-index:2147483647;background:#000!important;pointer-events:auto;user-select:none;';
        document.body.appendChild(cover);
      };
      mount();
      try { console.clear(); } catch (_) {}
    } catch (_) {}
  }

  function keyBlocked(e) {
    var key = String(e.key || '').toLowerCase();
    var code = e.keyCode || e.which;
    if (code === 123 || key === 'f12') return true;
    if (e.ctrlKey && e.shiftKey && (key === 'i' || key === 'j' || key === 'c' || key === 'k')) return true;
    if (e.metaKey && e.altKey && (key === 'i' || key === 'j' || key === 'c')) return true;
    if (e.ctrlKey && key === 'u') return true;
    return false;
  }

  document.addEventListener('keydown', function (e) {
    if (!keyBlocked(e)) return;
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    blackout('explicit-devtools-shortcut');
  }, true);

  // Context menu is only blocked. It never blacks out the page because browsers,
  // accessibility tools, touch emulation, and extensions can emit contextmenu events.
  document.addEventListener('contextmenu', function (e) {
    e.preventDefault();
    e.stopPropagation();
  }, true);

  // IMPORTANT: do not infer DevTools from outerWidth/innerWidth, resize, focus,
  // zoom, or timing. Those heuristics create false positives on mobile browsers,
  // PWA windows, browser sidebars, split-screen, and desktop window decorations.
})();
