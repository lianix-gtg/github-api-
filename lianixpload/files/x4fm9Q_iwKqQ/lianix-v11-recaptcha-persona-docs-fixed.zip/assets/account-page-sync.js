(function(){
'use strict';
const map={
  'f24t-c':'chats',
  'f24t-artifacts':'artifacts',
  'lianixpload_history_v1':'uploadHistory',
  'f24t-memory-consent':'memoryConsent',
  'f24t-avatar':'profilePhoto'
};
let ready=false, applying=false, last={};
function parse(v,f){try{return JSON.parse(v)}catch{return f}}
function localValue(k){const v=localStorage.getItem(k);if(k==='f24t-c'||k==='f24t-artifacts'||k==='lianixpload_history_v1')return parse(v,k==='lianixpload_history_v1'?[]:{});return v||''}
function remember(){for(const k of Object.keys(map))last[k]=localStorage.getItem(k)}
async function hydrate(){if(!window.LianixAccountStore)return;try{applying=true;const s=await LianixAccountStore.get();if(s.chats&&Object.keys(s.chats).length)localStorage.setItem('f24t-c',JSON.stringify(s.chats));if(s.artifacts&&Object.keys(s.artifacts).length)localStorage.setItem('f24t-artifacts',JSON.stringify(s.artifacts));if(Array.isArray(s.uploadHistory)&&s.uploadHistory.length)localStorage.setItem('lianixpload_history_v1',JSON.stringify(s.uploadHistory));if(s.memoryConsent)localStorage.setItem('f24t-memory-consent',s.memoryConsent);if(s.profile?.photoURL)localStorage.setItem('f24t-avatar',s.profile.photoURL);remember();ready=true;window.dispatchEvent(new CustomEvent('lianix:data-hydrated',{detail:{state:s}}))}catch(e){console.warn('[account-sync] hydrate:',e.message)}finally{applying=false}}
async function flush(force=false){if(!ready||applying||!window.LianixAccountStore)return;const patch={};let dirty=false;for(const [k,dst] of Object.entries(map)){const cur=localStorage.getItem(k);if(cur===last[k])continue;last[k]=cur;dirty=true;const val=localValue(k);if(dst==='profilePhoto')patch.profile={...(patch.profile||{}),photoURL:val||null};else patch[dst]=val}if(!dirty&&!force)return;try{await LianixAccountStore.patch(patch,force)}catch(e){console.warn('[account-sync] flush:',e.message)}}
window.addEventListener('lianix:auth',()=>hydrate());
window.addEventListener('pagehide',()=>{flush(true)});
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden')flush(true)});
window.LianixPageData={flush,hydrate};
setInterval(()=>flush(false),2500);
})();
