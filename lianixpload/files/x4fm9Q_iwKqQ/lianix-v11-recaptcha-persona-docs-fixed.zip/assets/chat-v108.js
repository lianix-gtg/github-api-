(function(){
  'use strict';
  const CLICKABLE='button,.ni,.sb-btn,.pill,.mo,.ibb,.tbtn,.mj-btn,.bn-item,[role="button"]';
  function installPressFX(root=document){
    root.querySelectorAll(CLICKABLE).forEach(el=>{
      if(el.dataset.c8Fx==='1') return;
      el.dataset.c8Fx='1'; el.classList.add('c8-clickable');
    });
  }
  function press(el,x,y){
    if(!el) return;
    const r=el.getBoundingClientRect();
    el.style.setProperty('--c8-x',(x-r.left)+'px');
    el.style.setProperty('--c8-y',(y-r.top)+'px');
    el.classList.remove('c8-pressed'); void el.offsetWidth; el.classList.add('c8-pressed');
    setTimeout(()=>el.classList.remove('c8-pressed'),520);
  }
  document.addEventListener('pointerdown',e=>{
    const el=e.target.closest(CLICKABLE); if(!el||el.disabled) return;
    press(el,e.clientX,e.clientY);
  },{passive:true});
  document.addEventListener('keydown',e=>{
    if(e.key!=='Enter'&&e.key!==' ') return;
    const el=e.target.closest(CLICKABLE); if(!el||el.disabled) return;
    const r=el.getBoundingClientRect(); press(el,r.left+r.width/2,r.top+r.height/2);
  });
  function decorateWelcome(){const wh=document.getElementById('wh');if(wh)wh.textContent='What can we build together?';const hint=document.getElementById('hint');if(hint)hint.textContent='F24nT AI · Multi-model workspace · Drag, paste, upload, or ask anything';}
  function observe(){
    const mo=new MutationObserver(ms=>{for(const m of ms){m.addedNodes.forEach(n=>{if(n.nodeType===1){installPressFX(n); if(n.matches&&n.matches(CLICKABLE)) installPressFX(n.parentNode||document)}})}});
    mo.observe(document.body,{childList:true,subtree:true});
  }
  function boot(){installPressFX();decorateWelcome();observe();document.documentElement.classList.add('chat-v108-ready')}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
})();
