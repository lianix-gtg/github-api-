(function(){
'use strict';
if(window.__LianixAuthGlobalLoaded)return;
window.__LianixAuthGlobalLoaded=true;
const CFG={apiKey:'AIzaSyDv5x_s-KWr6Fj-i0cpQc3T487pJiGTeyA',authDomain:'yoengpt-8f594.firebaseapp.com',projectId:'yoengpt-8f594',appId:'1:545234405794:web:d4506257eb2090d6794afb'};
const IS_DOCS = location.pathname==='/' || /^\/docs(?:\/|$)/.test(location.pathname);
let captchaPromise=null;
const S={firebase:null,auth:null,user:null,emailSession:localStorage.getItem('lianix_email_session_v1')||sessionStorage.getItem('f24t-email-session')||'',mode:localStorage.getItem('lianix_registered_hint')==='1'?'login':'register',authOpen:false,authBusy:false,captcha:{siteKey:'',widgetId:null,token:'',checked:false,verified:false,loading:false}};
const esc=s=>String(s??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
const googleLogo=`<svg class="lx-provider-logo" viewBox="0 0 48 48" aria-hidden="true"><path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.3 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.9 1.2 8 3.1l5.7-5.7C34.1 6.1 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.2-.1-2.4-.4-3.5z"/><path fill="#FF3D00" d="m6.3 14.7 6.6 4.8C14.7 15.1 18.9 12 24 12c3.1 0 5.9 1.2 8 3.1l5.7-5.7C34.1 6.1 29.3 4 24 4c-7.7 0-14.4 4.3-17.7 10.7z"/><path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.3 0-9.7-3.3-11.3-7.9l-6.5 5C9.5 39.6 16.2 44 24 44z"/><path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.3-2.2 4.2-4.1 5.6l6.2 5.2C37 39.2 44 34 44 24c0-1.2-.1-2.4-.4-3.5z"/></svg>`;
const githubLogo=`<svg class="lx-provider-logo" viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M12 .7C5.7.7.6 5.9.6 12.3c0 5.1 3.3 9.4 7.8 10.9.6.1.8-.3.8-.6v-2.2c-3.2.7-3.9-1.4-3.9-1.4-.5-1.4-1.3-1.8-1.3-1.8-1.1-.7.1-.7.1-.7 1.2.1 1.8 1.3 1.8 1.3 1.1 1.9 2.8 1.3 3.5 1 .1-.8.4-1.3.8-1.6-2.6-.3-5.3-1.3-5.3-5.8 0-1.3.5-2.3 1.2-3.1-.1-.3-.5-1.5.1-3.1 0 0 1-.3 3.2 1.2a10.9 10.9 0 0 1 5.8 0c2.2-1.5 3.2-1.2 3.2-1.2.6 1.6.2 2.8.1 3.1.8.8 1.2 1.8 1.2 3.1 0 4.5-2.7 5.5-5.3 5.8.4.4.8 1.1.8 2.2v3.2c0 .4.2.7.8.6 4.5-1.5 7.8-5.8 7.8-10.9C23.4 5.9 18.3.7 12 .7z"/></svg>`;
const icon=(path)=>`<svg class="lx-mini-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${path}</svg>`;
function script(src){return new Promise((ok,fail)=>{const ex=document.querySelector(`script[src="${src}"]`);if(ex){if(src.includes('firebase-app')&&window.firebase)return ok();if(src.includes('firebase-auth')&&window.firebase?.auth)return ok();let done=false;const finish=()=>{if(done)return;done=true;ok()};ex.addEventListener('load',finish,{once:true});ex.addEventListener('error',()=>{if(done)return;done=true;fail(new Error('Gagal memuat '+src))},{once:true});let n=0;const poll=setInterval(()=>{n++;if((src.includes('firebase-app')&&window.firebase)||(src.includes('firebase-auth')&&window.firebase?.auth)){clearInterval(poll);finish()}else if(n>80){clearInterval(poll);if(!done){done=true;fail(new Error('Timeout memuat '+src))}}},50);return}const s=document.createElement('script');s.src=src;s.async=true;s.onload=ok;s.onerror=()=>fail(new Error('Gagal memuat '+src));document.head.appendChild(s)})}
async function initFirebase(){try{await script('https://www.gstatic.com/firebasejs/10.12.0/firebase-app-compat.js');await script('https://www.gstatic.com/firebasejs/10.12.0/firebase-auth-compat.js');if(!firebase.apps.length)firebase.initializeApp(CFG);S.firebase=firebase;S.auth=firebase.auth();return true}catch(e){console.warn('[auth] Firebase unavailable:',e.message);return false}}
function root(){let r=document.getElementById('lianix-auth-root');if(r)return r;r=document.createElement('div');r.id='lianix-auth-root';r.hidden=true;r.innerHTML=`<div class="lx-auth-card"><section class="lx-auth-visual"><div><lianix-code-logo class="lx-auth-code-mark"></lianix-code-logo><h1>Lianix<br>Workspace</h1><p>Satu akun untuk F24nT AI, API Tools, Upload, Snippet, plan, dan semua data workspace kamu.</p><div class="lx-auth-features"><div class="lx-auth-feature">${icon('<path d="M12 3v18M3 12h18"/>')} Data tersinkron</div><div class="lx-auth-feature">${icon('<path d="M20 11a8 8 0 1 0-2.3 5.7"/><path d="M20 4v7h-7"/>')} Pulih lintas deploy</div><div class="lx-auth-feature">${googleLogo} OAuth langsung masuk</div><div class="lx-auth-feature">${icon('<path d="M4 4h16v16H4z"/><path d="M8 10h8M8 14h5"/>')} Email + password</div></div></div><small>Email: register dulu lalu login. Google/GitHub: sekali autentikasi langsung masuk workspace.</small></section><section class="lx-auth-form"><div class="lx-auth-switcher"><button data-mode="register" class="active">Register</button><button data-mode="login">Login</button></div><div class="lx-auth-form-stage" id="lx-stage"><lianix-code-logo class="lianix-brand-logo"></lianix-code-logo><h2 id="lx-title"></h2><div class="sub" id="lx-sub"></div><div class="lx-provider"><button class="lx-btn" id="lx-google">${googleLogo}<span>Lanjutkan dengan Google</span></button><button class="lx-btn" id="lx-github">${githubLogo}<span>Lanjutkan dengan GitHub</span></button></div><div class="lx-divider">atau dengan email & password</div><div class="lx-field"><label>Email</label><input id="lx-email" class="lx-input" type="email" autocomplete="email" placeholder="nama@email.com"></div><div class="lx-field"><label>Password</label><div class="lx-password-wrap"><input id="lx-password" class="lx-input" type="password" autocomplete="current-password" minlength="6" placeholder="Minimal 6 karakter"><button type="button" id="lx-password-toggle" class="lx-password-toggle" aria-label="Tampilkan password">${icon('<path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12z"/><circle cx="12" cy="12" r="2.5"/>')}</button></div></div><div class="lx-captcha-box"><div id="lx-recaptcha"></div><div id="lx-captcha-state" class="lx-captcha-state">Memuat verifikasi manusia…</div></div><button id="lx-email-btn" class="lx-btn primary" disabled></button><div id="lx-msg" class="lx-auth-msg"></div><div class="lx-auth-foot" id="lx-foot"></div></div></section></div>`;document.body.appendChild(r);bind(r);renderMode(false);return r}
function openAuth(forceMode){if(forceMode)S.mode=forceMode;S.authOpen=true;const r=root();r.hidden=false;document.documentElement.classList.add('lianix-auth-open');renderMode(false);ensureCaptcha().catch(e=>msg(e.message))}
function closeAuth(){S.authOpen=false;const r=root();r.hidden=true;document.documentElement.classList.remove('lianix-auth-open')}
function captchaButtons(){const emailDisabled=S.authBusy||!S.captcha.checked;const email=document.getElementById('lx-email-btn');if(email){email.disabled=emailDisabled;email.style.opacity=emailDisabled?'0.5':'1';email.style.cursor=emailDisabled?'not-allowed':'pointer'}['lx-google','lx-github'].forEach(id=>{const b=document.getElementById(id);if(b){b.disabled=S.authBusy||!S.captcha.checked;b.style.opacity=(S.authBusy||!S.captcha.checked)?'0.5':'1'}});const e=document.getElementById('lx-captcha-state');if(e){e.textContent=S.captcha.checked?'✓ Verifikasi selesai — lanjutkan.':(S.captcha.loading?'Memuat verifikasi…':'Centang “Saya bukan robot” untuk melanjutkan.');e.style.color=S.captcha.checked?'#15803d':'inherit'}}
function resetCaptcha(){S.captcha.token='';S.captcha.checked=false;S.captcha.verified=false;try{if(window.grecaptcha&&S.captcha.widgetId!==null)window.grecaptcha.reset(S.captcha.widgetId)}catch{}captchaButtons()}
function loadRecaptchaScript(){if(window.grecaptcha?.render)return Promise.resolve();return new Promise((ok,fail)=>{const id='lx-recaptcha-script';let el=document.getElementById(id);let done=false;const finish=()=>{if(done)return;if(window.grecaptcha?.render){done=true;ok()}};if(el){const poll=setInterval(()=>{if(window.grecaptcha?.render){clearInterval(poll);finish()}},80);setTimeout(()=>{clearInterval(poll);if(!done)fail(Error('reCAPTCHA gagal dimuat. Periksa koneksi.'))},12000);return}window.__lianixRecaptchaReady=()=>finish();el=document.createElement('script');el.id=id;el.src='https://www.google.com/recaptcha/api.js?onload=__lianixRecaptchaReady&render=explicit';el.async=true;el.defer=true;el.onerror=()=>fail(Error('reCAPTCHA gagal dimuat.'));document.head.appendChild(el)})}
async function ensureCaptcha(){
  const host=document.getElementById('lx-recaptcha');
  if(!host)throw Error('Wadah reCAPTCHA tidak ditemukan.');
  if(S.captcha.widgetId!==null && window.grecaptcha?.getResponse){captchaButtons();return S.captcha.widgetId}
  if(S.captcha.loading&&captchaPromise)return captchaPromise;
  S.captcha.loading=true;captchaButtons();
  captchaPromise=(async()=>{
  try{
    let configured='';
    try{
      const urls=['/api/auth/recaptcha','/.netlify/functions/recaptcha'];
      for(const url of urls){
        try{
          const r=await fetch(url,{cache:'no-store',headers:{Accept:'application/json'}});
          const d=await r.json().catch(()=>({}));
          if(r.ok&&d.siteKey){configured=String(d.siteKey).trim();break;}
        }catch(e){}
      }
    }catch(e){console.warn('[recaptcha] config fetch failed',e)}
    if(!configured)throw Error('Konfigurasi reCAPTCHA tidak tersedia. Pastikan RECAPTCHA_SITE_KEY tersedia untuk Functions/Runtime lalu deploy ulang.');
    S.captcha.siteKey=configured;
    await loadRecaptchaScript();

    // Google owns the iframe inside this element. Never clear/recreate it.
    // A stable, untransformed host is required on touch devices.
    host.dataset.lxRecaptchaHost='1';
    host.style.pointerEvents='auto';
    host.style.touchAction='manipulation';
    host.style.position='relative';
    host.style.zIndex='20';

    if(S.captcha.widgetId!==null){captchaButtons();return S.captcha.widgetId}
    if(host.dataset.lxRecaptchaRendered==='1'){
      // Recover an existing widget even if another auth lifecycle recreated state.
      const existing=host.dataset.lxRecaptchaWidget;
      if(existing!==undefined && existing!==''){
        S.captcha.widgetId=Number(existing);captchaButtons();return S.captcha.widgetId;
      }
      throw Error('Widget reCAPTCHA sudah terpasang.');
    }

    await new Promise((resolve,reject)=>{
      let settled=false;
      const fail=e=>{if(settled)return;settled=true;reject(e)};
      const ok=()=>{if(settled)return;settled=true;resolve()};
      try{
        grecaptcha.ready(()=>{
          if(settled)return;
          if(S.captcha.widgetId!==null){ok();return}
          if(host.dataset.lxRecaptchaRendered==='1'){fail(Error('Widget reCAPTCHA sudah terpasang.'));return}
          try{
            const id=grecaptcha.render(host,{
              sitekey:S.captcha.siteKey,
              theme:'light',
              size:'normal',
              tabindex:0,
              callback:(token)=>{
                S.captcha.token=String(token||'');
                S.captcha.checked=!!token;
                S.captcha.verified=false;
                captchaButtons();
              },
              'expired-callback':()=>{S.captcha.token='';S.captcha.checked=false;S.captcha.verified=false;captchaButtons()},
              'error-callback':()=>{S.captcha.token='';S.captcha.checked=false;S.captcha.verified=false;captchaButtons();msg('reCAPTCHA tidak dapat dimuat. Periksa koneksi atau domain Site Key.')}
            });
            S.captcha.widgetId=id;
            host.dataset.lxRecaptchaRendered='1';
            host.dataset.lxRecaptchaWidget=String(id);
            // Do not wrap/animate the Google iframe. Make its hit area explicit.
            const iframes=host.querySelectorAll('iframe');
            iframes.forEach(f=>{f.style.pointerEvents='auto';f.style.touchAction='manipulation';f.style.userSelect='none'});
            // Also fix the host container itself
            host.style.userSelect='none';
            host.style.webkitUserSelect='none';
            ok();
          }catch(e){fail(e)}
        });
      }catch(e){fail(e)}
    });
    return S.captcha.widgetId;
  }finally{S.captcha.loading=false;captchaButtons();captchaPromise=null}
  })();
  return captchaPromise;
}
async function verifyCaptcha(){
  if(!S.captcha.checked||!S.captcha.token)throw Error('Centang reCAPTCHA sampai berhasil dulu.');
  if(S.captcha.verified)return true;
  try{
    const r=await fetch('/api/auth/recaptcha',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token:S.captcha.token})});
    const d=await r.json().catch(()=>({}));
    // Server-side verification is mandatory. Never trust the browser token by itself.
    if(!r.ok){
      const errCode=d.error||'';
      if(r.status===503||errCode==='RECAPTCHA_SECRET_KEY_MISSING'||errCode==='RECAPTCHA_SITE_KEY_MISSING'||r.status===502){
        resetCaptcha();
        throw Error(d.message||'Konfigurasi reCAPTCHA server belum siap. Pastikan RECAPTCHA_SECRET_KEY tersedia pada Netlify Functions lalu deploy ulang.');
      }
      // Token errors — reset so user can re-check
      const codes=Array.isArray(d.codes)&&d.codes.length?' ['+d.codes.join(', ')+']':'';
      const host=d.hostname?` Hostname: ${d.hostname}.`:'';
      resetCaptcha();
      throw Error((d.message||d.error||'Verifikasi reCAPTCHA gagal.')+codes+host);
    }
    if(!d.ok){
      const codes=Array.isArray(d.codes)&&d.codes.length?' ['+d.codes.join(', ')+']':'';
      const host=d.hostname?` Hostname: ${d.hostname}.`:'';
      resetCaptcha();
      throw Error((d.message||d.error||'Verifikasi reCAPTCHA gagal.')+codes+host);
    }
    S.captcha.verified=true;return true;
  }catch(e){
    if(e.message&&(e.message.includes('fetch')||e.message.includes('network')||e.message.includes('Failed to fetch'))){
      resetCaptcha();
      throw Error('Server reCAPTCHA tidak dapat dihubungi. Login diblokir sampai verifikasi server berhasil.');
    }
    throw e;
  }
}
async function authOnce(fn){if(S.authBusy)return;S.authBusy=true;captchaButtons();try{return await fn()}finally{S.authBusy=false;captchaButtons()}}
function renderMode(animate=true){const r=root();if(!S.captcha.verified)resetCaptcha();const stage=r.querySelector('#lx-stage');if(animate){stage.classList.remove('lx-swap');void stage.offsetWidth;stage.classList.add('lx-swap')}r.querySelectorAll('.lx-auth-switcher button').forEach(b=>b.classList.toggle('active',b.dataset.mode===S.mode));const reg=S.mode==='register';r.querySelector('#lx-title').textContent=reg?'Buat akun F24nT AI':'Masuk ke F24nT AI';r.querySelector('#lx-sub').textContent=reg?'Daftar email + password sekali. Setelah berhasil, login dengan akun yang sama.':'Masukkan email dan password akun yang sudah terdaftar.';r.querySelector('#lx-email-btn').textContent=reg?'Buat akun email':'Login dengan email';r.querySelector('#lx-foot').textContent=reg?'Google/GitHub tidak perlu dua langkah — OAuth berhasil langsung masuk.':'Belum punya akun email? Pindah ke Register.';const pw=r.querySelector('#lx-password');if(pw)pw.autocomplete=reg?'new-password':'current-password';msg('',false);if(S.authOpen)queueMicrotask(()=>ensureCaptcha().catch(e=>msg(e.message)))}
function msg(t,bad=true){const text=t||'';const now=Date.now();if(S._lastMsg===text&&now-(S._lastMsgAt||0)<800)return;S._lastMsg=text;S._lastMsgAt=now;const e=document.getElementById('lx-msg');if(e){e.textContent=text;e.style.color=bad?'#c2410c':'#15803d'}}
async function headers(){const h={};if(S.user?.getIdToken){try{h.Authorization='Bearer '+await S.user.getIdToken()}catch{}}if(S.emailSession)h['X-Lianix-Email-Session']=S.emailSession;return h}
async function validate(){try{const r=await fetch('/api/auth/session',{headers:await headers(),cache:'no-store'});const d=await r.json();if(r.ok&&d.ok)return d.user}catch{}return null}
async function registry(action){const r=await fetch('/api/auth/account-registry',{method:'POST',headers:{'Content-Type':'application/json',...(await headers())},body:JSON.stringify({action})});const d=await r.json().catch(()=>({}));if(!r.ok||!d.ok)throw Error(d.error||'Gagal memeriksa akun.');return d}
function emailUser(u){return {...u,providerId:'email-code',photoURL:null}}
function clearEmailSession(){S.emailSession='';localStorage.removeItem('lianix_email_session_v1');sessionStorage.removeItem('f24t-email-session')}
async function doLogout(){try{await window.LianixUserData?.flush?.(true)}catch{}try{await window.LianixPageData?.flush?.(true)}catch{}try{await S.auth?.signOut()}catch{}clearEmailSession();location.reload()}
function showChip(){document.getElementById('lx-user-chip')?.remove();document.getElementById('lx-account-settings')?.remove();if(!S.user)return;const host=document.querySelector('#p-stg .pb');if(!host)return;const sec=document.createElement('div');sec.className='sg-sec';sec.id='lx-account-settings';const name=S.user.displayName||S.user.email||'Lianix User';sec.innerHTML=`<div class="sg-tl">Account</div><div class="lx-settings-account"><div class="lx-settings-avatar">${esc((name||'U').charAt(0).toUpperCase())}</div><div><b>${esc(name)}</b><small>${esc(S.user.email||S.user.providerId||'account')}</small></div></div><div class="lx-settings-account-actions"><button class="lx-settings-profile" id="lx-settings-profile" type="button">Profil & akun</button><button class="lx-settings-logout" id="lx-settings-logout" type="button">Logout</button></div>`;host.prepend(sec);sec.querySelector('#lx-settings-logout').onclick=doLogout;const pb=sec.querySelector('#lx-settings-profile');pb.onclick=()=>{if(typeof window.openProfile==='function')window.openProfile()}}
function success(u){S.user=u;localStorage.setItem('lianix_registered_hint','1');localStorage.setItem('lianix_registry_verified_v1','1');try{sessionStorage.setItem('f24t-su',JSON.stringify({uid:u.uid||null,displayName:u.displayName||u.name||null,email:u.email||null,photoURL:u.photoURL||null,providerId:u.providerId||null}))}catch{};if(window.G){G.user=u;try{window.onLogin?.(u)}catch(e){console.warn('[auth] app login bridge:',e.message)}}document.documentElement.classList.remove('lianix-auth-pending');closeAuth();showChip();window.LianixAuth={user:u,headers,getEmailSession:()=>S.emailSession,logout:doLogout,open:openAuth};window.LianixAccountStore={async get(){const r=await fetch('/api/user/data',{headers:await headers(),cache:'no-store'});const d=await r.json();if(!r.ok||!d.ok)throw Error(d.error||'Account store gagal');return d.state||{}},async patch(patch,forceBackup=false){const r=await fetch('/api/user/data',{method:'PATCH',headers:{'Content-Type':'application/json',...(await headers())},body:JSON.stringify({patch,forceBackup})});const d=await r.json();if(!r.ok||!d.ok)throw Error(d.error||'Account store gagal');return d}};window.dispatchEvent(new CustomEvent('lianix:auth',{detail:{user:u}}))}
async function finishRegistration(user){S.user=user;await registry('register');localStorage.setItem('lianix_registered_hint','1');localStorage.setItem('lianix_registry_verified_v1','1');try{await S.auth?.signOut()}catch{}clearEmailSession();S.user=null;S.emailPending=false;const cw=document.getElementById('lx-code-wrap');if(cw)cw.hidden=true;const cb=document.getElementById('lx-code');if(cb)cb.value='';S.mode='login';renderMode(true);msg('Registrasi berhasil. Sekarang login dengan akun yang baru didaftarkan.',false)}
async function ensureRegisteredThenLogin(user){S.user=user;const d=await registry('status');if(!d.registered){if(localStorage.getItem('lianix_registry_verified_v1')==='1'||localStorage.getItem('lianix_registered_hint')==='1'){await registry('register');success(user);return}try{await S.auth?.signOut()}catch{}clearEmailSession();S.user=null;S.mode='register';renderMode(true);throw Error('Akun belum terdaftar. Register dulu, baru login.')}success(user)}
async function emailAction(){return authOnce(async()=>{const email=document.getElementById('lx-email').value.trim(),password=document.getElementById('lx-password').value;if(!email)return msg('Masukkan email.');if(!password||password.length<6)return msg('Password minimal 6 karakter.');try{await verifyCaptcha();if(!S.auth)throw Error('Firebase Auth belum siap. Coba lagi.');if(S.mode==='register'){const z=await S.auth.createUserWithEmailAndPassword(email,password);S.user=z.user;await registry('register');localStorage.setItem('lianix_registered_hint','1');localStorage.setItem('lianix_registry_verified_v1','1');await S.auth.signOut();S.user=null;S.mode='login';renderMode(true);document.getElementById('lx-password').value='';msg('Akun berhasil dibuat. Sekarang login dengan email dan password yang sama.',false)}else{const z=await S.auth.signInWithEmailAndPassword(email,password);await ensureRegisteredThenLogin(z.user)}}catch(e){const map={'auth/email-already-in-use':'Email sudah terdaftar. Pindah ke Login.','auth/invalid-credential':'Email atau password salah.','auth/wrong-password':'Email atau password salah.','auth/user-not-found':'Akun belum ada. Register dulu.','auth/invalid-email':'Format email tidak valid.','auth/weak-password':'Password terlalu lemah. Minimal 6 karakter.'};const isCaptchaErr=!e.code&&(e.message||'').toLowerCase().includes('recaptcha');const isAuthErr=e.code&&e.code.startsWith('auth/');if(!S.user&&!isAuthErr&&isCaptchaErr)resetCaptcha();msg(map[e.code]||e.message)}})}
async function provider(kind){return authOnce(async()=>{try{await verifyCaptcha();if(!S.auth)throw Error('Login provider belum siap. Coba lagi.');const Provider=kind==='google'?firebase.auth.GoogleAuthProvider:firebase.auth.GithubAuthProvider;const z=await S.auth.signInWithPopup(new Provider());S.user=z.user;let d=null;try{d=await registry('status')}catch(e){console.warn('[auth] registry status:',e.message)}if(!d?.registered)await registry('register');localStorage.setItem('lianix_registered_hint','1');localStorage.setItem('lianix_registry_verified_v1','1');success(z.user)}catch(e){if(String(e.message||'').toLowerCase().includes('recaptcha'))resetCaptcha();msg(e.message)}})}
function bind(r){if(r.dataset.bound==='1')return;r.dataset.bound='1';r.querySelector('#lx-email-btn').addEventListener('click',emailAction,{passive:true});r.querySelector('#lx-password').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();emailAction()}});r.querySelector('#lx-password-toggle').addEventListener('click',()=>{const p=r.querySelector('#lx-password'),show=p.type==='password';p.type=show?'text':'password';r.querySelector('#lx-password-toggle').classList.toggle('on',show)});r.querySelector('#lx-google').addEventListener('click',()=>provider('google'));r.querySelector('#lx-github').addEventListener('click',()=>provider('github'));r.querySelectorAll('.lx-auth-switcher button').forEach(b=>b.addEventListener('click',()=>{if(S.mode===b.dataset.mode||S.authBusy)return;S.mode=b.dataset.mode;r.querySelector('#lx-password').value='';renderMode(true)}))}
function protectDocs(){if(!IS_DOCS)return;document.documentElement.classList.remove('lianix-auth-pending');const protectedPath=p=>/^\/(?:app|chat|tools|upload|plan|snippets|snippet|artifacts|recents|chats)(?:\/|$)/.test(p||'');const guard=(e)=>{if(S.user||S.authOpen)return;const el=e.target.closest?.('a,button,input,textarea,select,[role="button"]');if(!el||el.closest('#lianix-auth-root')||el.hasAttribute('data-public'))return;const href=el.tagName==='A'?el.getAttribute('href'):'';if(href&&href.startsWith('#'))return;if(el.hasAttribute('data-auth-required')||(href&&protectedPath(new URL(href,location.href).pathname))||['INPUT','TEXTAREA','SELECT','BUTTON'].includes(el.tagName)){e.preventDefault();e.stopImmediatePropagation();openAuth(localStorage.getItem('lianix_registered_hint')==='1'?'login':'register')}};document.addEventListener('click',guard,true);document.addEventListener('focusin',e=>{if(S.user||S.authOpen)return;const el=e.target;if(el?.matches?.('input,textarea,select')&&!el.closest('#lianix-auth-root')){e.preventDefault();el.blur();openAuth(localStorage.getItem('lianix_registered_hint')==='1'?'login':'register')}},true)}
async function boot(){root();protectDocs();const fb=await initFirebase();if(fb){const u=await new Promise(ok=>{const timer=setTimeout(()=>ok(null),3500);const off=S.auth.onAuthStateChanged(x=>{clearTimeout(timer);off();ok(x)})});if(u){S.user=u;try{const d=await registry('status');if(d.registered){localStorage.setItem('lianix_registry_verified_v1','1');success(u);return}if(localStorage.getItem('lianix_registered_hint')==='1'||localStorage.getItem('lianix_registry_verified_v1')==='1'){await registry('register');success(u);return}localStorage.removeItem('lianix_registry_verified_v1')}catch(e){if(localStorage.getItem('lianix_registry_verified_v1')==='1'||localStorage.getItem('lianix_registered_hint')==='1'){console.warn('[auth] registry sementara tidak tersedia; mempertahankan sesi terverifikasi');success(u);return}}try{await S.auth.signOut()}catch{}S.user=null}}
 if(S.emailSession){S.user=emailUser(await validate()||{});if(S.user?.uid){try{const d=await registry('status');if(d.registered){localStorage.setItem('lianix_registry_verified_v1','1');success(S.user);return}if(localStorage.getItem('lianix_registered_hint')==='1'||localStorage.getItem('lianix_registry_verified_v1')==='1'){await registry('register');success(S.user);return}}catch(e){if(localStorage.getItem('lianix_registry_verified_v1')==='1'||localStorage.getItem('lianix_registered_hint')==='1'){console.warn('[auth] registry sementara tidak tersedia; mempertahankan sesi email terverifikasi');success(S.user);return}}}clearEmailSession();S.user=null}
 if(IS_DOCS){document.documentElement.classList.remove('lianix-auth-pending');root().hidden=true}else{openAuth(localStorage.getItem('lianix_registered_hint')==='1'?'login':'register');document.documentElement.classList.add('lianix-auth-pending')}}
window.LianixAuthGate={open:openAuth,isAuthenticated:()=>!!S.user};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})();
