(function(){
  'use strict';
  const API_KEY='lianix';
  function crc32(buf){
    let c=0xffffffff;
    for(let i=0;i<buf.length;i++){
      c^=buf[i];
      for(let k=0;k<8;k++) c=(c>>>1)^((c&1)?0xedb88320:0);
    }
    return (c^0xffffffff)>>>0;
  }
  function u16(n){return new Uint8Array([n&255,(n>>>8)&255])}
  function u32(n){return new Uint8Array([n&255,(n>>>8)&255,(n>>>16)&255,(n>>>24)&255])}
  function dosTime(d){const t=((d.getHours()&31)<<11)|((d.getMinutes()&63)<<5)|((Math.floor(d.getSeconds()/2))&31);const da=(((d.getFullYear()-1980)&127)<<9)|(((d.getMonth()+1)&15)<<5)|(d.getDate()&31);return{t,da}}
  async function makeZip(entries,name='folder.zip'){
    const enc=new TextEncoder(), locals=[], centrals=[];let offset=0;
    for(const ent of entries){
      const file=ent.file||ent; const path=String(ent.path||file.webkitRelativePath||file.name||'file').replace(/^\/+/, '');
      const fn=enc.encode(path); const data=new Uint8Array(await file.arrayBuffer()); const crc=crc32(data); const dt=dosTime(new Date(file.lastModified||Date.now()));
      const localParts=[u32(0x04034b50),u16(20),u16(0x0800),u16(0),u16(dt.t),u16(dt.da),u32(crc),u32(data.length),u32(data.length),u16(fn.length),u16(0),fn,data];
      const localLen=localParts.reduce((s,x)=>s+x.length,0); locals.push(...localParts);
      centrals.push(u32(0x02014b50),u16(20),u16(20),u16(0x0800),u16(0),u16(dt.t),u16(dt.da),u32(crc),u32(data.length),u32(data.length),u16(fn.length),u16(0),u16(0),u16(0),u16(0),u32(0),u32(offset),fn);
      offset+=localLen;
    }
    const centralSize=centrals.reduce((s,x)=>s+x.length,0); const count=entries.length;
    const end=[u32(0x06054b50),u16(0),u16(0),u16(count),u16(count),u32(centralSize),u32(offset),u16(0)];
    return new File([...locals,...centrals,...end],name,{type:'application/zip',lastModified:Date.now()});
  }
  async function entryFiles(entry,prefix=''){
    if(entry.isFile){return await new Promise((resolve,reject)=>entry.file(f=>resolve([{file:f,path:(prefix+f.name).replace(/^\/+/, '')}]),reject));}
    if(!entry.isDirectory)return[];
    const reader=entry.createReader(), children=[];
    while(true){const batch=await new Promise((resolve,reject)=>reader.readEntries(resolve,reject));if(!batch.length)break;children.push(...batch)}
    const out=[];for(const ch of children)out.push(...await entryFiles(ch,prefix+entry.name+'/'));return out;
  }
  async function filesFromDataTransfer(dt){
    const items=[...(dt?.items||[])]; const entries=[];
    for(const item of items){const e=item.webkitGetAsEntry?.();if(e)entries.push(...await entryFiles(e,''));}
    if(entries.length)return entries;
    return [...(dt?.files||[])].map(file=>({file,path:file.webkitRelativePath||file.name}));
  }
  async function normalizeDropToUpload(dt,label='upload'){
    const entries=await filesFromDataTransfer(dt);
    if(!entries.length)throw new Error('Tidak ada file yang bisa dibaca.');
    const hasDir=entries.some(x=>String(x.path||'').includes('/'));
    if(entries.length===1&&!hasDir)return entries[0].file;
    const clean=String(label||'folder').replace(/[^a-z0-9._-]+/gi,'-').replace(/^-|-$/g,'')||'folder';
    return makeZip(entries,clean+'.zip');
  }
  function toB64(bytes){let bin='';const step=0x8000;for(let i=0;i<bytes.length;i+=step)bin+=String.fromCharCode(...bytes.subarray(i,i+step));return btoa(bin)}
  async function postJson(url,body){const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json','X-API-Key':API_KEY},body:JSON.stringify(body)});let d={};try{d=await r.json()}catch{}if(!r.ok||d.success===false)throw new Error(d.error||`HTTP ${r.status}`);return d}
  async function uploadDirect(file,onProgress){return await new Promise((resolve,reject)=>{const xhr=new XMLHttpRequest();xhr.open('POST','/api/upload');xhr.setRequestHeader('X-API-Key',API_KEY);xhr.timeout=45000;xhr.upload.onprogress=e=>{if(e.lengthComputable&&onProgress)onProgress(Math.round(e.loaded/e.total*100));};xhr.onload=()=>{let d;try{d=JSON.parse(xhr.responseText||'{}')}catch{d={}};if(xhr.status>=200&&xhr.status<300&&d.success!==false&&d.url)return resolve(d);reject(new Error(d.error||`Upload HTTP ${xhr.status}`));};xhr.onerror=()=>reject(new Error('Upload gagal: koneksi terputus.'));xhr.ontimeout=()=>reject(new Error('Upload timeout.'));const fd=new FormData();fd.append('file',file,file.name||'upload.bin');xhr.send(fd);})}
  async function uploadChunked(file,onProgress){const CHUNK=1536*1024,total=Math.ceil(file.size/CHUNK),session=(crypto.randomUUID?crypto.randomUUID():Date.now().toString(36)+Math.random().toString(36).slice(2)).replace(/-/g,'');for(let i=0;i<total;i++){const bytes=new Uint8Array(await file.slice(i*CHUNK,Math.min(file.size,(i+1)*CHUNK)).arrayBuffer());await postJson('/api/upload/chunk',{session,index:i,total,dataBase64:toB64(bytes)});if(onProgress)onProgress(Math.round(((i+1)/(total+1))*100));}const d=await postJson('/api/upload/finalize',{session,total,filename:file.name||'upload.bin',mime:file.type||'application/octet-stream'});if(onProgress)onProgress(100);return d}
  async function upload(file,onProgress){
    if(!(file instanceof Blob))throw new Error('File tidak valid.');
    if(file.size<=0)throw new Error('File kosong tidak dapat diupload.');
    if(file.size>10*1024*1024)throw new Error('Satu file maksimum 10 MB.');
    return file.size<=2500*1024?uploadDirect(file,onProgress):uploadChunked(file,onProgress);
  }
  window.LianixUpload={upload,makeZip,filesFromDataTransfer,normalizeDropToUpload};
})();
