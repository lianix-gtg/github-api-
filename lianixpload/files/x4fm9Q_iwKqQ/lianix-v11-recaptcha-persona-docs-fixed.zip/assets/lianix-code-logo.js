(()=>{
'use strict';
if(customElements.get('lianix-code-logo')) return;
const tpl=`<svg viewBox="0 0 1280 1280" role="img" aria-label="Lianix" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid meet"><image href="/assets/lianix-logo.png" x="0" y="0" width="1280" height="1280" preserveAspectRatio="xMidYMid meet"/></svg>`;
class LianixCodeLogo extends HTMLElement{
 constructor(){super();const s=this.attachShadow({mode:'open'});s.innerHTML=`<style>:host{display:inline-grid;place-items:center;width:1em;height:1em;line-height:0;contain:layout paint}.mark{width:100%;height:100%;overflow:visible;transform-origin:50% 50%;animation:lxLogoBreath 5.8s cubic-bezier(.45,.05,.25,1) infinite}.mark image{transform-origin:50% 50%;animation:lxLogoSpin 18s linear infinite}.mark:hover image{animation-duration:7s}@keyframes lxLogoBreath{0%,100%{transform:scale(.97) rotate(-1deg)}50%{transform:scale(1.035) rotate(1deg)}}@keyframes lxLogoSpin{0%{transform:rotate(0)}100%{transform:rotate(360deg)}}:host(.static) .mark,:host(.static) image{animation:none!important}@media(prefers-reduced-motion:reduce){.mark,image{animation:none!important}}</style><svg class="mark" viewBox="0 0 1280 1280" aria-hidden="true"><image href="/assets/lianix-logo.png" x="0" y="0" width="1280" height="1280"/></svg>`}
}
customElements.define('lianix-code-logo',LianixCodeLogo);window.LianixCodeLogoSVG=tpl;
})();
