# Lianix V7.5 — AI / Blobs / Memory / Auto Detect

## Fixed
- Restored `netlify/functions/ai-proxy.js` and `/api/ai/*` redirects required by `/app`.
- Default Overchat request is normalized to `/api/ai/overchat` (legacy `/api/ai/ai/overchat` is still accepted by the proxy).
- When `CMNTY_API_KEY` is not configured, default Overchat falls back to the existing local `hackai` function instead of returning an unhandled 500.
- `jeevesai` is proxied to the FAA provider and no longer falls into static 404.
- Netlify Blobs Lambda compatibility is initialized with `connectLambda(event)` before `getStore(name)`.
- Blobs configuration errors use a non-persistent in-memory fallback rather than crashing unrelated endpoints with HTTP 500.
- API metadata analyzer detects more request/query/body patterns, exported functions, plain single scraper functions, multer fields, function arguments, JSDoc params, URL query templates and dependencies.
- URL-like media parameters (`imageLink`, `imgUrl`, etc.) remain URL/text inputs; actual binary parameters become image/audio/video/file/folder uploads.
- Publish automatically merges detected npm packages into the API registry repository `package.json`, so the next npm build installs packages such as axios.
- Test receipt includes dependency metadata, so changing dependencies requires re-test before publish.

## Chat memory
The existing chat visual design is retained. A first-use popup asks whether the user wants Memory enabled. When enabled (and not in Incognito), a bounded selection of recent messages and a few recent chats is added as context. The preference is stored locally in the browser.

The typing indicator now rotates high-level activity states such as:
- Mengamati konteks & memori
- Memahami permintaan
- Menyusun jawaban
- Memeriksa respons

These are high-level UI statuses, not hidden chain-of-thought.

## Environment
Required for Admin/GitHub features:
- `ADMIN_PASSWORD`
- `GITHUB_TOKEN`
- `GITHUB_OWNER` (optional; defaults to configured project value)
- `GITHUB_REPO` (optional)
- `GITHUB_BRANCH` (optional)

Optional provider key:
- `CMNTY_API_KEY`, `CMNTY_API_KEY_2` ... `CMNTY_API_KEY_10`

Default Overchat can fall back to `hackai` when no CMNTY key is configured. Other CMNTY-only routes return a controlled provider-configuration error instead of an application crash.

## Dependency auto-install note
Admin publish updates the target GitHub API repository's `package.json`. Packages are installed automatically when that repository/runtime performs its normal `npm install`/deployment. A running serverless function cannot safely install arbitrary npm packages into itself after it has already been deployed.
