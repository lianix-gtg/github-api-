# Validation V9.4

- netlify.toml parse: PASS
- brat.js syntax: PASS
- fakecall.js syntax: PASS
- fakegc.js syntax: PASS
- dependency scanner: PASS
- structural build validation: PASS
- `@napi-rs/canvas` remains in root dependencies: PASS
- external module config limited to the 3 canvas functions: PASS

Note: a full Netlify CLI function bundle could not be reproduced in the local audit container because npm dependency installation timed out. The configuration follows Netlify's documented mechanism for native addons with esbuild.
