# Lianix V7.4 Fixes

- `/app` / chat AI dipulihkan byte-for-byte dari ZIP referensi user dan tidak dimodifikasi.
- Admin login tidak lagi bergantung Netlify Blobs; session memakai signed stateless token.
- Shared public API key kembali menjadi `lianix`.
- `/api/user/api-key` tidak lagi memerlukan Firebase dan tidak menghasilkan error pembuatan key.
- GitHub-synced API tidak lagi otomatis dikunci sebagai `Backend belum deployed` hanya karena tidak tercantum di `settings.json`.
- Admin mendapat GitHub Files manager: browse folder, create folder, create/edit file, upload file, move/rename, delete, commit.
- Folder baru dibuat dengan `.gitkeep` karena Git tidak menyimpan folder kosong.
- `GITHUB_TOKEN` tetap server-side di Netlify ENV.
