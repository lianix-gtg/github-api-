# V8.9 — Upload URL Bridge, ZIP Preview, Docs Comments & Snippets

- URL parameters in Tools can now accept manual URLs or drag/drop file/folder. Dropped files are uploaded to LianixPload and the returned `/f/<id>` URL is inserted automatically.
- Admin Runtime Test uses the same upload/URL bridge. File/image/audio/video parameters use styled drag/drop inputs.
- LianixPload UI supports files up to 10 MB using chunked uploads. Batch maximum remains 10 MB.
- Non-inline files, including ZIP/RAR/7z/TAR, open a LianixPload preview page first instead of immediately downloading. `/f/<id>/download` performs the actual download.
- Upload sidebar icons are aligned with Tools icons.
- Docs expanded with API/upload/snippet guidance and a GitHub-backed comment/reply area.
- Added `/snippets`, `/snippet/<id>`, `/raw/<id>`. Public snippets are readable publicly. Private snippets are AES-256-GCM encrypted and require password.
- Admin Content tab manages snippets and Docs comments/replies.
- JavaScript snippets can run a safe browser Worker test with network/DOM disabled and a hard timeout.
