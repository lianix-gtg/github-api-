# Lianix V7.7 — Dependency Hardening

## Dependency utama web
Netlify meng-install dependency dari `package.json` root sebelum menjalankan build.
Project sekarang mendeklarasikan semua package eksternal yang digunakan langsung:

- `@babel/parser` — analyzer JS / auto parameter detector
- `@napi-rs/canvas` — render fake call / fake group chat
- `@netlify/blobs` — storage transaksi, plan, health, stats

`scripts/check-dependencies.js` memindai `require()`, `require.resolve()`, static `import`, dan dynamic `import()` di `netlify/` dan `scripts/`. Build gagal bila package eksternal dipakai tetapi belum ada di package.json.

## Dependency scraper dari Admin
Saat JS scraper dianalisis:

1. package Node built-in (`fs`, `path`, `crypto`, `stream/promises`, dll.) tidak dianggap dependency npm;
2. `require('pkg')` ditandai sebagai CommonJS;
3. `import ... from 'pkg'` / `import('pkg')` ditandai sebagai ESM;
4. dependency companion ditambahkan jika dibutuhkan (contoh `axios-cookiejar-support` juga memastikan `axios` dan `tough-cookie`);
5. versi CommonJS-compatible dipilih untuk package yang versi modernnya ESM-only;
6. saat Publish, dependency otomatis digabung ke `package.json` repository GitHub;
7. package yang belum ada di tabel versi diverifikasi ke npm registry sebelum commit.

### Compatibility pins
Untuk scraper CommonJS (`require()`):
- `node-fetch` -> `^2.7.0`
- `got` -> `^11.8.6`
- `file-type` -> `^16.5.4`
- `axios-cookiejar-support` -> `^5.0.5`

Untuk scraper ESM (`import`), versi modern dapat digunakan.

## Penting
Dependency di-install pada proses build/deploy (`npm install`), bukan dengan menjalankan `npm install` di tengah request serverless. Ini menghindari request macet, filesystem ephemeral, dan deploy yang tidak reproducible.
