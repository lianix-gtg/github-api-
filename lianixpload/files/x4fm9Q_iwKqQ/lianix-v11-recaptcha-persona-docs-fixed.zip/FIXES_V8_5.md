# V8.5 — Admin New API / AI Auto Detect Fallback

- Admin New API analyzer dibuat fail-soft: AST, Safe Probe, dan AI review tidak lagi menjadi single point of failure.
- Provider chain: Jeeves -> Free Qwen/Rewind -> local static analyzer.
- Jika semua AI gagal, endpoint Analyze tetap mengembalikan metadata lokal + warning (bukan 500).
- Source yang dikirim ke AI disanitasi untuk menyensor token/API key/password/Authorization.
- Bukti static/CLI selalu memiliki prioritas lebih tinggi daripada AI saat merge parameter.
- AST parse error menghasilkan fallback metadata yang masih dapat diedit manual; Publish/Test tetap melakukan validasi yang ketat.
- UI Admin menampilkan AI provider yang dipakai dan warning ketika fallback aktif.
