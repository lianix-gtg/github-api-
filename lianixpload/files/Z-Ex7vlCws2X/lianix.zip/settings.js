/*
 * ============================================================
 * 🔧 TEMPAT SETTING UTAMA BOT — EDIT BAGIAN INI
 * ============================================================
 * Token bot, API Pterodactyl, owner, channel notif, gambar,
 * web panel, dan setting anti-kill dijelaskan di PANDUAN_LENGKAP_BOT.txt.
 * Cari komentar "EDIT DI SINI" untuk nilai yang boleh diubah.
 */
require("dotenv").config();
const ownerStore   = require("./src/data/ownerStore.js");
const panelStore   = require("./src/data/panelStore.js");
const channelStore = require("./src/data/channelStore.js");

// CATATAN: settings.token, settings.apikey, dll di bawah ini masih
// hardcoded (bawaan project ini). settings.licenseGithub.readToken
// khusus DIAMBIL DARI .env (LICENSE_GH_TOKEN) karena file settings.js
// ini ikut dibundle & dijual ke pembeli SC -- token baca lisensi
// TIDAK BOLEH ikut kebawa ke pembeli. Ati-ati: JANGAN share/upload/
// commit file .env ke tempat publik.

const settings = {
  // ✏️ EDIT DI SINI #1 — TOKEN BOT TELEGRAM
  token: "8853303612:AAGuCGNyZnYwrq3_P1KsvJMDTFAE8e_Dl1o",
  // ✏️ EDIT DI SINI #2 — PLTA GLOBAL LAMA (jika masih dipakai fitur tertentu)
  apikey: "ptla_8ByKxKdEkmiTfcHxWbGc9AmxLN3aSkWwO63xvvxWOTl",
  // ownerId asli ada di db/owner.json (getter di bawah), ini cuma fallback
  ownerId: 6301365869,
  // ✏️ EDIT DI SINI #3 — USERNAME OWNER/DEVELOPER
  dev: "yoennakbobo",
  dana: "-",
  // chUsn (channel wajib-join) juga getter dinamis, lihat di bawah
  groupId: [-1003749849944],

  // channel notifikasi tiap panel baru dibuat (bot wajib admin di sini)
  // ✏️ EDIT DI SINI #4 — ID CHANNEL NOTIFIKASI PANEL
  notifChannelId: -1003868407936,
  // ✏️ EDIT DI SINI #5 — FOTO NOTIFIKASI PANEL
  notifChannelImage: "https://files.catbox.moe/4vjwtd.jpg",

  // ✏️ EDIT DI SINI — COOKIE SESSION ALIGHTFREE
  // Ambil dari browser: Network tab → /api/send → Request Headers → cookie
  // Format: "alight_session=...%7D" (copy nilai header cookie lengkap)
  alightfreeCookie: process.env.ALIGHTFREE_COOKIE || "",

  apiDigitalOcean: "",
  apiDigitalOcean2: "",
  apiDigitalOcean3: "",
  apiDigitalOcean4: "",
  apiDigitalOcean5: "",
  apiDigitalOcean6: "",
  apiDigitalOcean7: "",
  apiDigitalOcean8: "",
  apiDigitalOcean9: "",
  apiDigitalOcean10: "",
  pp: "https://www.upload.ee/image/19648192/43f63a158cf294578f7b9dcadcde4b7a.jpg",
  ppVid: "https://www.upload.ee/image/19648192/43f63a158cf294578f7b9dcadcde4b7a.jpg",
  panel: "https://www.upload.ee/image/19648192/43f63a158cf294578f7b9dcadcde4b7a.jpg",
  qris: "https://files.catbox.moe/weikf8.jpg",

  // domain/plta/pltc tiap versi panel: getter dinamis di bawah (panelStore)

  // ✏️ EDIT DI SINI #8 — LOCATION ID PTERODACTYL
  loc: "1",
  // ✏️ EDIT DI SINI #9 — ALLOCATION ID DEFAULT
  allocation: "15",

  // Docker image khusus runtime Python. Bisa diganti lewat .env:
  // PYTHON_DOCKER_IMAGE=ghcr.io/parkervcp/yolks:python_3.12
  // Jangan biarkan undefined karena Pterodactyl mewajibkan field docker_image.
  dockerImagePython: process.env.PYTHON_DOCKER_IMAGE || "ghcr.io/parkervcp/yolks:python_3.12",

  // ===== Web Panel Mini App =====
  // port untuk HTTP server webpanel (default 3000)
  // webpanel_url = URL publik HTTPS yang mengarah ke server ini
  // (pakai Nginx reverse proxy / Cloudflare Tunnel / ngrok)
  // WAJIB diisi agar tombol "Panel Login" di bot bisa dibuka sebagai Mini App
  webpanel: {
    // ✏️ EDIT DI SINI #6 — PORT WEB PANEL
    port: 3000,
    // ✏️ EDIT DI SINI #7 — URL WEB PANEL PUBLIK HTTPS
    url: "https://ganti-dengan-domain-anda.com",  // ← ganti ini
  },

  // Anti Kill: auto-suspend server yang CPU/Disk-nya kelewat batas
  antiKill: {
    enabled: true,
    intervalMs: 120000,   // cek tiap 2 menit (ms)
    cpuThreshold: 500,    // % CPU sebelum server di-flag
    diskThresholdMb: 5120,// MB disk sebelum server di-flag
    notifyChatId: null,   // chat notif, null = pakai ownerId
    // Short identifier server yang ngerun bot ini sendiri (bisa dilihat
    // di URL panel: panel.domain/server/XXXXXXXX atau lewat /devpanel).
    // Server ini TIDAK akan di-suspend, hanya CPU-nya di-cap kalau over.
    selfIdentifier: "a5dd014c",
    // Batas CPU (%) yang di-set ke server self kalau over threshold.
    // 500 = 5 core × 100%. Pterodactyl: 0 = unlimited.
    cpuCapPercent: 500,
  },
};

// domain/plta/pltc Panel 1 & ADP -- getter dinamis dari panelStore
Object.defineProperties(settings, {
  domain: { get: () => panelStore.getPanel("1").domain, enumerable: true, configurable: true },
  plta: { get: () => panelStore.getPanel("1").plta, enumerable: true, configurable: true },
  pltc: { get: () => panelStore.getPanel("1").pltc, enumerable: true, configurable: true },
  domain_adp: { get: () => panelStore.getPanel("adp").domain, enumerable: true, configurable: true },
  plta_adp: { get: () => panelStore.getPanel("adp").plta, enumerable: true, configurable: true },
  pltc_adp: { get: () => panelStore.getPanel("adp").pltc, enumerable: true, configurable: true },
});

// domainV2..V20 / pltaV2..V20 / pltcV2..V20 -- getter dinamis per slot
for (let i = 2; i <= 20; i++) {
  const key = String(i);
  Object.defineProperty(settings, `domainV${i}`, { get: () => panelStore.getPanel(key).domain, enumerable: true, configurable: true });
  Object.defineProperty(settings, `pltaV${i}`, { get: () => panelStore.getPanel(key).plta, enumerable: true, configurable: true });
  Object.defineProperty(settings, `pltcV${i}`, { get: () => panelStore.getPanel(key).pltc, enumerable: true, configurable: true });
}

// chUsn: channel wajib-join, live dari db/channels.json
Object.defineProperty(settings, "chUsn", {
  get() {
    const channels = channelStore.getChannels();
    return (channels[0] && channels[0].username) || "@skynexaaa";
  },
  enumerable: true,
  configurable: true,
});

// ownerId live dari db/owner.json (bisa ganti lewat tombol "🔧 Ganti Owner")
Object.defineProperty(settings, "ownerId", {
  get: () => ownerStore.getOwnerId(),
  enumerable: true,
  configurable: true,
});

// Nama owner/developer juga live dari db/owner.json.
// Ini mencegah backup/restore kembali menampilkan nama owner lama
// yang masih tertulis sebagai fallback di object settings.
Object.defineProperty(settings, "dev", {
  get: () => {
    const name = ownerStore.getOwnerName();
    return String(name || "LianiX").replace(/^@/, "");
  },
  enumerable: true,
  configurable: true,
});

// password gerbang /start — stored as SHA-256 hash, JANGAN expose plain text
// hash dari: yoengtg
// 🔐 PASSWORD /START DISIMPAN SEBAGAI HASH — JANGAN GANTI KECUALI TAHU CARANYA
const _START_PASSWORD_HASH = "0f627908ecc59eb2f870a0e5d215a0a650bd141c2bd99595f7cce2facb3d6d9b";
const _crypto = require("crypto");
Object.defineProperty(settings, "startPassword", {
  get: () => _START_PASSWORD_HASH,
  enumerable: false, // disembunyikan dari enumeration
  configurable: false,
});
// helper: cek input password vs hash
settings.checkPassword = (input) =>
  _crypto.createHash("sha256").update(input).digest("hex") === _START_PASSWORD_HASH;

// URL tombol "Buy Script"
Object.defineProperty(settings, "buyScriptUrl", {
  get: () => "https://t.me/yoennakbobo",
  enumerable: true,
  configurable: true,
});

// ===== Lisensi GitHub (repo PUBLIK, read-only) =====
// Cek hash token bot terdaftar di authorized.json. Token privat (GHP)
// buat nulis ke repo ini cuma ada di tool voidra-admin-tos, gak pernah
// ikut di SC ini. Kelola token pembeli: lihat voidra-admin-tos/README.md
// ======================= LISENSI GITHUB (UPDATED) =======================
// Token terdaftar disimpan di GitHub repo ibnuuyingjunde-art/bot-tokens
// sebagai plain array di token.json.
// Kelola token lewat Bot Add Token (project bot-add-token).
// config akses lisensi — dikodekan, jangan diutak-atik
const _lghRaw = Buffer.from('eyJvd25lciI6ICJpYm51dXlpbmdqdW5kZS1hcnQiLCAicmVwbyI6ICJib3QtdG9rZW5zIiwgImJyYW5jaCI6ICJtYWluIiwgInBhdGgiOiAidG9rZW4uanNvbiJ9', 'base64').toString('utf8');
const _lghCfg = JSON.parse(_lghRaw);
settings.licenseGithub = {
  owner:     _lghCfg.owner,
  repo:      _lghCfg.repo,
  branch:    _lghCfg.branch,
  path:      _lghCfg.path,
  readToken: process.env.LICENSE_GH_TOKEN || "",
};

Object.defineProperty(settings, "licenseRawUrl", {
  get() {
    const { owner, repo, branch, path } = settings.licenseGithub;
    return `https://raw.githubusercontent.com/${owner}/${repo}/${branch}/${path}`;
  },
  enumerable: true,
  configurable: true,
});

Object.defineProperty(settings, "licenseApiUrl", {
  get() {
    const { owner, repo, branch, path } = settings.licenseGithub;
    return `https://api.github.com/repos/${owner}/${repo}/contents/${path}?ref=${branch}`;
  },
  enumerable: true,
  configurable: true,
});

// Owner check terpusat: Owner #1 dan Owner #2 memiliki akses owner yang sama.
settings.isOwner = (userId) => {
  try {
    return ownerStore.getOwnerIds().map(String).includes(String(userId));
  } catch (_) {
    return String(userId) === String(settings.ownerId);
  }
};

module.exports = settings;
