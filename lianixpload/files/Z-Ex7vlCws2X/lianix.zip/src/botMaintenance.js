// src/botMaintenance.js
// ============================================================
// BOT-WIDE MAINTENANCE MODE
// - Owner ON → semua user biasa diblok, dapat pesan custom
// - Owner tetap bisa gunain bot seperti biasa
// - Bisa setting pesan yang diterima user saat maintenance
// - Data disimpan di db/botMaintenance.json
// ============================================================
'use strict';

const fs   = require('fs-extra');
const path = require('path');

const DB_FILE = path.join(__dirname, '..', 'db', 'botMaintenance.json');

const DEFAULT = {
  enabled: false,
  message: '🛠 <b>BOT SEDANG MAINTENANCE</b>\n\nBot sedang dalam perbaikan oleh developer.\nSilakan tunggu hingga maintenance selesai.\n\n<i>Terima kasih atas pengertiannya 🙏</i>',
};

// ─── DB ─────────────────────────────────────────────────────

function load() {
  let data = { ...DEFAULT };
  try {
    if (fs.existsSync(DB_FILE)) {
      const d = fs.readJsonSync(DB_FILE);
      if (d && typeof d === 'object') data = Object.assign({}, DEFAULT, d);
    }
  } catch {}

  // Jangan pernah membiarkan pesan kosong. Jika owner belum mengisi
  // setting pesan, otomatis gunakan pesan default.
  if (typeof data.message !== 'string' || !data.message.trim()) {
    data.message = DEFAULT.message;
    try { save(data); } catch {}
  }

  data.enabled = Boolean(data.enabled);
  return data;
}

function save(data) {
  try {
    fs.ensureDirSync(path.dirname(DB_FILE));
    fs.writeJsonSync(DB_FILE, data, { spaces: 2 });
  } catch (e) {
    console.error('[botMaintenance] save:', e.message);
  }
}

// ─── Helpers ─────────────────────────────────────────────────

function esc(v = '') {
  return String(v).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function isOwner(id, settings) {
  return settings.isOwner(id);
}

function isEnabled() {
  return load().enabled;
}

function getMessage() {
  return load().message || DEFAULT.message;
}

// ─── Global maintenance gate ─────────────────────────────────
//
// processUpdate dipasang di level paling luar, sebelum TelegramBot
// menjalankan listener `message`, `callback_query`, `onText`, dll.
// Ini sengaja dibuat di sini supaya saat maintenance ON user private
// TIDAK mungkin masuk ke handler fitur apa pun.
//
// RULE:
// 1. OWNER                 -> semua update tetap diproses normal.
// 2. PRIVATE user biasa    -> update dihentikan, hanya kirim maintenance.
// 3. GROUP user biasa      -> pesan biasa tanpa prefix dihentikan diam-diam.
//                             Command ber-prefix apa pun -> maintenance.
// 4. Callback private      -> maintenance saja, callback tidak diteruskan.

function isGroupChat(chat) {
  return chat?.type === 'group' || chat?.type === 'supergroup';
}

function isPrefixedCommand(text = '') {
  const t = String(text).trim();
  if (!t) return false;

  // Semua prefix non-huruf/non-angka diterima:
  // /menu, .menu, !menu, #menu, -menu, ~menu, dll.
  return /^[^\p{L}\p{N}\s]+[\p{L}\p{N}_]+(?:@\w+)?(?:\s|$)/u.test(t);
}

function maintenanceMessage(bot, chatId, replyTo) {
  if (!chatId) return;
  const opts = { parse_mode: 'HTML' };
  if (replyTo) opts.reply_to_message_id = replyTo;

  bot.sendMessage(chatId, getMessage(), opts).catch(() => {});
}

function patchEmitter(bot, settings) {
  if (bot.__botMaintenancePatched) return;
  bot.__botMaintenancePatched = true;

  const originalProcessUpdate = bot.processUpdate?.bind(bot);

  // Fallback hanya jika library Telegram yang dipakai tidak mempunyai
  // processUpdate. Normalnya node-telegram-bot-api selalu memilikinya.
  if (typeof originalProcessUpdate !== 'function') return;

  bot.processUpdate = function(update) {
    if (!isEnabled()) {
      return originalProcessUpdate(update);
    }

    // Ambil identitas pengirim + chat dari update yang umum dipakai Telegram.
    const message = update?.message || update?.edited_message ||
      update?.channel_post || update?.edited_channel_post;
    const callback = update?.callback_query;

    const from = message?.from || callback?.from;
    const chat = message?.chat || callback?.message?.chat;
    const fromId = from?.id;
    const chatId = chat?.id;

    // Owner tidak boleh terkena maintenance sama sekali.
    if (fromId && isOwner(fromId, settings)) {
      return originalProcessUpdate(update);
    }

    // Tidak ada user/chat yang relevan: jangan biarkan update aneh masuk
    // ke handler fitur ketika maintenance aktif.
    if (!chatId) {
      return;
    }

    // CALLBACK:
    // Private user -> hanya maintenance.
    // Group callback -> diam; tidak ada fitur yang boleh dijalankan.
    if (callback) {
      if (!isGroupChat(chat)) {
        maintenanceMessage(
          bot,
          chatId,
          callback?.message?.message_id
        );
      }
      bot.answerCallbackQuery(callback.id).catch(() => {});
      return;
    }

    // MESSAGE:
    if (message) {
      const group = isGroupChat(chat);
      const text = typeof message.text === 'string' ? message.text : '';

      if (group) {
        // Group hanya diberi maintenance jika benar-benar memanggil
        // command/fitur dengan prefix.
        if (isPrefixedCommand(text)) {
          maintenanceMessage(bot, chatId, message.message_id);
        }

        // SELALU stop di sini agar fitur lain tidak ikut berjalan.
        return;
      }

      // PRIVATE user biasa:
      // Apa pun yang dikirim (/start, /menu, teks, foto, tombol, dll.)
      // hanya menghasilkan SATU pesan maintenance dan tidak diteruskan.
      maintenanceMessage(bot, chatId, message.message_id);
      return;
    }

    // Semua update user non-owner lainnya saat maintenance juga diblok.
    // Jangan meneruskan ke modul fitur.
    return;
  };
}

// ─── UI builders ─────────────────────────────────────────────

function buildMenuText(db) {
  const status = db.enabled ? '🔴 <b>MAINTENANCE</b>' : '🟢 <b>NORMAL</b>';
  return (
    `<blockquote expandable>⌗ <b>BOT MAINTENANCE MODE</b>\n\n` +
    `Status : ${status}\n\n` +
    `📋 <b>Cara pakai:</b>\n` +
    `• Tekan <b>ON/OFF Maintenance</b> untuk mengaktifkan atau mematikan\n` +
    `• Saat maintenance ON, semua user tidak bisa pakai bot\n` +
    `• <b>Owner tetap bisa pakai bot seperti biasa</b>\n` +
    `• Tekan <b>⚙️ Setting Pesan</b> untuk mengubah pesan yang diterima user\n\n` +
    `✉️ <b>Pesan saat ini:</b>\n` +
    `<i>${esc(db.message).slice(0, 400)}</i></blockquote>`
  );
}

function buildKeyboard(db) {
  return {
    inline_keyboard: [
      [
        {
          text: db.enabled ? '🔴 Maintenance • ON (Matikan)' : '🟢 Maintenance • OFF (Aktifkan)',
          callback_data: 'botmaint:toggle',
        },
      ],
      [
        { text: '⚙️ Setting Pesan', callback_data: 'botmaint:setmsg_menu' },
      ],
      [
        { text: '‹‹‹', callback_data: 'devpanel' },
      ],
    ],
  };
}

function buildSetmsgText(db) {
  return (
    `<blockquote expandable>✉️ <b>SETTING PESAN MAINTENANCE</b>\n\n` +
    `Pesan ini akan diterima user saat bot dalam mode maintenance.\n\n` +
    `<b>Pesan saat ini:</b>\n` +
    `<i>${esc(db.message).slice(0, 500)}</i>\n\n` +
    `Ketik pesan baru dan kirim, atau tekan Reset untuk kembali ke default.\n` +
    `HTML tag didukung: <code>&lt;b&gt;</code> <code>&lt;i&gt;</code> <code>&lt;code&gt;</code></blockquote>`
  );
}

function buildSetmsgKeyboard() {
  return {
    inline_keyboard: [
      [{ text: '↺ Reset ke Default', callback_data: 'botmaint:resetmsg' }],
      [{ text: '‹‹‹', callback_data: 'botmaint:back_menu' }],
    ],
  };
}

// ─── Session: menunggu input pesan baru ───────────────────────
const AWAIT_MSG = new Map(); // userId -> {chatId,messageId}; jaga satu kartu UI

// ─── Register ─────────────────────────────────────────────────

module.exports = (bot) => {
  const settings = require('../settings.js');
  patchEmitter(bot, settings);

  // /botmaintenance dan /maintenance — menu maintenance utama
  bot.onText(/^\/(?:botmaintenance|maintenance)$/i, async (msg) => {
    if (!isOwner(msg.from?.id, settings)) return;
    const db = load();
    return bot.sendMessage(msg.chat.id, buildMenuText(db), {
      parse_mode: 'HTML',
      reply_markup: buildKeyboard(db),
    });
  });

  // Tangkap input pesan baru dari owner (saat await aktif)
  bot.on('message', async (msg) => {
    if (!msg.text) return;
    if (!isOwner(msg.from?.id, settings)) return;
    if (!AWAIT_MSG.has(String(msg.from.id))) return;
    const waitCtx = AWAIT_MSG.get(String(msg.from.id));
    AWAIT_MSG.delete(String(msg.from.id));

    const newMsg = msg.text.trim();
    const db = load();
    // Input kosong => kembali ke pesan default, bukan diam tanpa reaksi.
    db.message = newMsg || DEFAULT.message;
    save(db);

    try { await bot.deleteMessage(msg.chat.id, msg.message_id); } catch (_) {}
    if (waitCtx?.messageId) {
      return bot.editMessageText(buildMenuText(db), { chat_id: waitCtx.chatId, message_id: waitCtx.messageId, parse_mode:'HTML', reply_markup:buildKeyboard(db) }).catch(()=>{});
    }
    return bot.sendMessage(msg.chat.id, buildMenuText(db), { parse_mode:'HTML', reply_markup:buildKeyboard(db) });
  });

  // Callback query
  bot.on('callback_query', async (q) => {
    // Entry point from the developer panel.
    if (q.data === 'botmaintenance_menu' || q.data === 'maintenance_menu') {
      if (!isOwner(q.from?.id, settings)) {
        return bot.answerCallbackQuery(q.id, { text: 'Khusus Owner.', show_alert: true }).catch(() => {});
      }
      await bot.answerCallbackQuery(q.id).catch(() => {});
      const db = load();
      return bot.editMessageText(buildMenuText(db), {
        chat_id:q.message.chat.id, message_id:q.message.message_id, parse_mode:'HTML', reply_markup:buildKeyboard(db)
      }).catch(async () => {
        try { await bot.editMessageCaption(buildMenuText(db), {chat_id:q.message.chat.id,message_id:q.message.message_id,parse_mode:'HTML',reply_markup:buildKeyboard(db)}); } catch (_) {}
      });
    }

    if (!q.data?.startsWith('botmaint:')) return;
    if (!isOwner(q.from?.id, settings)) {
      return bot.answerCallbackQuery(q.id, { text: 'Khusus Owner.', show_alert: true }).catch(() => {});
    }

    const action = q.data.slice('botmaint:'.length);
    const db = load();

    if (action === 'toggle') {
      db.enabled = !db.enabled;
      save(db);
      await bot.answerCallbackQuery(q.id, {
        text: db.enabled ? '🔴 Maintenance ON — user tidak bisa pakai bot' : '🟢 Maintenance OFF — bot kembali normal',
      }).catch(() => {});
      return bot.editMessageText(buildMenuText(db), {
        chat_id: q.message.chat.id,
        message_id: q.message.message_id,
        parse_mode: 'HTML',
        reply_markup: buildKeyboard(db),
      }).catch(() => {});
    }

    if (action === 'setmsg_menu') {
      await bot.answerCallbackQuery(q.id).catch(() => {});
      AWAIT_MSG.set(String(q.from.id), {chatId:q.message.chat.id,messageId:q.message.message_id});
      return bot.editMessageText(buildSetmsgText(db), {
        chat_id: q.message.chat.id,
        message_id: q.message.message_id,
        parse_mode: 'HTML',
        reply_markup: buildSetmsgKeyboard(),
      }).catch(() => {});
    }

    if (action === 'resetmsg') {
      db.message = DEFAULT.message;
      save(db);
      AWAIT_MSG.delete(String(q.from.id));
      await bot.answerCallbackQuery(q.id, { text: 'Pesan direset ke default.' }).catch(() => {});
      return bot.editMessageText(buildMenuText(db), {
        chat_id: q.message.chat.id,
        message_id: q.message.message_id,
        parse_mode: 'HTML',
        reply_markup: buildKeyboard(db),
      }).catch(() => {});
    }

    if (action === 'back_menu') {
      AWAIT_MSG.delete(String(q.from.id));
      await bot.answerCallbackQuery(q.id).catch(() => {});
      return bot.editMessageText(buildMenuText(db), {
        chat_id: q.message.chat.id,
        message_id: q.message.message_id,
        parse_mode: 'HTML',
        reply_markup: buildKeyboard(db),
      }).catch(() => {});
    }

  });
};

module.exports.isEnabled  = isEnabled;
module.exports.getMessage = getMessage;
