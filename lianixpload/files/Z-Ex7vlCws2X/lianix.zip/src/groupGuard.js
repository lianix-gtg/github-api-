const fs = require('fs');
const path = require('path');
const settings = require('../settings.js');

// safeRestrict — wrapper restrictChatMember yang aman, cek canRestrictTarget dulu.
async function safeRestrict(bot, chatId, userId, permissionsOrOpts, untilDate) {
  try {
    const ok = await canRestrictTarget(bot, chatId, userId);
    if (!ok) return;
    let permissions, until;
    if (permissionsOrOpts && permissionsOrOpts.permissions) {
      permissions = permissionsOrOpts.permissions;
      until = permissionsOrOpts.until_date || untilDate;
    } else {
      permissions = permissionsOrOpts || {};
      until = untilDate;
    }
    const opts = { chat_id: chatId, user_id: userId, permissions };
    if (until !== undefined) opts.until_date = until;
    await bot.restrictChatMember(chatId, userId, permissions, until !== undefined ? { until_date: until } : undefined);
  } catch (e) {
    // Gagal restrict (bot bukan admin, dll) — abaikan tanpa crash
  }
}

// Telegram tidak mengizinkan restrictChatMember terhadap creator/admin.
async function canRestrictTarget(bot, chatId, userId) {
  try {
    const member = await bot.getChatMember(chatId, userId);
    return !!member && member.status !== 'creator' && member.status !== 'administrator';
  } catch (err) {
    const d = String(err?.response?.body?.description || err?.message || err || '');
    if (/chat not found|user not found/i.test(d)) return false;
    // Do not turn a failed status lookup into an administrator restriction attempt.
    return false;
  }
}

const DB_DIR = path.join(process.cwd(), 'db');
const DB_FILE = path.join(DB_DIR, 'groupGuard.json');
const OWNER_ID = Number(settings.ownerId);
const MAX_WARNINGS = 3;
const DEFAULT_MUTE_MS = 60 * 60 * 1000;

// ───── helper: cek dev/owner ─────
function loadJsonArr(file) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')).map(String); } catch { return []; }
}
function isDevOrOwner(userId) {
  const id = String(userId);
  if (Number(id) === OWNER_ID) return true;
  const devFile = path.join(process.cwd(), 'db/users/developerUsers.json');
  const godFile = path.join(process.cwd(), 'db/users/godUsers.json');
  return loadJsonArr(devFile).includes(id) || loadJsonArr(godFile).includes(id);
}

const FEATURES = {
  link:     { label: 'Anti Link', icon: '🔗' },
  mention:  { label: 'Anti Mention', icon: '♙' },
  forward:  { label: 'Anti Forward', icon: '✉️' },
  bot:      { label: 'Anti Bot', icon: '🤖' },
  toxic:    { label: 'Anti Kata', icon: '🚫' },
  promo:    { label: 'Anti Promosi', icon: '📣' },
  adult:    { label: 'Anti 18+', icon: '🔞' },
  phishing: { label: 'Anti Phishing', icon: '🛡️' },
  scam:     { label: 'Anti Scam', icon: '⚠️' },
  phone:    { label: 'Anti Nomor', icon: '📱' },
  website:  { label: 'Anti Website', icon: '🌐' },
  duplicate:{ label: 'Anti Duplikat', icon: '♻️' },
  spam:     { label: 'Anti Spam', icon: '⚡' },
  flood:    { label: 'Anti Flood', icon: '🌊' },
};

const DEFAULT_WORDS = ['anjing','bangsat','kontol','memek','ngentot','tolol','goblok','idiot','bego','asu'];
const recent = new Map();
const lastText = new Map();
const adminCache = new Map();
const joinCache = new Map();
const pendingInput = new Map();
// pendingJoin: Map<userId, {chatId, msgId}> — user yang sedang menunggu verifikasi join
const pendingJoinVerify = new Map();
const botChannelAdminCache = new Map(); // chatId -> {at, channels}
const botChannelAdminWarned = new Map(); // chatId:channel -> last notification
function inputKey(chatId, userId) { return `${chatId}:${userId}`; }
const autoTimers = new Map();
const ownerFeatures = require('./ownerFeatures.js');
function firstJoinChannels() {
  return ownerFeatures.loadJoin().slice(0,5).map(s => s.username ? `@${String(s.username).replace(/^@/,'')}` : String(s.id)).filter(Boolean);
}

function ensureStore() {
  fs.mkdirSync(DB_DIR, { recursive: true });
  if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, JSON.stringify({}, null, 2));
}
function load() {
  ensureStore();
  try {
    const d = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
    return d && typeof d === 'object' ? d : {};
  } catch { return {}; }
}
function save(data) {
  ensureStore();
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
}
function defaults() {
  return {
    enabled: false,
    link:false, mention:false, forward:false, bot:false, toxic:false,
    promo:false, adult:false, phishing:false, scam:false, phone:false,
    website:false, duplicate:false, spam:false, flood:false,
    customWords: [...DEFAULT_WORDS],
    spamLimit: 5, spamWindowMs: 1000,
    actionModes: ['delete'],
    warnLimit: 3,
    muteMinutes: 60,
    wajibJoin: false,
    muteUntilJoin: false,
    wajibChannels: [],
    joinFirst: [],
    autoInterval: 0,
    lastAutoInterval: 0,
    autoText: '',
    autoEntities: [],
  };
}
function getConfig(chatId) {
  const db = load();
  const key = String(chatId);
  if (!db[key]) { db[key] = defaults(); save(db); }
  return { ...defaults(), ...db[key], customWords: Array.isArray(db[key].customWords) ? db[key].customWords : [...DEFAULT_WORDS], wajibChannels: Array.isArray(db[key].wajibChannels) ? db[key].wajibChannels : [], joinFirst: ownerFeatures.loadJoin().slice(0,5) };
}
function setConfig(chatId, patch) {
  const db = load();
  const key = String(chatId);
  db[key] = { ...defaults(), ...(db[key] || {}), ...patch };
  save(db);
  return getConfig(chatId);
}
function isGroup(msg) { return msg.chat && ['group','supergroup'].includes(msg.chat.type); }
function isAdmin(member) { return member && ['administrator','creator'].includes(member.status); }
async function botIsAdmin(bot, chatId) {
  try { const me = await bot.getMe(); return isAdmin(await bot.getChatMember(chatId, me.id)); } catch { return false; }
}
async function actorCanManage(bot, chatId, userId) {
  if (Number(userId) === OWNER_ID) return true;
  if (isDevOrOwner(userId)) return true;
  try { return isAdmin(await bot.getChatMember(chatId, userId)); } catch { return false; }
}

// ── Private: cek apakah boleh akses dari private chat (dev/owner) ──
async function canAccessFromPrivate(bot, chatId, userId) {
  return isDevOrOwner(userId);
}

function esc(v) { return String(v ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
function on(v) { return v ? '🟢 ON' : '🔴 OFF'; }
function actionText(cfg) { return Array.isArray(cfg.actionModes) && cfg.actionModes.length ? cfg.actionModes.join(' + ').toUpperCase() : 'DELETE'; }

function menuText(cfg) {
  const enabledCount = Object.keys(FEATURES).filter(k => cfg[k]).length;
  const total = Object.keys(FEATURES).length;
  return `<blockquote expandable><b>╭━━〔 🛡️ JAGA GRUP • LianiX 〕━━╮</b>\n` +
    `<i>Control • Moderation • Protection</i>\n` +
    `╰━━━━━━━━━━━━━━━━━━━━╯\n\n` +
    `⚙️ Status: <b>${cfg.enabled ? '🟢 AKTIF' : '🔴 NONAKTIF'}</b>\n` +
    `🛡️ Protection: <b>${enabledCount}/${total}</b> aktif\n` +
    `⚔️ Hukuman: <b>${esc(actionText(cfg))}</b>\n` +
    `⚠️ Warn: <b>${cfg.warnLimit}x</b>  •  🔇 Mute: <b>${cfg.muteMinutes}m</b>\n` +
    `📣 Wajib Join: <b>${cfg.wajibJoin ? '🟢 ON' : '🔴 OFF'}</b>  •  📅 Auto: <b>${cfg.autoInterval && cfg.autoText ? '🟢 ON' : cfg.autoInterval ? '🟡' : '🔴 OFF'}</b></blockquote>`;
}
function keyboard(cfg) {
  const f = k => `${FEATURES[k].icon} ${FEATURES[k].label} ${cfg[k] ? '🟢' : '🔴'}`;
  return { inline_keyboard: [
    [
      {text:'⚙️ SETTING',callback_data:'gg:settings'},
      {text:'⚔️ HUKUMAN',callback_data:'gg:punish'}
    ],
    [
      {text:f('link'),callback_data:'gg:toggle:link'},
      {text:f('mention'),callback_data:'gg:toggle:mention'}
    ],
    [
      {text:f('forward'),callback_data:'gg:toggle:forward'},
      {text:f('bot'),callback_data:'gg:toggle:bot'}
    ],
    [
      {text:f('toxic'),callback_data:'gg:toggle:toxic'},
      {text:f('promo'),callback_data:'gg:toggle:promo'}
    ],
    [
      {text:f('adult'),callback_data:'gg:toggle:adult'},
      {text:f('phishing'),callback_data:'gg:toggle:phishing'}
    ],
    [
      {text:f('scam'),callback_data:'gg:toggle:scam'},
      {text:f('phone'),callback_data:'gg:toggle:phone'}
    ],
    [
      {text:f('website'),callback_data:'gg:toggle:website'},
      {text:f('duplicate'),callback_data:'gg:toggle:duplicate'}
    ],
    [
      {text:f('spam'),callback_data:'gg:toggle:spam'},
      {text:f('flood'),callback_data:'gg:toggle:flood'}
    ],
    [
      {text:`☰ Kelola Kata (${cfg.customWords.length})`,callback_data:'gg:words'},
      {text:`🔇 Mute: ${cfg.muteMinutes}m`,callback_data:'gg:punish:mute'}
    ],
    [
      {text:'➖ Kurang',callback_data:'gg:warn:minus'},
      {text:`⚠️ Warn: ${cfg.warnLimit}x`,callback_data:'gg:punish:warn'},
      {text:'➕ Tambah',callback_data:'gg:warn:plus'}
    ],
    [
      {text:'📣 WAJIB JOIN',callback_data:'gg:joinmenu'}
    ],
    [
      {text:`📣 Wajib Join ${cfg.wajibJoin ? '🟢' : '🔴'}`,callback_data:'gg:join:toggle'},
      {text:`🔇 Mute sampai join ${cfg.muteUntilJoin ? '🟢' : '🔴'}`,callback_data:'gg:join:mute'}
    ],
    [
      {text:`📌 First Join (${Math.min(ownerFeatures.loadJoin().length,5)}/5)`,callback_data:'gg:join:channels'}
    ],
    [
      {text:`📅 PESAN OTOMATIS ${autoStatus(cfg)}`,callback_data:'gg:automenu'}
    ],
    [
      {text:`📅 Interval: ${cfg.autoInterval ? formatInterval(cfg.autoInterval) : 'OFF'}`,callback_data:'gg:auto:interval'},
      {text: cfg.autoText ? '✎ Edit Pesan ✅' : '✎ Set Pesan ⚠️',callback_data:'gg:auto:text'}
    ],
    [
      {text:'🔄 ON SEMUA',callback_data:'gg:onall'},
      {text:'⛔ OFF SEMUA',callback_data:'gg:offall'}
    ],
    [
      {text:'‹‹‹',callback_data:'groupmenu'}
    ]
  ]};
}

function settingsKeyboard(cfg) {
  const f = k => `${FEATURES[k].icon} ${FEATURES[k].label} ${cfg[k] ? '🟢' : '🔴'}`;
  return { inline_keyboard: [
    [{text:f('link'),callback_data:'gg:settings:toggle:link'},{text:f('mention'),callback_data:'gg:settings:toggle:mention'}],
    [{text:f('forward'),callback_data:'gg:settings:toggle:forward'},{text:f('bot'),callback_data:'gg:settings:toggle:bot'}],
    [{text:f('toxic'),callback_data:'gg:settings:toggle:toxic'},{text:f('promo'),callback_data:'gg:settings:toggle:promo'}],
    [{text:f('adult'),callback_data:'gg:settings:toggle:adult'},{text:f('phishing'),callback_data:'gg:settings:toggle:phishing'}],
    [{text:f('scam'),callback_data:'gg:settings:toggle:scam'},{text:f('phone'),callback_data:'gg:settings:toggle:phone'}],
    [{text:f('website'),callback_data:'gg:settings:toggle:website'},{text:f('duplicate'),callback_data:'gg:settings:toggle:duplicate'}],
    [{text:f('spam'),callback_data:'gg:settings:toggle:spam'},{text:f('flood'),callback_data:'gg:settings:toggle:flood'}],
    [{text:'🔄 ON SEMUA',callback_data:'gg:onall:settings'},{text:'⛔ OFF SEMUA',callback_data:'gg:offall:settings'}],
    [{text:'‹‹‹',callback_data:'gg:home'}]
  ]};
}
function punishKeyboard(cfg) {
  return { inline_keyboard: [
    [{text:`🗑 Delete ${cfg.actionModes.includes('delete')?'🟢':'🔴'}`,callback_data:'gg:mode:delete'},{text:`⚠️ Warn ${cfg.actionModes.includes('warn')?'🟢':'🔴'}`,callback_data:'gg:mode:warn'}],
    [{text:`👢 Kick ${cfg.actionModes.includes('kick')?'🟢':'🔴'}`,callback_data:'gg:mode:kick'},{text:`⛔ Ban ${cfg.actionModes.includes('ban')?'🟢':'🔴'}`,callback_data:'gg:mode:ban'}],
    [{text:`⚠️ Warn limit: ${cfg.warnLimit}x`,callback_data:'gg:punish:warn'},{text:`🔇 Mute: ${cfg.muteMinutes}m`,callback_data:'gg:punish:mute'}],
    [{text:'‹‹‹',callback_data:'gg:home'}]
  ]};
}
function joinKeyboard(cfg) {
  const rows = [
    [{text:`📣 Wajib Join ${cfg.wajibJoin?'🟢':'🔴'}`,callback_data:'gg:join:toggle'},
     {text:`🔇 Mute sampai join ${cfg.muteUntilJoin?'🟢':'🔴'}`,callback_data:'gg:join:mute'}]
  ];
  const slots = ownerFeatures.loadJoin().slice(0,5);
  slots.forEach((ch,i)=>rows.push([{text:`📌 ${ch.title || ch.username || ch.id}`,callback_data:'gg:join:noop'}]));
  if (!slots.length) rows.push([{text:'— First Join belum diatur owner —',callback_data:'gg:join:noop'}]);
  rows.push([{text:`ℹ️ First Join ${slots.length}/5`,callback_data:'gg:join:noop'}]);
  rows.push([{text:'‹‹‹',callback_data:'gg:home'}]);
  return { inline_keyboard: rows };
}
function autoKeyboard(cfg) {
  const isActive = cfg.autoInterval > 0 && !!cfg.autoText;
  const mark = ms => cfg.autoInterval === ms ? ' 🟢' : '';
  return { inline_keyboard: [
    [{text:`⏱ ${cfg.autoInterval ? formatInterval(cfg.autoInterval) : 'OFF'} ${isActive?'🟢':''}`,callback_data:'gg:auto:noop'},{text:cfg.autoText ? '✎ Edit Pesan ✅' : '✎ Set Pesan ⚠️',callback_data:'gg:auto:text'}],
    [{text:`1m${mark(60000)}`,callback_data:'gg:auto:set:60000'},{text:`5m${mark(300000)}`,callback_data:'gg:auto:set:300000'},{text:`10m${mark(600000)}`,callback_data:'gg:auto:set:600000'}],
    [{text:`30m${mark(1800000)}`,callback_data:'gg:auto:set:1800000'},{text:`1j${mark(3600000)}`,callback_data:'gg:auto:set:3600000'},{text:'⚙️ Custom',callback_data:'gg:auto:custom'}],
    cfg.autoInterval === 0 && cfg.autoText
      ? [{text:`${autoStatus(cfg)}`,callback_data:'gg:auto:noop'},{text:'👁️ Preview',callback_data:'gg:auto:preview'},{text:'🟢 ON',callback_data:'gg:auto:on'}]
      : [{text:`${autoStatus(cfg)}`,callback_data:'gg:auto:noop'},{text:'👁️ Preview',callback_data:'gg:auto:preview'},{text:'🔴 OFF',callback_data:'gg:auto:off'}],
    [{text:'‹‹‹',callback_data:'gg:home'}]
  ]};
}
function wordsKeyboard() {
  return { inline_keyboard: [[{text:'➕ Tambah Kata',callback_data:'gg:words:add'},{text:'➖ Hapus Kata',callback_data:'gg:words:del'}],[{text:'‹‹‹',callback_data:'gg:home'}]] };
}
function formatInterval(ms) { const m=Math.round(ms/60000); return m>=60 ? `${Math.round(m/60)}j` : `${m}m`; }
function autoStatus(cfg) {
  if (!cfg.autoInterval) return '🔴 OFF';
  return cfg.autoText ? '🟢 AKTIF' : '🟡 MENUNGGU PESAN';
}
function autoMenuText(cfg, extra='') {
  const isActive = cfg.autoInterval > 0 && !!cfg.autoText;
  return `<blockquote expandable><b>╭━━〔 📅 PESAN OTOMATIS 〕━━╮</b>
<i>Auto Send • Rich Text • Live Control</i>
╰━━━━━━━━━━━━━━━━━━━━╯

Status: <b>${autoStatus(cfg)}</b>
Interval: <b>${cfg.autoInterval ? formatInterval(cfg.autoInterval) : 'OFF'}</b>
Pesan: <b>${cfg.autoText ? '✅ Tersimpan' : '⚪ Belum diatur'}</b>
Format: <b>${cfg.autoEntities?.length ? '✨ Telegram Rich Text' : 'Teks biasa'}</b>` +
    (extra ? `\n\n${extra}` : '') + `</blockquote>`;
}
function pendingKeyboard(back='gg:home') {
  return { inline_keyboard: [[{text:'❌ Batal',callback_data:'gg:input:cancel'}],[{text:'‹‹‹',callback_data:back}]] };
}
async function edit(bot, q, text, markup) {
  try { await bot.editMessageCaption(text,{chat_id:q.message.chat.id,message_id:q.message.message_id,parse_mode:'HTML',reply_markup:markup}); return; } catch {}
  try { await bot.editMessageText(text,{chat_id:q.message.chat.id,message_id:q.message.message_id,parse_mode:'HTML',reply_markup:markup}); } catch {}
}

// ──────────────────────────────────────────────
// AUTO TIMER: hanya start jika BOTH interval & text tersedia
// ──────────────────────────────────────────────
function startAutoTimer(bot, chatId) {
  const key = String(chatId);
  // Selalu clear timer lama dulu
  if (autoTimers.has(key)) {
    clearInterval(autoTimers.get(key));
    autoTimers.delete(key);
  }
  const cfg = getConfig(chatId);
  // Hanya start jika interval > 0 DAN pesan sudah diset
  if (!cfg.autoInterval || !cfg.autoText) return;
  const ms = Math.max(60000, Number(cfg.autoInterval));
  const timer = setInterval(async () => {
    // Reload config setiap tick (mungkin sudah diubah)
    const c = getConfig(chatId);
    if (!c.autoInterval || !c.autoText) {
      clearInterval(timer);
      autoTimers.delete(key);
      return;
    }
    try {
      const opts = { parse_mode: undefined };
      if (Array.isArray(c.autoEntities) && c.autoEntities.length) {
        opts.entities = c.autoEntities;
      }
      await bot.sendMessage(chatId, c.autoText, opts);
    } catch (e) {
      reportError(bot, 'group_guard_auto_send', e, { chatId });
    }
  }, ms);
  if (timer.unref) timer.unref();
  autoTimers.set(key, timer);
}

// ──────────────────────────────────────────────
// ──────────────────────────────────────────────
// CHANNEL YANG BOT BENAR-BENAR ADMIN
// Hanya channel yang status bot = administrator/creator yang boleh
// masuk daftar Wajib Join. Channel yang bot belum admin dikeluarkan.
// ──────────────────────────────────────────────
async function getBotAdminChannels(bot, chatId, channels) {
  const list = Array.isArray(channels) ? channels.slice(0,10) : [];
  if (!list.length) return [];
  const key = String(chatId);
  const cached = botChannelAdminCache.get(key);
  if (cached && Date.now() - cached.at < 30000) return cached.channels;

  let me;
  try { me = await bot.getMe(); } catch { return []; }

  const active = [];
  for (const ch of list) {
    try {
      const member = await bot.getChatMember(ch, me.id);
      if (isAdmin(member)) {
        active.push(ch);
      } else {
        const warnKey = `${chatId}:${ch}`;
        const last = botChannelAdminWarned.get(warnKey) || 0;
        if (Date.now() - last > 6 * 60 * 60 * 1000) {
          botChannelAdminWarned.set(warnKey, Date.now());
          try {
            await bot.sendMessage(
              OWNER_ID,
              `⚠️ <b>WAJIB JOIN — BOT BELUM ADMIN</b>\n\n`+
              `Channel: <code>${esc(ch)}</code>\n`+
              `Grup: <code>${esc(chatId)}</code>\n\n`+
              `Bot belum dijadikan <b>admin</b> di channel ini. Channel tidak ditampilkan sebagai Wajib Join sampai bot menjadi admin.`,
              { parse_mode:'HTML' }
            );
          } catch {}
        }
      }
    } catch {
      const warnKey = `${chatId}:${ch}`;
      const last = botChannelAdminWarned.get(warnKey) || 0;
      if (Date.now() - last > 6 * 60 * 60 * 1000) {
        botChannelAdminWarned.set(warnKey, Date.now());
        try {
          await bot.sendMessage(
            OWNER_ID,
            `⚠️ <b>WAJIB JOIN — CHANNEL TIDAK AKTIF</b>\n\n`+
            `Channel: <code>${esc(ch)}</code>\n`+
            `Grup: <code>${esc(chatId)}</code>\n\n`+
            `Bot belum terdeteksi sebagai admin di channel ini. Channel tidak ditampilkan sebagai Wajib Join.`,
            { parse_mode:'HTML' }
          );
        } catch {}
      }
    }
  }
  botChannelAdminCache.set(key,{at:Date.now(),channels:active});
  return active;
}

// CHECK CHANNELS — cache 10 detik, skip kalau no channels
// ──────────────────────────────────────────────
async function checkChannels(bot, chatId, userId, channels) {
  const activeChannels = await getBotAdminChannels(bot, chatId, channels);
  if (!activeChannels.length) return true;
  const key = `${chatId}:${userId}`;
  const cached = joinCache.get(key);
  if (cached && Date.now() - cached.at < 5000) return cached.ok;
  for (const ch of activeChannels) {
    try {
      const m = await bot.getChatMember(ch, userId);
      if (!['member','administrator','creator'].includes(m.status)) {
        joinCache.set(key, { ok: false, at: Date.now() });
        return false;
      }
    } catch (e) {
      // Jika bot sudah admin tetapi Telegram masih tidak bisa membaca member,
      // jangan menganggap user belum join. Hanya channel aktif yang dipakai.
      continue;
    }
  }
  joinCache.set(key, { ok: true, at: Date.now() });
  return true;
}

// ──────────────────────────────────────────────
// GET UNJOINED CHANNELS — hanya channel yang bot adalah admin
// ──────────────────────────────────────────────
async function getUnjoinedChannels(bot, chatId, userId, channels) {
  const activeChannels = await getBotAdminChannels(bot, chatId, channels);
  const unjoined = [];
  for (const ch of activeChannels) {
    try {
      const m = await bot.getChatMember(ch, userId);
      if (!['member','administrator','creator'].includes(m.status)) unjoined.push(ch);
    } catch {
      // Tidak bisa verifikasi => jangan tampilkan sebagai belum join.
      continue;
    }
  }
  return unjoined;
}

// ──────────────────────────────────────────────
// KIRIM PESAN WAJIB JOIN ke member baru
// ──────────────────────────────────────────────
async function sendWajibJoinPrompt(bot, chatId, member, channels) {
  const activeChannels = await getBotAdminChannels(bot, chatId, channels);
  if (!activeChannels.length) return;
  const name = esc(member.first_name || 'User');
  // Ambil channel yang benar-benar belum di-join
  const unjoined = await getUnjoinedChannels(bot, chatId, member.id, activeChannels);
  const targetChannels = unjoined;

  // Baris tombol per channel (link langsung ke channel)
  const channelButtons = targetChannels.map(ch => {
    const url = ch.startsWith('@')
      ? `https://t.me/${ch.slice(1)}`
      : ch.startsWith('https://') ? ch : `https://t.me/${ch.replace(/^@/, '')}`;
    return [{ text: `📌 ${ch}`, url }];
  });

  const chList = targetChannels.map((c,i) => `${i+1}. ${esc(c)}`).join('\n');

  try {
    const sent = await bot.sendMessage(chatId,
      `📣 <b>WAJIB JOIN</b>\n` +
      `👋 Halo <a href="tg://user?id=${member.id}">${name}</a>!\n\n` +
      `Kamu harus join channel berikut terlebih dahulu:\n${chList}\n\n` +
      `Tekan tombol channel di bawah, lalu tekan <b>✅ Verifikasi</b>.`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            ...channelButtons,
            [{ text: '✅ Verifikasi — Saya Sudah Join', callback_data: `gg:joincheck:${member.id}` }]
          ]
        }
      }
    );
    // Simpan ref pesan untuk cleanup nanti
    pendingJoinVerify.set(String(member.id), {
      chatId: String(chatId),
      msgId: sent.message_id,
      at: Date.now()
    });
  } catch (e) {
    reportError(bot, 'group_guard_wajib_join_prompt', e, { chatId });
  }
}

async function applyActions(bot, msg, violation, cfg) {
  const modes = Array.isArray(cfg.actionModes) && cfg.actionModes.length ? cfg.actionModes.slice(0,2) : ['delete'];
  const chatId = msg.chat.id;
  for (const mode of modes) {
    try {
      if (mode === 'delete') await bot.deleteMessage(chatId, msg.message_id);
      if (mode === 'kick') await bot.banChatMember(chatId, msg.from.id).then(() => bot.unbanChatMember(chatId, msg.from.id, { only_if_banned: true }));
      if (mode === 'ban') await bot.banChatMember(chatId, msg.from.id);
      if (mode === 'warn') {
        const wf = path.join(DB_DIR, 'warnDB.json'); let db = {}; try { db = JSON.parse(fs.readFileSync(wf,'utf8')) || {}; } catch {}
        const key = `${chatId}:${msg.from.id}`; let count = Number(db[key]?.count || 0) + 1;
        db[key] = { count, updatedAt: Date.now() }; fs.writeFileSync(wf, JSON.stringify(db, null, 2));
        await bot.sendMessage(chatId, `⚠️ <b>Peringatan</b>\n👤 <a href="tg://user?id=${msg.from.id}">${esc([msg.from.first_name,msg.from.last_name].filter(Boolean).join(' ') || 'Pengguna')}</a>\nAlasan: <b>${esc(violation)}</b>\nWarning: <b>${count}/${cfg.warnLimit}</b>`, { parse_mode: 'HTML' });
        if (count >= cfg.warnLimit) {
          db[key] = { count: 0, updatedAt: Date.now() };
          fs.writeFileSync(wf, JSON.stringify(db, null, 2));
          await safeRestrict(bot, chatId, msg.from.id, { permissions: { can_send_messages: false }, until_date: Math.floor(Date.now()/500) + Math.max(1, Number(cfg.muteMinutes)) * 60 });
        }
      }
    } catch {}
  }
}

async function enforce(bot, msg) {
  if (!isGroup(msg) || !msg.from || msg.from.is_bot || Number(msg.from.id) === OWNER_ID) return;
  if (isDevOrOwner(msg.from.id)) return; // dev/owner bypass enforce
  const chatId = msg.chat.id; const cfg = getConfig(chatId);
  if (!cfg.enabled) return;
  const now = Date.now(); const cached = adminCache.get(chatId);
  if (!cached || now - cached.at > 30000) { const ok = await botIsAdmin(bot, chatId); adminCache.set(chatId, { ok, at: now }); if (!ok) return; } else if (!cached.ok) return;

  if (msg.new_chat_members && cfg.bot) {
    for (const member of msg.new_chat_members) { if (member.is_bot) { try { await bot.banChatMember(chatId, member.id); } catch {} } }
  }
  if (msg.new_chat_members && cfg.wajibJoin && ownerFeatures.loadJoin().length) {
    for (const member of msg.new_chat_members) {
      if (member.is_bot) continue;
      const joined = await checkChannels(bot, chatId, member.id, firstJoinChannels());
      if (!joined) {
        // Mute dulu jika opsi muteUntilJoin aktif
        if (cfg.muteUntilJoin) {
          try {
            await safeRestrict(bot, chatId, member.id, {
              permissions: {
                can_send_messages: false,
                can_send_polls: false,
                can_send_other_messages: false,
                can_add_web_page_previews: false,
                can_change_info: false,
                can_invite_users: false,
                can_pin_messages: false
              }
            });
          } catch {}
        }
        await sendWajibJoinPrompt(bot, chatId, member, firstJoinChannels());
      }
    }
  }

  // Cek wajib join untuk pesan biasa: hapus pesan & peringatkan
  if (cfg.wajibJoin && ownerFeatures.loadJoin().length && msg.text !== undefined) {
    const joined = await checkChannels(bot, chatId, msg.from.id, firstJoinChannels());
    if (!joined) {
      // Hapus pesan user yang belum join
      try { await bot.deleteMessage(chatId, msg.message_id); } catch {}
      // Mute kalau belum
      if (cfg.muteUntilJoin) {
        try {
          await safeRestrict(bot, chatId, msg.from.id, {
            permissions: {
              can_send_messages: false,
              can_send_polls: false,
              can_send_other_messages: false,
              can_add_web_page_previews: false
            }
          });
        } catch {}
      }
      // Kirim peringatan (throttle 30 detik per user agar tidak spam)
      const warnKey = `warnjoin:${chatId}:${msg.from.id}`;
      const lastWarn = joinCache.get(warnKey);
      if (!lastWarn || Date.now() - lastWarn > 30000) {
        joinCache.set(warnKey, Date.now());
        const name = esc([msg.from.first_name, msg.from.last_name].filter(Boolean).join(' ') || 'User');
        // Ambil hanya channel yang belum di-join user ini
        const unjoinedWarn = await getUnjoinedChannels(bot, chatId, msg.from.id, firstJoinChannels());
        const warnChannels = unjoinedWarn.length > 0 ? unjoinedWarn : firstJoinChannels();
        const chList = warnChannels.map((c,i) => `${i+1}. ${esc(c)}`).join('\n');
        const warnChannelButtons = warnChannels.map(ch => {
          const url = ch.startsWith('@')
            ? `https://t.me/${ch.slice(1)}`
            : ch.startsWith('https://') ? ch : `https://t.me/${ch.replace(/^@/, '')}`;
          return [{ text: `📌 ${ch}`, url }];
        });
        try {
          const warn = await bot.sendMessage(chatId,
            `🚫 <a href="tg://user?id=${msg.from.id}">${name}</a> kamu belum join channel wajib!\n\n${chList}\n\nTekan tombol channel lalu tekan <b>✅ Verifikasi</b>.`,
            {
              parse_mode: 'HTML',
              reply_markup: {
                inline_keyboard: [
                  ...warnChannelButtons,
                  [{ text: '✅ Verifikasi — Saya Sudah Join', callback_data: `gg:joincheck:${msg.from.id}` }]
                ]
              }
            }
          );
          // Auto hapus peringatan setelah 30 detik
          setTimeout(() => { try { bot.deleteMessage(chatId, warn.message_id); } catch {} }, 30000);
        } catch {}
      }
      return; // Jangan lanjut enforce lainnya
    } else if (cfg.muteUntilJoin) {
      // User sudah join semua channel aktif: buka mute otomatis.
      try {
        await safeRestrict(bot, chatId, msg.from.id, {
          permissions: {
            can_send_messages: true,
            can_send_audios: true,
            can_send_documents: true,
            can_send_photos: true,
            can_send_videos: true,
            can_send_video_notes: true,
            can_send_voice_notes: true,
            can_send_polls: true,
            can_send_other_messages: true,
            can_add_web_page_previews: true,
            can_change_info: false,
            can_invite_users: true,
            can_pin_messages: false,
            can_manage_topics: true
          }
        });
      } catch {}
      joinCache.delete(`${chatId}:${msg.from.id}`);
    }
  }

  const text = [msg.text, msg.caption].filter(Boolean).join(' '); let violation = null;
  if (cfg.link && /(https?:\/\/|www\.|t\.me\/|telegram\.me\/)/i.test(text)) violation = 'Anti Link';
  else if (cfg.mention && /@\w{3,}/.test(text)) violation = 'Anti Mention';
  else if (cfg.forward && (msg.forward_from || msg.forward_from_chat || msg.is_automatic_forward)) violation = 'Anti Forward';
  else if (cfg.toxic && cfg.customWords.some(w => w && new RegExp(`(?:^|\\W)${String(w).replace(/[.*+?^${}()|[\]\\]/g,'\\$&')}(?:$|\\W)`,'i').test(text))) violation = 'Anti Kata';
  else if (cfg.promo && /(jual|buy|sell|ready|order|open\s*(?:po|reseller)|murah|promo|diskon|harga|stok|pm\s*(?:saya|me)|hubungi|contact|wa\.me)/i.test(text)) violation = 'Anti Promosi';
  else if (cfg.adult && cfg.customWords.concat(['porn','porno','bokep','sex','seks','xnxx','xvideos','nsfw']).some(w => new RegExp(`(?:^|\\W)${String(w).replace(/[.*+?^${}()|[\]\\]/g,'\\$&')}(?:$|\\W)`,'i').test(text))) violation = 'Anti 18+';
  else if (cfg.phishing && /(verify|verification|login|claim|gift|airdrop|free\s*nitro|password|wallet).*(link|url|\.com|\.net|\.org|t\.me)/i.test(text)) violation = 'Anti Phishing';
  else if (cfg.scam && /(scam|penipuan|rekening|transfer|deposit|refund|investasi|giveaway).*(link|nomor|dm|wa|telegram|transfer)/i.test(text)) violation = 'Anti Scam';
  else if (cfg.phone && /(?:\+?62|0)8\d{7,13}\b/.test(text)) violation = 'Anti Nomor';
  else if (cfg.website && /\b[a-z0-9-]+\.(?:com|net|org|xyz|site|online|shop|id|co)\b/i.test(text)) violation = 'Anti Website';
  const userKey = `${chatId}:${msg.from.id}`;
  if (!violation && cfg.duplicate && text) { const prev = lastText.get(userKey); if (prev && prev.text === text && now - prev.at < 5000) violation = 'Anti Duplikat'; lastText.set(userKey, { text, at: now }); }
  if (!violation && cfg.spam) { const arr = (recent.get(userKey) || []).filter(t => now - t < cfg.spamWindowMs); arr.push(now); recent.set(userKey, arr); if (arr.length > cfg.spamLimit) violation = 'Anti Spam'; }
  if (!violation && cfg.flood && text && text.length > 1500) violation = 'Anti Flood';
  if (violation) await applyActions(bot, msg, violation, cfg);
}

module.exports = (bot) => {
  // Bangun timer pesan otomatis untuk konfigurasi lama saat bot start.
  for (const [chatId] of Object.entries(load())) startAutoTimer(bot, chatId);

  bot.on('callback_query', async q => {
    if (!q.data || !q.data.startsWith('gg:')) return;
    const chatId = q.message?.chat?.id;
    if (!chatId) return;

    const isPrivate = q.message.chat.type === 'private';
    const isGroupChat = ['group','supergroup'].includes(q.message.chat.type);

    // ── Tombol verifikasi join: siapa pun bisa pencet (tapi validasi userId) ──
    if (q.data.startsWith('gg:joincheck:')) {
      const targetId = q.data.split(':')[2];
      // Yang bisa verifikasi hanya user yang bersangkutan atau admin
      const isTarget = String(q.from.id) === String(targetId);
      const canManage = isTarget || await actorCanManage(bot, chatId, q.from.id);
      if (!canManage) return bot.answerCallbackQuery(q.id, { text: 'Tombol ini bukan untukmu.', show_alert: true });

      // Cek config grup
      const cfg = getConfig(chatId);
      const activeChannels = await getBotAdminChannels(bot, chatId, firstJoinChannels());
      const unjoinedCheck = await getUnjoinedChannels(bot, chatId, targetId, activeChannels);
      if (unjoinedCheck.length > 0) {
        const chNames = unjoinedCheck.join(', ');
        // Edit pesan dengan button channel yang belum di-join + tombol cek ulang
        const retryButtons = unjoinedCheck.map(ch => {
          const url = ch.startsWith('@')
            ? `https://t.me/${ch.slice(1)}`
            : ch.startsWith('https://') ? ch : `https://t.me/${ch.replace(/^@/, '')}`;
          return [{ text: `📌 ${ch}`, url }];
        });
        try {
          await bot.editMessageReplyMarkup(
            { inline_keyboard: [
                ...retryButtons,
                [{ text: '✅ Verifikasi — Saya Sudah Join', callback_data: `gg:joincheck:${targetId}` }]
              ]
            },
            { chat_id: chatId, message_id: q.message.message_id }
          );
        } catch {}
        return bot.answerCallbackQuery(q.id, { text: `❌ Belum join: ${chNames}\nJoin dulu lalu tekan Verifikasi lagi.`, show_alert: true });
      }
      // Sudah join — buka mute
      try {
        await safeRestrict(bot, chatId, targetId, {
          permissions: {
            can_send_messages: true,
            can_send_audios: true,
            can_send_documents: true,
            can_send_photos: true,
            can_send_videos: true,
            can_send_video_notes: true,
            can_send_voice_notes: true,
            can_send_polls: true,
            can_send_other_messages: true,
            can_add_web_page_previews: true,
            can_change_info: false,
            can_invite_users: true,
            can_pin_messages: false,
            can_manage_topics: true
          }
        });
      } catch {}
      // Hapus cache join biar langsung fresh
      joinCache.delete(`${chatId}:${targetId}`);
      // Hapus pending verify entry
      pendingJoinVerify.delete(String(targetId));
      await bot.answerCallbackQuery(q.id, { text: '✅ Verifikasi berhasil! Kamu sudah bisa chat.', show_alert: true });
      // Edit pesan wajib join jadi sukses
      try {
        await bot.editMessageText(
          `✅ <a href="tg://user?id=${targetId}">User</a> telah bergabung dan mute sudah dibuka.`,
          { chat_id: chatId, message_id: q.message.message_id, parse_mode: 'HTML' }
        );
        // Auto hapus pesan sukses setelah 10 detik
        setTimeout(() => { try { bot.deleteMessage(chatId, q.message.message_id); } catch {} }, 10000);
      } catch {}
      return;
    }

    // ── Akses dari private chat: khusus dev/owner ──
    if (isPrivate) {
      if (!isDevOrOwner(q.from.id)) {
        return bot.answerCallbackQuery(q.id, { text: '❌ Fitur ini hanya bisa diakses dev/owner dari private.', show_alert: true });
      }
      // dev/owner: semua aksi diizinkan (anggap chatId adalah grup target yg sudah tersimpan di pesan)
    } else if (isGroupChat) {
      if (!(await actorCanManage(bot, chatId, q.from.id))) {
        return bot.answerCallbackQuery(q.id, { text: 'Hanya admin grup/owner.', show_alert: true });
      }
    } else {
      return bot.answerCallbackQuery(q.id, { text: 'Buka Jaga Grup dari grup.', show_alert: true });
    }

    let cfg = getConfig(chatId); const d = q.data;
    if (d === 'gg:noop') return bot.answerCallbackQuery(q.id, { text: 'Aksi mengikuti menu Hukuman.' });
    if (d === 'gg:close') { await bot.answerCallbackQuery(q.id); try { await bot.deleteMessage(chatId, q.message.message_id); } catch {} return; }
    if (d === 'gg:home') { await bot.answerCallbackQuery(q.id); return edit(bot, q, menuText(cfg), keyboard(cfg)); }
    if (d === 'gg:open') { await bot.answerCallbackQuery(q.id); return edit(bot, q, menuText(cfg), keyboard(cfg)); }
    if (d === 'gg:settings') { await bot.answerCallbackQuery(q.id); return edit(bot, q, '<b>╭━━〔 SETTING JAGA GRUP 〕━━╮</b>\nPilih fitur yang ingin dijaga. Status berubah langsung tanpa restart.', settingsKeyboard(cfg)); }
    if (d === 'gg:punish') { await bot.answerCallbackQuery(q.id); return edit(bot, q, `<b>❗ HUKUMAN</b>\nMode aktif: <b>${esc(actionText(cfg))}</b>`, punishKeyboard(cfg)); }
    if (d.startsWith('gg:settings:toggle:')) {
      const key = d.split(':')[3]; if (!FEATURES[key]) return bot.answerCallbackQuery(q.id, { text: 'Fitur tidak ditemukan.', show_alert: true });
      cfg = setConfig(chatId, { [key]: !cfg[key], enabled: true });
      await bot.answerCallbackQuery(q.id, { text: `${FEATURES[key].label}: ${cfg[key] ? 'ON' : 'OFF'}` });
      return edit(bot, q, `<b>╭━━〔 SETTING JAGA GRUP 〕━━╮</b>\nStatus <b>${FEATURES[key].label}</b>: <b>${cfg[key] ? '🟢 ON' : '🔴 OFF'}</b>`, settingsKeyboard(cfg));
    }
    if (d.startsWith('gg:toggle:')) {
      const key = d.split(':')[2]; if (!FEATURES[key]) return bot.answerCallbackQuery(q.id, { text: 'Fitur tidak ditemukan.', show_alert: true });
      cfg = setConfig(chatId, { [key]: !cfg[key], enabled: true });
      await bot.answerCallbackQuery(q.id, { text: `${FEATURES[key].label}: ${cfg[key] ? 'ON' : 'OFF'}` });
      return edit(bot, q, menuText(cfg), keyboard(cfg));
    }
    if (d === 'gg:onall' || d === 'gg:onall:settings') {
      const patch = { enabled: true }; Object.keys(FEATURES).forEach(k => patch[k] = true); cfg = setConfig(chatId, patch);
      await bot.answerCallbackQuery(q.id, { text: 'Semua fitur ON' });
      return edit(bot, q, d.endsWith(':settings') ? '<b>╭━━〔 SETTING JAGA GRUP 〕━━╮</b>\n<b>🟢 Semua protection ON.</b>' : menuText(cfg), d.endsWith(':settings') ? settingsKeyboard(cfg) : keyboard(cfg));
    }
    if (d === 'gg:offall' || d === 'gg:offall:settings') {
      const patch = { enabled: false }; Object.keys(FEATURES).forEach(k => patch[k] = false); cfg = setConfig(chatId, patch);
      await bot.answerCallbackQuery(q.id, { text: 'Semua fitur OFF' });
      return edit(bot, q, d.endsWith(':settings') ? '<b>╭━━〔 SETTING JAGA GRUP 〕━━╮</b>\n<b>🔴 Semua protection OFF.</b>' : menuText(cfg), d.endsWith(':settings') ? settingsKeyboard(cfg) : keyboard(cfg));
    }
    if (d.startsWith('gg:mode:')) {
      const mode = d.split(':')[2]; let modes = [...(cfg.actionModes || [])];
      if (modes.includes(mode)) modes = modes.filter(x => x !== mode);
      else if (['delete','warn','kick','ban'].includes(mode)) { if (modes.length >= 2) return bot.answerCallbackQuery(q.id, { text: 'Maksimal 2 mode.', show_alert: true }); modes.push(mode); }
      cfg = setConfig(chatId, { actionModes: modes, enabled: true });
      await bot.answerCallbackQuery(q.id, { text: `Mode: ${actionText(cfg)}` });
      return edit(bot, q, `<b>❗ HUKUMAN</b>\nMode aktif: <b>${esc(actionText(cfg))}</b>`, punishKeyboard(cfg));
    }
    if (d === 'gg:punish:ban') { cfg = setConfig(chatId, { actionModes: ['ban'], enabled: true }); await bot.answerCallbackQuery(q.id, { text: 'Mode BAN aktif' }); return edit(bot, q, menuText(cfg), keyboard(cfg)); }
    if (d === 'gg:punish:warn') {
      const next = Number(cfg.warnLimit) >= MAX_WARNINGS ? 1 : Number(cfg.warnLimit) + 1;
      cfg = setConfig(chatId, { warnLimit: next }); await bot.answerCallbackQuery(q.id, { text: `Warn limit: ${next}x` });
      return edit(bot, q, `<b>❗ HUKUMAN</b>\nMode aktif: <b>${esc(actionText(cfg))}</b>`, punishKeyboard(cfg));
    }
    if (d === 'gg:punish:mute') {
      const cycle = [15,30,60,120,360,720,1440]; const idx = cycle.indexOf(Number(cfg.muteMinutes));
      const next = cycle[(idx < 0 ? 1 : idx + 1) % cycle.length];
      cfg = setConfig(chatId, { muteMinutes: next }); await bot.answerCallbackQuery(q.id, { text: `Mute: ${next} menit` });
      return edit(bot, q, `<b>❗ HUKUMAN</b>\nMode aktif: <b>${esc(actionText(cfg))}</b>`, punishKeyboard(cfg));
    }
    if (d === 'gg:warn:plus' || d === 'gg:warn:minus') {
      const next = Math.max(1, Math.min(MAX_WARNINGS, d.endsWith('plus') ? cfg.warnLimit + 1 : cfg.warnLimit - 1));
      cfg = setConfig(chatId, { warnLimit: next }); await bot.answerCallbackQuery(q.id, { text: `Warn limit: ${next}x` });
      return edit(bot, q, menuText(cfg), keyboard(cfg));
    }
    if (d === 'gg:words') {
      await bot.answerCallbackQuery(q.id);
      return edit(bot, q, `<b>╭━━〔 KELOLA KATA 〕━━╮</b>\n\nKata aktif: <b>${cfg.customWords.length}</b>\n${cfg.customWords.map((w,i) => `${i+1}. <code>${esc(w)}</code>`).join('\n') || 'Belum ada kata.'}`, wordsKeyboard());
    }
    if (d === 'gg:words:add' || d === 'gg:words:del') {
      const type = d.endsWith('add') ? 'wordAdd' : 'wordDel';
      pendingInput.set(inputKey(chatId, q.from.id), { type, chatId, menuMessageId: q.message.message_id, at: Date.now() });
      await bot.answerCallbackQuery(q.id, { text: 'Kirim input lalu menu akan kembali otomatis.' });
      return edit(bot, q, `<b>${type === 'wordAdd' ? '➕ TAMBAH KATA' : '➖ HAPUS KATA'}</b>\nKirim <b>1 kata</b> di chat ini.`, pendingKeyboard('gg:words'));
    }

    if (d === 'gg:joinmenu') {
      const activeChannels = await getBotAdminChannels(bot, chatId, firstJoinChannels());
      if (activeChannels.length !== ownerFeatures.loadJoin().length) {
        cfg = setConfig(chatId, { wajibChannels: activeChannels });
      }
      await bot.answerCallbackQuery(q.id);
      return edit(bot, q, `<b>📣 WAJIB JOIN</b>\n📌 First Join aktif: <b>${ownerFeatures.loadJoin().length}/5</b>\nHanya First Join yang bot bisa cek yang digunakan.`, joinKeyboard(cfg));
    }
    if (d === 'gg:join:noop') { return bot.answerCallbackQuery(q.id); }
    if (d.startsWith('gg:join:del:')) {
      await bot.answerCallbackQuery(q.id,{text:'First Join dikelola owner.',show_alert:true});
      return;
    }
    if (d === 'gg:join:toggle') {
      cfg = setConfig(chatId, { wajibJoin: !cfg.wajibJoin, enabled: true });
      await bot.answerCallbackQuery(q.id, { text: `Wajib Join: ${cfg.wajibJoin ? 'ON' : 'OFF'}` });
      return edit(bot, q, `<b>📣 WAJIB JOIN</b>\nStatus: <b>${cfg.wajibJoin ? '🟢 ON' : '🔴 OFF'}</b>`, joinKeyboard(cfg));
    }
    if (d === 'gg:join:mute') {
      cfg = setConfig(chatId, { muteUntilJoin: !cfg.muteUntilJoin });
      await bot.answerCallbackQuery(q.id, { text: `Mute sampai join: ${cfg.muteUntilJoin ? 'ON' : 'OFF'}` });
      return edit(bot, q, `<b>📣 WAJIB JOIN</b>\nMute sampai join: <b>${cfg.muteUntilJoin ? '🟢 ON' : '🔴 OFF'}</b>`, joinKeyboard(cfg));
    }
    if (d === 'gg:join:channels') {
      await bot.answerCallbackQuery(q.id, {text:'First Join dikelola owner. Maksimal 5 slot.',show_alert:true});
      return edit(bot, q, `<b>FIRST JOIN</b>

Jaga Grup sekarang memakai daftar <b>First Join global</b> milik owner.

Slot aktif: <b>${ownerFeatures.loadJoin().length}/5</b>

Gunakan <code>/joinfirst</code> sebagai owner untuk mengaturnya.`, joinKeyboard(cfg));
    }

    if (d === 'gg:automenu' || d === 'gg:auto:interval') {
      await bot.answerCallbackQuery(q.id);
      return edit(bot, q, autoMenuText(cfg, 'Pilih interval <b>dan</b> set pesan. Keduanya wajib agar auto aktif.'), autoKeyboard(cfg));
    }
    if (d === 'gg:input:cancel') {
      pendingInput.delete(inputKey(chatId, q.from.id)); cfg = getConfig(chatId);
      await bot.answerCallbackQuery(q.id, { text: 'Input dibatalkan' });
      return edit(bot, q, menuText(cfg), keyboard(cfg));
    }
    if (d === 'gg:auto:noop') {
      const status = cfg.autoInterval && cfg.autoText ? `✅ Auto aktif: ${formatInterval(cfg.autoInterval)}` :
        cfg.autoInterval && !cfg.autoText ? '⚠️ Interval aktif tapi pesan belum diset' :
        cfg.autoText && !cfg.autoInterval ? '⚠️ Pesan sudah ada tapi interval belum dipilih' :
        'Pilih interval dan set pesan untuk mengaktifkan.';
      return bot.answerCallbackQuery(q.id, { text: status, show_alert: true });
    }
    if (d.startsWith('gg:auto:set:')) {
      const ms = Number(d.split(':')[2]);
      if (!Number.isFinite(ms) || ms < 60000) return bot.answerCallbackQuery(q.id, { text: 'Interval tidak valid.', show_alert: true });
      cfg = setConfig(chatId, { autoInterval: ms, enabled: true });
      // Restart timer — hanya jalan kalau autoText sudah ada
      startAutoTimer(bot, chatId);
      const statusNote = cfg.autoText
        ? `✅ Auto <b>${formatInterval(ms)}</b> aktif`
        : `⚠️ Interval <b>${formatInterval(ms)}</b> tersimpan. Set pesan dulu agar auto mulai kirim.`;
      await bot.answerCallbackQuery(q.id, { text: cfg.autoText ? `Auto ${formatInterval(ms)} aktif` : `Interval tersimpan. Set pesan dulu!` });
      return edit(bot, q, autoMenuText(cfg, statusNote), autoKeyboard(cfg));
    }
    if (d === 'gg:auto:custom') {
      pendingInput.set(inputKey(chatId, q.from.id), { type: 'interval', chatId, menuMessageId: q.message.message_id, at: Date.now() });
      await bot.answerCallbackQuery(q.id, { text: 'Kirim angka menit, contoh 15.' });
      return edit(bot, q, autoMenuText(cfg, '⚙️ <b>Custom Interval</b>\nKirim angka menit, contoh <code>15</code>.'), pendingKeyboard('gg:automenu'));
    }
    if (d === 'gg:auto:text') {
      pendingInput.set(inputKey(chatId, q.from.id), { type: 'autoText', chatId, menuMessageId: q.message.message_id, at: Date.now() });
      await bot.answerCallbackQuery(q.id, { text: 'Kirim pesan berformat dari Telegram.' });
      return edit(bot, q, autoMenuText(cfg, '✎ <b>Edit Pesan</b>\nKirim pesan dengan format Telegram: <b>tebal</b>, <i>miring</i>, <u>garis bawah</u>, dll.'), pendingKeyboard('gg:automenu'));
    }
    if (d === 'gg:auto:preview') {
      if (!cfg.autoText) return bot.answerCallbackQuery(q.id, { text: 'Belum ada pesan tersimpan.', show_alert: true });
      const opts = {};
      if (Array.isArray(cfg.autoEntities) && cfg.autoEntities.length) opts.entities = cfg.autoEntities;
      await bot.answerCallbackQuery(q.id, { text: 'Preview dikirim.' });
      try { await bot.sendMessage(chatId, cfg.autoText, opts); } catch (e) { reportError(bot, 'group_guard_auto_preview', e, { chatId }); }
      return;
    }
    if (d === 'gg:auto:off') {
      const prevInterval = cfg.autoInterval || 0;
      cfg = setConfig(chatId, { autoInterval: 0, lastAutoInterval: prevInterval });
      startAutoTimer(bot, chatId); // akan clear timer karena interval = 0
      await bot.answerCallbackQuery(q.id, { text: 'Pesan otomatis OFF' });
      return edit(bot, q, autoMenuText(cfg, 'Auto send dimatikan. Pesan dan format tetap tersimpan.'), autoKeyboard(cfg));
    }
    if (d === 'gg:auto:on') {
      // Restore lastAutoInterval, atau fallback 60 menit kalau tidak ada
      const restoreMs = cfg.lastAutoInterval > 0 ? cfg.lastAutoInterval : 3600000;
      cfg = setConfig(chatId, { autoInterval: restoreMs, enabled: true });
      startAutoTimer(bot, chatId);
      await bot.answerCallbackQuery(q.id, { text: `Pesan otomatis ON — ${formatInterval(restoreMs)}` });
      return edit(bot, q, autoMenuText(cfg, `✅ Auto aktif kembali dengan interval <b>${formatInterval(restoreMs)}</b>.`), autoKeyboard(cfg));
    }
  });

  bot.on('message', async msg => {
    // Pendingkan input bisa dari grup maupun private (dev/owner)
    const isPrivateMsg = msg.chat?.type === 'private';
    if (!msg.from) return;

    // Jika di private, hanya dev/owner yang boleh ada pending input
    if (isPrivateMsg && !isDevOrOwner(msg.from.id)) {
      // Bukan grup, bukan dev — skip
      return;
    }

    const p = pendingInput.get(inputKey(msg.chat.id, msg.from.id));
    if (p && Number(p.chatId) === Number(msg.chat.id) && Date.now() - p.at < 5 * 60 * 1000 &&
        (isDevOrOwner(msg.from.id) || await actorCanManage(bot, msg.chat.id, msg.from.id))) {
      const text = String(msg.text || '').trim(); let cfg = getConfig(msg.chat.id);
      if (/^\/?(?:batal|cancel)$/i.test(text)) {
        pendingInput.delete(inputKey(msg.chat.id, msg.from.id));
        try { await bot.deleteMessage(msg.chat.id, msg.message_id); } catch {}
        if (p.menuMessageId) { try { await bot.editMessageText(menuText(cfg), { chat_id: msg.chat.id, message_id: p.menuMessageId, parse_mode: 'HTML', reply_markup: keyboard(cfg) }); } catch {} }
        return;
      }
      if (p.type === 'wordAdd' && text) {
        if (!cfg.customWords.includes(text.toLowerCase())) cfg = setConfig(msg.chat.id, { customWords: [...cfg.customWords, text.toLowerCase()], enabled: true });
        pendingInput.delete(inputKey(msg.chat.id, msg.from.id));
        try { await bot.deleteMessage(msg.chat.id, msg.message_id); } catch {}
        if (p.menuMessageId) { try { await bot.editMessageText(`<b>╭━━〔 KELOLA KATA 〕━━╮</b>\n\n<b>✅ Kata berhasil ditambahkan:</b> <code>${esc(text)}</code>\n\nKata aktif: <b>${cfg.customWords.length}</b>`, { chat_id: msg.chat.id, message_id: p.menuMessageId, parse_mode: 'HTML', reply_markup: wordsKeyboard() }); } catch {} }
        return;
      }
      if (p.type === 'wordDel' && text) {
        cfg = setConfig(msg.chat.id, { customWords: cfg.customWords.filter(w => w.toLowerCase() !== text.toLowerCase()) });
        pendingInput.delete(inputKey(msg.chat.id, msg.from.id));
        try { await bot.deleteMessage(msg.chat.id, msg.message_id); } catch {}
        if (p.menuMessageId) { try { await bot.editMessageText(`<b>╭━━〔 KELOLA KATA 〕━━╮</b>\n\n<b>✅ Kata berhasil dihapus:</b> <code>${esc(text)}</code>\n\nKata aktif: <b>${cfg.customWords.length}</b>`, { chat_id: msg.chat.id, message_id: p.menuMessageId, parse_mode: 'HTML', reply_markup: wordsKeyboard() }); } catch {} }
        return;
      }
      if (p.type === 'channels') {
        const requested = text.split(/\n|,|\s+/).map(x => x.trim()).filter(Boolean)
          .map(x => x.startsWith('@') ? x : x.replace(/^https?:\/\/t\.me\//i, '@'));
        const existing = Array.isArray(firstJoinChannels()) ? cfg.wajibChannels : [];
        const unique = [...new Set(requested)];
        const capacity = Math.max(0, 10 - existing.length);
        if (!unique.length || unique.length > capacity) {
          if (p.menuMessageId) try {
            await bot.editMessageText(
              `<b>❌ Batas channel</b>\n\nSudah ada <b>${existing.length}/10</b> channel.\nMaksimal tambah sekarang: <b>${capacity}</b>.`,
              {chat_id:msg.chat.id,message_id:p.menuMessageId,parse_mode:'HTML',reply_markup:pendingKeyboard('gg:joinmenu')}
            );
          } catch {}
          return;
        }

        // Validasi satu per satu: hanya channel yang bot benar-benar admin yang disimpan.
        const valid = [];
        const invalid = [];
        let me;
        try { me = await bot.getMe(); } catch { me = null; }
        for (const ch of unique) {
          try {
            const member = await bot.getChatMember(ch, me.id);
            if (isAdmin(member)) valid.push(ch); else invalid.push(ch);
          } catch { invalid.push(ch); }
        }

        const merged = [...existing, ...valid.filter(c => !existing.includes(c))].slice(0,10);
        cfg = setConfig(msg.chat.id, { wajibChannels: merged });
        botChannelAdminCache.delete(String(msg.chat.id));
        pendingInput.delete(inputKey(msg.chat.id, msg.from.id));
        try { await bot.deleteMessage(msg.chat.id, msg.message_id); } catch {}
        if (invalid.length) {
          try {
            await bot.sendMessage(OWNER_ID,
              `⚠️ <b>WAJIB JOIN — CHANNEL BELUM ADMIN</b>\n\n`+
              invalid.map(c=>`• <code>${esc(c)}</code>`).join('\n')+
              `\n\nGrup: <code>${esc(msg.chat.id)}</code>\nChannel tersebut tidak dimasukkan ke daftar Wajib Join.`,
              {parse_mode:'HTML'});
          } catch {}
        }
        if (p.menuMessageId) {
          try {
            await bot.editMessageText(
              `<b>📣 WAJIB JOIN</b>\n`+
              `✅ Aktif: <b>${valid.length}</b> channel\n`+
              (invalid.length ? `⚠️ Ditolak karena bot belum admin: <b>${invalid.length}</b>\n` : '')+
              `📌 Total: <b>${merged.length}/10</b>`,
              { chat_id: msg.chat.id, message_id: p.menuMessageId, parse_mode: 'HTML', reply_markup: joinKeyboard(cfg) }
            );
          } catch {}
        }
        return;
      }
      if (p.type === 'interval' && !/^\d+(?:\.\d+)?$/.test(text)) {
        if (p.menuMessageId) { try { await bot.editMessageText(autoMenuText(cfg, '<b>❌ Input tidak valid.</b>\nKirim angka menit, contoh <code>15</code>.'), { chat_id: msg.chat.id, message_id: p.menuMessageId, parse_mode: 'HTML', reply_markup: pendingKeyboard('gg:automenu') }); } catch {} }
        return;
      }
      if (p.type === 'interval' && /^\d+(?:\.\d+)?$/.test(text)) {
        const min = Number(text);
        cfg = setConfig(msg.chat.id, { autoInterval: min > 0 ? min * 60000 : 0 });
        startAutoTimer(bot, msg.chat.id);
        pendingInput.delete(inputKey(msg.chat.id, msg.from.id));
        try { await bot.deleteMessage(msg.chat.id, msg.message_id); } catch {}
        const statusNote = cfg.autoText
          ? `<b>✅ Interval diperbarui</b> → ${cfg.autoInterval ? formatInterval(cfg.autoInterval) : 'OFF'} — Auto aktif!`
          : `<b>✅ Interval diperbarui</b> → ${cfg.autoInterval ? formatInterval(cfg.autoInterval) : 'OFF'}\n⚠️ Set pesan dulu agar auto mulai kirim.`;
        if (p.menuMessageId) { try { await bot.editMessageText(autoMenuText(cfg, statusNote), { chat_id: msg.chat.id, message_id: p.menuMessageId, parse_mode: 'HTML', reply_markup: autoKeyboard(cfg) }); } catch {} }
        return;
      }
      if (p.type === 'autoText' && msg.text !== undefined) {
        const rawText = String(msg.text || '');
        if (!rawText.trim()) return;
        const entities = Array.isArray(msg.entities) ? msg.entities.map(e => ({ ...e })) : [];
        cfg = setConfig(msg.chat.id, { autoText: rawText, autoEntities: entities });
        startAutoTimer(bot, msg.chat.id);
        pendingInput.delete(inputKey(msg.chat.id, msg.from.id));
        try { await bot.deleteMessage(msg.chat.id, msg.message_id); } catch {}
        const statusNote = cfg.autoInterval
          ? `<b>✅ Pesan tersimpan & auto aktif</b>\nFormat: <b>${entities.length ? '✨ Rich Text' : 'Teks biasa'}</b>`
          : `<b>✅ Pesan tersimpan.</b>\n⚠️ Pilih interval agar auto mulai kirim.`;
        if (p.menuMessageId) { try { await bot.editMessageText(autoMenuText(cfg, statusNote), { chat_id: msg.chat.id, message_id: p.menuMessageId, parse_mode: 'HTML', reply_markup: autoKeyboard(cfg) }); } catch {} }
        return;
      }
    }

    // Skip enforce untuk private chat
    if (isPrivateMsg) return;

    enforce(bot, msg).catch(e => reportError(bot, 'group_guard', e, { chatId: msg?.chat?.id, userId: msg?.from?.id }));
  });
  bot.on('edited_message', msg => enforce(bot, msg).catch(e => reportError(bot, 'group_guard_edited', e, { chatId: msg?.chat?.id, userId: msg?.from?.id })));
};
