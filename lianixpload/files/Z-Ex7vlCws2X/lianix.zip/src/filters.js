// src/filters.js
// Rose-style /filter system.
//
// AKSES: Khusus owner bot (settings.ownerId). Bukan admin grup biasa.
// STORAGE: Per-grup terisolasi — db/filters/<chatId>.json
//          Grup A dan Grup B tidak pernah berbagi filter.
//
// Commands (khusus owner):
//   /filter <keyword> <reply>          — tambah filter teks
//   /filter <keyword>  (reply media)   — tambah filter media; teks opsional jadi caption baru
//   /filters                           — list filter grup ini
//   /stop <keyword>                    — hapus filter tertentu
//   /stopall                           — hapus semua filter grup ini
//
// Auto-reply: setiap pesan yang mengandung keyword (whole-word) → bot balas.
// Support: teks, foto, video, sticker, dokumen, audio, animasi, voice.
// Support Telegram formatting: HTML parse_mode di teks & caption.

'use strict';

const fs   = require('fs-extra');
const path = require('path');

const DB_DIR = path.join(__dirname, '..', 'db', 'filters');

// ─── Helpers ────────────────────────────────────────────────

function esc(v = '') {
  return String(v)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function dbPath(chatId) {
  return path.join(DB_DIR, `${String(chatId)}.json`);
}

function loadFilters(chatId) {
  try {
    const p = dbPath(chatId);
    if (fs.existsSync(p)) return fs.readJsonSync(p);
  } catch {}
  return {};
}

function saveFilters(chatId, data) {
  try {
    fs.ensureDirSync(DB_DIR);
    fs.writeJsonSync(dbPath(chatId), data, { spaces: 2 });
  } catch (e) {
    console.error('[filters] save:', e.message);
  }
}

function isGroup(msg) {
  return msg.chat && ['group', 'supergroup'].includes(msg.chat.type);
}

function isOwnerBot(id, settings) {
  return settings.isOwner(id);
}

function norm(kw) {
  return String(kw).toLowerCase().trim().replace(/\s+/g, ' ');
}

function bestFileId(arr) {
  if (!arr || !arr.length) return null;
  return arr[arr.length - 1].file_id;
}

function mediaIcon(type) {
  const icons = {
    photo:     '🖼️',
    video:     '🎥',
    sticker:   '🎭',
    document:  '📄',
    audio:     '🎵',
    voice:     '🎤',
    animation: '🎞️',
    text:      '📝',
  };
  return icons[type] || '📎';
}

function mediaLabel(type) {
  const labels = {
    photo:     'Foto',
    video:     'Video',
    sticker:   'Stiker',
    document:  'Dokumen',
    audio:     'Audio',
    voice:     'Voice Note',
    animation: 'GIF/Animasi',
    text:      'Teks',
  };
  return labels[type] || type;
}

// Ekstrak media dari pesan — jika replyText diberikan, caption diganti dengan replyText
function extractMedia(msg, overrideCaption) {
  if (!msg) return null;

  const cap = (overrideCaption !== undefined && overrideCaption !== null && overrideCaption !== '')
    ? overrideCaption
    : (msg.caption || null);

  if (msg.photo)     return { type: 'photo',     file_id: bestFileId(msg.photo), caption: cap };
  if (msg.video)     return { type: 'video',     file_id: msg.video.file_id,     caption: cap };
  if (msg.sticker)   return { type: 'sticker',   file_id: msg.sticker.file_id,   caption: null };
  if (msg.document)  return { type: 'document',  file_id: msg.document.file_id,  caption: cap };
  if (msg.audio)     return { type: 'audio',     file_id: msg.audio.file_id,     caption: cap };
  if (msg.animation) return { type: 'animation', file_id: msg.animation.file_id, caption: cap };
  if (msg.voice)     return { type: 'voice',     file_id: msg.voice.file_id,     caption: cap };
  // Pesan teks biasa yang di-reply → jadikan teks filternya teks itu (kalau ga ada override)
  if (msg.text && !overrideCaption) return { type: '_text_reply', text: msg.text };
  return null;
}

async function sendFilterReply(bot, chatId, filter, triggerMsgId) {
  const opts = { reply_to_message_id: triggerMsgId };

  // Helper: coba kirim dengan HTML, kalau gagal parse error → retry tanpa parse_mode
  // Ini handle kasus caption/content user yang mengandung tag tidak valid seperti <tulis>
  async function trySend(fn, htmlOpts, plainOpts) {
    try {
      return await fn(htmlOpts);
    } catch (e) {
      const isHtmlErr = /can't parse entities|parse error|unsupported.*tag|bad.*tag/i.test(e.message || '');
      if (isHtmlErr && plainOpts) return fn(plainOpts);
      throw e;
    }
  }

  const capHtml  = filter.caption ? { caption: filter.caption, parse_mode: 'HTML' } : {};
  const capPlain = filter.caption ? { caption: filter.caption } : {};

  switch (filter.type) {
    case 'text':
      return trySend(
        o => bot.sendMessage(chatId, filter.content, o),
        { parse_mode: 'HTML', ...opts },
        { ...opts }
      );
    case 'photo':
      return trySend(
        o => bot.sendPhoto(chatId, filter.file_id, o),
        { ...capHtml, ...opts },
        { ...capPlain, ...opts }
      );
    case 'video':
      return trySend(
        o => bot.sendVideo(chatId, filter.file_id, o),
        { ...capHtml, ...opts },
        { ...capPlain, ...opts }
      );
    case 'sticker':
      return bot.sendSticker(chatId, filter.file_id, opts);
    case 'document':
      return trySend(
        o => bot.sendDocument(chatId, filter.file_id, o),
        { ...capHtml, ...opts },
        { ...capPlain, ...opts }
      );
    case 'audio':
      return trySend(
        o => bot.sendAudio(chatId, filter.file_id, o),
        { ...capHtml, ...opts },
        { ...capPlain, ...opts }
      );
    case 'animation':
      return trySend(
        o => bot.sendAnimation(chatId, filter.file_id, o),
        { ...capHtml, ...opts },
        { ...capPlain, ...opts }
      );
    case 'voice':
      return bot.sendVoice(chatId, filter.file_id, opts);
    default:
      return trySend(
        o => bot.sendMessage(chatId, filter.content || '?', o),
        { parse_mode: 'HTML', ...opts },
        { ...opts }
      );
  }
}

// ─── Module ─────────────────────────────────────────────────

module.exports = (bot) => {
  const settings = require('../settings.js');

  // ── /filter <keyword> [teks/caption baru] ─────────────────
  bot.onText(/^\/filter(?:@\S+)?(?:\s+([\s\S]+))?$/i, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;

    if (!isOwnerBot(userId, settings)) {
      if (!isGroup(msg)) {
        return bot.sendMessage(chatId,
          '╔═══════════════════╗\n' +
          '║  ⛔ <b>Akses Ditolak</b>  ║\n' +
          '╚═══════════════════╝\n\n' +
          '<blockquote expandable>Fitur <b>/filter</b> hanya bisa digunakan oleh <b>owner bot</b>.</blockquote>',
          { parse_mode: 'HTML' }
        );
      }
      return;
    }

    if (!isGroup(msg)) {
      return bot.sendMessage(chatId,
        '<blockquote expandable>⚠️ <b>Hanya di Grup</b>\nPerintah ini hanya bisa dipakai di dalam grup.</blockquote>',
        { parse_mode: 'HTML' }
      );
    }

    const afterCmd  = (msg.text || '').replace(/^\/filter(?:@\S+)?\s*/i, '').trim();
    const spaceIdx  = afterCmd.search(/\s/);
    const keyword   = spaceIdx === -1 ? afterCmd : afterCmd.slice(0, spaceIdx).trim();
    const replyText = spaceIdx === -1 ? '' : afterCmd.slice(spaceIdx + 1).trim();

    if (!keyword) {
      return bot.sendMessage(chatId,
        '<blockquote expandable>📌 <b>Format Perintah</b>\n\n' +
        '• Filter teks:\n  <code>/filter &lt;keyword&gt; &lt;balasan&gt;</code>\n\n' +
        '• Filter media (reply ke foto/video/dokumen/dll):\n  <code>/filter &lt;keyword&gt;</code>  ← reply ke media\n  <code>/filter &lt;keyword&gt; &lt;caption baru&gt;</code>  ← ganti caption\n\n' +
        '💡 Caption mendukung <b>HTML formatting</b> Telegram.</blockquote>',
        { parse_mode: 'HTML' }
      );
    }

    const kw      = norm(keyword);
    const filters = loadFilters(chatId);

    // Cek apakah ada reply ke pesan
    const replied = msg.reply_to_message;
    if (replied) {
      // Jika reply ke pesan teks biasa + ada replyText → jadikan filter teks dengan konten replyText
      // Jika reply ke teks biasa + tidak ada replyText → gunakan teks pesan yang di-reply
      // Jika reply ke media → ambil media, caption diganti replyText jika ada
      const media = extractMedia(replied, replyText || undefined);

      if (media) {
        // Reply ke pesan teks biasa → jadikan filter teks
        if (media.type === '_text_reply') {
          const content = replyText || media.text;
          filters[kw] = { type: 'text', content };
          saveFilters(chatId, filters);
          return bot.sendMessage(chatId,
            `✅ <b>Filter Ditambahkan</b>\n\n` +
            `<blockquote expandable>` +
            `📝 <b>Tipe:</b> Teks (dari reply)\n` +
            `🔑 <b>Keyword:</b> <code>${esc(kw)}</code>\n` +
            `💬 <b>Balasan:</b> ${esc(content.slice(0, 150))}${content.length > 150 ? '…' : ''}` +
            `</blockquote>`,
            { parse_mode: 'HTML' }
          );
        }

        // Reply ke media
        filters[kw] = { type: media.type, file_id: media.file_id, caption: media.caption };
        saveFilters(chatId, filters);

        const captionInfo = media.caption
          ? `\n📝 <b>Caption:</b> ${esc(media.caption.slice(0, 100))}${media.caption.length > 100 ? '…' : ''}`
          : '\n📝 <b>Caption:</b> <i>tidak ada</i>';

        return bot.sendMessage(chatId,
          `✅ <b>Filter Ditambahkan</b>\n\n` +
          `<blockquote expandable>` +
          `${mediaIcon(media.type)} <b>Tipe:</b> ${mediaLabel(media.type)}\n` +
          `🔑 <b>Keyword:</b> <code>${esc(kw)}</code>${captionInfo}` +
          `</blockquote>`,
          { parse_mode: 'HTML' }
        );
      }
    }

    // Tidak ada reply — harus ada replyText
    if (!replyText) {
      return bot.sendMessage(chatId,
        '<blockquote expandable>⚠️ <b>Format Salah</b>\n\n' +
        'Tulis balasan setelah keyword, atau <b>reply</b> ke foto/video/dokumen/dll.\n\n' +
        'Contoh:\n' +
        '<code>/filter halo Halo juga!</code>\n' +
        '<code>/filter halo <b>Halo</b> &lt;i&gt;dunia&lt;/i&gt;</code></blockquote>',
        { parse_mode: 'HTML' }
      );
    }

    filters[kw] = { type: 'text', content: replyText };
    saveFilters(chatId, filters);

    return bot.sendMessage(chatId,
      `✅ <b>Filter Ditambahkan</b>\n\n` +
      `<blockquote expandable>` +
      `📝 <b>Tipe:</b> Teks\n` +
      `🔑 <b>Keyword:</b> <code>${esc(kw)}</code>\n` +
      `💬 <b>Balasan:</b> ${esc(replyText.slice(0, 200))}${replyText.length > 200 ? '…' : ''}` +
      `</blockquote>`,
      { parse_mode: 'HTML' }
    );
  });

  // ── /filters — list filter grup ini saja ──────────────────
  bot.onText(/^\/filters(?:@\S+)?$/i, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;

    if (!isOwnerBot(userId, settings)) {
      if (!isGroup(msg)) {
        return bot.sendMessage(chatId,
          '<blockquote expandable>⛔ <b>Akses Ditolak</b>\nFitur filters khusus owner bot.</blockquote>',
          { parse_mode: 'HTML' }
        );
      }
      return;
    }

    if (!isGroup(msg)) {
      return showAllGroups(bot, chatId);
    }

    return showGroupFilters(bot, chatId);
  });

  // ── /stop <keyword> ────────────────────────────────────────
  bot.onText(/^\/stop(?:@\S+)?\s+([\s\S]+)$/i, async (msg, match) => {
    if (!isGroup(msg)) return;
    const chatId = msg.chat.id;
    const userId = msg.from.id;

    if (!isOwnerBot(userId, settings)) return;

    const kw      = norm(match[1]);
    const filters = loadFilters(chatId);

    if (!filters[kw]) {
      return bot.sendMessage(chatId,
        `<blockquote expandable>❌ <b>Tidak Ditemukan</b>\n\nKeyword <code>${esc(kw)}</code> tidak ada di filter grup ini.\n\nLihat daftar filter aktif: /filters</blockquote>`,
        { parse_mode: 'HTML' }
      );
    }

    const deletedType = filters[kw].type;
    delete filters[kw];
    saveFilters(chatId, filters);

    const remaining = Object.keys(filters).length;

    return bot.sendMessage(chatId,
      `🗑️ <b>Filter Dihapus</b>\n\n` +
      `<blockquote expandable>` +
      `🔑 <b>Keyword:</b> <code>${esc(kw)}</code>\n` +
      `${mediaIcon(deletedType)} <b>Tipe:</b> ${mediaLabel(deletedType)}\n` +
      `📊 <b>Sisa filter:</b> ${remaining} filter aktif` +
      `</blockquote>`,
      { parse_mode: 'HTML' }
    );
  });

  // ── /stopall ───────────────────────────────────────────────
  bot.onText(/^\/stopall(?:@\S+)?$/i, async (msg) => {
    if (!isGroup(msg)) return;
    const chatId = msg.chat.id;
    const userId = msg.from.id;

    if (!isOwnerBot(userId, settings)) return;

    const filters = loadFilters(chatId);
    const total   = Object.keys(filters).length;

    if (!total) {
      return bot.sendMessage(chatId,
        '<blockquote expandable>📭 <b>Tidak Ada Filter</b>\nBelum ada filter aktif di grup ini.</blockquote>',
        { parse_mode: 'HTML' }
      );
    }

    saveFilters(chatId, {});
    return bot.sendMessage(chatId,
      `🗑️ <b>Semua Filter Dihapus</b>\n\n` +
      `<blockquote expandable>Sebanyak <b>${total} filter</b> telah dihapus dari grup ini.</blockquote>`,
      { parse_mode: 'HTML' }
    );
  });

  // ── Auto-reply: scan setiap pesan di grup ─────────────────
  bot.on('message', async (msg) => {
    if (!isGroup(msg)) return;

    const text = msg.text || msg.caption || '';
    if (!text.trim()) return;

    if (text.startsWith('/')) return;

    const chatId  = msg.chat.id;
    const filters = loadFilters(chatId);
    const keys    = Object.keys(filters);
    if (!keys.length) return;

    for (const kw of keys) {
      const escaped = kw.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const re      = new RegExp(`(?<![\\w])${escaped}(?![\\w])`, 'i');
      if (re.test(text)) {
        try {
          await sendFilterReply(bot, chatId, filters[kw], msg.message_id);
        } catch (e) {
          if (!/file_id|file is too big|wrong file/i.test(e.message)) {
            console.error('[filters] send reply:', e.message);
          }
        }
        break;
      }
    }
  });
};

// ─── Private helpers ─────────────────────────────────────────

async function showGroupFilters(bot, chatId) {
  const filters = loadFilters(chatId);
  const keys    = Object.keys(filters);

  if (!keys.length) {
    return bot.sendMessage(chatId,
      '<blockquote expandable>📭 <b>Belum Ada Filter</b>\n\nGrup ini belum punya filter aktif.\n\nTambahkan dengan:\n<code>/filter &lt;keyword&gt; &lt;balasan&gt;</code></blockquote>',
      { parse_mode: 'HTML' }
    );
  }

  function esc2(v = '') { return String(v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

  const icon = t => {
    const m = { text:'📝', photo:'🖼️', video:'🎥', sticker:'🎭', audio:'🎵', voice:'🎤', animation:'🎞️', document:'📄' };
    return m[t] || '📎';
  };

  const list = keys.sort().map((k, i) => {
    const f = filters[k];
    const cap = f.caption ? ` — <i>${esc2(f.caption.slice(0, 30))}${f.caption.length > 30 ? '…' : ''}</i>` : '';
    return `${i + 1}. ${icon(f.type)} <code>${esc2(k)}</code>${cap}`;
  }).join('\n');

  return bot.sendMessage(chatId,
    `📋 <b>Filter Aktif</b> — <b>${keys.length} filter</b>\n` +
    `<blockquote expandable>Grup: <code>${chatId}</code></blockquote>\n\n` +
    `${list}\n\n` +
    `<blockquote expandable>🗑️ Hapus satu: <code>/stop &lt;keyword&gt;</code>\n🧹 Hapus semua: <code>/stopall</code></blockquote>`,
    { parse_mode: 'HTML' }
  );
}

async function showAllGroups(bot, chatId) {
  const { existsSync, readdirSync, readJsonSync } = require('fs-extra');
  const DB_DIR2 = require('path').join(__dirname, '..', 'db', 'filters');

  function esc2(v = '') { return String(v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

  if (!existsSync(DB_DIR2)) {
    return bot.sendMessage(chatId,
      '<blockquote expandable>📭 <b>Filters</b>\nBelum ada filter yang tersimpan di grup mana pun.</blockquote>',
      { parse_mode: 'HTML' }
    );
  }

  const files = readdirSync(DB_DIR2).filter(f => f.endsWith('.json'));
  if (!files.length) {
    return bot.sendMessage(chatId,
      '<blockquote expandable>📭 <b>Filters</b>\nBelum ada filter yang tersimpan di grup mana pun.</blockquote>',
      { parse_mode: 'HTML' }
    );
  }

  const lines = [];
  for (const file of files) {
    try {
      const gid     = file.replace('.json', '');
      const f       = readJsonSync(require('path').join(DB_DIR2, file));
      const count   = Object.keys(f).length;
      if (count > 0) lines.push(`• Grup <code>${esc2(gid)}</code> — <b>${count} filter</b>`);
    } catch {}
  }

  if (!lines.length) {
    return bot.sendMessage(chatId,
      '<blockquote expandable>📭 <b>Filters</b>\nBelum ada filter aktif di grup mana pun.</blockquote>',
      { parse_mode: 'HTML' }
    );
  }

  return bot.sendMessage(chatId,
    `🌐 <b>Semua Grup dengan Filter Aktif</b>\n\n` +
    `${lines.join('\n')}\n\n` +
    `<blockquote expandable>💡 Gunakan <code>/filters</code> di dalam grup untuk melihat detail filter per grup.</blockquote>`,
    { parse_mode: 'HTML' }
  );
}
