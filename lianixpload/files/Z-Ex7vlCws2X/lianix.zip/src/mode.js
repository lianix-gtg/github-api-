// src/mode.js
// Fitur Self Mode / Public Mode ("maintenance mode").
// - PUBLIC : semua orang bisa pakai bot seperti biasa.
// - SELF   : hanya dev (settings.ownerId) yang bisa pakai bot,
//            user lain akan dapat notifikasi bot sedang maintenance.
// - Diatur lewat tombol di menu (bukan cuma command).
// - PENTING: modul ini WAJIB di-require PALING ATAS di index.js (sebelum
//   modul lain seperti start.js, panel.js, dst), karena modul ini
//   nge-patch bot.onText & bot.on supaya semua command yang didaftarkan
//   modul-modul SESUDAHNYA otomatis ikut kena cek mode ini.

const fs = require("fs");
const path = require("path");
const settings = require("../settings.js");

const ROOT = path.join(__dirname, "..");
const MODE_DB_FILE = path.join(ROOT, "db/botMode.json");

// FIX: sebelumnya OWNER_UID di-const sekali pas file ini di-require
// (paling awal, sebelum modul lain), padahal settings.ownerId itu getter
// dinamis yang narik dari db/owner.json (lihat settings.js + ownerStore.js).
// Akibatnya kalau owner diganti lewat tombol "⚒ Ganti Owner" di fitur Chat
// Owner, isOwner() di sini TETEP make ID owner LAMA sampai bot di-restart
// -> self-mode bisa nge-block owner baru / gagal ngenalin owner baru sama
// sekali. Sekarang dibaca ulang tiap panggilan, bukan disimpen ke const.
function isOwner(userId) {
  return settings.isOwner(userId);
}

// Cache di memori. Sebelumnya getMode() baca file dari disk (fs.readFileSync)
// SETIAP KALI ada command/tombol dipencet -> karena mode.js nge-patch SEMUA
// onText/on("message")/on("callback_query") di seluruh bot (200+ command,
// 70+ tombol), 1 aksi user bisa memicu puluhan pembacaan file bersamaan.
// Ini salah satu penyebab utama bot kerasa lag. Sekarang mode cuma dibaca
// dari disk SEKALI (pas pertama kali dipanggil / abis restart), sisanya
// dari cache. Cache di-update juga tiap kali setMode() dipanggil.
let cachedMode = null;

function loadModeDB() {
  if (cachedMode !== null) return { mode: cachedMode };

  try {
    if (!fs.existsSync(MODE_DB_FILE)) throw new Error("no file");
    const db = JSON.parse(fs.readFileSync(MODE_DB_FILE, "utf8"));
    if (db && (db.mode === "public" || db.mode === "self")) {
      cachedMode = db.mode;
      return db;
    }
    throw new Error("invalid file");
  } catch {
    const fresh = { mode: "public" }; // default: public, biar bot tetap jalan seperti biasa
    saveModeDB(fresh);
    return fresh;
  }
}

function saveModeDB(db) {
  fs.mkdirSync(path.dirname(MODE_DB_FILE), { recursive: true });
  fs.writeFileSync(MODE_DB_FILE, JSON.stringify(db, null, 2));
  cachedMode = db.mode;
}

function getMode() {
  return loadModeDB().mode;
}

function setMode(mode) {
  if (mode !== "public" && mode !== "self") return false;
  saveModeDB({ mode });
  return true;
}

// Owner selalu boleh akses apa pun, walaupun lagi self mode.
function isAllowed(userId) {
  if (isOwner(userId)) return true;
  return getMode() === "public";
}

function modeMenuText() {
  const mode = getMode();
  const statusText =
    mode === "public"
      ? "⟐ <b>PUBLIC</b> (semua orang bisa pakai bot)"
      : "⟠ <b>SELF</b> (cuma dev yang bisa pakai bot)";
  return `<blockquote expandable>┱ ⚒ Mode Bot\n┢────────\n┣ Status saat ini: ${statusText}\n┹</blockquote>\n\nPilih mode di bawah ▼`;
}

function modeMenuKeyboard() {
  const mode = getMode();
  return {
    inline_keyboard: [
      [
        { text: `${mode === "public" ? "◉ " : ""}⟐ Public`, callback_data: "mode_set_public" },
        { text: `${mode === "self" ? "◉ " : ""}⟠ Self (Dev Only)`, callback_data: "mode_set_self" },
      ],
      [{ text: "← ᴋᴇᴍʙᴀʟɪ", callback_data: "back" }],
    ],
  };
}

async function editMenu(bot, q, text, keyboard) {
  const opts = {
    chat_id: q.message.chat.id,
    message_id: q.message.message_id,
    parse_mode: "HTML",
    reply_markup: keyboard,
  };
  if (q.message.photo) return bot.editMessageCaption(text, opts);
  return bot.editMessageText(text, opts);
}

// Cooldown biar user yang spam command pas self mode gak dibanjiri notif berkali-kali.
const lastNotified = {};
const NOTIFY_COOLDOWN_MS = 15000;

async function notifyBlocked(bot, chatId, userId, replyToMessageId) {
  const key = String(userId);
  const now = Date.now();
  if (lastNotified[key] && now - lastNotified[key] < NOTIFY_COOLDOWN_MS) return;
  lastNotified[key] = now;
  try {
    await bot.sendMessage(
      chatId,
      "⚒ <b>Bot sedang mode privat (maintenance).</b>\nSaat ini bot cuma bisa dipakai oleh developer. Coba lagi nanti ya.",
      { parse_mode: "HTML", ...(replyToMessageId ? { reply_to_message_id: replyToMessageId } : {}) }
    );
  } catch {
    // diamkan kalau gagal kirim (misal bot diblokir user)
  }
}

// Nge-patch bot.onText & bot.on("message"/"callback_query") supaya semua
// handler yang didaftarkan SESUDAH ini otomatis kena cek mode.
function patchBot(bot) {
  if (bot.__modePatched) return; // jaga-jaga biar gak double patch
  bot.__modePatched = true;

  const originalOnText = bot.onText.bind(bot);
  bot.onText = function (regexp, callback) {
    return originalOnText(regexp, async (msg, match) => {
      try {
        if (!msg.from || !isAllowed(msg.from.id)) {
          return notifyBlocked(bot, msg.chat.id, msg.from?.id, msg.message_id);
        }
        return callback(msg, match);
      } catch (e) {
        console.error("[mode] error di onText wrapper:", e.message);
      }
    });
  };

  const originalOn = bot.on.bind(bot);
  bot.on = function (event, callback) {
    if (event === "message") {
      return originalOn(event, async (msg) => {
        try {
          if (!msg.from) return callback(msg);
          if (!isAllowed(msg.from.id)) {
            // biar gak spam notif tiap ada teks biasa (misal lagi isi state form),
            // notif cuma dikirim kalau user ngetik command ("/...").
            if (msg.text && msg.text.startsWith("/")) {
              return notifyBlocked(bot, msg.chat.id, msg.from.id, msg.message_id);
            }
            return;
          }
          return callback(msg);
        } catch (e) {
          console.error("[mode] error di on('message') wrapper:", e.message);
        }
      });
    }

    if (event === "callback_query") {
      return originalOn(event, async (q) => {
        try {
          if (!q.from || !isAllowed(q.from.id)) {
            return bot.answerCallbackQuery(q.id, {
              text: "⚒ Bot sedang mode privat (maintenance). Coba lagi nanti.",
              show_alert: true,
            });
          }
          return callback(q);
        } catch (e) {
          console.error("[mode] error di on('callback_query') wrapper:", e.message);
        }
      });
    }

    return originalOn(event, callback);
  };
}

module.exports = function registerModeHandlers(bot) {
  // Patch duluan supaya modul-modul yang di-require sesudah src/mode.js
  // (start.js, panel.js, dll) otomatis ke-cover proteksinya.
  patchBot(bot);

  bot.onText(/^\/mode$/, async (msg) => {
    if (!isOwner(msg.from.id)) {
      return bot.sendMessage(msg.chat.id, "⌖ Fitur ini khusus developer.");
    }
    await bot.sendMessage(msg.chat.id, modeMenuText(), {
      parse_mode: "HTML",
      reply_markup: modeMenuKeyboard(),
    });
  });

  bot.on("callback_query", async (q) => {
    if (q.data !== "mode_menu") return;
    if (!isOwner(q.from.id)) {
      return bot.answerCallbackQuery(q.id, { text: "⌖ Khusus developer.", show_alert: true });
    }
    await editMenu(bot, q, modeMenuText(), modeMenuKeyboard());
    await bot.answerCallbackQuery(q.id);
  });

  bot.on("callback_query", async (q) => {
    if (q.data !== "mode_set_public" && q.data !== "mode_set_self") return;
    if (!isOwner(q.from.id)) {
      return bot.answerCallbackQuery(q.id, { text: "⌖ Khusus developer.", show_alert: true });
    }
    const newMode = q.data === "mode_set_public" ? "public" : "self";
    setMode(newMode);
    await editMenu(bot, q, modeMenuText(), modeMenuKeyboard());
    await bot.answerCallbackQuery(q.id, {
      text: newMode === "public" ? "◉ Bot sekarang PUBLIC." : "◉ Bot sekarang SELF (dev only).",
    });
  });
};

module.exports.getMode = getMode;
module.exports.setMode = setMode;
module.exports.isAllowed = isAllowed;
module.exports.isOwner = isOwner;
module.exports.patchBot = patchBot;
