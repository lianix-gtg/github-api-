const fs = require('fs');
const path = require('path');

const dbDir = path.join(__dirname, 'db');
const dbFile = path.join(dbDir, 'datavps.json');

// pastikan folder ada
if (!fs.existsSync(dbDir)) {
    fs.mkdirSync(dbDir, { recursive: true });
}

// load data VPS
function loadVPS() {
    try {
        if (!fs.existsSync(dbFile)) return {};

        const raw = fs.readFileSync(dbFile, 'utf-8');
        if (!raw) return {};

        return JSON.parse(raw);
    } catch (err) {
        console.error('Error loading VPS DB:', err.message);
        return {};
    }
}

// save data VPS (lebih aman pakai temp file)
function saveVPS(data) {
    try {
        const tempFile = dbFile + '.tmp';

        fs.writeFileSync(tempFile, JSON.stringify(data, null, 2));
        fs.renameSync(tempFile, dbFile);
    } catch (err) {
        console.error('Error saving VPS DB:', err.message);
    }
}

// tambah VPS
function addVPS(dropletId, info) {
    const db = loadVPS();
    db[dropletId] = {
        ...info,
        updatedAt: new Date().toISOString()
    };
    saveVPS(db);
}

// ambil VPS
function getVPS(dropletId) {
    const db = loadVPS();
    return db[dropletId] || null;
}

// list semua VPS
function getAllVPS() {
    return loadVPS();
}

module.exports = { addVPS, getVPS, getAllVPS };