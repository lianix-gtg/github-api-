const fs = require("fs");
const path = require("path");

// ===================== PATH =====================
const dbDir = path.join(__dirname, "db");
const vpsFile = path.join(dbDir, "datavps.json");
const cdFile = path.join(dbDir, "cooldown.json");

// pastikan folder ada
if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true });

// ===================== SAFE JSON =====================
function readJSON(file, fallback) {
    try {
        if (!fs.existsSync(file)) return fallback;
        const raw = fs.readFileSync(file, "utf8");
        return raw ? JSON.parse(raw) : fallback;
    } catch (e) {
        console.error("JSON read error:", file, e.message);
        return fallback;
    }
}

function writeJSON(file, data) {
    try {
        const tmp = file + ".tmp";
        fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
        fs.renameSync(tmp, file);
        return true;
    } catch (e) {
        console.error("JSON write error:", file, e.message);
        return false;
    }
}

// ===================== VPS DB =====================
function loadVPS() {
    return readJSON(vpsFile, {});
}

function saveVPS(data) {
    return writeJSON(vpsFile, data);
}

function addVPS(dropletId, info) {
    const db = loadVPS();
    db[dropletId] = {
        ...info,
        updatedAt: Date.now()
    };
    saveVPS(db);
}

function getVPS(dropletId) {
    const db = loadVPS();
    return db[dropletId] || null;
}

// ===================== COOLDOWN =====================
let cooldownData = readJSON(cdFile, {
    time: 5 * 60 * 1000,
    users: {}
});

function saveCooldown() {
    writeJSON(cdFile, cooldownData);
}

function checkCooldown(userId) {
    const now = Date.now();

    if (cooldownData.users[userId]) {
        const remaining = cooldownData.time - (now - cooldownData.users[userId]);
        if (remaining > 0) {
            return Math.ceil(remaining / 1000);
        }
    }

    cooldownData.users[userId] = now;
    saveCooldown();

    setTimeout(() => {
        delete cooldownData.users[userId];
        saveCooldown();
    }, cooldownData.time);

    return 0;
}

function setCooldown(input) {
    const match = input.match(/(\d+)([smh])/);
    if (!match) return "✕ Format salah! contoh: 30s / 5m / 1h";

    let [, value, unit] = match;
    value = parseInt(value);

    const map = {
        s: 1000,
        m: 60 * 1000,
        h: 60 * 60 * 1000
    };

    cooldownData.time = value * map[unit];
    saveCooldown();

    return `✓ Cooldown diatur ke ${value}${unit}`;
}

// ===================== LOAD JSON DATA =====================
// Dipakai oleh install.js dan modul lain untuk baca file JSON dari path absolut.
// Mengembalikan parsed JSON; jika file tidak ada / corrupt, kembalikan array kosong.
function loadJsonData(filePath) {
    try {
        if (!fs.existsSync(filePath)) return [];
        const raw = fs.readFileSync(filePath, "utf8").trim();
        if (!raw) return [];
        return JSON.parse(raw);
    } catch (e) {
        console.error("loadJsonData error:", filePath, e.message);
        return [];
    }
}

// ===================== EXPORT =====================
module.exports = {
    checkCooldown,
    setCooldown,
    addVPS,
    getVPS,
    loadVPS,
    saveVPS,
    loadJsonData
};