// src/data/respawn.js
//
// FIX: sebelumnya tiap kali /restart (atau tombol "Restart Bot Sekarang")
// dipencet, kode cuma nunggu beberapa detik lalu process.exit(0) -- itu
// SAJA. Gak ada apa pun yang otomatis nyalain proses barunya lagi. Kalau
// bot dijalanin manual (node index.js / npm start di Termux atau VPS
// tanpa pm2/systemd), begitu exit ya bot MATI TOTAL sampai user ketik
// ulang node index.js secara manual. Itu sebabnya "restart" keliatan
// gak pernah auto-restart.
//
// Kode lama juga sempet nyoba "ngakalin" ini dengan process.stdin.write(...)
// isi base64, niatnya auto-isi password startup -- tapi itu gak pernah
// bisa jalan karena process.stdin cuma readable stream punya PROSES YANG
// SAMA, nulis ke situ gak ngirim apa-apa ke proses lain / ke proses baru.
// Jadi selain gak bikin restart beneran, itu juga gak ngefek sama sekali.
//
// Sekarang: sebelum exit, bot benar-benar men-spawn proses node baru
// (dirinya sendiri) yang detached, jadi tetap hidup walau proses lama
// sudah exit -- restart beneran, tanpa gantung ke pm2/systemd/wrapper apa pun.
const fs = require("fs");
const path = require("path");
const { spawn } = require("child_process");

const LOCK_FILE = path.join(__dirname, "..", "..", ".bot.lock");
const ROOT_DIR = path.join(__dirname, "..", "..");

function respawnAndExit(delayMs = 0) {
  const doRespawn = () => {
    // Lockfile single-instance masih nyimpen PID proses LAMA (yang lagi mau
    // exit ini). Kalau gak dibersihin dulu, proses baru bakal nolak start
    // karena ngira ada proses lain yang masih pegang token yang sama.
    // Restart ini sengaja/disadari, jadi aman dihapus di sini.
    try {
      fs.unlinkSync(LOCK_FILE);
    } catch (e) {
      // gak ada / gak bisa dihapus -> gapapa, biar proses baru yang urus
    }

    try {
      // BOT_INTERNAL_RESTART=1 → child process skip password prompt otomatis.
      // Ini yang bikin /restart dan file-watcher restart gak perlu input manual.
      const settings = require("../../settings.js");
      const childEnv = Object.assign({}, process.env, {
        BOT_INTERNAL_RESTART: "1",
        BOT_INTERNAL_RESTART_HASH: String(settings.startPassword || ""),
      });
      const child = spawn(process.argv[0], process.argv.slice(1), {
        cwd: ROOT_DIR,
        detached: true,
        stdio: "inherit",
        env: childEnv,
      });
      child.unref();
    } catch (e) {
      console.error("[respawn] Gagal nyalain proses baru:", e.message);
    }

    process.exit(0);
  };

  if (delayMs > 0) setTimeout(doRespawn, delayMs);
  else doRespawn();
}

module.exports = { respawnAndExit };
