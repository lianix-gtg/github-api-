// src/data/panelLog.js
// Nyimpen log setiap panel yang dibuat lewat bot.
// Key by pterodactyl `identifier` (string pendek, first segment UUID).
//
// Dipakai:
//   - src/panelCreate.js  → save() setelah panel berhasil dibuat
//   - src/panel.js        → findByIdentifier() di renderServerListSingle
//                           buat nampilin pembuat di /listsrv

const fs   = require("fs");
const path = require("path");

const DB_PATH = path.join(__dirname, "..", "..", "db", "panelLog.json");

function readStore() {
  try {
    const raw = fs.readFileSync(DB_PATH, "utf8");
    const d   = JSON.parse(raw);
    if (d && typeof d === "object") return d;
  } catch (_) {}
  return {};
}

function writeStore(data) {
  fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

/**
 * Simpan log panel baru.
 * @param {object} e
 * @param {string} e.identifier      pterodactyl server identifier (8-char)
 * @param {number} e.ptServerId      pterodactyl numeric server ID
 * @param {number} e.ptUserId        pterodactyl numeric user ID
 * @param {string} e.serverName      nama server di pterodactyl
 * @param {string} e.panelEmail      email akun yang dibuat
 * @param {string} e.panelVersion    "1" / "2"../"20" / "adp"
 * @param {string} e.runtime         "Node.js" | "Python"
 * @param {string} e.domain          domain panel
 * @param {number} e.creatorTgId     Telegram user ID pembuat
 * @param {string} e.creatorTgUsername "@username" atau ""
 * @param {string} e.creatorTgName   first_name pembuat
 */
function save(e) {
  const data = readStore();
  data[e.identifier] = {
    identifier:        e.identifier,
    ptServerId:        e.ptServerId,
    ptUserId:          e.ptUserId,
    serverName:        e.serverName,
    panelEmail:        e.panelEmail,
    panelVersion:      e.panelVersion,
    runtime:           e.runtime,
    domain:            e.domain,
    creatorTgId:       e.creatorTgId,
    creatorTgUsername: e.creatorTgUsername || "",
    creatorTgName:     e.creatorTgName     || "",
    targetTgId:        e.targetTgId || e.creatorTgId || null,
    createdAt:         new Date().toISOString(),
  };
  writeStore(data);
}

/** Lookup by identifier. Return entry atau null. */
function findByIdentifier(identifier) {
  return readStore()[String(identifier)] || null;
}

/** Lookup by pterodactyl numeric server ID. Return entry atau null. */
function findByPtServerId(id) {
  return Object.values(readStore()).find(e => String(e.ptServerId) === String(id)) || null;
}

/** Semua entries, terbaru dulu. */
function getAll() {
  return Object.values(readStore()).sort((a, b) =>
    new Date(b.createdAt) - new Date(a.createdAt)
  );
}

module.exports = { save, findByIdentifier, findByPtServerId, getAll };
