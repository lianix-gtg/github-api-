/*
 * ============================================================
 * 📢 TEMPAT DATA CHANNEL WAJIB JOIN
 * ============================================================
 * Data aktif disimpan di db/channels.json dan dapat diubah lewat menu bot.
 * Jangan mencari username channel di banyak file; sumber utamanya di sini.
 */
// src/data/channelStore.js
// Nyimpen daftar channel (bisa lebih dari satu) di db/channels.json, biar
// bisa ditambah/diubah/dihapus lewat tombol di Dev Panel tanpa edit
// settings.js manual. Dipakai di src/start.js (bagian "◆ Kelola Channel").

const fs = require("fs");
const path = require("path");

// ✏️ EDIT DI SINI #11 — FILE DATABASE CHANNEL WAJIB JOIN
const DB_PATH = path.join(__dirname, "..", "..", "db", "channels.json");

function readStore() {
  try {
    const raw = fs.readFileSync(DB_PATH, "utf8");
    const data = JSON.parse(raw);
    if (Array.isArray(data)) return data;
  } catch (e) {
    // file belum ada / corrupt -> mulai dari list kosong
  }
  return [];
}

function writeStore(list) {
  fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
  fs.writeFileSync(DB_PATH, JSON.stringify(list, null, 2));
}

function getChannels() {
  return readStore();
}

function getChannel(id) {
  return readStore().find((c) => String(c.id) === String(id)) || null;
}

function addChannel(username) {
  const list = readStore();
  const nextId = list.length ? Math.max(...list.map((c) => Number(c.id) || 0)) + 1 : 1;
  const clean = String(username).trim();
  const entry = {
    id: nextId,
    username: clean.startsWith("@") ? clean : `@${clean}`,
    addedAt: new Date().toISOString(),
  };
  list.push(entry);
  writeStore(list);
  return entry;
}

function updateChannel(id, newUsername) {
  const list = readStore();
  const idx = list.findIndex((c) => String(c.id) === String(id));
  if (idx === -1) return null;
  const clean = String(newUsername).trim();
  list[idx].username = clean.startsWith("@") ? clean : `@${clean}`;
  list[idx].updatedAt = new Date().toISOString();
  writeStore(list);
  return list[idx];
}

function removeChannel(id) {
  const list = readStore();
  const idx = list.findIndex((c) => String(c.id) === String(id));
  if (idx === -1) return false;
  list.splice(idx, 1);
  writeStore(list);
  return true;
}

module.exports = { getChannels, getChannel, addChannel, updateChannel, removeChannel, DB_PATH };
