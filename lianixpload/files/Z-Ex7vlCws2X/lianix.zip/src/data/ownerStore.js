/*
 * ============================================================
 * 👑 TEMPAT DATA OWNER
 * ============================================================
 * Owner aktif disimpan di db/owner.json. Fallback default ada di bawah.
 * Jika ingin mengubah owner permanen, ikuti panduan; jangan ubah sembarang
 * file yang memakai settings.ownerId.
 */
// src/data/ownerStore.js
// Nyimpen ID + nama Owner/Admin di db/owner.json biar bisa diganti
// tanpa edit settings.js manual (dipakai fitur tombol "⚒ Ganti Owner"
// di src/relaychat.js).
//
// PENTING: banyak file lain (panel.js, main.js, group.js, dll) masih
// nge-cache `settings.ownerId` ke const sekali pas file itu di-require
// pertama kali. Jadi kalau owner diganti lewat fitur ini, fitur "Chat
// Owner" langsung ikut owner baru (karena baca ownerStore.getOwnerId()
// tiap kali), tapi modul-modul lain baru bener-bener konsisten setelah
// bot di-restart.

const fs = require("fs");
const path = require("path");

const DB_PATH = path.join(__dirname, "..", "..", "db", "owner.json");

// Fallback dipakai kalau db/owner.json belum ada / rusak / kosong.
// Sengaja gak require("../../settings.js") di sini biar gak muter
// (settings.js juga baca modul ini buat expose settings.ownerId).
// ✏️ EDIT DI SINI #12 — FALLBACK OWNER ID
const DEFAULT_OWNER_ID = 6301365869;
// ✏️ EDIT DI SINI #13 — FALLBACK NAMA OWNER
const DEFAULT_OWNER_NAME = "LianiX";

function readStore() {
  try {
    const raw = fs.readFileSync(DB_PATH, "utf8");
    const data = JSON.parse(raw);
    if (data && data.ownerId) return data;
  } catch (e) {
    // file belum ada / corrupt -> pakai default di bawah
  }
  return { ownerId: DEFAULT_OWNER_ID, ownerName: DEFAULT_OWNER_NAME };
}

function writeStore(data) {
  fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

function getOwnerId() {
  const id = Number(readStore().ownerId);
  return Number.isFinite(id) && id > 0 ? id : DEFAULT_OWNER_ID;
}

function getOwnerName() {
  return readStore().ownerName || DEFAULT_OWNER_NAME;
}

function setOwner(newId, newName) {
  const data = {
    ownerId: Number(newId),
    ownerName: newName || null,
    updatedAt: new Date().toISOString(),
  };
  writeStore(data);
  return data;
}

// ── Two-owner system ──────────────────────────────────────
// db/owner.json bisa menyimpan ownerIds: [id1, id2] (maks 2)
// Tetap kompatibel dengan format lama { ownerId, ownerName }.

function getOwnerIds() {
  const data = readStore();
  if (Array.isArray(data.ownerIds) && data.ownerIds.length) return data.ownerIds.map(String);
  const single = String(data.ownerId || DEFAULT_OWNER_ID);
  return [single];
}

function addOwner(newId, newName) {
  const data  = readStore();
  // Normalisasi ke format ownerIds array
  const ids   = Array.isArray(data.ownerIds) && data.ownerIds.length
    ? [...data.ownerIds]
    : [String(data.ownerId || DEFAULT_OWNER_ID)];

  if (ids.length >= 2) {
    // Ganti slot ke-2
    ids[1] = String(newId);
  } else if (!ids.includes(String(newId))) {
    ids.push(String(newId));
  }

  const updated = {
    ...data,
    ownerIds: ids,
    ownerId: Number(ids[0]),
    ownerName: data.ownerName || DEFAULT_OWNER_NAME,
    owner2Id: Number(ids[1] || 0),
    owner2Name: newName || null,
    updatedAt: new Date().toISOString(),
  };
  writeStore(updated);
  return updated;
}

module.exports = { getOwnerId, getOwnerName, setOwner, getOwnerIds, addOwner, DB_PATH };
