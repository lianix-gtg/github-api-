const settings = require('../../settings.js');
const ownerStore = require('./ownerStore.js');


function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function cleanError(error) {
  const raw = error?.stack || error?.message || String(error || 'Unknown error');
  const secrets = [
    settings.token,
    process.env.BOT_TOKEN,
    process.env.FIREBASE_API_KEY,
    process.env.API_KEY,
    process.env.PLTA,
    process.env.PLTN,
  ].filter(Boolean).map(String);

  let safe = raw;
  for (const secret of secrets) {
    if (secret.length >= 4) safe = safe.split(secret).join('[REDACTED]');
  }
  return safe.slice(0, 3000);
}

async function reportError(bot, type, error, context = {}) {
  try {
    let ownerIds = [];
    try {
      ownerIds = [...new Set(ownerStore.getOwnerIds().map(String).filter(Boolean))];
    } catch (_) {
      ownerIds = settings.ownerId ? [String(settings.ownerId)] : [];
    }
    if (!ownerIds.length || !bot) return;

    // Transient network errors (ECONNRESET, AggregateError, 502/503/504)
    // bukan bug bot — hanya gangguan jaringan sesaat. Skip silently.
    const msg = String(error?.message || error || '');
    const status = Number(error?.response?.statusCode || error?.response?.status || 0);
    const isTransient =
      /ECONNRESET|ECONNREFUSED|ETIMEDOUT|EPIPE|ENOTFOUND|EAI_AGAIN|socket hang up/i.test(msg) ||
      (error instanceof AggregateError) || /AggregateError/i.test(msg) ||
      [502, 503, 504].includes(status) ||
      /ETELEGRAM:\s*(502|503|504)/i.test(msg) ||
      /502 Bad Gateway|503 Service Unavailable|504 Gateway/i.test(msg);
    if (isTransient) return;

    const safe = cleanError(error);
    const now = Date.now();
    const code = `ERR-${now.toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 7).toUpperCase()}`;
    const contextText = Object.entries(context)
      .filter(([, value]) => value !== undefined && value !== null && value !== '')
      .slice(0, 8)
      .map(([key, value]) => `${key}: ${String(value).slice(0, 180)}`)
      .join('\n');

    const text =
      `<b>╭━━〔 ⚠️ BOT ERROR 〕━━╮</b>\n` +
      `<b>▣ Code:</b> <code>${escapeHtml(code)}</code>\n` +
      `<b>▣ Type:</b> <code>${escapeHtml(type)}</code>\n` +
      (contextText ? `\n<b>▣ Context</b>\n<code>${escapeHtml(contextText)}</code>\n` : '\n') +
      `\n<pre>${escapeHtml(safe)}</pre>\n` +
      `<i>LIANIX CPANEL • Error Monitor</i>\n` +
      `╰━━━━━━━━━━━━━━━━━━━━╯`;

    for (const ownerId of ownerIds) {
      try {
        await bot.sendMessage(ownerId, text, { parse_mode: 'HTML' });
      } catch (_) {
        // Owner #1 gagal tidak boleh mencegah Owner #2 menerima log.
      }
    }
  } catch {}
}

module.exports = { reportError };
