/*
 * ============================================================
 * 🔧 TEMPAT SETTING PANEL — EDIT DEFAULT PANEL DI SINI
 * ============================================================
 * Jika panel diatur lewat menu bot, data disimpan ke db/panels.json.
 * Untuk nilai default saat database belum ada, lihat DEFAULT_PANEL.
 */
// src/data/panelStore.js
// Nyimpen domain + PLTA (Application API key) + PLTC (Client API key) buat
// tiap "slot" panel (1, V2..V20, ADP) di db/panels.json, biar bisa diganti
// satu-satu lewat tombol "▭ Kelola Panel" (lihat src/panelsettings.js)
// tanpa perlu edit settings.js manual.
//
// PENTING (sama kayak src/data/ownerStore.js): beberapa file lain
// (src/status.js contohnya) nge-cache nilai settings.domain / .plta / dst
// ke const sekali pas file itu di-require pertama kali. Jadi kalau sebuah
// panel diganti lewat fitur ini, settings.js langsung ikut nilai baru
// (karena baca panelStore.getPanel() tiap kali diakses), tapi modul yang
// nge-cache ke const di top-level file baru bener-bener ikut nilai baru
// setelah bot di-restart.

const fs = require("fs");
const path = require("path");

const DB_PATH = path.join(__dirname, "..", "..", "db", "panels.json");

// Urutan slot panel yang didukung: "1" (Panel Utama), "2".."20" (Panel V2-V20), "adp".
const PANEL_KEYS = ["1", ...Array.from({ length: 19 }, (_, i) => String(i + 2)), "adp"];

function labelFor(key) {
  if (key === "1") return "Panel 1 (Utama)";
  if (key === "adp") return "Panel ADP";
  return `Panel V${key}`;
}

// Fallback dipakai kalau db/panels.json belum ada / rusak / kosong.
// Sengaja gak require("../../settings.js") di sini biar gak muter
// (settings.js juga baca modul ini buat expose settings.domain dkk).
// NILAI DIAMBIL DARI .env (PANEL_DEFAULT_*) -- gak hardcoded API key
// asli lagi di sini. Kalau .env kosong, jatuh ke placeholder kosong
// dan settings.js bakal ngingetin lewat warning pas bot start.
// ✏️ EDIT DI SINI #10 — DEFAULT PANEL (dipakai jika db/panels.json belum tersedia)
const DEFAULT_PANEL = {
  // Domain panel utama / default
  domain:      process.env.PANEL_DEFAULT_DOMAIN || "",
  // PLTA = Application API Key Pterodactyl
  plta:        process.env.PANEL_DEFAULT_PLTA || "",
  // PLTC = Client API Key Pterodactyl
  pltc:        process.env.PANEL_DEFAULT_PLTC || "",
  // Egg Node.js
  eggs:        "20",   // Egg ID Node.js di Nest Pterodactyl
  // Egg Python
  eggsPython:  "22",   // Egg ID Python di Nest Pterodactyl
};

function buildDefaults() {
  const data = {};
  for (const key of PANEL_KEYS) data[key] = { ...DEFAULT_PANEL };
  return data;
}

function readStore() {
  try {
    const raw = fs.readFileSync(DB_PATH, "utf8");
    const data = JSON.parse(raw);
    if (data && typeof data === "object") {
      // Lengkapin slot yang mungkin belum ada (misal file lama / rusak sebagian)
      let changed = false;
      for (const key of PANEL_KEYS) {
        if (!data[key] || !data[key].domain || !data[key].plta || !data[key].pltc
            || !data[key].eggs || !data[key].eggsPython) {
          data[key] = data[key] ? { ...DEFAULT_PANEL, ...data[key] } : { ...DEFAULT_PANEL };
          changed = true;
        }
      }
      if (changed) writeStore(data);
      return data;
    }
  } catch (e) {
    // file belum ada / corrupt -> pakai default di bawah
  }
  const defaults = buildDefaults();
  writeStore(defaults);
  return defaults;
}

function writeStore(data) {
  fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

function isValidKey(key) {
  return PANEL_KEYS.includes(String(key));
}

function getPanel(key) {
  const data = readStore();
  return data[String(key)] || { ...DEFAULT_PANEL };
}

function getAllPanels() {
  return readStore();
}

function setPanel(key, { domain, plta, pltc, eggs, eggsPython }) {
  const k = String(key);
  if (!isValidKey(k)) throw new Error(`Panel key tidak dikenal: ${k}`);

  const data = readStore();
  const current = data[k] || { ...DEFAULT_PANEL };
  data[k] = {
    domain:     String(domain).trim().replace(/\/+$/, ""),
    plta:       String(plta).trim(),
    pltc:       String(pltc).trim(),
    eggs:       eggs      != null ? String(eggs).trim()      : (current.eggs      || DEFAULT_PANEL.eggs),
    eggsPython: eggsPython != null ? String(eggsPython).trim() : (current.eggsPython || DEFAULT_PANEL.eggsPython),
    updatedAt:  new Date().toISOString(),
  };
  writeStore(data);
  return data[k];
}

module.exports = {
  PANEL_KEYS,
  labelFor,
  isValidKey,
  getPanel,
  getAllPanels,
  setPanel,
  DB_PATH,
};
