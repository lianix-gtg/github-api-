// Scrape + Canvas feature bridge ported from ELAINA V3 for Lianix Telegram.
// Commands are intentionally registered once here; menus only navigate to these commands.
const path = require('path');
const fs = require('fs');
const axios = require('axios');

function esc(s='') {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}
function q(msg){ return msg?.message_id ? { reply_to_message_id: msg.message_id } : {}; }
function txt(msg){ return String(msg?.text || msg?.caption || '').trim(); }
function arg(msg, cmd){ return txt(msg).replace(new RegExp('^\\\\/'+cmd+'(?:@\\\\w+)?\\\\s*','i'),'').trim(); }
async function sendPhoto(bot, msg, buf, caption='') {
  if (!buf) throw new Error('Hasil gambar kosong');
  return bot.sendPhoto(msg.chat.id, buf, { caption: String(caption).slice(0,1024), parse_mode:'HTML', ...q(msg) });
}
async function loading(bot,msg,label,fn){
  let dots=0, alive=true;
  let m=await bot.sendMessage(msg.chat.id, `⏳ <b>${esc(label)}</b>`, {parse_mode:'HTML',...q(msg)});
  const timer=setInterval(async()=>{ if(!alive)return; dots=(dots+1)%4; try{await bot.editMessageText(`⏳ <b>${esc(label)}${'.'.repeat(dots)}</b>`,{chat_id:msg.chat.id,message_id:m.message_id,parse_mode:'HTML'});}catch{} },900);
  try{return await fn();} finally{alive=false;clearInterval(timer);try{await bot.deleteMessage(msg.chat.id,m.message_id);}catch{}}
}
async function fileUrl(bot, message){
  const m=message?.reply_to_message || message;
  const photo=m?.photo?.at(-1);
  const doc=m?.document;
  const fileId=photo?.file_id || doc?.file_id;
  if(!fileId) return null;
  return await bot.getFileLink(fileId);
}

function register(bot){
  // Group menu navigation: keep one message and open submenus.
  bot.on('callback_query', async cb=>{
    const d=String(cb.data||'');
    if(!/^sc:(canvas|scrape)$/.test(d)) return;
    await bot.answerCallbackQuery(cb.id).catch(()=>{});
    const rows = d==='canvas'
      ? [
          [{text:'🎨 BRAT',callback_data:'noop_sc_brat'},{text:'📱 FAKE IQC',callback_data:'noop_sc_iqc'}],
          [{text:'💬 FAKE NGL',callback_data:'noop_sc_ngl'},{text:'𝕏 FAKE TWEET',callback_data:'noop_sc_tweet'}],
          [{text:'🏴 WANTED',callback_data:'noop_sc_wanted'},{text:'💳 FAKE DANA',callback_data:'noop_sc_dana'}],
          [{text:'📸 CODE SNAP',callback_data:'noop_sc_snap'},{text:'🎬 MOVIE POSTER',callback_data:'noop_sc_movie'}],
          [{text:'🔮 TAROT',callback_data:'noop_sc_tarot'}],
          [{text:'‹‹‹',callback_data:'groupmenu'}]
        ]
      : d==='scrape'
      ? [
          [{text:'🎵 TIKTOK',callback_data:'noop_sc_tt'},{text:'▶️ YOUTUBE',callback_data:'noop_sc_yt'}],
          [{text:'🎧 SPOTIFY',callback_data:'noop_sc_sp'},{text:'📁 MEDIAFIRE',callback_data:'noop_sc_mf'}],
          [{text:'📥 SAVEFROM',callback_data:'noop_sc_sf'},{text:'📸 INSTAGRAM',callback_data:'noop_sc_ig'}],
          [{text:'🎌 ANIME',callback_data:'sc:anime'}],
          [{text:'🔢 BINARY',callback_data:'sc:binary'}],
          [{text:'🔎 GITHUB / NPM / ML',callback_data:'sc:stalk'}],
          [{text:'‹‹‹',callback_data:'groupmenu'}]
        ]
      : [[{text:'‹‹‹',callback_data:'groupmenu'}]];
    const title=d==='canvas'?'🎨 <b>CANVAS MENU</b>':d==='scrape'?'⌕ <b>SCRAPE MENU</b>':'<b>GROUP MENU</b>';
    try{
      await bot.editMessageText(title+'\n\n<i>Gunakan command yang sesuai setelah memilih fitur.</i>',{chat_id:cb.message.chat.id,message_id:cb.message.message_id,parse_mode:'HTML',reply_markup:{inline_keyboard:rows}});
    }catch{}
  });

  // Helper callbacks that show exact command usage without creating a second menu.
  bot.on('callback_query', async cb=>{
    const d=String(cb.data||'');
    const map={
      noop_sc_brat:'/brat <teks>',noop_sc_iqc:'/fakeiqc <teks>',noop_sc_ngl:'/fakengl <teks>',noop_sc_tweet:'/faketweet username|nama|teks',
      noop_sc_wanted:'/wanted nama|bounty|alias',noop_sc_dana:'/fakedana <nominal>',noop_sc_snap:'/codesnap <kode>',
      noop_sc_movie:'/movieposter nama|genre|judul',noop_sc_tarot:'/tarot [kartu|terbalik]',
      noop_sc_tt:'/tiktok <url>',noop_sc_yt:'/youtube <url>',noop_sc_sp:'/spotify <url/search>',noop_sc_mf:'/mediafire <url>',
      noop_sc_sf:'/savefrom <url>',noop_sc_ig:'/instagram <url>'
    };
    if(!map[d]) return;
    await bot.answerCallbackQuery(cb.id,{text:map[d],show_alert:true}).catch(()=>{});
  });

  bot.on('callback_query', async cb=>{
    const d=String(cb.data||'');
    if(d==='sc:anime'||d==='sc:binary'||d==='sc:stalk'){
      const map={ 'sc:anime':'/animesearch <judul>', 'sc:binary':'/biner <teks> atau /debiner <binary>', 'sc:stalk':'/githubstalk <user> • /npmstalk <package> • /mlstalk <id|zone>'};
      await bot.answerCallbackQuery(cb.id,{text:map[d],show_alert:true}).catch(()=>{});
    }
  });

  // Canvas
  bot.onText(/^\/brat(?:@\w+)?\s+([\s\S]+)$/i, async(msg,m)=>{
    try{const {generateBrat}=require('../lib/canvas/brat');const b=await loading(bot,msg,'Membuat Brat',()=>generateBrat(m[1]));await sendPhoto(bot,msg,b,'🎨 <b>BRAT</b>');}catch(e){await bot.sendMessage(msg.chat.id,`❌ Brat gagal: <code>${esc(e.message)}</code>`,{parse_mode:'HTML',...q(msg)});}
  });
  bot.onText(/^\/(?:fakeiqc|iqc)(?:@\w+)?(?:\s+([\s\S]+))?$/i, async(msg,m)=>{
    try{const {generateIQC}=require('../lib/canvas/fakeIQC');const b=await loading(bot,msg,'Membuat Fake IQC',()=>generateIQC({message:(m[1]||'').trim()||'kayaa ginii',timestamp:new Date().toTimeString().slice(0,5),reactions:['👍','❤️','😂','😮','😢','🙏']}));await sendPhoto(bot,msg,b,'📱 <b>Fake IQC</b>');}catch(e){await bot.sendMessage(msg.chat.id,`❌ Fake IQC gagal: <code>${esc(e.message)}</code>`,{parse_mode:'HTML',...q(msg)});}
  });
  bot.onText(/^\/fakengl(?:@\w+)?\s*([\s\S]*)$/i, async(msg,m)=>{
    try{const {generateFakeNgl}=require('../lib/canvas/fakeNgl');const b=await loading(bot,msg,'Membuat Fake NGL',()=>generateFakeNgl({message:(m[1]||'').trim()||'Kartu kosong',theme:'default',scale:2}));await sendPhoto(bot,msg,b,'💬 <b>Fake NGL</b>');}catch(e){await bot.sendMessage(msg.chat.id,`❌ Fake NGL gagal: <code>${esc(e.message)}</code>`,{parse_mode:'HTML',...q(msg)});}
  });
  bot.onText(/^\/faketweet(?:@\w+)?\s+([\s\S]+)$/i, async(msg,m)=>{
    try{const {createFakeTweet}=require('../lib/canvas/fakeTweet');const p=m[1].split('|').map(x=>x.trim());const b=await loading(bot,msg,'Membuat Fake Tweet',()=>createFakeTweet({username:(p[0]||'username').replace(/^@/,''),displayName:p[1]||p[0]||'User',content:p[2]||'This is a fake tweet.',theme:'dark',verified:p.includes('verified'),liked:p.includes('liked'),time:'9:41 AM',date:new Date().toLocaleDateString('en-US'),via:'Lianix'}));await sendPhoto(bot,msg,b,'𝕏 <b>Fake Tweet</b>');}catch(e){await bot.sendMessage(msg.chat.id,`❌ Fake Tweet gagal: <code>${esc(e.message)}</code>`,{parse_mode:'HTML',...q(msg)});}
  });
  bot.onText(/^\/wanted(?:@\w+)?(?:\s+([\s\S]+))?$/i, async(msg,m)=>{
    try{const {createWantedPoster}=require('../lib/canvas/wantedPoster');const p=(m[1]||'').split('|').map(x=>x.trim());const b=await loading(bot,msg,'Membuat Wanted Poster',()=>createWantedPoster({name:p[0]||msg.from?.first_name||'Member',bounty:Number((p[1]||'100000000').replace(/\D/g,'')),alias:p[2]||''}));await sendPhoto(bot,msg,b,'🏴 <b>Wanted Poster</b>');}catch(e){await bot.sendMessage(msg.chat.id,`❌ Wanted gagal: <code>${esc(e.message)}</code>`,{parse_mode:'HTML',...q(msg)});}
  });
  bot.onText(/^\/fakedana(?:@\w+)?\s+([\d.,]+)$/i, async(msg,m)=>{
    try{const {generateFakeDana}=require('../lib/canvas/fakedana');const b=await loading(bot,msg,'Membuat Fake Dana',()=>generateFakeDana(m[1]));await sendPhoto(bot,msg,b,'💳 <b>Fake Dana</b>');}catch(e){await bot.sendMessage(msg.chat.id,`❌ Fake Dana gagal: <code>${esc(e.message)}</code>`,{parse_mode:'HTML',...q(msg)});}
  });
  bot.onText(/^\/codesnap(?:@\w+)?\s+([\s\S]+)$/i, async(msg,m)=>{
    try{const {generateCodeSnap}=require('../lib/canvas/codesnap');const b=await loading(bot,msg,'Membuat Code Snap',()=>generateCodeSnap(m[1],{theme:'dracula'}));await sendPhoto(bot,msg,b,'📸 <b>Code Snap</b>');}catch(e){await bot.sendMessage(msg.chat.id,`❌ Code Snap gagal: <code>${esc(e.message)}</code>`,{parse_mode:'HTML',...q(msg)});}
  });
  bot.onText(/^\/movieposter(?:@\w+)?\s+([\s\S]+)$/i, async(msg,m)=>{
    try{const {createMoviePoster}=require('../lib/canvas/moviePoster');const p=m[1].split('|').map(x=>x.trim());const b=await loading(bot,msg,'Membuat Movie Poster',()=>createMoviePoster({name:p[0]||'Member',genre:p[1]||'action',title:p[2]||null,tagline:p[3]||null,year:new Date().getFullYear(),director:'A LIANIX FILM'}));await sendPhoto(bot,msg,b,'🎬 <b>Movie Poster</b>');}catch(e){await bot.sendMessage(msg.chat.id,`❌ Movie Poster gagal: <code>${esc(e.message)}</code>`,{parse_mode:'HTML',...q(msg)});}
  });
  bot.onText(/^\/tarot(?:@\w+)?(?:\s+([\s\S]+))?$/i, async(msg,m)=>{
    try{const {createTarotCard,getTarotCard,CARDS}=require('../lib/canvas/tarotCard');const p=(m[1]||'').split('|').map(x=>x.trim());let cardIndex=null;if(p[0]){const n=Number(p[0]);if(Number.isInteger(n)&&n>=0&&n<22)cardIndex=n;else{const f=CARDS.findIndex(c=>c.name.toLowerCase().includes(p[0].toLowerCase()));if(f>=0)cardIndex=f;}}const card=getTarotCard(String(msg.from?.id||''));const b=await loading(bot,msg,'Membuka Tarot',()=>createTarotCard({username:msg.from?.first_name||'Member',cardIndex,reversed:/terbalik/i.test(p[1]||'')}));await sendPhoto(bot,msg,b,`🔮 <b>${esc(card.name)}</b>`);}catch(e){await bot.sendMessage(msg.chat.id,`❌ Tarot gagal: <code>${esc(e.message)}</code>`,{parse_mode:'HTML',...q(msg)});}
  });

  // Scrape
  bot.onText(/^\/biner(?:@\w+)?\s+([\s\S]+)$/i, async(msg,m)=>{try{const {eBinary}=require('../lib/scrape/binary');const r=await loading(bot,msg,'Encode Binary',()=>eBinary(m[1]));await bot.sendMessage(msg.chat.id,`🔢 <b>BINARY</b>\n<code>${esc(String(r).slice(0,3500))}</code>`,{parse_mode:'HTML',...q(msg)});}catch(e){await bot.sendMessage(msg.chat.id,`❌ Binary gagal: ${esc(e.message)}`,{parse_mode:'HTML',...q(msg)});}});
  bot.onText(/^\/debiner(?:@\w+)?\s+([\s\S]+)$/i, async(msg,m)=>{try{const {dBinary}=require('../lib/scrape/binary');const r=await loading(bot,msg,'Decode Binary',()=>dBinary(m[1]));await bot.sendMessage(msg.chat.id,`📝 <b>DECODE</b>\n<code>${esc(String(r).slice(0,3500))}</code>`,{parse_mode:'HTML',...q(msg)});}catch(e){await bot.sendMessage(msg.chat.id,`❌ Decode gagal: ${esc(e.message)}`,{parse_mode:'HTML',...q(msg)});}});
  bot.onText(/^\/animesearch(?:@\w+)?\s+(.+)$/i, async(msg,m)=>{try{const {animeSearch}=require('../lib/scrape/anime');const r=await loading(bot,msg,'Mencari Anime',()=>animeSearch(m[1]));const data=r?.data||r;await bot.sendMessage(msg.chat.id,`🎌 <b>ANIME SEARCH</b>\n\n<pre>${esc(JSON.stringify(data,null,2).slice(0,3500))}</pre>`,{parse_mode:'HTML',...q(msg)});}catch(e){await bot.sendMessage(msg.chat.id,`❌ Anime gagal: ${esc(e.message)}`,{parse_mode:'HTML',...q(msg)});}});
  bot.onText(/^\/animeongoing$/i, async(msg)=>{try{const {animeOngoing}=require('../lib/scrape/anime');const r=await loading(bot,msg,'Mengambil Anime Ongoing',()=>animeOngoing());await bot.sendMessage(msg.chat.id,`🎌 <b>ONGOING</b>\n\n<pre>${esc(JSON.stringify(r?.data||r,null,2).slice(0,3500))}</pre>`,{parse_mode:'HTML',...q(msg)});}catch(e){await bot.sendMessage(msg.chat.id,`❌ Ongoing gagal: ${esc(e.message)}`,{parse_mode:'HTML',...q(msg)});}});
  bot.onText(/^\/animeschedule$/i, async(msg)=>{try{const {animeSchedule}=require('../lib/scrape/anime');const r=await loading(bot,msg,'Mengambil Jadwal Anime',()=>animeSchedule());await bot.sendMessage(msg.chat.id,`🎌 <b>SCHEDULE</b>\n\n<pre>${esc(JSON.stringify(r?.data||r,null,2).slice(0,3500))}</pre>`,{parse_mode:'HTML',...q(msg)});}catch(e){await bot.sendMessage(msg.chat.id,`❌ Schedule gagal: ${esc(e.message)}`,{parse_mode:'HTML',...q(msg)});}});
  bot.onText(/^\/animedetail(?:@\w+)?\s+(.+)$/i, async(msg,m)=>{try{const {animeDetail}=require('../lib/scrape/anime');const r=await loading(bot,msg,'Mengambil Detail Anime',()=>animeDetail(m[1]));await bot.sendMessage(msg.chat.id,`🎌 <b>DETAIL</b>\n\n<pre>${esc(JSON.stringify(r?.data||r,null,2).slice(0,3500))}</pre>`,{parse_mode:'HTML',...q(msg)});}catch(e){await bot.sendMessage(msg.chat.id,`❌ Detail gagal: ${esc(e.message)}`,{parse_mode:'HTML',...q(msg)});}});
  bot.onText(/^\/mlstalk(?:@\w+)?\s+(\S+)(?:\s+(\S+))?$/i, async(msg,m)=>{try{const {mlstalk}=require('../lib/scrape/mlstalk');const r=await loading(bot,msg,'ML Stalk',()=>mlstalk(m[1],m[2]));await bot.sendMessage(msg.chat.id,`🎮 <b>ML STALK</b>\n\n<pre>${esc(JSON.stringify(r,null,2).slice(0,3500))}</pre>`,{parse_mode:'HTML',...q(msg)});}catch(e){await bot.sendMessage(msg.chat.id,`❌ ML Stalk gagal: ${esc(e.message)}`,{parse_mode:'HTML',...q(msg)});}});
  bot.onText(/^\/savefrom(?:@\w+)?\s+(https?:\/\/\S+)$/i, async(msg,m)=>{try{const {savefrom}=require('../lib/scrape/savefrom');const r=await loading(bot,msg,'Scrape SaveFrom',()=>savefrom(m[1]));const out=Array.isArray(r)?r[0]:r;await bot.sendMessage(msg.chat.id,`⬇️ <b>SAVEFROM</b>\n\n<pre>${esc(JSON.stringify(out,null,2).slice(0,3500))}</pre>`,{parse_mode:'HTML',...q(msg)});}catch(e){await bot.sendMessage(msg.chat.id,`❌ SaveFrom gagal: ${esc(e.message)}`,{parse_mode:'HTML',...q(msg)});}});



}
module.exports=register;
