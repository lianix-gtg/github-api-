/**
 * LianiX AI Media Tools
 * Adapted from the supplied unified AI GACOR endpoints.
 * Secrets are read from environment variables; no API keys are hardcoded.
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const axios = require('axios');
const sharp = require('sharp');
const settings = require('../settings.js');
/**
 * safeReply — sendMessage with reply_to_message_id fallback.
 */
async function safeReply(bot, chatId, text, opts = {}) {
  try {
    return await bot.sendMessage(chatId, text, opts);
  } catch (err) {
    const desc = String(err?.response?.body?.description || err?.message || '');
    if (/message to be replied not found/i.test(desc) && opts.reply_to_message_id) {
      const { reply_to_message_id: _, ...safeOpts } = opts;
      return await bot.sendMessage(chatId, text, safeOpts);
    }
    throw err;
  }
}


const MAX_MEDIA = 20 * 1024 * 1024;
async function sendBufferFile(bot, method, chatId, buffer, filename, options = {}) {
  if (!Buffer.isBuffer(buffer)) return bot[method](chatId, buffer, options);
  const tmp = path.join(os.tmpdir(), `lianix_${Date.now()}_${Math.random().toString(36).slice(2)}_${filename}`);
  await fs.promises.writeFile(tmp, buffer);
  try {
    return await bot[method](chatId, tmp, options);
  } finally {
    fs.promises.unlink(tmp).catch(() => {});
  }
}

const FW_BASE = process.env.FIREWORKS_BASE || 'https://api.fireworks.ai/inference/v1';
const FW_KEY = process.env.FIREWORKS_API_KEY || process.env.FIREWORKS_KEY || '';
const AI_RETRY_MAX = 2;
const HF_TOKEN = process.env.HF_TOKEN || process.env.HUGGINGFACE_TOKEN || '';
const WAN_HF = process.env.WAN_HF_SPACE || 'https://zerogpu-aoti-wan2-2-fp8da-aoti-faster.hf.space';
const POLL = 'https://image.pollinations.ai/prompt/';
const IMGUP = 'https://api.imgupscaler.ai';
const REMBG = 'https://briaai-bria-rmbg-2-0.hf.space';
const CODEFORMER = 'https://sczhou-codeformer.hf.space';

const STYLES = {
  cyberpunk:'cyberpunk neon style, futuristic, neon glowing accents, highly detailed',
  anime:'anime style, vibrant colors, expressive eyes, digital art, high quality',
  '3d-render':'3d render, unreal engine 5, octane render, volumetric lighting, photorealistic',
  'oil-painting':'oil painting style, thick brush strokes, textured canvas, classical art',
  watercolor:'watercolor style, soft colors, splatters, hand-painted feel',
  sketch:'pencil sketch style, hand drawn, monochrome, graphite crosshatching',
  none:''
};
const MODELS = {
  'flux-schnell':'accounts/fireworks/models/flux-1-schnell',
  'flux-dev':'accounts/fireworks/models/flux-1-dev'
};

function q(msg){ return msg?.message_id ? {reply_to_message_id:msg.message_id} : {}; }
function esc(s=''){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}
function progressBar(p,w=18){p=Math.max(0,Math.min(100,Number(p)||0));const n=Math.round(p/100*w);return `[${'▰'.repeat(n)}${'▱'.repeat(w-n)}] ${Math.round(p)}%`;}
function loadingText(title,stage,p){return `⏳ <b>${esc(title)}</b>\n\n▸ ${esc(stage)}\n${progressBar(p)}\n\n🔄 <i>Mohon tunggu, proses sedang berjalan...</i>`;}
async function loading(bot,msg,title){
  let sent=null; try{sent=await bot.sendMessage(msg.chat.id,loadingText(title,'Menyiapkan...',0),{parse_mode:'HTML',...q(msg)});}catch{}
  let last=-1,lastAt=0;
  return {
    async update(stage,p){if(!sent)return;const v=Math.max(last,Math.min(100,Number(p)||0));const now=Date.now();if(v===last&&now-lastAt<2500)return;if(now-lastAt<900)return;last=v;lastAt=now;try{await bot.editMessageText(loadingText(title,stage,v),{chat_id:msg.chat.id,message_id:sent.message_id,parse_mode:'HTML'});}catch{}} ,
    async finish(ok=true){if(!sent)return;try{await bot.editMessageText(`⏳ <b>${esc(title)}</b>\n\n${ok?'✅ '+progressBar(100)+'\n\n<b>Selesai.</b>':'❌ Proses gagal.'}`,{chat_id:msg.chat.id,message_id:sent.message_id,parse_mode:'HTML'});setTimeout(()=>bot.deleteMessage(msg.chat.id,sent.message_id).catch(()=>{}),1200);}catch{}}
  };
}
async function getMedia(bot,msg){
  const t=msg.reply_to_message||msg;
  const id=t.photo?.at(-1)?.file_id||t.video?.file_id||t.document?.file_id||t.animation?.file_id||t.sticker?.file_id;
  if(!id) throw new Error('Balas atau kirim media yang didukung.');
  const f=await bot.getFile(id);
  const r=await axios.get(`https://api.telegram.org/file/bot${settings.token}/${f.file_path}`,{responseType:'arraybuffer',timeout:90000,maxContentLength:MAX_MEDIA,maxBodyLength:MAX_MEDIA});
  const name=t.document?.file_name||t.video?.file_name||t.animation?.file_name||path.basename(f.file_path)||`media_${Date.now()}`;
  return {buffer:Buffer.from(r.data),name,target:t};
}
async function postJSON(url,payload,headers={}){
  let last;
  for(let attempt=0;attempt<=AI_RETRY_MAX;attempt++){
    try{
      const r=await axios.post(url,payload,{headers:{'Content-Type':'application/json',...headers},timeout:180000,maxContentLength:100*1024*1024,maxBodyLength:100*1024*1024});
      return r.data;
    }catch(e){
      last=e;
      const status=e?.response?.status;
      if(status!==429 && status!==402) throw e;
      if(attempt<AI_RETRY_MAX) await new Promise(r=>setTimeout(r,1500*(attempt+1)));
    }
  }
  const status=last?.response?.status;
  if(status===429) throw new Error('AI provider sedang rate limit (429). Sistem akan mencoba provider cadangan.');
  if(status===402) throw new Error('AI provider membutuhkan saldo/kredit (402). Sistem akan mencoba provider cadangan.');
  throw last;
}
async function download(url,dest){const r=await axios.get(url,{responseType:'arraybuffer',timeout:180000,maxContentLength:100*1024*1024});fs.writeFileSync(dest,r.data);return dest;}
function fwHeaders(){if(!FW_KEY)throw new Error('FIREWORKS_API_KEY belum diatur di environment.');return {Authorization:`Bearer ${FW_KEY}`,'Content-Type':'application/json',Accept:'application/json'};}

async function txt2img({prompt,style='none',model='flux-dev',width=1024,height=1024}){
  const full=`${STYLES[style]||''} ${prompt}`.trim();
  try{
    const data=await postJSON(`${FW_BASE}/image_generation/${MODELS[model]||MODELS['flux-dev']}`,{prompt:full,negative_prompt:'blurry, low quality, distorted, watermark',width,height,num_inference_steps:30,guidance_scale:7,seed:Math.floor(Math.random()*99999),response_format:'b64_json'},fwHeaders());
    const imgs=data?.data||[];if(!imgs.length)throw new Error('Fireworks tidak mengembalikan gambar.');
    return imgs.map(x=>Buffer.from(x.b64_json,'base64')).filter(Boolean);
  }catch(e){
    const u=`${POLL}${encodeURIComponent(full)}?width=${width}&height=${height}&model=flux&nologo=true&seed=${Math.floor(Math.random()*99999)}`;
    const r=await axios.get(u,{responseType:'arraybuffer',timeout:180000,maxContentLength:30*1024*1024});
    if(!r.data?.length)throw e;return [Buffer.from(r.data)];
  }
}
async function img2video(image, prompt='') {
  const b64 = image.toString('base64');

  // Provider utama: Fireworks jika key tersedia.
  if (FW_KEY) {
    const workflows = [
      'accounts/fireworks/models/stable-video-diffusion-img2vid-xt',
      'accounts/fireworks/models/stable-video-diffusion-img2vid'
    ];
    for (const wf of workflows) {
      try {
        const d = await postJSON(`${FW_BASE}/workflows/${wf}`, {
          image: `data:image/jpeg;base64,${b64}`,
          prompt: prompt || 'smooth cinematic motion',
          num_frames: 40,
          motion_bucket_id: 50,
          fps: 8,
          aspect_ratio: '16:9'
        }, fwHeaders());
        const url = d?.video_url || d?.url || d?.output;
        if (url) return await axios.get(url, {responseType:'arraybuffer', timeout:180000});
      } catch (e) {
        // Coba workflow berikutnya / fallback HF.
      }
    }
  }

  // Fallback: Wan2.2 HuggingFace. Jadi /img2video tidak lagi langsung gagal
  // hanya karena FIREWORKS_API_KEY belum dipasang.
  return await img2videoHF(image, prompt);
}

async function img2videoHF(image, prompt='') {
  const HF = WAN_HF;
  const auth = HF_TOKEN ? {'Authorization': `Bearer ${HF_TOKEN}`} : {};

  try {
    const form = new (require('form-data'))();
    form.append('files', image, {filename:'image.jpg', contentType:'image/jpeg'});
    const up = await axios.post(`${HF}/gradio_api/upload`, form, {
      headers:{...form.getHeaders(), ...auth, Origin:HF, Referer:`${HF}/`},
      timeout:120000,
      maxContentLength:100*1024*1024,
      maxBodyLength:100*1024*1024
    });
    const uploaded = up.data?.[0] || up.data?.path;
    if (!uploaded) throw new Error('Upload Wan2.2 gagal.');

    const call = await axios.post(`${HF}/gradio_api/call/generate_video`, {
      data:[
        {path:uploaded, meta:{_type:'gradio.FileData'}},
        prompt || 'make this image come alive, cinematic motion, smooth animation',
        6,
        'Bright tones, overexposed, static, blurred details, worst quality',
        3.5,
        1.0,
        1.0,
        42,
        true
      ]
    }, {headers:{'Content-Type':'application/json',...auth,Origin:HF,Referer:`${HF}/`}, timeout:120000});

    const eventId = call.data?.event_id;
    if (!eventId) throw new Error('Job Wan2.2 gagal dibuat.');

    // Gradio queue endpoint mengirim SSE. Ambil event complete.
    const result = await axios.get(`${HF}/gradio_api/call/generate_video/${eventId}`, {
      headers:{...auth,Origin:HF,Referer:`${HF}/`},
      responseType:'text',
      timeout:300000
    });
    const text = String(result.data || '');
    if (!text.includes('event: complete')) {
      const errLine = text.split('\n').find(x=>x.startsWith('data:') && /error/i.test(x));
      throw new Error(errLine ? errLine.slice(5).trim() : 'Wan2.2 generation gagal atau timeout.');
    }

    const lines = text.split('\n');
    const idx = lines.findIndex(x=>x.includes('event: complete'));
    const dataLine = lines.slice(idx).find(x=>x.startsWith('data:'));
    if (!dataLine) throw new Error('Output Wan2.2 tidak ditemukan.');

    let parsed;
    try { parsed = JSON.parse(dataLine.slice(5)); } catch { throw new Error('Response Wan2.2 tidak valid.'); }
    const fileOut = parsed?.[0];
    const filePath = fileOut?.path;
    if (!filePath) throw new Error('File video Wan2.2 tidak ditemukan.');

    const file = await axios.get(`${HF}/gradio_api/file=${encodeURIComponent(filePath)}`, {
      headers:{...auth,Origin:HF,Referer:`${HF}/`},
      responseType:'arraybuffer', timeout:300000,
      maxContentLength:100*1024*1024
    });
    if (!file.data?.length) throw new Error('Video Wan2.2 kosong.');
    return file;
  } catch (e) {
    const msg = e?.response?.data && typeof e.response.data === 'string'
      ? e.response.data.slice(0,300)
      : (e?.message || 'Provider image-to-video tidak tersedia.');
    throw new Error(`Image-to-video tidak tersedia: ${msg}`);
  }
}
async function imageEnhance(image,tool='upscale'){
  try {
    const endpoint=`${IMGUP}/api/imgupscaler/v3/ai-image-${tool}/create-job`;
    const form=new (require('form-data'))();
    form.append('file',image,{filename:'input.jpg',contentType:'image/jpeg'});
    const up=await axios.post(endpoint,form,{headers:form.getHeaders(),timeout:120000});
    const id=up.data?.job_id||up.data?.id;
    if(!id) throw new Error('Job enhancer tidak didapatkan.');
    for(let i=0;i<40;i++){
      await new Promise(r=>setTimeout(r,3000));
      const st=await axios.get(`${IMGUP}/api/imgupscaler/v3/ai-image-${tool}/get-job/${id}`,{timeout:30000});
      const d=st.data||{};
      const url=d.result_url||d.url||d.download_url;
      if(url&&(d.status==='success'||d.status==='completed'||url)){
        const result=await axios.get(url,{responseType:'arraybuffer',timeout:120000});
        if(result.data?.length) return Buffer.from(result.data);
      }
      if(d.status==='failed') break;
    }
    throw new Error('Enhancement timeout/gagal.');
  } catch (providerErr) {
    // Provider enhancer can reject requests (for example HTTP 422).
    // Keep the command usable with a deterministic local Sharp fallback.
    const meta=await sharp(image).metadata();
    const width=Math.max(1,Number(meta.width||100));
    const height=Math.max(1,Number(meta.height||100));
    const scale=tool==='upscale'?2:1;
    return sharp(image)
      .resize({
        width: Math.min(width*scale, 4096),
        height: Math.min(height*scale, 4096),
        fit:'inside',
        withoutEnlargement:false,
        kernel:sharp.kernel.lanczos3
      })
      .sharpen({sigma:1})
      .png()
      .toBuffer();
  }
}

// Remove background — pixa.com primary, HF briaai fallback (see features/removebackground.js)
const { removeBg } = require('./features/removebackground.js');

function register(bot){
  bot.onText(/^\/txt2img(?:@\w+)?\s+([\s\S]+)$/i,async(msg,m)=>{
    const load=await loading(bot,msg,'TEXT → IMAGE');try{
      const parts=m[1].trim();const style=/--style\s+(\S+)/i.exec(parts)?.[1]||'none';const model=/--model\s+(\S+)/i.exec(parts)?.[1]||'flux-dev';const width=parseInt(/--width\s+(\d+)/i.exec(parts)?.[1]||1024);const height=parseInt(/--height\s+(\d+)/i.exec(parts)?.[1]||1024);const prompt=parts.replace(/--(?:style|model|width|height)\s+\S+/gi,'').trim();if(!prompt)throw new Error('Prompt wajib diisi.');
      await load.update('Mengirim prompt ke image provider...',20);const imgs=await txt2img({prompt,style,model,width,height});await load.update('Gambar selesai dibuat, mengirim hasil...',90);for(const b of imgs)await sendBufferFile(bot,'sendPhoto',msg.chat.id,b,`ai_${Date.now()}.jpg`,{caption:`🎨 <b>TEXT → IMAGE</b>\n\nModel: <code>${esc(model)}</code>\nStyle: <code>${esc(style)}</code>`,parse_mode:'HTML',...q(msg)});await load.finish(true);
    }catch(e){await load.finish(false);await bot.sendMessage(msg.chat.id,`❌ <b>TXT2IMG GAGAL</b>\n\n${esc(e.message)}`,{parse_mode:'HTML',...q(msg)});}
  });

  bot.onText(/^\/(img2video|image2video)(?:@\w+)?(?:\s+([\s\S]+))?$/i,async(msg,m)=>{
    const load=await loading(bot,msg,'IMAGE → VIDEO');try{await load.update('Mengambil gambar...',10);const {buffer,target}=await getMedia(bot,msg);if(!target.photo&&!/image\//i.test(target.document?.mime_type||''))throw new Error('Reply gambar yang valid.');await load.update('Memproses image-to-video...',35);const r=await img2video(buffer,m[2]||'');await load.update('Video selesai, mengirim hasil...',90);await bot.sendVideo(msg.chat.id,{source:r.data,filename:`ai_video_${Date.now()}.mp4`},{caption:'🎬 <b>IMAGE → VIDEO</b>',parse_mode:'HTML',supports_streaming:true,...q(msg)});await load.finish(true);}catch(e){await load.finish(false);await bot.sendMessage(msg.chat.id,`❌ <b>IMAGE → VIDEO GAGAL</b>\n\n${esc(e.message)}`,{parse_mode:'HTML',...q(msg)});}}
  );

  for(const cmd of ['upscale','enhance','unblur','denoise','restore','colorize']) bot.onText(new RegExp(`^\/${cmd}(?:@\w+)?$`,'i'),async msg=>{
    // /restore juga dipakai oleh Panel Tools untuk database ZIP.
    // Dokumen non-gambar dibiarkan ke handler database agar tidak ada output/error ganda.
    if(cmd === 'restore'){
      const doc = msg.reply_to_message?.document;
      if(doc && !/^image\//i.test(String(doc.mime_type || ''))) return;
    }
    const load=await loading(bot,msg,cmd.toUpperCase());try{await load.update('Mengambil gambar...',10);const {buffer}=await getMedia(bot,msg);await load.update('Mengirim ke AI enhancer...',30);const out=await imageEnhance(buffer,cmd);await load.update('Menyiapkan output...',90);await sendBufferFile(bot,'sendDocument',msg.chat.id,out,`${cmd}_${Date.now()}.png`,{caption:`✨ <b>${cmd.toUpperCase()}</b>`,parse_mode:'HTML',...q(msg)});await load.finish(true);}catch(e){await load.finish(false);await bot.sendMessage(msg.chat.id,`❌ <b>${cmd.toUpperCase()} GAGAL</b>\n\n${esc(e.message)}`,{parse_mode:'HTML',...q(msg)});}});

  bot.onText(/^\/rembg(?:@\w+)?$/i,async msg=>{const load=await loading(bot,msg,'REMOVE BG');try{await load.update('Mengambil gambar...',10);const {buffer}=await getMedia(bot,msg);await load.update('Menghapus background...',40);const out=await removeBg(buffer);await load.update('Mengirim PNG transparan...',90);await sendBufferFile(bot,'sendDocument',msg.chat.id,out,`rembg_${Date.now()}.png`,{caption:'◇ <b>REMOVE BACKGROUND</b>',parse_mode:'HTML',...q(msg)});await load.finish(true);}catch(e){await load.finish(false);await bot.sendMessage(msg.chat.id,`❌ <b>REMBG GAGAL</b>\n\n${esc(e.message)}`,{parse_mode:'HTML',...q(msg)});}});

  bot.onText(/^\/aihelp$/i,async msg=>bot.sendMessage(msg.chat.id,`<b>AI MEDIA TOOLS</b>\n\n/txt2img <code>prompt</code> [--style anime] [--model flux-dev]\n/img2video <code>prompt</code> (reply gambar)\n/upscale (reply gambar)\n/enhance (reply gambar)\n/unblur (reply gambar)\n/denoise (reply gambar)\n/restore (reply gambar)\n/colorize (reply gambar)\n/rembg (reply gambar)`,{parse_mode:'HTML',...q(msg)}));
}
module.exports={register};
