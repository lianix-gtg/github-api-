// src/status.js
// Command /status
// - Langsung nampilin status VPS (CPU, RAM, Disk) begitu command dijalankan.
// - Sekaligus nge-cek status online/offline Server 1 s/d 20 (domain, domainV2..domainV20).
//
// Dipanggil dari main menu (lihat footer di src/menu.js: "Ketik /status ...").

const os = require("os");
const { execSync } = require("child_process");
const axios = require("axios");
const settings = require("../settings.js");

// Daftar 20 server panel yang dipakai bot ini.
const SERVERS = [
  { no: 1, domain: settings.domain, key: settings.plta },
  { no: 2, domain: settings.domainV2, key: settings.pltaV2 },
  { no: 3, domain: settings.domainV3, key: settings.pltaV3 },
  { no: 4, domain: settings.domainV4, key: settings.pltaV4 },
  { no: 5, domain: settings.domainV5, key: settings.pltaV5 },
  { no: 6, domain: settings.domainV6, key: settings.pltaV6 },
  { no: 7, domain: settings.domainV7, key: settings.pltaV7 },
  { no: 8, domain: settings.domainV8, key: settings.pltaV8 },
  { no: 9, domain: settings.domainV9, key: settings.pltaV9 },
  { no: 10, domain: settings.domainV10, key: settings.pltaV10 },
  { no: 11, domain: settings.domainV11, key: settings.pltaV11 },
  { no: 12, domain: settings.domainV12, key: settings.pltaV12 },
  { no: 13, domain: settings.domainV13, key: settings.pltaV13 },
  { no: 14, domain: settings.domainV14, key: settings.pltaV14 },
  { no: 15, domain: settings.domainV15, key: settings.pltaV15 },
  { no: 16, domain: settings.domainV16, key: settings.pltaV16 },
  { no: 17, domain: settings.domainV17, key: settings.pltaV17 },
  { no: 18, domain: settings.domainV18, key: settings.pltaV18 },
  { no: 19, domain: settings.domainV19, key: settings.pltaV19 },
  { no: 20, domain: settings.domainV20, key: settings.pltaV20 },
];

// Ambil info disk lewat `df -h /` (Linux). Kalau gagal (mis. bukan Linux), return null.
function getDiskInfo() {
  try {
    const out = execSync("df -h / | awk 'NR==2 {print $2, $3, $4, $5}'")
      .toString()
      .trim();
    const [total, used, free, percent] = out.split(/\s+/);
    return { total, used, free, percent };
  } catch (e) {
    return null;
  }
}

// Cek 1 server: dianggap Online kalau API application-nya bisa diakses.
async function checkServer(server) {
  if (!server.domain || !server.key) {
    return { ...server, status: "⚠ Belum Diset" };
  }

  try {
    await axios.get(`${server.domain}/api/application/servers`, {
      params: { per_page: 1 },
      headers: {
        Authorization: `Bearer ${server.key}`,
        Accept: "Application/vnd.pterodactyl.v1+json",
      },
      timeout: 8000,
    });
    return { ...server, status: "● Online" };
  } catch (e) {
    return { ...server, status: "○ Offline" };
  }
}

module.exports = (bot) => {
  bot.onText(/^\/status$/, async (msg) => {
    const chatId = msg.chat.id;

    const sent = await bot.sendMessage(
      chatId,
      "⏳ <b>Mengecek status VPS &amp; Server...</b>",
      { parse_mode: "HTML" }
    );

    // ================= STATUS VPS =================
    const cpuList = os.cpus() || [];
    const cpuModel = cpuList[0]?.model?.trim() || "Unknown";
    const cpuCores = cpuList.length || 1;

    const totalMemGB = os.totalmem() / 1024 ** 3;
    const freeMemGB = os.freemem() / 1024 ** 3;
    const usedMemGB = totalMemGB - freeMemGB;
    const memPercent = ((usedMemGB / totalMemGB) * 100).toFixed(1);

    const load1 = os.loadavg()[0];
    const cpuLoadPercent = Math.min(((load1 / cpuCores) * 100), 100).toFixed(1);

    const disk = getDiskInfo();
    const diskText = disk
      ? `${disk.used} / ${disk.total} (${disk.percent})`
      : "Tidak tersedia";

    const vpsUptimeSec = os.uptime();
    const uptimeStr = `${Math.floor(vpsUptimeSec / 86400)}d ${Math.floor(
      (vpsUptimeSec % 86400) / 3600
    )}h ${Math.floor((vpsUptimeSec % 3600) / 60)}m`;

    // ================= STATUS SERVER 1-10 (paralel) =================
    const results = await Promise.all(SERVERS.map(checkServer));

    const onlineCount = results.filter((r) => r.status.includes("Online")).length;

    let serverText = "";
    for (const r of results) {
      serverText += `  ⌇ Server ${r.no.toString().padEnd(2)} : ${r.status}\n`;
    }

    const finalText = `▭ <b>STATUS VPS</b>
<blockquote expandable>↬ Uptime    : ${uptimeStr}
↬ CPU       : ${cpuModel} (${cpuCores} cores)
↬ CPU Load  : ${cpuLoadPercent}%
↬ RAM       : ${usedMemGB.toFixed(2)} GB / ${totalMemGB.toFixed(2)} GB (${memPercent}%)
↬ Disk      : ${diskText}</blockquote>

⌂ <b>STATUS SERVER (1-20)</b>
<blockquote expandable>${serverText}
✦ Online: ${onlineCount} / ${results.length}</blockquote>`;

    await bot.editMessageText(finalText, {
      chat_id: chatId,
      message_id: sent.message_id,
      parse_mode: "HTML",
    });
  });
};
