const axios = require("axios");
const fs = require("fs");
const path = require('path');
const archiver = require("archiver");
const { Client } = require("ssh2");
const dns = require("dns").promises;
const crypto = require("crypto");
const fetch = require("node-fetch")
const settings = require("../settings.js");
const { getUserRole } = require("./limit.js");
const dev = settings.dev;
const OWNER_ID = "./db/onlyID.json";
const ownerId = settings.ownerId;
const panel = settings.panel;
const ppNebula = "https://files.catbox.moe/sbqsli.jpg";

const OWNER_FILE = './db/users/adminID.json';

// Prevent duplicate Telegram handlers when this module is accidentally loaded
// more than once against the same bot instance.
const REGISTERED_INSTALL_BOTS = global.__LIANIX_INSTALL_REGISTERED_BOTS__ || (global.__LIANIX_INSTALL_REGISTERED_BOTS__ = new WeakSet());

// Loader owner yang konsisten. Versi sebelumnya mengimpor loadJsonData
// dari src/data/function.js, tetapi fungsi tersebut tidak diekspor sehingga
// command uninstall bisa melempar ReferenceError sebelum mengirim respons.
function loadJsonData(file) {
  try {
    if (!fs.existsSync(file)) return [];
    const raw = fs.readFileSync(file, 'utf8');
    const data = JSON.parse(raw || '[]');
    return Array.isArray(data) ? data : [];
  } catch (e) {
    console.error('[install] gagal membaca JSON:', file, e.message);
    return [];
  }
}

// Port SSH default dapat diatur lewat settings.sshPort / SSH_PORT.
const DEFAULT_SSH_PORT = Number(settings.sshPort || process.env.SSH_PORT || 22);

const LIANIX_NODE_MANIFEST = path.join(__dirname, "../nest/lianix/nodejs.json");
const LIANIX_PYTHON_MANIFEST = path.join(__dirname, "../nest/lianix/python.json");

function loadManifestB64(file) {
  try {
    return fs.readFileSync(file).toString("base64");
  } catch (e) {
    console.error("[install] Manifest Lianix tidak ditemukan:", file, e.message);
    return null;
  }
}

const lianixNodeManifestB64 = loadManifestB64(LIANIX_NODE_MANIFEST);
const lianixPythonManifestB64 = loadManifestB64(LIANIX_PYTHON_MANIFEST);


// fungsi validasi IP
function isValidIP(ip) {
  const ipRegex = /^(\d{1,3}\.){3}\d{1,3}$/;
  return ipRegex.test(ip);
}

// Legacy Cloudflare subdomain provider: credentials are no longer bundled.
// Set CF_SUBDOMAINS_JSON only if legacy domains are still required.
try {
  global.subdomain = process.env.CF_SUBDOMAINS_JSON
    ? JSON.parse(process.env.CF_SUBDOMAINS_JSON)
    : {};
} catch {
  global.subdomain = {};
}


const userStates = new Map();
let lastMessageContent = {};

module.exports = (bot) => {
    if (REGISTERED_INSTALL_BOTS.has(bot)) {
      console.warn('[install] handlers already registered for this bot; skipping duplicate registration.');
      return;
    }
    REGISTERED_INSTALL_BOTS.add(bot);

    // log command
function notifyOwner(commandName, msg) {
    const userId = msg.from.id;
    const username = msg.from.username || msg.from.first_name;
    const chatId = msg.chat.id;
    const now = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });

    const logMessage = `<pre>❝ Command: /${commandName}
◉ User: @${username}
⌇ ID: ${userId}
◷ Waktu: ${now}
</pre>
    `;
    bot.sendMessage(OWNER_ID, logMessage, { parse_mode: 'HTML' });
}
    
    // createloc
bot.onText(/^\/createloc (.+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const args = match[1].split("|");

  if (args.length < 3) {
    return bot.sendMessage(chatId, "✕ Format salah!\n\nContoh:\n/createloc https://domain|ptlaApikey|SG");
  }

  const domain = args[0].trim();
  const ptla = args[1].trim();
  const shortCode = args[2].trim().toUpperCase();

  try {
    const locationData = {
      short: shortCode,
      description: `Location ${shortCode}`
    };

    const response = await axios.post(
      `${domain}/api/application/locations`,
      locationData,
      {
        headers: {
          "Authorization": `Bearer ${ptla}`,
          "Content-Type": "application/json",
          "Accept": "Application/vnd.pterodactyl.v1+json"
        }
      }
    );

    const location = response.data.attributes;

    bot.sendMessage(
      chatId,
      `✓ *ʟᴏᴄᴀᴛɪᴏɴ ʙᴇʀʜᴀꜱɪʟ ᴅɪʙᴜᴀᴛ!*\n\nShort Code: ${location.short}\nID: ${location.id}`,
      { parse_mode: "Markdown" }
    );
  } catch (error) {
    console.error("Error creating location:", error.response?.data || error.message);

    if (error.response?.data?.errors) {
      const errorDetails = error.response.data.errors;
      let errorMessage = "✕ Gagal membuat location:\n";

      errorDetails.forEach(err => {
        errorMessage += `• ${err.detail || err.code}\n`;
      });

      bot.sendMessage(chatId, errorMessage);
    } else {
      bot.sendMessage(chatId, "✕ Terjadi kesalahan saat membuat location. Silakan coba lagi.");
    }
  }
});


const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

bot.onText(/\/reinstall (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    return bot.sendMessage(
      chatId,
      "⚠ Command /reinstall dinonaktifkan karena menjalankan script dari repo pihak ketiga (rexzy223/tools) sebagai root, sumber belum terverifikasi aman."
    );
    // eslint-disable-next-line no-unreachable
    const [ip, user, pass, domainNew, domainOld] = match[1].split("|");

    if (!ip || !user || !pass || !domainNew || !domainOld) {
        return bot.sendMessage(
            chatId,
            "Format salah!\n/reinstall ip|user|pass|domain_new|domain_old"
        );
    }

    bot.sendMessage(chatId, "➤ Connecting SSH...");

    const conn = new Client();

    conn.on("ready", async () => {
        bot.sendMessage(chatId, "✓ SSH Connected");

        conn.shell(async (err, stream) => {
            if (err) {
                return bot.sendMessage(chatId, "✕ Shell error: " + err.message);
            }

            // jalankan script
            stream.write("bash <(curl -s https://raw.githubusercontent.com/rexzy223/tools/main/run.sh)\n");

            bot.sendMessage(chatId, "⏳ Menunggu menu...");

            // STEP 1: tunggu 30 detik lalu kirim "1"
            await sleep(30000);
            stream.write("1\n");
            bot.sendMessage(chatId, "⬡ Send: 1");

            // STEP 2: tunggu lalu kirim domain baru
            await sleep(8000);
            stream.write(domainNew + "\n");
            bot.sendMessage(chatId, "⬡ Domain Baru terkirim");

            // STEP 3: tunggu lalu kirim domain lama
            await sleep(8000);
            stream.write(domainOld + "\n");
            bot.sendMessage(chatId, "⬡ Domain Lama terkirim");

            // selesai
            await sleep(5000);
            bot.sendMessage(chatId, "✓ Reinstall selesai");
            conn.end();
        });
    });

    conn.on("error", (err) => {
        bot.sendMessage(chatId, "✕ SSH Error: " + err.message);
    });

    conn.connect({
        host: ip,
        port: 22,
        username: user,
        password: pass,
    });
});

const LOCAL_MAINTANCE_FILE = "./src/index.html"

// [removed] /maintance, /kunci, /deface, /undeface - SSH-based server defacement/lockout tools (unauthorized access / website defacement)
bot.onText(/^(\.|\#|\/)createnode\s+(.+)$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const fromId = String(msg.from.id);
  const paramText = match[2];
  const owners = loadJsonData(OWNER_FILE);

  if (!owners.includes(fromId)) {
    return bot.sendMessage(chatId, "✕ Kamu tidak memiliki akses owner!");
  }

  const parts = paramText.split("|").map(x => x.trim());
  if (parts.length < 2) {
    return bot.sendMessage(
      chatId,
      "✕ Format salah: /createnode ipvps|password"
    );
  }

  userStates[chatId] = {
    type: "createnode",
    step: "node_name",
    userId: fromId,
    data: {
      ipvps: parts[0],
      passwd: parts[1]
    }
  };

  bot.sendMessage(chatId, "⌂ Masukkan nama node:");
});

bot.on("message", async (msg) => {
  const chatId = msg.chat.id;
  const text = (msg.text || "").trim();
  if (!text || text.startsWith("/")) return;

  const state = userStates[chatId];
  if (!state || state.type !== "createnode") return;

  switch (state.step) {

    case "node_name":
      state.data.namenode = text;
      state.step = "domain";
      return bot.sendMessage(
        chatId,
        "⟐ Masukkan domain node:\nContoh: node1.example.com"
      );

    case "domain":
      state.data.domainnode = text;
      state.step = "ram";
      return bot.sendMessage(
        chatId,
        "⟡ Masukkan RAM node\nContoh 16GB = 1600000"
      );

    case "ram":
      state.data.ramserver = text;
      state.step = "confirm";
      const d = state.data;

      return bot.sendMessage(
        chatId,
`<b>☰ Konfirmasi Data Node</b>
<blockquote>
⟐ IP VPS : ${d.ipvps}
⌂ Nama Node : ${d.namenode}
↠ Domain Node : ${d.domainnode}
⟡ RAM : ${d.ramserver}
</blockquote>`,
        {
          parse_mode: "HTML",
          reply_markup: {
            inline_keyboard: [
              [
                { text: "✓ YES", callback_data: "createnode_yes" },
                { text: "✕ CANCEL", callback_data: "createnode_cancel" }
              ]
            ]
          }
        }
      );
  }
});

bot.on("callback_query", async (query) => {
  const chatId = query.message.chat.id;
  const data = query.data;

  const state = userStates[chatId];
  if (!state || state.type !== "createnode") return;

  if (data === "createnode_yes") {
    const payload = { ...state.data };
    delete userStates[chatId];

    await bot.answerCallbackQuery(query.id, { text: "Memproses..." });
    return runCreateNode(chatId, query.message, payload);
  }

  if (data === "createnode_cancel") {
    delete userStates[chatId];
    await bot.answerCallbackQuery(query.id, { text: "Dibatalkan" });
    return bot.sendMessage(chatId, "✕ Proses create node dibatalkan.");
  }
});

function runCreateNode(chatId, msg, {
  ipvps,
  passwd,
  namenode,
  domainnode,
  ramserver
}) {
  bot.sendMessage(
    chatId,
    "⚠ Fitur create node ini dinonaktifkan karena menjalankan script dari repo rexzy223/tema yang belum terverifikasi aman (repo lain dari akun yang sama terbukti backdoor)."
  );
  return;
  // eslint-disable-next-line no-unreachable
  const ssh = new Client();

  ssh.on("ready", () => {
    bot.sendMessage(chatId, "⌂ Memproses create node...");

    const commandCreateNode =
      "bash <(curl -s https://raw.githubusercontent.com/rexzy223/tema/main/createnode.sh)";

    ssh.exec(commandCreateNode, (err, stream) => {
      if (err) {
        bot.sendMessage(chatId, "✕ Gagal menjalankan script.");
        ssh.end();
        return;
      }

      stream.on("close", () => {
        bot.sendMessage(
          chatId,
`<b>✓ Sukses Create Node!</b>
<blockquote>
<b>⚠ Token Deployment</b>
1. Login panel Pterodactyl
2. Pilih node yang baru dibuat
3. Configuration → Generate Token
4. Ketik /swings ipvps|password|token
</blockquote>`,
          { parse_mode: "HTML", reply_to_message_id: msg.message_id }
        );
        ssh.end();
      });

      stream.on("data", (data) => {
        const o = data.toString();

        if (o.includes("Masukkan nama lokasi"))
          stream.write("SGP\n");
        else if (o.includes("Masukkan deskripsi lokasi"))
          stream.write("NODE-1n");
        else if (o.includes("Masukkan domain"))
          stream.write(`${domainnode}\n`);
        else if (o.includes("Masukkan nama node"))
          stream.write(`${namenode}\n`);
        else if (o.includes("Masukkan RAM"))
          stream.write(`${ramserver}\n`);
        else if (o.includes("disk space"))
          stream.write(`${ramserver}\n`);
        else if (o.includes("Masukkan Locid"))
          stream.write("1\n");
      });
    });
  });

  ssh.on("error", () => {
    bot.sendMessage(chatId, "✕ IP atau password VPS salah!");
  });

  ssh.connect({
    host: ipvps,
    port: 22,
    username: "root",
    password: passwd
  });
}
    // runtime vps
bot.onText(/^\/runtimevps(?:\s+(.+))?/, async (msg, match) => {
  notifyOwner('runtimevps', msg);
  const chatId = msg.chat.id;
  const input = match[1];
    
  if (!input) {
    return bot.sendMessage(chatId, "✕ Format salah!\nContoh: /runtimevps ipvps|pwvps");
  }

  if (!input.includes("|")) {
    return bot.sendMessage(chatId, "✕ Format salah!\nGunakan: `/runtimevps ipvps|password`", {
      parse_mode: "Markdown"
    });
  }

  let [host, password] = input.split("|");
  host = host.trim();
  password = password.trim();

  try {
    const conn = new Client();

    conn
      .on("ready", () => {
        conn.exec("uptime -p", (err, stream) => {
          if (err) {
            bot.sendMessage(chatId, "✕ Gagal eksekusi command uptime.");
            return conn.end();
          }

          let output = "";
          stream
            .on("data", (data) => {
              output += data.toString();
            })
            .on("close", () => {
              bot.sendMessage(chatId, `✓ ʀᴜɴᴛɪᴍᴇ ᴠᴘꜱ ${host}\n\`\`\`${output.trim()}\`\`\``, {
                parse_mode: "Markdown"
              });
              conn.end();
            });
        });
      })
      .on("error", (err) => {
        bot.sendMessage(chatId, `✕ Gagal konek VPS: ${err.message}`);
      })
      .connect({
        host,
        port: 22,
        username: "root",
        password
      });

  } catch (err) {
    bot.sendMessage(chatId, "✕ Terjadi kesalahan koneksi VPS.");
    console.error(err);
  }
});

async function generateDomainKeyboard(domains, page = 0, host, ip) {

    const perPage = 12;
    const start = page * perPage;
    const end = start + perPage;
    const currentDomains = domains.slice(start, end);

    const keyboard = [];

    for (let i = 0; i < currentDomains.length; i += 2) {

        const row = [];

        for (let j = 0; j < 2; j++) {

            const d = currentDomains[i + j];
            if (!d) continue;

            row.push({
                text: `${d}`,
                callback_data: `create_domain ${start + i + j} ${host}|${ip}`
            });

        }

        keyboard.push(row);
    }

    const nav = [];

    if (page > 0) {
        nav.push({ text: "⬅ ‹", callback_data: `page_domain ${page - 1} ${host}|${ip}` });
    }

    if (end < domains.length) {
        nav.push({ text: "➡ Lanjut", callback_data: `page_domain ${page + 1} ${host}|${ip}` });
    }

    if (nav.length > 0) keyboard.push(nav);

    return keyboard;
}

// ================== COMMAND ==================
bot.onText(/^\/(?:subdo|subdomain)(?:\s+(.+))?$/i, async (msg, match) => {

    const chatId = msg.chat.id;

    // DuckDNS menjadi provider utama bila token tersedia.
    if (process.env.DUCKDNS_TOKEN) {
        const ownersDuck = loadJsonData(OWNER_FILE);
        if (!ownersDuck.includes(msg.from.id.toString())) {
            return bot.sendMessage(chatId, "✕ Kamu tidak memiliki akses owner!!!");
        }

        const textDuck = String(match?.[1] || "").trim();
        if (!textDuck || !textDuck.includes("|")) {
            return bot.sendMessage(chatId, "✕ Contoh: /subdo mambo-noir|ipvps\n✕ Atau: /subdo nodemambo-noir|ipvps");
        }

        let [hostDuck, ipDuck] = textDuck.split("|").map(v => v.trim());
        hostDuck = hostDuck.toLowerCase()
            .replace(/^https?:\/\//, "")
            .replace(/\.duckdns\.org\.?$/, "")
            .replace(/[^a-z0-9-]/g, "")
            .replace(/^-+|-+$/g, "");
        ipDuck = ipDuck.replace(/[^0-9.]/g, "");

        if (!hostDuck) return bot.sendMessage(chatId, "✕ Nama DuckDNS tidak valid.");
        if (!/^(?:\d{1,3}\.){3}\d{1,3}$/.test(ipDuck) || ipDuck.split(".").some(n => Number(n) > 255)) {
            return bot.sendMessage(chatId, "✕ IP tidak valid.");
        }

        try {
            const axiosDuck = require("axios");
            const response = await axiosDuck.get("https://www.duckdns.org/update", {
                params: { domains: hostDuck, token: process.env.DUCKDNS_TOKEN, ip: ipDuck, verbose: "true" },
                timeout: 15000,
                responseType: "text"
            });
            const result = String(response.data || "").trim();
            if (!result.startsWith("OK")) throw new Error(result || "KO");
            return bot.sendMessage(chatId, `<blockquote><b>✓ DuckDNS Berhasil</b>\n\n<b>Domain :</b> <code>${hostDuck}.duckdns.org</code>\n<b>IP :</b> <code>${ipDuck}</code></blockquote>`, { parse_mode: "HTML" });
        } catch (e) {
            const safe = String(e.message || e).replace(/&/g, "&amp;").replace(/</g, "&lt;");
            return bot.sendMessage(chatId, `<blockquote><b>✕ DuckDNS Gagal</b>\n\n<code>${safe}</code></blockquote>`, { parse_mode: "HTML" });
        }
    }
    const owners = loadJsonData(OWNER_FILE);

    if (!owners.includes(msg.from.id.toString())) {
        return bot.sendMessage(chatId, "✕ Kamu tidak memiliki akses owner!!!");
    }

    const text = match[1];

    if (!text || !text.includes("|")) {
        return bot.sendMessage(chatId, "✕ Contoh: /subdo host|ipvps");
    }

    let [host, ip] = text.split("|").map(v => v.trim());

    host = host
        .replace(/[^a-z0-9.-]/gi, "")
        .toLowerCase()
        .replace(/\.+/g, ".")
        .replace(/^\./, "")
        .replace(/\.$/, "");

    ip = ip.replace(/[^0-9.]/gi, "");

    const isValidIP = /^(\d{1,3}\.){3}\d{1,3}$/.test(ip);
    if (!isValidIP) {
        return bot.sendMessage(chatId, "✕ IP tidak valid");
    }

    const dom = Object.keys(global.subdomain);

    if (dom.length === 0) {
        return bot.sendMessage(chatId, "✕ Tidak ada domain.");
    }

    const keyboard = await generateDomainKeyboard(dom, 0, host, ip);

    bot.sendMessage(chatId, `⬡ *Pilih Domain*`, {
        parse_mode: "Markdown",
        reply_markup: { inline_keyboard: keyboard }
    });

});

// ================== CALLBACK ==================
bot.on("callback_query", async (callbackQuery) => {

    const msg = callbackQuery.message;
    const data = callbackQuery.data.split(" ");

    // ===== PAGE =====
    if (data[0] === "page_domain") {

        const page = Number(data[1]);
        const payload = data.slice(2).join("\n");
        const [host, ip] = payload.split("|");

        const dom = Object.keys(global.subdomain);
        const keyboard = await generateDomainKeyboard(dom, page, host, ip);

        await bot.editMessageReplyMarkup(
            { inline_keyboard: keyboard },
            { chat_id: msg.chat.id, message_id: msg.message_id }
        );

        return bot.answerCallbackQuery(callbackQuery.id);
    }

    // ===== CREATE DOMAIN =====
    if (data[0] === "create_domain") {

        const domainIndex = Number(data[1]);
        const payload = data.slice(2).join("\n");
        let [host, ip] = payload.split("|");

        const dom = Object.keys(global.subdomain);

        if (domainIndex < 0 || domainIndex >= dom.length) {
            return bot.answerCallbackQuery(callbackQuery.id, {
                text: "✕ Domain tidak ditemukan",
                show_alert: true
            });
        }

        const tldnya = dom[domainIndex];

        async function createSubDomain(name, ip) {

            const cfg = global.subdomain[tldnya];

            const headers = {
                Authorization: `Bearer ${cfg.apitoken}`,
                "Content-Type": "application/json"
            };

            const check = await axios.get(
                `https://api.cloudflare.com/client/v4/zones/${cfg.zone}/dns_records?type=A&name=${name}`,
                { headers }
            );

            if (check.data.result.length > 0) {

                const record = check.data.result[0];

                const update = await axios.put(
                    `https://api.cloudflare.com/client/v4/zones/${cfg.zone}/dns_records/${record.id}`,
                    {
                        type: "A",
                        name,
                        content: ip,
                        ttl: 1,
                        proxied: false
                    },
                    { headers }
                );

                if (!update.data.success) {
                    throw new Error(JSON.stringify(update.data.errors));
                }

                return "updated";
            }

            const create = await axios.post(
                `https://api.cloudflare.com/client/v4/zones/${cfg.zone}/dns_records`,
                {
                    type: "A",
                    name,
                    content: ip,
                    ttl: 1,
                    proxied: false
                },
                { headers }
            );

            if (!create.data.success) {
                throw new Error(JSON.stringify(create.data.errors));
            }

            return "created";
        }

        try {

            host = host
                .replace(/[^a-z0-9.-]/gi, "")
                .toLowerCase()
                .replace(/\.+/g, ".")
                .replace(/^\./, "")
                .replace(/\.$/, "");

            ip = ip.replace(/[^0-9.]/gi, "");

            let domain = `${host}.${tldnya}`;

            await createSubDomain(domain, ip);

            // ✓ SUKSES → EDIT MESSAGE + HAPUS BUTTON
            await bot.editMessageText(
`✓ *Domain Berhasil Dibuat*

⟐ Domain : \`${domain}\`
⬡ IP VPS : \`${ip}\``,
                {
                    chat_id: msg.chat.id,
                    message_id: msg.message_id,
                    parse_mode: "Markdown",
                    reply_markup: { inline_keyboard: [] }
                }
            );

        } catch (e) {

            console.log("ERROR:", e.response?.data || e.message);

            // ✕ GAGAL → KIRIM MESSAGE BARU (BUTTON TIDAK DIUBAH)
            await bot.sendMessage(
                msg.chat.id,
`✕ *Gagal membuat domain*

⟐ Domain : \`${host}.${tldnya}\`

Error:
\`${e.response?.data?.errors?.[0]?.message || e.message}\``,
                { parse_mode: "Markdown" }
            );

        }

        return bot.answerCallbackQuery(callbackQuery.id);
    }

});

bot.onText(/^\/ceksubdo(?:\s+(.+))?$/i, async (msg, match) => {
    const chatId = msg.chat.id;
    const domain = match[1]?.trim();

    if (!domain) {
        return bot.sendMessage(chatId, "✕ Contoh: /ceksubdo sub.example.com");
    }

    const domainRegex = /^(?!:\/\/)([a-zA-Z0-9-_]+\.)+[a-zA-Z]{2,}$/;
    if (!domainRegex.test(domain)) {
        return bot.sendMessage(chatId, "✕ Format domain tidak valid");
    }

    try {
        const records = await dns.resolve4(domain);

        if (!records || records.length === 0) {
            return bot.sendMessage(
                chatId,
                `✕ *SUBDOMAIN TIDAK DITEMUKAN*\n\n⟐ Domain : \`${domain}\``,
                { parse_mode: "Markdown" }
            );
        }

        await bot.sendMessage(
            chatId,
            `✓ *SUBDOMAIN VALID*\n\n⟐ Domain : \`${domain}\`\n⬡ IP : \`${records.join(", ")}\``,
            { parse_mode: "Markdown" }
        );
    } catch (e) {
        await bot.sendMessage(
            chatId,
            `✕ *SUBDOMAIN TIDAK DITEMUKAN*\n\n⟐ Domain : \`${domain}\``,
            { parse_mode: "Markdown" }
        );
    }
});
bot.onText(/^\/listsubdo$/, async (msg) => {
  const chatId = msg.chat.id;
  const owners = loadJsonData(OWNER_FILE);

  if (!owners.includes(msg.from.id.toString())) {
    return bot.sendMessage(
      chatId,
      "<blockquote>✕ Khusus owner!</blockquote>",
      { parse_mode: "HTML" }
    );
  }

  if (process.env.DUCKDNS_TOKEN) {
    const domains = (process.env.DUCKDNS_DOMAINS || "mambo-noir,nodemambo-noir")
      .split(",").map(v => v.trim()).filter(Boolean);
    const rows = [];
    for (const d of domains) {
      const fqdn = `${d}.duckdns.org`;
      let ips = [];
      try { ips = await require("dns").promises.resolve4(fqdn); } catch {}
      rows.push(`${ips.length ? "✓" : "✕"} <code>${fqdn}</code>${ips.length ? ` → <code>${ips.join(", ")}</code>` : ""}`);
    }
    return bot.sendMessage(chatId, `<blockquote><b>DUCKDNS SUBDOMAIN</b>\n\n${rows.join("\n")}</blockquote>`, { parse_mode: "HTML" });
  }

  const allSubdomains = Object.keys(global.subdomain);
  if (allSubdomains.length === 0) {
    return bot.sendMessage(
      chatId,
      "<blockquote>✕ Tidak ada domain yang tersedia saat ini.</blockquote>",
      { parse_mode: "HTML" }
    );
  }

  let teks = "<blockquote>⌗ <b>Daftar Subdomain</b>\n\n";

  const cekPromises = allSubdomains.map(async (d, index) => {
    const { zone, apitoken } = global.subdomain[d];
    let icon = "✕"; // default error

    try {
      const cek = await axios.get(`https://api.cloudflare.com/client/v4/zones/${zone}`, {
        headers: {
          Authorization: `Bearer ${apitoken}`,
          "Content-Type": "application/json"
        }
      });

      if (cek.data.success) icon = "✓"; // valid
    } catch {}

    return `${icon} ${index + 1}. ${d}`;
  });

  const hasil = await Promise.all(cekPromises);
  teks += hasil.join("\n") + "</blockquote>"; // tutup blok quote setelah semua teks

  bot.sendMessage(chatId, teks, {
    parse_mode: "HTML",
    reply_to_message_id: msg.message_id
  });
});

bot.onText(/^\/totalsubdo$/i, async (msg) => {
  const chatId = msg.chat.id;

  const keyboard = Object.keys(global.subdomain).map(domain => ([
    { text: domain, callback_data: `totalsubdo:${domain}` }
  ]));

  await bot.sendMessage(
    chatId,
    "<blockquote>⌗ Pilih Root Domain</blockquote>",
    {
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: keyboard }
    }
  );
});

bot.on("callback_query", async (query) => {
  const chatId = query.message.chat.id;
  const data = query.data;
  if (!data.startsWith("totalsubdo:")) return;

  const root = data.split(":")[1];
  const cfg = global.subdomain[root];
  if (!cfg) return;

  try {
    const res = await axios.get(
      `https://api.cloudflare.com/client/v4/zones/${cfg.zone}/dns_records?per_page=1000`,
      {
        headers: {
          Authorization: `Bearer ${cfg.apitoken}`,
          "Content-Type": "application/json"
        }
      }
    );

    const records = res.data.result || [];

    const listDomain = records
      .map((r, i) => {
        const isOff =
          r.disabled === true ||
          r.content === "0.0.0.0" ||
          !r.content;

        const status = isOff ? "off ✕" : "on ✓";
        return `${i + 1}. <code>${r.name}</code> ( ${status} )`;
      })
      .join("\n");

    const message = `
<blockquote>
⌗ TOTAL SUBDOMAIN

⟐ Root : <code>${root}</code>
⬡ Total : ${records.length}

${listDomain}
</blockquote>
`;

    await bot.deleteMessage(chatId, query.message.message_id);
    await bot.sendMessage(chatId, message, { parse_mode: "HTML" });

    bot.answerCallbackQuery(query.id);
  } catch {
    bot.sendMessage(
      chatId,
      "<blockquote>✕ Gagal mengambil data</blockquote>",
      { parse_mode: "HTML" }
    );
  }
});
bot.onText(/^\/delsubdo(?:\s+(.+))?$/i, async (msg, match) => {
  notifyOwner("delsubdo", msg);
  const chatId = msg.chat.id;
  const owners = loadJsonData(OWNER_FILE);

  if (!owners.includes(msg.from.id.toString())) {
    return bot.sendMessage(chatId, "✕ Kamu tidak memiliki akses owner!!!");
  }

  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      "✕ Format salah!\nContoh: /delsubdo mambo-noir.duckdns.org,nodemambo-noir.duckdns.org"
    );
  }

  if (process.env.DUCKDNS_TOKEN) {
    const domains = match[1].split(",").map(d => d.trim()).filter(Boolean);
    const results = [];
    for (const raw of domains) {
      const name = raw.toLowerCase().replace(/\.duckdns\.org\.?$/, "").replace(/[^a-z0-9-]/g, "");
      if (!name) continue;
      try {
        const r = await axios.get("https://www.duckdns.org/update", {
          params: { domains: name, token: process.env.DUCKDNS_TOKEN, clear: "true" },
          timeout: 15000, responseType: "text"
        });
        results.push(`${String(r.data || "").trim().startsWith("OK") ? "✓" : "✕"} ${name}.duckdns.org`);
      } catch { results.push(`✕ ${name}.duckdns.org`); }
    }
    return bot.sendMessage(chatId, `<blockquote><b>DUCKDNS CLEAR</b>\n\n${results.join("\n") || "Tidak ada domain valid."}</blockquote>`, { parse_mode: "HTML" });
  }

  const domains = match[1]
    .split(",")
    .map(d => d.trim())
    .filter(Boolean);

  if (!domains.length) {
    return bot.sendMessage(chatId, "✕ Format salah!");
  }

  for (const domain of domains) {
    const tld = Object.keys(global.subdomain).find(d => domain.endsWith(d));
    if (!tld) {
      await bot.sendMessage(
        chatId,
        `✕ Domain tidak ditemukan dalam list global.subdomain!\n\n⟐ \`${domain}\``,
        { parse_mode: "Markdown" }
      );
      continue;
    }

    const zone = global.subdomain[tld].zone;
    const token = global.subdomain[tld].apitoken;

    try {
      const find = await axios.get(
        `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records?name=${domain}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json"
          }
        }
      );

      if (!find.data.success || find.data.result.length === 0) {
        await bot.sendMessage(
          chatId,
          `✕ Subdomain tidak ditemukan di Cloudflare!\n\n⟐ \`${domain}\``,
          { parse_mode: "Markdown" }
        );
        continue;
      }

      const recordId = find.data.result[0].id;

      const del = await axios.delete(
        `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records/${recordId}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json"
          }
        }
      );

      if (del.data.success) {
        await bot.sendMessage(
          chatId,
          `✓ *Berhasil menghapus subdomain*\n\n⟐ \`${domain}\``,
          { parse_mode: "Markdown" }
        );
      } else {
        await bot.sendMessage(
          chatId,
          `✕ Gagal menghapus subdomain\n\n⟐ \`${domain}\``,
          { parse_mode: "Markdown" }
        );
      }

    } catch (e) {
      await bot.sendMessage(
        chatId,
        `✕ Error:\n${e.response?.data?.errors?.[0]?.message || e.message}\n\n⟐ \`${domain}\``,
        { parse_mode: "Markdown" }
      );
    }
  }
});
// Command /installdepend — installer dependency lokal/terkontrol.
bot.onText(/^\/installdepend(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from?.id;
  if (userId !== ownerId && getUserRole(userId) !== "ceo") return bot.sendMessage(chatId, "✗ Khusus Owner/CEO!");
  const input = match?.[1]?.trim() || "";
  if (!input || input.split("|").length < 2) return bot.sendMessage(chatId,
    `<blockquote expandable><b>PANDUAN INSTALL DEPENDENCY</b>\n\n<b>Format:</b> <code>/installdepend host_target | password_vps</code>\n\nMemasang dependency dasar dari repository OS resmi: curl, ca-certificates, gnupg, unzip, tar, git, jq, lsb-release, software-properties-common.</blockquote>`,
    { parse_mode:"HTML" });
  const parts=input.split("|"); const targetRaw=parts.shift().trim(); const password=parts.join("|").trim();
  let target; try{target=parseSshTarget(targetRaw);}catch(e){return bot.sendMessage(chatId,`✕ ${escapeHTML(e.message)}`,{parse_mode:"HTML"});}
  if(!password)return bot.sendMessage(chatId,"✕ Password VPS kosong.");
  const st=await bot.sendMessage(chatId,"<b>INSTALL DEPENDENCY</b>\n\n<code>[░░░░░░░░░░] 0%</code>\nMenyiapkan SSH...",{parse_mode:"HTML"});
  const ui=createLiveInstallerCard(bot,chatId,st.message_id,{title:"INSTALL DEPENDENCY",target:target.display,status:"Membangun koneksi SSH...",stage:"Persiapan",percent:0}); await ui.flush();
  const conn=new Client(); let done=false;
  const timer=setTimeout(async()=>{if(done)return;done=true;try{conn.end()}catch{};await ui.close();await safeEdit(bot,chatId,st.message_id,"✕ <b>INSTALL DEPENDENCY GAGAL</b>\n\nTimeout 12 menit. Proses dihentikan agar tidak stuck.").catch(()=>{});},12*60*1000); if(timer.unref)timer.unref();
  conn.once("ready",async()=>{
    try{
      await showVpsProfileInCard(ui, conn, target.display);
      await ui.setStage("Tahap 0/3 • Identitas VPS selesai dibaca",8,true);
      await ui.setStatus("✅ SSH Terhubung! • Memasang dependency...",true);
      const script=`set -Eeuo pipefail
exec 9>/run/lock/lianix-panel-action.lock
flock -n 9 || { echo LIANIX_BUSY; exit 88; }
command -v apt-get >/dev/null 2>&1 || { echo UNSUPPORTED_OS; exit 20; }
export DEBIAN_FRONTEND=noninteractive
echo DEP_STEP_1
WAIT=0
while fuser /var/lib/dpkg/lock-frontend >/dev/null 2>&1 || fuser /var/lib/dpkg/lock >/dev/null 2>&1 || fuser /var/lib/apt/lists/lock >/dev/null 2>&1; do WAIT=$((WAIT+2)); [ "$WAIT" -ge 120 ] && { echo APT_LOCK_TIMEOUT; exit 21; }; echo "Menunggu apt lock • $WAIT/120s"; sleep 2; done
echo DEP_STEP_2
(timeout 600 apt-get -o DPkg::Lock::Timeout=120 -o Acquire::Retries=3 update -y && timeout 600 apt-get -o DPkg::Lock::Timeout=120 install -y curl ca-certificates gnupg unzip tar git jq lsb-release software-properties-common apt-transport-https) >/tmp/lianix-deps.log 2>&1 &
PID=$!; SEC=0
while kill -0 "$PID" >/dev/null 2>&1; do sleep 5; SEC=$((SEC+5)); echo "DEP_HEARTBEAT:apt masih berjalan • $SEC s"; tail -n 2 /tmp/lianix-deps.log 2>/dev/null | sed 's/^/APT • /' || true; done
if ! wait "$PID"; then tail -n 100 /tmp/lianix-deps.log; echo DEP_APT_FAILED; exit 22; fi
echo DEP_STEP_3
for C in curl unzip tar git jq; do command -v "$C" >/dev/null 2>&1 || { echo "DEP_MISSING:$C"; exit 23; }; done
echo DEP_OK`;
      const r=await runLianixRemoteScript(conn,script,{username:target.username,password,maxRuntimeMs:11*60*1000,onLine:async(row,isErr)=>{if(row.includes('DEP_STEP_1'))await ui.setStage('Tahap 1/3 • Menunggu package manager',20,true);else if(row.includes('DEP_STEP_2'))await ui.setStage('Tahap 2/3 • Install package resmi',55,true);else if(row.includes('DEP_STEP_3'))await ui.setStage('Tahap 3/3 • Verifikasi binary',90,true);else if(row!=='LIANIX_REMOTE_CHANNEL_OK'&&row!=='DEP_OK')await ui.add(row,{stderr:isErr});}});
      done=true;clearTimeout(timer);try{conn.end()}catch{};const all=`${r.out||''}\n${r.errOut||''}`;
      if(r.code===0&&all.includes('DEP_OK')){await ui.setStage('Tahap 3/3 • Dependency siap',100,true);await ui.close();return safeEdit(bot,chatId,st.message_id,`✓ <b>DEPENDENCY BERHASIL DIINSTALL</b>\n\nTarget: <code>${escapeHTML(target.display)}</code>\nStatus: <b>TERVERIFIKASI</b>`);}
      await ui.close();return safeEdit(bot,chatId,st.message_id,`✕ <b>INSTALL DEPENDENCY GAGAL</b>\n\n${escapeHTML(r.errOut?.trim()||r.out?.trim()||`Exit ${r.code}`).slice(0,1800)}`);
    }catch(e){done=true;clearTimeout(timer);try{conn.end()}catch{};await ui.close();return safeEdit(bot,chatId,st.message_id,`✕ <b>INSTALL DEPENDENCY GAGAL</b>\n\n${escapeHTML(String(e?.message||e)).slice(0,1800)}`);}
  });
  conn.once("error",async e=>{if(done)return;done=true;clearTimeout(timer);await ui.close();await safeEdit(bot,chatId,st.message_id,`✕ <b>INSTALL DEPENDENCY GAGAL</b>\n\nKoneksi SSH: ${escapeHTML(e.message)}`).catch(()=>{});});
  conn.connect({host:target.host,port:target.port,username:target.username,password,readyTimeout:20000,keepaliveInterval:5000,keepaliveCountMax:3});
});

bot.onText(/^\/setpwvps(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  return bot.sendMessage(chatId, "⚠ Command /setpwvps dinonaktifkan karena menjalankan script dari repo pihak ketiga (rexzy223/tema) yang belum terverifikasi aman.");
  // eslint-disable-next-line no-unreachable
  notifyOwner('setpwvps', msg);
  const userId = msg.from.id;
    
  let text = match[1];
  if (!text) {
    return bot.sendMessage(chatId, "✕ Format salah!\nContoh: /setpwvps ipvps|password_lama|password_baru");
  }
    
  let t = text.split("|");
  if (t.length < 3) {
    return bot.sendMessage(chatId, "✕ Format salah!\nContoh:\n/setpwvps ipvps|password_lama|password_baru");
  }

  let ipvps = t[0].trim();
  let passwd = t[1].trim();
  let newpw = t[2].trim();

  await bot.sendMessage(chatId, "⏳ Sedang Memproses...");

  const connSettings = {
    host: ipvps,
    port: 22,
    username: "root",
    password: passwd
  };

  const command = `bash <(curl -s https://raw.githubusercontent.com/rexzy223/tema/refs/heads/main/install.sh)`;
  const conn = new Client();

  conn.on("ready", () => {
    conn.exec(command, (err, stream) => {
      if (err) throw err;

      stream.on("close", async () => {
        conn.end();
      }).on("data", (data) => {
        console.log("STDOUT:", data.toString());
      }).stderr.on("data", (data) => {
        console.log("STDERR:", data.toString());
        stream.write("8\n");
        stream.write(`${newpw}\n`);
        stream.write(`${newpw}\n`);
      });
    });
  }).on("error", (err) => {
    console.log("Connection Error:", err);
    bot.sendMessage(chatId, "✕ ᴋᴀᴛᴀꜱᴀɴᴅɪ ᴀᴛᴀᴜ ɪᴘ ᴛɪᴅᴀᴋ ᴠᴀʟɪᴅ");
  }).connect(connSettings);
    
    let teks = `
*Sukses mengganti password ✓*

*Detail Password:*
⬡ IP VPS: \`${ipvps}\`
⚷ Password: \`${newpw}\`
`;
        await bot.sendMessage(chatId, teks, { parse_mode: "Markdown" });
});
    
function parseSshTarget(input) {
  let raw = String(input || "").trim();
  let username = "root";
  let port = 22;
  if (!raw) throw new Error("Host target kosong.");
  if (raw.includes("@")) {
    const at = raw.indexOf("@");
    username = raw.slice(0, at).trim() || "root";
    raw = raw.slice(at + 1).trim();
  }
  // IPv4/hostname + optional :port. IPv6 literal sengaja tidak dipecah tanpa [] agar tidak ambigu.
  const m = raw.match(/^(.+):(\d{1,5})$/);
  if (m && !m[1].includes(":")) {
    raw = m[1];
    port = Number(m[2]);
  }
  if (!raw || !Number.isInteger(port) || port < 1 || port > 65535) throw new Error("Host/port tidak valid.");
  if (!/^[a-zA-Z0-9._-]+$/.test(username)) throw new Error("Username SSH tidak valid.");
  return { host: raw, port, username, display: `${username}@${raw}:${port}` };
}

function shellQuote(value) {
  return "'" + String(value).replace(/'/g, "'\\''") + "'";
}

// Ambil identitas VPS SEGERA setelah SSH terautentikasi. Command ini read-only,
// kecil, dan punya timeout supaya halaman pre-flight tidak bisa membuat proses stuck.
function readVpsProfile(conn, targetDisplay = "") {
  const cmd = `set +e
printf 'HOSTNAME|'; hostname 2>/dev/null || true
printf 'OS|'; if [ -r /etc/os-release ]; then . /etc/os-release; printf '%s' "\${PRETTY_NAME:-\${NAME:-Linux}}"; else uname -s; fi; printf '\n'
printf 'KERNEL|'; uname -r 2>/dev/null || true
printf 'CPU|'; (lscpu 2>/dev/null | awk -F: '/Model name/{sub(/^[ \\t]+/,"",$2); print $2; exit}') || true
printf 'CPUCORES|'; nproc 2>/dev/null || getconf _NPROCESSORS_ONLN 2>/dev/null || true
printf 'RAM|'; free -h 2>/dev/null | awk '/^Mem:/{print $3" / "$2}' || true
printf 'DISK|'; df -h / 2>/dev/null | awk 'NR==2{print $3" / "$2" ("$5")"}' || true
printf 'VIRT|'; (systemd-detect-virt 2>/dev/null || printf 'unknown')
printf 'UPTIME|'; uptime -p 2>/dev/null || true
printf 'IP|'; hostname -I 2>/dev/null | awk '{print $1}' || true
`;
  return new Promise((resolve) => {
    let finished=false, out='', err='';
    const done=(profile)=>{ if(finished)return; finished=true; clearTimeout(timer); resolve(profile); };
    const timer=setTimeout(()=>done({target:targetDisplay,error:'VPS_PROFILE_TIMEOUT'}),8000); if(timer.unref)timer.unref();
    conn.exec(cmd,(e,stream)=>{
      if(e) return done({target:targetDisplay,error:e.message||String(e)});
      stream.on('data',d=>{out+=String(d)});
      stream.stderr.on('data',d=>{err+=String(d)});
      stream.on('close',()=>{
        const p={target:targetDisplay};
        for(const line of out.split(/\r?\n/)){ const idx=line.indexOf('|'); if(idx<1)continue; p[line.slice(0,idx).trim().toLowerCase()]=line.slice(idx+1).trim(); }
        if(err.trim())p.warning=err.trim().slice(0,500);
        done(p);
      });
    });
  });
}

function formatVpsProfileHtml(p={}) {
  const rows=[
    ['Target',p.target],['Hostname',p.hostname],['OS',p.os],['Kernel',p.kernel],
    ['CPU',p.cpu],['CPU Core',p.cpucores],['RAM',p.ram],['Disk /',p.disk],
    ['Virtualisasi',p.virt],['Uptime',p.uptime],['IP Internal',p.ip]
  ].filter(([,v])=>String(v||'').trim());
  return `<b>🖥 VPS TERHUBUNG</b>\n`+rows.map(([k,v])=>`<b>${escapeHTML(k)}:</b> <code>${escapeHTML(v)}</code>`).join('\n');
}

async function showVpsProfileInCard(ui, conn, targetDisplay) {
  const p=await readVpsProfile(conn,targetDisplay);
  await ui.setStatus('✅ SSH Terhubung! • VPS teridentifikasi',true);
  await ui.add('=== VPS INFO ===',{force:true});
  for(const [k,v] of Object.entries(p)){
    if(['target','error','warning'].includes(k)||!String(v||'').trim())continue;
    await ui.add(`${k.toUpperCase()} • ${v}`);
  }
  if(p.error) await ui.add(`VPS INFO WARNING • ${p.error}`,{stderr:true});
  return p;
}

const SSH_PROGRESS_LOGS = new Map();
async function editProgressOnly(bot, chatId, messageId, text) {
  try {
    const r = await bot.editMessageText(text, { chat_id: chatId, message_id: messageId, parse_mode: "HTML" });
    return r == null ? { ok:true, unchanged:true } : r;
  } catch (e) {
    const d=String(e?.response?.body?.description||e?.message||"");
    if (/message is not modified/i.test(d)) return {ok:true,unchanged:true};
    if (/429|too many requests/i.test(d)) return {ok:false,rateLimited:true};
    if (/message to edit not found|message can't be edited|there is no text in the message to edit/i.test(d)) return {ok:false,gone:true};
    console.warn('[progress-edit] skipped:', d.slice(0,180));
    return {ok:false,error:d};
  }
}
async function sshProgressEdit(bot, chatId, messageId, title, pct, stage, detail = "") {
  const fill = Math.max(0, Math.min(10, Math.round(pct / 10)));
  const key = `${chatId}:${messageId}:${title}`;
  const logs = SSH_PROGRESS_LOGS.get(key) || [];
  const cleanStage = String(stage || "").trim();
  if (cleanStage && logs[logs.length - 1] !== cleanStage) logs.push(cleanStage);
  while (logs.length > 4) logs.shift();
  SSH_PROGRESS_LOGS.set(key, logs);
  const liveLog = logs.length ? `

<b>LOG PROSES</b>
<pre>${escapeHTML(logs.map((x,i)=>`${i+1}. ${x}`).join("\n"))}</pre>` : "";
  const text = `<b>${escapeHTML(title)}</b>

<code>[${"█".repeat(fill)}${"░".repeat(10-fill)}] ${pct}%</code>
${escapeHTML(cleanStage)}${detail ? `

${detail}` : ""}${liveLog}`;
  const out = await editProgressOnly(bot, chatId, messageId, text);
  if (pct >= 100) setTimeout(() => SSH_PROGRESS_LOGS.delete(key), 30000);
  return out;
}


// ===== LIVE INSTALLER CARD (gaya rekaman referensi) =====
function createLiveInstallerCard(bot, chatId, messageId, options = {}) {
  const startedAt = Date.now();
  const state = { title:String(options.title||"PROSES INSTALL"), target:String(options.target||""), status:String(options.status||"Membangun koneksi SSH..."), stage:String(options.stage||""), percent:Number(options.percent)||0, lines:[], closed:false, renderTimer:null, heartbeat:null, lastRenderedAt:0, renderChain:Promise.resolve() };
  const stripAnsi = v => String(v||"").replace(/\x1B(?:[@-Z\\-_]|\[[0-?]*[ -\/]*[@-~])/g,"").replace(/\r/g,"");
  const elapsed = () => { const sec=Math.max(0,Math.floor((Date.now()-startedAt)/1000)); return `${String(Math.floor(sec/60)).padStart(2,"0")}:${String(sec%60).padStart(2,"0")}`; };
  const visibleTail = () => { const maxChars=2850, kept=[]; let total=0; for(let i=state.lines.length-1;i>=0;i--){const line=state.lines[i]; if(total+line.length+1>maxChars)break; kept.unshift(line); total+=line.length+1;} return kept; };
  const buildText = () => { const pct=Math.max(0,Math.min(100,Math.round(Number(state.percent)||0))), fill=Math.max(0,Math.min(10,Math.floor(pct/10))), logs=visibleTail(); return `<b>🚀 ${escapeHTML(state.title)}</b>\n`+(state.target?`<b>Target:</b> <code>${escapeHTML(state.target)}</code>\n`:"")+`<b>Status:</b> ${escapeHTML(state.status)}\n<b>⏱ ${elapsed()}</b>\n\n<code>[${"█".repeat(fill)}${"░".repeat(10-fill)}] ${pct}%</code>`+(state.stage?`\n<b>${escapeHTML(state.stage)}</b>`:"")+`\n\n<b>LIVE LOG</b>\n<pre>${escapeHTML(logs.length?logs.join("\n"):"Menunggu output proses...")}</pre>`; };
  const renderNow = async () => {
    if(state.closed)return;
    state.lastRenderedAt=Date.now();
    const text=buildText();
    // Jangan biarkan satu request Telegram yang macet (ECONNRESET/socket hang up)
    // membekukan seluruh renderChain. Setiap edit punya deadline sendiri.
    const editWithDeadline = async () => {
      let t;
      try {
        return await Promise.race([
          editProgressOnly(bot,chatId,messageId,text),
          new Promise((_,reject)=>{ t=setTimeout(()=>reject(new Error("TELEGRAM_EDIT_TIMEOUT")),7000); if(t.unref)t.unref(); })
        ]);
      } finally { if(t) clearTimeout(t); }
    };
    state.renderChain=state.renderChain.catch(()=>{}).then(editWithDeadline).catch(()=>{});
    await state.renderChain;
  };
  const scheduleRender = (force=false) => { if(state.closed)return Promise.resolve(); if(force){if(state.renderTimer)clearTimeout(state.renderTimer);state.renderTimer=null;return renderNow();} if(state.renderTimer)return Promise.resolve(); const wait=Math.max(0,900-(Date.now()-state.lastRenderedAt)); state.renderTimer=setTimeout(()=>{state.renderTimer=null;renderNow().catch(()=>{});},wait); return Promise.resolve(); };
  const addLines=(raw,{stderr=false,force=false}={})=>{const clean=stripAnsi(raw); for(const rawLine of clean.split(/\n/)){let line=rawLine.trimEnd(); if(!line.trim())continue; if(/^(?:LIANIX_STEP|THEME_STEP|PROTECT_STEP|THEME_OK|PROTECT_OK|INSTALL_OK)[:_]/i.test(line))continue; if(stderr&&!/^ERR\b/i.test(line))line=`ERR • ${line}`; if(line.length>360)line=line.slice(0,357)+"..."; state.lines.push(line);} while(state.lines.length>120)state.lines.shift(); return scheduleRender(force);};
  state.heartbeat = setInterval(() => { if (!state.closed) scheduleRender(false); }, 2000);
  return {
    setStatus(status,force=true){state.status=String(status||"");return scheduleRender(force);},
    setStage(stage,percent,force=true){if(stage!=null)state.stage=String(stage);if(Number.isFinite(Number(percent)))state.percent=Number(percent);return scheduleRender(force);},
    add(raw,opts){return addLines(raw,opts);},
    async flush(){await scheduleRender(true);},
    async close(){state.closed=true;if(state.renderTimer)clearTimeout(state.renderTimer);if(state.heartbeat)clearInterval(state.heartbeat);state.renderTimer=null;state.heartbeat=null;await state.renderChain.catch(()=>{});},
    get elapsed(){return elapsed();}
  };

}

// ===== ROBUST SSH SCRIPT TRANSPORT =====
// Menghindari ssh.exec() sebagai transport utama. Pada ssh2, callback channel/exec
// dapat tidak terpanggil ketika request channel kehilangan reply. Shell channel diberi
// watchdog SEBELUM callback, script dikirim bertahap dengan backpressure, dan output
// pertama wajib muncul dalam batas waktu.
function runLianixRemoteScript(conn, scriptText, options = {}) {
  const username = String(options.username || "root");
  const password = String(options.password || "");
  const onLine = typeof options.onLine === "function" ? options.onLine : async () => {};
  const openTimeoutMs = Number(options.openTimeoutMs || 12000);
  const firstOutputTimeoutMs = Number(options.firstOutputTimeoutMs || 15000);
  const maxRuntimeMs = Number(options.maxRuntimeMs || 30 * 60 * 1000);
  const maxCapture = Number(options.maxCapture || 2 * 1024 * 1024);

  return new Promise((resolve, reject) => {
    let settled = false, stream = null, gotOutput = false;
    let out = "", errOut = "", stdoutPending = "", stderrPending = "";
    let lineQueue = Promise.resolve();
    const finishReject = (err) => {
      if (settled) return;
      settled = true;
      clearTimeout(openTimer); clearTimeout(firstOutputTimer); clearTimeout(runtimeTimer);
      try { stream?.close(); } catch {}
      try { stream?.destroy(); } catch {}
      reject(err instanceof Error ? err : new Error(String(err)));
    };
    const openTimer = setTimeout(() => {
      finishReject(new Error("SSH_CHANNEL_OPEN_TIMEOUT: shell channel tidak memberikan callback dalam batas waktu."));
    }, openTimeoutMs);
    let firstOutputTimer = null;
    const runtimeTimer = setTimeout(() => {
      finishReject(new Error(`INSTALLER_RUNTIME_TIMEOUT: proses remote melewati batas ${Math.ceil(maxRuntimeMs/60000)} menit dan dihentikan agar tidak stuck.`));
    }, maxRuntimeMs);
    if (runtimeTimer.unref) runtimeTimer.unref();

    const pushLine = (raw, isErr = false) => {
      let line = String(raw || "").replace(/\x1b\[[0-9;?]*[ -\/]*[@-~]/g, "").replace(/\r/g, "").trimEnd();
      if (!line.trim()) return;
      lineQueue = lineQueue.then(() => onLine(line, isErr)).catch(() => {});
    };
    const consume = (chunk, isErr = false) => {
      gotOutput = true;
      if (firstOutputTimer) { clearTimeout(firstOutputTimer); firstOutputTimer = null; }
      let pending = (isErr ? stderrPending : stdoutPending) + String(chunk);
      const rows = pending.split(/\n/);
      pending = rows.pop() || "";
      if (isErr) stderrPending = pending; else stdoutPending = pending;
      for (const row of rows) pushLine(row, isErr);
    };
    const appendCapture = (chunk, isErr = false) => {
      if (isErr) { errOut += String(chunk); if (errOut.length > maxCapture) errOut = errOut.slice(-maxCapture); }
      else { out += String(chunk); if (out.length > maxCapture) out = out.slice(-maxCapture); }
      consume(chunk, isErr);
    };
    const writeChunks = async (channel, data) => {
      const buf = Buffer.from(String(data || ""));
      const CHUNK = 8192;
      for (let off = 0; off < buf.length; off += CHUNK) {
        const part = buf.subarray(off, Math.min(buf.length, off + CHUNK));
        if (!channel.write(part)) await new Promise((res, rej) => {
          const onDrain = () => { cleanup(); res(); };
          const onErr = e => { cleanup(); rej(e); };
          const cleanup = () => { channel.off("drain", onDrain); channel.off("error", onErr); };
          channel.once("drain", onDrain); channel.once("error", onErr);
        });
      }
    };

    // window=false => shell tanpa PTY. Ini menghindari echo script/password ke live log.
    conn.shell(false, (err, ch) => {
      clearTimeout(openTimer);
      if (err) return finishReject(new Error(`SSH_SHELL_OPEN_FAILED: ${err.message}`));
      stream = ch;
      firstOutputTimer = setTimeout(() => {
        if (gotOutput || settled) return;
        finishReject(new Error("INSTALLER_NO_OUTPUT: shell terbuka tetapi bash remote tidak mengeluarkan output dalam 15 detik."));
      }, firstOutputTimeoutMs);

      ch.on("data", d => appendCapture(d, false));
      if (ch.stderr) ch.stderr.on("data", d => appendCapture(d, true));
      ch.on("error", e => finishReject(e));
      ch.on("close", async (code, signal) => {
        if (settled) return;
        settled = true;
        clearTimeout(firstOutputTimer); clearTimeout(runtimeTimer);
        if (stdoutPending.trim()) pushLine(stdoutPending, false);
        if (stderrPending.trim()) pushLine(stderrPending, true);
        await lineQueue.catch(() => {});
        resolve({ out, errOut, code: Number.isInteger(code) ? code : (signal ? 128 : 0), signal });
      });

      (async () => {
        try {
          // Gunakan `exec` builtin shell agar tidak menyisakan shell induk.
          if (username === "root") {
            await writeChunks(ch, "exec bash -s\n");
          } else {
            await writeChunks(ch, "exec sudo -S -p '' bash -s\n");
            await writeChunks(ch, password + "\n");
          }
          // Marker ini berasal dari bash remote, bukan UI lokal. Kalau marker tidak
          // kembali, berarti script memang belum mulai dieksekusi.
          const payload = 'echo "LIANIX_REMOTE_CHANNEL_OK"\n' + String(scriptText || "") + "\n";
          await writeChunks(ch, payload);
          ch.end();
        } catch (e) { finishReject(e); }
      })();
    });
  });
}

// /ubahpwvps host|pwlama|pwbaru
// Aman: ubah password memakai chpasswd lokal, verifikasi dengan koneksi SSH BARU,
// dan rollback ke password lama bila autentikasi password baru gagal.
bot.onText(/^\/ubahpwvps(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  if (getUserRole(userId) !== "ceo" && userId !== ownerId) return bot.sendMessage(chatId, "✗ Khusus Owner/CEO!");

  const text = match?.[1]?.trim() || "";
  if (!text || text.split("|").length < 3) {
    return bot.sendMessage(chatId,
      "<b>PANDUAN UBAH PASSWORD VPS</b>\n\n" +
      "Gunakan: <code>/ubahpwvps host_target | password_lama | password_baru</code>\n\n" +
      "Host mendukung: <code>IP</code>, <code>IP:PORT</code>, <code>user@IP</code>, <code>user@IP:PORT</code>\n" +
      "Password baru diverifikasi lewat koneksi SSH kedua. Jika verifikasi gagal, Lianix mencoba rollback otomatis.",
      { parse_mode: "HTML" });
  }

  const parts = text.split("|");
  const targetRaw = parts.shift().trim();
  const pwLama = parts.shift().trim();
  const pwBaru = parts.join("|").trim(); // password baru boleh mengandung karakter |
  let target;
  try { target = parseSshTarget(targetRaw); }
  catch (e) { return bot.sendMessage(chatId, `✕ ${escapeHTML(e.message)}`, { parse_mode: "HTML" }); }

  if (!pwLama) return bot.sendMessage(chatId, "✕ Password lama kosong.");
  if (!pwBaru || pwBaru.length < 8) return bot.sendMessage(chatId, "✕ Password baru minimal 8 karakter.");
  if (pwBaru.length > 256) return bot.sendMessage(chatId, "✕ Password baru terlalu panjang (maksimal 256 karakter).");
  if (pwBaru === pwLama) return bot.sendMessage(chatId, "✕ Password baru harus berbeda dari password lama.");
  if (/[\x00-\x1f\x7f]/.test(pwBaru)) return bot.sendMessage(chatId, "✕ Password baru tidak boleh mengandung karakter kontrol/newline.");

  const procMsg = await bot.sendMessage(chatId, "<b>UBAH PASSWORD VPS</b>\n\n<code>[░░░░░░░░░░] 0%</code>\nMenyiapkan koneksi...", { parse_mode: "HTML" });
  await sshProgressEdit(bot, chatId, procMsg.message_id, "UBAH PASSWORD VPS", 15, "Tahap 1/5 • Menghubungkan SSH...", `<code>${escapeHTML(target.display)}</code>`);

  const conn = new Client();
  let settled = false;
  let overallTimer;
  const closeConn = () => { try { conn.end(); } catch {} };
  const finishError = async (message) => {
    if (settled) return;
    settled = true;
    clearTimeout(overallTimer);
    closeConn();
    await safeEdit(bot, chatId, procMsg.message_id, `✕ <b>UBAH PASSWORD VPS GAGAL</b>\n\n${escapeHTML(message)}`);
  };

  const changePassword = (oldForSudo, nextPassword) => new Promise((resolve, reject) => {
    // -k memaksa sudo meminta password sehingga stdin tidak bergeser saat sudo cache masih aktif.
    const cmd = target.username === "root" ? "chpasswd" : "sudo -k -S -p '' chpasswd";
    const t = setTimeout(() => reject(new Error("Timeout menjalankan chpasswd.")), 15000);
    conn.exec(cmd, (err, stream) => {
      if (err) { clearTimeout(t); return reject(err); }
      let errBuf = "";
      stream.stderr.on("data", d => errBuf += d.toString());
      stream.on("close", code => {
        clearTimeout(t);
        if (code === 0) resolve();
        else reject(new Error(errBuf.trim() || `chpasswd exit ${code}`));
      });
      const line = `${target.username}:${nextPassword}\n`;
      stream.end(target.username === "root" ? line : `${oldForSudo}\n${line}`);
    });
  });

  const verifyLogin = (password, attempts = 2) => new Promise((resolve, reject) => {
    let n = 0;
    const tryOnce = () => {
      n++;
      const test = new Client();
      let done = false;
      const timer = setTimeout(() => {
        if (done) return; done = true; try { test.end(); } catch {}
        if (n < attempts) return setTimeout(tryOnce, 700);
        reject(new Error("Timeout verifikasi login dengan password baru."));
      }, 12000);
      test.once("ready", () => {
        if (done) return; done = true; clearTimeout(timer);
        test.exec("printf LIANIX_PASSWORD_VERIFY_OK", (err, st) => {
          if (err) { try { test.end(); } catch {}; return resolve(true); } // auth sudah terverifikasi saat ready
          let out = "";
          st.on("data", d => out += d.toString());
          st.on("close", () => { try { test.end(); } catch {}; resolve(out.includes("LIANIX_PASSWORD_VERIFY_OK") || true); });
        });
      });
      test.once("error", err => {
        if (done) return; done = true; clearTimeout(timer); try { test.end(); } catch {}
        if (n < attempts) return setTimeout(tryOnce, 700);
        reject(err);
      });
      test.connect({ host: target.host, port: target.port, username: target.username, password, readyTimeout: 10000, keepaliveInterval: 5000, keepaliveCountMax: 2 });
    };
    tryOnce();
  });

  overallTimer = setTimeout(() => finishError("Timeout total 75 detik. Operasi dihentikan agar VPS tidak dibiarkan pada kondisi tidak pasti."), 75000);
  if (overallTimer.unref) overallTimer.unref();

  conn.once("ready", async () => {
    try {
      const vpsProfile = await readVpsProfile(conn, target.display);
      const vpsInfoHtml = formatVpsProfileHtml(vpsProfile);
      await sshProgressEdit(bot, chatId, procMsg.message_id, "UBAH PASSWORD VPS", 35, "Tahap 2/5 • SSH terhubung. Identitas VPS berhasil dibaca.", vpsInfoHtml);
      await sshProgressEdit(bot, chatId, procMsg.message_id, "UBAH PASSWORD VPS", 42, "Tahap 2/5 • Menjalankan perubahan password...", vpsInfoHtml);
      await changePassword(pwLama, pwBaru);

      await sshProgressEdit(bot, chatId, procMsg.message_id, "UBAH PASSWORD VPS", 65, "Tahap 3/5 • Password berubah. Menguji login baru...", vpsInfoHtml);
      try {
        await verifyLogin(pwBaru, 2);
      } catch (verifyErr) {
        await sshProgressEdit(bot, chatId, procMsg.message_id, "UBAH PASSWORD VPS", 75, "Tahap 4/5 • Verifikasi gagal. Melakukan rollback...", vpsInfoHtml);
        try {
          // Untuk user non-root, sudo sekarang memakai password BARU karena akun sudah berubah.
          await changePassword(pwBaru, pwLama);
          await verifyLogin(pwLama, 1).catch(() => {});
          return finishError(`Password baru tidak lolos verifikasi SSH dan sudah di-rollback ke password lama. Detail: ${verifyErr.message}`);
        } catch (rollbackErr) {
          return finishError(`KRITIS: password baru gagal diverifikasi dan rollback juga gagal. Jangan tutup sesi SSH yang masih aktif. Verifikasi manual akses VPS. Detail verifikasi: ${verifyErr.message}; rollback: ${rollbackErr.message}`);
        }
      }

      if (settled) return;
      clearTimeout(overallTimer);
      closeConn();
      const successText =
        `✓ <b>PASSWORD VPS BERHASIL DIGANTI</b>\n\n` +
        `Target: <code>${escapeHTML(target.display)}</code>\n` +
        `User: <code>${escapeHTML(target.username)}</code>\n` +
        `Status: <b>SUKSES</b>\n` +
        `Verifikasi: <b>login SSH dengan password baru berhasil</b>\n\n` +
        `${vpsInfoHtml}\n\n` +
        `<i>Password baru sengaja tidak ditampilkan ulang di chat.</i>`;
      let shown = false;
      let lastUiErr = null;
      for (let i = 0; i < 3 && !shown; i++) {
        try {
          await safeEdit(bot, chatId, procMsg.message_id, successText);
          shown = true;
        } catch (uiErr) {
          lastUiErr = uiErr;
          await sleep(500 * (i + 1));
        }
      }
      if (!shown) {
        try { await bot.sendMessage(chatId, successText, { parse_mode: "HTML" }); shown = true; }
        catch (sendErr) { lastUiErr = sendErr; }
      }
      settled = true;
      SSH_PROGRESS_LOGS.delete(`${chatId}:${procMsg.message_id}:UBAH PASSWORD VPS`);
      if (!shown) console.error("[ubahpwvps] password berhasil tetapi UI sukses gagal dikirim:", lastUiErr?.message || lastUiErr);
    } catch (e) {
      await finishError(e.message || String(e));
    }
  });
  conn.once("error", err => finishError(`Koneksi SSH gagal: ${err.message}`));
  conn.connect({ host: target.host, port: target.port, username: target.username, password: pwLama, readyTimeout: 20000, keepaliveInterval: 5000, keepaliveCountMax: 2 });
});

async function runUninstallPanel(chatId, ipRaw, port, password) {
  const statusMsg = await bot.sendMessage(chatId, `<b>UNINSTALL PANEL</b>\nMenghubungkan ke <code>${escapeHTML(ipRaw)}:${port}</code>...`, { parse_mode: 'HTML' });
  const conn = new Client();
  const safeCmd = `set -e
if command -v systemctl >/dev/null 2>&1; then
  systemctl stop pteroq 2>/dev/null || true
  systemctl stop pterodactyl 2>/dev/null || true
fi
rm -f /etc/systemd/system/pteroq.service
rm -f /etc/systemd/system/pterodactyl.service
rm -f /etc/systemd/system/pterodactyl-queue.service
rm -f /etc/systemd/system/pterodactyl-schedule.service
rm -f /etc/systemd/system/pterodactyl-worker.service
rm -f /etc/nginx/sites-enabled/pterodactyl.conf
rm -f /etc/nginx/sites-available/pterodactyl.conf
rm -rf /var/www/pterodactyl
rm -rf /etc/pterodactyl
if command -v mariadb >/dev/null 2>&1; then
  mariadb -Nse "SELECT User,Host FROM mysql.user WHERE User='pterodactyl'" 2>/dev/null | while read -r u h; do mariadb -e "DROP USER IF EXISTS '$u'@'$h';" 2>/dev/null || true; done
  mariadb -e "DROP DATABASE IF EXISTS panel;" 2>/dev/null || true
fi
systemctl daemon-reload 2>/dev/null || true
nginx -t 2>/dev/null && systemctl reload nginx 2>/dev/null || true
echo 'PTERODACTYL_PANEL_REMOVED'
`;
  conn.on('ready', () => {
    conn.exec(safeCmd, (err, stream) => {
      if (err) { conn.end(); return bot.editMessageText(`✕ Gagal menjalankan uninstall: ${escapeHTML(err.message)}`, { chat_id: chatId, message_id: statusMsg.message_id, parse_mode: 'HTML' }); }
      let out = '', errOut = '';
      stream.on('data', d => { out += d.toString(); });
      stream.stderr.on('data', d => { errOut += d.toString(); });
      stream.on('close', code => {
        conn.end();
        if (code === 0 && out.includes('PTERODACTYL_PANEL_REMOVED')) {
          return bot.editMessageText(`<b>✓ UNINSTALL PANEL SELESAI</b>\n\nTarget: <code>${escapeHTML(ipRaw)}:${port}</code>\nPanel Pterodactyl dan konfigurasi terkait sudah dihapus.\nSitus/config Nginx lain tidak disentuh.`, { chat_id: chatId, message_id: statusMsg.message_id, parse_mode: 'HTML' });
        }
        return bot.editMessageText(`<b>⚠ UNINSTALL PANEL SELESAI DENGAN WARNING</b>\n\nExit code: <code>${code}</code>\n<pre>${escapeHTML((errOut || out || 'Tidak ada output').slice(-7000))}</pre>`, { chat_id: chatId, message_id: statusMsg.message_id, parse_mode: 'HTML' });
      });
    });
  }).on('error', err => bot.editMessageText(
    `<b>✕ SSH GAGAL</b>\n\nTarget: <code>${escapeHTML(ipRaw)}:${port}</code>\nError: <code>${escapeHTML(err.message)}</code>\n\nPastikan password benar dan port SSH sesuai.`,
    { chat_id: chatId, message_id: statusMsg.message_id, parse_mode: 'HTML' }
  )).connect({ host: ipRaw, port, username: 'root', password, readyTimeout: 15000 });
}

// Button-first uninstall flow: the menu button asks for target credentials,
// then the existing confirmation buttons are used. No /uninstallpanel confirm command.
bot.on("message", async (msg) => {
  try {
    if (!msg?.text || !msg.reply_to_message) return;
    const marker = String(msg.reply_to_message.text || "");
    if (!marker.includes("LIANIX_UNINSTALL_PANEL_INPUT")) return;
    const chatId = msg.chat.id;
    const owners = loadJsonData(OWNER_FILE);
    if (!owners.includes(String(msg.from.id))) return;
    const parts = String(msg.text).trim().split("|");
    const ip = String(parts[0] || "").trim();
    const password = String(parts[1] || "").trim();
    const port = Number(parts[2] || DEFAULT_SSH_PORT);
    if (!isValidIP(ip) || !password || !Number.isInteger(port) || port < 1 || port > 65535) {
      return bot.sendMessage(chatId, "✕ Format salah. Kirim: IP|password|port\nContoh: 1.2.3.4|password|22");
    }
    global.__lianixUninstallConfirm = global.__lianixUninstallConfirm || new Map();
    const key = `${msg.from.id}:${ip}:${port}`;
    global.__lianixUninstallConfirm.set(key, { password, expires: Date.now() + 120000, chatId });
    return bot.sendMessage(chatId,
      `<b>UNINSTALL PANEL</b>\\n\\nTarget: <code>${escapeHTML(ip)}:${port}</code>\\n\\nIni akan menghapus Pterodactyl Panel, service panel, konfigurasi Pterodactyl dan database panel bila ditemukan. <b>File/situs Nginx lain tidak disentuh.</b>\\n\\nTekan tombol di bawah untuk melanjutkan.`,
      { parse_mode: "HTML", reply_markup: { inline_keyboard: [[
        { text: "✓ Ya, Uninstall Panel", callback_data: `uninstallpanel_confirm:${ip}:${port}` },
        { text: "✕ Batal", callback_data: `uninstallpanel_cancel:${ip}:${port}` }
      ]] } }
    );
  } catch (e) {
    console.error("uninstallpanel button flow:", e);
  }
});

bot.onText(/^\/uninstallpanel(?:\s+(.+))?$/, async (msg, match) => {
  notifyOwner('uninstallpanel', msg);
  const chatId = msg.chat.id;
  const text = String(match?.[1] || '').trim();
  const owners = loadJsonData(OWNER_FILE);
  if (!owners.includes(String(msg.from.id))) return bot.sendMessage(chatId, "✕ Kamu tidak memiliki akses owner.");
  if (!text) return bot.sendMessage(chatId, "✕ Format: /uninstallpanel ipvps|passwordvps|port\nPort boleh dikosongkan untuk memakai port SSH default.");

  const parts = text.split('|');
  const ip = String(parts[0] || '').trim();
  const password = String(parts[1] || '').trim();
  const port = Number(parts[2] || DEFAULT_SSH_PORT);
  if (!isValidIP(ip) || !password || !Number.isInteger(port) || port < 1 || port > 65535) {
    return bot.sendMessage(chatId, "✕ Format: /uninstallpanel ipvps|passwordvps|port\nContoh: /uninstallpanel 1.2.3.4|password|35641");
  }

  global.__lianixUninstallConfirm = global.__lianixUninstallConfirm || new Map();
  const key = `${msg.from.id}:${ip}:${port}`;
  global.__lianixUninstallConfirm.set(key, { password, expires: Date.now() + 120000, chatId });
  return bot.sendMessage(chatId,
    `<b>UNINSTALL PANEL</b>\n\nTarget: <code>${ip}:${port}</code>\n\nIni akan menghapus Pterodactyl Panel, service panel, konfigurasi Pterodactyl dan database panel bila ditemukan. <b>File/situs Nginx lain tidak disentuh.</b>\n\nTekan tombol di bawah untuk melanjutkan.`,
    { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '✓ Ya, Uninstall Panel', callback_data: `uninstallpanel_confirm:${ip}:${port}` }, { text: '✕ Batal', callback_data: `uninstallpanel_cancel:${ip}:${port}` }]] } }
  );
});

bot.on('callback_query', async (q) => {
  const data = String(q.data || '');
  if (!data.startsWith('uninstallpanel_')) return;
  const owners = loadJsonData(OWNER_FILE);
  if (!owners.includes(String(q.from.id))) return bot.answerCallbackQuery(q.id, { text: 'Khusus owner', show_alert: true });
  const m = data.match(/^uninstallpanel_(confirm|cancel):(.*):(\d+)$/);
  if (!m) return bot.answerCallbackQuery(q.id);
  const ip = m[2];
  const port = Number(m[3]);
  const key = `${q.from.id}:${ip}:${port}`;
  const pending = global.__lianixUninstallConfirm?.get(key);
  if (m[1] === 'cancel') {
    global.__lianixUninstallConfirm?.delete(key);
    await bot.answerCallbackQuery(q.id, { text: 'Dibatalkan' });
    return bot.editMessageText('<b>UNINSTALL PANEL</b>\n\n✕ Dibatalkan.', { chat_id: q.message.chat.id, message_id: q.message.message_id, parse_mode: 'HTML' });
  }
  if (!pending || pending.expires < Date.now()) return bot.answerCallbackQuery(q.id, { text: 'Konfirmasi sudah kedaluwarsa', show_alert: true });
  global.__lianixUninstallConfirm.delete(key);
  await bot.answerCallbackQuery(q.id, { text: 'Memulai uninstall...' });
  return runUninstallPanel(q.message.chat.id, ip, port, pending.password);
});

bot.onText(/^\/uninstallwings(?:\s+(.+))?$/, async (msg, match) => {
  notifyOwner('uninstallwings', msg);
  const chatId = msg.chat.id;
  const text = match[1];
  
  if (!text) {
    return bot.sendMessage(chatId, "✕ Format salah!\nContoh: /uninstallwings ip|password|port");
  }

  const owners = loadJsonData(OWNER_FILE);

  if (!owners.includes(msg.from.id.toString())) {
    return bot.sendMessage(chatId, "✕ Kamu tidak memiliki akses owner!!!");
  }
    
  const [ip, password, portRaw] = text.split("|").map(v => String(v || "").trim());
  const port = Number(portRaw || 22);
  if (!ip || !password || !Number.isInteger(port) || port < 1 || port > 65535) {
    return bot.sendMessage(chatId, "✕ Format salah!\nGunakan:\n`/uninstallwings ip|password|port`", { parse_mode: "Markdown" });
  }

  const conn = new Client();
  bot.sendMessage(chatId, `⚒ ᴍᴇɴɢʜᴜʙᴜɴɢᴋᴀɴ ᴋᴇ ᴠᴘꜱ *${ip}*...\nꜱᴇᴅᴀɴɢ ᴘʀᴏꜱᴇꜱ ᴜɴɪɴꜱᴛᴀʟʟ ᴡɪɴɢꜱ + ʀᴇꜱᴇᴛ ᴘᴏʀᴛ`, { parse_mode: "Markdown" });

  conn.on("ready", () => {
    // Aggregate Lianix egg manifests: one JSON for Node.js and one for Python.

  const script = `
systemctl stop wings
systemctl disable wings
rm -f /etc/systemd/system/wings.service
rm -f /usr/local/bin/wings
rm -rf /etc/pterodactyl
rm -rf /var/lib/pterodactyl
`;

    conn.exec(script, (err, stream) => {
      if (err) {
        conn.end();
        return bot.sendMessage(chatId, "✕ Gagal mengeksekusi perintah di VPS.");
      }

      stream.on("close", (code) => {
        conn.end();
        if (code === 0) {
          bot.sendMessage(chatId, `✓ *Wings berhasil dihapus dari VPS ${ip}*\n⟲ Port 8080 & 2022 juga dibersihkan.`, { parse_mode: "Markdown" });
        } else {
          bot.sendMessage(chatId, `⚠ Selesai dengan kode ${code}. Sebagian mungkin gagal. Periksa manual.`);
        }
      }).on("data", (data) => {
        console.log("STDOUT:", data.toString());
      }).stderr.on("data", (data) => {
        console.error("STDERR:", data.toString());
      });
    });
  }).on("error", (err) => {
    bot.sendMessage(chatId, `✕ Tidak bisa konek ke VPS:\n${err.message}`);
  }).connect({
    host: ip,
    port,
    username: "root",
    password: password,
    readyTimeout: 15000
  });
});

bot.onText(/^\/usrpanel(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  
  if (!text) {
    return bot.sendMessage(chatId, "✕ Format salah!\nContoh: /usrpanel ip|password");
  }

  if (!text.includes("|")) {
    return bot.sendMessage(chatId, "✕ Format salah!\nContoh: /usrpanel ipvps|password");
  }

  const [ip, password] = text.split("|");
  if (!ip || !password) {
    return bot.sendMessage(chatId, "✕ Format tidak valid.\nGunakan: /usrpanel ipvps|password");
  }

  const sshConfig = {
    host: ip,
    port: 22,
    username: "root",
    password: password.trim()
  };

  const conn = new Client();

  conn.on("ready", () => {
    conn.exec(
      'cd /var/www/pterodactyl && php artisan tinker --execute="print_r(Pterodactyl\\\\Models\\\\User::all([\'id\',\'username\',\'email\'])->toArray());"',
      (err, stream) => {
        if (err) {
          bot.sendMessage(chatId, "✕ Gagal eksekusi command.");
          return conn.end();
        }

        let output = "";
        stream.on("data", (data) => {
          output += data.toString();
        });

        stream.on("close", () => {
          conn.end();
          if (!output.trim()) {
            return bot.sendMessage(chatId, "✕ Tidak ada output dari server.");
          }

          if (output.length > 3500) {
            output = output.slice(0, 3500) + "\n... (dipotong)";
          }
          bot.sendMessage(chatId, "☰ Daftar User Panel\nOutput:\n```\n" + output + "\n```", {
            parse_mode: "Markdown"
          });
        });
      }
    );
  }).on("error", (err) => {
    bot.sendMessage(chatId, "✕ Gagal konek SSH: " + err.message);
  }).connect(sshConfig);
});

bot.onText(/^\/usrpasswd(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  
  if (!text) {
    return bot.sendMessage(chatId, "✕ Format salah!\nContoh: /usrpasswd ip|password");
  }

  const parts = text.split("|");
  if (parts.length < 4) {
    return bot.sendMessage(
      chatId,
      "✕ Format salah!\nContoh: /usrpasswd ipvps|passwordroot|iduser|passwordbaru"
    );
  }

  const [ip, rootPass, userId, newPass] = parts;

  const sshConfig = {
    host: ip,
    port: 22,
    username: "root",
    password: rootPass.trim()
  };

  const conn = new Client();

  conn.on("ready", () => {
    const cmd = `cd /var/www/pterodactyl && php artisan tinker --execute="if(Pterodactyl\\Models\\User::find(${userId})){ Pterodactyl\\Models\\User::find(${userId})->update(['password' => bcrypt('${newPass}')]); echo 'Password user ID ${userId} berhasil diubah'; } else { echo 'User tidak ditemukan'; }"`;

    conn.exec(cmd, (err, stream) => {
      if (err) {
        bot.sendMessage(chatId, "✕ Gagal eksekusi command.");
        return conn.end();
      }

      let output = "";
      stream.on("data", (data) => {
        output += data.toString();
      });

      stream.on("close", () => {
        conn.end();
        if (!output.trim()) output = "✕ Tidak ada respon dari server.";
        bot.sendMessage(chatId, "⚷ Output:\n```\n" + output.trim() + "\n```", {
          parse_mode: "Markdown"
        });
      });
    });
  }).on("error", (err) => {
    bot.sendMessage(chatId, "✕ Gagal konek SSH: " + err.message);
  }).connect(sshConfig);
});

// /clearall user&server panel
bot.onText(/^\/clearall (.+)$/, async (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;

    const params = match[1].split('|');
    if (params.length !== 2) {
        return bot.sendMessage(chatId, '✕ Format salah! Gunakan: /clearall ipvps|pwvps');
    }

    const [ipvps, pwvps] = params;

    try {
        const processingMsg = await bot.sendMessage(chatId, '⟳ ᴍᴇᴍᴘʀᴏꜱᴇꜱ ᴄʟᴇᴀʀ ᴀʟʟ...');

        // koneksi SSH
        const conn = new Client();
        let sshOutput = '';

        conn.on('ready', () => {
            console.log('SSH Connection Ready');
            
            const cmd = `cd /var/www/pterodactyl && php artisan tinker --execute="DB::statement('SET FOREIGN_KEY_CHECKS=0;'); \\\\Pterodactyl\\\\Models\\\\User::truncate(); \\\\Pterodactyl\\\\Models\\\\Server::truncate(); DB::statement('SET FOREIGN_KEY_CHECKS=1;'); echo 'Clear all berhasil dilakukan!';"`;
            
            conn.exec(cmd, (err, stream) => {
                if (err) {
                    bot.editMessageText(`✕ SSH Error: ${err.message}`, {
                        chat_id: chatId,
                        message_id: processingMsg.message_id
                    });
                    return conn.end();
                }
                
                stream.on('close', (code, signal) => {
                    console.log('Stream closed');
                    conn.end();
                    
                    bot.editMessageText(`✓ Sukses clear all User & Server!
ᴏᴜᴛᴘᴜᴛ:
\`\`\`
${sshOutput || 'Tidak ada output'}
\`\`\`
`, {
                        chat_id: chatId,
                        parse_mode: "Markdown",
                        message_id: processingMsg.message_id
                    });
                }).on('data', (data) => {
                    sshOutput += data.toString();
                }).stderr.on('data', (data) => {
                    sshOutput += data.toString();
                });
            });
        });

        conn.on('error', (err) => {
            console.error('SSH Connection Error:', err);
            bot.editMessageText(`✕ SSH Connection Error: ${err.message}`, {
                chat_id: chatId,
                message_id: processingMsg.message_id
            });
        });

        conn.on('end', () => {
            console.log('SSH Connection Ended');
        });

        // Connect to SSH
        conn.connect({
            host: ipvps,
            port: 22,
            username: 'root',
            password: pwvps
        });

    } catch (error) {
        console.error('Error:', error);
        bot.sendMessage(chatId, `✕ Terjadi error: ${error.message}`);
    }
});

const { Client } = require("ssh2")

bot.onText(/^\/datavps (.+)/, async (msg, match) => {

  const chatId = msg.chat.id
  const input = match[1]

  if (!input.includes("|")) {
    return bot.sendMessage(chatId,
`✕ Format salah

Gunakan:
/datavps ip|password|port`)
  }

  const parts = input.split("|")

  const ip = parts[0].trim()
  const password = parts[1].trim()
  const port = parts[2] ? parseInt(parts[2].trim()) : 22

  bot.sendMessage(chatId,"⌕ Mengambil informasi VPS...")

  getVpsData(chatId, ip, password, port)

})


// ================= FUNCTION =================
function getVpsData(chatId, ip, password, port, messageId = null) {

  const conn = new Client()

  conn.on("ready", () => {

    const cmd = `
echo "RUNTIME: $(uptime -p)"
echo "LOAD: $(uptime | awk -F'load average:' '{print $2}')"

echo "RAM_TOTAL: $(free -g | awk '/Mem:/ {print $2}')"
echo "RAM_USED: $(free -g | awk '/Mem:/ {print $3}')"

echo "CORE: $(nproc)"
echo "CPU_USAGE: $(top -bn1 | grep "Cpu(s)" | awk '{print 100 - $8}')"

echo "DISK_TOTAL: $(df -h / | awk 'NR==2 {print $2}')"
echo "DISK_USED: $(df -h / | awk 'NR==2 {print $3}')"
echo "DISK_FREE: $(df -h / | awk 'NR==2 {print $4}')"

echo "OS: $(hostnamectl | grep 'Operating System' | cut -d ':' -f2)"
echo "KERNEL: $(uname -r)"

echo "SSH_PORT: $(ss -tulnp | grep sshd | grep LISTEN | awk -F':' '{print $2}' | awk '{print $1}')"

echo "WINGS_STATUS: $(systemctl is-active wings 2>/dev/null)"

echo "DOMAIN_NGINX: $(grep server_name /etc/nginx/sites-enabled/* 2>/dev/null | awk '{print $2}' | tr -d ';' | tr '\\n' ',')"
echo "DOMAIN_APACHE: $(grep ServerName /etc/apache2/sites-enabled/* 2>/dev/null | awk '{print $2}' | tr '\\n' ',')"
`

    conn.exec(cmd,(err,stream)=>{

      if (err) return conn.end()

      let output=""

      stream.on("data",(d)=> output += d.toString())

      stream.on("close",()=>{

        let info={}
        output.trim().split("\n").forEach(line=>{
          const [k,...v]=line.split(":")
          info[k.trim()] = v.join(":").trim()
        })

        const fix = v => (!v || v==="0" || v==="0G") ? "-" : v

        // ===== DOMAIN BLUR =====
        const rawDomain =
          [info.DOMAIN_NGINX,info.DOMAIN_APACHE]
          .filter(Boolean)
          .join(",")
          .replace(/,+/g,",")
          .replace(/,$/,"")

        const domain = rawDomain
          ? rawDomain.split(",").map(d => `<tg-spoiler>${d}</tg-spoiler>`).join(", ")
          : "-"

        const wings =
          info.WINGS_STATUS === "active"
          ? "● Aktif"
          : "○ Tidak Aktif"

        // ===== HTML KUTIP =====
        const text = `
<blockquote><b>⌂ INFO VPS</b>

<b>⟐ IP</b>
<code>${ip}</code>

<b>▭ System</b>
OS: ${fix(info.OS)}
Kernel: ${fix(info.KERNEL)}
Runtime: ${fix(info.RUNTIME)}
Load: ${fix(info.LOAD)}

<b>⟡ RAM</b>
Total: ${fix(info.RAM_TOTAL)} GB
Used: ${fix(info.RAM_USED)} GB

<b>⊙ CPU</b>
Core: ${fix(info.CORE)}
Usage: ${fix(parseFloat(info.CPU_USAGE || 0).toFixed(1))}%

<b>⌗ Disk</b>
Total: ${fix(info.DISK_TOTAL)}
Used: ${fix(info.DISK_USED)}
Free: ${fix(info.DISK_FREE)}

<b>⚿ SSH</b>
Port: ${fix(info.SSH_PORT)}

<b>⌖ Wings</b>
${wings}

<b>⟐ Domain</b>
${domain}
</blockquote>
`.trim()

        const keyboard = {
          inline_keyboard: [
            [
              {
                text: "⟳ Refresh",
                callback_data: `refresh|${ip}|${password}|${port}`
              }
            ]
          ]
        }

        if (messageId) {
          bot.editMessageText(text, {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: "HTML",
            reply_markup: keyboard
          })
        } else {
          bot.sendMessage(chatId, text, {
            parse_mode: "HTML",
            reply_markup: keyboard
          })
        }

        conn.end()

      })

    })

  })

  conn.connect({
    host: ip,
    port: port,
    username: "root",
    password: password
  })

}


// ================= REFRESH =================
bot.on("callback_query", (query) => {

  if (!query.data.startsWith("refresh")) return

  const [_, ip, password, port] = query.data.split("|")

  bot.answerCallbackQuery(query.id, { text: "⟳ Refreshing..." })

  getVpsData(
    query.message.chat.id,
    ip,
    password,
    parseInt(port),
    query.message.message_id
  )

})
bot.onText(/^\/refreshvps(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const input = match[1];

  if (!input) {
    return bot.sendMessage(
      chatId,
      "✕ Cara penggunaan: /refreshvps ip|password"
    );
  }

  if (!input.includes("|")) {
    return bot.sendMessage(
      chatId,
      "✕ Cara penggunaan: /refreshvps ip|password"
    );
  }

  const [ip, password] = input.split("|").map(a => a.trim());

  const conn = new Client();
  bot.sendMessage(chatId, `⟳ Memproses clear cache VPS`, { reply_to_message_id: msg.message_id });

  conn.on("ready", () => {
    conn.exec(
      `cd /var/www/pterodactyl && php artisan config:clear && php artisan route:clear && php artisan view:clear && php artisan cache:clear && php artisan optimize`,
      (err, stream) => {
        if (err) {
          bot.sendMessage(chatId, `✕ Error eksekusi command: ${err.message}`);
          conn.end();
          return;
        }

        let output = "";
        stream.on("data", (data) => { output += data.toString(); });
        stream.stderr.on("data", (data) => { output += data.toString(); });

        stream.on("close", () => {
          bot.sendMessage(chatId, `✓ Refresh VPS selesai!`, {
            parse_mode: "Markdown",
            reply_to_message_id: msg.message_id
          });
          conn.end();
        });
      }
    );
  })

  .connect({
    host: ip,
    port: 22,
    username: "root",
    password: password
  });

  conn.on("error", (err) => {
    bot.sendMessage(chatId, `✕ Gagal konek ke VPS: ${err.message}`);
  });
});
bot.onText(/^\/spekvps (.+)$/, async (msg, match) => {
    const chatId = msg.chat.id;
    const userInput = match[1].trim();

    if (!userInput.includes("|")) {
        return bot.sendMessage(chatId, "✕ Cara penggunaan: /spekvps ip|password");
    }

    const [host, password] = userInput.split("|").map(a => a.trim());
    const username = "root";

    bot.sendMessage(chatId, "⚡ Menghubungkan ke VPS...");

    const conn = new Client();
    conn
        .on("ready", () => {
            const commands = [
                "echo '=== CPU Info ===' && lscpu | grep 'Model name'",
                "echo '=== Core Count ===' && nproc",
                "echo '=== RAM ===' && free -m | awk 'NR==2{print $2\" MB Total, \"$3\" MB Used, \"$4\" MB Free\"}'",
                "echo '=== Disk ===' && df -h --total | grep total",
                "echo '=== OS ===' && lsb_release -a 2>/dev/null || cat /etc/os-release | grep PRETTY_NAME",
                "echo '=== Kernel ===' && uname -r",
                "echo '=== Uptime ===' && uptime -p"
            ];

            conn.exec(commands.join(" && echo '---' && "), (err, stream) => {
                if (err) return bot.sendMessage(chatId, "✕ Error eksekusi perintah: " + err.message);

                let output = "";
                stream.on("data", (data) => output += data.toString());

                stream.on("close", () => {
                    bot.sendMessage(chatId, "⌗ Spesifikasi VPS:\n\n```\n" + output + "\n```", {
                        parse_mode: "Markdown",
                        reply_to_message_id: msg.message_id
                    });
                    conn.end();
                });
            });
        })
        .on("error", (err) => {
            bot.sendMessage(chatId, "✕ Gagal koneksi: " + err.message);
        })
        .connect({
            host,
            port: 22,
            username,
            password,
        });
});
bot.onText(/^\/cpuvps (.+)$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1].trim();

  if (!text.includes("|")) {
    return bot.sendMessage(chatId, "✕ Cara penggunaan: /cpuvps ip|password");
  }

  const [ip, password] = text.split("|").map(a => a.trim());

  bot.sendMessage(chatId, `⟳ Mengecek CPU VPS *${ip}*...`, { parse_mode: "Markdown" });

  const conn = new Client();
  conn
    .on("ready", () => {
      conn.exec("top -bn1 | grep 'Cpu(s)'", (err, stream) => {
        if (err) {
          bot.sendMessage(chatId, `✕ Gagal eksekusi command di ${ip}`);
          conn.end();
          return;
        }

        let data = "";
        stream.on("data", (chunk) => data += chunk.toString());

        stream.on("close", () => {
          conn.end();

          const matchCpu = data.match(/(\d+\.\d+)\s*id/);
          if (matchCpu) {
            const idle = parseFloat(matchCpu[1]);
            const used = (100 - idle).toFixed(2);

            bot.sendMessage(chatId, `⌗ Total CPU VPS: *${used}%*`, {
              parse_mode: "Markdown",
              reply_to_message_id: msg.message_id
            });
          } else {
            bot.sendMessage(chatId, `⚠ Gagal parsing data CPU dari VPS *${ip}*`);
          }
        });
      });
    })
    .on("error", (err) => {
      bot.sendMessage(chatId, `✕ Gagal koneksi ke VPS *${ip}*\nPesan: ${err.message}`, { parse_mode: "Markdown" });
    })
    .connect({
      host: ip,
      port: 22,
      username: "root",
      password,
    });
});
bot.onText(/^\/clearstorage(?:\s+(.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const input = match && match[1] ? match[1].trim() : "";

  if (!input) {
    return bot.sendMessage(chatId,
      "✕ Format salah!\nContoh:\n/clearstorage ipvps|pwvps",
      { parse_mode: "Markdown" }
    );
  }

  const parts = input.split("|");
  if (parts.length < 2) {
    return bot.sendMessage(chatId,
      "✕ Format salah!\nContoh:\n/clearstorage ipvps|pwvps",
      { parse_mode: "Markdown" }
    );
  }

  const ipvps = parts[0].trim();
  const pwvps = parts[1].trim();

  const conn = new Client();
  let output = "";
  let stderr = "";

  conn.on("ready", () => {
    bot.sendMessage(chatId, `➤ Membersihkan storage di VPS: ${ipvps}`);
    conn.exec(
      `docker stop $(docker ps -aq) >/dev/null 2>&1 || true && \
docker system prune -af --volumes && \
rm -rf /var/lib/docker/containers/*/*-json.log || true && \
df -h`,
      (err, stream) => {
        if (err) {
          bot.sendMessage(chatId, "✕ Error eksekusi perintah");
          conn.end();
          return;
        }

        stream.on("data", (data) => {
          output += data.toString();
        });

        stream.stderr.on("data", (data) => {
          stderr += data.toString();
        });

        stream.on("close", (code, signal) => {
          let combined = "";
          if (output) combined += output;
          if (stderr) combined += "\n\nSTDERR:\n" + stderr;

          const safeOutput = combined.length > 3900
            ? combined.slice(0, 3900) + "\n\n... (dipotong)"
            : combined || "Tidak ada output.";

          bot.sendMessage(
            chatId,
            `<b>✓ Storage dibersihkan di VPS ${ipvps}</b>\n\n⌗ Sisa storage VPS:\n<pre>${safeOutput}</pre>\n\n<b>Exit code:</b> ${code}, <b>Signal:</b> ${signal}`,
            { parse_mode: "HTML" }
          ).catch(() => {});

          conn.end();
        });
      }
    );
  });

  conn.on("error", (err) => {
    bot.sendMessage(chatId, `✕ Gagal terkoneksi ke VPS ${ipvps}\nError: ${err.message}`);
  });

  conn.on("end", () => {
    console.log(`SSH connection to ${ipvps} ended`);
  });

  conn.on("timeout", () => {
    bot.sendMessage(chatId, `✕ Koneksi ke VPS ${ipvps} timeout`);
    conn.end();
  });

  try {
    conn.connect({
      host: ipvps,
      port: 22,
      username: "root",
      password: pwvps,
      readyTimeout: 20000
    });
  } catch (e) {
    bot.sendMessage(chatId, `✕ Terjadi error saat mencoba koneksi: ${e.message}`);
  }
});
bot.onText(/^\/swings(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from?.id;
  if (userId !== ownerId && getUserRole(userId) !== "ceo") return bot.sendMessage(chatId, "✗ Khusus Owner/CEO!");
  const text = match?.[1]?.trim() || "";
  const parts = text.split("|");
  if (!text || parts.length < 3) {
    return bot.sendMessage(chatId, `<blockquote>✕ Format salah!\nGunakan: <code>/swings host_target | password_vps | token/configure_command_node</code>\n\nCommand konfigurasi dijalankan maksimal 3 menit lalu service Wings diverifikasi aktif.</blockquote>`, { parse_mode: "HTML" });
  }
  const targetRaw = parts.shift().trim();
  const password = parts.shift().trim();
  const configureCommand = parts.join("|").trim();
  if (!password || !configureCommand) return bot.sendMessage(chatId, "✕ Password atau token/configure command kosong.");
  let target; try { target = parseSshTarget(targetRaw); } catch (e) { return bot.sendMessage(chatId, `✕ ${escapeHTML(e.message)}`, { parse_mode:"HTML" }); }
  const sent = await bot.sendMessage(chatId, `<b>CONFIGURE WINGS</b>\n\n<code>[░░░░░░░░░░] 0%</code>\nMenyiapkan koneksi...`, { parse_mode:"HTML" });
  const ui = createLiveInstallerCard(bot, chatId, sent.message_id, { title:"CONFIGURE WINGS", target:target.display, status:"Membangun koneksi SSH...", stage:"Persiapan", percent:0 });
  await ui.flush();
  const ssh = new Client(); let done = false;
  const timer = setTimeout(async()=>{ if(done)return; done=true; try{ssh.end()}catch{}; await ui.close(); await safeEdit(bot,chatId,sent.message_id,"✕ <b>CONFIGURE WINGS GAGAL</b>\n\nTimeout total 4 menit. Proses dihentikan agar tidak stuck.").catch(()=>{}); }, 4*60*1000);
  if (timer.unref) timer.unref();
  ssh.once("ready", async () => {
    try {
      await ui.setStatus("✅ SSH Terhubung! • Mengonfigurasi Wings...", true);
      await ui.setStage("Tahap 1/4 • Validasi Wings & Docker", 20, true);
      const script = `set -Eeuo pipefail
trap 'rc=$?; echo "SWINGS_FATAL:exit=$rc line=\${BASH_LINENO[0]:-?}" >&2' ERR
command -v wings >/dev/null 2>&1 || { echo WINGS_BINARY_NOT_FOUND; exit 31; }
command -v docker >/dev/null 2>&1 || { echo DOCKER_NOT_FOUND; exit 32; }
systemctl is-active --quiet docker || { echo DOCKER_NOT_ACTIVE; exit 33; }
echo SWINGS_STEP_2
cd /etc/pterodactyl
CONFIG_CMD=${shellQuote(configureCommand)}
timeout 180 bash -lc "$CONFIG_CMD"
echo SWINGS_STEP_3
test -s /etc/pterodactyl/config.yml || { echo WINGS_CONFIG_NOT_CREATED; exit 34; }
timeout 30 systemctl daemon-reload
timeout 30 systemctl enable wings >/dev/null 2>&1 || true
timeout 45 systemctl restart wings
sleep 3
systemctl is-active --quiet wings || { systemctl status wings --no-pager -l || true; journalctl -u wings -n 80 --no-pager || true; echo WINGS_SERVICE_NOT_ACTIVE; exit 35; }
echo SWINGS_STEP_4
/usr/local/bin/wings version 2>/dev/null || wings version 2>/dev/null || true
echo SWINGS_OK`;
      const result = await runLianixRemoteScript(ssh, script, { username:target.username, password, maxRuntimeMs:3.5*60*1000, onLine:async(row,isErr)=>{
        if(row.includes("SWINGS_STEP_2")) await ui.setStage("Tahap 2/4 • Menjalankan konfigurasi node",45,true);
        else if(row.includes("SWINGS_STEP_3")) await ui.setStage("Tahap 3/4 • Restart & cek service Wings",75,true);
        else if(row.includes("SWINGS_STEP_4")) await ui.setStage("Tahap 4/4 • Verifikasi akhir",92,true);
        else if(row!=="LIANIX_REMOTE_CHANNEL_OK" && row!=="SWINGS_OK") await ui.add(row,{stderr:isErr});
      }});
      const combined = `${result.out||""}\n${result.errOut||""}`;
      if (result.code !== 0 || !combined.includes("SWINGS_OK")) throw new Error(result.errOut?.trim() || result.out?.trim() || `Exit ${result.code}`);
      done=true; clearTimeout(timer); try{ssh.end()}catch{}; await ui.setStage("Tahap 4/4 • Wings aktif dan terverifikasi",100,true); await ui.close();
      return safeEdit(bot,chatId,sent.message_id,`✓ <b>WINGS BERHASIL DIKONFIGURASI</b>\n\nTarget: <code>${escapeHTML(target.display)}</code>\nService Wings: <b>ACTIVE</b>\nConfig: <code>/etc/pterodactyl/config.yml</code>`);
    } catch (e) {
      if(done)return; done=true; clearTimeout(timer); try{ssh.end()}catch{}; await ui.close();
      return safeEdit(bot,chatId,sent.message_id,`✕ <b>CONFIGURE WINGS GAGAL</b>\n\n${escapeHTML(String(e?.message||e)).slice(0,1800)}`).catch(()=>{});
    }
  });
  ssh.once("error", async e=>{ if(done)return; done=true; clearTimeout(timer); await ui.close(); await safeEdit(bot,chatId,sent.message_id,`✕ <b>CONFIGURE WINGS GAGAL</b>\n\nKoneksi SSH: ${escapeHTML(e.message)}`).catch(()=>{}); });
  ssh.connect({ host:target.host, port:target.port, username:target.username, password, readyTimeout:20000, keepaliveInterval:5000, keepaliveCountMax:3 });
});
function generateReadableString(length = 4) {
  const chars = "abcdefghijklmnopqrstuvwxyz0123456789";
  let res = "";
  for (let i = 0; i < length; i++) {
    res += chars[Math.floor(Math.random() * chars.length)];
  }
  return res;
}

// ===== THEME INSTALLER =====
// Daftar tema, dikunci ke zip yang memang disediakan untuk produk ini.
const THEME_LIST = {
  "1": { name: "Stellar", url: "https://raw.githubusercontent.com/PJRstrike/installerBashhbyviolezx/main/theme/stellar.zip" },
  "2": { name: "Billing", url: "https://raw.githubusercontent.com/PJRstrike/installerBashhbyviolezx/main/theme/billing.zip" },
  "3": { name: "Enigma", url: "https://raw.githubusercontent.com/PJRstrike/installerBashhbyviolezx/main/theme/enigma.zip" },
  "4": { name: "Elysium", url: "https://raw.githubusercontent.com/PJRstrike/installerBashhbyviolezx/main/theme/elysium.zip" },
  "5": { name: "Frostcore", url: "https://raw.githubusercontent.com/PJRstrike/installerBashhbyviolezx/main/theme/frostcore.zip" },
  "6": { name: "Nightcore", url: "https://raw.githubusercontent.com/PJRstrike/installerBashhbyviolezx/main/theme/nightcore.zip" },
  "7": { name: "IceMinecraft", url: "https://raw.githubusercontent.com/PJRstrike/installerBashhbyviolezx/main/theme/iceMinecraft.zip" },
  "8": { name: "Noobe", url: "https://raw.githubusercontent.com/PJRstrike/installerBashhbyviolezx/main/theme/noobe.zip" },
  "b1": { name: "Nebula V1.8-3", url: "https://raw.githubusercontent.com/PJRstrike/installerBashhbyviolezx/main/theme/nebula_v1.8-3.zip" },
  "b2": { name: "Nebula V2.0-1", url: "https://raw.githubusercontent.com/PJRstrike/installerBashhbyviolezx/main/theme/nebula_v2.0-1.zip" },
  "b3": { name: "Recolor", url: "https://raw.githubusercontent.com/PJRstrike/installerBashhbyviolezx/main/theme/recolor.zip" },
  "b4": { name: "NavySeals", url: "https://raw.githubusercontent.com/PJRstrike/installerBashhbyviolezx/main/theme/navyseals.zip" },
  "b5": { name: "LememTheme", url: "https://raw.githubusercontent.com/PJRstrike/installerBashhbyviolezx/main/theme/lemem.zip" },
  "b6": { name: "Darkenate", url: "https://raw.githubusercontent.com/PJRstrike/installerBashhbyviolezx/main/theme/darkenate.zip" },
  "b7": { name: "AbyssPurple", url: "https://raw.githubusercontent.com/PJRstrike/installerBashhbyviolezx/main/theme/abysspurple.zip" },
};

function themeMenuText() {
  let t = "<blockquote><b>⟡ Pilih tema panel</b>\n\n";
  t += "Ketik: <code>/installtheme ipvps|pwvps|kode_tema</code>\n\n";
  t += "<b>Kode tema:</b>\n";
  for (const [code, theme] of Object.entries(THEME_LIST)) {
    t += `• <code>${code}</code> - ${escapeHTML(theme.name)}\n`;
  }
  t += "\nContoh: <code>/installtheme 1.2.3.4|passwordvps|3</code></blockquote>";
  return t;
}

bot.onText(/^\/installtheme_legacy_disabled(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  const role = getUserRole(userId);
  if (userId !== ownerId && role !== "ceo") {
    return bot.sendMessage(chatId, "⟡ Maaf, fitur install tema ini khusus untuk role CEO ya.");
  }

  return bot.sendMessage(
    chatId,
    `⚠ <b>Command /installtheme dinonaktifkan.</b>\n\n` +
    `Command ini men-download file .zip tema dari repository pihak ketiga (bukan milik kita), ` +
    `lalu kalau isinya ada install.sh, dijalankan sebagai root di VPS — pola yang sama dengan ` +
    `backdoor yang sudah ditemukan di fitur protect. Karena isinya belum direview, fitur ini dimatikan ` +
    `sampai sumber temanya diganti dengan sumber tepercaya/dihosting sendiri.`,
    { parse_mode: "HTML" }
  );
  // eslint-disable-next-line no-unreachable
  const text = match && match[1] ? match[1].trim() : "";
  if (!text || text.split("|").length < 3) {
    return bot.sendMessage(chatId, themeMenuText(), { parse_mode: "HTML" });
  }

  const [vpsIP, vpsPassword, rawCode] = text.split("|").map(v => v.trim());
  const code = rawCode.toLowerCase();
  const theme = THEME_LIST[code];

  if (!theme) {
    return bot.sendMessage(
      chatId,
      `<blockquote>✕ Kode tema <code>${escapeHTML(rawCode)}</code> tidak ditemukan.</blockquote>\n\n` + themeMenuText(),
      { parse_mode: "HTML" }
    );
  }

  const statusMsg = await bot.sendMessage(
    chatId,
    `<blockquote>⏳ <b>Menginstall tema ${escapeHTML(theme.name)}...</b>\nMenghubungkan ke ${escapeHTML(vpsIP)}</blockquote>`,
    { parse_mode: "HTML" }
  );

  const conn = new Client();

  // Cari folder panel, backup file lama, lalu terapkan tema baru.
  // Kalau tema punya install.sh sendiri di dalam zip, itu yang dipakai;
  // kalau tidak, kontennya ditimpakan langsung ke folder panel (dengan backup dulu).
  const cmd = `
set -e
export DEBIAN_FRONTEND=noninteractive
command -v unzip >/dev/null 2>&1 || (apt-get update -y >/dev/null 2>&1; apt-get install -y unzip >/dev/null 2>&1)

DIR="/var/www/pterodactyl"
if [ ! -d "$DIR" ]; then
  DIR=$(find /var -maxdepth 3 -type d -name "pterodactyl" | head -n 1)
fi

if [ -z "$DIR" ] || [ ! -d "$DIR" ]; then
  echo "THEME_ERROR_NO_PANEL_DIR"
  exit 0
fi

WORKDIR=$(mktemp -d)
cd "$WORKDIR"
curl -fsSL "${theme.url}" -o theme.zip || { echo "THEME_ERROR_DOWNLOAD"; exit 0; }
unzip -oq theme.zip -d extracted || { echo "THEME_ERROR_UNZIP"; exit 0; }

BACKUP_DIR="$DIR/theme_backup_$(date +%s)"
mkdir -p "$BACKUP_DIR"
[ -d "$DIR/public/themes" ] && cp -a "$DIR/public/themes" "$BACKUP_DIR/" 2>/dev/null || true
[ -d "$DIR/resources/views" ] && cp -a "$DIR/resources/views" "$BACKUP_DIR/" 2>/dev/null || true

SRC="extracted"
INNER=$(find extracted -maxdepth 1 -mindepth 1 -type d | head -n 1)
[ -n "$INNER" ] && [ -z "$(find extracted -maxdepth 1 -mindepth 1 ! -path "$INNER")" ] && SRC="$INNER"

if [ -f "$SRC/install.sh" ]; then
  cd "$SRC"
  chmod +x install.sh
  bash install.sh || { echo "THEME_ERROR_CUSTOM_INSTALL"; exit 0; }
else
  cp -rf "$SRC"/. "$DIR"/ 2>/dev/null || { echo "THEME_ERROR_COPY"; exit 0; }
fi

cd "$DIR"
php artisan view:clear >/dev/null 2>&1 || true
php artisan config:clear >/dev/null 2>&1 || true
php artisan queue:restart >/dev/null 2>&1 || true
chown -R www-data:www-data "$DIR" >/dev/null 2>&1 || true

echo "THEME_INSTALL_SUCCESS"
`;

  let finished = false;
  let output = "";

  conn.on("ready", () => {
    conn.exec(cmd, (err, stream) => {
      if (err) {
        finished = true;
        conn.end();
        return bot.editMessageText(
          `<blockquote>✕ Gagal menjalankan instalasi tema.</blockquote>`,
          { chat_id: chatId, message_id: statusMsg.message_id, parse_mode: "HTML" }
        );
      }

      stream.on("data", d => (output += d.toString()));
      stream.stderr.on("data", d => (output += d.toString()));

      stream.on("close", async () => {
        finished = true;
        conn.end();

        if (output.includes("THEME_INSTALL_SUCCESS")) {
          await bot.editMessageText(
            `<blockquote>✓ <b>Tema ${escapeHTML(theme.name)} berhasil dipasang!</b>\nSilakan cek panel di ${escapeHTML(vpsIP)}.</blockquote>`,
            { chat_id: chatId, message_id: statusMsg.message_id, parse_mode: "HTML" }
          );
        } else {
          const reason = output.includes("THEME_ERROR_NO_PANEL_DIR") ? "Folder panel Pterodactyl tidak ditemukan di VPS ini."
            : output.includes("THEME_ERROR_DOWNLOAD") ? "Gagal mengunduh file tema."
            : output.includes("THEME_ERROR_UNZIP") ? "File tema gagal diekstrak (zip rusak/tidak valid)."
            : output.includes("THEME_ERROR_CUSTOM_INSTALL") ? "Script instalasi bawaan tema gagal dijalankan."
            : output.includes("THEME_ERROR_COPY") ? "Gagal menyalin file tema ke folder panel."
            : "Terjadi kendala saat instalasi, silakan coba lagi.";

          await bot.editMessageText(
            `<blockquote>⚠ <b>Instalasi tema belum selesai</b>\n${escapeHTML(reason)}</blockquote>`,
            { chat_id: chatId, message_id: statusMsg.message_id, parse_mode: "HTML" }
          );
        }
      });
    });
  });

  conn.on("error", async (err) => {
    if (finished) return;
    finished = true;
    await bot.editMessageText(
      `<blockquote>✕ Gagal terhubung ke VPS.\nMohon cek kembali IP/password VPS.</blockquote>`,
      { chat_id: chatId, message_id: statusMsg.message_id, parse_mode: "HTML" }
    );
  });

  conn.connect({
    host: vpsIP,
    port: 22,
    username: "root",
    password: vpsPassword,
    readyTimeout: 20000
  });
});


// ===== INSTALL TEMA LIANIX • MULTI THEME =====
// Tema built-in tidak menjalankan shell pihak ketiga. NookTheme hanya memakai release resmi Nookure
// dan hanya diizinkan jika versi Panel cocok dengan release yang diketahui kompatibel.
const lianixThemeSessions = new Map();
const LIANIX_THEME_PROFILES = {
  modern:   { name: "Lianix Modern",   desc: "Violet/blue modern", a:"#8b5cf6", b:"#2563eb", bg:"#090d18", card:"#111827", text:"#e5e7eb" },
  midnight: { name: "Lianix Midnight", desc: "Dark navy elegan",   a:"#38bdf8", b:"#6366f1", bg:"#050816", card:"#0f172a", text:"#e2e8f0" },
  emerald:  { name: "Lianix Emerald",  desc: "Dark emerald",       a:"#10b981", b:"#0ea5e9", bg:"#06110d", card:"#0b1f18", text:"#ecfdf5" },
  crimson:  { name: "Lianix Crimson",  desc: "Dark red premium",   a:"#ef4444", b:"#f97316", bg:"#120708", card:"#211012", text:"#fff1f2" },
  ocean:    { name: "Lianix Ocean",    desc: "Blue/cyan clean",    a:"#06b6d4", b:"#2563eb", bg:"#06101a", card:"#0b1b2b", text:"#e0f2fe" },
  amoled:   { name: "Lianix AMOLED",   desc: "Pure black OLED",    a:"#a855f7", b:"#3b82f6", bg:"#000000", card:"#080808", text:"#f5f5f5" },
  neon:     { name: "Lianix Neon",     desc: "Neon cyber",         a:"#22d3ee", b:"#c026d3", bg:"#05050a", card:"#10101a", text:"#ecfeff" },
  minimal:  { name: "Lianix Minimal",  desc: "Minimal soft dark",  a:"#94a3b8", b:"#64748b", bg:"#0f1115", card:"#171a21", text:"#e5e7eb" },
  nook:     { name: "NookTheme Official", desc: "Full upstream theme (version-gated)", external: true }
};
function lianixThemeKeyboard(){
  const ids=Object.keys(LIANIX_THEME_PROFILES), rows=[];
  for(let i=0;i<ids.length;i+=2) rows.push(ids.slice(i,i+2).map(id=>({text:LIANIX_THEME_PROFILES[id].name,callback_data:`lxt:${id}`})));
  rows.push([{text:"‹‹‹",callback_data:"lxt:cancel"}]);
  return {inline_keyboard:rows};
}
function lianixThemeCss(profile){
  const {a,b,bg,card,text}=profile;
  return `:root{--lx:${a};--lx2:${b};--lxbg:${bg};--lxcard:${card};--lxtext:${text};--lxline:color-mix(in srgb,var(--lx) 22%,transparent)}html,body{background:${bg}!important;color:${text}!important}body{background-image:radial-gradient(circle at 90% 0,color-mix(in srgb,${a} 16%,transparent),transparent 35%),radial-gradient(circle at 0 100%,color-mix(in srgb,${b} 14%,transparent),transparent 34%)!important}a{transition:.18s ease!important}button,.btn,[role=button]{border-radius:11px!important;transition:.18s ease!important}button:hover,.btn:hover{transform:translateY(-1px)}.box,.panel,.card,[class*=Card]{border-color:var(--lxline)!important;box-shadow:0 12px 36px rgba(0,0,0,.22)!important}.content-wrapper{background:transparent!important}.main-header .navbar,.main-header .logo,.main-sidebar,.left-side{background:linear-gradient(180deg,${card},${bg})!important}.skin-blue .main-header .navbar,.skin-blue .main-header .logo{background:linear-gradient(90deg,${a},${b})!important}.btn-primary,.bg-blue,.label-primary{background:linear-gradient(90deg,${a},${b})!important;border-color:transparent!important}.box.box-primary{border-top-color:${a}!important}input,select,textarea{border-radius:9px!important}.content-header h1:after{content:'  •  Lianix';font-size:11px;font-weight:700;color:${a};vertical-align:middle}.lianix-brand-badge{position:fixed;right:14px;bottom:12px;z-index:9999;padding:6px 10px;border-radius:999px;background:color-mix(in srgb,${card} 84%,transparent);backdrop-filter:blur(12px);border:1px solid color-mix(in srgb,${a} 32%,transparent);color:${text};font:700 11px/1.2 sans-serif;pointer-events:none}`;
}
function themeHelp(){
  return `<blockquote expandable><b>PANDUAN INSTALL TEMA • LIANIX</b>\n\n<b>Format:</b> <code>/installtema host_target | password_vps</code> (alias: <code>/installtheme</code>)\n\nSetelah SSH target disimpan, pilih tema lewat tombol. Tersedia 8 tema Lianix built-in + NookTheme official.\n\nTema built-in memakai backup + asset CSS + injeksi Blade + clear cache + verifikasi. NookTheme hanya berjalan bila versi Panel cocok dengan release official yang didukung.\n\n<b>host_target</b>: <code>IP</code>, <code>IP:PORT</code>, <code>user@IP</code>, atau <code>user@IP:PORT</code>.</blockquote>`;
}
async function applyLianixTheme(bot,q,session,themeId){
  const chatId=q.message.chat.id,messageId=q.message.message_id;
  const profile=LIANIX_THEME_PROFILES[themeId];
  if(!profile)return;
  const {target,password}=session;
  const ui=createLiveInstallerCard(bot,chatId,messageId,{title:`INSTALL TEMA • ${profile.name.toUpperCase()}`,target:target.display,status:"Membangun koneksi SSH...",stage:"Persiapan",percent:0});
  await ui.flush();
  const conn=new Client(); let done=false;
  const timeout=setTimeout(async()=>{if(done)return;done=true;try{conn.end()}catch{};await ui.add("TIMEOUT • proses tema melewati 15 menit",{stderr:true,force:true});await ui.close();await safeEdit(bot,chatId,messageId,"✕ <b>INSTALL TEMA GAGAL</b>\n\nTimeout proses 15 menit.").catch(()=>{});},15*60*1000);
  const cssB64=profile.external?"":Buffer.from(lianixThemeCss(profile)).toString("base64");
  conn.on("ready",async()=>{
    await showVpsProfileInCard(ui, conn, target.display);
    await ui.setStatus("✅ SSH Terhubung! • Installer tema berjalan...",true);
    await ui.add(`SSH ready • memasang ${profile.name}...`,{force:true});
    await ui.setStage("Tahap 1/7 • Pemeriksaan panel",10,true);
    const builtIn=`set -Eeuo pipefail
DIR=/var/www/pterodactyl
BACKUP=""
restore_theme(){ [ -n "$BACKUP" ] || return 0; for F in resources/views/templates/wrapper.blade.php resources/views/layouts/admin.blade.php; do [ -f "$BACKUP/$F" ] && cp -af "$BACKUP/$F" "$DIR/$F" || true; done; if [ -f "$BACKUP/lianix-theme.css" ]; then cp -af "$BACKUP/lianix-theme.css" "$DIR/public/lianix-theme.css"; else rm -f "$DIR/public/lianix-theme.css"; fi; }
trap 'rc=$?; restore_theme; echo "LIANIX_FATAL:exit=$rc line=\${BASH_LINENO[0]:-?} cmd=\${BASH_COMMAND:-unknown}" >&2' ERR
exec 9>/run/lock/lianix-panel-action.lock
flock -n 9 || { echo "LIANIX_BUSY"; exit 88; }
echo "[1/7] Memeriksa Panel Pterodactyl..."
[ -f "$DIR/artisan" ] || { echo THEME_ERR_NO_PANEL; exit 10; }
cd "$DIR"
php -r 'exit(version_compare(PHP_VERSION,"8.2.0",">=")?0:1);' || { echo THEME_ERR_PHP; exit 11; }
echo THEME_STEP_2
echo "[2/7] Membuat backup tampilan lama..."
STAMP=$(date +%Y%m%d%H%M%S); BACKUP="$DIR/.lianix-theme-backup-$STAMP"; mkdir -p "$BACKUP"
for F in resources/views/templates/wrapper.blade.php resources/views/layouts/admin.blade.php; do if [ -f "$DIR/$F" ]; then mkdir -p "$BACKUP/$(dirname "$F")"; cp -a "$DIR/$F" "$BACKUP/$F"; fi; done
[ -f "$DIR/public/lianix-theme.css" ] && cp -a "$DIR/public/lianix-theme.css" "$BACKUP/lianix-theme.css" || true
printf '%s\n' '${themeId}' > "$BACKUP/theme-id"
echo THEME_STEP_3
echo "[3/7] Menulis asset ${profile.name}..."
printf '%s' '${cssB64}' | base64 -d > "$DIR/public/lianix-theme.css"
[ -s "$DIR/public/lianix-theme.css" ] || { echo THEME_ERR_ASSET; exit 12; }
echo THEME_STEP_4
echo "[4/7] Menyisipkan asset ke user/admin Panel..."
cat > /tmp/lianix-theme-apply.php <<'PHP'
<?php
$root='/var/www/pterodactyl';
$css='<link rel="stylesheet" href="/lianix-theme.css?v=22">';
$badge='<div class="lianix-brand-badge">Lianix • @yoennakbobo</div>';
foreach(['resources/views/templates/wrapper.blade.php','resources/views/layouts/admin.blade.php'] as $rel){$p=$root.'/'.$rel;if(!is_file($p))continue;$t=file_get_contents($p);$t=preg_replace('#<link rel="stylesheet" href="/lianix-theme\\.css[^>]*>#','',$t);$t=str_replace('<div class="lianix-brand-badge">Lianix • @yoennakbobo</div>','',$t);if(strpos($t,'</head>')!==false)$t=str_replace('</head>',$css."\n</head>",$t);if(strpos($t,'</body>')!==false)$t=str_replace('</body>',$badge."\n</body>",$t);file_put_contents($p,$t);}
PHP
php /tmp/lianix-theme-apply.php; rm -f /tmp/lianix-theme-apply.php
echo THEME_STEP_5
echo "[5/7] Memeriksa syntax Blade/PHP dan permission..."
chmod 644 "$DIR/public/lianix-theme.css"; chown www-data:www-data "$DIR/public/lianix-theme.css" 2>/dev/null || true
php -l "$DIR/app/Http/Kernel.php" >/dev/null

echo THEME_STEP_6
echo "[6/7] Membersihkan cache Panel..."
timeout 180 php artisan optimize:clear
timeout 180 php artisan view:clear || true
echo "[7/7] Memverifikasi tema..."
grep -Rqs '/lianix-theme.css' "$DIR/resources/views" || { echo THEME_ERR_APPLY; exit 13; }
grep -Rqs 'lianix-brand-badge' "$DIR/resources/views" || { echo THEME_ERR_APPLY; exit 14; }
grep -q '\.lianix-brand-badge' "$DIR/public/lianix-theme.css" || { echo THEME_ERR_APPLY; exit 15; }
mkdir -p /etc/lianix
printf '%s\n' '${themeId}' > /etc/lianix/theme-active
chmod 600 /etc/lianix/theme-active
trap - ERR
echo THEME_OK`;
    const nook=`set -Eeuo pipefail
DIR=/var/www/pterodactyl
exec 9>/run/lock/lianix-panel-action.lock
flock -n 9 || { echo LIANIX_BUSY; exit 88; }
echo "[1/7] Memeriksa Panel dan versi untuk NookTheme..."
[ -f "$DIR/artisan" ] || { echo THEME_ERR_NO_PANEL; exit 10; }
cd "$DIR"
VER=$(php artisan p:info 2>/dev/null | grep -oE '[0-9]+\\.[0-9]+\\.[0-9]+' | head -n1 || true)
[ -n "$VER" ] || VER=$(grep -oE 'v?[0-9]+\\.[0-9]+\\.[0-9]+' CHANGELOG.md 2>/dev/null | head -n1 | tr -d v || true)
echo "Panel version: ${'$'}VER"
[ "$VER" = "1.14.1" ] || { echo "THEME_ERR_NOOK_VERSION:${'$'}VER"; exit 21; }
echo THEME_STEP_2
echo "[2/7] Backup penuh file penting Panel..."
STAMP=$(date +%Y%m%d%H%M%S); BACKUP="$DIR/.lianix-nook-backup-$STAMP"; mkdir -p "$BACKUP"
for D in app bootstrap config database public resources routes; do [ -e "$D" ] && cp -a "$D" "$BACKUP/" || true; done
for F in composer.json composer.lock package.json yarn.lock; do [ -f "$F" ] && cp -a "$F" "$BACKUP/" || true; done
rollback_nook(){
  echo "ROLLBACK • memulihkan Panel sebelum NookTheme..." >&2
  for D in app bootstrap config database public resources routes; do [ -d "$BACKUP/$D" ] && { rm -rf "$DIR/$D"; cp -a "$BACKUP/$D" "$DIR/$D"; } || true; done
  for F in composer.json composer.lock package.json yarn.lock; do [ -f "$BACKUP/$F" ] && cp -af "$BACKUP/$F" "$DIR/$F" || true; done
  cd "$DIR"
  timeout 1200 composer install --no-dev --optimize-autoloader --no-interaction >/dev/null 2>&1 || true
  php artisan optimize:clear >/dev/null 2>&1 || true
  php artisan up >/dev/null 2>&1 || true
}
trap 'rc=$?; rollback_nook; echo "LIANIX_FATAL:exit=$rc line=\${BASH_LINENO[0]:-?} cmd=\${BASH_COMMAND:-unknown}" >&2' ERR
echo THEME_STEP_3
echo "[3/7] Download NookTheme official release 1.14.1..."
TMP=$(mktemp -d); curl -fL --retry 3 --connect-timeout 15 --max-time 180 'https://github.com/Nookure/NookTheme/releases/download/theme-1.4.0-1.14.1/panel.tar.gz' -o "$TMP/panel.tar.gz"
tar -tzf "$TMP/panel.tar.gz" >/dev/null || { echo THEME_ERR_ARCHIVE; exit 22; }
echo THEME_STEP_4
echo "[4/7] Maintenance mode + menerapkan NookTheme..."
php artisan down --retry=60 || true
tar -xzf "$TMP/panel.tar.gz" -C "$DIR"
echo THEME_STEP_5
echo "[5/7] Composer dependencies..."
timeout 1200 composer install --no-dev --optimize-autoloader --no-interaction
chmod -R 755 storage/* bootstrap/cache || true
chown -R www-data:www-data "$DIR" || true
echo THEME_STEP_6
echo "[6/7] Migration/cache..."
timeout 600 php artisan migrate --seed --force
timeout 180 php artisan optimize:clear
php artisan up || true
echo "[7/7] Verifikasi NookTheme..."
[ -f artisan ] && [ -d resources ] && [ -d public ] || { echo THEME_ERR_APPLY; exit 23; }
rm -rf "$TMP"
trap - ERR
echo THEME_OK`;
    const cmd=profile.external?nook:builtIn;
    try{
      const result=await runLianixRemoteScript(conn,cmd,{username:target.username,password,openTimeoutMs:12000,firstOutputTimeoutMs:15000,onLine:async(row,isErr)=>{if(row.includes("THEME_STEP_2"))await ui.setStage("Tahap 2/7 • Backup",25,true);else if(row.includes("THEME_STEP_3"))await ui.setStage("Tahap 3/7 • Menyiapkan tema",40,true);else if(row.includes("THEME_STEP_4"))await ui.setStage("Tahap 4/7 • Menerapkan tema",58,true);else if(row.includes("THEME_STEP_5"))await ui.setStage("Tahap 5/7 • Dependency/permission",72,true);else if(row.includes("THEME_STEP_6"))await ui.setStage("Tahap 6/7 • Cache/migration",86,true);else if(!/^THEME_STEP_/.test(row)&&row!=="LIANIX_REMOTE_CHANNEL_OK")await ui.add(row,{stderr:isErr});}});
      clearTimeout(timeout);done=true;try{conn.end()}catch{}
      const combined=`${result.out||''}\n${result.errOut||''}`;
      if(result.code===0&&combined.includes("THEME_OK")){await ui.setStage("Tahap 7/7 • Tema aktif & terverifikasi",100,true);await ui.add("✓ Tema selesai dipasang dan diverifikasi.",{force:true});await ui.close();lianixThemeSessions.delete(String(q.from.id));return safeEdit(bot,chatId,messageId,`✓ <b>INSTALL TEMA SELESAI</b>\n\nTema: <b>${escapeHTML(profile.name)}</b>\nTarget: <code>${escapeHTML(target.display)}</code>\nTag: <code>Lianix • @yoennakbobo</code>\n\n✓ Backup dibuat\n✓ Tema diterapkan\n✓ Cache dibersihkan\n✓ Verifikasi selesai`);}
      const reason=combined.includes("LIANIX_BUSY")?"VPS sedang dipakai proses panel lain.":combined.includes("THEME_ERR_NO_PANEL")?"Panel Pterodactyl tidak ditemukan.":combined.includes("THEME_ERR_PHP")?"PHP Panel terlalu lama (butuh PHP 8.2+).":combined.includes("THEME_ERR_NOOK_VERSION")?`NookTheme official di installer ini hanya untuk Panel 1.14.1. Versi target: ${escapeHTML((combined.match(/THEME_ERR_NOOK_VERSION:([^\s]+)/)||[])[1]||'tidak terdeteksi')}`:combined.includes("THEME_ERR_ARCHIVE")?"Archive NookTheme tidak valid.":combined.includes("THEME_ERR_ASSET")?"Asset tema gagal dibuat.":combined.includes("THEME_ERR_APPLY")?"Tema gagal diverifikasi setelah pemasangan.":(result.errOut?.trim()||`Exit ${result.code}`);
      await ui.add(`GAGAL • ${reason}`,{stderr:true,force:true});await ui.close();return safeEdit(bot,chatId,messageId,`✕ <b>INSTALL TEMA GAGAL</b>\n\n${escapeHTML(reason).slice(0,1800)}`);
    }catch(e){clearTimeout(timeout);done=true;try{conn.end()}catch{};const reason=String(e?.message||e);await ui.add(`SSH TRANSPORT GAGAL • ${reason}`,{stderr:true,force:true}).catch(()=>{});await ui.close().catch(()=>{});return safeEdit(bot,chatId,messageId,`✕ <b>INSTALL TEMA GAGAL</b>\n\n${escapeHTML(reason).slice(0,1800)}`);}
  }).on("error",async e=>{clearTimeout(timeout);if(done)return;done=true;await ui.add(`SSH ERROR • ${e.message}`,{stderr:true,force:true}).catch(()=>{});await ui.close().catch(()=>{});await safeEdit(bot,chatId,messageId,`✕ <b>INSTALL TEMA GAGAL</b>\n\nKoneksi SSH: ${escapeHTML(e.message)}`).catch(()=>{});}).connect({host:target.host,port:target.port,username:target.username,password,readyTimeout:20000,keepaliveInterval:10000});
}
async function handleInstallTemaCommand(msg,match){
  const chatId=msg.chat.id,userId=msg.from.id;if(getUserRole(userId)!=="ceo"&&userId!==ownerId)return bot.sendMessage(chatId,"✗ Khusus Owner/CEO!");
  const input=match?.[1]?.trim()||"";if(!input||input.split("|").length<2)return bot.sendMessage(chatId,themeHelp(),{parse_mode:"HTML"});
  const parts=input.split("|").map(v=>v.trim()),targetRaw=parts[0],password=parts[1],direct=(parts[2]||"").toLowerCase();let target;try{target=parseSshTarget(targetRaw)}catch(e){return bot.sendMessage(chatId,`✕ ${escapeHTML(e.message)}`,{parse_mode:"HTML"})}
  lianixThemeSessions.set(String(userId),{target,password,at:Date.now()});
  const m=await bot.sendMessage(chatId,`<b>PILIH TEMA PTERODACTYL</b>\n\nTarget: <code>${escapeHTML(target.display)}</code>\n\n8 tema Lianix built-in aman + NookTheme official (version-gated).`,{parse_mode:"HTML",reply_markup:lianixThemeKeyboard()});
  if(direct&&LIANIX_THEME_PROFILES[direct]){const fake={id:"",from:msg.from,message:{chat:msg.chat,message_id:m.message_id}};return applyLianixTheme(bot,fake,lianixThemeSessions.get(String(userId)),direct);}
}
bot.onText(/^\/installtema(?:\s+(.+))?$/i, handleInstallTemaCommand);
bot.onText(/^\/installtheme(?:\s+(.+))?$/i, handleInstallTemaCommand);
bot.on("callback_query",async q=>{if(!String(q.data||"").startsWith("lxt:"))return;await bot.answerCallbackQuery(q.id).catch(()=>{});const key=String(q.from.id);if(q.data==="lxt:cancel"){lianixThemeSessions.delete(key);return safeEdit(bot,q.message.chat.id,q.message.message_id,"<b>INSTALL TEMA DIBATALKAN</b>");}const id=String(q.data).split(":")[1],ses=lianixThemeSessions.get(key);if(!ses||Date.now()-ses.at>10*60*1000)return safeEdit(bot,q.message.chat.id,q.message.message_id,"✕ Sesi tema kedaluwarsa. Jalankan /installtema lagi.");if(!LIANIX_THEME_PROFILES[id])return;return applyLianixTheme(bot,q,ses,id);});

// ===== UNINSTALL TEMA LIANIX MODERN =====
// Mengembalikan backup tema terakhir yang dibuat /installtema dan menghapus asset Lianix.
bot.onText(/^\/uninstalltema(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id, userId = msg.from.id;
  if (getUserRole(userId) !== "ceo" && userId !== ownerId) return bot.sendMessage(chatId, "✗ Khusus Owner/CEO!");
  const input = match?.[1]?.trim() || "";
  if (!input || input.split("|").length < 2) return bot.sendMessage(chatId,
    `<blockquote expandable><b>PANDUAN UNINSTALL TEMA • LIANIX</b>\n\n`+
    `<b>Format:</b> <code>/uninstalltema host_target | password_vps</code>\n\n`+
    `Bot akan mencari backup terbaru dari /installtema, mengembalikan Blade lama, menghapus asset Lianix, clear cache, lalu memverifikasi hasil.</blockquote>`,
    { parse_mode:"HTML" });
  const [targetRaw,password] = input.split("|").map(v=>v.trim());
  let target; try { target=parseSshTarget(targetRaw); } catch(e) { return bot.sendMessage(chatId,`✕ ${escapeHTML(e.message)}`,{parse_mode:"HTML"}); }
  const st=await bot.sendMessage(chatId,`<b>🚀 MEMPROSES UNINSTALL TEMA...</b>\n<b>Target:</b> <code>${escapeHTML(target.display)}</code>`,{parse_mode:"HTML"});
  const ui=createLiveInstallerCard(bot,chatId,st.message_id,{title:"UNINSTALL TEMA • LIANIX",target:target.display,status:"Membangun koneksi SSH...",stage:"Persiapan",percent:0});
  await ui.flush();
  const conn=new Client(); let done=false;
  const timer=setTimeout(async()=>{if(done)return;done=true;try{conn.end()}catch{};await ui.close();await safeEdit(bot,chatId,st.message_id,'✕ <b>UNINSTALL TEMA GAGAL</b>\n\nTimeout proses 5 menit.').catch(()=>{});},300000);
  conn.on('ready',async()=>{
    await ui.setStatus('✅ SSH Terhubung! • Mencari backup tema...',true);
    await ui.setStage('Tahap 1/4 • Mencari backup',20,true);
    const cmd=`set -Eeuo pipefail
DIR=/var/www/pterodactyl
exec 9>/run/lock/lianix-panel-action.lock
if ! flock -n 9; then echo "LIANIX_BUSY"; exit 88; fi
[ -f "$DIR/artisan" ] || { echo "THEME_ERR_NO_PANEL"; exit 10; }
BACKUP=$(find "$DIR" -maxdepth 1 -type d \( -name '.lianix-theme-backup-*' -o -name '.lianix-nook-backup-*' \) -printf '%T@ %p\n' 2>/dev/null | sort -nr | head -n1 | cut -d' ' -f2-)
[ -n "$BACKUP" ] || { echo "THEME_ERR_NO_BACKUP"; exit 11; }
echo "UN_THEME_STEP_2"
if [[ "$(basename "$BACKUP")" == .lianix-nook-backup-* ]]; then
  for D in app bootstrap config database public resources routes; do [ -d "$BACKUP/$D" ] && { rm -rf "$DIR/$D"; cp -a "$BACKUP/$D" "$DIR/$D"; } || true; done
  for F in composer.json composer.lock package.json yarn.lock; do [ -f "$BACKUP/$F" ] && cp -af "$BACKUP/$F" "$DIR/$F" || true; done
  cd "$DIR"
  timeout 1200 composer install --no-dev --optimize-autoloader --no-interaction || { echo THEME_ERR_RESTORE; exit 12; }
else
  for F in resources/views/templates/wrapper.blade.php resources/views/layouts/admin.blade.php; do [ -f "$BACKUP/$F" ] && cp -af "$BACKUP/$F" "$DIR/$F"; done
  rm -f "$DIR/public/lianix-theme.css"
fi
echo "UN_THEME_STEP_3"
cd "$DIR"
timeout 180 php artisan optimize:clear
timeout 180 php artisan view:clear || true
php artisan up || true
chown -R www-data:www-data "$DIR" 2>/dev/null || true
echo "UN_THEME_STEP_4"
if [[ "$(basename "$BACKUP")" != .lianix-nook-backup-* ]]; then ! grep -Rqs '/lianix-theme.css' "$DIR/resources/views" || { echo "THEME_ERR_RESTORE"; exit 12; }; fi
echo "UN_THEME_OK"`;
    const remote=target.username==='root'?'bash -s':"sudo -S -p '' bash -s";
    conn.exec(remote,(err,stream)=>{
      if(err){clearTimeout(timer);done=true;conn.end();ui.close().catch(()=>{});return safeEdit(bot,chatId,st.message_id,`✕ <b>UNINSTALL TEMA GAGAL</b>\n\n${escapeHTML(err.message)}`);}
      let out='',er='',pending='';
      const consume=(chunk,isErr=false)=>{const text=pending+String(chunk);const rows=text.split(/\r?\n/);pending=rows.pop()||'';for(const row of rows){out+=row+'\n';if(row.includes('UN_THEME_STEP_2'))ui.setStage('Tahap 2/4 • Restore tampilan lama',45,true);else if(row.includes('UN_THEME_STEP_3'))ui.setStage('Tahap 3/4 • Clear cache',70,true);else if(row.includes('UN_THEME_STEP_4'))ui.setStage('Tahap 4/4 • Verifikasi',90,true);else ui.add(row,{stderr:isErr});}};
      stream.on('data',d=>consume(d,false)); stream.stderr.on('data',d=>{er+=d;consume(d,true)});
      stream.on('close',async code=>{clearTimeout(timer);done=true;conn.end();if(code===0&&out.includes('UN_THEME_OK')){await ui.setStage('Tahap 4/4 • Selesai',100,true);await ui.close();return safeEdit(bot,chatId,st.message_id,`✓ <b>UNINSTALL TEMA SELESAI</b>\n\nTarget: <code>${escapeHTML(target.display)}</code>\nTema Lianix dilepas dan backup tampilan lama berhasil dipulihkan.`);}const reason=out.includes('LIANIX_BUSY')?'VPS sedang dipakai proses panel lain.':out.includes('THEME_ERR_NO_PANEL')?'Panel Pterodactyl tidak ditemukan.':out.includes('THEME_ERR_NO_BACKUP')?'Backup tema Lianix tidak ditemukan.':out.includes('THEME_ERR_RESTORE')?'Restore tema gagal diverifikasi.':(er.trim()||`Exit ${code}`);await ui.close();return safeEdit(bot,chatId,st.message_id,`✕ <b>UNINSTALL TEMA GAGAL</b>\n\n${escapeHTML(reason).slice(0,1800)}`);});
      if(target.username!=='root')stream.write(`${password}\n`);
      stream.end(cmd + '\n');
    });
  }).on('error',async e=>{clearTimeout(timer);if(done)return;done=true;await ui.close();await safeEdit(bot,chatId,st.message_id,`✕ <b>UNINSTALL TEMA GAGAL</b>\n\nKoneksi SSH: ${escapeHTML(e.message)}`).catch(()=>{});}).connect({host:target.host,port:target.port,username:target.username,password,readyTimeout:20000,keepaliveInterval:10000});
});

// ===== INSTALL PROTECT LIANIX • LEVEL 1-20 =====
// Implementasi lokal dengan Laravel middleware. Tidak mengunduh/menjalankan script root pihak ketiga.
const lianixProtectSessions = new Map();
const PROTECT_LEVELS = {
  1:"Anti Delete Server", 2:"Anti Edit/Create User", 3:"Kunci Locations", 4:"Kunci Nodes", 5:"Kunci Nests & Eggs",
  6:"Kunci Settings", 7:"Sembunyikan Daftar Server", 8:"Sembunyikan Detail Server", 9:"Anti Modifikasi Server", 10:"Lindungi Admin Utama",
  11:"Kunci Mounts", 12:"Kunci Application API", 13:"Kunci Database Hosts", 14:"Anti Delete User", 15:"Anti Delete Node",
  16:"Anti Delete Location", 17:"Anti Delete Nest/Egg", 18:"Admin Read-Only", 19:"Sembunyikan User Admin", 20:"Full Admin Lockdown"
};
function protectKeyboard(){const rows=[];for(let i=1;i<=20;i+=4){rows.push([i,i+1,i+2,i+3].filter(x=>x<=20).map(x=>({text:String(x),callback_data:`lxp:${x}`})));}rows.push([{text:"‹‹‹",callback_data:"lxp:cancel"}]);return {inline_keyboard:rows};}
function protectMiddlewarePhp(){return `<?php\nnamespace Pterodactyl\\Http\\Middleware;\nuse Closure;\nuse Illuminate\\Http\\Request;\nuse Illuminate\\Support\\Facades\\Auth;\nclass LianixAdminProtect { public function handle(Request $request, Closure $next) { $u=Auth::user(); if(!$u || !$u->root_admin) return $next($request); $cfg=@json_decode(@file_get_contents('/etc/lianix/protect.json'),true) ?: []; $main=(int)($cfg['admin_id'] ?? 1); if((int)$u->id===$main) return $next($request); $lv=array_values(array_unique(array_map('intval',$cfg['levels'] ?? []))); $p=trim($request->path(),'/'); $m=strtoupper($request->method()); $deny=false; $admin=str_starts_with($p,'admin'); if(in_array(1,$lv,true)&&$m==='DELETE'&&preg_match('#^admin/servers(?:/|$)#',$p))$deny=true; if(in_array(2,$lv,true)&&preg_match('#^admin/users(?:/|$)#',$p)&&$m!=='GET')$deny=true; if(in_array(3,$lv,true)&&preg_match('#^admin/locations(?:/|$)#',$p))$deny=true; if(in_array(4,$lv,true)&&preg_match('#^admin/nodes(?:/|$)#',$p))$deny=true; if(in_array(5,$lv,true)&&preg_match('#^admin/(nests|eggs)(?:/|$)#',$p))$deny=true; if(in_array(6,$lv,true)&&preg_match('#^admin/settings(?:/|$)#',$p))$deny=true; if(in_array(7,$lv,true)&&$m==='GET'&&$p==='admin/servers')$deny=true; if(in_array(8,$lv,true)&&$m==='GET'&&preg_match('#^admin/servers/[^/]+#',$p))$deny=true; if(in_array(9,$lv,true)&&$m!=='GET'&&preg_match('#^admin/servers(?:/|$)#',$p))$deny=true; if(in_array(10,$lv,true)&&preg_match('#^admin/users/'.$main.'(?:/|$)#',$p))$deny=true; if(in_array(11,$lv,true)&&preg_match('#^admin/mounts(?:/|$)#',$p))$deny=true; if(in_array(12,$lv,true)&&preg_match('#^admin/api(?:/|$)#',$p))$deny=true; if(in_array(13,$lv,true)&&preg_match('#^admin/databases(?:/|$)#',$p))$deny=true; if(in_array(14,$lv,true)&&$m==='DELETE'&&preg_match('#^admin/users(?:/|$)#',$p))$deny=true; if(in_array(15,$lv,true)&&$m==='DELETE'&&preg_match('#^admin/nodes(?:/|$)#',$p))$deny=true; if(in_array(16,$lv,true)&&$m==='DELETE'&&preg_match('#^admin/locations(?:/|$)#',$p))$deny=true; if(in_array(17,$lv,true)&&$m==='DELETE'&&preg_match('#^admin/(nests|eggs)(?:/|$)#',$p))$deny=true; if(in_array(18,$lv,true)&&$admin&&!in_array($m,['GET','HEAD','OPTIONS'],true))$deny=true; if(in_array(19,$lv,true)&&$m==='GET'&&preg_match('#^admin/users(?:/|$)#',$p))$deny=true; if(in_array(20,$lv,true)&&$admin)$deny=true; if($deny) abort(403,'Protected by Lianix • @yoennakbobo'); return $next($request); } }\n`;}
async function applyProtectLevel(bot, q, session, level){
  const chatId = q.message.chat.id, messageId = q.message.message_id;
  const { target, password, adminId } = session;
  const ui = createLiveInstallerCard(bot, chatId, messageId, {
    title: `INSTALL PROTECT • LEVEL ${level}`,
    target: target.display,
    status: `Membangun koneksi SSH • ${PROTECT_LEVELS[level]}`,
    stage: "Persiapan",
    percent: 0
  });
  await ui.flush();

  const phpB64 = Buffer.from(protectMiddlewarePhp()).toString('base64');
  const conn = new Client();
  let done = false;
  const timer = setTimeout(async()=>{
    if(done)return; done=true; try{conn.end()}catch{}
    await ui.add('TIMEOUT • proses protect melewati batas 5 menit',{stderr:true,force:true});
    await ui.close();
    await safeEdit(bot,chatId,messageId,'✕ <b>INSTALL PROTECT GAGAL</b>\n\nTimeout proses 5 menit.').catch(()=>{});
  },300000);

  conn.on('ready', async()=>{
    await showVpsProfileInCard(ui, conn, target.display);
    await ui.setStatus('✅ SSH Terhubung! • Menjalankan script protect...', true);
    await ui.add('SSH ready • mengirim script Protect Lianix lewat stdin...', {force:true});
    await ui.setStage('Tahap 1/5 • Pemeriksaan panel', 15, true);
    const cmd=`set -Eeuo pipefail
DIR=/var/www/pterodactyl
K="$DIR/app/Http/Kernel.php"
PROTECT_TMP="/tmp/lianix-protect-backup-$$"
mkdir -p "$PROTECT_TMP"
[ -f "$K" ] && cp -a "$K" "$PROTECT_TMP/Kernel.php" || true
[ -f "$DIR/app/Http/Middleware/LianixAdminProtect.php" ] && cp -a "$DIR/app/Http/Middleware/LianixAdminProtect.php" "$PROTECT_TMP/LianixAdminProtect.php" || true
[ -f /etc/lianix/protect.json ] && cp -a /etc/lianix/protect.json "$PROTECT_TMP/protect.json" || true
[ -f "$DIR/resources/views/admin/index.blade.php" ] && cp -a "$DIR/resources/views/admin/index.blade.php" "$PROTECT_TMP/admin-index.blade.php" || true
rollback_lianix_protect(){
  [ -f "$PROTECT_TMP/Kernel.php" ] && cp -af "$PROTECT_TMP/Kernel.php" "$K" || true
  if [ -f "$PROTECT_TMP/LianixAdminProtect.php" ]; then cp -af "$PROTECT_TMP/LianixAdminProtect.php" "$DIR/app/Http/Middleware/LianixAdminProtect.php"; else rm -f "$DIR/app/Http/Middleware/LianixAdminProtect.php"; fi
  if [ -f "$PROTECT_TMP/protect.json" ]; then mkdir -p /etc/lianix; cp -af "$PROTECT_TMP/protect.json" /etc/lianix/protect.json; else rm -f /etc/lianix/protect.json; fi
  [ -f "$PROTECT_TMP/admin-index.blade.php" ] && cp -af "$PROTECT_TMP/admin-index.blade.php" "$DIR/resources/views/admin/index.blade.php" || true
}
trap 'rc=$?; rollback_lianix_protect; echo "LIANIX_FATAL:exit=$rc line=\${BASH_LINENO[0]:-?} cmd=\${BASH_COMMAND:-unknown}" >&2' ERR
exec 9>/run/lock/lianix-panel-action.lock
if ! flock -n 9; then echo "LIANIX_BUSY: VPS sedang menjalankan proses panel lain."; exit 88; fi

echo "[1/5] Mengecek panel dan akun admin utama..."
[ -f "$DIR/artisan" ] || { echo PROTECT_ERR_NO_PANEL; exit 10; }
cd "$DIR"
timeout 60 php artisan --version || true
ADMIN_OK=$(php -r 'require "vendor/autoload.php"; $app=require "bootstrap/app.php"; $kernel=$app->make(Illuminate\Contracts\Console\Kernel::class); $kernel->bootstrap(); echo (int) \Pterodactyl\Models\User::query()->where("id", ${adminId})->where("root_admin", 1)->exists();' 2>/dev/null || true)
[ "$ADMIN_OK" = "1" ] || { echo "PROTECT_ERR_ADMIN: ID admin utama ${adminId} tidak ditemukan atau bukan root admin."; exit 11; }

echo PROTECT_STEP_2
echo "[2/5] Menulis middleware proteksi Lianix..."
mkdir -p /etc/lianix "$DIR/app/Http/Middleware"
printf '%s' '${phpB64}' | base64 -d > "$DIR/app/Http/Middleware/LianixAdminProtect.php"
php -l "$DIR/app/Http/Middleware/LianixAdminProtect.php"

echo PROTECT_STEP_3
echo "[3/5] Menyimpan kebijakan protect level ${level} untuk admin utama ${adminId}..."
php -r '$f="/etc/lianix/protect.json";$d=is_file($f)?(json_decode(file_get_contents($f),true)?:[]):[];$d["admin_id"]=${adminId};$l=$d["levels"]??[];$l[]=${level};$d["levels"]=array_values(array_unique(array_map("intval",$l)));file_put_contents($f,json_encode($d,JSON_PRETTY_PRINT));'
chmod 600 /etc/lianix/protect.json
cat /etc/lianix/protect.json

echo PROTECT_STEP_4
echo "[4/5] Mendaftarkan middleware ke Laravel Kernel..."
K="$DIR/app/Http/Kernel.php"
[ -f "$K" ] || { echo PROTECT_ERR_KERNEL; exit 12; }
cp -an "$K" "$K.lianix-original" || true
if ! grep -q 'LianixAdminProtect::class' "$K"; then
  cat > /tmp/lianix-kernel-inject.php <<'PHP'
<?php
$p='/var/www/pterodactyl/app/Http/Kernel.php';
$t=file_get_contents($p);
if(strpos($t,'LianixAdminProtect::class')!==false) exit(0);
$needle='StartSession::class,';
$pos=strpos($t,$needle);
if($pos===false){fwrite(STDERR,"STARTSESSION_NOT_FOUND\n");exit(2);}
$end=$pos+strlen($needle);
$t=substr($t,0,$end)."\n            \\Pterodactyl\\Http\\Middleware\\LianixAdminProtect::class,".substr($t,$end);
file_put_contents($p,$t);
PHP
  php /tmp/lianix-kernel-inject.php || { rm -f /tmp/lianix-kernel-inject.php; echo PROTECT_ERR_KERNEL; exit 12; }
  rm -f /tmp/lianix-kernel-inject.php
fi
grep -q 'LianixAdminProtect::class' "$K" || { echo PROTECT_ERR_KERNEL; exit 12; }
php -l "$K" >/dev/null || { echo PROTECT_ERR_KERNEL; exit 12; }

echo "[5/5] Memasang label Lianix Protect, membersihkan cache, dan memverifikasi..."
ADMIN_INDEX="$DIR/resources/views/admin/index.blade.php"
[ -f "$ADMIN_INDEX" ] || { echo PROTECT_ERR_ADMIN_VIEW; exit 15; }
if ! grep -q 'LIANIX_PROTECT_BADGE_START' "$ADMIN_INDEX"; then
  php -r '
$p="/var/www/pterodactyl/resources/views/admin/index.blade.php";
$t=file_get_contents($p);
$badge="\n{{-- LIANIX_PROTECT_BADGE_START --}}\n<div class=\"row\" id=\"lianix-protect-badge\" style=\"margin-top:24px;\">\n  <div class=\"col-xs-12 text-center\">\n    <button type=\"button\" class=\"btn btn-danger\" style=\"min-width:220px;font-weight:600;pointer-events:none;\">\n      <i class=\"fa fa-fw fa-shield\"></i> Lianix Protect\n    </button>\n  </div>\n</div>\n{{-- LIANIX_PROTECT_BADGE_END --}}\n";
$pos=strrpos($t,"@endsection");
if($pos===false){fwrite(STDERR,"ADMIN_ENDSECTION_NOT_FOUND\n");exit(2);}
$t=substr($t,0,$pos).$badge.substr($t,$pos);
file_put_contents($p,$t);
' || { echo PROTECT_ERR_ADMIN_VIEW; exit 15; }
fi
grep -q 'Lianix Protect' "$ADMIN_INDEX" || { echo PROTECT_ERR_ADMIN_VIEW; exit 15; }
timeout 180 php artisan optimize:clear
php -l app/Http/Middleware/LianixAdminProtect.php
php -r '$d=json_decode(file_get_contents("/etc/lianix/protect.json"),true)?:[]; $levels=array_map("intval",$d["levels"]??[]); exit(((int)($d["admin_id"]??0)===${adminId} && in_array(${level},$levels,true))?0:1);' || { echo PROTECT_ERR_VERIFY; exit 13; }
grep -q 'LianixAdminProtect::class' app/Http/Kernel.php || { echo PROTECT_ERR_VERIFY; exit 14; }
trap - ERR
rm -rf "$PROTECT_TMP"
echo PROTECT_OK`;
    try {
      const result = await runLianixRemoteScript(conn, cmd, {
        username: target.username,
        password,
        openTimeoutMs: 12000,
        firstOutputTimeoutMs: 15000,
        onLine: async (row, isErr) => {
          if(row.includes('PROTECT_STEP_2')) await ui.setStage('Tahap 2/5 • Membuat middleware',35,true);
          else if(row.includes('PROTECT_STEP_3')) await ui.setStage('Tahap 3/5 • Menyimpan kebijakan',55,true);
          else if(row.includes('PROTECT_STEP_4')) await ui.setStage('Tahap 4/5 • Mendaftarkan middleware',75,true);
          else if(!/^PROTECT_STEP_/.test(row) && row !== 'LIANIX_REMOTE_CHANNEL_OK') await ui.add(row,{stderr:isErr});
        }
      });
      clearTimeout(timer); done=true; try{conn.end()}catch{}
      const combined=`${result.out||''}
${result.errOut||''}`;
      if(result.code===0&&combined.includes('PROTECT_OK')){
        await ui.setStage('Tahap 5/5 • Protect aktif & terverifikasi',100,true);
        await ui.add('✓ Semua verifikasi protect berhasil.',{force:true});
        await ui.close();
        return safeEdit(bot,chatId,messageId,`✓ <b>PROTECT LEVEL ${level} AKTIF</b>

${escapeHTML(PROTECT_LEVELS[level])}
Admin utama: <code>${adminId}</code>
Target: <code>${escapeHTML(target.display)}</code>
Tag: <code>Lianix • @yoennakbobo</code>
Label Admin: <b>Lianix Protect</b>

Admin utama tetap punya akses penuh; admin lain dibatasi sesuai level ini.`);
      }
      const r=combined.includes('LIANIX_BUSY')?'VPS sedang menjalankan proses panel lain. Tunggu proses sebelumnya selesai.'
        :combined.includes('PROTECT_ERR_NO_PANEL')?'Panel Pterodactyl tidak ditemukan.'
        :combined.includes('PROTECT_ERR_ADMIN')?'ID admin utama tidak ditemukan atau bukan root admin.'
        :combined.includes('PROTECT_ERR_KERNEL')?'Kernel Laravel tidak cocok/pendaftaran middleware gagal.'
        :combined.includes('PROTECT_ERR_VERIFY')?'Verifikasi konfigurasi gagal.'
        :(result.errOut?.trim()||`Exit ${result.code}`);
      await ui.add(`GAGAL • ${r}`,{stderr:true,force:true});
      await ui.close();
      return safeEdit(bot,chatId,messageId,`✕ <b>INSTALL PROTECT GAGAL</b>

${escapeHTML(r).slice(0,1800)}`);
    } catch(e) {
      clearTimeout(timer); done=true; try{conn.end()}catch{}
      const reason=String(e?.message||e);
      await ui.add(`SSH TRANSPORT GAGAL • ${reason}`,{stderr:true,force:true}).catch(()=>{});
      await ui.close().catch(()=>{});
      return safeEdit(bot,chatId,messageId,`✕ <b>INSTALL PROTECT GAGAL</b>

${escapeHTML(reason).slice(0,1800)}`);
    }
  }).on('error',async e=>{
    clearTimeout(timer);if(done)return;done=true;
    await ui.add(`SSH ERROR • ${e.message}`,{stderr:true,force:true});
    await ui.close();
    await safeEdit(bot,chatId,messageId,`✕ <b>INSTALL PROTECT GAGAL</b>\n\nKoneksi SSH: ${escapeHTML(e.message)}`).catch(()=>{});
  }).connect({host:target.host,port:target.port,username:target.username,password,readyTimeout:20000,keepaliveInterval:10000});
}
bot.onText(/^\/installprotect(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId=msg.chat.id,userId=msg.from.id;if(getUserRole(userId)!=='ceo'&&userId!==ownerId)return bot.sendMessage(chatId,'✗ Khusus Owner/CEO!');
  const input=match?.[1]?.trim()||'';
  if(!input||input.split('|').length<3)return bot.sendMessage(chatId,`<blockquote expandable><b>PANDUAN INSTALL PROTECT • LEVEL 1-20</b>\n\n<b>Format:</b> <code>/installprotect host_target | password_vps | id_admin_utama</code>\n\nSetelah data valid, bot menampilkan tombol <b>1–20</b>. Pilih proteksi yang ingin dipasang.\n\n1 Anti Delete Server\n2 Anti Edit/Create User\n3 Kunci Locations\n4 Kunci Nodes\n5 Kunci Nests & Eggs\n6 Kunci Settings\n7 Sembunyikan Daftar Server\n8 Sembunyikan Detail Server\n9 Anti Modifikasi Server\n10 Lindungi Admin Utama\n11 Kunci Mounts\n12 Kunci Application API\n13 Kunci Database Hosts\n14 Anti Delete User\n15 Anti Delete Node\n16 Anti Delete Location\n17 Anti Delete Nest/Egg\n18 Admin Read-Only\n19 Sembunyikan User Admin\n20 Full Admin Lockdown\n\nAdmin utama selalu bypass dan tetap memiliki akses penuh.</blockquote>`,{parse_mode:'HTML'});
  const [targetRaw,password,adminId]=input.split('|').map(v=>v.trim());if(!/^\d+$/.test(adminId))return bot.sendMessage(chatId,'✕ ID admin utama harus angka.');let target;try{target=parseSshTarget(targetRaw)}catch(e){return bot.sendMessage(chatId,`✕ ${escapeHTML(e.message)}`,{parse_mode:'HTML'})}
  lianixProtectSessions.set(String(userId),{target,password,adminId,at:Date.now()});
  return bot.sendMessage(chatId,`<b>PILIH PROTECT LEVEL</b>\n\nAdmin utama: <code>${adminId}</code>\nTarget: <code>${escapeHTML(target.display)}</code>\n\nPilih 1–20. Setiap level bisa dipasang satu per satu; level yang sudah aktif tetap tersimpan.`,{parse_mode:'HTML',reply_markup:protectKeyboard()});
});
bot.on('callback_query',async q=>{if(!String(q.data||'').startsWith('lxp:'))return;await bot.answerCallbackQuery(q.id).catch(()=>{});const key=String(q.from.id);if(q.data==='lxp:cancel'){lianixProtectSessions.delete(key);return safeEdit(bot,q.message.chat.id,q.message.message_id,'<b>INSTALL PROTECT DIBATALKAN</b>');}const level=Number(q.data.split(':')[1]);const ses=lianixProtectSessions.get(key);if(!ses||Date.now()-ses.at>10*60*1000)return safeEdit(bot,q.message.chat.id,q.message.message_id,'✕ Sesi protect kedaluwarsa. Jalankan /installprotect lagi.');if(!PROTECT_LEVELS[level])return;return applyProtectLevel(bot,q,ses,level);});

// ===== SAFE EDIT (FIX chat not found) =====
async function safeEdit(bot, chatId, messageId, text) {
  const opts={chat_id:chatId,message_id:messageId,parse_mode:"HTML"};
  let lastErr=null;
  for (let attempt=0; attempt<3; attempt++) {
    try {
      const r=await bot.editMessageText(text, opts);
      // Idempotent edit = status final sudah tampil, jadi JANGAN kirim pesan kedua.
      if (r == null || (r && r.unchanged === true)) return r || {ok:true,unchanged:true};
      // Hanya message yang benar-benar hilang yang membutuhkan fallback sendMessage.
      if (r && r.gone === true) throw Object.assign(new Error("message progress sudah tidak ada"), { __messageGone:true });
      if (r && r.ok === false) throw new Error(r.error || "editMessageText returned ok:false");
      if (r && r.skipped === true) throw new Error("editMessageText skipped");
      return r;
    } catch (e) {
      lastErr=e;
      const d=String(e?.response?.body?.description||e?.message||"");
      if (/message is not modified/i.test(d)) return {ok:true,unchanged:true};
      if (/there is no text in the message to edit|message has no text|message is a media message|caption/i.test(d)) {
        try {
          const r=await bot.editMessageCaption(text, opts);
          if (!(r && (r.ok===false || r.skipped===true))) return r;
        } catch (ce) { lastErr=ce; }
      }
      if (attempt<2) await new Promise(r=>setTimeout(r,350*(attempt+1)));
    }
  }
  // Output final tidak boleh dobel: bila kartu lama tidak bisa diedit, coba hapus
  // kartu progress dulu, BARU kirim satu kartu final baru.
  try { await bot.deleteMessage(chatId, messageId); } catch (_) {}
  try { return await bot.sendMessage(chatId,text,{parse_mode:"HTML"}); }
  catch (sendErr) {
    console.error("[safeEdit] edit+fallback send gagal:", sendErr?.message || sendErr, "edit:", lastErr?.message || lastErr);
    throw sendErr;
  }
}

// ===== HELPER ESCAPE HTML (WAJIB) =====
function escapeHTML(text = "") {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

// ===== UBAH HOSTNAME VPS =====
// Hanya mengubah hostname OS. Tidak menyentuh IP, interface jaringan, route, firewall,
// port SSH, sshd_config, atau DNS. /etc/hostname dan /etc/hosts dibackup + rollback otomatis.
bot.onText(/^\/ubahhostname(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id, userId = msg.from.id;
  if (getUserRole(userId) !== "ceo" && userId !== ownerId) return bot.sendMessage(chatId, "✗ Khusus Owner/CEO!");
  const input = match?.[1]?.trim() || "";
  if (!input || input.split("|").length < 3) return bot.sendMessage(chatId,
    `<blockquote expandable><b>PANDUAN UBAH HOSTNAME</b>\n\n`+
    `<b>Format:</b> <code>/ubahhostname host_target | password_vps | hostname_baru</code>\n\n`+
    `Fitur ini hanya mengubah nama mesin Linux. IP VPS, network interface, firewall, port SSH, dan konfigurasi sshd tidak disentuh.\n\n`+
    `<i>Contoh: /ubahhostname root@1.2.3.4:22 | passwordku | lianix-node-1</i></blockquote>`, { parse_mode: "HTML" });

  const parts = input.split("|");
  const targetRaw = parts.shift().trim();
  const password = parts.shift().trim();
  const hostnameRaw = parts.join("|").trim();
  if (!password) return bot.sendMessage(chatId, "✕ Password VPS kosong.");
  // Static hostname Linux: label sederhana, aman untuk /etc/hostname dan resolver lokal.
  if (!/^[A-Za-z0-9](?:[A-Za-z0-9.-]{0,61}[A-Za-z0-9])?$/.test(hostnameRaw) || /\.\.|--/.test(hostnameRaw)) {
    return bot.sendMessage(chatId, "✕ Hostname tidak valid. Maksimal 63 karakter, tidak boleh diawali/diakhiri titik atau minus, dan gunakan huruf, angka, titik, atau minus.");
  }
  let target;
  try { target = parseSshTarget(targetRaw); }
  catch (e) { return bot.sendMessage(chatId, `✕ ${escapeHTML(e.message)}`, { parse_mode: "HTML" }); }

  const st = await bot.sendMessage(chatId, `<b>UBAH HOSTNAME</b>\n\n<code>[░░░░░░░░░░] 0%</code>\nMenyiapkan koneksi...`, { parse_mode: "HTML" });
  const ui = createLiveInstallerCard(bot, chatId, st.message_id, { title: "UBAH HOSTNAME VPS", target: target.display, status: "Membangun koneksi SSH...", stage: "Persiapan", percent: 0 });
  await ui.flush();
  const conn = new Client();
  let done = false;
  const timer = setTimeout(async () => {
    if (done) return; done = true; try { conn.end(); } catch {};
    await ui.close();
    await safeEdit(bot, chatId, st.message_id, "✕ <b>UBAH HOSTNAME GAGAL</b>\n\nTimeout proses 90 detik. Tidak ada konfigurasi jaringan yang diubah.").catch(()=>{});
  }, 90000);
  if (timer.unref) timer.unref();

  conn.once("ready", async () => {
    try {
      await showVpsProfileInCard(ui, conn, target.display);
      await ui.setStatus("✅ SSH Terhubung! • Menyiapkan perubahan hostname...", true);
      await ui.setStage("Tahap 1/5 • Backup konfigurasi hostname", 20, true);
      const script = `set -Eeuo pipefail
NEW=${shellQuote(hostnameRaw)}
OLD="$(hostnamectl --static 2>/dev/null || hostname)"
STAMP="$(date +%s)-$$"
BK="/tmp/lianix-hostname-$STAMP"
mkdir -p "$BK"
cp -a /etc/hostname "$BK/hostname" 2>/dev/null || true
cp -a /etc/hosts "$BK/hosts" 2>/dev/null || true
CLOUD_PRESERVE=/etc/cloud/cloud.cfg.d/99-lianix-preserve-hostname.cfg
[ -f "$CLOUD_PRESERVE" ] && cp -a "$CLOUD_PRESERVE" "$BK/cloud-preserve" || true
rollback() {
  rc=$?
  echo "HOSTNAME_ROLLBACK"
  [ -f "$BK/hostname" ] && cp -a "$BK/hostname" /etc/hostname || true
  [ -f "$BK/hosts" ] && cp -a "$BK/hosts" /etc/hosts || true
  if [ -f "$BK/cloud-preserve" ]; then cp -a "$BK/cloud-preserve" "$CLOUD_PRESERVE"; else rm -f "$CLOUD_PRESERVE"; fi
  if command -v hostnamectl >/dev/null 2>&1; then hostnamectl set-hostname "$OLD" 2>/dev/null || true; else hostname "$OLD" 2>/dev/null || true; fi
  exit "$rc"
}
trap rollback ERR INT TERM
echo HOSTNAME_STEP_2
if command -v hostnamectl >/dev/null 2>&1; then hostnamectl set-hostname "$NEW"; else hostname "$NEW"; fi
printf '%s\\n' "$NEW" > /etc/hostname
if [ -d /etc/cloud/cloud.cfg.d ]; then printf 'preserve_hostname: true\\n' > "$CLOUD_PRESERVE"; fi
if [ -f /etc/hosts ]; then
  awk -v h="$NEW" 'BEGIN{done=0} $1=="127.0.1.1" && !done {$2=h; done=1} {print} END{if(!done) print "127.0.1.1\\t" h}' /etc/hosts > "$BK/hosts.new"
  cat "$BK/hosts.new" > /etc/hosts
fi
echo HOSTNAME_STEP_3
CUR="$(hostnamectl --static 2>/dev/null || hostname)"
[ "$CUR" = "$NEW" ]
[ "$(hostname 2>/dev/null)" = "$NEW" ] || [ "$(hostname -s 2>/dev/null)" = "\${NEW%%.*}" ]
[ "$(cat /etc/hostname 2>/dev/null | tr -d '\\r\\n')" = "$NEW" ]
if [ -f /etc/hosts ]; then grep -Eq "^127\\.0\\.1\\.1[[:space:]]+$NEW([[:space:]]|$)" /etc/hosts; fi
echo HOSTNAME_STEP_4
trap - ERR INT TERM
rm -rf "$BK"
echo "HOSTNAME_OK:$OLD:$NEW"`;

      const result = await runLianixRemoteScript(conn, script, {
        username: target.username,
        password,
        openTimeoutMs: 12000,
        firstOutputTimeoutMs: 15000,
        onLine: async (row, isErr) => {
          if (row.includes("HOSTNAME_STEP_2")) await ui.setStage("Tahap 2/5 • Menerapkan hostname baru", 45, true);
          else if (row.includes("HOSTNAME_STEP_3")) await ui.setStage("Tahap 3/5 • Memperbarui resolver lokal", 65, true);
          else if (row.includes("HOSTNAME_STEP_4")) await ui.setStage("Tahap 4/5 • Verifikasi /etc/hostname & /etc/hosts", 85, true);
          else if (row.includes("HOSTNAME_ROLLBACK")) await ui.add("Perubahan gagal; backup sedang dipulihkan otomatis.", { stderr: true });
          else if (!row.startsWith("HOSTNAME_OK:") && row !== "LIANIX_REMOTE_CHANNEL_OK") await ui.add(row, { stderr: isErr });
        }
      });

      if (result.code !== 0 || !result.out.includes("HOSTNAME_OK:")) throw new Error(result.errOut.trim() || result.out.trim() || `Exit ${result.code}`);
      done = true; clearTimeout(timer); try { conn.end(); } catch {};
      await ui.setStage("Tahap 5/5 • Hostname terverifikasi", 100, true);
      await ui.close();
      await safeEdit(bot, chatId, st.message_id,
        `✓ <b>HOSTNAME VPS BERHASIL DIUBAH</b>\n\n`+
        `Target: <code>${escapeHTML(target.display)}</code>\n`+
        `Hostname baru: <code>${escapeHTML(hostnameRaw)}</code>\n\n`+
        `<b>Tidak diubah:</b> IP VPS, port SSH, network interface, route, firewall, dan sshd_config.`);
    } catch (e) {
      if (done) return; done = true; clearTimeout(timer); try { conn.end(); } catch {};
      await ui.close();
      await safeEdit(bot, chatId, st.message_id, `✕ <b>UBAH HOSTNAME GAGAL</b>\n\n${escapeHTML(e.message || String(e))}\n\nBackup hostname/hosts dipulihkan otomatis jika perubahan sempat dimulai.`).catch(()=>{});
    }
  });
  conn.once("error", async e => {
    if (done) return; done = true; clearTimeout(timer);
    await ui.close();
    await safeEdit(bot, chatId, st.message_id, `✕ <b>UBAH HOSTNAME GAGAL</b>\n\nKoneksi SSH: ${escapeHTML(e.message)}`).catch(()=>{});
  });
  conn.connect({ host: target.host, port: target.port, username: target.username, password, readyTimeout: 20000, keepaliveInterval: 5000, keepaliveCountMax: 2 });
});

// ===== FIX KILL PANEL / RESOURCE RECOVERY =====
bot.onText(/^\/fixkillpanel(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId=msg.chat.id,userId=msg.from.id;
  if(getUserRole(userId)!=="ceo"&&userId!==ownerId)return bot.sendMessage(chatId,"✗ Khusus Owner/CEO!");
  const input=match?.[1]?.trim()||"";
  if(!input||input.split("|").length<2)return bot.sendMessage(chatId, `<blockquote expandable><b>PANDUAN FIX KILL PANEL</b>\n\n<b>Format:</b> <code>/fixkillpanel host_target | password_vps</code>\n\nFitur ini melakukan diagnosis resource, membersihkan journal/log Docker yang berlebihan, prune image/container yang sudah tidak dipakai, lalu merestart service panel yang aman untuk direstart. Server/container yang sedang berjalan tidak dihapus.</blockquote>`,{parse_mode:"HTML"});
  const [targetRaw,password]=input.split("|").map(v=>v.trim()); let target; try{target=parseSshTarget(targetRaw)}catch(e){return bot.sendMessage(chatId,`✕ ${escapeHTML(e.message)}`,{parse_mode:"HTML"})}
  const st=await bot.sendMessage(chatId,"<b>FIX KILL PANEL</b>\n\n<code>[░░░░░░░░░░] 0%</code>\nMenyiapkan diagnosis...",{parse_mode:"HTML"});
  const conn=new Client();let done=false;const timer=setTimeout(()=>{if(!done){done=true;try{conn.end()}catch{};safeEdit(bot,chatId,st.message_id,"✕ <b>FIX KILL PANEL GAGAL</b>\n\nTimeout SSH.").catch(()=>{})}},180000);
  conn.on("ready",async()=>{await sshProgressEdit(bot,chatId,st.message_id,"FIX KILL PANEL",20,"Tahap 1/5 • SSH terhubung. Membaca resource...");const cmd=`set -e\necho '=== BEFORE ==='\ndf -h / | tail -1\nfree -h | head -2\necho FIX_STEP_2\njournalctl --vacuum-time=7d >/dev/null 2>&1 || true\nfind /var/lib/docker/containers -name '*-json.log' -type f -size +100M -exec sh -c ': > "$1"' _ {} \\; 2>/dev/null || true\necho FIX_STEP_3\nif command -v docker >/dev/null 2>&1; then docker container prune -f >/dev/null 2>&1 || true; docker image prune -f >/dev/null 2>&1 || true; docker builder prune -f >/dev/null 2>&1 || true; fi\necho FIX_STEP_4\nsystemctl restart pteroq.service >/dev/null 2>&1 || true\nsystemctl restart wings >/dev/null 2>&1 || true\nsystemctl reload nginx >/dev/null 2>&1 || true\necho '=== AFTER ==='\ndf -h / | tail -1\nfree -h | head -2\necho FIX_OK`;
    const remote=target.username==="root"?cmd:`sudo -S -p '' bash -c ${shellQuote(cmd)}`;conn.exec(remote,(err,stream)=>{if(err){clearTimeout(timer);done=true;conn.end();return safeEdit(bot,chatId,st.message_id,`✕ ${escapeHTML(err.message)}`)};let out="",er="";stream.on("data",d=>{out+=d;const c=String(d);if(c.includes("FIX_STEP_2"))sshProgressEdit(bot,chatId,st.message_id,"FIX KILL PANEL",40,"Tahap 2/5 • Membersihkan log berlebih...");if(c.includes("FIX_STEP_3"))sshProgressEdit(bot,chatId,st.message_id,"FIX KILL PANEL",60,"Tahap 3/5 • Membersihkan resource Docker yang tidak terpakai...");if(c.includes("FIX_STEP_4"))sshProgressEdit(bot,chatId,st.message_id,"FIX KILL PANEL",80,"Tahap 4/5 • Memulihkan service panel...");});stream.stderr.on("data",d=>er+=d);stream.on("close",async code=>{clearTimeout(timer);done=true;conn.end();if(code===0&&out.includes("FIX_OK")){await sshProgressEdit(bot,chatId,st.message_id,"FIX KILL PANEL",100,"Tahap 5/5 • Diagnosis akhir selesai.");return safeEdit(bot,chatId,st.message_id,`✓ <b>FIX KILL PANEL SELESAI</b>\n\n<pre>${escapeHTML(out.replace(/FIX_STEP_[234]|FIX_OK/g,'').trim()).slice(0,2500)}</pre>`)}return safeEdit(bot,chatId,st.message_id,`✕ <b>FIX KILL PANEL GAGAL</b>\n\n${escapeHTML(er.trim()||`Exit ${code}`).slice(0,1400)}`)});if(target.username!=="root")stream.end(`${password}\n`);});
  }).on("error",e=>{clearTimeout(timer);if(done)return;done=true;safeEdit(bot,chatId,st.message_id,`✕ <b>FIX KILL PANEL GAGAL</b>\n\nKoneksi SSH: ${escapeHTML(e.message)}`).catch(()=>{})}).connect({host:target.host,port:target.port,username:target.username,password,readyTimeout:20000});
});

// ===== UNINSTALL PROTECT LIANIX =====
bot.onText(/^\/uninstallprotect(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId=msg.chat.id,userId=msg.from.id;
  if(getUserRole(userId)!=="ceo"&&userId!==ownerId)return bot.sendMessage(chatId,"✗ Khusus Owner/CEO!");
  const input=match?.[1]?.trim()||"";
  if(!input||input.split("|").length<2)return bot.sendMessage(chatId, `<blockquote expandable><b>PANDUAN UNINSTALL PROTECT • LIANIX</b>\n\n<b>Format:</b> <code>/uninstallprotect host_target | password_vps</code>\n\nMiddleware Lianix, registrasi Kernel, config level protect, dan hardening Lianix akan dicabut lalu cache Panel dibersihkan dan hasil diverifikasi.</blockquote>`,{parse_mode:"HTML"});
  const [targetRaw,password]=input.split("|").map(v=>v.trim());let target;try{target=parseSshTarget(targetRaw)}catch(e){return bot.sendMessage(chatId,`✕ ${escapeHTML(e.message)}`,{parse_mode:"HTML"})}
  const st=await bot.sendMessage(chatId,"<b>UNINSTALL PROTECT • LIANIX</b>\n\nMenyiapkan koneksi...",{parse_mode:"HTML"});
  const ui=createLiveInstallerCard(bot,chatId,st.message_id,{title:"UNINSTALL PROTECT • LIANIX",target:target.display,status:"Membangun koneksi SSH...",stage:"Persiapan",percent:0}); await ui.flush();
  const conn=new Client(); let done=false; const timer=setTimeout(async()=>{if(done)return;done=true;try{conn.end()}catch{};await ui.close();await safeEdit(bot,chatId,st.message_id,"✕ <b>UNINSTALL PROTECT GAGAL</b>\n\nTimeout proses 5 menit.").catch(()=>{});},300000); if(timer.unref)timer.unref();
  conn.on("ready",async()=>{
    await ui.setStatus("✅ SSH Terhubung! • Mencabut Protect Lianix...",true); await ui.setStage("Tahap 1/4 • Backup dan pemeriksaan",20,true);
    const script=`set -Eeuo pipefail
DIR=/var/www/pterodactyl
K="$DIR/app/Http/Kernel.php"
B="/tmp/lianix-unprotect-backup-$$"
mkdir -p "$B"
[ -f "$K" ] && cp -a "$K" "$B/Kernel.php" || true
[ -f "$DIR/app/Http/Middleware/LianixAdminProtect.php" ] && cp -a "$DIR/app/Http/Middleware/LianixAdminProtect.php" "$B/LianixAdminProtect.php" || true
[ -f "$DIR/resources/views/admin/index.blade.php" ] && cp -a "$DIR/resources/views/admin/index.blade.php" "$B/admin-index.blade.php" || true
[ -f /etc/lianix/protect.json ] && cp -a /etc/lianix/protect.json "$B/protect.json" || true
rollback(){ [ -f "$B/Kernel.php" ] && cp -af "$B/Kernel.php" "$K" || true; [ -f "$B/LianixAdminProtect.php" ] && { mkdir -p "$DIR/app/Http/Middleware"; cp -af "$B/LianixAdminProtect.php" "$DIR/app/Http/Middleware/LianixAdminProtect.php"; } || true; [ -f "$B/admin-index.blade.php" ] && cp -af "$B/admin-index.blade.php" "$DIR/resources/views/admin/index.blade.php" || true; [ -f "$B/protect.json" ] && { mkdir -p /etc/lianix; cp -af "$B/protect.json" /etc/lianix/protect.json; } || true; }
trap 'rc=$?; rollback; echo "UNPROTECT_FATAL:$rc" >&2' ERR
exec 9>/run/lock/lianix-panel-action.lock
flock -n 9 || { echo LIANIX_BUSY; exit 88; }
[ -f "$DIR/artisan" ] || { echo UNPROTECT_NO_PANEL; exit 10; }
echo UNPROTECT_STEP_2
if [ -f "$K" ] && grep -q 'LianixAdminProtect::class' "$K"; then
cat > /tmp/lianix-kernel-remove.php <<'PHP'
<?php
$p='/var/www/pterodactyl/app/Http/Kernel.php';$t=file_get_contents($p);$t=preg_replace('/^[\\t ]*\\\\Pterodactyl\\\\Http\\\\Middleware\\\\LianixAdminProtect::class,[\\t ]*\\R?/m','',$t);file_put_contents($p,$t);
PHP
php /tmp/lianix-kernel-remove.php; rm -f /tmp/lianix-kernel-remove.php
fi
ADMIN_INDEX="$DIR/resources/views/admin/index.blade.php"
if [ -f "$ADMIN_INDEX" ] && grep -q 'LIANIX_PROTECT_BADGE_START' "$ADMIN_INDEX"; then
  php -r '
$p="/var/www/pterodactyl/resources/views/admin/index.blade.php";
$t=file_get_contents($p);
$t=preg_replace("/\n?\{\{-- LIANIX_PROTECT_BADGE_START --\}\}.*?\{\{-- LIANIX_PROTECT_BADGE_END --\}\}\n?/s","\n",$t);
file_put_contents($p,$t);
' || { echo UNPROTECT_VIEW_FAIL; exit 15; }
fi
rm -f "$DIR/app/Http/Middleware/LianixAdminProtect.php" /etc/lianix/protect.json /etc/lianix/pterodactyl-main-admin-id /etc/sysctl.d/99-lianix-pterodactyl.conf
rmdir /etc/lianix 2>/dev/null || true
php -l "$K" >/dev/null
echo UNPROTECT_STEP_3
cd "$DIR"
timeout 180 php artisan optimize:clear
timeout 180 php artisan view:clear || true
sysctl --system >/dev/null 2>&1 || true
echo UNPROTECT_STEP_4
! grep -q 'LianixAdminProtect::class' "$K" || { echo UNPROTECT_VERIFY_FAIL; exit 11; }
[ ! -e "$DIR/app/Http/Middleware/LianixAdminProtect.php" ] || { echo UNPROTECT_VERIFY_FAIL; exit 12; }
! grep -q 'LIANIX_PROTECT_BADGE_START' "$DIR/resources/views/admin/index.blade.php" || { echo UNPROTECT_VERIFY_FAIL; exit 15; }
[ ! -e /etc/lianix/protect.json ] || { echo UNPROTECT_VERIFY_FAIL; exit 13; }
trap - ERR
rm -rf "$B"
echo UNPROTECT_OK`;
    try{
      const r=await runLianixRemoteScript(conn,script,{username:target.username,password,openTimeoutMs:12000,firstOutputTimeoutMs:15000,onLine:async(row,isErr)=>{if(row.includes('UNPROTECT_STEP_2'))await ui.setStage('Tahap 2/4 • Mencabut middleware & config',50,true);else if(row.includes('UNPROTECT_STEP_3'))await ui.setStage('Tahap 3/4 • Membersihkan cache',75,true);else if(row.includes('UNPROTECT_STEP_4'))await ui.setStage('Tahap 4/4 • Verifikasi',90,true);else if(!/^UNPROTECT_STEP_/.test(row)&&row!=='LIANIX_REMOTE_CHANNEL_OK')await ui.add(row,{stderr:isErr});}});
      clearTimeout(timer);done=true;try{conn.end()}catch{};const all=`${r.out||''}\n${r.errOut||''}`;
      if(r.code===0&&all.includes('UNPROTECT_OK')){await ui.setStage('Tahap 4/4 • Selesai',100,true);await ui.close();return safeEdit(bot,chatId,st.message_id,`✓ <b>UNINSTALL PROTECT SELESAI</b>\n\nTarget: <code>${escapeHTML(target.display)}</code>\nMiddleware, level protect, dan registrasi Kernel Lianix sudah dicabut dan diverifikasi.`);}
      const reason=all.includes('LIANIX_BUSY')?'VPS sedang dipakai proses panel lain.':all.includes('UNPROTECT_NO_PANEL')?'Panel Pterodactyl tidak ditemukan.':all.includes('UNPROTECT_VERIFY_FAIL')?'Verifikasi pencabutan Protect gagal.':(r.errOut?.trim()||`Exit ${r.code}`);await ui.close();return safeEdit(bot,chatId,st.message_id,`✕ <b>UNINSTALL PROTECT GAGAL</b>\n\n${escapeHTML(reason).slice(0,1800)}`);
    }catch(e){clearTimeout(timer);done=true;try{conn.end()}catch{};await ui.close().catch(()=>{});return safeEdit(bot,chatId,st.message_id,`✕ <b>UNINSTALL PROTECT GAGAL</b>\n\n${escapeHTML(e?.message||e)}`);}
  }).on('error',async e=>{clearTimeout(timer);if(done)return;done=true;await ui.close();await safeEdit(bot,chatId,st.message_id,`✕ <b>UNINSTALL PROTECT GAGAL</b>\n\nKoneksi SSH: ${escapeHTML(e.message)}`).catch(()=>{});}).connect({host:target.host,port:target.port,username:target.username,password,readyTimeout:20000,keepaliveInterval:10000});
});

bot.onText(/^\/fixcpu(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  // ⟠ hanya owner
  if (userId !== ownerId) {
    return bot.sendMessage(chatId, "✕ Command ini hanya bisa digunakan oleh owner.");
  }

  const text = match && match[1] ? match[1].trim() : "";

  if (!text || text.split("|").length < 2) {
    return bot.sendMessage(
      chatId,
`<blockquote>✕ <b>Format salah!</b>
Gunakan: <code>/fixcpu ip|pwvps</code></blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  const [vpsIP, vpsPassword] = text.split("|").map(v => v.trim());

  const ssh = new Client();

  const connSettings = {
    host: vpsIP,
    port: 22,
    username: "root",
    password: vpsPassword
  };

  const commandFixCPU = `
echo "⚒ Fix CPU Usage..." && \
for pid in $(ps -eo pid,%cpu --sort=-%cpu | awk '$2 > 70 {print $1}'); do sudo kill -9 $pid 2>/dev/null; done && \
sync && \
echo 3 | sudo tee /proc/sys/vm/drop_caches > /dev/null && \
sudo systemctl restart docker 2>/dev/null && \
sudo systemctl restart nginx 2>/dev/null && \
echo "✓ CPU berhasil dibersihkan"
`;

  try {

    await bot.sendMessage(
      chatId,
`<blockquote>⊙ <b>Memperbaiki penggunaan CPU VPS...</b></blockquote>`,
      { parse_mode: "HTML" }
    );

    await new Promise((resolve, reject) => {
      ssh.on("ready", resolve).on("error", reject).connect(connSettings);
    });

    let output = "";

    await new Promise((resolve, reject) => {
      ssh.exec(commandFixCPU, (err, stream) => {
        if (err) return reject(err);

        stream.on("close", resolve);

        stream.on("data", (data) => {
          output += data.toString();
        });

        stream.stderr.on("data", (data) => {
          output += data.toString();
        });
      });
    });

    ssh.end();

    return bot.sendMessage(
      chatId,
`<blockquote>✓ <b>Fix CPU selesai</b>

<code>${escapeHTML(output)}</code>
</blockquote>`,
      { parse_mode: "HTML" }
    );

  } catch (err) {
    ssh.end();

    return bot.sendMessage(
      chatId,
`<blockquote>✕ <b>Gagal memperbaiki CPU</b>

<code>${escapeHTML(err.message)}</code>
</blockquote>`,
      { parse_mode: "HTML" }
    );
  }
});
// Prevent the same Telegram command from starting two SSH installers in
// parallel (e.g. duplicate update/process). A completed run releases the lock.
const installPanelInFlight = global.__LIANIX_INSTALLPANEL_INFLIGHT__ || (global.__LIANIX_INSTALLPANEL_INFLIGHT__ = new Set());
const installPanelProcessLocks = global.__LIANIX_INSTALLPANEL_PROCESS_LOCKS__ || (global.__LIANIX_INSTALLPANEL_PROCESS_LOCKS__ = new Map());
const REGISTERED_INSTALLPANEL_BOTS = global.__LIANIX_INSTALLPANEL_BOTS__ || (global.__LIANIX_INSTALLPANEL_BOTS__ = new WeakSet());

// Guard ekstra: walaupun module ini sempat di-load ulang oleh loader/plugin lain,
// /installpanel hanya boleh punya satu handler untuk satu instance bot.
if (REGISTERED_INSTALLPANEL_BOTS.has(bot)) {
  console.warn('[installpanel] handler sudah terdaftar untuk bot ini; registrasi dilewati.');
  return;
}
REGISTERED_INSTALLPANEL_BOTS.add(bot);

bot.onText(/^\/installpanel(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const lockPath = path.join(require("os").tmpdir(), `lianix-installpanel-${String(chatId).replace(/[^0-9-]/g, "_")}.lock`);
  if (installPanelInFlight.has(chatId) || installPanelProcessLocks.has(chatId)) {
    return bot.sendMessage(chatId, "⚠ Install Panel sedang berjalan. Tunggu proses yang sedang berjalan selesai.");
  }
  try {
    // Bersihkan lock yatim setelah bot/crash sebelumnya. Lock lama tidak boleh
    // membuat /installpanel mati permanen setelah restart.
    if (fs.existsSync(lockPath)) {
      try {
        const rawLock=fs.readFileSync(lockPath,"utf8").trim().split(/\s+/);
        const oldPid=Number(rawLock[0]); const oldAt=Number(rawLock[1]);
        let alive=false;
        if (Number.isInteger(oldPid) && oldPid>1) { try { process.kill(oldPid,0); alive=true; } catch {} }
        const stale=!alive || !Number.isFinite(oldAt) || (Date.now()-oldAt > 60*60*1000);
        if (stale) fs.unlinkSync(lockPath);
      } catch { try { fs.unlinkSync(lockPath); } catch {} }
    }
    const fd = fs.openSync(lockPath, "wx");
    fs.writeFileSync(fd, `${process.pid}\n${Date.now()}\n`);
    fs.closeSync(fd);
    installPanelProcessLocks.set(chatId, lockPath);
  } catch (e) {
    return bot.sendMessage(chatId, "⚠ Install Panel sudah berjalan di proses bot lain. Tunggu sampai selesai.");
  }
  installPanelInFlight.add(chatId);
  try {
  const userId = msg.from?.id;
  const rolePanel = getUserRole(userId);
  if (userId !== ownerId && rolePanel !== "ceo") {
    return bot.sendMessage(chatId, "⟡ Fitur install panel khusus CEO/owner.");
  }

  const text = match && match[1] ? match[1].trim() : "";
  if (!text || text.split("|").length < 4) {
    return bot.sendMessage(chatId,
      `<blockquote expandable><b>PANDUAN INSTALL PANEL</b>\n\n`+
      `<b>Format:</b>\n<code>/installpanel host_target | password_vps | domain_panel | domain_node | ram_mb</code>\n\n`+
      `<b>host_target</b> = alamat SSH VPS, contoh <code>1.2.3.4</code>, <code>1.2.3.4:2222</code>, <code>root@1.2.3.4</code>, atau <code>ubuntu@1.2.3.4:2222</code>.\n`+
      `<b>password_vps</b> = password SSH VPS.\n`+
      `<b>domain_panel</b> = domain untuk dashboard Pterodactyl, contoh <code>panel.domain.com</code>.\n`+
      `<b>domain_node</b> = domain Wings/node, wajib berbeda dari domain panel.\n`+
      `<b>ram_mb</b> = batas RAM node dalam MB; opsional, default <code>0</code> = mengikuti kapasitas installer.\n\n`+
      `<b>Sebelum install:</b>\n1. Gunakan VPS KVM/Dedicated Ubuntu/Debian yang bersih.\n2. Arahkan A record kedua domain ke IP VPS dan tunggu DNS aktif.\n3. Pastikan port SSH benar dan akun mempunyai root/sudo.\n4. Jangan memakai domain panel dan node yang sama.\n\n`+
      `<b>Proses:</b> pre-flight → dependency → database/webserver → Panel → admin → Docker/Wings → Location/Node → Egg → verifikasi.\n\n`+
      `<i>Contoh: /installpanel root@1.2.3.4:22 | passwordku | panel.domain.com | node.domain.com | 0</i></blockquote>`,
      {parse_mode:'HTML'}
    );
  }

  const parts = text.split("|").map(v => v.trim());
  const [targetRaw, vpsPassword, domainpanelRaw, domainnodeRaw] = parts;
  const ramserver = parts[4] || "0";
  let sshTarget;
  try { sshTarget = parseSshTarget(targetRaw); } catch (e) { return bot.sendMessage(chatId, `✕ ${escapeHTML(e.message)}`, {parse_mode:'HTML'}); }
  const vpsIP = sshTarget.host;
  const duckDomains = (process.env.DUCKDNS_DOMAINS || "mambo-noir,nodemambo-noir").split(",").map(v => v.trim()).filter(Boolean);
  const domainpanel = (domainpanelRaw.toLowerCase() === "auto" ? `${duckDomains[0] || "mambo-noir"}.duckdns.org` : domainpanelRaw).replace(/^https?:\/\//i, "").replace(/\/$/, "").toLowerCase();
  const domainnode = (domainnodeRaw.toLowerCase() === "auto" ? `${duckDomains[1] || "nodemambo-noir"}.duckdns.org` : domainnodeRaw).replace(/^https?:\/\//i, "").replace(/\/$/, "").toLowerCase();
  const isValidFqdn = (value) => {
    const v = String(value || "").trim();
    if (!v || v.length > 253 || v.includes("..")) return false;
    if (!/^[a-z0-9.-]+$/i.test(v)) return false;
    const labels = v.split(".");
    if (labels.length < 2) return false;
    return labels.every(label => label.length >= 1 && label.length <= 63 && /^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i.test(label));
  };
  if (!isValidFqdn(domainpanel)) return bot.sendMessage(chatId, "✕ Domain Panel tidak valid. Gunakan FQDN seperti panel.domain.com tanpa path/port.");
  if (!isValidFqdn(domainnode)) return bot.sendMessage(chatId, "✕ Domain Node tidak valid. Gunakan FQDN seperti node.domain.com tanpa path/port.");
  if (domainpanel === domainnode) return bot.sendMessage(chatId, "✕ Domain Panel dan Domain Node wajib berbeda.");
  if ((domainpanelRaw.toLowerCase() === "auto" || domainnodeRaw.toLowerCase() === "auto") && !process.env.DUCKDNS_TOKEN) {
    return bot.sendMessage(chatId, "✕ Mode auto DuckDNS membutuhkan DUCKDNS_TOKEN.");
  }
  if (process.env.DUCKDNS_TOKEN && (domainpanelRaw.toLowerCase() === "auto" || domainnodeRaw.toLowerCase() === "auto")) {
    const axiosDuck = require("axios");
    const updateNames = [duckDomains[0] || "mambo-noir", duckDomains[1] || "nodemambo-noir"];
    for (const dn of updateNames) {
      await axiosDuck.get("https://www.duckdns.org/update", { params: { domains: dn, token: process.env.DUCKDNS_TOKEN, ip: vpsIP }, timeout: 15000, responseType: "text" });
    }
  }
  // Password ADP selalu diawali lianix- dan memenuhi aturan password Panel
  // (huruf besar, huruf kecil, dan angka) tanpa membocorkan credential di log.
  const alphabetLower = "abcdefghijklmnopqrstuvwxyz";
  const alphabetUpper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  const digits = "0123456789";
  const pick = (chars) => chars[crypto.randomInt(0, chars.length)];
  const shuffle = (value) => value.split("").sort(() => crypto.randomInt(-1, 2)).join("");
  const random = shuffle(
    pick(alphabetLower) + pick(alphabetUpper) + pick(digits) +
    crypto.randomBytes(2).toString("hex").slice(0, 2)
  );
  const panelUsername = "adp";
  const panelPassword = `lianix-${random}`;
  const panelEmail = `lianix@${domainpanel}`;
  const dbPassword = crypto.randomBytes(18).toString("hex");
  const firstName = "Lianix";
  const lastName = "Owdc";

  const progress = await bot.sendMessage(chatId,
    `<b>🚀 MEMPROSES INSTALL PANEL...</b>\n<b>Target:</b> <code>${escapeHTML(sshTarget.display)}</code>\n<b>Panel:</b> <code>${escapeHTML(domainpanel)}</code>\n<b>Node:</b> <code>${escapeHTML(domainnode)}</code>\n\n<i>Sedang membangun koneksi SSH ke VPS untuk memasang Pterodactyl...</i>`,
    { parse_mode: "HTML" });

  const INSTALL_STAGES = [
    "Persiapan & pemeriksaan VPS",
    "Update repository & dependency",
    "MariaDB + Redis + PHP-FPM",
    "Install Pterodactyl Panel resmi",
    "Konfigurasi database & environment",
    "Membuat akun admin",
    "Nginx + Queue Worker + Scheduler",
    "Install Docker + Wings resmi",
    "Membuat Location + Node",
    "Install Nest + Egg runtime",
    "Generate config Wings",
    "Verifikasi akhir"
  ];
  let currentStage = 1;
  let lastProgress = "";
  const panelUi = createLiveInstallerCard(bot, chatId, progress.message_id, {
    title: "INSTALL PANEL LIANIX",
    target: `${sshTarget.display} • ${domainpanel} • ${domainnode}`,
    status: "Membangun koneksi SSH...",
    stage: `Tahap 1/${INSTALL_STAGES.length} • ${INSTALL_STAGES[0]}`,
    percent: 4
  });
  await panelUi.flush();

  const stageFromText = (text) => {
    const raw = String(text || "").replace(/^(?:LIANIX_STEP|LIANIX_STEP):/i, "").trim();
    const x = raw.toLowerCase();
    let detected = currentStage;
    if (/verifikasi akhir|final verification|install_ok|semua tahap/.test(x)) detected = 12;
    else if (/config wings|generate config|konfigurasi wings/.test(x)) detected = 11;
    else if (/nest|egg|runtime/.test(x)) detected = 10;
    else if (/location|membuat node|node lianix|allocation/.test(x)) detected = 9;
    else if (/docker|binary wings|install wings|memasang wings|mengunduh binary wings/.test(x)) detected = 8;
    else if (/queue|scheduler|web server|nginx.*queue|konfigurasi nginx/.test(x)) detected = 7;
    else if (/akun admin|admin adp|membuat akun admin/.test(x)) detected = 6;
    else if (/database|environment|migration|migrasi/.test(x)) detected = 5;
    else if (/pterodactyl panel|panel resmi|panel sudah diekstrak/.test(x)) detected = 4;
    else if (/mariadb|redis|php-fpm|composer/.test(x)) detected = 3;
    else if (/apt|repository|dependency/.test(x)) detected = 2;
    else if (/cek selesai|pemeriksaan vps|preflight|storage|inode|ssh tersambung/.test(x)) detected = 1;
    currentStage = Math.max(currentStage, detected);
    return Math.max(1, Math.min(INSTALL_STAGES.length, currentStage));
  };

  const updateProgress = (text) => {
    const raw = String(text || "").trim();
    if (!raw || raw === lastProgress) return Promise.resolve();
    lastProgress = raw;
    const clean = raw.replace(/^LIANIX_STEP:/i, "").trim();
    const stage = stageFromText(raw);
    const finalDone = stage === INSTALL_STAGES.length && /(?:selesai|berhasil|complete|done)/i.test(raw);
    let pct = finalDone ? 100 : (stage === 12 ? 96 : Math.max(4, Math.min(94, Math.round((stage / 12) * 94))));
    // Tahap Docker/Wings sebelumnya terlihat membeku di 63% karena banyak subproses
    // tetap berada pada stage yang sama. Naikkan progress sesuai sub-tahap nyata.
    if (stage === 8) {
      if (/memeriksa docker/i.test(clean)) pct = Math.max(pct, 64);
      if (/docker.*(?:aktif|selesai|siap)/i.test(clean)) pct = Math.max(pct, 66);
      if (/menyiapkan binary wings/i.test(clean)) pct = Math.max(pct, 67);
      if (/mengunduh binary wings|download wings/i.test(clean)) pct = Math.max(pct, 69);
      if (/binary wings resmi tervalidasi/i.test(clean)) pct = Math.max(pct, 71);
    }
    panelUi.setStage(`Tahap ${stage}/12 • ${INSTALL_STAGES[stage-1]}`, pct, /^LIANIX_STEP:/i.test(raw));
    if (/ssh tersambung/i.test(clean)) panelUi.setStatus("✅ SSH Terhubung! • Installer sedang berjalan...", true);
    // Marker tahap sudah tercermin di judul tahap; baris output biasa masuk live terminal.
    if (!/^(?:LIANIX_STEP|LIANIX_STEP):/i.test(raw)) panelUi.add(clean, { stderr:/^(?:ERR|LIANIX_FATAL)/i.test(clean) });
    else panelUi.add(`→ ${clean}`);
    return Promise.resolve();
  };

  const requestedPort = sshTarget.port;
  const portCandidates = [Number(requestedPort || 22)];
  const validPorts = [...new Set(portCandidates)].filter(p => Number.isInteger(p) && p >= 1 && p <= 65535);
  if (!validPorts.length) {
    return bot.sendMessage(chatId, "✕ Port SSH tidak valid. Gunakan port 1-65535.");
  }
  let sshPort = validPorts[0];
  let connSettings = { host: vpsIP, port: sshPort, username: sshTarget.username || "root", password: vpsPassword, readyTimeout: 20000, keepaliveInterval: 10000, keepaliveCountMax: 3 };
  const ssh = new Client();
  const q = value => `'${String(value).replace(/'/g, "'\\''")}'`;

  // The remote script intentionally uses only official Pterodactyl release files,
  // official Composer bootstrap, and the official Wings binary. No third-party
  // create-node/wings scripts are fetched or executed.
  const script = `
set -Eeuo pipefail
trap '__li_rc=$?; echo "LIANIX_FATAL:exit=$__li_rc line=\${BASH_LINENO[0]:-?} cmd=\${BASH_COMMAND:-unknown}" >&2' ERR
export DEBIAN_FRONTEND=noninteractive
export CI=1
export NONINTERACTIVE=1
export TERM=dumb
export TMPDIR=/tmp
INSTALLER_VERSION="lianix-pterodactyl-2026-08-27"
echo "LIANIX_INSTALLER_VERSION:$INSTALLER_VERSION"
PANEL_DOMAIN=${q(domainpanel)}
PANEL_URL="http://$PANEL_DOMAIN"
PANEL_USER=${q(panelUsername)}
PANEL_PASS=${q(panelPassword)}
PANEL_EMAIL=${q(panelEmail)}
DB_PASS=${q(dbPassword)}
export PANEL_USER PANEL_PASS PANEL_EMAIL DB_PASS
NODE_DOMAIN=${q(domainnode)}
RAM_LIMIT=${q(ramserver)}
SSH_PUBLIC_IP=${q(vpsIP)}

# One installer per VPS. A second bot instance must not run a competing SSH install.
exec 9>/run/lock/lianix-panel-action.lock
if ! flock -n 9; then
  echo "LIANIX_BUSY: VPS sedang menjalankan proses panel lain; proses kedua dihentikan."
  exit 88
fi

if ! command -v apt-get >/dev/null 2>&1; then
  echo "UNSUPPORTED_OS: install flow supports Debian/Ubuntu only"
  exit 20
fi

echo "=== LIANIX VPS PRE-FLIGHT ==="
echo "User     | $(id -un)"
if [ -r /etc/os-release ]; then . /etc/os-release; echo "OS       | \${PRETTY_NAME:-unknown}"; fi
echo "Kernel   | $(uname -r)"
echo "CPU      | $(lscpu 2>/dev/null | awk -F: '/Model name/{gsub(/^[ \t]+/,"",$2);print $2;exit}')"
echo "Memory   | $(free -h | awk '/Mem:/{print $3 " / " $2}')"
echo "Disk     | $(df -h / | awk 'NR==2{print $3 " / " $2 " (" $5 ")"}')"
echo "SSH      | \${PANEL_DOMAIN:-panel} via $(hostname -I 2>/dev/null | awk '{print $1}')"
VIRT=$(systemd-detect-virt 2>/dev/null || true)
echo "Virt     | \${VIRT:-none}"
if systemd-detect-virt --container >/dev/null 2>&1; then
  echo "VPS_CONTAINER_WARNING: target terdeteksi sebagai container ($VIRT). Installer tetap lanjut dan akan memverifikasi Docker/Wings secara nyata."
fi
echo "PRE-FLIGHT OK"

# Preflight: curl error 23 usually means the destination cannot be written
# (disk/inode exhaustion or a non-writable temp directory). Detect it early.
mkdir -p /tmp
touch /tmp/lianix-write-test && rm -f /tmp/lianix-write-test
ROOT_AVAIL_KB=$(df -Pk / | awk 'NR==2 {print $4}')
INODE_AVAIL=$(df -Pi / | awk 'NR==2 {print $4}')
if [ -z "$ROOT_AVAIL_KB" ] || [ "$ROOT_AVAIL_KB" -lt 1048576 ]; then
  echo "PREFLIGHT_ERROR: root filesystem has less than 1 GiB free."
  df -h /
  exit 22
fi
if [ -z "$INODE_AVAIL" ] || [ "$INODE_AVAIL" -lt 10000 ]; then
  echo "PREFLIGHT_ERROR: root filesystem is almost out of inodes."
  df -ih /
  exit 23
fi

echo "LIANIX_STEP:Cek selesai — memperbaiki APT dan install dependency..."

wait_apt_locks() {
  for i in $(seq 1 60); do
    if ! fuser /var/lib/dpkg/lock-frontend /var/lib/dpkg/lock /var/lib/apt/lists/lock /var/cache/apt/archives/lock >/dev/null 2>&1; then return 0; fi
    sleep 2
  done
  echo "APT_LOCK_TIMEOUT: apt/dpkg masih dikunci proses lain setelah 120 detik. Tidak akan memaksa atau menjalankan apt bersamaan."
  return 1
}
repair_apt_cache() {
  mkdir -p /var/cache/apt/archives/partial /var/lib/apt/lists/partial
  chmod 755 /var/cache/apt /var/lib/apt/lists
  rm -f /var/cache/apt/pkgcache.bin /var/cache/apt/srcpkgcache.bin 2>/dev/null || true
  rm -rf /var/lib/apt/lists/* 2>/dev/null || true
  timeout 300 dpkg --configure -a || true
  apt-get clean || true
}
apt_update_safe() {
  local n=1
  while [ "$n" -le 4 ]; do
    if ! wait_apt_locks; then return 1; fi
    echo "LIANIX_STEP:APT update — sinkronisasi repository (percobaan $n/4)..."
    if timeout 600 apt-get -o DPkg::Lock::Timeout=120 -o Dir::Cache::pkgcache="" -o Dir::Cache::srcpkgcache="" -o Acquire::Retries=3 update >/tmp/lianix-apt-update.log 2>&1; then
      echo "LIANIX_STEP:APT update selesai — repository siap."
      return 0
    fi
    echo "APT_UPDATE_DETAIL:"
    tail -n 30 /tmp/lianix-apt-update.log 2>/dev/null || true
    echo "LIANIX_APT_RETRY:$n — memperbaiki cache APT lalu mencoba lagi..."
    repair_apt_cache
    rm -f /var/cache/apt/pkgcache.bin /var/cache/apt/srcpkgcache.bin 2>/dev/null || true
    n=$((n+1))
    sleep 2
  done
  echo "APT_ERROR: apt-get update gagal setelah 4 percobaan atau APT masih dikunci proses lain."
  exit 24
}
apt_install_safe() {
  local n=1
  while [ "$n" -le 3 ]; do
    if ! wait_apt_locks; then return 1; fi
    echo "LIANIX_STEP:Memasang dependency sistem — percobaan $n/3..."
    if timeout 1200 apt-get -o DPkg::Lock::Timeout=120 -o Dir::Cache::pkgcache="" -o Dir::Cache::srcpkgcache="" install -y "$@" >/tmp/lianix-apt-install.log 2>&1; then
      echo "LIANIX_STEP:Dependency sistem selesai dipasang."
      return 0
    fi
    echo "APT_INSTALL_DETAIL:"
    tail -n 40 /tmp/lianix-apt-install.log 2>/dev/null || true
    echo "LIANIX_APT_INSTALL_RETRY:$n — memperbaiki state dpkg/APT lalu mencoba lagi..."
    timeout 300 dpkg --configure -a || true
    repair_apt_cache
    if ! apt_update_safe; then return 1; fi
    n=$((n+1))
  done
  echo "APT_ERROR: apt-get install gagal setelah 3 percobaan atau APT masih dikunci proses lain."
  exit 25
}
repair_apt_cache
apt_update_safe
# APT sometimes leaves a transient pkgcache rename behind on VPS images.
# Remove only the optional binary caches; package lists themselves stay intact.
rm -f /var/cache/apt/pkgcache.bin /var/cache/apt/srcpkgcache.bin 2>/dev/null || true
# PHP harus >= 8.2 untuk Panel Pterodactyl modern. Ubuntu 22.04 defaultnya 8.1,
# jadi pasang PHP 8.3 dari PPA resmi komunitas Ondrej seperti panduan Pterodactyl.
. /etc/os-release
PHP_PACKAGES=(php php-cli php-gd php-mysql php-mbstring php-bcmath php-xml php-curl php-zip php-fpm)
if [ "\${ID:-}" = "ubuntu" ] && [ "\${VERSION_ID:-}" = "22.04" ]; then
  apt_install_safe software-properties-common
  if ! grep -Rqs '^deb .*ondrej/php' /etc/apt/sources.list /etc/apt/sources.list.d 2>/dev/null; then
    timeout 180 add-apt-repository -y ppa:ondrej/php >/tmp/lianix-php-repo.log 2>&1 || { cat /tmp/lianix-php-repo.log; exit 27; }
    apt_update_safe
  fi
  PHP_PACKAGES=(php8.3 php8.3-common php8.3-cli php8.3-gd php8.3-mysql php8.3-mbstring php8.3-bcmath php8.3-xml php8.3-curl php8.3-zip php8.3-fpm)
elif [ "\${ID:-}" = "ubuntu" ] && [ "\${VERSION_ID:-}" = "24.04" ]; then
  PHP_PACKAGES=(php8.3 php8.3-common php8.3-cli php8.3-gd php8.3-mysql php8.3-mbstring php8.3-bcmath php8.3-xml php8.3-curl php8.3-zip php8.3-fpm)
fi
apt_install_safe curl ca-certificates gnupg unzip tar git nginx mariadb-server redis-server certbot python3-certbot-nginx cron openssl util-linux "\${PHP_PACKAGES[@]}"
PHP_OK=$(php -r 'echo version_compare(PHP_VERSION,"8.2.0",">=") ? "1" : "0";' 2>/dev/null || echo 0)
[ "$PHP_OK" = "1" ] || { echo "PHP_VERSION_ERROR: Pterodactyl membutuhkan PHP >= 8.2, terpasang: $(php -v 2>/dev/null | head -1)"; exit 28; }
echo "LIANIX_STEP:Dependency selesai — PHP $(php -r 'echo PHP_VERSION;'), MariaDB/Redis siap diaktifkan..."
for svc in mariadb redis-server cron; do
  if ! timeout 60 systemctl enable --now "$svc" >/tmp/lianix-$svc.log 2>&1; then
    echo "SERVICE_ERROR:$svc gagal aktif setelah dependency selesai"
    cat "/tmp/lianix-$svc.log" 2>/dev/null || true
    systemctl status "$svc" --no-pager -l 2>/dev/null || true
    exit 26
  fi
done
# Nginx sengaja belum diwajibkan aktif di sini. VPS bekas install gagal dapat
# menyisakan konfigurasi Nginx lama yang invalid. Konfigurasi panel akan dibuat
# ulang dan diuji dengan nginx -t pada tahap web server sebelum service direstart.
echo "LIANIX_STEP:MariaDB dan Redis aktif — menyiapkan Composer..."

if ! command -v composer >/dev/null 2>&1; then
  curl -fL --retry 3 --retry-delay 2 --connect-timeout 15 --max-time 120 \
    -o /tmp/composer-setup.php https://getcomposer.org/installer
  timeout 180 php /tmp/composer-setup.php --install-dir=/usr/local/bin --filename=composer
  rm -f /tmp/composer-setup.php
  chmod +x /usr/local/bin/composer
fi

echo "LIANIX_STEP:Mengunduh release resmi Pterodactyl Panel dari GitHub..."
mkdir -p /var/www/pterodactyl
cd /var/www/pterodactyl
if [ -f .env ]; then cp .env ".env.backup.$(date +%s)"; fi
PANEL_RELEASE_URL="https://github.com/pterodactyl/panel/releases/latest/download/panel.tar.gz"
curl -fL --retry 5 --retry-all-errors --retry-delay 3 --connect-timeout 20 --max-time 900 \
  -o panel.tar.gz "$PANEL_RELEASE_URL"
tar -tzf panel.tar.gz >/tmp/lianix-panel-archive-list.log 2>&1 || { echo "PANEL_ARCHIVE_ERROR: release Panel bukan tar.gz valid"; cat /tmp/lianix-panel-archive-list.log; exit 27; }
tar -tzf panel.tar.gz | grep -qx 'artisan' || { echo "PANEL_ARCHIVE_ERROR: file artisan tidak ada"; exit 27; }
tar -tzf panel.tar.gz | grep -qx 'composer.json' || { echo "PANEL_ARCHIVE_ERROR: composer.json tidak ada"; exit 27; }
tar -xzf panel.tar.gz
rm -f panel.tar.gz
php -r '$j=json_decode(file_get_contents("composer.json"),true);$n=strtolower((string)($j["name"]??""));if($n!=="pterodactyl/panel"){fwrite(STDERR,"Unexpected package: ".$n."\n");exit(1);}' || { echo "PANEL_ARCHIVE_ERROR: package bukan pterodactyl/panel"; exit 27; }
[ -f artisan ] && [ -f .env.example ] && [ -d resources/views ] || { echo "PANEL_ARCHIVE_ERROR: struktur release Panel tidak lengkap"; exit 27; }
chmod -R 755 storage bootstrap/cache
echo "LIANIX_STEP:Release resmi Pterodactyl Panel tervalidasi."

DBCMD="mariadb"
timeout 90 systemctl enable --now mariadb
for i in $(seq 1 30); do
  if $DBCMD -u root -e "SELECT 1;" >/dev/null 2>&1; then break; fi
  sleep 1
done
$DBCMD -u root -e "CREATE DATABASE IF NOT EXISTS panel CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
$DBCMD -u root <<SQL
CREATE USER IF NOT EXISTS 'pterodactyl'@'127.0.0.1' IDENTIFIED BY '$DB_PASS';
CREATE USER IF NOT EXISTS 'pterodactyl'@'localhost' IDENTIFIED BY '$DB_PASS';
ALTER USER 'pterodactyl'@'127.0.0.1' IDENTIFIED BY '$DB_PASS';
ALTER USER 'pterodactyl'@'localhost' IDENTIFIED BY '$DB_PASS';
GRANT ALL PRIVILEGES ON panel.* TO 'pterodactyl'@'127.0.0.1';
GRANT ALL PRIVILEGES ON panel.* TO 'pterodactyl'@'localhost';
FLUSH PRIVILEGES;
SQL
if ! $DBCMD -h 127.0.0.1 -P 3306 -u pterodactyl -p"$DB_PASS" panel -Nse "SELECT 1;" >/dev/null 2>/tmp/lianix-db-auth.err; then
  echo "DB_ERROR: akun pterodactyl tidak bisa login setelah dibuat."
  cat /tmp/lianix-db-auth.err 2>/dev/null || true
  exit 40
fi

echo "LIANIX_STEP:Panel sudah diekstrak — memasang dependency Composer..."
cp .env.example .env
# Do not execute Pterodactyl Composer lifecycle hooks here. Some releases/hooks
# can start interactive environment setup commands before our deterministic .env
# configuration is applied. We configure the environment ourselves below.
COMPOSER_ALLOW_SUPERUSER=1 timeout 1200 composer install --no-dev --optimize-autoloader --no-interaction --no-progress --no-scripts
echo "LIANIX_STEP:Composer selesai — mengatur environment, database, dan migration Panel..."
# Stop an orphaned interactive Panel setup left by an earlier failed run.
# The bracket form prevents the cleanup command itself from matching.
for _pat in 'p:environment:setup' 'p:environment:database'; do
  while IFS= read -r _pid; do
    [ -n "$_pid" ] || continue
    kill "$_pid" 2>/dev/null || true
  done < <(pgrep -f "[p]hp artisan \${_pat}" 2>/dev/null || true)
done
# Create APP_KEY directly so no artisan command can stop for an APP_KEY confirmation.
# This also makes retries deterministic and preserves an existing key on reinstall.
if ! grep -qE '^APP_KEY=base64:' .env 2>/dev/null; then
  APP_KEY_B64=$(openssl rand -base64 32 | tr -d '\n')
  sed -i "s|^APP_KEY=.*|APP_KEY=base64:\${APP_KEY_B64}|" .env
fi

set_env() {
  key="$1"; value="$2"
  # Keep the variable expansion inside the remote Bash script. Do NOT escape
  # $key/$value here: this function must actually modify .env.
  if grep -qE "^$key=" .env; then
    sed -i "s|^$key=.*|$key=$value|" .env
  else
    printf '\n%s=%s\n' "$key" "$value" >> .env
  fi
}
# Guard against accidental interactive environment setup commands from future edits.
# The installer itself must remain fully non-interactive.
set_env APP_ENV production
set_env APP_DEBUG false
set_env APP_URL "$PANEL_URL"
set_env APP_TIMEZONE Asia/Jakarta
set_env APP_SERVICE_AUTHOR "$PANEL_EMAIL"
set_env CACHE_DRIVER file
set_env SESSION_DRIVER file
set_env QUEUE_CONNECTION redis
set_env REDIS_HOST 127.0.0.1
set_env REDIS_PASSWORD ''
set_env REDIS_PORT 6379
set_env DB_CONNECTION mysql
set_env DB_HOST 127.0.0.1
set_env DB_PORT 3306
set_env DB_DATABASE panel
set_env DB_USERNAME pterodactyl
set_env DB_PASSWORD "$DB_PASS"
set_env MAIL_FROM_ADDRESS "$PANEL_EMAIL"

# Hard guard: this installer must never invoke the interactive environment wizard.
# Also make sure Laravel sees the intended TCP database settings before migrations.
if grep -qE "^DB_HOST=localhost$|^DB_USERNAME=root$" .env; then
  echo "DB_CONFIG_ERROR: invalid Laravel database configuration detected; repairing automatically..."
  set_env DB_HOST 127.0.0.1
  set_env DB_PORT 3306
  set_env DB_DATABASE panel
  set_env DB_USERNAME pterodactyl
  set_env DB_PASSWORD "$DB_PASS"
fi

# Verify the exact database credentials that Laravel will use. If the
# pterodactyl account is missing, has stale credentials, or is using an
# incompatible socket/plugin configuration, repair it automatically before

DB_AUTH_OK=0
if "$DBCMD" -h 127.0.0.1 -P 3306 -u pterodactyl "-p$DB_PASS" panel -Nse "SELECT 1;" >/dev/null 2>/tmp/lianix-db-auth.err; then
  DB_AUTH_OK=1
fi
if [ "$DB_AUTH_OK" -ne 1 ]; then
  echo "LIANIX_STEP:Database login gagal — bot memperbaiki akun database pterodactyl otomatis..."
  "$DBCMD" -u root -e "CREATE DATABASE IF NOT EXISTS panel CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
  "$DBCMD" -u root <<SQL
CREATE USER IF NOT EXISTS 'pterodactyl'@'127.0.0.1' IDENTIFIED BY '$DB_PASS';
CREATE USER IF NOT EXISTS 'pterodactyl'@'localhost' IDENTIFIED BY '$DB_PASS';
ALTER USER 'pterodactyl'@'127.0.0.1' IDENTIFIED BY '$DB_PASS';
ALTER USER 'pterodactyl'@'localhost' IDENTIFIED BY '$DB_PASS';
GRANT ALL PRIVILEGES ON panel.* TO 'pterodactyl'@'127.0.0.1';
GRANT ALL PRIVILEGES ON panel.* TO 'pterodactyl'@'localhost';
FLUSH PRIVILEGES;
SQL
  if ! "$DBCMD" -h 127.0.0.1 -P 3306 -u pterodactyl "-p$DB_PASS" panel -Nse "SELECT 1;" >/dev/null 2>/tmp/lianix-db-auth.err; then
    echo "DB_ERROR: bot gagal memperbaiki login database pterodactyl"
    cat /tmp/lianix-db-auth.err 2>/dev/null || true
    exit 40
  fi
  echo "LIANIX_STEP:Login database berhasil diperbaiki otomatis."
fi
# Rebuild Laravel package discovery explicitly after Composer hooks were disabled.
# This command is non-interactive and cannot invoke the p:environment:* wizard.
timeout 180 php artisan package:discover --ansi --no-interaction </dev/null >/tmp/lianix-package-discover.log 2>&1 || {
  echo "ARTISAN_PACKAGE_DISCOVER_ERROR: gagal menjalankan package discovery"
  cat /tmp/lianix-package-discover.log 2>/dev/null || true
  exit 39
}
timeout 180 php artisan config:clear --no-interaction </dev/null
for required in APP_KEY APP_URL DB_CONNECTION DB_HOST DB_PORT DB_DATABASE DB_USERNAME DB_PASSWORD; do
  grep -qE "^$required=" .env || { echo "ENV_ERROR: missing $required in .env"; exit 39; }
done
[ "$(grep -E '^DB_HOST=' .env | tail -1 | cut -d= -f2-)" = "127.0.0.1" ] || { echo "ENV_ERROR: DB_HOST is not 127.0.0.1"; exit 39; }
[ "$(grep -E '^DB_USERNAME=' .env | tail -1 | cut -d= -f2-)" = "pterodactyl" ] || { echo "ENV_ERROR: DB_USERNAME is not pterodactyl"; exit 39; }
timeout 600 php artisan migrate --seed --force --no-interaction </dev/null
echo "LIANIX_STEP:Database selesai — membuat/memperbarui akun admin ADP..."
# Idempotent admin setup tanpa Laravel Facades/Tinker.
# Query langsung ke database untuk menghindari masalah namespace ketika
# perintah Artisan dibungkus di dalam SSH/bash. Pterodactyl tetap memakai
# p:user:make resmi untuk pembuatan user baru.
set +e
ADMIN_EXISTS_RAW=$($DBCMD -h 127.0.0.1 -u pterodactyl -p"$DB_PASS" panel -Nse "SELECT COUNT(*) FROM users WHERE username='$PANEL_USER' OR email='$PANEL_EMAIL';" 2>/tmp/lianix-admin-db.err)
ADMIN_DB_RC=$?
set -e
if [ "$ADMIN_DB_RC" -ne 0 ]; then
  echo "ADMIN_ERROR: gagal memeriksa tabel users pada database Panel"
  cat /tmp/lianix-admin-db.err 2>/dev/null || true
  exit 41
fi
ADMIN_EXISTS=$(printf '%s' "$ADMIN_EXISTS_RAW" | tr -d '[:space:]')
if [ "\${ADMIN_EXISTS:-0}" = "0" ]; then
  echo "LIANIX_STEP:Akun ADP belum ada — membuat user admin resmi Pterodactyl..."
  timeout 180 php artisan p:user:make -n --email="$PANEL_EMAIL" --username="$PANEL_USER" --name-first="Lianix" --name-last="CPanel" --password="$PANEL_PASS" --admin=1 2>&1 || { echo "ADMIN_ERROR: gagal membuat akun ADP dengan p:user:make"; exit 41; }
else
  echo "LIANIX_STEP:Akun ADP sudah ada — memperbarui password dan hak admin..."
  ADMIN_HASH=$(php -r 'echo password_hash($argv[1], PASSWORD_BCRYPT);' "$PANEL_PASS")
  $DBCMD -h 127.0.0.1 -u pterodactyl -p"$DB_PASS" panel <<SQL
UPDATE users
SET username='\${PANEL_USER}',
    email='\${PANEL_EMAIL}',
    name_first='Lianix',
    name_last='CPanel',
    root_admin=1,
    password='\${ADMIN_HASH}',
    updated_at=NOW()
WHERE username='\${PANEL_USER}' OR email='\${PANEL_EMAIL}';
SQL
  echo "LIANIX_STEP:Akun admin ADP berhasil diperbarui."
fi

echo "LIANIX_STEP:Admin selesai — mengatur Nginx, Queue Worker, dan Scheduler..."
PHPV=$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;')
FPM_SOCK="/run/php/php$PHPV-fpm.sock"
cat > /etc/nginx/sites-available/pterodactyl.conf <<NGINX
server {
    listen 80;
    server_name $PANEL_DOMAIN;
    root /var/www/pterodactyl/public;
    index index.php;
    charset utf-8;
    client_max_body_size 100m;
    location / { try_files \\$uri \\$uri/ /index.php?\\$query_string; }
    location ~ \\.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:$FPM_SOCK;
    }
    location ~ /\\.ht { deny all; }
}
NGINX
rm -f /etc/nginx/sites-enabled/default
ln -sfn /etc/nginx/sites-available/pterodactyl.conf /etc/nginx/sites-enabled/pterodactyl.conf
chown -R www-data:www-data /var/www/pterodactyl
cat > /etc/systemd/system/pteroq.service <<'UNIT'
[Unit]
Description=Pterodactyl Queue Worker
After=redis-server.service
[Service]
User=www-data
Group=www-data
Restart=always
ExecStart=/usr/bin/php /var/www/pterodactyl/artisan queue:work --queue=high,standard,low --sleep=3 --tries=3
RestartSec=5s
[Install]
WantedBy=multi-user.target
UNIT
printf '* * * * * php /var/www/pterodactyl/artisan schedule:run >> /dev/null 2>&1\\n' > /etc/cron.d/pterodactyl
chmod 644 /etc/cron.d/pterodactyl
timeout 30 systemctl daemon-reload
timeout 60 systemctl enable --now pteroq.service
if ! timeout 30 systemctl enable php$PHPV-fpm >/dev/null 2>&1; then true; fi
if ! timeout 60 systemctl restart php$PHPV-fpm >/tmp/lianix-phpfpm.log 2>&1; then
  echo "WEB_ERROR: PHP-FPM gagal direstart"
  cat /tmp/lianix-phpfpm.log 2>/dev/null || true
  systemctl status php$PHPV-fpm --no-pager -l 2>/dev/null || true
  exit 42
fi
if ! nginx -t >/tmp/lianix-nginx-test.log 2>&1; then
  echo "WEB_ERROR: konfigurasi Nginx tidak valid"
  cat /tmp/lianix-nginx-test.log
  exit 43
fi
if ! timeout 60 systemctl enable --now nginx >/tmp/lianix-nginx.log 2>&1; then
  echo "WEB_ERROR: Nginx gagal aktif"
  cat /tmp/lianix-nginx.log 2>/dev/null || true
  systemctl status nginx --no-pager -l 2>/dev/null || true
  exit 44
fi

echo "LIANIX_STEP:Memasang SSL HTTPS untuk domain Panel..."
SSL_OK=0
if getent hosts "$PANEL_DOMAIN" >/dev/null 2>&1; then
  if timeout 300 certbot --nginx --non-interactive --agree-tos --register-unsafely-without-email --redirect -d "$PANEL_DOMAIN"; then
    SSL_OK=1
    PANEL_URL="https://$PANEL_DOMAIN"
    sed -i "s#^APP_URL=.*#APP_URL=$PANEL_URL#" /var/www/pterodactyl/.env
    cd /var/www/pterodactyl
    timeout 180 php artisan config:clear >/dev/null 2>&1 || true
    timeout 180 php artisan config:cache >/dev/null 2>&1 || true
    echo "LIANIX_STEP:SSL aktif — Panel diarahkan otomatis ke HTTPS."
  else
    echo "SSL_WARNING: Certbot gagal menerbitkan sertifikat untuk $PANEL_DOMAIN. Panel tetap tersedia melalui HTTP sampai DNS/port 80 siap."
  fi
else
  echo "SSL_WARNING: DNS $PANEL_DOMAIN belum mengarah ke VPS. Panel tetap tersedia melalui HTTP sampai DNS benar."
fi

echo "LIANIX_STEP:Konfigurasi web selesai — memasang Docker dan binary Wings resmi..."

echo "LIANIX_STEP:Memeriksa Docker..."
if ! command -v docker >/dev/null 2>&1; then
  echo "LIANIX_STEP:Download installer Docker resmi..."
  curl -fsSL --retry 3 --retry-delay 2 --connect-timeout 15 --max-time 180 https://get.docker.com -o /tmp/lianix-get-docker.sh
  echo "LIANIX_STEP:Menjalankan installer Docker resmi..."
  timeout 600 sh /tmp/lianix-get-docker.sh >/tmp/lianix-docker-install.log 2>&1 &
  DPID=$!
  DSEC=0
  while kill -0 "$DPID" >/dev/null 2>&1; do
    sleep 5
    DSEC=$((DSEC+5))
    echo "LIANIX_STEP:Install Docker masih berjalan • \${DSEC}s"
    tail -n 2 /tmp/lianix-docker-install.log 2>/dev/null | sed 's/^/DOCKER • /' || true
  done
  if ! wait "$DPID"; then
    tail -n 80 /tmp/lianix-docker-install.log 2>/dev/null || true
    echo "DOCKER_INSTALL_ERROR"
    exit 29
  fi
  rm -f /tmp/lianix-get-docker.sh
  echo "LIANIX_STEP:Docker selesai dipasang — mengaktifkan service..."
fi
if ! timeout 90 systemctl enable --now docker >/tmp/lianix-docker.log 2>&1; then
  echo "NODE_ERROR: Docker gagal dijalankan"
  cat /tmp/lianix-docker.log
  exit 22
fi
mkdir -p /etc/pterodactyl /var/lib/pterodactyl /var/log/pterodactyl
ARCH=$(uname -m)
case "$ARCH" in x86_64) WARCH=amd64;; aarch64|arm64) WARCH=arm64;; *) echo "UNSUPPORTED_ARCH:$ARCH"; exit 21;; esac
echo "LIANIX_STEP:Menyiapkan binary Wings ($WARCH)..."
# Jangan menulis langsung ke /usr/local/bin/wings saat Wings sedang berjalan.
# Itu menyebabkan curl error 23 / "Text file busy". Hentikan service dulu,
# download ke file temporary, validasi, lalu atomic replace.
timeout 30 systemctl stop wings >/tmp/lianix-wings-stop.log 2>&1 || true
WINGS_TMP="/tmp/wings-linux-$WARCH.$$"
rm -f "$WINGS_TMP"
echo "LIANIX_STEP:Mengunduh binary Wings ($WARCH)..."
curl -fL --retry 5 --retry-delay 3 --connect-timeout 20 --max-time 300 \
  -o "$WINGS_TMP" "https://github.com/pterodactyl/wings/releases/latest/download/wings_linux_$WARCH" >/tmp/lianix-wings.log 2>&1 &
WPID=$!
WSEC=0
while kill -0 "$WPID" >/dev/null 2>&1; do
  sleep 4
  WSEC=$((WSEC+4))
  SIZE=$(du -h "$WINGS_TMP" 2>/dev/null | awk '{print $1}' || true)
  echo "LIANIX_STEP:Download Wings masih berjalan • \${WSEC}s\${SIZE:+ • $SIZE}"
done
if ! wait "$WPID"; then
  echo "NODE_ERROR: gagal mengunduh binary Wings"
  cat /tmp/lianix-wings.log 2>/dev/null || true
  rm -f "$WINGS_TMP"
  exit 23
fi
chmod u+x "$WINGS_TMP"
if ! "$WINGS_TMP" version >/tmp/lianix-wings-version.log 2>&1; then
  echo "NODE_ERROR: binary Wings resmi hasil download tidak valid"
  cat /tmp/lianix-wings-version.log
  rm -f "$WINGS_TMP"
  exit 24
fi
WINGS_VERSION_TEXT="$(tr '\n' ' ' </tmp/lianix-wings-version.log | sed 's/[[:space:]][[:space:]]*/ /g')"
[ -n "$WINGS_VERSION_TEXT" ] || { echo "NODE_ERROR: Wings tidak mengembalikan informasi versi"; rm -f "$WINGS_TMP"; exit 24; }
echo "LIANIX_STEP:Binary Wings resmi tervalidasi • $WINGS_VERSION_TEXT"
mv -f "$WINGS_TMP" /usr/local/bin/wings
chmod u+x /usr/local/bin/wings

# Resolve Location/Nodе secara idempotent. Jangan pernah membuat Location jika short sudah ada.
cd /var/www/pterodactyl
LOCATION_LOG=/tmp/lianix-location.log
DBCMD="$(command -v mariadb || command -v mysql)"
[ -n "$DBCMD" ] || { echo "NODE_ERROR: client MariaDB tidak ditemukan"; exit 30; }

# Baca Location menggunakan kredensial database Panel melalui TCP. Jika record
# sudah ada, installer langsung memakai ID tersebut dan tidak membuat duplicate.
DB_QUERY=("$DBCMD" -h 127.0.0.1 -P 3306 -u pterodactyl "-p$DB_PASS" panel -Nse)
LOCATION_SQL="SELECT id FROM locations WHERE BINARY short='lianix' LIMIT 1;"
echo "LIANIX_STEP:Memeriksa Location Lianix yang sudah ada..."
LOCATION_ID="$("\${DB_QUERY[@]}" "$LOCATION_SQL" 2>"$LOCATION_LOG" | tr -d '[:space:]' || true)"

if [ -n "$LOCATION_ID" ]; then
  echo "LIANIX_STEP:Location Lianix sudah ada (ID $LOCATION_ID) — menggunakan data yang ada."
else
  if ! "\${DB_QUERY[@]}" "SELECT 1 FROM locations LIMIT 1;" >/dev/null 2>"$LOCATION_LOG"; then
    echo "NODE_ERROR: gagal membaca database Panel untuk memeriksa Location Lianix"
    cat "$LOCATION_LOG" 2>/dev/null || true
    exit 31
  fi

  echo "LIANIX_STEP:Location Lianix belum ada — membuat Location baru..."
  if timeout 180 php artisan p:location:make --short="lianix" --long="Lianix" --no-interaction >"$LOCATION_LOG" 2>&1; then
    LOCATION_ID="$("\${DB_QUERY[@]}" "$LOCATION_SQL" 2>/dev/null | tr -d '[:space:]' || true)"
  else
    # Duplicate/race-safe: jika command gagal karena record sudah ada, ambil ID-nya.
    LOCATION_ID="$("\${DB_QUERY[@]}" "$LOCATION_SQL" 2>/dev/null | tr -d '[:space:]' || true)"
    if [ -n "$LOCATION_ID" ]; then
      echo "LIANIX_STEP:Location Lianix sudah tersedia (ID $LOCATION_ID) — menggunakan data yang ada."
    else
      echo "NODE_ERROR: gagal membuat Location Lianix"
      cat "$LOCATION_LOG" 2>/dev/null || true
      exit 31
    fi
  fi
fi

[ -n "$LOCATION_ID" ] || { echo "NODE_ERROR: ID Location Lianix tidak ditemukan"; cat "$LOCATION_LOG" 2>/dev/null || true; exit 31; }
echo "LIANIX_STEP:Location siap — ID $LOCATION_ID."

NODE_ID="$(NODE_DOMAIN="$NODE_DOMAIN" $DBCMD -u root -Nse "SELECT id FROM panel.nodes WHERE fqdn='$NODE_DOMAIN' LIMIT 1;" 2>/dev/null | tr -d '[:space:]' || true)"
NODE_SCHEME="http"
NODE_SSL_OK=0
# Wings memakai TLS native di :8080. Jangan terminasi TLS lewat Nginx karena
# daemonListeningPort pada Panel juga dipakai untuk config Wings; reverse proxy
# dengan frontend 443/backend 8080 dapat membuat node merah setelah auto-deploy.
echo "LIANIX_STEP:Menyiapkan sertifikat Node Lianix untuk Wings native TLS..."
mkdir -p /var/www/html/.well-known/acme-challenge
cat > /etc/nginx/sites-available/lianix-node-acme.conf <<NGINX
server {
    listen 80;
    server_name $NODE_DOMAIN;
    root /var/www/html;
    location /.well-known/acme-challenge/ { try_files \$uri =404; }
    location / { return 404; }
}
NGINX
ln -sfn /etc/nginx/sites-available/lianix-node-acme.conf /etc/nginx/sites-enabled/lianix-node-acme.conf
if nginx -t >/tmp/lianix-node-nginx-test.log 2>&1; then
  systemctl reload nginx
else
  echo "NODE_SSL_ERROR: konfigurasi ACME Nginx tidak valid"
  cat /tmp/lianix-node-nginx-test.log
  exit 45
fi
if getent hosts "$NODE_DOMAIN" >/dev/null 2>&1; then
  if timeout 300 certbot certonly --webroot -w /var/www/html --non-interactive --agree-tos --register-unsafely-without-email -d "$NODE_DOMAIN" >/tmp/lianix-node-certbot.log 2>&1; then
    NODE_SCHEME="https"
    NODE_SSL_OK=1
    echo "LIANIX_STEP:SSL Node aktif — Wings akan melayani HTTPS langsung pada port 8080."
  else
    echo "SSL_WARNING: Sertifikat Node gagal diterbitkan."
    tail -n 30 /tmp/lianix-node-certbot.log 2>/dev/null || true
  fi
else
  echo "SSL_WARNING: DNS $NODE_DOMAIN belum resolve dari VPS."
fi
rm -f /etc/nginx/sites-enabled/lianix-node-acme.conf /etc/nginx/sites-available/lianix-node-acme.conf
nginx -t >/dev/null 2>&1 && systemctl reload nginx || true
# Jika Panel sudah HTTPS, Node juga wajib HTTPS menurut dokumentasi Pterodactyl.
if [ "$SSL_OK" = "1" ] && [ "$NODE_SSL_OK" != "1" ]; then
  echo "NODE_SSL_ERROR: Panel sudah HTTPS tetapi sertifikat Node belum tersedia. Pastikan A record $NODE_DOMAIN menuju VPS dan port 80 terbuka."
  exit 46
fi
MEM_MB=$(awk '/MemTotal/ {print int($2/1024)}' /proc/meminfo)
DISK_MB=$(df -Pm /var/lib/pterodactyl | awk 'NR==2 {print $4}')
[ "$MEM_MB" -gt 256 ] || MEM_MB=256
[ "$DISK_MB" -gt 1024 ] || DISK_MB=1024
if printf '%s' "$RAM_LIMIT" | grep -Eq '^[0-9]+$' && [ "$RAM_LIMIT" -gt 0 ] && [ "$RAM_LIMIT" -lt "$MEM_MB" ]; then
  MEM_MB="$RAM_LIMIT"
fi
if [ -z "$NODE_ID" ]; then
  timeout 180 php /var/www/pterodactyl/artisan p:node:make --name="Lianix Node" --description="Managed by Lianix • @yoennakbobo" --locationId="$LOCATION_ID" --fqdn="$NODE_DOMAIN" --public=1 --scheme="$NODE_SCHEME" --proxy=0 --maintenance=0 --maxMemory="$MEM_MB" --overallocateMemory=0 --maxDisk="$DISK_MB" --overallocateDisk=0 --uploadSize=100 --daemonListeningPort=8080 --daemonSFTPPort=2022 --daemonBase=/var/lib/pterodactyl/volumes --no-interaction >/tmp/lianix-node.log 2>&1 || {
    NODE_ID="$($DBCMD -u root -Nse "SELECT id FROM panel.nodes WHERE fqdn='$NODE_DOMAIN' LIMIT 1;" 2>/dev/null | tr -d '[:space:]' || true)"
    if [ -z "$NODE_ID" ]; then
      echo "NODE_ERROR: gagal membuat node"
      cat /tmp/lianix-node.log
      exit 32
    fi
  }
  NODE_ID="$($DBCMD -u root -Nse "SELECT id FROM panel.nodes WHERE fqdn='$NODE_DOMAIN' LIMIT 1;" 2>/dev/null | tr -d '[:space:]' || true)"
fi
[ -n "$NODE_ID" ] || { echo "NODE_ERROR: Node ID tidak ditemukan"; exit 33; }
# Reinstall-safe: perbaiki node lama yang mungkin dibuat oleh installer versi sebelumnya
# dengan reverse-proxy/branding yang salah. Wings tetap listen native di 8080.
$DBCMD -u root panel -e "UPDATE nodes SET name='Lianix Node', description='Managed by Lianix • @yoennakbobo', scheme='$NODE_SCHEME', behind_proxy=0, daemonListen=8080, daemonSFTP=2022, maintenance_mode=0, memory=$MEM_MB, updated_at=NOW() WHERE id=$NODE_ID;"

# Create the requested game-server port allocations idempotently.
# For NAT VPS, Pterodactyl allocations describe ports available to Wings;
# provider-side port forwarding is still required for public reachability.
echo "LIANIX_STEP:Menyiapkan allocation port 10000–11000..."
cat > /tmp/lianix-allocations.php <<'PHP'
<?php
require '/var/www/pterodactyl/vendor/autoload.php';
$app = require '/var/www/pterodactyl/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use Illuminate\Support\Facades\DB;

$nodeId = (int) getenv('LIANIX_NODE_ID');
if ($nodeId <= 0) {
    throw new RuntimeException('Node ID tidak valid');
}

$ip = getenv('LIANIX_ALLOC_IP') ?: '0.0.0.0';
$now = now();

$existing = DB::table('allocations')
    ->where('node_id', $nodeId)
    ->where('ip', $ip)
    ->whereBetween('port', [10000, 11000])
    ->pluck('port')
    ->map(fn($p) => (int) $p)
    ->all();

$rows = [];
for ($port = 10000; $port <= 11000; $port++) {
    if (!in_array($port, $existing, true)) {
        $rows[] = [
            'node_id' => $nodeId,
            'ip' => $ip,
            'port' => $port,
            'ip_alias' => null,
            'notes' => 'Lianix allocation',
            'created_at' => $now,
            'updated_at' => $now,
        ];
    }
}
foreach (array_chunk($rows, 250) as $chunk) {
    DB::table('allocations')->insert($chunk);
}
echo "ALLOC_OK:" . (1001 - count($existing)) . "\n";
PHP

# Use the panel's own Laravel/database connection, not a separate mysql login.
ALLOC_IP="0.0.0.0"
if ip -o addr show 2>/dev/null | grep -Fq " $SSH_PUBLIC_IP/"; then ALLOC_IP="$SSH_PUBLIC_IP"; fi
echo "LIANIX_STEP:Allocation Lianix memakai IP $ALLOC_IP (SSH target: $SSH_PUBLIC_IP)."
LIANIX_NODE_ID="$NODE_ID" LIANIX_ALLOC_IP="$ALLOC_IP" \
  php /tmp/lianix-allocations.php \
  >/tmp/lianix-alloc.log 2>&1 || {
    echo "ALLOCATION_ERROR: gagal membuat allocation 10000-11000"
    cat /tmp/lianix-alloc.log
    exit 36
  }
cat /tmp/lianix-alloc.log
rm -f /tmp/lianix-allocations.php /tmp/lianix-alloc.log

timeout 180 php /var/www/pterodactyl/artisan p:node:configuration "$NODE_ID" </dev/null > /etc/pterodactyl/config.yml
[ -s /etc/pterodactyl/config.yml ] || { echo "WINGS_CONFIG_ERROR: config.yml kosong"; exit 37; }
grep -q '^remote:' /etc/pterodactyl/config.yml || { echo "WINGS_CONFIG_ERROR: remote Panel tidak ada di config.yml"; exit 37; }
if [ "$NODE_SCHEME" = "https" ]; then
  grep -A6 '^api:' /etc/pterodactyl/config.yml | grep -q 'enabled: true' || { echo "WINGS_CONFIG_ERROR: Node HTTPS tetapi SSL Wings tidak aktif di config.yml"; sed -n '1,80p' /etc/pterodactyl/config.yml; exit 37; }
  [ -s "/etc/letsencrypt/live/$NODE_DOMAIN/fullchain.pem" ] || { echo "WINGS_CONFIG_ERROR: fullchain Node tidak ditemukan"; exit 37; }
  [ -s "/etc/letsencrypt/live/$NODE_DOMAIN/privkey.pem" ] || { echo "WINGS_CONFIG_ERROR: private key Node tidak ditemukan"; exit 37; }
fi
cat > /etc/systemd/system/wings.service <<'UNIT'
[Unit]
Description=Pterodactyl Wings Daemon
After=docker.service
Requires=docker.service
PartOf=docker.service
[Service]
User=root
WorkingDirectory=/etc/pterodactyl
LimitNOFILE=4096
PIDFile=/var/run/wings/daemon.pid
ExecStart=/usr/local/bin/wings
Restart=on-failure
StartLimitInterval=180
StartLimitBurst=30
RestartSec=5s
[Install]
WantedBy=multi-user.target
UNIT
timeout 30 systemctl daemon-reload
# Wings harus bisa dijangkau Panel pada 8080 dan SFTP pada 2022. Jika UFW aktif,
# buka kedua port tanpa mengubah firewall yang sedang nonaktif.
if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -qi '^Status: active'; then
  ufw allow 8080/tcp >/dev/null 2>&1 || true
  ufw allow 2022/tcp >/dev/null 2>&1 || true
fi
echo "LIANIX_STEP:Config Wings dibuat — membuka akses 8080/2022 dan menjalankan Wings..."
if ! timeout 90 systemctl enable --now wings >/tmp/lianix-wings-start.log 2>&1; then
  echo "WINGS_ERROR: service Wings gagal start"
  cat /tmp/lianix-wings-start.log 2>/dev/null || true
  systemctl status wings --no-pager -l 2>/dev/null || true
  journalctl -u wings -n 80 --no-pager 2>/dev/null || true
  exit 38
fi

echo "LIANIX_STEP:Node Lianix aktif — memasang Nest Lianix + Egg Node.js v12–v26 + Python 3.11–3.14..."
cat > /tmp/lianix-nodejs.json.b64 <<'LIANIXJSON'
${lianixNodeManifestB64}
LIANIXJSON
cat > /tmp/lianix-python.json.b64 <<'LIANIXJSON'
${lianixPythonManifestB64}
LIANIXJSON
base64 -d /tmp/lianix-nodejs.json.b64 > /tmp/lianix-nodejs.json
base64 -d /tmp/lianix-python.json.b64 > /tmp/lianix-python.json
cat > /tmp/lianix-seed-eggs.php <<'PHP'
<?php
use Illuminate\Support\Str;
use Pterodactyl\Models\Nest;
use Pterodactyl\Models\Egg;

$nest = Nest::where('name', 'Lianix')->first();
if (!$nest) {
    $nest = new Nest();
    $nest->uuid = (string) Str::uuid();
    $nest->author = 'lianix@yoennakbobo.local';
    $nest->name = 'Lianix';
    $nest->description = 'Lianix runtime nest';
    $nest->save();
}

$manifests = ['/tmp/lianix-nodejs.json', '/tmp/lianix-python.json'];
foreach ($manifests as $mf) {
    if (!is_file($mf)) { throw new RuntimeException("Manifest tidak ditemukan: {$mf}"); }
    $data = json_decode(file_get_contents($mf), true, 512, JSON_THROW_ON_ERROR);
    foreach (($data['eggs'] ?? []) as $d) {
        $name = trim($d['name'] ?? '');
        if ($name === '') continue;
        $egg = Egg::where('nest_id', $nest->id)->where('name', $name)->first() ?: new Egg();
        $egg->uuid = $egg->uuid ?: (string) Str::uuid();
        $egg->nest_id = $nest->id;
        $egg->author = $d['author'] ?? 'lianix@yoennakbobo.local';
        $egg->name = $name;
        $egg->description = $d['description'] ?? '';
        $egg->features = $d['features'] ?? null;
        $egg->docker_images = $d['docker_images'] ?? [];
        $egg->force_outgoing_ip = false;
        $egg->file_denylist = $d['file_denylist'] ?? [];
        $egg->config_files = $d['config']['files'] ?? '{}';
        $egg->config_startup = $d['config']['startup'] ?? '{}';
        $egg->config_logs = $d['config']['logs'] ?? '{}';
        $egg->config_stop = $d['config']['stop'] ?? '^C';
        $egg->config_from = null;
        $egg->startup = $d['startup'] ?? '';
        $egg->script_is_privileged = false;
        $egg->script_install = $d['scripts']['installation']['script'] ?? "#!/bin/bash\necho 'Lianix runtime ready'";
        $egg->script_entry = $d['scripts']['installation']['entrypoint'] ?? 'bash';
        $egg->script_container = $d['scripts']['installation']['container'] ?? 'alpine';
        $egg->copy_script_from = null;
        $egg->save();

        foreach (($d['variables'] ?? []) as $v) {
            $var = $egg->variables()->where('env_variable', $v['env_variable'] ?? '')->first();
            if (!$var) $var = $egg->variables()->make();
            $var->name = $v['name'] ?? ($v['env_variable'] ?? 'Variable');
            $var->description = $v['description'] ?? '';
            $var->env_variable = $v['env_variable'] ?? '';
            $var->default_value = $v['default_value'] ?? '';
            $var->user_viewable = (bool)($v['user_viewable'] ?? true);
            $var->user_editable = (bool)($v['user_editable'] ?? true);
            $var->rules = $v['rules'] ?? 'nullable|string';
            $var->save();
        }
    }
}

PHP
timeout 180 php /var/www/pterodactyl/artisan tinker --execute='require "/tmp/lianix-seed-eggs.php";' >/tmp/lianix-eggs.log 2>&1 || { echo "EGG_ERROR: gagal memasang Nest/Egg"; cat /tmp/lianix-eggs.log; exit 34; }
cat /tmp/lianix-eggs.log
rm -f /tmp/lianix-seed-eggs.php /tmp/lianix-location.log /tmp/lianix-node.log /tmp/lianix-eggs.log /tmp/lianix-nodejs.json.b64 /tmp/lianix-python.json.b64 /tmp/lianix-nodejs.json /tmp/lianix-python.json

echo "LIANIX_STEP:Nest Lianix dan runtime selesai — melakukan verifikasi akhir..."
WINGS_STATUS=$(systemctl is-active wings 2>/dev/null || true)
[ "$WINGS_STATUS" = "active" ] || { echo "WINGS_ERROR: service wings belum active"; systemctl status wings --no-pager -l || true; exit 35; }
echo "LIANIX_STEP:Wings aktif — menunggu endpoint Node benar-benar merespons..."
NODE_READY=0
for i in $(seq 1 20); do
  # Health check lokal menghindari false-negative pada VPS NAT yang tidak mendukung hairpin NAT.
  # Untuk HTTPS tetap gunakan hostname sertifikat melalui --resolve ke 127.0.0.1.
  if [ "$NODE_SCHEME" = "https" ]; then
    curl -kIsS --resolve "$NODE_DOMAIN:8080:127.0.0.1" --connect-timeout 4 --max-time 6 "https://$NODE_DOMAIN:8080" >/dev/null 2>&1 && NODE_READY=1 && break
  else
    curl -IsS --connect-timeout 4 --max-time 6 "http://127.0.0.1:8080" >/dev/null 2>&1 && NODE_READY=1 && break
  fi
  sleep 3
done
[ "$NODE_READY" = "1" ] || { echo "NODE_HEALTH_ERROR: service Wings aktif tetapi listener lokal :8080 belum merespons"; ss -lntp 2>/dev/null | grep ':8080' || true; journalctl -u wings -n 80 --no-pager 2>/dev/null || true; exit 36; }
printf 'INSTALL_OK\\n'
printf 'PANEL_DOMAIN=%s\\n' "$PANEL_DOMAIN"
printf 'PANEL_USER=%s\\n' "$PANEL_USER"
printf 'PANEL_PASS=%s\\n' "$PANEL_PASS"
printf 'NODE_DOMAIN=%s\\n' "$NODE_DOMAIN"
printf 'RAM_LIMIT=%s\\n' "$RAM_LIMIT"
printf 'WINGS_BINARY=/usr/local/bin/wings\\n'
`;

  const execRemote = (command, onData) => new Promise((resolve, reject) => {
    ssh.exec(command, (err, stream) => {
      if (err) return reject(err);
      let out = "";
      let errOut = "";
      let stdoutPending = "";
      let stderrPending = "";
      let progressQueue = Promise.resolve();
      const MAX_CAPTURE = 2 * 1024 * 1024;

      const pushLive = (raw, isErr = false) => {
        if (typeof onData !== "function") return;
        let line = String(raw || "").replace(/\x1b\[[0-9;]*m/g, "").trim();
        if (!line) return;
        // Hindari membanjiri kartu dengan progress-control terminal, tetapi semua
        // baris proses/command/error nyata tetap masuk secara berurutan.
        if (/^[.#=\-_|/\\ ]{18,}$/.test(line)) return;
        if (line.length > 260) line = line.slice(0, 257) + "...";
        const marker = line.match(/^LIANIX_STEP:(.*)$/i);
        const visible = marker ? marker[1].trim() : (isErr ? `ERR • ${line}` : line);
        progressQueue = progressQueue.then(() => onData(visible)).catch(() => {});
      };

      const consume = (chunk, isErr = false) => {
        let pending = (isErr ? stderrPending : stdoutPending) + chunk;
        const parts = pending.split(/\r?\n/);
        pending = parts.pop() || "";
        if (isErr) stderrPending = pending; else stdoutPending = pending;
        for (const line of parts) pushLive(line, isErr);
      };

      stream.on("data", d => {
        const chunk = d.toString();
        out += chunk;
        if (out.length > MAX_CAPTURE) out = out.slice(-MAX_CAPTURE);
        consume(chunk, false);
      });
      stream.stderr.on("data", d => {
        const chunk = d.toString();
        errOut += chunk;
        if (errOut.length > MAX_CAPTURE) errOut = errOut.slice(-MAX_CAPTURE);
        consume(chunk, true);
      });
      stream.on("close", async code => {
        if (stdoutPending.trim()) pushLive(stdoutPending, false);
        if (stderrPending.trim()) pushLive(stderrPending, true);
        await progressQueue.catch(() => {});
        resolve({ out, errOut, code });
      });
    });
  });

  // Deterministic self-healing untuk error installer yang aman diperbaiki.
  // Tidak menjalankan source/script pihak ketiga dan hanya melakukan repair
  // pada VPS yang sedang dipasang panel. Maksimal satu kali retry.
  const diagnoseAndRepair = async (result) => {
    const combined = `${result?.out || ""}\n${result?.errOut || ""}`;
    const repairs = [];

    if (/curl:\s*\(23\)\s*Failure writing output to destination/i.test(combined)) {
      repairs.push({
        name: "curl-23 / ruang atau permission temporary",
        cmd: `set -u
mkdir -p /tmp /var/www/pterodactyl/storage /var/www/pterodactyl/bootstrap/cache
chmod 1777 /tmp
chown -R www-data:www-data /var/www/pterodactyl/storage /var/www/pterodactyl/bootstrap/cache 2>/dev/null || true
rm -f /tmp/composer-setup.php /tmp/panel.tar.gz 2>/dev/null || true
apt-get clean || true
rm -rf /var/lib/apt/lists/* 2>/dev/null || true
df -h /
df -ih /`
      });
    }

    if (/Could not get lock|Unable to acquire the dpkg frontend lock|dpkg frontend lock/i.test(combined)) {
      repairs.push({
        name: "APT/DPKG lock",
        cmd: `set -u
while fuser /var/lib/dpkg/lock-frontend >/dev/null 2>&1 || fuser /var/lib/apt/lists/lock >/dev/null 2>&1; do sleep 2; done
timeout 300 dpkg --configure -a || true
apt-get -f install -y || true`
      });
    }

    // Ubuntu/Debian kadang menyisakan pkgcache.bin yang corrupt/kehilangan
    // file temporary saat apt-get update. Error ini TIDAK sama dengan lock
    // dpkg, jadi repair lama tidak pernah terpanggil dan retry mengulang
    // error yang sama. Bersihkan cache biner apt lalu rebuild index.
    if (/package cache file is corrupted|Problem renaming .*pkgcache\.bin|pkgcache\.bin.*No such file or directory/i.test(combined)) {
      repairs.push({
        name: "APT package cache corrupt",
        cmd: `set -u
rm -f /var/cache/apt/pkgcache.bin /var/cache/apt/srcpkgcache.bin 2>/dev/null || true
mkdir -p /var/cache/apt/archives/partial /var/lib/apt/lists/partial
for i in $(seq 1 60); do
  if ! fuser /var/lib/dpkg/lock-frontend /var/lib/dpkg/lock /var/lib/apt/lists/lock /var/cache/apt/archives/lock >/dev/null 2>&1; then break; fi
  sleep 2
done
rm -f /var/cache/apt/pkgcache.bin /var/cache/apt/srcpkgcache.bin 2>/dev/null || true
rm -rf /var/lib/apt/lists/* 2>/dev/null || true
timeout 300 dpkg --configure -a || true
apt-get clean || true
apt-get -o Dir::Cache::pkgcache="" -o Dir::Cache::srcpkgcache="" update -y`
      });
    }

    if (/Permission denied|permission denied|failed to open stream/i.test(combined)) {
      repairs.push({
        name: "permission Pterodactyl",
        cmd: `set -u
mkdir -p /var/www/pterodactyl/storage /var/www/pterodactyl/bootstrap/cache
chown -R www-data:www-data /var/www/pterodactyl/storage /var/www/pterodactyl/bootstrap/cache
chmod -R ug+rwX /var/www/pterodactyl/storage /var/www/pterodactyl/bootstrap/cache`
      });
    }

    if (/SERVICE_ERROR:(mariadb|redis-server)/i.test(combined)) {
      repairs.push({
        name: "service database/cache",
        cmd: `systemctl daemon-reload || true
systemctl restart mariadb redis-server || true
systemctl is-active mariadb
systemctl is-active redis-server`
      });
    }

    if (/nginx.*(failed|error)|emerg|syntax is invalid/i.test(combined)) {
      repairs.push({
        name: "Nginx config",
        cmd: `nginx -t && systemctl restart nginx`
      });
    }

    if (/mariadb|mysql.*(connection|denied|down)|redis.*(connection|down)/i.test(combined)) {
      repairs.push({
        name: "MariaDB/Redis service",
        cmd: `systemctl enable --now mariadb redis-server || true
systemctl restart mariadb redis-server || true`
      });
    }

    if (/INSTALLER_NO_OUTPUT:/i.test(combined)) return { repaired:false, details:"Shell SSH berhasil dibuka tetapi script remote tidak mulai mengeluarkan output. Koneksi/channel ditutup agar bot tidak stuck; coba lagi setelah memastikan shell bash tersedia dan SSH tidak dibatasi proxy." };
    if (!repairs.length) return { repaired: false, details: "Tidak ada repair otomatis yang aman untuk pola error ini." };

    const applied = [];
    for (const repair of repairs) {
      const r = await execRemote(repair.cmd);
      applied.push(repair.name);
      if (r.code !== 0) {
        return { repaired: false, details: `Repair ${repair.name} gagal.`, applied };
      }
    }
    return { repaired: true, details: `Perbaikan otomatis: ${applied.join(", ")}.`, applied };
  };

  const connectSSH = (settingsForConnection) => new Promise((resolve, reject) => {
    let settled = false;
    const fail = (err) => {
      if (settled) return;
      settled = true;
      reject(err);
    };
    ssh.once("ready", () => {
      if (settled) return;
      settled = true;
      resolve();
    });
    ssh.once("error", fail);
    try { ssh.connect(settingsForConnection); } catch (err) { fail(err); }
  });

  try {
    let connected = false;
    const connectionErrors = [];
    for (const candidatePort of validPorts) {
      sshPort = candidatePort;
      connSettings = { ...connSettings, port: candidatePort };
      try {
        await connectSSH(connSettings);
        connected = true;
        await updateProgress(`SSH tersambung ke ${vpsIP}:${candidatePort}. Membaca identitas VPS...`);
        const vpsProfile = await readVpsProfile(ssh, sshTarget.display);
        await panelUi.setStatus("✅ SSH Terhubung! • VPS teridentifikasi • Installer siap", true);
        await panelUi.add("=== VPS INFO SETELAH SSH ===", { force:true });
        for (const [k,v] of Object.entries(vpsProfile)) {
          if (["target","error","warning"].includes(k) || !String(v||"").trim()) continue;
          await panelUi.add(`${k.toUpperCase()} • ${v}`);
        }
        if (vpsProfile.error) await panelUi.add(`VPS INFO WARNING • ${vpsProfile.error}`, { stderr:true, force:true });
        await updateProgress(`Identitas VPS selesai dibaca. Melanjutkan pre-flight installer...`);
        break;
      } catch (err) {
        connectionErrors.push(`:${candidatePort} → ${err.code || err.message || "unknown SSH error"}`);
        try { ssh.end(); } catch {}
      }
    }
    if (!connected) {
      await panelUi.add(`SSH GAGAL • ${connectionErrors.join(" | ")}`, { stderr:true, force:true });
      await panelUi.close();
      return safeEdit(bot, chatId, progress.message_id,
        `<blockquote><b>✕ Koneksi SSH Gagal</b>\n\n<b>Target:</b> <code>${escapeHTML(vpsIP)}</code>\n<b>Percobaan port:</b> <code>${escapeHTML(validPorts.join(", "))}</code>\n\n<b>Detail:</b>\n<code>${escapeHTML(connectionErrors.join("\n"))}</code>\n\nPastikan IP yang dimasukkan adalah <b>IP endpoint SSH NAT</b> dan port SSH NAT benar. Password tidak ditampilkan.</blockquote>`,
        { chat_id: chatId, message_id: progress.message_id, parse_mode: "HTML" }
      );
    }
    // Jangan kirim script installer besar sebagai satu command base64 di ssh.exec().
    // Pada sebagian SSH NAT/proxy command panjang bisa diterima tetapi shell tidak pernah
    // mulai membaca payload, sehingga UI berhenti di Tahap 1. Kirim script melalui stdin.
    const execRemoteScript = (scriptText, onData) => runLianixRemoteScript(ssh, scriptText, {
      username: sshTarget.username || "root",
      password: vpsPassword,
      openTimeoutMs: 12000,
      firstOutputTimeoutMs: 15000,
      maxRuntimeMs: 45 * 60 * 1000,
      onLine: async (raw, isErr) => {
        let line = String(raw || '').replace(/\x1b\[[0-9;?]*[ -\/]*[@-~]/g, '').trim();
        if (!line) return;
        if (/^[.#=\-_|/\\ ]{18,}$/.test(line)) return;
        if (line.length > 320) line = line.slice(0, 317) + '...';
        const visible = isErr && !/^LIANIX_FATAL:/i.test(line) ? `ERR • ${line}` : line;
        if (typeof onData === 'function') await onData(visible);
      }
    });
    let result;
    try {
      result = await execRemoteScript(script, updateProgress);
    } catch (transportErr) {
      const tmsg = String(transportErr?.message || transportErr || "SSH transport gagal");
      await panelUi.add(`SSH TRANSPORT GAGAL • ${tmsg}`, { stderr:true, force:true });
      await panelUi.close();
      try { ssh.end(); } catch {}
      return safeEdit(bot, chatId, progress.message_id,
        `<b>✕ INSTALL PANEL GAGAL</b>\n\n<b>Transport SSH:</b> <code>${escapeHTML(tmsg)}</code>\n\n`+
        `SSH sudah terautentikasi, tetapi channel shell/script tidak bisa dimulai. Bot menghentikan proses supaya tidak stuck.`
      );
    }

    const firstCombined = `${result.out || ""}\n${result.errOut || ""}`;
    // Virtualization/container detection is informational only. Do not abort here.
    // Docker/Wings capability is decided later by real service/binary health checks.
    if (/LIANIX_BUSY:/i.test(firstCombined)) {
      ssh.end();
      await panelUi.add("VPS sedang dipakai proses panel lain.", { stderr:true, force:true });
      await panelUi.close();
      return safeEdit(bot, chatId, progress.message_id, `<b>⚠ AKSI DITOLAK: VPS SEDANG SIBUK</b>\n\nTarget <code>${escapeHTML(sshTarget.display)}</code> sedang menjalankan Install Panel/Tema/Protect lain. Tunggu proses tersebut selesai lalu coba lagi.`);
    }

    // Jika gagal, bot menganalisis output error, menjalankan repair yang cocok,
    // lalu mengulang installer sekali. Tidak ada loop tak terbatas.
    if (result.code !== 0 || !result.out.includes("INSTALL_OK")) {
      const diagnosis = await diagnoseAndRepair(result);
      if (diagnosis.repaired) {
        await updateProgress(`⚠ Error terdeteksi.\n${diagnosis.details}\n\n↻ Menjalankan repair otomatis, lalu mengulang instalasi 1x...`);
        result = await execRemoteScript(script, updateProgress);
      } else {
        const raw = `${result.errOut || ""}\n${result.out || ""}`.trim();
        ssh.end();
        const safeRaw = raw.slice(-3000);
        await panelUi.add(`INSTALL GAGAL • ${diagnosis.details}`, { stderr:true, force:true });
        await panelUi.close();
        return bot.editMessageText(`<blockquote><b>✕ Install Panel Gagal</b>\n\n<b>Diagnosa:</b> ${escapeHTML(diagnosis.details)}\n\n<code>${escapeHTML(safeRaw)}</code></blockquote>`, { chat_id: chatId, message_id: progress.message_id, parse_mode: "HTML" }).catch(async () => {
          return bot.editMessageText(`✕ Install Panel gagal.\nTahap: ${lastProgress}\nDiagnosa: ${diagnosis.details}\n\n${safeRaw.slice(-1800)}`, { chat_id: chatId, message_id: progress.message_id }).catch(() => {});
        });
      }
    }

    ssh.end();
    const ok = result.code === 0 && result.out.includes("INSTALL_OK");
    if (!ok) {
      const raw = `${result.out || ""}\n${result.errOut || ""}`.trim();
      const fatalLines = raw.split(/\r?\n/).filter(line => /LIANIX_FATAL|_ERROR:|failed|fatal|exception/i.test(line));
      const safeRaw = (fatalLines.length ? fatalLines.slice(-20).join("\n") + "\n\n--- log terakhir ---\n" : "") + raw.slice(-2200);
      await panelUi.add("INSTALL MASIH GAGAL setelah repair otomatis.", { stderr:true, force:true });
      await panelUi.close();
      return safeEdit(bot, chatId, progress.message_id, `<blockquote><b>✕ Install Panel Masih Gagal</b>

<b>Bot sudah mencoba repair otomatis 1x.</b>

<code>${escapeHTML(safeRaw)}</code></blockquote>`).catch(() => {});
    }
    const hookWarning = /curl:\s*\(23\)\s*Failure writing output to destination/i.test(result.out + "\n" + result.errOut);
    const warningText = hookWarning
      ? "\n\n⚠ Peringatan: ada curl (23) dari addon hook, tetapi instalasi utama selesai. Bot sudah menjalankan repair temporary/storage sebelum retry."
      : "";
    currentStage = INSTALL_STAGES.length;
    await updateProgress("Verifikasi akhir selesai. Semua tahap installer berhasil.");
    await panelUi.setStage("Tahap 12/12 • Verifikasi akhir", 100, true);
    await panelUi.add("✓ INSTALL_OK • Panel, Wings, Node, Nest dan Egg terverifikasi.", { force:true });
    await panelUi.close();
    
    return safeEdit(bot, chatId, progress.message_id,
      `<blockquote><b>✓ PANEL LIANIX SELESAI</b>\n\n<b>Yang sudah dikerjakan:</b>\n✓ Dependency & service\n✓ Pterodactyl Panel resmi\n✓ Database & environment\n✓ Admin ADP\n✓ Nginx, Queue Worker & Scheduler\n✓ Wings resmi\n✓ Verifikasi akhir\n\n<b>ADP :</b> <code>${escapeHTML(panelUsername)}</code>\n<b>Password :</b> <code>${escapeHTML(panelPassword)}</code>\n<b>Panel :</b> <code>${/SSL_OK=1/.test(result.out) ? `https://${escapeHTML(domainpanel)}` : `http://${escapeHTML(domainpanel)}`}</code>\n<b>Node :</b> <code>${escapeHTML(domainnode)}</code>\n<b>Wings :</b> <code>Installed</code>\n\n<b>Keterangan :</b> Node Lianix + Nest Lianix sudah dibuat otomatis. Egg Node.js v20 menjadi runtime default/rekomendasi; versi Node.js lain juga tersedia di Nest Lianix, dan Python tersedia sebagai pilihan. Node health check sudah lulus sebelum installer menyatakan selesai; Wings aktif dan endpoint Node sudah dapat dijangkau.${escapeHTML(warningText)}</blockquote>`
    );
  } catch (err) {
    try { ssh.end(); } catch {}
    const detail = err && (err.stack || err.message) ? (err.stack || err.message) : String(err);
    console.warn("[installpanel] gagal tertangani:", detail);
    const safeDetail = detail.slice(-3000);
    await panelUi.add(`FATAL • ${safeDetail.slice(-1200)}`, { stderr:true, force:true }).catch(()=>{});
    await panelUi.close().catch(()=>{});
    return safeEdit(bot, chatId, progress.message_id,
      `<blockquote><b>✕ INSTALL PANEL GAGAL</b>\n\n<b>Tahap terakhir:</b> <code>${escapeHTML(lastProgress)}</code>\n\n<b>Error:</b>\n<code>${escapeHTML(safeDetail)}</code>\n\nPassword VPS tidak ditampilkan.</blockquote>`
    ).catch(() => {});
  }
  } finally {
    installPanelInFlight.delete(chatId);
    const lock = installPanelProcessLocks.get(chatId);
    if (lock) { try { fs.unlinkSync(lock); } catch {} installPanelProcessLocks.delete(chatId); }
  }
});

bot.onText(/^\/installwings(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from?.id;
  if (userId !== ownerId && getUserRole(userId) !== "ceo") return bot.sendMessage(chatId, "✗ Khusus Owner/CEO!");
  const text = match?.[1]?.trim() || "";
  if (!text || text.split("|").length < 2) {
    return bot.sendMessage(chatId,
      `<blockquote expandable><b>PANDUAN INSTALL WINGS • LIANIX</b>\n\n`+
      `<b>Format:</b> <code>/installwings host_target | password_vps</code>\n\n`+
      `Bot memasang Docker, binary Wings resmi, folder config, dan service systemd. Setelah itu ambil konfigurasi Node dari Panel lalu gunakan fitur konfigurasi Wings.</blockquote>`,
      {parse_mode:"HTML"});
  }
  const [targetRaw,password] = text.split("|").map(v=>v.trim());
  let target; try { target=parseSshTarget(targetRaw); } catch(e) { return bot.sendMessage(chatId,`✕ ${escapeHTML(e.message)}`,{parse_mode:"HTML"}); }
  const st=await bot.sendMessage(chatId,`<b>🚀 INSTALL WINGS LIANIX</b>\n<b>Target:</b> <code>${escapeHTML(target.display)}</code>`,{parse_mode:"HTML"});
  const ui=createLiveInstallerCard(bot,chatId,st.message_id,{title:"INSTALL WINGS LIANIX",target:target.display,status:"Membangun koneksi SSH...",stage:"Persiapan",percent:0});
  await ui.flush();
  const conn=new Client(); let done=false;
  const timer=setTimeout(async()=>{if(done)return;done=true;try{conn.end()}catch{};await ui.close();await safeEdit(bot,chatId,st.message_id,'✕ <b>INSTALL WINGS GAGAL</b>\n\nTimeout proses 15 menit.').catch(()=>{});},15*60*1000);
  conn.on('ready',async()=>{
    await showVpsProfileInCard(ui, conn, target.display);
    await ui.setStatus('✅ SSH Terhubung! • Memasang Wings...',true);
    const script=`set -Eeuo pipefail
trap 'rc=$?; echo "LIANIX_FATAL:exit=$rc line=\${BASH_LINENO[0]:-?} cmd=\${BASH_COMMAND:-unknown}" >&2' ERR
exec 9>/run/lock/lianix-panel-action.lock
if ! flock -n 9; then echo LIANIX_BUSY; exit 88; fi
command -v apt-get >/dev/null 2>&1 || { echo UNSUPPORTED_OS; exit 20; }
echo WINGS_STEP_1
echo "[1/5] Menyiapkan dependency Docker/Wings..."
export DEBIAN_FRONTEND=noninteractive
echo "Menunggu lock apt/dpkg maksimal 120 detik..."
APT_WAIT=0
while fuser /var/lib/dpkg/lock-frontend >/dev/null 2>&1 || fuser /var/lib/dpkg/lock >/dev/null 2>&1 || fuser /var/lib/apt/lists/lock >/dev/null 2>&1; do
  APT_WAIT=$((APT_WAIT+2)); [ "$APT_WAIT" -ge 120 ] && { echo APT_LOCK_TIMEOUT; exit 21; }; sleep 2
done
(
  timeout 600 apt-get -o DPkg::Lock::Timeout=120 -o Acquire::Retries=3 update -y &&
  timeout 600 apt-get -o DPkg::Lock::Timeout=120 install -y ca-certificates curl
) >/tmp/lianix-wings-apt.log 2>&1 &
APID=$!
ASEC=0
while kill -0 "$APID" >/dev/null 2>&1; do
  sleep 5
  ASEC=$((ASEC+5))
  echo "WINGS_HEARTBEAT:dependency masih berjalan • \${ASEC}s"
  tail -n 2 /tmp/lianix-wings-apt.log 2>/dev/null | sed 's/^/APT • /' || true
done
if ! wait "$APID"; then echo APT_DEPENDENCY_FAILED; tail -n 80 /tmp/lianix-wings-apt.log; exit 22; fi

echo WINGS_STEP_2
echo "[2/5] Memeriksa dan mengaktifkan Docker..."
if ! command -v docker >/dev/null 2>&1; then
  curl -fsSL --retry 3 --retry-delay 2 --connect-timeout 15 --max-time 180 https://get.docker.com -o /tmp/lianix-get-docker.sh || { echo DOCKER_INSTALLER_DOWNLOAD_FAILED; exit 23; }
  timeout 600 sh /tmp/lianix-get-docker.sh >/tmp/lianix-wings-docker.log 2>&1 &
  DPID=$!
  DSEC=0
  while kill -0 "$DPID" >/dev/null 2>&1; do
    sleep 5
    DSEC=$((DSEC+5))
    echo "WINGS_HEARTBEAT:install Docker masih berjalan • \${DSEC}s"
    tail -n 2 /tmp/lianix-wings-docker.log 2>/dev/null | sed 's/^/DOCKER • /' || true
  done
  if ! wait "$DPID"; then echo DOCKER_INSTALL_FAILED; tail -n 80 /tmp/lianix-wings-docker.log; exit 23; fi
  rm -f /tmp/lianix-get-docker.sh
timeout 90 systemctl daemon-reload >/dev/null 2>&1 || true
fi
timeout 90 systemctl enable --now docker >/tmp/lianix-wings-docker-start.log 2>&1 || { echo DOCKER_START_FAILED; cat /tmp/lianix-wings-docker-start.log; exit 23; }
timeout 30 systemctl is-active --quiet docker || { echo DOCKER_NOT_ACTIVE; systemctl status docker --no-pager -l || true; exit 23; }
echo WINGS_STEP_3
echo "[3/5] Mengunduh binary Wings resmi..."
ARCH=$(uname -m)
case "$ARCH" in x86_64|amd64) BIN=wings_linux_amd64;; aarch64|arm64) BIN=wings_linux_arm64;; *) echo UNSUPPORTED_ARCH:$ARCH; exit 24;; esac
timeout 30 systemctl stop wings >/dev/null 2>&1 || true
WINGS_TMP="/tmp/lianix-$BIN.$$"
rm -f "$WINGS_TMP"
curl -fL --retry 5 --retry-all-errors --retry-delay 3 --connect-timeout 20 --max-time 300 -o "$WINGS_TMP" "https://github.com/pterodactyl/wings/releases/latest/download/$BIN" >/tmp/lianix-standalone-wings-download.log 2>&1 &
WPID=$!
WSEC=0
while kill -0 "$WPID" >/dev/null 2>&1; do
  sleep 4
  WSEC=$((WSEC+4))
  SIZE=$(du -h "$WINGS_TMP" 2>/dev/null | awk '{print $1}' || true)
  echo "WINGS_HEARTBEAT:download Wings masih berjalan • \${WSEC}s\${SIZE:+ • $SIZE}"
done
if ! wait "$WPID"; then cat /tmp/lianix-standalone-wings-download.log 2>/dev/null || true; rm -f "$WINGS_TMP"; echo WINGS_DOWNLOAD_FAILED; exit 25; fi
chmod +x "$WINGS_TMP"
"$WINGS_TMP" version >/tmp/lianix-standalone-wings-version.log 2>&1 || { cat /tmp/lianix-standalone-wings-version.log; rm -f "$WINGS_TMP"; echo WINGS_BINARY_INVALID; exit 25; }
echo "Wings official: $(tr '\n' ' ' </tmp/lianix-standalone-wings-version.log)"
mv -f "$WINGS_TMP" /usr/local/bin/wings
chmod +x /usr/local/bin/wings
/usr/local/bin/wings version
echo WINGS_STEP_4
echo "[4/5] Membuat folder config dan service systemd..."
mkdir -p /etc/pterodactyl
cat >/etc/systemd/system/wings.service <<'EOF'
[Unit]
Description=Pterodactyl Wings Daemon • Lianix
After=docker.service
Requires=docker.service
PartOf=docker.service
[Service]
User=root
WorkingDirectory=/etc/pterodactyl
LimitNOFILE=4096
PIDFile=/var/run/wings/daemon.pid
ExecStart=/usr/local/bin/wings
Restart=on-failure
StartLimitInterval=180
StartLimitBurst=30
RestartSec=5s
[Install]
WantedBy=multi-user.target
EOF
timeout 30 systemctl daemon-reload
timeout 30 systemctl enable wings >/dev/null 2>&1 || true
echo WINGS_STEP_5
echo "[5/5] Verifikasi instalasi Wings..."
test -x /usr/local/bin/wings
test -f /etc/systemd/system/wings.service
WINGS_CONFIG_STATE="missing"
if [ -s /etc/pterodactyl/config.yml ]; then
  WINGS_CONFIG_STATE="present"
  echo "Config Wings ditemukan — mencoba start service..."
  if timeout 60 systemctl restart wings >/tmp/lianix-standalone-wings-start.log 2>&1 && sleep 2 && systemctl is-active --quiet wings; then
    WINGS_CONFIG_STATE="active"
    echo "WINGS_SERVICE_ACTIVE"
  else
    echo "WINGS_CONFIG_PRESENT_BUT_SERVICE_FAILED"
    cat /tmp/lianix-standalone-wings-start.log 2>/dev/null || true
    systemctl status wings --no-pager -l 2>/dev/null || true
    journalctl -u wings -n 60 --no-pager 2>/dev/null || true
    exit 26
  fi
else
  echo "WINGS_CONFIG_MISSING: binary/service terpasang; config Node belum diberikan."
fi
echo "WINGS_CONFIG_STATE:$WINGS_CONFIG_STATE"
echo WINGS_INSTALL_OK`;
    try{
      const result=await runLianixRemoteScript(conn,script,{username:target.username,password,maxRuntimeMs:14*60*1000,onLine:async(row,isErr)=>{
        if(row.includes('WINGS_STEP_1'))await ui.setStage('Tahap 1/5 • Dependency',15,true);
        else if(row.includes('WINGS_STEP_2'))await ui.setStage('Tahap 2/5 • Docker',35,true);
        else if(row.includes('WINGS_STEP_3'))await ui.setStage('Tahap 3/5 • Binary Wings',55,true);
        else if(row.includes('WINGS_STEP_4'))await ui.setStage('Tahap 4/5 • Service systemd',75,true);
        else if(row.includes('WINGS_STEP_5'))await ui.setStage('Tahap 5/5 • Verifikasi',90,true);
        else if(row!=='LIANIX_REMOTE_CHANNEL_OK')await ui.add(row,{stderr:isErr});
      }});
      clearTimeout(timer);done=true;try{conn.end()}catch{}
      const combined=`${result.out||''}\n${result.errOut||''}`;
      if(result.code===0&&combined.includes('WINGS_INSTALL_OK')){await ui.setStage('Tahap 5/5 • Selesai',100,true);await ui.close();return safeEdit(bot,chatId,st.message_id,`✓ <b>INSTALL WINGS SELESAI</b>\n\nTarget: <code>${escapeHTML(target.display)}</code>\nBinary dan service Wings resmi sudah terpasang.\n\nSelanjutnya masukkan konfigurasi Node dari Panel ke <code>/etc/pterodactyl/config.yml</code>, lalu start Wings.`);}
      await ui.close();return safeEdit(bot,chatId,st.message_id,`✕ <b>INSTALL WINGS GAGAL</b>\n\n${escapeHTML(result.errOut?.trim()||`Exit ${result.code}`).slice(0,1800)}`);
    }catch(e){clearTimeout(timer);done=true;try{conn.end()}catch{};await ui.close();return safeEdit(bot,chatId,st.message_id,`✕ <b>INSTALL WINGS GAGAL</b>\n\n${escapeHTML(String(e?.message||e)).slice(0,1800)}`);}
  }).on('error',async e=>{clearTimeout(timer);if(done)return;done=true;await ui.close();await safeEdit(bot,chatId,st.message_id,`✕ <b>INSTALL WINGS GAGAL</b>\n\nKoneksi SSH: ${escapeHTML(e.message)}`).catch(()=>{});}).connect({host:target.host,port:target.port,username:target.username,password,readyTimeout:20000,keepaliveInterval:10000,keepaliveCountMax:3});
});

// [removed] /gavps - credential-harvesting root-password hijack tool targeting other people's VPS

bot.onText(/^\/installnginx(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from?.id;
  if (userId !== ownerId && getUserRole(userId) !== "ceo") return bot.sendMessage(chatId, "✗ Khusus Owner/CEO!");
  const input = match?.[1]?.trim() || "";
  if (!input || input.split("|").length < 2) return bot.sendMessage(chatId, `<blockquote expandable><b>PANDUAN INSTALL NGINX</b>\n\n<b>Format:</b> <code>/installnginx host_target | password_vps</code>\n\nInstaller memakai timeout, live log, apt lock wait, dan verifikasi service agar tidak stuck.</blockquote>`, {parse_mode:"HTML"});
  const parts=input.split("|"); const targetRaw=parts.shift().trim(); const password=parts.join("|").trim();
  let target; try{ target=parseSshTarget(targetRaw); }catch(e){ return bot.sendMessage(chatId,`✕ ${escapeHTML(e.message)}`,{parse_mode:"HTML"}); }
  if(!password) return bot.sendMessage(chatId,"✕ Password VPS kosong.");
  const st=await bot.sendMessage(chatId,"<b>INSTALL NGINX</b>\n\n<code>[░░░░░░░░░░] 0%</code>\nMenyiapkan koneksi...",{parse_mode:"HTML"});
  const ui=createLiveInstallerCard(bot,chatId,st.message_id,{title:"INSTALL NGINX",target:target.display,status:"Membangun koneksi SSH...",stage:"Persiapan",percent:0}); await ui.flush();
  const conn=new Client(); let done=false;
  const timer=setTimeout(async()=>{ if(done)return; done=true; try{conn.end()}catch{}; await ui.close(); await safeEdit(bot,chatId,st.message_id,"✕ <b>INSTALL NGINX GAGAL</b>\n\nTimeout total 12 menit. Proses dihentikan agar tidak stuck.").catch(()=>{}); },12*60*1000); if(timer.unref)timer.unref();
  conn.once("ready",async()=>{
    try{
      await showVpsProfileInCard(ui, conn, target.display);
      await ui.setStatus("✅ SSH Terhubung! • Memasang Nginx...",true);
      const script=`set -Eeuo pipefail
trap 'rc=$?; echo "NGINX_FATAL:exit=$rc line=\${BASH_LINENO[0]:-?} cmd=\${BASH_COMMAND:-unknown}" >&2' ERR
exec 9>/run/lock/lianix-panel-action.lock
flock -n 9 || { echo LIANIX_BUSY; exit 88; }
command -v apt-get >/dev/null 2>&1 || { echo UNSUPPORTED_OS; exit 20; }
export DEBIAN_FRONTEND=noninteractive
echo NGINX_STEP_1
WAIT=0
while fuser /var/lib/dpkg/lock-frontend >/dev/null 2>&1 || fuser /var/lib/dpkg/lock >/dev/null 2>&1 || fuser /var/lib/apt/lists/lock >/dev/null 2>&1; do WAIT=$((WAIT+2)); [ "$WAIT" -ge 120 ] && { echo APT_LOCK_TIMEOUT; exit 21; }; echo "Menunggu apt lock • $WAIT/120s"; sleep 2; done
echo NGINX_STEP_2
(timeout 600 apt-get -o DPkg::Lock::Timeout=120 -o Acquire::Retries=3 update -y && timeout 600 apt-get -o DPkg::Lock::Timeout=120 install -y nginx) >/tmp/lianix-nginx-apt.log 2>&1 &
PID=$!; SEC=0
while kill -0 "$PID" >/dev/null 2>&1; do sleep 5; SEC=$((SEC+5)); echo "NGINX_HEARTBEAT:apt masih berjalan • $SEC s"; tail -n 2 /tmp/lianix-nginx-apt.log 2>/dev/null | sed 's/^/APT • /' || true; done
if ! wait "$PID"; then tail -n 100 /tmp/lianix-nginx-apt.log; echo NGINX_APT_FAILED; exit 22; fi
echo NGINX_STEP_3
timeout 30 nginx -t
timeout 45 systemctl enable --now nginx
sleep 2
systemctl is-active --quiet nginx || { systemctl status nginx --no-pager -l || true; exit 23; }
echo NGINX_STEP_4
curl -fsS --connect-timeout 5 --max-time 10 http://127.0.0.1/ >/dev/null || { echo NGINX_LOCAL_HTTP_FAILED; exit 24; }
echo NGINX_OK`;
      const result=await runLianixRemoteScript(conn,script,{username:target.username,password,maxRuntimeMs:11*60*1000,onLine:async(row,isErr)=>{
        if(row.includes("NGINX_STEP_1"))await ui.setStage("Tahap 1/4 • Menunggu package manager",15,true);
        else if(row.includes("NGINX_STEP_2"))await ui.setStage("Tahap 2/4 • Update repository & install",40,true);
        else if(row.includes("NGINX_STEP_3"))await ui.setStage("Tahap 3/4 • Validasi config & start service",75,true);
        else if(row.includes("NGINX_STEP_4"))await ui.setStage("Tahap 4/4 • Health check localhost",92,true);
        else if(row!=="LIANIX_REMOTE_CHANNEL_OK"&&row!=="NGINX_OK")await ui.add(row,{stderr:isErr});
      }});
      const combined=`${result.out||""}\n${result.errOut||""}`; if(result.code!==0||!combined.includes("NGINX_OK"))throw new Error(result.errOut?.trim()||result.out?.trim()||`Exit ${result.code}`);
      done=true;clearTimeout(timer);try{conn.end()}catch{};await ui.setStage("Tahap 4/4 • Nginx aktif & HTTP lokal OK",100,true);await ui.close();return safeEdit(bot,chatId,st.message_id,`✓ <b>NGINX BERHASIL DIINSTALL</b>\n\nTarget: <code>${escapeHTML(target.display)}</code>\nService: <b>ACTIVE</b>\nHealth check: <b>HTTP localhost OK</b>`);
    }catch(e){if(done)return;done=true;clearTimeout(timer);try{conn.end()}catch{};await ui.close();return safeEdit(bot,chatId,st.message_id,`✕ <b>INSTALL NGINX GAGAL</b>\n\n${escapeHTML(String(e?.message||e)).slice(0,1800)}`).catch(()=>{});}
  });
  conn.once("error",async e=>{if(done)return;done=true;clearTimeout(timer);await ui.close();await safeEdit(bot,chatId,st.message_id,`✕ <b>INSTALL NGINX GAGAL</b>\n\nKoneksi SSH: ${escapeHTML(e.message)}`).catch(()=>{});});
  conn.connect({host:target.host,port:target.port,username:target.username,password,readyTimeout:20000,keepaliveInterval:5000,keepaliveCountMax:3});
});

bot.onText(/^\/cleardisk (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;

    if (!match[1]) {
        return bot.sendMessage(chatId, "Format:\n/cleardisk ip|password");
    }

    const [ip, password] = match[1].split("|");

    bot.sendMessage(chatId, "⌕ Scan folder terbesar di /var/lib/pterodactyl/volumes...");

    const conn = new Client();

    conn.on("ready", () => {
        // Command yang akan dijalankan di SSH
        const scanDeleteCmd = `
LARGEST=$(du -s -B1M /var/lib/pterodactyl/volumes/* 2>/dev/null | sort -nr | head -n1)
if [ -z "$LARGEST" ]; then
  echo "NOFOLDER"
else
  SIZE=$(echo $LARGEST | awk '{print $1}')
  FOLDER=$(echo $LARGEST | awk '{print $2}')
  echo "$SIZE|$FOLDER"
  rm -rf "$FOLDER"
fi
`;

        conn.exec(scanDeleteCmd, { pty: true }, (err, stream) => {
            if (err) {
                bot.sendMessage(chatId, "✕ Gagal terhubung ke SSH.");
                conn.end();
                return;
            }

            let output = "";

            stream.on("data", (data) => output += data.toString());
            stream.on("close", () => {
                if (output.includes("NOFOLDER")) {
                    bot.sendMessage(chatId, "✕ Tidak ada folder ditemukan di /var/lib/pterodactyl/volumes.");
                } else {
                    const [size, folder] = output.trim().split("|");
                    bot.sendMessage(
                        chatId,
                        `✓ Folder terbesar berhasil dihapus!\n\nFolder: ${folder}\nUkuran: ${size} MB`
                    );
                }
                conn.end();
            });

            stream.on("error", (e) => {
                bot.sendMessage(chatId, `✕ Terjadi error SSH: ${e.message}`);
                conn.end();
            });
        });

    }).connect({
        host: ip,
        port: 22,
        username: "root",
        password: password
    });

});
bot.onText(/^\/killlog (.+)$/, async (msg, match) => {
    const chatId = msg.chat.id;
    const input = match[1];

    if (!input.includes('|')) {
        return bot.sendMessage(chatId, '✕ Format salah!\nGunakan: /killlog ip|password');
    }

    const [ip, password] = input.split('|');

    const conn = new Client();

    conn.on('ready', () => {
        // Script kill semua session
        const cmd = `
echo "⌗ Sebelum:";
who;
echo "";

who | while read user tty date time ip; do
  pkill -kill -t "$tty"
  echo "✕ Kicked $user ($ip)"
done

echo "";
echo "⌗ Sesudah:";
who;
        `;

        conn.exec(cmd, (err, stream) => {
            if (err) {
                bot.sendMessage(chatId, '✕ Gagal eksekusi');
                conn.end();
                return;
            }

            let data = '';

            stream.on('data', (chunk) => {
                data += chunk.toString();
            });

            stream.on('close', () => {
                if (!data.trim()) {
                    data = 'Tidak ada user login.';
                }

                bot.sendMessage(chatId, `⟡ KILL LOGIN VPS (${ip})\n\n${data}`);
                conn.end();
            });
        });

    }).on('error', (err) => {
        bot.sendMessage(chatId, `✕ Login gagal!\n${err.message}`);
    }).connect({
        host: ip,
        port: 22,
        username: 'root',
        password: password,
        readyTimeout: 5000
    });
});
bot.onText(/^\/totallog (.+)$/, async (msg, match) => {
    const chatId = msg.chat.id;
    const input = match[1];

    if (!input.includes('|')) {
        return bot.sendMessage(chatId, '✕ Format salah!\nGunakan: /totallog ip|password');
    }

    const [ip, password] = input.split('|');

    const conn = new Client();

    conn.on('ready', () => {
        conn.exec("last -n 10", (err, stream) => {
            if (err) {
                bot.sendMessage(chatId, '✕ Gagal ambil data');
                conn.end();
                return;
            }

            let data = '';

            stream.on('data', (chunk) => {
                data += chunk.toString();
            });

            stream.on('close', () => {
                if (!data.trim()) {
                    data = 'Tidak ada riwayat login.';
                }
                
                bot.sendMessage(chatId, `⌗ 10 Login Terakhir VPS (${ip}):\n\n${data}`);
                conn.end();
            });
        });

    }).on('error', (err) => {
        bot.sendMessage(chatId, `✕ Login gagal!\n${err.message}`);
    }).connect({
        host: ip,
        port: 22,
        username: 'root',
        password: password,
        readyTimeout: 5000
    });
});
bot.onText(/^\/cekwings (.+)$/, async (msg, match) => {
    const chatId = msg.chat.id;
    const input = match[1];

    if (!input.includes('|')) {
        return bot.sendMessage(chatId, '✕ Format salah!\nGunakan: /cekwings ip|password');
    }

    const [ip, password] = input.split('|');

    const conn = new Client();

    conn.on('ready', () => {
        const cmd = "systemctl status wings --no-pager";

        conn.exec(cmd, (err, stream) => {
            if (err) {
                bot.sendMessage(chatId, '✕ Gagal ambil status wings');
                conn.end();
                return;
            }

            let data = '';

            stream.on('data', (chunk) => {
                data += chunk.toString();
            });

            stream.on('close', () => {

                // ================= ANALISA =================
                let analisa = "✓ Wings terlihat normal";

                if (data.includes("inactive (dead)")) {
                    analisa = "✕ Wings tidak berjalan (inactive/dead)\n➡ Jalankan: systemctl start wings";
                } 
                else if (data.includes("failed")) {
                    analisa = "✕ Wings FAILED\n➡ Cek config atau jalankan ulang";
                } 
                else if (data.includes("permission denied")) {
                    analisa = "✕ Permission denied\n➡ Jalankan dengan root / cek izin file";
                } 
                else if (data.includes("address already in use")) {
                    analisa = "✕ Port sudah digunakan\n➡ Ganti port atau kill process lain";
                } 
                else if (data.includes("connection refused")) {
                    analisa = "✕ Koneksi ditolak\n➡ Cek firewall / panel";
                }

                // ================= OUTPUT =================
                let result = `⚒ STATUS WINGS (${ip})\n\n`;
                result += "⌗ Output:\n" + data + "\n";
                result += "⌘ Analisa:\n" + analisa;

                bot.sendMessage(chatId, result);
                conn.end();
            });
        });

    }).on('error', (err) => {
        bot.sendMessage(chatId, `✕ Login gagal!\n${err.message}`);
    }).connect({
        host: ip,
        port: 22,
        username: 'root',
        password: password,
        readyTimeout: 5000
    });
});

let conn = null;
let knownLogins = new Set();
let activeChat = null;

// ================== START MONITOR ==================
bot.onText(/\/pantau (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const [ip, password] = match[1].split("|");

    if (!ip || !password) {
        return bot.sendMessage(chatId, "Format salah!\nContoh: /pantau ip|pw");
    }

    activeChat = chatId;
    bot.sendMessage(chatId, "⌕ Menghubungkan ke VPS...");

    function connectSSH() {
        conn = new Client();

        conn.on('ready', () => {
            bot.sendMessage(chatId, `✓ Terhubung ke VPS ${ip}`);

            // ⌕ Monitor login baru
            function checkLogin() {
                conn.exec("who", (err, stream) => {
                    if (err) return;

                    let data = "";

                    stream.on('data', d => data += d.toString());

                    stream.on('close', () => {
                        const lines = data.trim().split("\n");

                        lines.forEach(line => {
                            if (!knownLogins.has(line) && line.trim() !== "") {
                                knownLogins.add(line);

                                bot.sendMessage(chatId, `⎔ LOGIN BARU!\n${line}`);

                                // ⟡ AUTO KICK NEZURA
                                if (line.includes("nezura")) {
                                    conn.exec("pkill -KILL -u nezura", () => {});
                                    bot.sendMessage(chatId, "⊘ nezura langsung di-kick");
                                }
                            }
                        });
                    });
                });
            }

            setInterval(checkLogin, 10000);

        }).on('close', () => {
            bot.sendMessage(chatId, "⚠ Koneksi terputus, reconnect...");
            setTimeout(connectSSH, 5000);
        }).on('error', () => {});

        conn.connect({
            host: ip,
            port: 22,
            username: 'root',
            password: password
        });
    }

    connectSSH();
});


// ================== AUTO EXECUTE TEXT ==================
bot.on('message', (msg) => {
    const chatId = msg.chat.id;

    if (!msg.text) return;

    // ✕ Abaikan semua command (/start, /pantau, dll)
    if (msg.text.startsWith('/')) return;

    // pastikan sudah connect
    if (!conn || chatId !== activeChat) return;

    const command = msg.text;

    conn.exec(command, (err, stream) => {
        if (err) return bot.sendMessage(chatId, "✕ Gagal menjalankan command");

        let output = "";

        stream.on('data', (data) => {
            output += data.toString();
        });

        stream.stderr.on('data', (data) => {
            output += data.toString();
        });

        stream.on('close', () => {
            if (!output.trim()) {
                output = "✓ Command berhasil (tanpa output)";
            }

            bot.sendMessage(chatId, `▼ Output:\n${output}`);
        });
    });
});


// ================== UPLOAD FILE ==================
bot.on('document', async (msg) => {
    const chatId = msg.chat.id;

    if (!conn || chatId !== activeChat) {
        return bot.sendMessage(chatId, "✕ SSH belum terhubung");
    }

    const fileId = msg.document.file_id;
    const fileName = msg.document.file_name || "file.txt";
    const filePath = path.join(__dirname, fileName);

    try {
        const fileLink = await bot.getFileLink(fileId);

        const response = await axios({
            url: fileLink,
            method: 'GET',
            responseType: 'stream'
        });

        const writer = fs.createWriteStream(filePath);
        response.data.pipe(writer);

        writer.on('finish', () => {
            bot.sendMessage(chatId, `▼ File diterima: ${fileName}\n➤ Menjalankan...`);

            const content = fs.readFileSync(filePath, 'utf-8');

            conn.exec(content, (err, stream) => {
                if (err) return bot.sendMessage(chatId, "✕ Gagal eksekusi file");

                let output = "";

                stream.on('data', d => output += d.toString());
                stream.stderr.on('data', d => output += d.toString());

                stream.on('close', () => {
                    if (!output.trim()) {
                        output = "✓ File dijalankan (tanpa output)";
                    }

                    bot.sendMessage(chatId, `▼ Output:\n${output}`);
                });
            });

            fs.unlinkSync(filePath);
        });

    } catch (err) {
        bot.sendMessage(chatId, "✕ Gagal upload file");
    }
});
bot.onText(/^\/cekvps$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  const VPS_IP = "152.42.244.85";
  const VPS_USER = "root";
  const VPS_PASS = "rexzzyhc";

  const sendNotify = (text) =>
    bot.sendMessage(chatId, text, { parse_mode: "HTML" });

  const SSH = require("ssh2").Client;
  const conn = new SSH();

  conn.on("ready", () => {
    conn.exec(`
      CPU_TOTAL=$(nproc)
      CPU_USED=$(top -bn1 | grep "Cpu(s)" | awk '{print 100 - $8}')
      RAM_TOTAL=$(free -g | awk 'NR==2{print $2}')
      RAM_USED=$(free -g | awk 'NR==2{print $3}')
      DISK_TOTAL=$(df -BG / | awk 'NR==2{print $2}' | sed 's/G//')
      DISK_USED=$(df -BG / | awk 'NR==2{print $3}' | sed 's/G//')
      echo "$CPU_TOTAL $CPU_USED $RAM_TOTAL $RAM_USED $DISK_TOTAL $DISK_USED"
    `, (err, stream) => {

      if (err) {
        sendNotify(`✕ <b>Gagal mengambil status VPS</b>\n\n<code>${escapeHTML(err.message || String(err))}</code>`).catch(() => {});
        conn.end();
        return;
      }
      let output = '';

      stream.on('close', () => {

        const values = output.trim().split(/\s+/).map(Number);
        if (values.length < 6 || values.slice(0, 6).some(v => !Number.isFinite(v))) {
          sendNotify('✕ <b>Data VPS tidak valid</b>\n\nSSH terhubung, tetapi output monitoring tidak lengkap.').catch(() => {});
          conn.end();
          return;
        }
        const [cpuTotal, cpuUsed, ramTotal, ramUsed, diskTotal, diskUsed] = values;

        const ramFree = ramTotal - ramUsed;
        const diskFree = diskTotal - diskUsed;

        const ramPercent = ramTotal > 0 ? (ramUsed / ramTotal) * 100 : 0;
        const diskPercent = diskTotal > 0 ? (diskUsed / diskTotal) * 100 : 0;

        const getStatus = (percent) =>
          percent < 50 ? "● NORMAL" :
          percent < 75 ? "○ SEDANG" :
          "○ WARNING";

        sendNotify(`<blockquote>▭ <b>VPS STATUS</b>

⚡ <b>CPU</b>
Core        : ${cpuTotal} Core
Digunakan   : ${cpuUsed.toFixed(2)}%
Tersisa     : ${(100 - cpuUsed).toFixed(2)}%
Status      : ${getStatus(cpuUsed)}

⌘ <b>RAM</b>
Total       : ${ramTotal} GB
Digunakan   : ${ramUsed} GB
Tersisa     : ${ramFree} GB
Status      : ${getStatus(ramPercent)}

⟡ <b>Disk</b>
Total       : ${diskTotal} GB
Digunakan   : ${diskUsed} GB
Tersisa     : ${diskFree} GB
Status      : ${getStatus(diskPercent)}</blockquote>`);

        conn.end();

      }).on('data', data => output += data.toString())
        .stderr.on('data', data => output += data.toString());

    });

  }).connect({
    host: VPS_IP,
    port: 22,
    username: VPS_USER,
    password: VPS_PASS
  });
});

};