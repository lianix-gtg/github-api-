// OURIN-inspired Telegram Feature Hub: Group, Search, Fun, Game, AI, Tools.
// Ported for Telegram; no WhatsApp-specific APIs are used.
const fs = require('fs-extra');
const path = require('path');
const axios = require('axios');
const os = require('os');
const { execFile } = require('child_process');
const { promisify } = require('util');
const execFileAsync = promisify(execFile);
const { reportError } = require('./data/errorReporter.js');

const DB_DIR = path.join(process.cwd(), 'db');
const CFG_FILE = path.join(DB_DIR, 'ourinFeatureHub.json');
const MAX_TEXT = 3500;
const sleep = ms => new Promise(r => setTimeout(r, ms));

function loadDB() {
  try { return fs.readJsonSync(CFG_FILE); } catch { return { groups: {}, anti: {}, games: {} }; }
}
function saveDB(db) { fs.ensureDirSync(DB_DIR); fs.writeJsonSync(CFG_FILE, db, { spaces: 2 }); }
const db = loadDB();

const JOIN_REQUEST_FILE = path.join(DB_DIR, 'joinRequests.json');

function loadJoinRequests() {
  try { return fs.readJsonSync(JOIN_REQUEST_FILE); }
  catch { return {}; }
}
function saveJoinRequests(data) {
  fs.ensureDirSync(DB_DIR);
  fs.writeJsonSync(JOIN_REQUEST_FILE, data, { spaces: 2 });
}
function rememberJoinRequest(req) {
  if (!req?.chat?.id || !req?.from?.id) return;
  const data = loadJoinRequests();
  const chatKey = String(req.chat.id);
  const list = Array.isArray(data[chatKey]) ? data[chatKey] : [];
  const userId = String(req.from.id);
  const filtered = list.filter(x => String(x.userId) !== userId);
  filtered.push({
    userId,
    firstName: req.from.first_name || '',
    lastName: req.from.last_name || '',
    username: req.from.username || '',
    date: req.date || Math.floor(Date.now() / 1000),
    inviteLink: req.invite_link?.invite_link || ''
  });
  data[chatKey] = filtered.slice(-500);
  saveJoinRequests(data);
}
function forgetJoinRequest(chatId, userId) {
  const data = loadJoinRequests();
  const key = String(chatId);
  if (!Array.isArray(data[key])) return;
  data[key] = data[key].filter(x => String(x.userId) !== String(userId));
  saveJoinRequests(data);
}
function getPendingJoinRequests(chatId) {
  const data = loadJoinRequests();
  return Array.isArray(data[String(chatId)]) ? data[String(chatId)] : [];
}


function esc(s='') { return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function q(msg) { return msg?.message_id ? { reply_to_message_id: msg.message_id } : {}; }
function isGroup(msg) { return ['group','supergroup'].includes(msg?.chat?.type); }
async function isAdmin(bot, msg, userId=msg.from?.id) {
  try { const m = await bot.getChatMember(msg.chat.id, userId); return ['creator','administrator'].includes(m.status); } catch { return false; }
}
async function requireAdmin(bot,msg) { if (!isGroup(msg)) { await bot.sendMessage(msg.chat.id,'⌖ Fitur ini hanya tersedia di grup.',q(msg)); return false; } if (!(await isAdmin(bot,msg))) { await bot.sendMessage(msg.chat.id,'◇ Fitur ini khusus admin grup.',q(msg)); return false; } return true; }
async function requireBotAdmin(bot,msg) { if (!(await requireAdmin(bot,msg))) return false; try { const m=await bot.getChatMember(msg.chat.id, bot.options?.username ? bot.options.username : (await bot.getMe()).id); return ['creator','administrator'].includes(m.status); } catch { return true; } }

async function loading(bot,msg,steps,work) {
  let sent = null;
  const total = Math.max(1, steps.length - 1);
  const bar = (percent, width=18) => {
    const n=Math.max(0,Math.min(100,Number.isFinite(percent)?percent:0));
    const filled=Math.round((n/100)*width);
    return `[${'▰'.repeat(filled)}${'▱'.repeat(width-filled)}] ${Math.round(n)}%`;
  };
  const text=(stage,percent)=>`⏳ <b>${esc(stage)}</b>\n\n${bar(percent)}\n\n🔄 <i>Mohon tunggu, proses sedang berjalan...</i>`;
  try { sent=await bot.sendMessage(msg.chat.id,text(steps[0]||'Memproses...',0),{parse_mode:'HTML',...q(msg)}); } catch {}
  let lastAt=0,last=-1;
  const update=async(stage,percent)=>{
    if(!sent)return;
    const now=Date.now(); const n=Math.max(last,Math.min(100,Number(percent)||0));
    if(n===last && now-lastAt<3000)return;
    if(now-lastAt<1200)return;
    last=n;lastAt=now;
    try{await bot.editMessageText(text(stage,n),{chat_id:msg.chat.id,message_id:sent.message_id,parse_mode:'HTML'});}catch(e){
      const d=String(e?.response?.body?.description||e?.message||e);
      if(!/429|too many requests|message is not modified|query is too old/i.test(d)){}
    }
  };
  try {
    for(let i=1;i<steps.length;i++){await sleep(150);await update(steps[i],Math.round((i/total)*85));}
    const result=await work(update);
    if(sent){try{await bot.editMessageText(text('✅ Selesai.',100),{chat_id:msg.chat.id,message_id:sent.message_id,parse_mode:'HTML'});}catch{} setTimeout(()=>bot.deleteMessage(msg.chat.id,sent.message_id).catch(()=>{}),1000);}
    return result;
  } catch(e){
    if(sent){try{await bot.editMessageText(`❌ <b>Proses gagal</b>\n\n${esc(e.message)}`,{chat_id:msg.chat.id,message_id:sent.message_id,parse_mode:'HTML'});}catch{} setTimeout(()=>bot.deleteMessage(msg.chat.id,sent.message_id).catch(()=>{}),1500);}
    throw e;
  }
}

function groupKey(msg) { return String(msg.chat.id); }

// Telegram Bot API tidak menyediakan endpoint untuk mengambil seluruh member grup.
// Karena itu /tagall memakai member yang pernah terlihat oleh bot + admin grup.
function rememberGroupMember(msg, member = msg?.from) {
  if (!isGroup(msg) || !member?.id || member.is_bot) return;
  const key = String(msg.chat.id);
  db.groups[key] ||= {};
  const list = Array.isArray(db.groups[key].members) ? db.groups[key].members : [];
  const id = String(member.id);
  const row = {
    id,
    name: [member.first_name, member.last_name].filter(Boolean).join(' ') || member.username || `User ${id}`,
    username: member.username || '',
    active: true,
    last_seen_at: Date.now()
  };
  const idx = list.findIndex(x => String(x.id) === id);
  if (idx >= 0) list[idx] = { ...list[idx], ...row };
  else list.push(row);
  // Hindari database membesar tanpa batas.
  db.groups[key].members = list.slice(-2000);
  saveDB(db);
}

function groupMemberRows(chatId) {
  const g = db.groups[String(chatId)] || {};
  return Array.isArray(g.members) ? g.members : [];
}

function markGroupMemberInactive(chatId, userId) {
  const key = String(chatId);
  db.groups[key] ||= {};
  const list = Array.isArray(db.groups[key].members) ? db.groups[key].members : [];
  const id = String(userId || '');
  const idx = list.findIndex(x => String(x?.id) === id);
  if (idx >= 0) {
    list[idx] = { ...list[idx], active: false, left_at: Date.now() };
    db.groups[key].members = list;
    saveDB(db);
  }
}

function rememberUsersFromMessage(msg) {
  try {
    if (!isGroup(msg)) return;
    rememberGroupMember(msg);
    if (msg.reply_to_message?.from) rememberGroupMember(msg, msg.reply_to_message.from);
    for (const m of (msg.new_chat_members || [])) rememberGroupMember(msg, m);
    if (msg.left_chat_member?.id) markGroupMemberInactive(msg.chat.id, msg.left_chat_member.id);
    const entities = [...(msg.entities || []), ...(msg.caption_entities || [])];
    for (const e of entities) if (e?.user) rememberGroupMember(msg, e.user);
  } catch {}
}

async function sendTagAll(bot, msg, customText = "") {
  if (!(await requireAdmin(bot, msg))) return;
  const known = new Map();
  for (const m of groupMemberRows(msg.chat.id)) {
    if (m?.id && m.active !== false) known.set(String(m.id), m);
  }
  try {
    const admins = await bot.getChatAdministrators(msg.chat.id);
    for (const a of admins || []) {
      const u = a?.user;
      if (!u || u.is_bot) continue;
      known.set(String(u.id), { id: String(u.id), name: [u.first_name, u.last_name].filter(Boolean).join(' ') || u.username || `User ${u.id}`, username: u.username || '' });
    }
  } catch {}
  let totalMembers = null;
  try { totalMembers = await bot.getChatMemberCount(msg.chat.id); } catch {}
  const rows = [];
  for (const m of known.values()) {
    try {
      const cm = await bot.getChatMember(msg.chat.id, Number(m.id));
      const status = String(cm?.status || '');
      if (status === 'left' || status === 'kicked') {
        markGroupMemberInactive(msg.chat.id, m.id);
        continue;
      }
      rows.push(m);
    } catch {
      // Jika Telegram sementara gagal mengecek satu user, pertahankan cache aktif
      // agar satu gangguan API tidak membuat mention terlewat.
      rows.push(m);
    }
  }
  if (!rows.length) {
    return bot.sendMessage(msg.chat.id,
      `◇ <b>TAG ALL</b>\n\nBelum ada member yang tersimpan di cache bot.\n\n<i>Telegram tidak menyediakan API untuk meminta daftar seluruh member grup. Bot akan mencatat member saat mereka mengirim pesan, join, atau menghasilkan update member.</i>`,
      { parse_mode: 'HTML', ...q(msg) });
  }

  const emojis = ['✨','⚡','🌙','⭐','💫','🌟','🔥','🍀','🎯','🪐','🌊','🫧','🎈','🧩','🎵','🦋','🌸','☄️','🍉','🪄'];
  const mentions = rows.map((m, i) => `<a href="tg://user?id=${m.id}">${emojis[i % emojis.length]}</a>`);
  const userText = String(customText || '').trim();
  const head = userText
    ? `<b>${esc(userText)}</b>\n\n`
    : `<b>TAG ALL MEMBER</b>\n\n`;
  const chunks = [];
  let current = '';
  for (const mention of mentions) {
    const candidate = current ? `${current} ${mention}` : mention;
    if ((head.length + candidate.length) > 3800 && current) {
      chunks.push(current);
      current = mention;
    } else current = candidate;
  }
  if (current) chunks.push(current);

  for (let i = 0; i < chunks.length; i++) {
    const prefix = i === 0 ? head : `<b>${esc(userText || 'TAG ALL MEMBER')}</b> <i>(${i + 1}/${chunks.length})</i>\n\n`;
    await bot.sendMessage(msg.chat.id, prefix + chunks[i], {
      parse_mode: 'HTML',
      disable_web_page_preview: true,
      ...q(msg)
    });
  }
}

async function setGroupLocked(bot, msg, locked) {
  if (!(await requireAdmin(bot, msg))) return;
  try {
    const me = await bot.getMe();
    const bm = await bot.getChatMember(msg.chat.id, me.id);
    if (!['creator', 'administrator'].includes(String(bm.status))) {
      return bot.sendMessage(msg.chat.id, '◇ Bot harus menjadi admin grup untuk lock/unlock grup.', q(msg));
    }
    const permissions = locked
      ? {
          can_send_messages: false,
          can_send_audios: false,
          can_send_documents: false,
          can_send_photos: false,
          can_send_videos: false,
          can_send_video_notes: false,
          can_send_voice_notes: false,
          can_send_polls: false,
          can_add_web_page_previews: false,
          can_change_info: false,
          can_invite_users: true,
          can_pin_messages: false,
          can_manage_topics: false
        }
      : {
          can_send_messages: true,
          can_send_audios: true,
          can_send_documents: true,
          can_send_photos: true,
          can_send_videos: true,
          can_send_video_notes: true,
          can_send_voice_notes: true,
          can_send_polls: true,
          can_add_web_page_previews: true,
          can_change_info: false,
          can_invite_users: true,
          can_pin_messages: false,
          can_manage_topics: false
        };
    await bot.setChatPermissions(msg.chat.id, permissions, { use_independent_chat_permissions: true });
    await bot.sendMessage(msg.chat.id, `<blockquote expandable>${locked ? '🔒 <b>GRUP DI-LOCK</b>\n\nMember biasa tidak dapat mengirim pesan. Admin tetap dapat mengelola grup.' : '🔓 <b>GRUP DI-UNLOCK</b>\n\nMember biasa dapat mengirim pesan kembali.'}</blockquote>`, { parse_mode: 'HTML', ...q(msg) });
  } catch (e) {
    await reportError(bot, locked ? 'group_lock' : 'group_unlock', e, { chatId: msg.chat.id, actorId: msg.from?.id });
    await bot.sendMessage(msg.chat.id, `❌ <b>${locked ? 'LOCK' : 'UNLOCK'} GAGAL</b>\n\n${esc(e.message || String(e))}`, { parse_mode: 'HTML', ...q(msg) });
  }
}

async function resolveGroupTarget(msg, target = '') {
  if (msg.reply_to_message?.from?.id) return Number(msg.reply_to_message.from.id);
  const raw = String(target || '').trim();
  if (/^\d+$/.test(raw)) return Number(raw);
  const mention = raw.replace(/^@/, '').trim();
  if (mention) {
    try {
      const user = await msg._bot.getChat(`@${mention}`);
      return Number(user.id);
    } catch {}
  }
  return null;
}

async function promoteTarget(bot, msg, target) {
  if (!(await requireAdmin(bot, msg))) return;
  msg._bot = bot;
  const userId = await resolveGroupTarget(msg, target);
  if (!userId) return bot.sendMessage(msg.chat.id, '◇ Reply pesan user lalu ketik /promote, atau gunakan /promote @username / USER_ID.', q(msg));
  try {
    const targetMember = await bot.getChatMember(msg.chat.id, userId);
    if (['creator', 'administrator'].includes(targetMember.status)) {
      return bot.sendMessage(msg.chat.id, '◇ User tersebut sudah menjadi admin.', q(msg));
    }
    await bot.promoteChatMember(msg.chat.id, userId, {
      can_manage_chat: true,
      can_delete_messages: true,
      can_manage_video_chats: true,
      can_restrict_members: true,
      can_promote_members: false,
      can_change_info: false,
      can_invite_users: true,
      can_post_messages: true,
      can_edit_messages: true,
      can_pin_messages: true,
      can_manage_topics: true
    });
    await bot.sendMessage(msg.chat.id, `◇ <b>ADMIN BERHASIL DITAMBAHKAN</b>\n\nUser ID: <code>${userId}</code>`, { parse_mode: 'HTML', ...q(msg) });
  } catch (e) {
    await reportError(bot, 'group_promote', e, { chatId: msg.chat.id, actorId: msg.from?.id, targetId: userId });
    await bot.sendMessage(msg.chat.id, `❌ Gagal promote: ${esc(e.message || String(e))}`, { parse_mode: 'HTML', ...q(msg) });
  }
}

async function demoteTarget(bot, msg, target) {
  if (!(await requireAdmin(bot, msg))) return;
  msg._bot = bot;
  const userId = await resolveGroupTarget(msg, target);
  if (!userId) return bot.sendMessage(msg.chat.id, '◇ Reply admin lalu ketik /demote, atau gunakan /demote @username / USER_ID.', q(msg));
  try {
    const targetMember = await bot.getChatMember(msg.chat.id, userId);
    if (targetMember.status === 'creator') return bot.sendMessage(msg.chat.id, '◇ Owner grup tidak dapat didemote oleh bot.', q(msg));
    if (targetMember.status !== 'administrator') return bot.sendMessage(msg.chat.id, '◇ User tersebut bukan admin.', q(msg));
    await bot.promoteChatMember(msg.chat.id, userId, {
      can_manage_chat: false,
      can_delete_messages: false,
      can_manage_video_chats: false,
      can_restrict_members: false,
      can_promote_members: false,
      can_change_info: false,
      can_invite_users: false,
      can_post_messages: false,
      can_edit_messages: false,
      can_pin_messages: false,
      can_manage_topics: false
    });
    await bot.sendMessage(msg.chat.id, `◇ <b>ADMIN BERHASIL DITURUNKAN</b>\n\nUser ID: <code>${userId}</code>`, { parse_mode: 'HTML', ...q(msg) });
  } catch (e) {
    await reportError(bot, 'group_demote', e, { chatId: msg.chat.id, actorId: msg.from?.id, targetId: userId });
    await bot.sendMessage(msg.chat.id, `❌ Gagal demote: ${esc(e.message || String(e))}`, { parse_mode: 'HTML', ...q(msg) });
  }
}

function groupMenuText() {
  return `<blockquote expandable><b>╭━━〔 GROUP MENU 〕━━╮</b>\n` +
    `│ 👥 Member & Admin\n` +
    `│ 🔐 Lock / Unlock\n` +
    `│ 📣 Tag All\n` +
    `│ 🛡️ Moderation & Protection\n` +
    `│ 🎨 Canvas\n` +
    `│ ⌕ Scrape\n` +
    `╰━━━━━━━━━━━━━━━━━━━━╯\n\n` +
    `<b>GROUP TOOLS</b>\n` +
    `⪼ /all atau @all — tag member yang sudah dikenali bot\n` +
    `⪼ /lock • /unlock\n` +
    `⪼ /promote • /demote\n` +
    `⪼ /adduser\n\n` +
    `<b>CANVAS</b>\n` +
    `⪼ /brat • /fakeiqc • /fakengl • /faketweet\n` +
    `⪼ /wanted • /fakedana • /codesnap • /movieposter • /tarot\n\n` +
    `<b>SCRAPE</b>\n` +
    `⪼ /tiktok • /youtube • /spotify • /instagram\n` +
    `⪼ /mediafire • /savefrom\n` +
    `⪼ /animesearch • /animeongoing • /animeschedule • /animedetail\n` +
    `⪼ /biner • /debiner • /githubstalk • /npmstalk • /mlstalk\n\n` +
    `<i>Fitur Canvas/Scrape dipasang sebagai command agar handler tidak dobel.</i>` +
    `</blockquote>`;
}

function menuKeyboard(chatId) {
  const enabled = (() => {
    try {
      const f = path.join(process.cwd(), "db", "groupGuard.json");
      const d = JSON.parse(fs.readFileSync(f, "utf8"));
      return !!d?.[String(chatId)]?.enabled;
    } catch { return false; }
  })();
  return { inline_keyboard: [
    [{ text: `${enabled ? "🟢" : "🔴"} Jaga Grup`, callback_data: "gg:open" }],
    [{ text: "Dashboard", callback_data: "back" }]
  ] };
}

function antiCfg(chatId) {
  const key=String(chatId); db.anti[key] ||= { link:false, spam:false, toxic:false, sticker:false, photo:false, video:false, document:false, audio:false, voice:false, forward:false, caps:false };
  return db.anti[key];
}
const antiLabels={link:'Anti Link',spam:'Anti Spam',toxic:'Anti Toxic',sticker:'Anti Sticker',photo:'Anti Photo',video:'Anti Video',document:'Anti Document',audio:'Anti Audio',voice:'Anti Voice',forward:'Anti Forward',caps:'Anti Caps'};
const toxicWords=['anjing','bangsat','kontol','memek','tolol','goblok','bajingan','ngentot'];
const spamCache=new Map();

const pages={
 search:`<b>⌕ SEARCH CENTER</b>\n\n<blockquote expandable>/search [kata kunci]\n/google [kata kunci]\n/wiki [kata kunci]</blockquote>`,
 fun:`<b>✦ FUN CENTER</b>\n\n<blockquote expandable>/apakah [pertanyaan]\n/berapa [pertanyaan]\n/bagaimana [pertanyaan]\n/rate [teks]\n/jodoh [nama]\n/truth\n/dare\n/quotes</blockquote>`,
 game:`<b>◉ GAME CENTER</b>\n\n<blockquote expandable>/tebakangka\n/family100\n/tictactoe</blockquote>`,
 ai:`<b>◇ AI CENTER</b>\n\n<blockquote expandable>/ai [pertanyaan]\n/ai reply pesan</blockquote>`,
 tools:`<b>▣ TOOLS CENTER</b>\n\n<blockquote expandable><b>MEDIA TOOLS</b>\n/qr [teks]\n/ssweb [url]\n/imginfo (reply gambar)\n/tourl (reply media)\n/hd (reply foto)\n/hdvideo (reply video)\n/hdvideo2 (reply video)\n/txt2img [prompt]\n/txt2img2 [prompt]
/txt2imgv2 [prompt]\n/img2img [prompt] (reply gambar)\n/img2prompt (reply gambar)\n/rembg (reply gambar)\n/upscale (reply gambar)\n/seaart [prompt]\n/seaart3d [prompt] (reply gambar)\n/tts [teks]\n/wink (reply media)\n/mconverter [url/file]\n/downloader URL</blockquote>\n\n<blockquote expandable><b>SEARCH & INFO</b>\n/dafont [font]\n/wallpaper [kata kunci]\n/gsmarena [nama HP]\n/wwchar [karakter]\n/hokinfo [hero]\n/dramabox [judul]\n/tiktoksearch [kata kunci]</blockquote>\n\n<blockquote expandable><b>AM PREMIUM</b>\n/amprem — auto buat akun Alight Motion Premium\nFlow: Register → Ads → TempMail → Premium → Firebase → Deep Link</blockquote>\n\n<blockquote expandable><b>REACT WA CHANNEL</b>\n/reactwa — kirim reaksi emoji ke pesan saluran WhatsApp\nCara: /reactwa → isi URL saluran → isi emoji (max 5)</blockquote>`
};

const gameState=new Map();
const family=[
  {q:'Sebutkan 5 benda yang sering ada di kamar.', a:['kasur','bantal','lemari','meja','kursi','lampu','cermin','kipas']},
  {q:'Sebutkan 5 makanan yang populer di Indonesia.', a:['nasi goreng','mie','sate','bakso','rendang','gado','soto','ayam']},
  {q:'Sebutkan 5 aplikasi chat.', a:['whatsapp','telegram','line','discord','messenger','signal']}
];
function norm(s){return String(s||'').toLowerCase().replace(/[^a-z0-9 ]/g,'').trim();}

async function register(bot) {
  // Catat member yang terlihat bot. Ini menjadi sumber /tagall karena Bot API
  // memang tidak menyediakan getChatMembers untuk seluruh anggota grup.
  bot.on('message', rememberUsersFromMessage);
  bot.on('edited_message', rememberUsersFromMessage);

  // Callback juga memberi sinyal member aktif walaupun dia belum mengirim pesan teks.
  bot.on('callback_query', cb => {
    try {
      if (cb?.message && isGroup(cb.message) && cb?.from) rememberGroupMember(cb.message, cb.from);
    } catch {}
  });

  // Simpan update keanggotaan juga supaya cache /all makin lengkap.
  bot.on('chat_member', upd => {
    try {
      const chat = upd?.chat;
      const cm = upd?.new_chat_member;
      const member = cm?.user;
      if (!chat || !member || member.is_bot) return;
      const status = String(cm?.status || '');
      if (status === 'left' || status === 'kicked' || (status === 'restricted' && cm?.is_member === false)) {
        markGroupMemberInactive(chat.id, member.id);
      } else {
        rememberGroupMember({ chat, from: member }, member);
      }
    } catch {}
  });

  bot.on('chat_join_request', upd => {
    try {
      if (upd?.chat && upd?.from && !upd.from.is_bot) rememberGroupMember({ chat: upd.chat, from: upd.from }, upd.from);
    } catch {}
  });

  // Group Menu baru — satu menu canonical untuk semua tombol grup.
  bot.on('callback_query', async cb => {
    const d = String(cb.data || '');
    if (!d.startsWith('gmenu:')) return;
    const msg = cb.message;
    if (!msg?.chat) return bot.answerCallbackQuery(cb.id).catch(() => {});
    await bot.answerCallbackQuery(cb.id).catch(() => {});
    try {
      const fakeAdminMsg = { chat: msg.chat, from: cb.from, message_id: msg.message_id };
      if (!(await requireAdmin(bot, fakeAdminMsg))) return;
      if (d === 'gmenu:tagall') {
        const fake = { chat: msg.chat, from: cb.from, message_id: msg.message_id };
        return sendTagAll(bot, fake, "Panggilan untuk semua member");
      }
      if (d === 'gmenu:lock' || d === 'gmenu:unlock') {
        const fake = { chat: msg.chat, from: cb.from, message_id: msg.message_id };
        return setGroupLocked(bot, fake, d.endsWith(':lock'));
      }
      if (d === 'gmenu:addadmin') {
        return bot.sendMessage(msg.chat.id, '<blockquote expandable>👑 <b>ADD ADMIN</b>\n\nReply pesan user lalu kirim <code>/promote</code>.\nAtau gunakan <code>/promote @username</code> / <code>/promote USER_ID</code>.\nTurunkan admin dengan <code>/demote</code>.\n\nBot harus menjadi admin dan memiliki izin Promote Members.</blockquote>', { parse_mode: 'HTML' });
      }
      if (d === 'gmenu:adduser') {
        return bot.sendMessage(msg.chat.id, '<blockquote expandable>👤 <b>ADD USER</b>\n\nGunakan <code>/adduser</code> untuk membuat invite link 1 orang.\n\nTelegram tidak mengizinkan bot memaksa akun tertentu masuk ke grup.</blockquote>', { parse_mode: 'HTML' });
      }
    } catch (e) {
      await reportError(bot, 'group_menu_callback', e, { chatId: msg.chat.id, actorId: cb.from?.id });
    }
  });

  bot.onText(/^\/(?:tagall|all)(?:@\w+)?(?:\s+([\s\S]+))?$/i, (msg, m) => sendTagAll(bot, msg, m?.[1] || ""));
  bot.onText(/^@all(?:\s+([\s\S]+))?$/i, (msg, m) => sendTagAll(bot, msg, m?.[1] || ""));
  bot.onText(/^\/lock(?:@\w+)?$/i, msg => setGroupLocked(bot, msg, true));
  bot.onText(/^\/unlock(?:@\w+)?$/i, msg => setGroupLocked(bot, msg, false));
  bot.onText(/^\/(?:addadmin|promote)(?:@\w+)?(?:\s+(@?[A-Za-z0-9_]+|\d+))?$/i, async (msg, m) => promoteTarget(bot, msg, m[1] || ''));
  bot.onText(/^\/demote(?:@\w+)?(?:\s+(@?[A-Za-z0-9_]+|\d+))?$/i, async (msg, m) => demoteTarget(bot, msg, m[1] || ''));
  bot.onText(/^\/adduser(?:@\w+)?(?:\s+(.+))?$/i, async (msg, m) => {
    if (!(await requireAdmin(bot, msg))) return;
    const label = (m[1] || '').trim();
    try {
      const link = await bot.createChatInviteLink(msg.chat.id, {
        name: label ? `Invite ${label}` : 'Invite member',
        member_limit: 1
      });
      await bot.sendMessage(msg.chat.id, `<blockquote expandable>👤 <b>INVITE USER</b>\n\n${label ? `Target: <b>${esc(label)}</b>\n` : ''}Link: ${esc(link.invite_link)}\n\nUser dapat masuk melalui link tersebut.</blockquote>`, { parse_mode: 'HTML', ...q(msg) });
    } catch (e) {
      await reportError(bot, 'group_add_user', e, { chatId: msg.chat.id, actorId: msg.from?.id });
      await bot.sendMessage(msg.chat.id, `❌ Gagal membuat invite: ${esc(e.message || String(e))}`, { parse_mode: 'HTML', ...q(msg) });
    }
  });

  // Category callbacks; one message is edited in place.
  bot.on('callback_query', async cb=>{
    if (!['fh_search','fh_fun','fh_game','fh_ai','fh_tools'].includes(cb.data)) return;
    await bot.answerCallbackQuery(cb.id).catch(()=>{});
    const text=groupMenuText();
    const opts={chat_id:cb.message.chat.id,message_id:cb.message.message_id,parse_mode:'HTML',reply_markup:menuKeyboard(cb.message.chat.id)};
    try { if(cb.message.photo) await bot.editMessageCaption(text,opts); else await bot.editMessageText(text,opts); } catch { try{await bot.editMessageText(text,opts)}catch{} }
  });
  // Simpan join request yang masuk. Bot API tidak menyediakan getChatJoinRequests;
  // request harus ditangkap lewat update chat_join_request agar /accall tetap bisa bekerja.
  bot.on('chat_join_request', req => {
    try { rememberJoinRequest(req); }
    catch (e) { reportError(bot, 'join_request_store', e, { chatId: req?.chat?.id, userId: req?.from?.id }); }
  });

  // Hapus request dari cache setelah user benar-benar masuk.
  bot.on('message', msg => {
    if (!msg?.chat?.id || !Array.isArray(msg.new_chat_members)) return;
    for (const member of msg.new_chat_members) {
      try { forgetJoinRequest(msg.chat.id, member.id); } catch {}
    }
  });

  // Approve semua request yang sudah diterima bot.
  bot.onText(/^\/(accall|approveall)(?:@\w+)?$/i, async msg=>{
    if(!(await requireAdmin(bot,msg))) return;

    const list = getPendingJoinRequests(msg.chat.id);
    if(!list.length) {
      return bot.sendMessage(
        msg.chat.id,
        `<blockquote expandable>◇ <b>TIDAK ADA REQUEST</b>\n\nBelum ada join request yang tersimpan.\n\n` +
        `Pastikan bot adalah admin dan memiliki izin <b>Invite Users / Add Users</b> agar update join request diterima.</blockquote>`,
        {parse_mode:'HTML', ...q(msg)}
      );
    }

    let ok = 0;
    let failed = 0;
    const failedRows = [];

    try {
      await loading(bot,msg,
        ['Menyiapkan ACC ALL...','Membaca request tersimpan...','Menyetujui anggota...'],
        async update => {
          for (const r of list) {
            try {
              await bot.approveChatJoinRequest(msg.chat.id, Number(r.userId));
              ok++;
              forgetJoinRequest(msg.chat.id, r.userId);
            } catch (e) {
              failed++;
              failedRows.push(`${r.username ? '@' + r.username : r.firstName || r.userId}: ${e.message || 'gagal'}`);
              // Request yang sudah diproses Telegram tidak perlu dicoba lagi.
              if (/already|missing|not found|processed|request/i.test(String(e.message || ''))) {
                forgetJoinRequest(msg.chat.id, r.userId);
              }
              await reportError(bot, 'accall_approve', e, {
                chatId: msg.chat.id,
                userId: r.userId,
                username: r.username ? '@' + r.username : ''
              });
            }
            await new Promise(resolve => setTimeout(resolve, 120));
          }
        }
      );

      const failedText = failedRows.length
        ? `\n\n<b>Gagal:</b>\n${failedRows.slice(0,8).map(esc).join('\n')}`
        : '';

      await bot.sendMessage(
        msg.chat.id,
        `<blockquote expandable>◉ <b>ACC ALL SELESAI</b>\n\n` +
        `✓ Berhasil: <b>${ok}</b>\n` +
        `✕ Gagal: <b>${failed}</b>\n` +
        `▣ Total request: <b>${list.length}</b>${failedText}</blockquote>`,
        {parse_mode:'HTML', ...q(msg)}
      );
    } catch(e) {
      await reportError(bot, 'accall', e, { chatId: msg.chat.id, actorId: msg.from?.id });
      await bot.sendMessage(
        msg.chat.id,
        `❌ <b>ACC ALL GAGAL</b>\n\n<code>${esc(e.message || String(e))}</code>\n\n` +
        `Detail error sudah dikirim ke owner.`,
        {parse_mode:'HTML', ...q(msg)}
      );
    }
  });

  // Invite helper. Telegram bots cannot force-add arbitrary users; they can create invite links.
  bot.onText(/^\/add(?:@\w+)?(?:\s+(.+))?$/i, async(msg,m)=>{
    if(!(await requireAdmin(bot,msg))) return; const target=(m[1]||'').trim();
    try { const link=await bot.createChatInviteLink(msg.chat.id,{name:target?`Invite ${target}`:'Invite member',member_limit:1}); await bot.sendMessage(msg.chat.id,`◇ <b>INVITE LINK</b>\n\nTarget: <b>${esc(target||'anggota')}</b>\nLink: ${esc(link.invite_link)}\n\nTelegram tidak mengizinkan bot memaksa menambahkan akun secara langsung.`,{parse_mode:'HTML',...q(msg)}); } catch(e){ await reportError(bot,'group_add_invite',e,{chatId:msg.chat.id,actorId:msg.from?.id}); await bot.sendMessage(msg.chat.id,`❌ Gagal membuat invite: ${esc(e.message)}\n\nDetail error sudah dikirim ke owner.`,{parse_mode:'HTML',...q(msg)});}
  });

  // Absen simple group session.
  bot.onText(/^\/mulaiabsen(?:@\w+)?$/i, async msg=>{ if(!(await requireAdmin(bot,msg)))return; db.groups[groupKey(msg)]={...(db.groups[groupKey(msg)]||{}),absen:{active:true,members:[]}}; saveDB(db); await bot.sendMessage(msg.chat.id,'◉ <b>ABSEN DIMULAI</b>\n\nKetik /absen untuk masuk daftar.',{parse_mode:'HTML',...q(msg)}); });
  bot.onText(/^\/absen(?:@\w+)?$/i, async msg=>{ if(!isGroup(msg))return; const g=db.groups[groupKey(msg)]; if(!g?.absen?.active)return bot.sendMessage(msg.chat.id,'◇ Absen belum dimulai.',q(msg)); const id=String(msg.from.id); if(!g.absen.members.some(x=>x.id===id))g.absen.members.push({id,name:msg.from.first_name||'User'}); saveDB(db); await bot.sendMessage(msg.chat.id,`◉ <b>ABSEN</b>\n\n${esc(msg.from.first_name||'User')} sudah tercatat.\nTotal: <b>${g.absen.members.length}</b>`,{parse_mode:'HTML',...q(msg)}); });
  bot.onText(/^\/cekabsen(?:@\w+)?$/i, async msg=>{ if(!isGroup(msg))return; const a=db.groups[groupKey(msg)]?.absen; const list=a?.members||[]; await bot.sendMessage(msg.chat.id,`◉ <b>DAFTAR ABSEN</b>\n\n${list.length?list.map((x,i)=>`${i+1}. ${esc(x.name)}`).join('\n'):'Belum ada yang absen.'}`,{parse_mode:'HTML',...q(msg)}); });
  bot.onText(/^\/selesaiabsen(?:@\w+)?$/i, async msg=>{ if(!(await requireAdmin(bot,msg)))return; const g=db.groups[groupKey(msg)]; const n=g?.absen?.members?.length||0; if(g)g.absen.active=false;saveDB(db);await bot.sendMessage(msg.chat.id,`◇ <b>ABSEN SELESAI</b>\n\nTotal hadir: <b>${n}</b>`,{parse_mode:'HTML',...q(msg)}); });

  // Anti settings. Excludes status/story anti because Telegram has no WhatsApp Status.
  bot.onText(/^\/(anti(?:link|spam|toxic|sticker|photo|video|document|audio|voice|forward|caps)|antilink|antispam|antitoxic|antisticker|antiphoto|antivideo|antidocument|antiaudio|antivoice|antiforward|anticaps)(?:@\w+)?\s+(on|off)$/i, async(msg,m)=>{
    if(!(await requireAdmin(bot,msg)))return; let raw=m[1].toLowerCase().replace(/^anti/,'').replace(/^anti/,''); if(raw==='')raw='link'; const c=antiCfg(msg.chat.id); c[raw]=m[2].toLowerCase()==='on'; saveDB(db); await bot.sendMessage(msg.chat.id,`◇ <b>${esc(antiLabels[raw]||raw)}</b> ${c[raw]?'AKTIF':'NONAKTIF'}.`,{parse_mode:'HTML',...q(msg)});
  });
  bot.onText(/^\/listanti(?:@\w+)?$/i, async msg=>{if(!isGroup(msg))return;const c=antiCfg(msg.chat.id);await bot.sendMessage(msg.chat.id,`◇ <b>ANTI STATUS</b>\n\n${Object.entries(antiLabels).map(([k,v])=>`${c[k]?'●':'○'} ${v}`).join('\n')}`,{parse_mode:'HTML',...q(msg)});});

  // Basic anti enforcement. Only deletes when enabled; requires bot admin.
  bot.on('message', async msg=>{
    if(!isGroup(msg)||!msg.from||msg.from.is_bot)return;
    const c=antiCfg(msg.chat.id); if(!Object.values(c).some(Boolean))return;
    if(await isAdmin(bot,msg,msg.from.id))return;
    let reason=null; const text=msg.text||msg.caption||'';
    if(c.link && /(?:https?:\/\/|t\.me\/|www\.)/i.test(text)) reason='link';
    if(c.toxic && toxicWords.some(w=>new RegExp(`\\b${w}\\b`,'i').test(text))) reason='toxic';
    if(c.sticker && msg.sticker) reason='sticker';
    if(c.photo && msg.photo) reason='photo';
    if(c.video && (msg.video||msg.animation)) reason='video';
    if(c.document && msg.document) reason='document';
    if(c.audio && msg.audio) reason='audio';
    if(c.voice && msg.voice) reason='voice';
    if(c.forward && (msg.forward_from||msg.forward_from_chat||msg.forward_origin)) reason='forward';
    if(c.caps && text.length>12 && text.replace(/[^A-Z]/g,'').length>Math.max(8,text.replace(/[^A-Za-z]/g,'').length*0.65)) reason='caps';
    if(c.spam && text){const key=`${msg.chat.id}:${msg.from.id}`;const now=Date.now();const arr=(spamCache.get(key)||[]).filter(t=>now-t<7000);arr.push(now);spamCache.set(key,arr);if(arr.length>=6)reason='spam';}
    if(!reason)return;
    try{await bot.deleteMessage(msg.chat.id,msg.message_id);}catch{}
    try{await bot.sendMessage(msg.chat.id,`⚠ <b>${esc(antiLabels[reason]||'Anti')}</b>\nPesan ${esc(reason)} terdeteksi dan dihapus.`,{parse_mode:'HTML',...q(msg)}).then(m=>setTimeout(()=>bot.deleteMessage(msg.chat.id,m.message_id).catch(()=>{}),3500));}catch{}
  });

  // SEARCH
  bot.onText(/^\/(search|google|wiki)(?:@\w+)?\s+(.+)$/i, async(msg,m)=>{
    const term=m[2].trim();
    try{const result=await loading(bot,msg,['Menyiapkan pencarian...','Menghubungkan ke mesin pencari...','Mengambil hasil...'],async()=>{
      if(m[1].toLowerCase()==='wiki'){const r=await axios.get(`https://id.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(term)}`,{timeout:15000});return `<b>⌕ WIKIPEDIA</b>\n\n<b>${esc(r.data.title)}</b>\n${esc(r.data.extract||'Tidak ada ringkasan.').slice(0,2600)}\n\n${esc(r.data.content_urls?.desktop?.page||'')}`;}
      const r=await axios.get('https://api.duckduckgo.com/',{params:{q:term,format:'json',no_html:1,skip_disambig:0},timeout:15000}); return `<b>⌕ SEARCH</b>\n\n<b>${esc(term)}</b>\n\n${esc(r.data.AbstractText||r.data.Answer||'Tidak ada ringkasan. Coba kata kunci yang lebih spesifik.').slice(0,3000)}${r.data.AbstractURL?`\n\n${esc(r.data.AbstractURL)}`:''}`;
    }); await bot.sendMessage(msg.chat.id,result,{parse_mode:'HTML',...q(msg)});}catch(e){await bot.sendMessage(msg.chat.id,`❌ Search gagal: ${esc(e.message)}`,{parse_mode:'HTML',...q(msg)});}
  });

  // FUN
  bot.onText(/^\/(apakah|berapa|bagaimana)(?:@\w+)?\s*(.*)$/i, async(msg,m)=>{const answers=['Iya, kemungkinan besar.','Belum tentu.','Coba cek lagi faktanya.','Bisa jadi, tapi jangan terlalu cepat menyimpulkan.','Tidak ada yang bisa memastikan dari informasi itu.'];const a=answers[Math.floor(Math.random()*answers.length)];await bot.sendMessage(msg.chat.id,`✦ <b>${m[1].toUpperCase()}</b>\n\nPertanyaan: ${esc(m[2]||'—')}\nJawaban: <b>${a}</b>`,{parse_mode:'HTML',...q(msg)});});
  bot.onText(/^\/(truth|dare|quotes)(?:@\w+)?$/i, async msg=>{const data={truth:['Apa hal yang paling kamu sembunyikan dari teman?','Siapa orang yang terakhir kamu stalk?','Apa keputusan paling impulsifmu?'],dare:['Kirim stiker terakhir yang kamu pakai.','Ganti nama profil 5 menit.','Tag satu teman dan bilang halo.'],quotes:['Progress kecil tetap progress.','Jangan menukar tujuan dengan alasan.','Kalau mau hasil berbeda, ubah tindakan.']};const arr=data[msg.text.split(/[ @]/)[0].slice(1)]||data.quotes;await bot.sendMessage(msg.chat.id,`✦ <b>${esc(msg.text.slice(1).toUpperCase())}</b>\n\n${esc(arr[Math.floor(Math.random()*arr.length)])}`,{parse_mode:'HTML',...q(msg)});});

  // GAME: number + family100, group scoped.
  bot.onText(/^\/tebakangka(?:@\w+)?$/i, async msg=>{const n=Math.floor(Math.random()*50)+1;gameState.set(String(msg.chat.id),{type:'number',n,tries:0});await bot.sendMessage(msg.chat.id,'◉ <b>TEBAK ANGKA</b>\n\nAku sudah memilih angka 1–50. Kirim angka tebakanmu.',{parse_mode:'HTML',...q(msg)});});
  bot.onText(/^\/family100(?:@\w+)?$/i, async msg=>{const item=family[Math.floor(Math.random()*family.length)];gameState.set(String(msg.chat.id),{type:'family',item,found:[]});await bot.sendMessage(msg.chat.id,`◉ <b>FAMILY 100</b>\n\n${esc(item.q)}\n\nKetik jawabanmu.`,{parse_mode:'HTML',...q(msg)});});
  bot.on('message',async msg=>{if(!isGroup(msg)||!msg.text||msg.text.startsWith('/'))return;const st=gameState.get(String(msg.chat.id));if(!st)return;const t=norm(msg.text);if(st.type==='number'&&/^\d+$/.test(t)){const n=Number(t);st.tries++;const hint=n<st.n?'Terlalu kecil.':'Terlalu besar.';if(n===st.n){gameState.delete(String(msg.chat.id));return bot.sendMessage(msg.chat.id,`◉ <b>BENAR!</b>\n\nAngkanya <b>${n}</b>. Percobaan: <b>${st.tries}</b>.`,{parse_mode:'HTML',...q(msg)});}return bot.sendMessage(msg.chat.id,`◇ ${hint} Coba lagi.`,{parse_mode:'HTML',...q(msg)});}if(st.type==='family'){const idx=st.item.a.findIndex(a=>norm(a)===t||t.includes(norm(a)));if(idx>=0&&!st.found.includes(idx)){st.found.push(idx);if(st.found.length>=5){gameState.delete(String(msg.chat.id));return bot.sendMessage(msg.chat.id,'◉ <b>FAMILY 100 SELESAI!</b>\n\nKalian menemukan 5 jawaban.',{parse_mode:'HTML',...q(msg)});}return bot.sendMessage(msg.chat.id,`✓ Jawaban masuk. Skor: <b>${st.found.length}/5</b>`,{parse_mode:'HTML',...q(msg)});}}});

  // SEARCH: API nyata yang kompatibel dengan Telegram.
  bot.onText(/^\/wiki(?:@\w+)?\s+(.+)$/i, async (msg,m)=>{
    const term=m[1].trim();
    try {
      const out=await loading(bot,msg,['Menyiapkan Wikipedia...','Mengambil artikel...','Merapikan hasil...'],async()=>{
        const r=await axios.get(`https://id.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(term)}`,{timeout:15000});
        if(!r.data?.title) throw new Error('Artikel tidak ditemukan.');
        return `<b>⌕ WIKIPEDIA</b>\n\n<b>${esc(r.data.title)}</b>\n\n${esc(r.data.extract||'Tidak ada ringkasan.').slice(0,2800)}${r.data.content_urls?.desktop?.page?`\n\n${esc(r.data.content_urls.desktop.page)}`:''}`;
      });
      await bot.sendMessage(msg.chat.id,out,{parse_mode:'HTML',...q(msg)});
    } catch(e){ await bot.sendMessage(msg.chat.id,`❌ <b>WIKIPEDIA GAGAL</b>\n\n${esc(e.message)}`,{parse_mode:'HTML',...q(msg)}); }
  });

  // TOOLS ditangani oleh src/extraTools.js agar setiap command hanya terdaftar sekali.

  // Fun tambahan yang benar-benar memiliki handler.
  bot.onText(/^\/jodoh(?:@\w+)?(?:\s+(.+))?$/i, async(msg,m)=>{
    const name=(m[1]||msg.from.first_name||'Kamu').trim(); const score=Math.floor(Math.random()*41)+60;
    await bot.sendMessage(msg.chat.id,`✦ <b>JODOH CHECK</b>\n\nNama: <b>${esc(name)}</b>\nKecocokan: <b>${score}%</b>\n\n${score>=85?'Potensinya tinggi.':'Masih perlu lihat kenyataannya.'}`,{parse_mode:'HTML',...q(msg)});
  });

  // TicTacToe sederhana berbasis chat: tidak lagi menjadi command kosong.
  bot.onText(/^\/tictactoe(?:@\w+)?$/i, async msg=>{
    const key=String(msg.chat.id); if(gameState.get(key)?.type==='ttt') return bot.sendMessage(msg.chat.id,'◇ Game TicTacToe sedang berjalan di chat ini.',q(msg));
    const board=['·','·','·','·','·','·','·','·','·']; gameState.set(key,{type:'ttt',board,turn:String(msg.from.id)});
    const kb={inline_keyboard:[[0,1,2].map(i=>({text:board[i],callback_data:`ttt:${key}:${i}`})),[3,4,5].map(i=>({text:board[i],callback_data:`ttt:${key}:${i}`})),[6,7,8].map(i=>({text:board[i],callback_data:`ttt:${key}:${i}`}))]};
    await bot.sendMessage(msg.chat.id,`◉ <b>TIC TAC TOE</b>\n\nGiliran: <b>${esc(msg.from.first_name||'Player')}</b>\nTekan kotak untuk mulai.`,{parse_mode:'HTML',reply_markup:kb,...q(msg)});
  });
  bot.on('callback_query',async cb=>{
    if(!String(cb.data||'').startsWith('ttt:')) return; await bot.answerCallbackQuery(cb.id).catch(()=>{});
    const [,key,idx]=cb.data.split(':'); const st=gameState.get(key); if(!st||st.type!=='ttt') return;
    if(st.turn!==String(cb.from.id)) return bot.answerCallbackQuery(cb.id,{text:'Bukan giliranmu.',show_alert:true}).catch(()=>{});
    const i=Number(idx); if(st.board[i]!=='·') return;
    st.board[i]='X';
    const win=[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]].some(a=>a.every(n=>st.board[n]==='X'));
    if(win||st.board.every(x=>x!=='·')) gameState.delete(key);
    else {const empty=st.board.map((v,n)=>v==='·'?n:-1).filter(n=>n>=0); const r=empty[Math.floor(Math.random()*empty.length)]; st.board[r]='O'; st.turn=String(cb.from.id);}
    const kb={inline_keyboard:[[0,1,2].map(n=>({text:st.board[n],callback_data:`ttt:${key}:${n}`})),[3,4,5].map(n=>({text:st.board[n],callback_data:`ttt:${key}:${n}`})),[6,7,8].map(n=>({text:st.board[n],callback_data:`ttt:${key}:${n}`}))]};
    const text=win?`◉ <b>TIC TAC TOE</b>\n\nKamu menang.`:st.board.every(x=>x!=='·')?`◉ <b>TIC TAC TOE</b>\n\nHasil: seri.`:`◉ <b>TIC TAC TOE</b>\n\nX = kamu • O = bot`;
    try{await bot.editMessageText(text,{chat_id:cb.message.chat.id,message_id:cb.message.message_id,parse_mode:'HTML',reply_markup:win||st.board.every(x=>x!=='·')?undefined:kb});}catch{}
  });

  // AI: configurable endpoint, with a compatible fallback from the user's previous project context.
  bot.onText(/^\/ai(?:@\w+)?(?:\s+([\s\S]+))?$/i, async(msg,m)=>{let prompt=(m[1]||'').trim();if(!prompt&&msg.reply_to_message)prompt=msg.reply_to_message.text||msg.reply_to_message.caption||'';if(!prompt)return bot.sendMessage(msg.chat.id,'◇ Gunakan /ai [pertanyaan] atau reply pesan lalu /ai.',q(msg));try{const out=await loading(bot,msg,['Menyiapkan AI...','Menghubungkan model...','Menyusun jawaban...'],async()=>{const base=process.env.AI_API_URL||'https://api-xemoz-official.my.id/api/ai/perplexity.php';const r=await axios.get(base,{params:{q:prompt},timeout:60000});return r.data?.result||r.data?.answer||r.data?.data||r.data?.message||r.data?.text||JSON.stringify(r.data);});await bot.sendMessage(msg.chat.id,`◇ <b>AI RESULT</b>\n\n<blockquote expandable>${esc(String(out).slice(0,12000))}</blockquote>`,{parse_mode:'HTML',...q(msg)});}catch(e){await bot.sendMessage(msg.chat.id,`❌ AI gagal: ${esc(e.message)}`,{parse_mode:'HTML',...q(msg)});}});

  // Helpful utility commands.
  bot.onText(/^\/groupinfo(?:@\w+)?$/i, async msg=>{if(!isGroup(msg))return;const c=await bot.getChat(msg.chat.id);if(!c)return bot.sendMessage(msg.chat.id,'◇ Grup tidak dapat dibaca bot.',{...q(msg)});await bot.sendMessage(msg.chat.id,`◇ <b>GROUP INFO</b>\n\nNama: <b>${esc(c.title||'-')}</b>\nID: <code>${c.id}</code>\nUsername: <b>${esc(c.username?`@${c.username}`:'private')}</b>`,{parse_mode:'HTML',...q(msg)});});
}
module.exports=register;
