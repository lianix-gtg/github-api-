// LianiX AI Error Repair Assistant
// Menganalisis error dan membuat saran perbaikan/patch untuk OWNER.
// Versi baru: AI bisa langsung fix file, kirim backup dulu, lalu terapkan patch.
const fs = require('fs');
const path = require('path');
const axios = require('axios');
const archiver = require('archiver');
const settings = require('../settings.js');
const { generateText } = require('./aiProvider.js');

const STORE = new Map();
const MAX_STORE = 80;
const OUT_DIR = path.join(__dirname, '..', 'output', 'ai-fixes');
const BACKUP_DIR = path.join(__dirname, '..', 'output', 'ai-backups');
const ACTIVE_ACTIONS = new Set();

// Root direktori project (satu level di atas src/)
const PROJECT_ROOT = path.join(__dirname, '..');

function esc(v = '') {
  return String(v).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function remember(code, payload = {}) {
  STORE.set(String(code), {
    code: String(code),
    type: String(payload.type || 'unknown'),
    raw: String(payload.raw || '').slice(0, 7000),
    context: payload.context || {},
    createdAt: Date.now(),
  });
  while (STORE.size > MAX_STORE) STORE.delete(STORE.keys().next().value);
}

function get(code) { return STORE.get(String(code)); }

// Ekstrak path file dari stack trace error
function extractFilePaths(raw) {
  const found = new Set();
  // Match: /absolute/path/to/file.js:line:col atau ./relative
  const patterns = [
    /at .+ \((.+\.js):\d+:\d+\)/g,
    /at (.+\.js):\d+:\d+/g,
  ];
  for (const rx of patterns) {
    let m;
    while ((m = rx.exec(raw)) !== null) {
      const p = m[1];
      // Filter: hanya file dalam project (bukan node_modules)
      if (!p.includes('node_modules') && !p.includes('internal/') && !p.startsWith('node:')) {
        // Resolve ke absolute path kalau perlu
        const abs = path.isAbsolute(p) ? p : path.resolve(PROJECT_ROOT, p);
        if (fs.existsSync(abs)) found.add(abs);
      }
    }
  }
  return [...found];
}

async function askAI(item, mode = 'analyze', fileContent = null) {
  let prompt;
  if (mode === 'direct_fix' && fileContent) {
    prompt = `Kamu adalah AI debugger expert untuk bot Telegram Node.js milik user sendiri.
Perbaiki hanya masalah nyata yang ditunjukkan oleh error. Jangan ubah logika bisnis yang tidak terkait.

ERROR CODE: ${item.code}
TYPE: ${item.type}
ERROR:
${item.raw}

KODE FILE YANG PERLU DIPERBAIKI:
\`\`\`javascript
${fileContent}
\`\`\`

INSTRUKSI:
1. Berikan HANYA isi file JavaScript lengkap yang sudah diperbaiki.
2. Jangan potong bagian yang tidak diubah.
3. Jangan tambahkan markdown fence atau penjelasan.
4. Jangan ubah token, password, URL rahasia, atau konfigurasi yang tidak berkaitan.
5. Pertahankan kompatibilitas CommonJS/Node.js yang sudah digunakan file.`;
  } else {
    prompt = `Kamu adalah AI debugger untuk bot Telegram Node.js milik user sendiri.
Analisis hanya berdasarkan error dan context yang diberikan. Jangan mengarang file atau line.
Mode: ${mode}.
Jika mode=patch, berikan perubahan aman dan jangan menyarankan bypass autentikasi, token, atau keamanan.

ERROR CODE: ${item.code}
TYPE: ${item.type}
CONTEXT: ${JSON.stringify(item.context)}
ERROR:
${item.raw}

Format:
1. Penyebab paling mungkin
2. Bukti dari error
3. Perbaikan
4. Patch/contoh perubahan bila memungkinkan
5. Cara verifikasi setelah diperbaiki`;
  }

  const result = await generateText(prompt, { pollinationsModel: process.env.ERROR_AI_MODEL || 'openai' });
  return String(result.text || '').trim();
}

function saveFix(code, content) {
  fs.mkdirSync(OUT_DIR, { recursive: true });
  const file = path.join(OUT_DIR, `AI-FIX-${String(code).replace(/[^A-Za-z0-9_-]/g, '_')}.md`);
  fs.writeFileSync(file, content, 'utf8');
  return file;
}

// Buat zip backup dari file-file yang akan diubah
function createBackupZip(filePaths, code) {
  return new Promise((resolve, reject) => {
    fs.mkdirSync(BACKUP_DIR, { recursive: true });
    const zipPath = path.join(BACKUP_DIR, `BACKUP-${String(code).replace(/[^A-Za-z0-9_-]/g, '_')}-${Date.now()}.zip`);
    const output = fs.createWriteStream(zipPath);
    const archive = archiver('zip', { zlib: { level: 9 } });

    output.on('close', () => resolve(zipPath));
    archive.on('error', reject);
    archive.pipe(output);

    for (const fp of filePaths) {
      if (fs.existsSync(fp)) {
        const name = path.relative(PROJECT_ROOT, fp).replace(/\\/g, '/');
        archive.file(fp, { name });
      }
    }
    archive.finalize();
  });
}

function keyboard(code) {
  return {
    inline_keyboard: [[
      { text: 'AI ANALISIS', callback_data: `aierr:analyze:${code}`.slice(0, 64) },
      { text: 'AI FIX', callback_data: `aierr:patch:${code}`.slice(0, 64) },
      { text: 'AI FIX LANGSUNG', callback_data: `aierr:direct:${code}`.slice(0, 64) },
    ]]
  };
}

function register(bot) {
  bot.on('callback_query', async (cb) => {
    const data = String(cb.data || '');
    const m = data.match(/^aierr:(analyze|patch|direct):(.+)$/);
    if (!m) return;

    if (!settings.isOwner(cb.from?.id)) {
      return bot.answerCallbackQuery(cb.id, { text: 'Khusus OWNER.', show_alert: true }).catch(() => {});
    }

    const item = get(m[2]);
    if (!item) return bot.answerCallbackQuery(cb.id, { text: 'Data error sudah kedaluwarsa.', show_alert: true }).catch(() => {});

    const mode = m[1];
    const actionKey = `${cb.message?.chat?.id}:${item.code}:${mode}`;
    if (ACTIVE_ACTIONS.has(actionKey)) {
      return bot.answerCallbackQuery(cb.id, { text: 'Proses masih berjalan. Tunggu hasil sebelumnya.', show_alert: false }).catch(() => {});
    }
    ACTIVE_ACTIONS.add(actionKey);

    // ── MODE: AI FIX LANGSUNG ─────────────────────────────────────────────
    if (mode === 'direct') {
      await bot.answerCallbackQuery(cb.id, { text: 'AI sedang menganalisis dan menyiapkan fix...' }).catch(() => {});

      const chatId = cb.message.chat.id;
      let statusMsg;
      try {
        statusMsg = await bot.sendMessage(chatId, '<b>AI FIX LANGSUNG</b>\n\n- Mendeteksi file dari stack trace...', { parse_mode: 'HTML' });
      } catch (_) {}

      const updateStatus = async (text) => {
        if (!statusMsg) return;
        try {
          await bot.editMessageText(`<b>AI FIX LANGSUNG</b>\n\n- ${esc(text)}`, {
            chat_id: chatId, message_id: statusMsg.message_id, parse_mode: 'HTML',
          });
        } catch (_) {}
      };

      try {
        // 1. Deteksi file dari stack trace
        const filePaths = extractFilePaths(item.raw);

        if (filePaths.length === 0) {
          await updateStatus('File tidak terdeteksi dari stack trace.');
          await bot.sendMessage(chatId,
            `<b>PERINGATAN AI FIX LANGSUNG GAGAL</b>\n\n` +
            `<blockquote expandable>Tidak ada file project yang terdeteksi dari stack trace error ini.\n\n` +
            `Error mungkin dari library eksternal atau tidak menyertakan path file.\n\n` +
            `Gunakan <b>AI FIX</b> untuk saran manual.</blockquote>`,
            { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: 'AI FIX Manual', callback_data: `aierr:patch:${item.code}` }]] } }
          ).catch(() => {});
          ACTIVE_ACTIONS.delete(actionKey);
          return;
        }

        // 2. Baca konten file pertama yang relevan
        await updateStatus(`Membaca ${path.basename(filePaths[0])}...`);
        const targetFile = filePaths[0];
        const fileContent = fs.readFileSync(targetFile, 'utf-8');

        if (fileContent.length > 80000) {
          await bot.sendMessage(chatId,
            `<b>PERINGATAN File Terlalu Besar</b>\n\n` +
            `<code>${esc(path.relative(PROJECT_ROOT, targetFile))}</code>\n` +
            `Ukuran: ${Math.round(fileContent.length / 1024)}KB (maks 80KB untuk AI fix langsung).\n\n` +
            `Gunakan AI FIX untuk saran manual.`,
            { parse_mode: 'HTML' }
          ).catch(() => {});
          ACTIVE_ACTIONS.delete(actionKey);
          return;
        }

        // 3. Buat backup ZIP sebelum mengubah apapun
        await updateStatus('Membuat backup file sebelum diubah...');
        const zipPath = await createBackupZip(filePaths, item.code);
        const zipName = path.basename(zipPath);

        // 4. Kirim backup ke owner
        await updateStatus('Mengirim backup ke owner...');
        try {
          await bot.sendDocument(chatId, zipPath, {
            caption: `<b>BACKUP SEBELUM AI FIX</b>\n\n` +
              `<code>Error Code: ${esc(item.code)}</code>\n` +
              `File yang akan diubah:\n` +
              filePaths.map(fp => `<code>${esc(path.relative(PROJECT_ROOT, fp))}</code>`).join('\n') +
              `\n\n<i>Backup ini dikirim SEBELUM AI menerapkan perubahan.</i>`,
            parse_mode: 'HTML',
          });
        } catch (backupErr) {
          await bot.sendMessage(chatId, `<b>PERINGATAN Backup gagal dikirim:</b> <code>${esc(backupErr.message)}</code>\n\nProses dihentikan untuk keamanan.`, { parse_mode: 'HTML' }).catch(() => {});
          ACTIVE_ACTIONS.delete(actionKey);
          return;
        }

        // 5. Minta AI generate fixed code
        await updateStatus('Menghubungi AI untuk generate kode perbaikan...');
        const fixedCode = await askAI(item, 'direct_fix', fileContent);

        if (!fixedCode || fixedCode.length < 50) {
          throw new Error('AI tidak menghasilkan kode yang valid.');
        }

        // Bersihkan kalau AI tetap wrap dengan backtick
        let cleanCode = fixedCode;
        if (cleanCode.startsWith('```')) {
          cleanCode = cleanCode.replace(/^```(?:javascript|js)?\n?/, '').replace(/\n?```$/, '');
        }

        // 6. Tulis file yang diperbaiki
        await updateStatus(`Menerapkan fix ke ${path.basename(targetFile)}...`);
        fs.writeFileSync(targetFile, cleanCode, 'utf-8');

        // 7. Kirim hasil fix sebagai file juga
        const fixFilePath = saveFix(item.code, `# AI FIX ${item.code}\n\nFile: ${path.relative(PROJECT_ROOT, targetFile)}\nType: ${item.type}\n\n\`\`\`javascript\n${cleanCode}\n\`\`\`\n`);

        // 8. Laporan selesai
        if (statusMsg) {
          await bot.deleteMessage(chatId, statusMsg.message_id).catch(() => {});
        }

        // Satu output final: file hasil fix. Status/loading sebelumnya sudah dihapus.
        await bot.sendDocument(chatId, fixFilePath, {
          caption: `<b>AI FIX LANGSUNG SELESAI</b>\n\n` +
            `<code>${esc(path.relative(PROJECT_ROOT, targetFile))}</code>\n` +
            `Backup: <code>${esc(zipName)}</code>\n` +
            `Error Code: <code>${esc(item.code)}</code>\n\n` +
            `<i>Restart bot untuk menerapkan perubahan.</i>`,
          parse_mode: 'HTML',
        }).catch(() => {});



      } catch (e) {
        if (statusMsg) {
          await bot.editMessageText(
            `GAGAL <b>AI FIX LANGSUNG GAGAL</b>\n\n<code>${esc(e.message)}</code>`,
            { chat_id: chatId, message_id: statusMsg.message_id, parse_mode: 'HTML' }
          ).catch(() => {});
        } else {
          await bot.sendMessage(chatId, `GAGAL <b>AI FIX LANGSUNG GAGAL</b>\n\n<code>${esc(e.message)}</code>`, { parse_mode: 'HTML' }).catch(() => {});
        }
      }
      finally {
        ACTIVE_ACTIONS.delete(actionKey);
      }
      return;
    }

    // ── MODE: ANALYZE / PATCH ─────────────────────────────────────────────
    await bot.answerCallbackQuery(cb.id, { text: 'AI sedang menganalisis...' }).catch(() => {});
    try {
      const answer = await askAI(item, mode);
      const prefix = mode === 'patch' ? 'AI PATCH / SARAN PERUBAHAN' : 'AI ANALISIS ERROR';
      const body = `<b>${prefix}</b>\n\n<blockquote expandable>${esc(answer).slice(0, 12000)}</blockquote>`;
      if (mode === 'patch') {
        const file = saveFix(item.code, `# AI FIX ${item.code}\n\nType: ${item.type}\n\n${answer}\n`);
        await bot.sendDocument(cb.message.chat.id, file, {
          caption: `<b>AI FIX</b>\nCode: <code>${esc(item.code)}</code>`,
          parse_mode: 'HTML',
        }).catch(() => {});
        return;
      }
      await bot.sendMessage(cb.message.chat.id, body, {
        parse_mode: 'HTML',
        reply_to_message_id: cb.message.message_id,
      }).catch(() => {});
    } catch (e) {
      await bot.sendMessage(cb.message.chat.id, `<b>AI ERROR</b>\n<code>${esc(e.message)}</code>`, { parse_mode: 'HTML' }).catch(() => {});
    } finally {
      ACTIVE_ACTIONS.delete(actionKey);
    }
  });
}

module.exports = { remember, get, keyboard, register };
