// src/limit.js
// Sistem limit request pembuatan panel/vps per role.
// - Tiap role punya limit sendiri (bisa angka, bisa unlimited).
// - Owner/admin (adminID.json) selalu unlimited, tidak pernah kena limit.
// - Dev bisa atur limit tiap role lewat /setlimit.
// - Dev bisa reset semua limit ke default (5) lewat /resetlimit + tombol konfirmasi.

const fs = require("fs");
const path = require("path");
const settings = require("../settings.js");
const roleAccess = require("./roleAccess");

const ROOT = path.join(__dirname, "..");
const OWNER_UID = settings.ownerId;

const OWNER_FILE = path.join(ROOT, "db/users/adminID.json");
const DEV_FILE = path.join(ROOT, "db/users/developerUsers.json");
const FOUNDER_FILE = path.join(ROOT, "db/users/founderUsers.json");
const CEO_FILE = path.join(ROOT, "db/users/ceoUsers.json");
const TK_FILE = path.join(ROOT, "db/users/tkUsers.json");
const PT_FILE = path.join(ROOT, "db/users/ptUsers.json");
const PREMIUM_FILE = path.join(ROOT, "db/users/premiumUsers.json");
const RESELLER_FILE = path.join(ROOT, "db/users/resellerUsers.json");

const LIMIT_DB_FILE = path.join(ROOT, "db/reqLimit.json");

// Urutan role dari yang paling rendah ke paling tinggi.
// Sesuaikan/tambah di sini kalau nama role di project kamu beda.
const ROLE_ORDER = [
  "member", "reseller", "premium", "pt", "tk", "ceo", "founder",
  "pemilik", "cofounder", "king", "khusus", "god"
];

// Limit bawaan (dipakai saat file limit belum ada / saat direset lewat tombol dev)
const DEFAULT_LIMITS = {
  member: 5,
  reseller: 5,
  premium: 10,
  pt: 15,
  tk: 20,
  ceo: 25,
  founder: -1,
  pemilik: -1,
  cofounder: -1,
  king: -1,
  khusus: -1,
  god: -1,
};

function loadJson(file, fallback) {
  try {
    if (!fs.existsSync(file)) return fallback;
    return JSON.parse(fs.readFileSync(file, "utf8"));
  } catch {
    return fallback;
  }
}

function saveJson(file, data) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

function loadLimitDB() {
  const db = loadJson(LIMIT_DB_FILE, null);
  if (db && db.roleLimits && db.usage) {
    let changed = false;
    for (const role of ROLE_ORDER) {
      if (!(role in db.roleLimits)) {
        db.roleLimits[role] = DEFAULT_LIMITS[role] ?? 5;
        changed = true;
      }
    }
    if (changed) saveJson(LIMIT_DB_FILE, db);
    return db;
  }
  const fresh = { roleLimits: { ...DEFAULT_LIMITS }, usage: {} };
  saveJson(LIMIT_DB_FILE, fresh);
  return fresh;
}

function saveLimitDB(db) {
  saveJson(LIMIT_DB_FILE, db);
}

// PENTING: fitur limit ini khusus 1 orang DEV (settings.ownerId).
// Sengaja TIDAK ikut cek adminID.json / ceoUsers.json, supaya CEO,
// admin panel, atau owner lain yang cuma "titipan" tetap tidak bisa akses.
function isOwner(userId) {
  return settings.isOwner(userId);
}

// Tentukan role user. Prioritas dari yang paling tinggi ke paling rendah.
// Kalau user tidak ada di list manapun, dianggap "member".
function getUserRole(userId) {
  const id = String(userId);
  if (isOwner(id) || loadJson(OWNER_FILE, []).map(String).includes(id)) return "owner";
  if (loadJson(FOUNDER_FILE, []).map(String).includes(id)) return "founder";
  if (roleAccess.hasActiveRole("ceo", id)) return "ceo";
  if (roleAccess.hasActiveRole("tk", id)) return "tk";
  if (roleAccess.hasActiveRole("pt", id)) return "pt";
  if (roleAccess.hasActiveRole("premium", id)) return "premium";
  if (roleAccess.hasActiveRole("reseller", id)) return "reseller";
  return "member";
}

function isUnlimitedValue(val) {
  return val === null || val === -1 || val === "unlimited" || val === Infinity;
}

function getRoleLimit(role) {
  const db = loadLimitDB();
  if (!(role in db.roleLimits)) return DEFAULT_LIMITS[role] ?? 5;
  return db.roleLimits[role];
}

// Cek apakah user masih boleh melakukan request (TIDAK memotong kuota).
// Panggil ini di paling atas setiap fungsi pembuatan panel/vps.
function checkLimit(userId) {
  const role = getUserRole(userId);
  if (role === "owner") return { allowed: true, role, remaining: null };

  const limit = getRoleLimit(role);
  if (isUnlimitedValue(limit)) return { allowed: true, role, limit: null, remaining: null };

  const db = loadLimitDB();
  const used = db.usage[String(userId)]?.count || 0;
  const remaining = limit - used;

  return {
    allowed: remaining > 0,
    role,
    limit,
    used,
    remaining: Math.max(remaining, 0),
  };
}

// Panggil ini SETELAH panel/vps berhasil dibuat (jangan panggil kalau proses gagal).
function consumeLimit(userId) {
  const role = getUserRole(userId);
  if (role === "owner") return;

  const limit = getRoleLimit(role);
  if (isUnlimitedValue(limit)) return;

  const db = loadLimitDB();
  const key = String(userId);
  if (!db.usage[key]) db.usage[key] = { count: 0 };
  db.usage[key].count += 1;
  saveLimitDB(db);
}

// Set limit 1 role. value: angka, atau string "unlimited".
function setRoleLimit(role, value) {
  if (!ROLE_ORDER.includes(role)) return false;
  const db = loadLimitDB();
  db.roleLimits[role] = value === "unlimited" ? null : Number(value);
  saveLimitDB(db);
  return true;
}

// Reset SEMUA limit role ke default (5/5/10/15/20/25) + hapus semua pemakaian user.
function resetAllLimits() {
  const db = { roleLimits: { ...DEFAULT_LIMITS }, usage: {} };
  saveLimitDB(db);
  return db;
}

// Reset pemakaian 1 user saja tanpa mengubah limit role.
function resetUserUsage(userId) {
  const db = loadLimitDB();
  delete db.usage[String(userId)];
  saveLimitDB(db);
}

function formatLimitInfo() {
  const db = loadLimitDB();
  let text = "⌗ <b>Konfigurasi Limit Request Panel</b>\n\n";
  for (const role of ROLE_ORDER) {
    const val = db.roleLimits[role];
    text += `• ${role.toUpperCase()} : ${isUnlimitedValue(val) ? "∞ Unlimited" : val + "x"}\n`;
  }
  text += "\n⌖ OWNER/ADMIN : ∞ Unlimited (tidak terkena limit)";
  text += `\n\nUbah limit: <code>/setlimit &lt;role&gt; &lt;angka|unlimited&gt;</code>`;
  text += `\nContoh: <code>/setlimit reseller 5</code>, <code>/setlimit ceo unlimited</code>`;
  text += `\nReset semua ke default: <code>/resetlimit</code>`;
  return text;
}

// Preset angka yang muncul sebagai tombol cepat waktu atur limit per role
const QUICK_VALUES = ["5", "10", "15", "20", "25", "50", "unlimited"];

// Helper: edit pesan yang benar (caption kalau pesannya foto, text kalau pesan biasa)
async function editMenu(bot, q, text, keyboard) {
  const chatId = q.message.chat.id;
  const messageId = q.message.message_id;
  const opts = {
    chat_id: chatId,
    message_id: messageId,
    parse_mode: "HTML",
    reply_markup: keyboard,
  };
  if (q.message.photo) {
    return bot.editMessageCaption(text, opts);
  }
  return bot.editMessageText(text, opts);
}

function limitMenuText() {
  const db = loadLimitDB();
  let text = `<blockquote expandable>┱ ⚿ Limit Menu\n┢────────`;
  for (const role of ROLE_ORDER) {
    const val = db.roleLimits[role];
    text += `\n┣ ${role.toUpperCase()}: ${isUnlimitedValue(val) ? "∞ Unlimited" : val + "x"}`;
  }
  text += `\n┹</blockquote>\n\nPilih menu di bawah ▼`;
  return text;
}

function limitMenuKeyboard() {
  return {
    inline_keyboard: [
      [{ text: "Atur Limit Role", callback_data: "limit_roles" }],
      [{ text: "Limit AM Premium", callback_data: "limit_amprem" }],
      [{ text: "Reset Ke Default", callback_data: "limit_reset_ask" }],
      [{ text: "Limit Saya", callback_data: "limit_mine" }],
      [{ text: "‹‹‹", callback_data: "back" }],
    ],
  };
}

// Pengaturan limit AM Premium memakai DB terpisah agar tidak bercampur
// dengan limit panel/VPS. Nilai -1 berarti unlimited.
const AM_LIMIT_FILE = path.join(ROOT, "db/amPremLimit.json");
const AM_ROLES = ["premium","pt","tk","ceo","founder","pemilik","cofounder","king","khusus","god"];
function loadAmLimitDB() {
  const fallback = { limits: Object.fromEntries(AM_ROLES.map(r => [r, ["cofounder","king","khusus","god"].includes(r) ? -1 : 1])), usage: {} };
  const db = loadJson(AM_LIMIT_FILE, fallback);
  if (!db || typeof db !== "object") return fallback;
  db.limits = db.limits && typeof db.limits === "object" ? db.limits : {};
  db.usage = db.usage && typeof db.usage === "object" ? db.usage : {};
  let changed = false;
  for (const role of AM_ROLES) {
    if (!(role in db.limits)) {
      db.limits[role] = ["cofounder","king","khusus","god"].includes(role) ? -1 : 1;
      changed = true;
    }
  }
  if (changed) saveJson(AM_LIMIT_FILE, db);
  return db;
}
function saveAmLimitDB(db) { saveJson(AM_LIMIT_FILE, db); }
function amLimitKeyboard() {
  const db = loadAmLimitDB();
  const rows = AM_ROLES.map(role => [{
    text: `${role.toUpperCase()}: ${db.limits[role] === -1 ? "∞" : `${db.limits[role]}x`}`,
    callback_data: `limit_amprem_role_${role}`
  }]);
  rows.push([{ text: "Reset ke 1x / Co-Founder+ Unlimited", callback_data: "limit_amprem_reset" }]);
  rows.push([{ text: "‹‹‹", callback_data: "limit_menu" }]);
  return { inline_keyboard: rows };
}

function roleListKeyboard() {
  const rows = [];
  for (let i = 0; i < ROLE_ORDER.length; i += 2) {
    const row = ROLE_ORDER.slice(i, i + 2).map((role) => ({
      text: role.toUpperCase(),
      callback_data: `limit_role_${role}`,
    }));
    rows.push(row);
  }
  rows.push([{ text: "‹‹‹", callback_data: "limit_menu" }]);
  return { inline_keyboard: rows };
}

function roleValueKeyboard(role) {
  const rows = [];
  for (let i = 0; i < QUICK_VALUES.length; i += 3) {
    const row = QUICK_VALUES.slice(i, i + 3).map((v) => ({
      text: v === "unlimited" ? "∞ Unlimited" : `${v}x`,
      callback_data: `limit_setval_${role}_${v}`,
    }));
    rows.push(row);
  }
  rows.push([{ text: "Custom (ketik sendiri)", callback_data: `limit_custom_${role}` }]);
  rows.push([{ text: "‹‹‹", callback_data: "limit_roles" }]);
  return { inline_keyboard: rows };
}

// Nyimpen siapa yang lagi diminta ngetik angka custom, per userId -> { role, chatId, messageId }
const awaitingCustom = {};

// Kirim pesan ke Owner pas ada user yang limitnya udah habis dan kena block.
// Dipanggil dari file lain (panel.js, cvps.js, dll) tepat sebelum nge-return
// "limit habis" ke user, dengan bot instance & msg.from milik user tsb.
async function notifyOwnerLimitReached(bot, fromUser, limitRes) {
  try {
    const uname = fromUser?.username ? `@${fromUser.username}` : (fromUser?.first_name || "Tidak diketahui");
    await bot.sendMessage(
      OWNER_UID,
      `<blockquote expandable>◈ <b>Limit Harian Habis</b>\n\n◉ User  : ${uname} (<code>${fromUser?.id}</code>)\n⌖ Role  : ${limitRes.role.toUpperCase()}\n⬢ Limit : ${limitRes.limit}x\n◉ Terpakai: ${limitRes.used}x\n\n</blockquote>User ini baru aja coba bikin panel/vps tapi limitnya udah habis.`,
      { parse_mode: "HTML" }
    );
  } catch (e) {
    console.error("[limit] Gagal kirim notif limit habis ke owner:", e.message);
  }
}

module.exports = function registerLimitHandlers(bot) {
  // ================= MENU UTAMA (TOMBOL) =================
  bot.on("callback_query", async (q) => {
    if (q.data !== "limit_menu") return;
    if (!isOwner(q.from.id)) {
      return bot.answerCallbackQuery(q.id, { text: "◇ Khusus developer/owner.", show_alert: true });
    }
    await editMenu(bot, q, limitMenuText(), limitMenuKeyboard());
    await bot.answerCallbackQuery(q.id);
  });

  // ================= LIMIT AMPRem =================
  bot.on("callback_query", async (q) => {
    if (q.data !== "limit_amprem") return;
    if (!isOwner(q.from.id)) {
      return bot.answerCallbackQuery(q.id, { text: "◇ Khusus developer/owner.", show_alert: true });
    }
    await editMenu(bot, q, "<blockquote expandable>┱ LIMIT AM PREMIUM\n┢────────\n┣ Role di bawah Co-Founder: default 1x/hari\n┣ Co-Founder ke atas: Unlimited\n┹</blockquote>\n\nPilih role untuk mengatur limit AM:", amLimitKeyboard());
    await bot.answerCallbackQuery(q.id);
  });

  bot.on("callback_query", async (q) => {
    if (q.data !== "limit_amprem_reset") return;
    if (!isOwner(q.from.id)) return bot.answerCallbackQuery(q.id, { text: "◇ Khusus developer/owner.", show_alert: true });
    const db = loadAmLimitDB();
    for (const role of AM_ROLES) db.limits[role] = ["cofounder","king","khusus","god"].includes(role) ? -1 : 1;
    db.usage = {};
    saveAmLimitDB(db);
    await editMenu(bot, q, "<blockquote expandable>✓ Limit AM direset.\n\nSemua role di bawah Co-Founder: 1x/hari.\nCo-Founder dan di atas: Unlimited.</blockquote>", amLimitKeyboard());
    await bot.answerCallbackQuery(q.id, { text: "Limit AM direset" });
  });

  bot.on("callback_query", async (q) => {
    const m = String(q.data || "").match(/^limit_amprem_role_(\w+)$/);
    if (!m) return;
    if (!isOwner(q.from.id)) return bot.answerCallbackQuery(q.id, { text: "◇ Khusus developer/owner.", show_alert: true });
    const role = m[1];
    if (!AM_ROLES.includes(role)) return bot.answerCallbackQuery(q.id);
    const db = loadAmLimitDB();
    const current = db.limits[role] === -1 ? "Unlimited" : `${db.limits[role]}x/hari`;
    const values = [1,2,3,5,10,20];
    const rows = [];
    for (let i=0;i<values.length;i+=3) rows.push(values.slice(i,i+3).map(v => ({ text:`${v}x`, callback_data:`limit_amprem_set_${role}_${v}` })));
    rows.push([{ text:"Unlimited", callback_data:`limit_amprem_set_${role}_-1` }]);
    rows.push([{ text:"‹‹‹", callback_data:"limit_amprem" }]);
    await editMenu(bot, q, `<blockquote expandable>┱ LIMIT AM — ${role.toUpperCase()}\n┢────────\n┣ Saat ini: ${current}\n┹</blockquote>\n\nPilih limit baru:`, { inline_keyboard: rows });
    await bot.answerCallbackQuery(q.id);
  });

  bot.on("callback_query", async (q) => {
    const m = String(q.data || "").match(/^limit_amprem_set_(\w+)_(-?\d+)$/);
    if (!m) return;
    if (!isOwner(q.from.id)) return bot.answerCallbackQuery(q.id, { text: "◇ Khusus developer/owner.", show_alert: true });
    const role=m[1], value=Number(m[2]);
    if (!AM_ROLES.includes(role) || (value !== -1 && value < 0)) return bot.answerCallbackQuery(q.id);
    const db=loadAmLimitDB(); db.limits[role]=value; saveAmLimitDB(db);
    await editMenu(bot, q, `<blockquote expandable>✓ Limit AM ${role.toUpperCase()} diubah ke <b>${value === -1 ? "Unlimited" : value+"x/hari"}</b>.</blockquote>`, amLimitKeyboard());
    await bot.answerCallbackQuery(q.id, { text:"Limit AM diperbarui" });
  });

  // Daftar role yang bisa diatur
  bot.on("callback_query", async (q) => {
    if (q.data !== "limit_roles") return;
    if (!isOwner(q.from.id)) {
      return bot.answerCallbackQuery(q.id, { text: "◇ Khusus developer/owner.", show_alert: true });
    }
    await editMenu(
      bot,
      q,
      "<blockquote expandable>┱ Atur Limit Role\n┢────────\n┹</blockquote>\n\nPilih role yang mau diatur limitnya:",
      roleListKeyboard()
    );
    await bot.answerCallbackQuery(q.id);
  });

  // Pilih 1 role -> tampilkan pilihan angka limit
  bot.on("callback_query", async (q) => {
    if (!q.data || !q.data.match(/^limit_role_(\w+)$/)) return;
    if (!isOwner(q.from.id)) {
      return bot.answerCallbackQuery(q.id, { text: "◇ Khusus developer/owner.", show_alert: true });
    }
    const role = q.data.replace("limit_role_", "");
    if (!ROLE_ORDER.includes(role)) return bot.answerCallbackQuery(q.id);

    const currentVal = getRoleLimit(role);
    const currentText = isUnlimitedValue(currentVal) ? "∞ Unlimited" : `${currentVal}x`;

    await editMenu(
      bot,
      q,
      `<blockquote expandable>┱ ⊙ Limit Role: ${role.toUpperCase()}\n┢────────\n┣ Limit saat ini: ${currentText}\n┹</blockquote>\n\nPilih limit baru:`,
      roleValueKeyboard(role)
    );
    await bot.answerCallbackQuery(q.id);
  });

  // Set nilai limit untuk 1 role dari tombol preset
  bot.on("callback_query", async (q) => {
    if (!q.data || !q.data.startsWith("limit_setval_")) return;
    if (!isOwner(q.from.id)) {
      return bot.answerCallbackQuery(q.id, { text: "◇ Khusus developer/owner.", show_alert: true });
    }

    const parts = q.data.replace("limit_setval_", "").split("_");
    const value = parts.pop();
    const role = parts.join("_");
    if (!ROLE_ORDER.includes(role)) return bot.answerCallbackQuery(q.id);

    setRoleLimit(role, value);
    await bot.answerCallbackQuery(q.id, {
      text: `◉ Limit ${role.toUpperCase()} diatur ke ${value === "unlimited" ? "Unlimited" : value + "x"}`,
    });

    await editMenu(
      bot,
      q,
      "<blockquote expandable>┱ Atur Limit Role\n┢────────\n┹</blockquote>\n\nPilih role yang mau diatur limitnya:",
      roleListKeyboard()
    );
  });

  // Tombol "✎ Custom" -> minta owner ketik angka bebas
  bot.on("callback_query", async (q) => {
    if (!q.data || !q.data.startsWith("limit_custom_")) return;
    if (!isOwner(q.from.id)) {
      return bot.answerCallbackQuery(q.id, { text: "◇ Khusus developer/owner.", show_alert: true });
    }
    const role = q.data.replace("limit_custom_", "");
    if (!ROLE_ORDER.includes(role)) return bot.answerCallbackQuery(q.id);

    awaitingCustom[String(q.from.id)] = {
      role,
      chatId: q.message.chat.id,
      messageId: q.message.message_id,
      hasPhoto: !!q.message.photo,
    };

    await editMenu(
      bot,
      q,
      `<blockquote expandable>┱ ✎ Custom Limit: ${role.toUpperCase()}\n┢────────\n┹</blockquote>\n\nKetik angka limit yang kamu mau (contoh: <code>37</code>), atau ketik <code>unlimited</code> buat gak dibatasi sama sekali.\n\nBalas langsung di chat ini ya.`,
      { inline_keyboard: [[{ text: "⊠ Batal", callback_data: `limit_role_${role}` }]] }
    );
    await bot.answerCallbackQuery(q.id);
  });

  // Tangkap angka/kata "unlimited" yang diketik owner setelah pencet tombol Custom
  bot.on("message", async (msg) => {
    const key = String(msg.from?.id);
    const state = awaitingCustom[key];
    if (!state) return;
    if (!isOwner(msg.from.id)) return; // jaga-jaga
    if (!msg.text) return;
    if (msg.text.startsWith("/")) {
      delete awaitingCustom[key];
      return; // user ngetik command lain, batalkan mode custom diam-diam
    }

    const raw = msg.text.trim().toLowerCase();
    delete awaitingCustom[key]; // state dipakai sekali aja, apapun hasilnya

    if (raw !== "unlimited" && (isNaN(Number(raw)) || Number(raw) < 0 || !Number.isInteger(Number(raw)))) {
      return bot.sendMessage(
        msg.chat.id,
        "◇ Input gak valid. Harus angka bulat positif (contoh: 37) atau kata 'unlimited'. Silakan buka Limit Menu lagi dan ulangi.",
        { reply_to_message_id: msg.message_id }
      );
    }

    setRoleLimit(state.role, raw === "unlimited" ? "unlimited" : Number(raw));

    const confirmText = `◉ Limit role <b>${state.role.toUpperCase()}</b> berhasil diatur ke <b>${
      raw === "unlimited" ? "∞ Unlimited" : raw + "x"
    }</b>.`;
    const backKeyboard = { inline_keyboard: [[{ text: "‹‹‹", callback_data: "limit_roles" }]] };

    try {
      const opts = {
        chat_id: state.chatId,
        message_id: state.messageId,
        parse_mode: "HTML",
        reply_markup: backKeyboard,
      };
      if (state.hasPhoto) {
        await bot.editMessageCaption(confirmText, opts);
      } else {
        await bot.editMessageText(confirmText, opts);
      }
    } catch (e) {
      await bot.sendMessage(msg.chat.id, confirmText, { parse_mode: "HTML", reply_markup: backKeyboard });
    }
  });

  // Minta konfirmasi reset (tombol)
  bot.on("callback_query", async (q) => {
    if (q.data !== "limit_reset_ask") return;
    if (!isOwner(q.from.id)) {
      return bot.answerCallbackQuery(q.id, { text: "◇ Khusus developer/owner.", show_alert: true });
    }
    await editMenu(
      bot,
      q,
      "⚠ <b>Apakah anda yakin ingin reset limit?</b>\n\nSemua limit role akan dikembalikan ke default (Member 5 / Reseller 5 / Premium 10 / PT 15 / TK 20 / CEO 25) dan seluruh pemakaian user akan dihapus.",
      {
        inline_keyboard: [
          [
            { text: "◉ Ya, Reset", callback_data: "limit_reset_confirm" },
            { text: "⊠ Batal", callback_data: "limit_reset_cancel" },
          ],
        ],
      }
    );
    await bot.answerCallbackQuery(q.id);
  });

  // Eksekusi konfirmasi/batal reset (dipakai baik dari command lama maupun tombol menu)
  bot.on("callback_query", async (q) => {
    if (!q.data || !q.data.startsWith("limit_reset_") || q.data === "limit_reset_ask") return;
    if (!isOwner(q.from.id)) {
      return bot.answerCallbackQuery(q.id, { text: "◇ Khusus developer/owner.", show_alert: true });
    }

    if (q.data === "limit_reset_confirm") {
      resetAllLimits();
      await editMenu(
        bot,
        q,
        "◉ <b>Berhasil!</b> Semua limit role telah direset ke default dan pemakaian user dihapus.",
        { inline_keyboard: [[{ text: "‹‹‹", callback_data: "limit_menu" }]] }
      );
    } else if (q.data === "limit_reset_cancel") {
      await editMenu(bot, q, "⊘ Reset limit dibatalkan.", {
        inline_keyboard: [[{ text: "‹‹‹", callback_data: "limit_menu" }]],
      });
    }
    await bot.answerCallbackQuery(q.id);
  });

  // Lihat limit sendiri (tombol, bisa dipakai semua user)
  bot.on("callback_query", async (q) => {
    if (q.data !== "limit_mine") return;
    const res = checkLimit(q.from.id);
    const text =
      res.remaining === null
        ? `<blockquote expandable>◉ Role kamu: <b>${res.role.toUpperCase()}</b></blockquote>\n∞ Limit request: Unlimited`
        : `<blockquote expandable>◉ Role kamu: <b>${res.role.toUpperCase()}</b></blockquote>\n⬢ Limit: ${res.limit}x\n◉ Terpakai: ${res.used}x\n⟡ Sisa: ${res.remaining}x`;

    await editMenu(bot, q, text, {
      inline_keyboard: [[{ text: "‹‹‹", callback_data: isOwner(q.from.id) ? "limit_menu" : "back" }]],
    });
    await bot.answerCallbackQuery(q.id);
  });

  // ================= COMMAND LAMA (opsional, tetap bisa dipakai) =================
  bot.onText(/^\/limitinfo$/, async (msg) => {
    if (!isOwner(msg.from.id)) return;
    await bot.sendMessage(msg.chat.id, formatLimitInfo(), { parse_mode: "HTML" });
  });

  bot.onText(/^\/setlimit (\w+) (\S+)$/i, async (msg, match) => {
    if (!isOwner(msg.from.id)) return;
    const role = match[1].toLowerCase();
    const value = match[2].toLowerCase();

    if (!ROLE_ORDER.includes(role)) {
      return bot.sendMessage(
        msg.chat.id,
        `◇ Role tidak dikenali. Role yang tersedia: ${ROLE_ORDER.join(", ")}`
      );
    }
    if (value !== "unlimited" && (isNaN(Number(value)) || Number(value) < 0)) {
      return bot.sendMessage(msg.chat.id, "◇ Value harus angka positif atau kata 'unlimited'.");
    }

    setRoleLimit(role, value === "unlimited" ? "unlimited" : Number(value));
    await bot.sendMessage(
      msg.chat.id,
      `◉ Limit role <b>${role.toUpperCase()}</b> berhasil diatur ke <b>${
        value === "unlimited" ? "∞ Unlimited" : value + "x"
      }</b>.`,
      { parse_mode: "HTML" }
    );
  });

  bot.onText(/^\/resetlimit$/, async (msg) => {
    if (!isOwner(msg.from.id)) {
      return bot.sendMessage(msg.chat.id, "◇ Fitur ini khusus developer/owner.");
    }
    await bot.sendMessage(
      msg.chat.id,
      "⚠ <b>Apakah anda yakin ingin reset limit?</b>\n\nSemua limit role akan dikembalikan ke default (Member 5 / Reseller 5 / Premium 10 / PT 15 / TK 20 / CEO 25) dan seluruh pemakaian user akan dihapus.",
      {
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "◉ Ya, Reset", callback_data: "limit_reset_confirm" },
              { text: "⊠ Batal", callback_data: "limit_reset_cancel" },
            ],
          ],
        },
      }
    );
  });

  bot.onText(/^\/mylimit$/, async (msg) => {
    const res = checkLimit(msg.from.id);
    if (res.remaining === null) {
      return bot.sendMessage(msg.chat.id, `◉ Role kamu: <b>${res.role.toUpperCase()}</b>\n∞ Limit request: Unlimited`, { parse_mode: "HTML" });
    }
    await bot.sendMessage(
      msg.chat.id,
      `◉ Role kamu: <b>${res.role.toUpperCase()}</b>\n⬢ Limit: ${res.limit}x\n◉ Terpakai: ${res.used}x\n⟡ Sisa: ${res.remaining}x`,
      { parse_mode: "HTML" }
    );
  });
};

// Fungsi-fungsi ini dipakai file lain (panel.js, panelwa.js, cvps.js, start.js, dll)
module.exports.checkLimit = checkLimit;
module.exports.consumeLimit = consumeLimit;
module.exports.getUserRole = getUserRole;
module.exports.resetUserUsage = resetUserUsage;
module.exports.isOwner = isOwner;
module.exports.ROLE_ORDER = ROLE_ORDER;
module.exports.notifyOwnerLimitReached = notifyOwnerLimitReached;

// ===== EXTENDED ROLE SYSTEM (GOD tier) =====
// Role baru di atas FOUNDER, dikelola lewat file JSON masing-masing.
// Urutan: reseller < premium < pt < tk < ceo < founder <
//         pemilik < cofounder < king < khusus < god < owner (dev)

const PEMILIK_FILE   = path.join(ROOT, "db/users/pemilikUsers.json");
const COFOUNDER_FILE = path.join(ROOT, "db/users/cofounderUsers.json");
const KING_FILE      = path.join(ROOT, "db/users/kingUsers.json");
const KHUSUS_FILE    = path.join(ROOT, "db/users/khususUsers.json");
const GOD_FILE       = path.join(ROOT, "db/users/godUsers.json");

// Tambahkan role baru ke DEFAULT_LIMITS (unlimited karena role tinggi)
Object.assign(DEFAULT_LIMITS, {
  pemilik:   -1,
  cofounder: -1,
  king:      -1,
  khusus:    -1,
  god:       -1,
});

// Label display per role key
const ROLE_DISPLAY_LABELS = {
  developer: "DEVELOPER",
  owner:     "OWNER",
  god:       "GOD",
  khusus:    "ROLE KHUSUS",
  king:      "KING",
  cofounder: "CO-FOUNDER",
  pemilik:   "PEMILIK",
  founder:   "FOUNDER",
  ceo:       "CEO",
  tk:        "TK",
  pt:        "PT",
  premium:   "PREMIUM",
  reseller:  "RESELLER",
  member:    "MEMBER",
};

// getUserRoleExtended — cek semua role termasuk yang baru, return key
function getUserRoleExtended(userId) {
  const id = String(userId);
  if (String(OWNER_UID) === id) return "developer";
  if (loadJson(DEV_FILE, []).map(String).includes(id)) return "developer";
  if (loadJson(OWNER_FILE, []).map(String).includes(id)) return "owner";
  if (loadJson(GOD_FILE,       []).map(String).includes(id)) return "god";
  if (loadJson(KHUSUS_FILE,    []).map(String).includes(id)) return "khusus";
  if (loadJson(KING_FILE,      []).map(String).includes(id)) return "king";
  if (loadJson(COFOUNDER_FILE, []).map(String).includes(id)) return "cofounder";
  if (loadJson(PEMILIK_FILE,   []).map(String).includes(id)) return "pemilik";
  if (loadJson(FOUNDER_FILE,   []).map(String).includes(id)) return "founder";
  if (loadJson(CEO_FILE,       []).map(String).includes(id)) return "ceo";
  if (loadJson(TK_FILE,        []).map(String).includes(id)) return "tk";
  if (loadJson(PT_FILE,        []).map(String).includes(id)) return "pt";
  if (loadJson(PREMIUM_FILE,   []).map(String).includes(id)) return "premium";
  if (loadJson(RESELLER_FILE,  []).map(String).includes(id)) return "reseller";
  return "member";
}

function getUserRoleLabel(userId) {
  return ROLE_DISPLAY_LABELS[getUserRoleExtended(userId)] || "MEMBER";
}

// Init: buat file JSON role baru kalau belum ada
for (const f of [PEMILIK_FILE, COFOUNDER_FILE, KING_FILE, KHUSUS_FILE, GOD_FILE]) {
  if (!fs.existsSync(f)) saveJson(f, []);
}

module.exports.getUserRoleExtended = getUserRoleExtended;
module.exports.getUserRoleLabel    = getUserRoleLabel;
module.exports.ROLE_DISPLAY_LABELS = ROLE_DISPLAY_LABELS;
module.exports.PEMILIK_FILE   = PEMILIK_FILE;
module.exports.COFOUNDER_FILE = COFOUNDER_FILE;
module.exports.KING_FILE      = KING_FILE;
module.exports.KHUSUS_FILE    = KHUSUS_FILE;
module.exports.GOD_FILE       = GOD_FILE;
