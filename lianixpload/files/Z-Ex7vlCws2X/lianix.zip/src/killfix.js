// src/killfix.js
//
// Fitur "Cek Kill" — beda dari src/antikill.js (yang mantau via Pterodactyl
// Client API resource usage, jadi cuma jalan kalau API/node-nya masih hidup
// normal). Fitur ini buat kondisi yang lebih parah: NODE/VPS FISIKNYA sendiri
// udah kena disk penuh / not responding gara-gara ada server yang "ngekill"
// (nge-dump file sampah / disk bomb), jadi harus SSH LANGSUNG ke VPS-nya
// (ip|password, root) buat nyari folder volume mana yang paling boros disk,
// baru dicocokin ke server Pterodactyl mana itu lewat Application API.
//
// Alur:
//   1. Owner ketik /cekkill ipvps|password
//   2. Bot SSH ke situ, jalanin `du` di /var/lib/pterodactyl/volumes/*/
//      (path default Wings) buat nemuin folder paling gede + cek disk root.
//   3. Tiap folder (uuid) dicocokin ke server di Panel 1 (settings.domain/plta)
//      lewat Application API, biar ketahuan nama server & siapa ownernya.
//   4. Owner dikasih daftar + tombol per server: "Suspend & Hapus". Sengaja
//      pake tombol konfirmasi (bukan auto tanpa tanya), soalnya aksi ini
//      MENGHAPUS FILE PERMANEN -- kalau salah target gak bisa di-undo.
//   5. Pencet tombol -> server itu langsung disuspend via API + isi folder
//      volume-nya dihapus langsung lewat SSH yang sama.
//
// Password VPS CUMA disimpen di memori sementara (gak pernah ditulis ke
// disk/db), otomatis kehapus abis dipake atau abis 10 menit gak disentuh.

const { Client } = require("ssh2");
const axios = require("axios");
const settings = require("../settings.js");

const OWNER_UID = settings.ownerId;
const { domain, plta } = settings;

const VOLUME_BASE = "/var/lib/pterodactyl/volumes"; // path default Wings

function isOwner(userId) {
  return settings.isOwner(userId);
}

// Jalanin 1 command SSH, return stdout-nya. Timeout biar gak nyangkut
// selama-lamanya kalau IP salah / VPS bener2 gak respon.
function runSSHCommand(host, password, command, timeoutMs = 20000) {
  return new Promise((resolve, reject) => {
    const conn = new Client();
    let out = "";
    let done = false;

    const timer = setTimeout(() => {
      if (done) return;
      done = true;
      try { conn.end(); } catch (_) {}
      reject(new Error("Timeout koneksi/eksekusi SSH."));
    }, timeoutMs);

    conn.on("ready", () => {
      conn.exec(command, (err, stream) => {
        if (err) {
          if (done) return;
          done = true;
          clearTimeout(timer);
          try { conn.end(); } catch (_) {}
          return reject(err);
        }
        stream.on("data", (data) => { out += data.toString(); });
        stream.stderr.on("data", () => {}); // diemin stderr, fokus stdout aja
        stream.on("close", () => {
          if (done) return;
          done = true;
          clearTimeout(timer);
          try { conn.end(); } catch (_) {}
          resolve(out);
        });
      });
    });

    conn.on("error", (err) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      reject(err);
    });

    conn.connect({ host, port: 22, username: "root", password, readyTimeout: 15000 });
  });
}

async function getAllServers() {
  const res = await axios.get(`${domain}/api/application/servers`, {
    headers: { Accept: "application/json", Authorization: `Bearer ${plta}` },
  });
  return res.data?.data || [];
}

async function suspendServer(serverId) {
  await axios.post(
    `${domain}/api/application/servers/${serverId}/suspend`,
    {},
    { headers: { Accept: "application/json", Authorization: `Bearer ${plta}` } }
  );
}

// state per owner (single owner, jadi gak perlu keyed macem2): host/password
// sementara + daftar kandidat hasil cek terakhir.
let pending = null;

function clearPending() {
  pending = null;
}

module.exports = (bot) => {
  bot.onText(/^\/cekkill(?:\s+(.+))?$/i, async (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;

    if (!isOwner(userId)) {
      return bot.sendMessage(chatId, "⌖ Perintah ini khusus owner.");
    }

    const input = (match && match[1] ? match[1] : "").trim();
    if (!input || !input.includes("|")) {
      return bot.sendMessage(
        chatId,
        "◇ Format salah!\nGunakan: <code>/cekkill ipvps|password</code>\n\n" +
          `➳ Bot bakal SSH root ke VPS itu, cari folder <code>${VOLUME_BASE}/&lt;uuid&gt;</code> ` +
          "yang disknya paling boros (biasanya itu penyebab node kena kill/disk penuh), " +
          "terus dicocokin ke server mana di Panel 1.",
        { parse_mode: "HTML" }
      );
    }

    const sep = input.indexOf("|");
    const host = input.slice(0, sep).trim();
    const password = input.slice(sep + 1).trim();
    if (!host || !password) {
      return bot.sendMessage(chatId, "◇ Format salah!\nGunakan: /cekkill ipvps|password");
    }

    const wait = await bot.sendMessage(chatId, "⏳ Konek ke VPS & nyari volume paling boros disk...");

    let duOutput, dfOutput;
    try {
      duOutput = await runSSHCommand(
        host,
        password,
        `du -sm ${VOLUME_BASE}/*/ 2>/dev/null | sort -rn | head -10`
      );
      dfOutput = await runSSHCommand(host, password, "df -h / | tail -1");
    } catch (err) {
      return bot.editMessageText(
        `◇ Gagal konek/eksekusi ke VPS <code>${host}</code>.\n<code>${String(err.message || err).slice(0, 200)}</code>\n\nCek lagi IP/password-nya bener atau enggak.`,
        { chat_id: chatId, message_id: wait.message_id, parse_mode: "HTML" }
      ).catch(() => {});
    }

    const lines = (duOutput || "").split("\n").map((l) => l.trim()).filter(Boolean);
    if (!lines.length) {
      return bot.editMessageText(
        `◉ Gak ketemu isi folder volume yang mencurigakan di <code>${host}</code> (atau path <code>${VOLUME_BASE}</code> gak ada/beda di VPS ini).\n\n⟡ Disk root: <code>${(dfOutput || "-").trim()}</code>`,
        { chat_id: chatId, message_id: wait.message_id, parse_mode: "HTML" }
      ).catch(() => {});
    }

    // parse baris "<sizeMB>\t/var/lib/pterodactyl/volumes/<uuid>/"
    const parsed = lines
      .map((l) => {
        const m = l.match(/^(\d+)\s+.*\/volumes\/([a-f0-9-]{8,36})\/?$/i);
        if (!m) return null;
        return { sizeMb: parseInt(m[1], 10), uuid: m[2] };
      })
      .filter(Boolean);

    if (!parsed.length) {
      return bot.editMessageText(
        `⚠ Ketemu output tapi gak bisa di-parse otomatis. Cek manual:\n<code>${duOutput.slice(0, 500)}</code>`,
        { chat_id: chatId, message_id: wait.message_id, parse_mode: "HTML" }
      ).catch(() => {});
    }

    let servers = [];
    let apiError = "";
    try {
      servers = await getAllServers();
    } catch (err) {
      apiError = err.response?.data ? JSON.stringify(err.response.data).slice(0, 150) : err.message;
    }

    const candidates = parsed.map((p) => {
      const found = servers.find((s) => s.attributes.uuid === p.uuid);
      return {
        uuid: p.uuid,
        sizeMb: p.sizeMb,
        id: found ? found.attributes.id : null,
        name: found ? found.attributes.name : "(uuid gak ketemu di Panel 1)",
        ownerUserId: found ? found.attributes.user : null,
        suspended: found ? found.attributes.suspended : null,
      };
    });

    pending = { host, password, candidates, expiresAt: Date.now() + 10 * 60 * 1000 };

    let text = `⎔ <b>Hasil Cek Kill — ${host}</b>\n\n⟡ Disk root: <code>${(dfOutput || "-").trim()}</code>`;
    if (apiError) text += `\n⚠ Gagal ambil data Panel 1 (${apiError}), nama/ID server di bawah gak lengkap.`;
    text += `\n\n<b>Volume paling boros disk:</b>`;

    const rows = [];
    candidates.forEach((c, i) => {
      text += `\n\n${i + 1}. <b>${c.name}</b>\n   ⟡ ${c.sizeMb}MB | ⌬ <code>${c.uuid}</code>${c.id ? ` | ⌇ ${c.id}` : ""}${c.ownerUserId ? ` | ◉ User ${c.ownerUserId}` : ""}${c.suspended ? " | ⊘ sudah suspend" : ""}`;
      if (c.id && !c.suspended) {
        rows.push([{ text: `⊘ Suspend & Hapus #${i + 1} (${c.sizeMb}MB)`, callback_data: `killfix_${i}` }]);
      }
    });

    text += `\n\n➳ Pencet tombol buat langsung suspend server itu + hapus semua isi foldernya di VPS. <b>Data yang dihapus gak bisa balik lagi</b>, pastiin dulu emang itu yang bikin kena kill.`;

    rows.push([{ text: "⊠ Batal / Tutup", callback_data: "killfix_cancel" }]);

    await bot.editMessageText(text, {
      chat_id: chatId,
      message_id: wait.message_id,
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: rows },
    }).catch(() => {});
  });

  // ================= TOMBOL: EKSEKUSI SUSPEND + HAPUS =================
  bot.on("callback_query", async (query) => {
    if (!/^killfix_\d+$/.test(String(query.data || ""))) return;
    if (!isOwner(query.from.id)) {
      return bot.answerCallbackQuery(query.id, { text: "⌖ Perintah ini khusus owner.", show_alert: true });
    }

    const idx = parseInt(query.data.replace("killfix_", ""), 10);

    if (!pending || pending.expiresAt < Date.now() || !pending.candidates[idx]) {
      return bot.answerCallbackQuery(query.id, { text: "⌛ Sesi kadaluarsa, ulangi /cekkill lagi.", show_alert: true });
    }

    const cand = pending.candidates[idx];
    if (!cand.id) {
      return bot.answerCallbackQuery(query.id, { text: "◇ Server ini gak ketemu di Panel, gak bisa disuspend otomatis.", show_alert: true });
    }
    if (!/^[a-f0-9-]{8,36}$/i.test(cand.uuid)) {
      return bot.answerCallbackQuery(query.id, { text: "◇ Format UUID gak valid, dibatalin demi keamanan.", show_alert: true });
    }

    await bot.answerCallbackQuery(query.id, { text: "⏳ Memproses..." });

    const { host, password } = pending;

    let suspendOk = false;
    let suspendErr = "";
    try {
      await suspendServer(cand.id);
      suspendOk = true;
    } catch (err) {
      suspendErr = err.response?.data ? JSON.stringify(err.response.data).slice(0, 150) : err.message;
    }

    let deleteOk = false;
    let deleteErr = "";
    try {
      await runSSHCommand(host, password, `rm -rf ${VOLUME_BASE}/${cand.uuid}/* ${VOLUME_BASE}/${cand.uuid}/.[!.]* 2>/dev/null`);
      deleteOk = true;
    } catch (err) {
      deleteErr = err.message;
    }

    const resultText =
      `${suspendOk ? "✓" : "◇"} Suspend server <b>${cand.name}</b> (ID: ${cand.id})${suspendOk ? "" : `\n   error: ${suspendErr}`}\n` +
      `${deleteOk ? "✓" : "◇"} Hapus isi folder volume <code>${cand.uuid}</code>${deleteOk ? "" : `\n   error: ${deleteErr}`}`;

    await bot.editMessageText(resultText, {
      chat_id: query.message.chat.id,
      message_id: query.message.message_id,
      parse_mode: "HTML",
    }).catch(() => {});

    clearPending(); // password gak perlu nyangkut lama-lama di memori
  });

  // ================= TOMBOL: BATAL =================
  bot.on("callback_query", async (query) => {
    if (query.data !== "killfix_cancel") return;
    if (!isOwner(query.from.id)) {
      return bot.answerCallbackQuery(query.id, { text: "⌖ Perintah ini khusus owner.", show_alert: true });
    }
    clearPending();
    await bot.answerCallbackQuery(query.id, { text: "Dibatalkan." });
    await bot.editMessageText("◇ Dibatalkan.", {
      chat_id: query.message.chat.id,
      message_id: query.message.message_id,
    }).catch(() => {});
  });

  // Auto-bersihin sesi yang lupa dibatalin/dieksekusi, biar password gak
  // ngendon di memori kelamaan.
  setInterval(() => {
    if (pending && pending.expiresAt < Date.now()) clearPending();
  }, 5 * 60 * 1000);
};
