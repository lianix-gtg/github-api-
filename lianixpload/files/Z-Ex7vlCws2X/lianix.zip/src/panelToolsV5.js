// src/panelToolsV5.js
// ============================================================
//  Implementasi nyata buat 3 kategori command yang tadinya cuma
//  teks placeholder di PANEL MENU (2/3 & 3/3):
//    [ DELETE ]         /delusr /deladp /delsrv /delsrvoff (+versi v2-v5)
//    [ DELETE MASSAL ]  /dellallsrv /dellalluser /dellalladp (+versi v2-v5)
//    [ PANEL TOOLS ]    /unsuspend /unsuspend-v5 /cekapikey /restore
//                       (/suspend & /backup udah ada duluan di panel.js & main.js)
//
//  Semua command versi (v1..v5) resolve domain/plta lewat panelStore
//  (db/panels.json), jadi tiap versi bisa punya panel Pterodactyl beda,
//  sama kayak fitur create-server yang udah ada duluan.
// ============================================================

const fs = require("fs");
const path = require("path");
const fetch = require("node-fetch");
const unzipper = require("unzipper");
const settings = require("../settings.js");
const panelStore = require("./data/panelStore.js");

const OWNER_FILE = "./db/users/adminID.json";
const dev = settings.dev;

function isOwner(userId) {
  try {
    const ownerUsers = JSON.parse(fs.readFileSync(OWNER_FILE));
    return ownerUsers.includes(String(userId));
  } catch {
    return false;
  }
}

function denyNotOwner(bot, chatId) {
  return bot.sendMessage(chatId, "⌖ Perintah ini khusus owner.", {
    reply_markup: { inline_keyboard: [[{ text: "ʟᴀᴘᴏʀᴀɴ", url: `https://t.me/${dev}` }]] },
  });
}

// key panelStore: "1" utk V1 (polos, tanpa akhiran), "2".."5" utk V2-V5
function resolvePanel(versionSuffix) {
  const key = versionSuffix ? versionSuffix.replace(/^v/i, "") : "1";
  return panelStore.getPanel(key);
}

function labelVersion(versionSuffix) {
  return versionSuffix ? versionSuffix.toUpperCase() : "V1";
}

async function safeFetch(url, options, retry = 3) {
  for (let i = 0; i < retry; i++) {
    try {
      return await fetch(url, options);
    } catch (e) {
      if (i === retry - 1) throw e;
      await new Promise((r) => setTimeout(r, 800));
    }
  }
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

module.exports = (bot) => {
  // ============================================================
  //  [ DELETE ] — hapus 1 user by ID
  //  /delusr <ID>      -> V1
  //  /delusrv2..v5 <ID>
  // ============================================================
  function registerDelUser(versionSuffix) {
    const cmd = versionSuffix ? `delusr${versionSuffix}` : "delusr";
    bot.onText(new RegExp(`^\\/${cmd}\\s+(.+)$`, "i"), async (msg, match) => {
      const chatId = msg.chat.id;
      const id = match[1].trim();

      if (!isOwner(msg.from.id)) return denyNotOwner(bot, chatId);

      const { domain, plta } = resolvePanel(versionSuffix);
      if (!domain || !plta) {
        return bot.sendMessage(chatId, `◇ Panel ${labelVersion(versionSuffix)} belum diatur (domain/PLTA kosong).`);
      }

      try {
        const del = await safeFetch(`${domain}/api/application/users/${id}`, {
          method: "DELETE",
          headers: { Accept: "application/json", Authorization: `Bearer ${plta}` },
        });

        if (del.status === 204) {
          return bot.sendMessage(
            chatId,
            `<blockquote expandable>◉ <b>USER BERHASIL DIHAPUS</b>\n\n⌇ Panel: <b>${labelVersion(versionSuffix)}</b>\n⌇ User ID: <code>${id}</code></blockquote>`,
            { parse_mode: "HTML", reply_to_message_id: msg.message_id }
          );
        }
        if (del.status === 404) {
          return bot.sendMessage(chatId, `◇ User ID <code>${id}</code> tidak ditemukan di Panel ${labelVersion(versionSuffix)}!`, { parse_mode: "HTML" });
        }

        const errText = await del.text();
        console.error(`DEL USER ${labelVersion(versionSuffix)} ERROR:`, errText);
        bot.sendMessage(chatId, `⚠ Gagal menghapus user (status ${del.status}). User mungkin masih punya server aktif.`);
      } catch (err) {
        console.error(`DEL USER ${labelVersion(versionSuffix)} ERROR:`, err);
        bot.sendMessage(chatId, `◇ Terjadi error saat menghapus user: ${err.message}`);
      }
    });
  }
  ["", "v2", "v3", "v4", "v5"].forEach(registerDelUser);

  // ============================================================
  //  [ DELETE ] — hapus 1 admin (sub-user) by user ID
  //  /deladpv5 <ID>   ("/deladp" polos & v1..v20 udah ada duluan di panel.js)
  // ============================================================
  bot.onText(/^\/deladpv5\s+(.+)$/i, async (msg, match) => {
    const chatId = msg.chat.id;
    const id = match[1].trim();

    if (!isOwner(msg.from.id)) return denyNotOwner(bot, chatId);

    const { domain, plta } = resolvePanel("v5");
    if (!domain || !plta) {
      return bot.sendMessage(chatId, "◇ Panel V5 belum diatur (domain/PLTA kosong).");
    }

    try {
      const del = await safeFetch(`${domain}/api/application/users/${id}`, {
        method: "DELETE",
        headers: { Accept: "application/json", Authorization: `Bearer ${plta}` },
      });

      if (del.status === 204) {
        return bot.sendMessage(
          chatId,
          `<blockquote expandable>◉ <b>ADMIN BERHASIL DIHAPUS</b>\n\n⌇ Panel: <b>V5</b>\n⌇ Admin ID: <code>${id}</code></blockquote>`,
          { parse_mode: "HTML", reply_to_message_id: msg.message_id }
        );
      }
      if (del.status === 404) {
        return bot.sendMessage(chatId, `◇ Admin ID <code>${id}</code> tidak ditemukan di Panel V5!`, { parse_mode: "HTML" });
      }

      const errText = await del.text();
      console.error("DEL ADP V5 ERROR:", errText);
      bot.sendMessage(chatId, `⚠ Gagal menghapus admin (status ${del.status}).`);
    } catch (err) {
      console.error("DEL ADP V5 ERROR:", err);
      bot.sendMessage(chatId, `◇ Terjadi error: ${err.message}`);
    }
  });

  // ============================================================
  //  [ DELETE ] — hapus 1 server by ID
  //  /delsrvv2..v5 <ID>   ("/delsrv" polos udah ada duluan di panel.js)
  // ============================================================
  function registerDelSrv(versionSuffix) {
    bot.onText(new RegExp(`^\\/delsrv${versionSuffix}\\s+(.+)$`, "i"), async (msg, match) => {
      const chatId = msg.chat.id;
      const id = match[1].trim();

      if (!isOwner(msg.from.id)) return denyNotOwner(bot, chatId);

      const { domain, plta } = resolvePanel(versionSuffix);
      if (!domain || !plta) {
        return bot.sendMessage(chatId, `◇ Panel ${labelVersion(versionSuffix)} belum diatur (domain/PLTA kosong).`);
      }

      try {
        const del = await safeFetch(`${domain}/api/application/servers/${id}`, {
          method: "DELETE",
          headers: { Accept: "application/json", Authorization: `Bearer ${plta}` },
        });

        if (del.status === 204) {
          return bot.sendMessage(
            chatId,
            `<blockquote expandable>◉ <b>SERVER BERHASIL DIHAPUS</b>\n\n⌇ Panel: <b>${labelVersion(versionSuffix)}</b>\n⌇ Server ID: <code>${id}</code></blockquote>`,
            { parse_mode: "HTML", reply_to_message_id: msg.message_id }
          );
        }
        if (del.status === 404) {
          return bot.sendMessage(chatId, `◇ Server ID <code>${id}</code> tidak ditemukan di Panel ${labelVersion(versionSuffix)}!`, { parse_mode: "HTML" });
        }

        const errText = await del.text();
        console.error(`DEL SRV ${labelVersion(versionSuffix)} ERROR:`, errText);
        bot.sendMessage(chatId, `⚠ Gagal menghapus server (status ${del.status}).`);
      } catch (err) {
        console.error(`DEL SRV ${labelVersion(versionSuffix)} ERROR:`, err);
        bot.sendMessage(chatId, `◇ Terjadi error: ${err.message}`);
      }
    });
  }
  ["v2", "v3", "v4", "v5"].forEach(registerDelSrv);

  // ============================================================
  //  [ DELETE ] — hapus 1 server TAPI hanya kalau statusnya offline
  //  /delsrvoff <ID>          -> V1
  //  /delsrvoffv2..v5 <ID>
  // ============================================================
  function registerDelSrvOff(versionSuffix) {
    const cmd = versionSuffix ? `delsrvoff${versionSuffix}` : "delsrvoff";
    bot.onText(new RegExp(`^\\/${cmd}\\s+(.+)$`, "i"), async (msg, match) => {
      const chatId = msg.chat.id;
      const id = match[1].trim();

      if (!isOwner(msg.from.id)) return denyNotOwner(bot, chatId);

      const { domain, plta, pltc } = resolvePanel(versionSuffix);
      if (!domain || !plta) {
        return bot.sendMessage(chatId, `◇ Panel ${labelVersion(versionSuffix)} belum diatur (domain/PLTA kosong).`);
      }

      try {
        const infoRes = await safeFetch(`${domain}/api/application/servers/${id}`, {
          headers: { Accept: "application/json", Authorization: `Bearer ${plta}` },
        });
        if (infoRes.status === 404) {
          return bot.sendMessage(chatId, `◇ Server ID <code>${id}</code> tidak ditemukan di Panel ${labelVersion(versionSuffix)}!`, { parse_mode: "HTML" });
        }
        const info = await infoRes.json();
        const s = info?.attributes;
        if (!s) return bot.sendMessage(chatId, "◇ Gagal membaca data server.");

        let liveStatus = null;
        try {
          const resRes = await safeFetch(`${domain}/api/client/servers/${s.uuid.split("-")[0]}/resources`, {
            headers: { Accept: "application/json", Authorization: `Bearer ${pltc}` },
          });
          const resData = await resRes.json();
          liveStatus = resData?.attributes?.current_state || null;
        } catch {}

        if (liveStatus !== "offline") {
          return bot.sendMessage(
            chatId,
            `⚠ Server <code>${id}</code> sedang <b>${liveStatus || "tidak diketahui"}</b> (bukan offline), tidak dihapus. Pakai /delsrv${versionSuffix} kalau tetap mau hapus paksa.`,
            { parse_mode: "HTML" }
          );
        }

        const del = await safeFetch(`${domain}/api/application/servers/${id}`, {
          method: "DELETE",
          headers: { Accept: "application/json", Authorization: `Bearer ${plta}` },
        });

        if (del.status === 204) {
          return bot.sendMessage(
            chatId,
            `<blockquote expandable>◉ <b>SERVER OFFLINE BERHASIL DIHAPUS</b>\n\n⌇ Panel: <b>${labelVersion(versionSuffix)}</b>\n⌇ Server ID: <code>${id}</code>\n⌇ Nama: <b>${s.name}</b></blockquote>`,
            { parse_mode: "HTML", reply_to_message_id: msg.message_id }
          );
        }
        const errText = await del.text();
        console.error(`DEL SRV OFF ${labelVersion(versionSuffix)} ERROR:`, errText);
        bot.sendMessage(chatId, `⚠ Gagal menghapus server (status ${del.status}).`);
      } catch (err) {
        console.error(`DEL SRV OFF ${labelVersion(versionSuffix)} ERROR:`, err);
        bot.sendMessage(chatId, `◇ Terjadi error: ${err.message}`);
      }
    });
  }
  ["", "v2", "v3", "v4", "v5"].forEach(registerDelSrvOff);

  // ============================================================
  //  [ DELETE MASSAL ] — hapus SEMUA server / SEMUA user-tanpa-server /
  //  SEMUA admin (sub-user) di satu panel versi tertentu.
  //  /dellallsrv    /dellallsrvv2..v5
  //  /dellalluser   /dellalluserv2..v5
  //  /dellalladp    /dellalladpv2..v5
  // ============================================================
  async function fetchAllPages(domain, plta, endpoint) {
    let items = [];
    let page = 1;
    let totalPages = 1;
    do {
      const f = await safeFetch(`${domain}${endpoint}${endpoint.includes("?") ? "&" : "?"}page=${page}`, {
        headers: { Accept: "application/json", Authorization: `Bearer ${plta}` },
      });
      const res = await f.json();
      items = items.concat(res.data || []);
      totalPages = res?.meta?.pagination?.total_pages || 1;
      page++;
      await sleep(800);
    } while (page <= totalPages);
    return items;
  }

  function registerDelAllSrv(versionSuffix) {
    const cmd = versionSuffix ? `dellallsrv${versionSuffix}` : "dellallsrv";
    bot.onText(new RegExp(`^\\/${cmd}$`, "i"), async (msg) => {
      const chatId = msg.chat.id;
      if (!isOwner(msg.from.id)) return denyNotOwner(bot, chatId);

      const { domain, plta } = resolvePanel(versionSuffix);
      if (!domain || !plta) {
        return bot.sendMessage(chatId, `◇ Panel ${labelVersion(versionSuffix)} belum diatur (domain/PLTA kosong).`);
      }

      const proses = await bot.sendMessage(chatId, `⏳ Mengambil daftar server Panel ${labelVersion(versionSuffix)}...`);

      try {
        const servers = await fetchAllPages(domain, plta, "/api/application/servers");
        let success = 0, failed = 0;

        for (const srv of servers) {
          const s = srv.attributes;
          try {
            const del = await safeFetch(`${domain}/api/application/servers/${s.id}`, {
              method: "DELETE",
              headers: { Accept: "application/json", Authorization: `Bearer ${plta}` },
            });
            if (del.status === 204) success++; else failed++;
          } catch {
            failed++;
          }
          await sleep(1200);
        }

        bot.editMessageText(
          `<blockquote expandable>◉ <b>DELETE MASSAL SERVER SELESAI</b>\n\n⌇ Panel: <b>${labelVersion(versionSuffix)}</b>\n⌇ Total ditemukan: <b>${servers.length}</b>\n◉ Berhasil: <b>${success}</b>\n◇ Gagal: <b>${failed}</b></blockquote>`,
          { chat_id: chatId, message_id: proses.message_id, parse_mode: "HTML" }
        );
      } catch (err) {
        console.error(`DELLALLSRV ${labelVersion(versionSuffix)} ERROR:`, err);
        bot.editMessageText(`◇ Gagal proses delete massal: ${err.message}`, { chat_id: chatId, message_id: proses.message_id });
      }
    });
  }
  ["", "v2", "v3", "v4", "v5"].forEach(registerDelAllSrv);

  function registerDelAllUser(versionSuffix) {
    const cmd = versionSuffix ? `dellalluser${versionSuffix}` : "dellalluser";
    bot.onText(new RegExp(`^\\/${cmd}$`, "i"), async (msg) => {
      const chatId = msg.chat.id;
      if (!isOwner(msg.from.id)) return denyNotOwner(bot, chatId);

      const { domain, plta } = resolvePanel(versionSuffix);
      if (!domain || !plta) {
        return bot.sendMessage(chatId, `◇ Panel ${labelVersion(versionSuffix)} belum diatur (domain/PLTA kosong).`);
      }

      const proses = await bot.sendMessage(chatId, `⏳ Mengambil daftar user Panel ${labelVersion(versionSuffix)}...`);

      try {
        const users = await fetchAllPages(domain, plta, "/api/application/users");
        let success = 0, failed = 0, skipped = 0;

        for (const u of users) {
          const user = u.attributes;
          if (user.root_admin) { skipped++; continue; }

          let hasServer = false;
          try {
            const checkRes = await safeFetch(`${domain}/api/application/servers?filter[user_id]=${user.id}`, {
              headers: { Accept: "application/json", Authorization: `Bearer ${plta}` },
            });
            const checkData = await checkRes.json();
            hasServer = (checkData?.data?.length || 0) > 0;
          } catch {}

          if (hasServer) { skipped++; await sleep(400); continue; }

          try {
            const del = await safeFetch(`${domain}/api/application/users/${user.id}`, {
              method: "DELETE",
              headers: { Accept: "application/json", Authorization: `Bearer ${plta}` },
            });
            if (del.status === 204) success++; else failed++;
          } catch {
            failed++;
          }
          await sleep(1200);
        }

        bot.editMessageText(
          `<blockquote expandable>◉ <b>DELETE MASSAL USER SELESAI</b>\n\n⌇ Panel: <b>${labelVersion(versionSuffix)}</b>\n⌇ Total ditemukan: <b>${users.length}</b>\n◉ Berhasil dihapus: <b>${success}</b>\n⊘ Dilewati (punya server/root admin): <b>${skipped}</b>\n◇ Gagal: <b>${failed}</b></blockquote>`,
          { chat_id: chatId, message_id: proses.message_id, parse_mode: "HTML" }
        );
      } catch (err) {
        console.error(`DELLALLUSER ${labelVersion(versionSuffix)} ERROR:`, err);
        bot.editMessageText(`◇ Gagal proses delete massal: ${err.message}`, { chat_id: chatId, message_id: proses.message_id });
      }
    });
  }
  ["", "v2", "v3", "v4", "v5"].forEach(registerDelAllUser);

  function registerDelAllAdp(versionSuffix) {
    const cmd = versionSuffix ? `dellalladp${versionSuffix}` : "dellalladp";
    bot.onText(new RegExp(`^\\/${cmd}$`, "i"), async (msg) => {
      const chatId = msg.chat.id;
      if (!isOwner(msg.from.id)) return denyNotOwner(bot, chatId);

      const { domain, plta } = resolvePanel(versionSuffix);
      if (!domain || !plta) {
        return bot.sendMessage(chatId, `◇ Panel ${labelVersion(versionSuffix)} belum diatur (domain/PLTA kosong).`);
      }

      const proses = await bot.sendMessage(chatId, `⏳ Mengambil daftar admin Panel ${labelVersion(versionSuffix)}...`);

      try {
        const users = await fetchAllPages(domain, plta, "/api/application/users");
        const admins = users.filter((u) => !u.attributes.root_admin);
        let success = 0, failed = 0;

        for (const u of admins) {
          const user = u.attributes;
          try {
            const del = await safeFetch(`${domain}/api/application/users/${user.id}`, {
              method: "DELETE",
              headers: { Accept: "application/json", Authorization: `Bearer ${plta}` },
            });
            if (del.status === 204) success++; else failed++;
          } catch {
            failed++;
          }
          await sleep(1200);
        }

        bot.editMessageText(
          `<blockquote expandable>◉ <b>DELETE MASSAL ADMIN SELESAI</b>\n\n⌇ Panel: <b>${labelVersion(versionSuffix)}</b>\n⌇ Total ditemukan: <b>${admins.length}</b>\n◉ Berhasil: <b>${success}</b>\n◇ Gagal: <b>${failed}</b></blockquote>`,
          { chat_id: chatId, message_id: proses.message_id, parse_mode: "HTML" }
        );
      } catch (err) {
        console.error(`DELLALLADP ${labelVersion(versionSuffix)} ERROR:`, err);
        bot.editMessageText(`◇ Gagal proses delete massal: ${err.message}`, { chat_id: chatId, message_id: proses.message_id });
      }
    });
  }
  ["", "v2", "v3", "v4", "v5"].forEach(registerDelAllAdp);

  // ============================================================
  //  [ ADD TOKEN ] — whitelist token bot LOKAL (db/tokens.json)
  //  Beda dari token bot cPanel utama (settings.token) -- ini buat
  //  mendaftarkan token bot LAIN yang boleh pakai script ini, dicek
  //  bareng daftar lisensi GitHub pas bot start (lihat index.js).
  //  Token disimpan sebagai hash SHA-256, bukan mentahnya.
  // ============================================================
  const TOKENS_DB_PATH = path.join(__dirname, "..", "db", "tokens.json");
  const crypto = require("crypto");

  function loadTokensDb() {
    try {
      if (!fs.existsSync(TOKENS_DB_PATH)) return { tokens: [] };
      const data = JSON.parse(fs.readFileSync(TOKENS_DB_PATH, "utf8"));
      if (!Array.isArray(data.tokens)) data.tokens = [];
      return data;
    } catch {
      return { tokens: [] };
    }
  }

  function saveTokensDb(data) {
    fs.mkdirSync(path.dirname(TOKENS_DB_PATH), { recursive: true });
    fs.writeFileSync(TOKENS_DB_PATH, JSON.stringify(data, null, 2));
  }

  bot.onText(/^\/addtoken\s+(\S+)$/i, async (msg, match) => {
    const chatId = msg.chat.id;
    const rawToken = match[1].trim();

    if (!isOwner(msg.from.id)) return denyNotOwner(bot, chatId);

    if (!/^\d+:[A-Za-z0-9_-]{30,}$/.test(rawToken)) {
      return bot.sendMessage(chatId, "◇ Format token bot tidak valid.\nContoh: /addtoken 123456789:AAExampleTokenHere");
    }

    const hash = crypto.createHash("sha256").update(rawToken).digest("hex");
    const db = loadTokensDb();

    if (db.tokens.includes(hash)) {
      return bot.sendMessage(chatId, "⚠ Token ini sudah terdaftar di whitelist lokal.");
    }

    db.tokens.push(hash);
    saveTokensDb(db);

    bot.sendMessage(
      chatId,
      `<blockquote expandable>◉ <b>TOKEN BERHASIL DIDAFTARKAN</b>\n\n⌇ Hash: <code>${hash.slice(0, 16)}...</code>\n⚠ Token bot itu sekarang boleh dipakai buat menjalankan script ini (dicek pas bot start).</blockquote>`,
      { parse_mode: "HTML", reply_to_message_id: msg.message_id }
    );
  });

  bot.onText(/^\/deltoken\s+(\S+)$/i, async (msg, match) => {
    const chatId = msg.chat.id;
    const rawToken = match[1].trim();

    if (!isOwner(msg.from.id)) return denyNotOwner(bot, chatId);

    const hash = crypto.createHash("sha256").update(rawToken).digest("hex");
    const db = loadTokensDb();

    if (!db.tokens.includes(hash)) {
      return bot.sendMessage(chatId, "◇ Token ini tidak ada di whitelist lokal.");
    }

    db.tokens = db.tokens.filter((h) => h !== hash);
    saveTokensDb(db);

    bot.sendMessage(chatId, "◉ Token berhasil dihapus dari whitelist lokal.");
  });

  bot.onText(/^\/listtoken$/i, async (msg) => {
    const chatId = msg.chat.id;
    if (!isOwner(msg.from.id)) return denyNotOwner(bot, chatId);

    const db = loadTokensDb();
    if (!db.tokens.length) {
      return bot.sendMessage(chatId, "⚠ Whitelist token lokal masih kosong.");
    }

    const lines = db.tokens.map((h, i) => `${i + 1}. <code>${h.slice(0, 16)}...</code>`);
    bot.sendMessage(chatId, `<blockquote expandable>⌇ <b>WHITELIST TOKEN LOKAL</b>\n\n${lines.join("\n")}</blockquote>`, { parse_mode: "HTML" });
  });

  // ============================================================
  //  [ PANEL TOOLS ]
  // ============================================================

  // /unsuspend <uuid/id>  -> Panel V1 (lawan dari /suspend yang udah ada)
  bot.onText(/^\/unsuspend\s+(.+)/i, async (msg, match) => {
    const chatId = msg.chat.id;
    const input = match[1].trim();
    if (!isOwner(msg.from.id)) return denyNotOwner(bot, chatId);

    const { domain, plta } = resolvePanel("");
    if (!domain || !plta) return bot.sendMessage(chatId, "◇ Panel V1 belum diatur (domain/PLTA kosong).");

    try {
      await bot.sendMessage(chatId, "⏳ Mencari server...");
      const res = await safeFetch(`${domain}/api/application/servers`, {
        headers: { Accept: "application/json", Authorization: `Bearer ${plta}` },
      });
      const data = await res.json();
      const servers = data.data || [];

      let server = servers.find((s) => s.attributes.uuid === input);
      if (!server) server = servers.find((s) => String(s.attributes.id) === input);
      if (!server) return bot.sendMessage(chatId, "◇ Server tidak ditemukan!");

      const s = server.attributes;
      if (!s.suspended) return bot.sendMessage(chatId, "⚠ Server tidak dalam keadaan suspend!");

      const unsuspendRes = await safeFetch(`${domain}/api/application/servers/${s.id}/unsuspend`, {
        method: "POST",
        headers: { Accept: "application/json", Authorization: `Bearer ${plta}` },
      });

      if (!unsuspendRes.ok) return bot.sendMessage(chatId, "◇ Gagal unsuspend server!");

      bot.sendMessage(
        chatId,
        `<blockquote expandable>◉ <b>SERVER BERHASIL DI-UNSUSPEND</b>\n\n⌇ Server ID: <code>${s.id}</code>\n⌬ UUID: <code>${s.uuid}</code>\n◈ Nama: <b>${s.name}</b></blockquote>`,
        { parse_mode: "HTML" }
      );
    } catch (err) {
      console.error("UNSUSPEND ERROR:", err);
      bot.sendMessage(chatId, `◇ Terjadi error: ${err.message}`);
    }
  });

  // /unsuspend-v5 <id_server>  -> langsung by server ID di panel V5
  bot.onText(/^\/unsuspend-v5\s+(.+)/i, async (msg, match) => {
    const chatId = msg.chat.id;
    const id = match[1].trim();
    if (!isOwner(msg.from.id)) return denyNotOwner(bot, chatId);

    const { domain, plta } = resolvePanel("v5");
    if (!domain || !plta) return bot.sendMessage(chatId, "◇ Panel V5 belum diatur (domain/PLTA kosong).");

    try {
      const unsuspendRes = await safeFetch(`${domain}/api/application/servers/${id}/unsuspend`, {
        method: "POST",
        headers: { Accept: "application/json", Authorization: `Bearer ${plta}` },
      });

      if (unsuspendRes.status === 404) {
        return bot.sendMessage(chatId, `◇ Server ID <code>${id}</code> tidak ditemukan di Panel V5!`, { parse_mode: "HTML" });
      }
      if (!unsuspendRes.ok) return bot.sendMessage(chatId, `◇ Gagal unsuspend server (status ${unsuspendRes.status}).`);

      bot.sendMessage(
        chatId,
        `<blockquote expandable>◉ <b>SERVER V5 BERHASIL DI-UNSUSPEND</b>\n\n⌇ Server ID: <code>${id}</code></blockquote>`,
        { parse_mode: "HTML" }
      );
    } catch (err) {
      console.error("UNSUSPEND V5 ERROR:", err);
      bot.sendMessage(chatId, `◇ Terjadi error: ${err.message}`);
    }
  });

  // /cekapikey [versi]  -> cek validitas PLTA tiap panel (default: semua V1-V5)
  bot.onText(/^\/cekapikey(?:\s+(v[2-5]))?$/i, async (msg, match) => {
    const chatId = msg.chat.id;
    if (!isOwner(msg.from.id)) return denyNotOwner(bot, chatId);

    const targets = match[1] ? [match[1].toLowerCase()] : ["", "v2", "v3", "v4", "v5"];
    const proses = await bot.sendMessage(chatId, "⏳ Mengecek API key tiap panel...");

    const lines = [];
    for (const v of targets) {
      const { domain, plta } = resolvePanel(v);
      if (!domain || !plta) {
        lines.push(`◇ ${labelVersion(v)}: domain/PLTA kosong`);
        continue;
      }
      try {
        const res = await safeFetch(`${domain}/api/application/users?per_page=1`, {
          headers: { Accept: "application/json", Authorization: `Bearer ${plta}` },
        });
        if (res.status === 200) lines.push(`◉ ${labelVersion(v)}: API key valid (${domain})`);
        else if (res.status === 401 || res.status === 403) lines.push(`◇ ${labelVersion(v)}: API key ditolak (status ${res.status})`);
        else lines.push(`⚠ ${labelVersion(v)}: status ${res.status}`);
      } catch (err) {
        lines.push(`◇ ${labelVersion(v)}: gagal konek (${err.message})`);
      }
      await sleep(400);
    }

    bot.editMessageText(
      `<blockquote expandable>⌕ <b>CEK API KEY</b>\n\n${lines.join("\n")}</blockquote>`,
      { chat_id: chatId, message_id: proses.message_id, parse_mode: "HTML" }
    );
  });

  // /restore -- reply ke file .zip hasil /backup, isi ulang folder db/
  bot.onText(/^\/restore$/i, async (msg) => {
    const chatId = msg.chat.id;
    const doc = msg.reply_to_message?.document;

    // /restore juga merupakan command AI untuk gambar. Hanya ambil alih
    // command jika reply berupa dokumen non-gambar (backup ZIP).
    if (!doc) return;
    if (/^image\//i.test(String(doc.mime_type || ''))) return;

    if (!isOwner(msg.from.id)) return denyNotOwner(bot, chatId);
    if (!doc.file_name || !doc.file_name.toLowerCase().endsWith('.zip')) {
      return bot.sendMessage(chatId, '◇ File yang di-reply harus berupa .zip hasil /backup.');
    }

    const proses = await bot.sendMessage(chatId, "⏳ Mengunduh & memulihkan backup...");

    try {
      const fileLink = await bot.getFileLink(doc.file_id);
      const res = await fetch(fileLink);
      if (!res.ok) throw new Error(`Gagal unduh file (status ${res.status})`);

      const tmpZip = path.join(__dirname, "..", "restore_tmp.zip");
      const dest = fs.createWriteStream(tmpZip);
      await new Promise((resolve, reject) => {
        res.body.pipe(dest);
        res.body.on("error", reject);
        dest.on("finish", resolve);
      });

      // Ekstrak HANYA folder db/ dari zip backup, biar gak nimpa source code
      // yang sedang jalan (index.js/settings.js/src) secara tidak sengaja.
      let restoredFiles = 0;
      await new Promise((resolve, reject) => {
        const parser = fs.createReadStream(tmpZip).pipe(unzipper.Parse());
        const writes = [];
        parser.on('entry', (entry) => {
          const entryPath = String(entry.path || '').replace(/\\/g, '/');
          const safeRelative = path.posix.normalize(entryPath);
          const target = path.resolve(__dirname, '..', safeRelative);
          const dbRoot = path.resolve(__dirname, '..', 'db') + path.sep;

          if (safeRelative.startsWith('db/') && !safeRelative.endsWith('/') && target.startsWith(dbRoot)) {
            fs.mkdirSync(path.dirname(target), { recursive: true });
            const writePromise = new Promise((res, rej) => {
              const out = fs.createWriteStream(target);
              out.on('finish', res);
              out.on('error', rej);
              entry.on('error', rej);
              entry.pipe(out);
            }).then(() => { restoredFiles++; });
            writes.push(writePromise);
          } else {
            entry.autodrain();
          }
        });
        parser.on('close', () => Promise.all(writes).then(resolve, reject));
        parser.on('error', reject);
      });

      if (restoredFiles === 0) {
        throw new Error('Backup ZIP tidak berisi file database pada folder db/.');
      }

      fs.unlinkSync(tmpZip);

      bot.editMessageText(
        `<blockquote expandable>◉ <b>RESTORE SELESAI</b>\n\n⌇ File database dipulihkan: <b>${restoredFiles}</b>\n⚠ Restart bot disarankan biar semua modul baca ulang data terbaru.</blockquote>`,
        { chat_id: chatId, message_id: proses.message_id, parse_mode: "HTML" }
      );
    } catch (err) {
      console.error("RESTORE ERROR:", err);
      bot.editMessageText(`◇ Gagal restore: ${err.message}`, { chat_id: chatId, message_id: proses.message_id });
    }
  });
};
