/**
 * ============================================================
 * LianiX — AI Commands Hub
 * ============================================================
 * Semua perintah AI terpusat di sini, prefix sesuai nama model.
 *
 * COMMAND LIST:
 *   /haiku  <pesan> [sesi]    → Claude Haiku (claude-haiku-4-5)
 *   /gemini <pesan> [sesi]    → Gemini (Google, session support)
 *   /deepseek <pesan>         → DeepSeek Thinking (notegpt.io)
 *   /gpt5   <pesan> [sesi]    → GPT-5 (overchat.ai, gpt-4.1)
 *   /qwen   <pesan>           → Qwen3 (80B, overchat.ai)
 *
 * Session support (Gemini & Haiku & GPT5):
 *   /haiku halo              → tanpa sesi (fresh)
 *   /haiku halo <sessionId>  → lanjut sesi sebelumnya
 *   Bot reply selalu sertakan sessionId baru di bawah.
 *
 * Downloader commands dipisah ke downloaderCommands.js
 * AI media tools (txt2img, rembg, dll) tetap di aiTools.js
 * ============================================================
 */

'use strict';

const path    = require('path');
const axios   = require('axios');
const settings = require('../settings.js');

// ── Helpers ────────────────────────────────────────────────
function esc(s = '') {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function q(msg) {
  return msg?.message_id ? { reply_to_message_id: msg.message_id } : {};
}

/**
 * Loading message with progress bar.
 * Returns { update(stage, pct), finish(ok) }
 */
async function loading(bot, msg, title) {
  const bar = (p, w = 18) => {
    const n = Math.round(Math.max(0, Math.min(100, p)) / 100 * w);
    return `[${'▰'.repeat(n)}${'▱'.repeat(w - n)}] ${Math.round(p)}%`;
  };
  const text = (stage, p) =>
    `⏳ <b>${esc(title)}</b>\n\n▸ ${esc(stage)}\n${bar(p)}\n\n🔄 <i>Mohon tunggu...</i>`;

  let sent = null;
  try {
    sent = await bot.sendMessage(msg.chat.id, text('Menyiapkan...', 0), {
      parse_mode: 'HTML',
      ...q(msg),
    });
  } catch {}

  let last = -1, lastAt = 0;
  return {
    async update(stage, p) {
      if (!sent) return;
      const now = Date.now();
      const v = Math.max(last, Math.min(100, Number(p) || 0));
      if (v === last && now - lastAt < 2500) return;
      if (now - lastAt < 900) return;
      last = v; lastAt = now;
      try {
        await bot.editMessageText(text(stage, v), {
          chat_id: msg.chat.id,
          message_id: sent.message_id,
          parse_mode: 'HTML',
        });
      } catch {}
    },
    async finish(ok = true) {
      if (!sent) return;
      try {
        await bot.editMessageText(
          `⏳ <b>${esc(title)}</b>\n\n${ok
            ? '✅ ' + bar(100) + '\n\n<b>Selesai.</b>'
            : '❌ Proses gagal.'}`,
          { chat_id: msg.chat.id, message_id: sent.message_id, parse_mode: 'HTML' }
        );
        setTimeout(() => bot.deleteMessage(msg.chat.id, sent.message_id).catch(() => {}), 1200);
      } catch {}
    },
  };
}

// ── Dynamic ESM feature loader ─────────────────────────────
const _cache = new Map();
async function loadFeature(name) {
  if (_cache.has(name)) return _cache.get(name);
  const mod = await import(path.join(__dirname, 'features', name));
  _cache.set(name, mod);
  return mod;
}

// ── Session stores (in-memory, per run) ───────────────────
// Key: userId  →  Value: { chatId, deviceId, ... }
const haikuSessions  = new Map();
const geminiSessions = new Map();
const gpt5Sessions   = new Map();

/**
 * Encode session data to base64 string untuk dikirim ke user.
 */
function encodeSession(data) {
  return Buffer.from(JSON.stringify(data)).toString('base64');
}

/**
 * Decode session dari argumen pesan user.
 * Kalau gagal parse → return null (fresh session).
 */
function decodeSession(str) {
  if (!str) return null;
  try { return JSON.parse(Buffer.from(str, 'base64').toString()); } catch { return null; }
}

// ──────────────────────────────────────────────────────────
//  CLAUDE HAIKU — /haiku <pesan> [sessionId]
// ──────────────────────────────────────────────────────────
async function handleHaiku(bot, msg, rawArgs) {
  // Pisah argumen: bagian terakhir bisa jadi sessionId (base64)
  // Format: /haiku <pesan> atau /haiku <pesan> <sessionId>
  const parts   = rawArgs.trim().split(/\s+/);
  let sessionArg = null;
  let promptParts = parts;

  // Coba decode token terakhir sebagai session
  const maybeSession = decodeSession(parts[parts.length - 1]);
  if (maybeSession?.chatId && maybeSession?.deviceId) {
    sessionArg   = maybeSession;
    promptParts  = parts.slice(0, -1);
  }

  const prompt = promptParts.join(' ').trim();
  if (!prompt && !msg.reply_to_message) {
    return bot.sendMessage(
      msg.chat.id,
      '◇ Gunakan: /haiku <pesan>\nAtau: /haiku <pesan> <sessionId> untuk lanjut sesi.',
      { parse_mode: 'HTML', ...q(msg) }
    );
  }

  const finalPrompt = prompt ||
    (msg.reply_to_message?.text || msg.reply_to_message?.caption || '');

  const load = await loading(bot, msg, 'Claude Haiku');
  try {
    await load.update('Menghubungi Claude Haiku...', 20);
    const { ClaudeHaiku } = await loadFeature('claudehaiku.js');
    const opts = sessionArg ? { chatId: sessionArg.chatId, deviceId: sessionArg.deviceId } : {};
    const res  = await ClaudeHaiku(finalPrompt, opts);
    if (!res?.status) throw new Error(res?.error || 'Haiku gagal merespons.');

    // Simpan session baru
    const newSession = encodeSession({ chatId: res.chatId, deviceId: res.deviceId });
    haikuSessions.set(String(msg.from?.id), newSession);

    await load.finish(true);
    await bot.sendMessage(
      msg.chat.id,
      `◇ <b>Claude Haiku</b>\n\n${esc(res.answer)}\n\n` +
      `<blockquote><code>Session: ${newSession}</code>\nKirim ulang dengan session ID ini untuk lanjut chat.</blockquote>`,
      { parse_mode: 'HTML', ...q(msg) }
    );
  } catch (e) {
    await load.finish(false);
    await bot.sendMessage(msg.chat.id,
      `❌ <b>Haiku Error</b>\n${esc(e.message)}`,
      { parse_mode: 'HTML', ...q(msg) }
    );
  }
}

// ──────────────────────────────────────────────────────────
//  GEMINI — /gemini <pesan> [sessionId]
// ──────────────────────────────────────────────────────────
async function handleGemini(bot, msg, rawArgs) {
  const parts      = rawArgs.trim().split(/\s+/);
  let sessionArg   = null;
  let promptParts  = parts;

  const maybeSession = decodeSession(parts[parts.length - 1]);
  if (maybeSession?.resumeArray && maybeSession?.cookie) {
    sessionArg  = maybeSession;
    promptParts = parts.slice(0, -1);
  }

  const prompt = promptParts.join(' ').trim() ||
    (msg.reply_to_message?.text || msg.reply_to_message?.caption || '');

  if (!prompt) {
    return bot.sendMessage(
      msg.chat.id,
      '◇ Gunakan: /gemini <pesan>\nAtau sertakan sessionId untuk lanjut percakapan.',
      { parse_mode: 'HTML', ...q(msg) }
    );
  }

  const load = await loading(bot, msg, 'Gemini');
  try {
    await load.update('Menghubungi Gemini...', 20);
    const mod    = await loadFeature('gemini.js');
    const gemini = mod.default || mod.gemini;
    const opts   = sessionArg
      ? { message: prompt, sessionId: encodeSession(sessionArg) }
      : { message: prompt };
    const res = await gemini(opts);
    if (!res?.answer && !res?.result) throw new Error('Gemini tidak merespons.');

    // Gemini mengembalikan resumeArray + cookie untuk session
    const newSession = res.resumeArray && res.cookie
      ? encodeSession({ resumeArray: res.resumeArray, cookie: res.cookie })
      : null;
    if (newSession) geminiSessions.set(String(msg.from?.id), newSession);

    await load.finish(true);
    const answer = res.answer || res.result || '';
    const sessionBlock = newSession
      ? `\n\n<blockquote><code>Session: ${newSession}</code>\nKirim ulang dengan session ID ini untuk lanjut chat.</blockquote>`
      : '';

    await bot.sendMessage(
      msg.chat.id,
      `◇ <b>Gemini</b>\n\n${esc(answer)}${sessionBlock}`,
      { parse_mode: 'HTML', ...q(msg) }
    );
  } catch (e) {
    await load.finish(false);
    await bot.sendMessage(msg.chat.id,
      `❌ <b>Gemini Error</b>\n${esc(e.message)}`,
      { parse_mode: 'HTML', ...q(msg) }
    );
  }
}

// ──────────────────────────────────────────────────────────
//  DEEPSEEK — /deepseek <pesan>
//  (stateless per request, no persistent session)
// ──────────────────────────────────────────────────────────
async function handleDeepSeek(bot, msg, prompt) {
  const load = await loading(bot, msg, 'DeepSeek Thinking');
  try {
    await load.update('Menghubungi DeepSeek...', 20);
    const { DeepSeekThinking } = await loadFeature('deepseek.js');
    const res = await DeepSeekThinking(prompt, []);
    const answer = res?.answer || res?.result || res?.text || JSON.stringify(res);
    if (!answer) throw new Error('DeepSeek tidak merespons.');

    await load.finish(true);
    await bot.sendMessage(
      msg.chat.id,
      `◇ <b>DeepSeek</b>\n\n${esc(answer)}`,
      { parse_mode: 'HTML', ...q(msg) }
    );
  } catch (e) {
    await load.finish(false);
    await bot.sendMessage(msg.chat.id,
      `❌ <b>DeepSeek Error</b>\n${esc(e.message)}`,
      { parse_mode: 'HTML', ...q(msg) }
    );
  }
}

// ──────────────────────────────────────────────────────────
//  GPT-5 — /gpt5 <pesan> [sessionId]
// ──────────────────────────────────────────────────────────
async function handleGPT5(bot, msg, rawArgs) {
  const parts     = rawArgs.trim().split(/\s+/);
  let sessionArg  = null;
  let promptParts = parts;

  const maybeSession = decodeSession(parts[parts.length - 1]);
  if (maybeSession?.chatId && maybeSession?.deviceId) {
    sessionArg  = maybeSession;
    promptParts = parts.slice(0, -1);
  }

  const prompt = promptParts.join(' ').trim() ||
    (msg.reply_to_message?.text || msg.reply_to_message?.caption || '');

  if (!prompt) {
    return bot.sendMessage(
      msg.chat.id,
      '◇ Gunakan: /gpt5 <pesan>\nAtau sertakan sessionId untuk lanjut percakapan.',
      { parse_mode: 'HTML', ...q(msg) }
    );
  }

  const load = await loading(bot, msg, 'GPT-5');
  try {
    await load.update('Menghubungi GPT-5...', 20);
    const { GPT5 } = await loadFeature('gpt5.js');
    const opts = sessionArg
      ? { chatId: sessionArg.chatId, deviceId: sessionArg.deviceId }
      : {};
    const res  = await GPT5(prompt, opts);
    if (!res?.status) throw new Error(res?.error || 'GPT-5 gagal merespons.');

    const newSession = encodeSession({ chatId: res.chatId, deviceId: res.deviceId });
    gpt5Sessions.set(String(msg.from?.id), newSession);

    await load.finish(true);
    await bot.sendMessage(
      msg.chat.id,
      `◇ <b>GPT-5</b>\n\n${esc(res.answer)}\n\n` +
      `<blockquote><code>Session: ${newSession}</code>\nKirim ulang dengan session ID ini untuk lanjut chat.</blockquote>`,
      { parse_mode: 'HTML', ...q(msg) }
    );
  } catch (e) {
    await load.finish(false);
    await bot.sendMessage(msg.chat.id,
      `❌ <b>GPT-5 Error</b>\n${esc(e.message)}`,
      { parse_mode: 'HTML', ...q(msg) }
    );
  }
}

// ──────────────────────────────────────────────────────────
//  QWEN — /qwen <pesan>
// ──────────────────────────────────────────────────────────
async function handleQwen(bot, msg, prompt) {
  const load = await loading(bot, msg, 'Qwen3');
  try {
    await load.update('Menghubungi Qwen3...', 20);
    const { Qwen3 } = await loadFeature('qwen3.js');
    const res = await Qwen3(prompt);
    if (!res?.status) throw new Error(res?.error || 'Qwen3 gagal merespons.');

    await load.finish(true);
    await bot.sendMessage(
      msg.chat.id,
      `◇ <b>Qwen3</b>\n\n${esc(res.answer)}`,
      { parse_mode: 'HTML', ...q(msg) }
    );
  } catch (e) {
    await load.finish(false);
    await bot.sendMessage(msg.chat.id,
      `❌ <b>Qwen3 Error</b>\n${esc(e.message)}`,
      { parse_mode: 'HTML', ...q(msg) }
    );
  }
}

// ──────────────────────────────────────────────────────────
//  REGISTER — dipanggil dari index.js
// ──────────────────────────────────────────────────────────
function register(bot) {

  // /haiku <pesan> [sessionId]
  bot.onText(/^\/haiku(?:@\w+)?(?:\s+([\s\S]+))?$/i, async (msg, m) => {
    const args = (m[1] || '').trim();
    if (!args && !msg.reply_to_message) {
      return bot.sendMessage(
        msg.chat.id,
        '◇ Gunakan: <code>/haiku pesan kamu</code>\n\nDengan sesi: <code>/haiku pesan kamu &lt;sessionId&gt;</code>',
        { parse_mode: 'HTML', ...q(msg) }
      );
    }
    await handleHaiku(bot, msg, args);
  });

  // /gemini <pesan> [sessionId]
  bot.onText(/^\/gemini(?:@\w+)?(?:\s+([\s\S]+))?$/i, async (msg, m) => {
    const args = (m[1] || '').trim();
    if (!args && !msg.reply_to_message) {
      return bot.sendMessage(
        msg.chat.id,
        '◇ Gunakan: <code>/gemini pesan kamu</code>\n\nDengan sesi: <code>/gemini pesan kamu &lt;sessionId&gt;</code>',
        { parse_mode: 'HTML', ...q(msg) }
      );
    }
    await handleGemini(bot, msg, args);
  });

  // /deepseek <pesan>
  bot.onText(/^\/deepseek(?:@\w+)?(?:\s+([\s\S]+))?$/i, async (msg, m) => {
    const prompt = (m[1] || '').trim() ||
      (msg.reply_to_message?.text || msg.reply_to_message?.caption || '');
    if (!prompt) {
      return bot.sendMessage(
        msg.chat.id,
        '◇ Gunakan: <code>/deepseek pesan kamu</code>',
        { parse_mode: 'HTML', ...q(msg) }
      );
    }
    await handleDeepSeek(bot, msg, prompt);
  });

  // /gpt5 <pesan> [sessionId]
  bot.onText(/^\/gpt5(?:@\w+)?(?:\s+([\s\S]+))?$/i, async (msg, m) => {
    const args = (m[1] || '').trim();
    if (!args && !msg.reply_to_message) {
      return bot.sendMessage(
        msg.chat.id,
        '◇ Gunakan: <code>/gpt5 pesan kamu</code>\n\nDengan sesi: <code>/gpt5 pesan kamu &lt;sessionId&gt;</code>',
        { parse_mode: 'HTML', ...q(msg) }
      );
    }
    await handleGPT5(bot, msg, args);
  });

  // /qwen <pesan>
  bot.onText(/^\/qwen(?:@\w+)?(?:\s+([\s\S]+))?$/i, async (msg, m) => {
    const prompt = (m[1] || '').trim() ||
      (msg.reply_to_message?.text || msg.reply_to_message?.caption || '');
    if (!prompt) {
      return bot.sendMessage(
        msg.chat.id,
        '◇ Gunakan: <code>/qwen pesan kamu</code>',
        { parse_mode: 'HTML', ...q(msg) }
      );
    }
    await handleQwen(bot, msg, prompt);
  });

  // /ailist — daftar semua AI yang tersedia
  bot.onText(/^\/ailist(?:@\w+)?$/i, async (msg) => {
    await bot.sendMessage(
      msg.chat.id,
      `<b>◇ AI CENTER — LianiX</b>\n\n` +
      `<blockquote expandable>` +
      `<b>CHAT AI</b>\n` +
      `├ <code>/haiku &lt;pesan&gt;</code>\n` +
      `│   Model: claude-haiku-4-5 | Provider: Overchat\n` +
      `│   Session: <code>/haiku pesan &lt;sessionId&gt;</code>\n\n` +
      `├ <code>/gemini &lt;pesan&gt;</code>\n` +
      `│   Model: Gemini | Provider: Google\n` +
      `│   Session: <code>/gemini pesan &lt;sessionId&gt;</code>\n\n` +
      `├ <code>/deepseek &lt;pesan&gt;</code>\n` +
      `│   Model: DeepSeek Thinking | Provider: NoteGPT\n` +
      `│   (Stateless — tiap request fresh)\n\n` +
      `├ <code>/gpt5 &lt;pesan&gt;</code>\n` +
      `│   Model: GPT-4.1 | Provider: Overchat\n` +
      `│   Session: <code>/gpt5 pesan &lt;sessionId&gt;</code>\n\n` +
      `╰ <code>/qwen &lt;pesan&gt;</code>\n` +
      `\n<b>AI TAMBAHAN</b>\n` +
      `├ <code>/unlimitedai &lt;pesan&gt;</code> — Unlimited AI\n` +
      `├ <code>/gpt52 &lt;pesan&gt;</code> — GPT-5.2\n` +
      `├ <code>/feeb &lt;pesan&gt;</code> — FeelBetter\n` +
      `├ <code>/logicbell &lt;pesan&gt;</code> — Logic Bell\n` +
      `╰ <code>/geminivision &lt;pertanyaan&gt;</code> — reply foto\n` +
      `    Model: Qwen3-80B | Provider: Overchat\n` +
      `    (Stateless — tiap request fresh)\n` +
      `</blockquote>\n\n` +
      `<blockquote expandable>` +
      `<b>AI MEDIA TOOLS</b>\n` +
      `├ <code>/txt2img &lt;prompt&gt;</code> [--style anime] [--model flux-dev]\n` +
      `├ <code>/img2video</code> (reply gambar)\n` +
      `├ <code>/upscale</code> / <code>/enhance</code> / <code>/unblur</code> (reply gambar)\n` +
      `├ <code>/rembg</code> — remove background\n` +
      `╰ <code>/aihelp</code> — bantuan lengkap AI media\n` +
      `</blockquote>\n\n` +
      `<blockquote expandable>` +
      `<b>AI CODE & CHAT (Pollinations)</b>\n` +
      `├ <code>/ai &lt;pesan&gt;</code> — chat model aktif\n` +
      `├ <code>/modelai</code> — pilih model\n` +
      `├ <code>/chatgptai</code> / <code>/geminiflash</code> / <code>/deepseekr1</code>\n` +
      `╰ <code>/gptbig</code> / <code>/deepseek</code> / <code>/mistralai</code>\n` +
      `</blockquote>`,
      { parse_mode: 'HTML', ...q(msg) }
    );
  });
}

module.exports = (bot) => register(bot);

// ──────────────────────────────────────────────────────────
//  AI CENTER — inline button menu (aimenu + per-model pages)
//  Dipanggil dari start.js via callback_query "aimenu"
// ──────────────────────────────────────────────────────────

const AI_MODELS = {
  ai_haiku: {
    label: '🟣 Claude Haiku',
    title: 'Claude Haiku',
    icon: '◇',
    desc:
      'Model: <b>claude-haiku-4-5</b> via Overchat.ai\n' +
      'Mode: Streaming • Session: tersedia\n\n' +
      '<code>/haiku &lt;pesan kamu&gt;</code>\n' +
      '<code>/haiku lanjut sesi &lt;sessionId&gt;</code>\n\n' +
      'Session ID dikirim otomatis di tiap reply — copy & paste untuk lanjut percakapan.',
  },
  ai_gemini: {
    label: '🔵 Gemini',
    title: 'Gemini',
    icon: '◇',
    desc:
      'Model: <b>Gemini</b> via Google (langsung)\n' +
      'Mode: Streaming • Session: tersedia\n\n' +
      '<code>/gemini &lt;pesan kamu&gt;</code>\n' +
      '<code>/gemini lanjut sesi &lt;sessionId&gt;</code>\n\n' +
      'Cocok untuk pertanyaan umum, analisis, riset cepat.',
  },
  ai_gpt5: {
    label: '🟢 GPT-5',
    title: 'GPT-5 (GPT-4.1)',
    icon: '◇',
    desc:
      'Model: <b>openai/gpt-4.1-nano</b> via Overchat.ai\n' +
      'Mode: Streaming • Session: tersedia\n\n' +
      '<code>/gpt5 &lt;pesan kamu&gt;</code>\n' +
      '<code>/gpt5 lanjut sesi &lt;sessionId&gt;</code>\n\n' +
      'Responsif, ringan, cocok untuk coding dan writing.',
  },
  ai_deepseek: {
    label: '🔴 DeepSeek',
    title: 'DeepSeek Thinking',
    icon: '◇',
    desc:
      'Model: <b>deepseek-v4-flash</b> via NoteGPT (deep think mode)\n' +
      'Mode: Chain-of-thought reasoning • Stateless\n\n' +
      '<code>/deepseek &lt;pesan kamu&gt;</code>\n\n' +
      'Setiap request fresh — terbaik untuk soal logika dan math.',
  },
  ai_qwen: {
    label: '🟠 Qwen3',
    title: 'Qwen3 (80B)',
    icon: '◇',
    desc:
      'Model: <b>qwen3-next-80b-a3b-instruct</b> via Overchat.ai\n' +
      'Mode: Streaming • Stateless\n\n' +
      '<code>/qwen &lt;pesan kamu&gt;</code>\n\n' +
      'Model besar 80B — cocok untuk analisis mendalam & bahasa Indonesia.',
  },
  ai_media: {
    label: '🎨 AI Media Tools',
    title: 'AI Media Tools',
    icon: '◇',
    desc:
      '<b>IMAGE GENERATION</b>\n' +
      '<code>/txt2img &lt;prompt&gt;</code> [--style anime] [--model flux-dev]\n\n' +
      '<b>REMOVE BACKGROUND</b>\n' +
      '<code>/rembg</code> — reply foto → PNG transparan (pixa.com / HF)\n\n' +
      '<b>IMAGE → VIDEO</b>\n' +
      '<code>/img2video &lt;prompt&gt;</code> — reply gambar\n\n' +
      '<b>AI ENHANCE</b>\n' +
      '<code>/upscale</code> / <code>/enhance</code> / <code>/unblur</code> / <code>/denoise</code> / <code>/restore</code> / <code>/colorize</code> — reply gambar',
  },
};

function buildAiMenuPayload() {
  const text =
    `<b>╭━━〔 🤖 AI CENTER 〕━━╮</b>\n` +
    `<blockquote expandable>` +
    `Semua model AI tersedia di sini.\nPilih model untuk melihat cara penggunaan dan command-nya.\n\n` +
    `◇ Claude Haiku — Gemini — GPT-5\n` +
    `◇ DeepSeek Thinking — Qwen3 80B\n` +
    `◇ AI Media Tools (rembg, txt2img, enhance)` +
    `</blockquote>`;

  const kb = {
    inline_keyboard: [
      [
        { text: AI_MODELS.ai_haiku.label,   callback_data: 'ai_haiku' },
        { text: AI_MODELS.ai_gemini.label,  callback_data: 'ai_gemini' },
      ],
      [
        { text: AI_MODELS.ai_gpt5.label,    callback_data: 'ai_gpt5' },
        { text: AI_MODELS.ai_deepseek.label, callback_data: 'ai_deepseek' },
      ],
      [
        { text: AI_MODELS.ai_qwen.label,    callback_data: 'ai_qwen' },
        { text: AI_MODELS.ai_media.label,   callback_data: 'ai_media' },
      ],
      [
        { text: '📋 Semua Command AI', callback_data: 'ai_allcmds' },
      ],
      [
        { text: '‹‹‹', callback_data: 'back' },
      ],
    ],
  };

  return { text, kb };
}

function buildAiModelPage(key) {
  const m = AI_MODELS[key];
  if (!m) return null;
  const text =
    `<b>${m.icon} ${m.title.toUpperCase()}</b>\n\n` +
    `<blockquote expandable>${m.desc}</blockquote>`;
  const kb = {
    inline_keyboard: [
      [
        { text: '‹ AI Center', callback_data: 'aimenu' },
        { text: '‹‹‹', callback_data: 'back' },
      ],
    ],
  };
  return { text, kb };
}

function buildAiAllCmdsPage() {
  const text =
    `<b>◇ SEMUA COMMAND AI</b>\n\n` +
    `<blockquote expandable>` +
    `<b>CHAT AI</b>\n` +
    `├ <code>/haiku &lt;pesan&gt;</code> — Claude Haiku\n` +
    `├ <code>/gemini &lt;pesan&gt;</code> — Gemini Google\n` +
    `├ <code>/gpt5 &lt;pesan&gt;</code> — GPT-5 (gpt-4.1)\n` +
    `├ <code>/deepseek &lt;pesan&gt;</code> — DeepSeek Thinking\n` +
    `╰ <code>/qwen &lt;pesan&gt;</code> — Qwen3 80B\n\n` +
    `<b>AI MEDIA</b>\n` +
    `├ <code>/txt2img &lt;prompt&gt;</code> — Text → Image\n` +
    `├ <code>/rembg</code> — Remove Background (gratis)\n` +
    `├ <code>/img2video &lt;prompt&gt;</code> — Image → Video\n` +
    `├ <code>/upscale</code> / <code>/enhance</code> / <code>/unblur</code>\n` +
    `╰ <code>/denoise</code> / <code>/restore</code> / <code>/colorize</code>\n\n` +
    `<b>TAMBAHAN</b>\n` +
    `├ <code>/unlimitedai &lt;pesan&gt;</code>\n` +
    `├ <code>/gpt52 &lt;pesan&gt;</code>\n` +
    `├ <code>/feeb &lt;pesan&gt;</code>\n` +
    `├ <code>/logicbell &lt;pesan&gt;</code>\n` +
    `╰ <code>/geminivision &lt;tanya&gt;</code> (reply foto)\n` +
    `</blockquote>`;

  const kb = {
    inline_keyboard: [
      [
        { text: '‹ AI Center', callback_data: 'aimenu' },
        { text: '‹‹‹', callback_data: 'back' },
      ],
    ],
  };
  return { text, kb };
}

function registerAiMenu(bot) {
  const editMsg = async (callbackQuery, text, kb) => {
    const opts = {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      parse_mode: 'HTML',
      reply_markup: kb,
    };
    try {
      await bot.editMessageCaption(text, opts);
    } catch {
      try { await bot.editMessageText(text, opts); } catch {}
    }
  };

  // aimenu — main AI sub-menu
  bot.on('callback_query', async (cb) => {
    if (cb.data !== 'aimenu') return;
    await bot.answerCallbackQuery(cb.id).catch(() => {});
    const { text, kb } = buildAiMenuPayload();
    await editMsg(cb, text, kb);
  });

  // ai_allcmds — full command list page
  bot.on('callback_query', async (cb) => {
    if (cb.data !== 'ai_allcmds') return;
    await bot.answerCallbackQuery(cb.id).catch(() => {});
    const { text, kb } = buildAiAllCmdsPage();
    await editMsg(cb, text, kb);
  });

  // individual model pages: ai_haiku, ai_gemini, ai_gpt5, ai_deepseek, ai_qwen, ai_media
  const modelKeys = Object.keys(AI_MODELS);
  bot.on('callback_query', async (cb) => {
    if (!modelKeys.includes(cb.data)) return;
    await bot.answerCallbackQuery(cb.id).catch(() => {});
    const page = buildAiModelPage(cb.data);
    if (!page) return;
    await editMsg(cb, page.text, page.kb);
  });
}

// Append registerAiMenu call into the existing register() export
const _origRegister = module.exports;
module.exports = (bot) => {
  _origRegister(bot);
  registerAiMenu(bot);
};
