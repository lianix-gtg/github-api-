const fetch = require("node-fetch");
const path = require("path");

const settings = require("../settings.js");
const dataFunction = require("../src/data/function");
const fsData = require("fs");

// Jangan bergantung penuh pada export loadJsonData dari modul bersama.
// Beberapa deployment lama masih memiliki cache/module function.js versi lama,
// sehingga destructuring langsung bisa menghasilkan "loadJsonData is not a function".
// VPS commands memakai fallback lokal yang selalu tersedia.
const loadJsonData = typeof dataFunction.loadJsonData === "function"
    ? dataFunction.loadJsonData
    : function loadJsonDataFallback(file) {
        try {
            if (!fsData.existsSync(file)) return [];
            const raw = fsData.readFileSync(file, "utf8");
            const value = JSON.parse(raw || "[]");
            return Array.isArray(value) ? value : [];
        } catch (err) {
            console.error("[cvps] gagal membaca JSON:", file, err.message);
            return [];
        }
    };
const saveJsonData = typeof dataFunction.saveJsonData === "function"
    ? dataFunction.saveJsonData
    : function saveJsonDataFallback(file, value) {
        try {
            const dir = path.dirname(file);
            if (!fsData.existsSync(dir)) fsData.mkdirSync(dir, { recursive: true });
            fsData.writeFileSync(file, JSON.stringify(value, null, 2));
            return true;
        } catch (err) {
            console.error("[cvps] gagal menyimpan JSON:", file, err.message);
            return false;
        }
    };
const { addVPS, getVPS } = dataFunction;

const RESSVPS_FILE = path.join(__dirname, '..', 'db', 'users', 'resellerVps.json');
const OWNER_ID = settings.ownerId;

const userStates = global.__LIANIX_CVPS_USER_STATES__ || (global.__LIANIX_CVPS_USER_STATES__ = Object.create(null));
// FIX: dulu dropletId & apiKey buat /rebuild disimpen di global.__REBUILD_ID__ /
// global.__REBUILD_API__ (satu slot doang buat SEMUA user). Kalau 2 reseller
// jalanin /rebuild bersamaan, punya user B bisa nimpa punya user A -> salah
// droplet yang ke-rebuild. Sekarang disimpen per-user pakai object ini.
const rebuildState = {};

    const vpsSpecs = {
  r1c1:  { size: "s-1vcpu-1gb",        name: "Ram 1GB Core 1",  icon: "⬢" },
  r2c2:  { size: "s-2vcpu-2gb",        name: "Ram 2GB Core 2",  icon: "⟡" },
  r4c2:  { size: "s-2vcpu-4gb",        name: "Ram 4GB Core 2",  icon: "▭" },
  r8c4:  { size: "s-4vcpu-8gb",        name: "Ram 8GB Core 4",  icon: "⊙" },
  r16c4: { size: "s-4vcpu-16gb-amd",   name: "Ram 16GB Core 4", icon: "⚒" },
  r16c8: { size: "s-8vcpu-16gb-amd",   name: "Ram 16GB Core 8", icon: "➤" },
  r32c8: { size: "s-8vcpu-32gb-amd",   name: "Ram 32GB Core 8", icon: "⌖" }
};

    const vpsImages = {
  ubuntu20: { image: "ubuntu-20-04-x64", name: "Ubuntu 20.04 LTS", icon: "○" },
  ubuntu22: { image: "ubuntu-22-04-x64", name: "Ubuntu 22.04 LTS", icon: "●" },
  ubuntu24: { image: "ubuntu-24-04-x64", name: "Ubuntu 24.04 LTS", icon: "○" },
  debian11: { image: "debian-11-x64",   name: "Debian 11", icon: "○" },
  debian12: { image: "debian-12-x64",   name: "Debian 12", icon: "○" },
  centos9: { image: "centos-stream-9-x64", name: "CentOS Stream 9", icon: "●" }
};

    const vpsRegions = {
  sgp1: { name: "Singapore", flag: "⟐", latency: "Tercepat untuk Asia" },
  nyc1: { name: "New York", flag: "⟐", latency: "USA Pantai Timur" },
  sfo3: { name: "San Francisco", flag: "⟐", latency: "USA Pantai Barat" },
  lon1: { name: "London", flag: "⟐", latency: "Eropa Barat" },
  fra1: { name: "Frankfurt", flag: "⟐", latency: "Eropa Tengah" },
  ams3: { name: "Amsterdam", flag: "⟐", latency: "Eropa Barat" },
  tor1: { name: "Toronto", flag: "⟐", latency: "Amerika Utara" },
  blr1: { name: "Bangalore", flag: "⟐", latency: "Asia Selatan" }
};

const REGISTERED_CVPS_BOTS = global.__LIANIX_CVPS_REGISTERED_BOTS__ || (global.__LIANIX_CVPS_REGISTERED_BOTS__ = new WeakSet());
const processedAddDoMessages = global.__LIANIX_ADD_DO_MESSAGES__ || (global.__LIANIX_ADD_DO_MESSAGES__ = new Map());
const processedAddDoCallbacks = global.__LIANIX_ADD_DO_CALLBACKS__ || (global.__LIANIX_ADD_DO_CALLBACKS__ = new Set());
const processedCvpsMessages = global.__LIANIX_CVPS_MESSAGES__ || (global.__LIANIX_CVPS_MESSAGES__ = new Map());

function onceMessage(map, key, ttl = 60000) {
  const now = Date.now();
  const old = map.get(key);
  if (old && now - old < ttl) return false;
  map.set(key, now);
  for (const [k, t] of map) if (now - t > ttl) map.delete(k);
  return true;
}

module.exports = (bot) => {
    // Cegah handler /adddo, /createvps, callback, dll terdaftar dua kali
    // bila loader melakukan require ulang terhadap modul CVPS.
    if (REGISTERED_CVPS_BOTS.has(bot)) {
        console.warn('[cvps] handlers sudah terdaftar untuk bot ini; registrasi dilewati.');
        return;
    }
    REGISTERED_CVPS_BOTS.add(bot);

    async function createVPSDroplet(apiKey, hostname, spec, os, region, password) {
  const dropletData = {
    name: hostname.toLowerCase().trim(),
    region,
    size: vpsSpecs[spec].size,
    image: vpsImages[os].image,
    ssh_keys: null,
    backups: false,
    ipv6: true,
    user_data: `#cloud-config\npassword: ${password}\nchpasswd: { expire: False }\nssh_pwauth: True`,
    private_networking: null,
    volumes: null,
    tags: ["YanzDev-VPS", "pay-tama.vercel.app", new Date().toISOString().split("T")[0]]
  };

  const response = await fetch("https://api.digitalocean.com/v2/droplets", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`
    },
    body: JSON.stringify(dropletData)
  });

  const data = await response.json();
  if (!response.ok) throw new Error(data.message || "Failed to create VPS");
  return data.droplet.id;
}

async function getDropletIP(apiKey, dropletId) {
  const response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`
    }
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.message || "Failed to fetch droplet info");
  return data.droplet.networks.v4.find(net => net.type === "public").ip_address;
}

async function getDropletInfo(apiKey, dropletId) {
  const response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`
    }
  });

  const data = await response.json();
  if (!response.ok) {
    throw new Error(data.message || `Gagal ambil info VPS (HTTP ${response.status})`);
  }

  return data.droplet;
}
    

async function deleteVPS(apiKey, dropletId) {
  const response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`
    }
  });

  if (!response.ok) {
    const data = await response.json().catch(() => ({}));
    throw new Error(data.message || `Gagal delete VPS (HTTP ${response.status})`);
  }

  return true;
}

async function getAllVPS(apiKey) {
  const response = await fetch("https://api.digitalocean.com/v2/droplets", {
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`
    }
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.message || `Gagal ambil VPS (HTTP ${response.status})`);
  return Array.isArray(data.droplets) ? data.droplets : [];
}

async function getListVps(apiKey) {
  if (!apiKey) throw new Error("API Key DigitalOcean belum diatur untuk slot ini");
  const response = await fetch("https://api.digitalocean.com/v2/droplets", {
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`
    }
  });

  if (!response.ok) {
    throw new Error(`Gagal ambil daftar VPS: ${response.status} ${response.statusText}`);
  }

  const data = await response.json();
  return data.droplets || [];
}

async function getVpsDetail(apiKey, dropletId) {
  const response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`
    }
  });

  if (!response.ok) {
    throw new Error(`Gagal ambil detail VPS: ${response.status} ${response.statusText}`);
  }

  const data = await response.json();
  return data.droplet;
}

function formatVPSStatus(status) {
  if (status === "active") return "● Active"
  if (status === "off") return "○ Off"
  return "○ " + status
}

function formatUptime(createdAt) {
  const created = new Date(createdAt)
  const now = new Date()
  const diffMs = now - created
  const diffHrs = Math.floor(diffMs / 3600000)
  const diffDays = Math.floor(diffHrs / 24)
  return diffDays > 0 ? `${diffDays}d ${diffHrs % 24}h` : `${diffHrs}h`
}
    
// ===================== ADD DIGITAL OCEAN API KEY =====================
// /adddo -> pilih slot DO 1-10 lewat tombol -> user diminta kirim API Key
// sebagai pesan teks biasa -> divalidasi ke DigitalOcean -> disimpan.
// Disimpan ke settings (in-memory, biar semua lookup existing di file ini
// yang baca `settings.apiDigitalOceanN` langsung ke-update) dan juga
// ditulis balik ke settings.js supaya nggak hilang kalau bot di-restart.
const fsAddDo = require("fs");
const SETTINGS_FILE_PATH = path.join(__dirname, "..", "settings.js");

function doSlotKey(slot) {
  return slot === "1" ? "apiDigitalOcean" : `apiDigitalOcean${slot}`;
}

function getDoApiKey(slot) {
  const key = doSlotKey(String(slot));
  return String(settings[key] || "").trim();
}

function persistDoApiKey(slot, apiKey) {
  const key = doSlotKey(slot);
  // Update in-memory dulu supaya efeknya langsung kepakai tanpa restart.
  settings[key] = apiKey;
  try {
    let src = fsAddDo.readFileSync(SETTINGS_FILE_PATH, "utf8");
    const q = String(apiKey).replace(/\\/g, "\\\\").replace(/"/g, '\\"');
    const re = new RegExp(`(^\\s*${key}\\s*:\\s*)(".*?"|'.*?')(\\s*,?\\s*(?://.*)?$)`, "m");
    if (re.test(src)) {
      src = src.replace(re, `$1"${q}"$3`);
    } else {
      // Key belum ada di settings.js -> sisipkan setelah apiDigitalOcean pertama yang ketemu,
      // atau di baris kedua file kalau sama sekali belum ada key DO manapun.
      const anchor = /(^\s*apiDigitalOcean\w*\s*:\s*(?:".*?"|'.*?')\s*,?\s*(?:\/\/.*)?$)/m;
      if (anchor.test(src)) {
        src = src.replace(anchor, `$1\n  ${key}: "${q}",`);
      } else {
        src = src.replace(/module\.exports\s*=\s*\{/, `module.exports = {\n  ${key}: "${q}",`);
      }
    }
    fsAddDo.writeFileSync(SETTINGS_FILE_PATH, src);
    return true;
  } catch (e) {
    console.error("[adddo] gagal menulis settings.js:", e.message);
    return false;
  }
}

bot.onText(/^\/adddo$/, async (msg) => {
  const chatId = msg.chat.id;
  const addDoMsgKey = `${chatId}:${msg.message_id}`;
  if (!onceMessage(processedAddDoMessages, addDoMsgKey)) return;
  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "✕ Khusus owner.");
  }

  const rows = [];
  for (let i = 1; i <= 10; i += 2) {
    const row = [{ text: `⟐ DO ${i}`, callback_data: `adddo_${i}` }];
    if (i + 1 <= 10) row.push({ text: `⟐ DO ${i + 1}`, callback_data: `adddo_${i + 1}` });
    rows.push(row);
  }

  bot.sendMessage(
    chatId,
    `⌗ Tambah API Key Digital Ocean\nThanks from @${settings.dev}\n\nPilih slot DO yang mau diisi/diupdate:`,
    { reply_to_message_id: msg.message_id, reply_markup: { inline_keyboard: rows } }
  );
});

bot.on("callback_query", async (query) => {
  if (!query.message) return;
  const data = query.data || "";
  if (data.startsWith('adddo_')) {
    const callbackKey = String(query.id);
    if (processedAddDoCallbacks.has(callbackKey)) return;
    processedAddDoCallbacks.add(callbackKey);
    setTimeout(() => processedAddDoCallbacks.delete(callbackKey), 120000);
  }
  if (!data.startsWith("adddo_")) return;

  const chatId = query.message.chat.id;
  if (query.from.id !== OWNER_ID) {
    return bot.answerCallbackQuery(query.id, { text: "Khusus owner", show_alert: true });
  }

  const slot = data.replace("adddo_", "");
  if (!/^([1-9]|10)$/.test(slot)) return bot.answerCallbackQuery(query.id);

  userStates[chatId] = { type: "adddo", slot };
  await bot.answerCallbackQuery(query.id);
  bot.sendMessage(
    chatId,
    `⟐ Masukkan API Key DigitalOcean untuk slot ${slot}:\n(kirim sebagai pesan teks biasa, kirim /batal untuk membatalkan)`,
    { reply_to_message_id: query.message.message_id }
  );
});

bot.on("message", async (msg) => {
  const chatId = msg.chat.id;
  const text = (msg.text || "").trim();
  if (!text) return;

  const state = userStates[chatId];
  if (!state || state.type !== "adddo") return;

  if (text === "/batal") {
    delete userStates[chatId];
    return bot.sendMessage(chatId, "✕ Dibatalkan.");
  }
  if (text.startsWith("/")) return; // biarkan command lain lewat tanpa kesedot state ini

  delete userStates[chatId];
  const slot = state.slot;
  const apiKey = text;

  const checking = await bot.sendMessage(chatId, `⏳ Memeriksa API Key untuk slot ${slot}...`);
  try {
    const res = await fetch("https://api.digitalocean.com/v2/account", {
      headers: { Authorization: `Bearer ${apiKey}` }
    });
    if (!res.ok) {
      return bot.editMessageText(
        `✕ API Key ditolak DigitalOcean (HTTP ${res.status}). Cek lagi key-nya lalu ulangi /adddo.`,
        { chat_id: chatId, message_id: checking.message_id }
      );
    }
    const acc = await res.json();
    const email = acc?.account?.email || "-";
    const status = acc?.account?.status || "-";

    const saved = persistDoApiKey(slot, apiKey);
    if (!saved) {
      return bot.editMessageText(
        `⚠ API Key valid (akun: ${email}, status: ${status}) tapi GAGAL disimpan permanen ke settings.js. Sudah aktif untuk sesi ini, tapi akan hilang kalau bot di-restart. Cek log server.`,
        { chat_id: chatId, message_id: checking.message_id }
      );
    }
    return bot.editMessageText(
      `✓ API Key DO slot ${slot} tersimpan.\nAkun: ${email}\nStatus: ${status}`,
      { chat_id: chatId, message_id: checking.message_id }
    );
  } catch (e) {
    return bot.editMessageText(
      `✕ Gagal menghubungi DigitalOcean: ${e.message}`,
      { chat_id: chatId, message_id: checking.message_id }
    );
  }
});

bot.onText(/^\/statusdo$/, async (msg) => {
  const chatId = msg.chat.id;

  const ressVps = loadJsonData(RESSVPS_FILE);
  if (msg.from.id !== OWNER_ID && !ressVps.includes(msg.from.id)) {
    return bot.sendMessage(chatId, '✕ Khusus reseller VPS');
  }

  const opts = {
    reply_markup: {
      inline_keyboard: [
        [{ text: "⟐ Digital Ocean 1", callback_data: "infodo_1" }],
        [{ text: "⟐ Digital Ocean 2", callback_data: "infodo_2" }],
        [{ text: "⟐ Digital Ocean 3", callback_data: "infodo_3" }],
        [{ text: "⟐ Digital Ocean 4", callback_data: "infodo_4" }],
        [{ text: "⟐ Digital Ocean 5", callback_data: "infodo_5" }],
        [{ text: "⟐ Digital Ocean 6", callback_data: "infodo_6" }],
        [{ text: "⟐ Digital Ocean 7", callback_data: "infodo_7" }],
        [{ text: "⟐ Digital Ocean 8", callback_data: "infodo_8" }],
        [{ text: "⟐ Digital Ocean 9", callback_data: "infodo_9" }],
        [{ text: "⟐ Digital Ocean 10", callback_data: "infodo_10" }]
      ]
    }
  };

  bot.sendMessage(
    chatId,
    `⌗ Menu Status Digital Ocean
Thanks from @${settings.dev}

Digital Ocean Account:`,
    {
      reply_to_message_id: msg.message_id,
      ...opts
    }
  );
});

bot.on("callback_query", async (query) => {
  if (!query.message) return;

  const chatId = query.message.chat.id;
  const data = query.data;

  if (data.startsWith("infodo_") && !data.includes("detail")) {
    const tag = data.replace("infodo_", "");
    const apiKey = getDoApiKey(tag);

    if (!apiKey) return bot.answerCallbackQuery(query.id, { text: "API Key belum diatur!" });

    try {
      const accountRes = await fetch("https://api.digitalocean.com/v2/account", {
        headers: { Authorization: `Bearer ${apiKey}` }
      });
      const account = await accountRes.json();

      const dropletRes = await fetch("https://api.digitalocean.com/v2/droplets", {
        headers: { Authorization: `Bearer ${apiKey}` }
      });
      const droplets = await dropletRes.json();

      if (account.account && account.account.email) {
        const dropletList = Array.isArray(droplets.droplets) ? droplets.droplets : [];
        const activeVPS = dropletList.filter(d => d.status === "active").length;
        const totalDroplet = dropletList.length;

        let msgText = `<blockquote>`;
        msgText += `⌗ Status Akun: ${account.account.status}\n`;
        msgText += `⌗ Total Droplet: ${account.account.droplet_limit}\n`;
        msgText += `⟐ VPS Aktif: ${activeVPS}\n`;
        msgText += `⬡ Sisa Droplet: ${account.account.droplet_limit - totalDroplet}`;
        msgText += `</blockquote>`;

        bot.editMessageText(msgText, {
          chat_id: chatId,
          message_id: query.message.message_id,
          parse_mode: "HTML",
          reply_markup: {
            inline_keyboard: [
              [{ text: "ℹ Info Lengkap", callback_data: `infodo_detail_${tag}` }]
            ]
          }
        });
      } else {
        bot.editMessageText("<blockquote>✕ API Key tidak valid atau akun tidak aktif</blockquote>", {
          chat_id: chatId,
          message_id: query.message.message_id,
          parse_mode: "HTML"
        });
      }
    } catch {
      bot.editMessageText("<blockquote>⚠ Gagal mengambil data dari DigitalOcean</blockquote>", {
        chat_id: chatId,
        message_id: query.message.message_id,
        parse_mode: "HTML"
      });
    }
  }

  // ===== INFO LENGKAP =====
  if (data.startsWith("infodo_detail_")) {
    const tag = data.replace("infodo_detail_", "");
    const apiKey = getDoApiKey(tag);

    if (!apiKey) return bot.answerCallbackQuery(query.id, { text: "API Key belum diatur!" });

    try {
      const accountRes = await fetch("https://api.digitalocean.com/v2/account", {
        headers: { Authorization: `Bearer ${apiKey}` }
      });
      const account = await accountRes.json();

      const dropletRes = await fetch("https://api.digitalocean.com/v2/droplets", {
        headers: { Authorization: `Bearer ${apiKey}` }
      });
      const droplets = await dropletRes.json();

      const info = account.account;
      const dropletList = Array.isArray(droplets.droplets) ? droplets.droplets : [];
      const suspendedCount = dropletList.filter(d => d.status !== "active").length;

      let detailText = `<blockquote>`;
      detailText += `✉ Email: ${info.email}\n`;
      detailText += `⌇ UUID: ${info.uuid}\n`;
      detailText += `▦ Status: ${info.status}\n`;
      detailText += `⌗ Droplet Limit: ${info.droplet_limit}\n`;
      detailText += `⟠ Email Verified: ${info.email_verified ? "Ya" : "Tidak"}\n`;
      detailText += `⚑ Team: ${info.team ? "Ya" : "Tidak"}\n`;
      detailText += `⊘ VPS Suspend: ${suspendedCount}`;
      detailText += `</blockquote>`;

      bot.editMessageText(detailText, {
        chat_id: chatId,
        message_id: query.message.message_id,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [{ text: "⬅ ‹", callback_data: data.replace("detail_", "") }]
          ]
        }
      });
    } catch {
      bot.editMessageText("<blockquote>✕ Gagal mengambil info lengkap</blockquote>", {
        chat_id: chatId,
        message_id: query.message.message_id,
        parse_mode: "HTML"
      });
    }
  }

  bot.answerCallbackQuery(query.id).catch(() => {});
});
const userCreateVPS = {};

function autoHostnameFromSpec(spec) {
  const m = String(spec?.size || "s-1vcpu-1gb").match(/^s-(.+)$/);
  return m ? m[1].replace(/-amd$/, "") : "1vcpu-1gb";
}

bot.onText(/^\/(?:cvps|createvps)(?:\s+(.+))?$/i, async msg => {
  const chatId = msg.chat.id;
  const cvpsMsgKey = `${chatId}:${msg.message_id}`;
  if (!onceMessage(processedCvpsMessages, cvpsMsgKey)) return;

  const ressVps = loadJsonData(RESSVPS_FILE);
  if (msg.from.id !== OWNER_ID && !ressVps.includes(msg.from.id)) {
    return bot.sendMessage(chatId, '✕ Khusus reseller VPS');
  }

  const inputHostname = msg.text.split(" ").slice(1).join(" ").trim();

  userCreateVPS[msg.from.id] = {
    hostname: inputHostname
      ? inputHostname
          .toLowerCase()
          .replace(/[^a-z0-9-]/g, "")
          .slice(0, 32)
      : null
  };

  const keyboard = [
    [{ text: "⟐ Digital Ocean 1", callback_data: "createvps_1" }],
    [{ text: "⟐ Digital Ocean 2", callback_data: "createvps_2" }],
    [{ text: "⟐ Digital Ocean 3", callback_data: "createvps_3" }],
    [{ text: "⟐ Digital Ocean 4", callback_data: "createvps_4" }],
    [{ text: "⟐ Digital Ocean 5", callback_data: "createvps_5" }],
    [{ text: "⟐ Digital Ocean 6", callback_data: "createvps_6" }],
    [{ text: "⟐ Digital Ocean 7", callback_data: "createvps_7" }],
    [{ text: "⟐ Digital Ocean 8", callback_data: "createvps_8" }],
    [{ text: "⟐ Digital Ocean 9", callback_data: "createvps_9" }],
    [{ text: "⟐ Digital Ocean 10", callback_data: "createvps_10" }]
  ];

  bot.sendMessage(
    chatId,
    `⌂ *Menu Create VPS*
ᴛʜᴀɴᴋꜱ ꜰʀᴏᴍ @${settings.dev}

Digital Ocean Account:`,
    {
      parse_mode: "Markdown",
      reply_to_message_id: msg.message_id,
      reply_markup: { inline_keyboard: keyboard }
    }
  );
});

bot.on("callback_query", async cb => {
  const chatId = cb.message.chat.id;
  const userId = cb.from.id;
  const data = cb.data;


  if (data === "cvps_create") {
    const ressVps = loadJsonData(RESSVPS_FILE);
    if (userId !== OWNER_ID && !ressVps.includes(userId)) {
      return bot.answerCallbackQuery(cb.id, { text: "Khusus reseller VPS.", show_alert: true }).catch(() => {});
    }
    userCreateVPS[userId] = userCreateVPS[userId] || { hostname: null };
    const keyboard = Array.from({length:10}, (_,i) => ([{ text: `Digital Ocean ${i+1}`, callback_data: `createvps_${i+1}` }]))
      .concat([[{ text: "‹‹‹", callback_data: "cvpsmenu" }]]);
    await bot.answerCallbackQuery(cb.id).catch(() => {});
    return bot.editMessageText(
      `⌂ *CREATE VPS*\n\nPilih akun DigitalOcean yang akan digunakan.\nHostname akan dibuat otomatis jika belum ditentukan lewat /cvps namahost.`,
      { chat_id: chatId, message_id: cb.message.message_id, parse_mode: "Markdown", reply_markup: { inline_keyboard: keyboard } }
    ).catch(() => {});
  }

  if (data.startsWith("createvps_")) {
    const accId = data.split("_")[1];

    const keyboard = Object.entries(vpsSpecs).map(([id, spec]) => ([{
      text: `${spec.icon} ${spec.name}`,
      callback_data: `spec_${accId}_${id}`
    }]));

    return bot.editMessageText(
      `⌂ *Menu Create VPS*
⟐ Digital Ocean: *${accId}*
Pilih spesifikasi VPS:`,
      {
        chat_id: chatId,
        message_id: cb.message.message_id,
        parse_mode: "Markdown",
        reply_markup: { inline_keyboard: keyboard }
      }
    );
  }

  /* ===== PILIH SPEC ===== */
  if (data.startsWith("spec_")) {
    const [, accId, specId] = data.split("_");
    const spec = vpsSpecs[specId];
    const userData = userCreateVPS[userId] || {};
    const previewHostname = userData.hostname || autoHostnameFromSpec(spec);

    const keyboard = Object.entries(vpsImages).map(([id, img]) => ([{
      text: `${img.icon} ${img.name}`,
      callback_data: `image_${accId}_${specId}_${id}`
    }]));

    return bot.editMessageText(
      `⬢ Spesifikasi VPS
*${spec.name}*
▭ Hostname:
\`${previewHostname}\`

Pilih OS image:`,
      {
        chat_id: chatId,
        message_id: cb.message.message_id,
        parse_mode: "Markdown",
        reply_markup: { inline_keyboard: keyboard }
      }
    );
  }

  /* ===== PILIH IMAGE ===== */
  if (data.startsWith("image_")) {
    const [, accId, specId, imageId] = data.split("_");
    const spec = vpsSpecs[specId];
    const img = vpsImages[imageId];

    const keyboard = Object.entries(vpsRegions).map(([id, reg]) => ([{
      text: `${reg.flag} ${reg.name}`,
      callback_data: `region_${accId}_${specId}_${imageId}_${id}`
    }]));

    return bot.editMessageText(
      `⬢ Spesifikasi VPS
*${spec.name}*
⟡ Image: *${img.name}*

Pilih region:`,
      {
        chat_id: chatId,
        message_id: cb.message.message_id,
        parse_mode: "Markdown",
        reply_markup: { inline_keyboard: keyboard }
      }
    );
  }

  /* ===== CREATE VPS ===== */
  if (data.startsWith("region_")) {
    const [, accId, specId, imageId, regionId] = data.split("_");
    const spec = vpsSpecs[specId];
    const img = vpsImages[imageId];
    const reg = vpsRegions[regionId];
    const apiKey = getDoApiKey(accId);

    const userData = userCreateVPS[userId] || {};
    const hostname = userData.hostname || autoHostnameFromSpec(spec);
    const password = "love";

    if (!apiKey) {
      return bot.answerCallbackQuery(cb.id, { text: `API DigitalOcean slot ${accId} belum diatur.`, show_alert: true }).catch(() => {});
    }
    if (!spec || !img || !reg) {
      return bot.answerCallbackQuery(cb.id, { text: "Pilihan VPS tidak valid. Ulangi /cvps.", show_alert: true }).catch(() => {});
    }

    const editCreate = async (pct, step) => {
      const fill = Math.max(0, Math.min(10, Math.round(pct / 10)));
      const text = `⌂ *CREATE VPS*\n\n[${"█".repeat(fill)}${"░".repeat(10-fill)}] *${pct}%*\n${step}\n\n⬢ ${spec.name}\n▭ Hostname: \`${hostname}\`\n⟡ ${img.name}\n⟐ ${reg.flag} ${reg.name}`;
      try { await bot.editMessageText(text, { chat_id: chatId, message_id: cb.message.message_id, parse_mode: "Markdown" }); } catch {}
    };

    await editCreate(10, "Tahap 1/5 • Memvalidasi akun DigitalOcean...");

    try {
      await editCreate(30, "Tahap 2/5 • Mengirim permintaan pembuatan Droplet...");
      const dropletId = await createVPSDroplet(
        apiKey,
        hostname,
        specId,
        imageId,
        regionId,
        password
      );

      await editCreate(55, `Tahap 3/5 • Droplet #${dropletId} dibuat. Menunggu provisioning...`);
      let ipAddress = null;
      let lastDroplet = null;
      const deadline = Date.now() + 3 * 60 * 1000;
      while (!ipAddress && Date.now() < deadline) {
        await new Promise(res => setTimeout(res, 5000));
        lastDroplet = await getDropletInfo(apiKey, dropletId);
        ipAddress = lastDroplet?.networks?.v4?.find(n => n.type === "public")?.ip_address || null;
        if (!ipAddress) await editCreate(75, "Tahap 4/5 • Menunggu IP publik dari DigitalOcean...");
      }
      if (!ipAddress) {
        throw new Error(`Droplet ${dropletId} berhasil dibuat, tetapi IP publik belum tersedia setelah 3 menit. Cek /listvps.`);
      }
      await editCreate(100, "Tahap 5/5 • VPS aktif dan IP publik sudah tersedia.");
      await new Promise(res => setTimeout(res, 300));

      bot.sendMessage(
        chatId,
        `✓ <b>Sukses create VPS!</b>
ʙᴇʀɪᴋᴜᴛ ᴅᴇᴛᴀɪʟ ᴠᴘꜱ ᴀɴᴅᴀ:

<blockquote expandable>⟐ IP VPS: <code>${ipAddress}</code>
⚿ Password: <code>${password}</code>
▭ Hostname: <code>${hostname}</code>
⌇ Droplet: <code>${dropletId}</code></blockquote>

⬢ Spec: ${spec.name}
⟡ OS: ${img.name}
⟐ Region: ${reg.flag} ${reg.name}

⌂ ᴅᴇᴛᴀɪʟ ʟᴏɢɪɴ ᴠᴘꜱ:
<code>root@${ipAddress}:22</code>

<blockquote expandable>⚠ 𝗧.𝗢.𝗦 𝗩𝗣𝗦:
• ɴᴏ ʜᴀᴄᴋɪɴɢ
• ɴᴏ ᴍɪɴɪɴɢ  
• ɴᴏ ᴛᴏʀʀᴇɴᴛ  
• ɴᴏ ᴏᴠᴇʀʟᴏᴀᴅ (100% ᴄᴘᴜ)  
• ɴᴏ ᴅᴅᴏs 
• ɪɴᴛɪɴʏᴀ: ᴊᴀɴɢᴀɴ ᴅɪɢᴜɴᴀᴋᴀɴ ᴜɴᴛᴜᴋ ᴀᴋᴛɪꜰɪᴛᴀꜱ ɪʟᴇɢᴀʟ ᴀᴘᴀ ᴘᴜɴ

▭ 𝗧.𝗢.𝗦 𝗧𝗢𝗞𝗢:
• Web toko mati karena DDoS tapi VPS masih aktif → Garansi TETAP AKTIF  
• VPS mati karena DDoS → Garansi HANGUS  
• VPS aktif tapi tidak bisa login → CPU 100% → Garansi HANGUS  
• Simpan data VPS Anda! Kehilangan data = Garansi hangus  
• Menjadi pembeli yang bijak, gunakan VPS sesuai aturan!

⚑ 𝗞𝗘𝗧𝗘𝗡𝗧𝗨𝗔𝗡 𝗔𝗞𝗨𝗡 𝗗.𝗢:
• Apabila akun DigitalOcean (DO) terkena suspend → Garansi hangus 

✎ 𝗦𝗬𝗔𝗥𝗔𝗧 𝗖𝗟𝗔𝗜𝗠 𝗚𝗔𝗥𝗔𝗡𝗦𝗜:
1. Membawa bukti transfer  
2. Sertakan screenshot chat saat pembelian
3. Simpan tanggal pembelian  
4. Lampirkan data VPS (IP/User/dll)
</blockquote>`,
        { parse_mode: "HTML" }
      );

      delete userCreateVPS[userId];
      bot.answerCallbackQuery(cb.id);
    } catch (err) {
      bot.sendMessage(chatId, `✕ Gagal membuat VPS\n${err.message}`);
    }
  }
});

bot.onText(/^\/listvps$/, async msg => {
  const chatId = msg.chat.id;

  const ressVps = loadJsonData(RESSVPS_FILE);
  if (msg.from.id !== OWNER_ID && !ressVps.includes(msg.from.id)) {
    return bot.sendMessage(chatId, '✕ Khusus reseller VPS');
  }

const keyboard = [
  [{ text: "⟐ Digital Ocean 1", callback_data: "listdo_1" }],
  [{ text: "⟐ Digital Ocean 2", callback_data: "listdo_2" }],
  [{ text: "⟐ Digital Ocean 3", callback_data: "listdo_3" }],
  [{ text: "⟐ Digital Ocean 4", callback_data: "listdo_4" }],
  [{ text: "⟐ Digital Ocean 5", callback_data: "listdo_5" }],
  [{ text: "⟐ Digital Ocean 6", callback_data: "listdo_6" }],
  [{ text: "⟐ Digital Ocean 7", callback_data: "listdo_7" }],
  [{ text: "⟐ Digital Ocean 8", callback_data: "listdo_8" }],
  [{ text: "⟐ Digital Ocean 9", callback_data: "listdo_9" }],
  [{ text: "⟐ Digital Ocean 10", callback_data: "listdo_10" }]
];

  await bot.sendMessage(chatId, `*☰ Menu List VPS*
ᴛʜᴀɴᴋꜱ ꜰʀᴏᴍ @${settings.dev}

Digital Ocean Account:`, {
    parse_mode: "Markdown",
    reply_to_message_id: msg.message_id,
    reply_markup: { inline_keyboard: keyboard }
  });
});

bot.on("callback_query", async query => {
  const chatId = query.message.chat.id;
  const data = query.data;

  if (data.startsWith("listdo_")) {
    const accId = data.split("_")[1];
    const apiKey = getDoApiKey(accId);

    try {
      await bot.editMessageText("⌕ Mengambil daftar VPS...", {
        chat_id: chatId,
        message_id: query.message.message_id
      });

      const droplets = await getListVps(apiKey);

      if (droplets.length === 0) {
        return bot.editMessageText("✉ Tidak ada VPS yang ditemukan.", {
          chat_id: chatId,
          message_id: query.message.message_id
        });
      }

      const keyboard = droplets.map(vps => {
        const ip = vps.networks?.v4?.find(net => net.type === "public")?.ip_address || "No IP";
        const region = vpsRegions[vps.region.slug] || { flag: "⚐", name: "Unknown" };
        const status = formatVPSStatus(vps.status);
        const uptime = formatUptime(vps.created_at);

        return [{
          text: `▭ ${vps.name} | ${status} | ${region.flag} ${region.name} | ${ip} | ${uptime}`,
          callback_data: `vpsinfo_${accId}_${vps.id}`
        }];
      });

      await bot.editMessageText(
        `⌂ *Monitoring Vps*\n\n⌗ Total VPS: *${droplets.length}*\nSilahkan klik untuk detail:`,
        {
          chat_id: chatId,
          message_id: query.message.message_id,
          parse_mode: "Markdown",
          reply_markup: { inline_keyboard: keyboard }
        }
      );
    } catch (err) {
      console.error("[LIST VPS ERROR]", err);
      bot.sendMessage(chatId, `✕ Gagal ambil daftar VPS\n\n⌗ Error: ${err.message}`);
    }
  }

  if (data.startsWith("vpsinfo_")) {
    const [_, accId, dropletId] = data.split("_");
    const apiKey = getDoApiKey(accId);
    
    try {
      const droplet = await getVpsDetail(apiKey, dropletId);

      const ip = droplet?.networks?.v4?.find(net => net.type === "public")?.ip_address || "Belum tersedia";
      const region = vpsRegions[droplet?.region?.slug] || { flag: "⚐", name: "Unknown" };
      const status = formatVPSStatus(droplet?.status);
      const uptime = droplet?.created_at ? formatUptime(droplet.created_at) : "Belum tersedia";

      const info = [
        `▭ *${droplet?.name || "Unknown"}*`,
        ``,
        `⌇ ID: \`${droplet?.id || "???"}\``,
        `⟐ IP: \`${ip}\``,
        `⬢ Spec: ${droplet?.size_slug || "???"}`,
        `▭ OS: ${droplet?.image?.distribution || "???"} ${droplet?.image?.name || ""}`,
        `⟐ Region: ${region.flag} ${region.name}`,
        `⌂ Status: ${status}`,
        `⏱ Uptime: ${uptime}`
      ].join("\n");

      await bot.sendMessage(chatId, info, { parse_mode: "Markdown" });
    } catch (err) {
      console.error("[VPS DETAIL ERROR]", err);
      bot.sendMessage(chatId, `✕ Gagal ambil detail VPS\n\n⌗ Error: ${err.message}`);
    }
  }

  bot.answerCallbackQuery(query.id);
});

bot.onText(/^\/delvps (.+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const dropletId = match[1].trim();

  const ressVps = loadJsonData(RESSVPS_FILE);
  if (msg.from.id !== OWNER_ID && !ressVps.includes(msg.from.id)) {
    return bot.sendMessage(chatId, "✕ Khusus reseller VPS");
  }

  if (!dropletId) {
    return bot.sendMessage(chatId, "✕ ID VPS tidak valid");
  }

  bot.sendMessage(
    chatId,
    `*⟲ Menu Delete VPS*
Thanks from @${settings.dev}

Digital Ocean Account:`,
    {
      parse_mode: "Markdown",
      reply_to_message_id: msg.message_id,
      reply_markup: {
        inline_keyboard: [
          [{ text: "⟐ Digital Ocean 1", callback_data: `delvpsacc_1_${dropletId}` }],
          [{ text: "⟐ Digital Ocean 2", callback_data: `delvpsacc_2_${dropletId}` }],
          [{ text: "⟐ Digital Ocean 3", callback_data: `delvpsacc_3_${dropletId}` }],
          [{ text: "⟐ Digital Ocean 4", callback_data: `delvpsacc_4_${dropletId}` }],
          [{ text: "⟐ Digital Ocean 5", callback_data: `delvpsacc_5_${dropletId}` }],
          [{ text: "⟐ Digital Ocean 6", callback_data: `delvpsacc_6_${dropletId}` }],
          [{ text: "⟐ Digital Ocean 7", callback_data: `delvpsacc_7_${dropletId}` }],
          [{ text: "⟐ Digital Ocean 8", callback_data: `delvpsacc_8_${dropletId}` }],
          [{ text: "⟐ Digital Ocean 9", callback_data: `delvpsacc_9_${dropletId}` }],
          [{ text: "⟐ Digital Ocean 10", callback_data: `delvpsacc_10_${dropletId}` }]
        ]
      }
    }
  );
});

bot.on("callback_query", async (cbq) => {
  if (!cbq.message) return;

  const chatId = cbq.message.chat.id;
  const data = cbq.data;

  if (data.startsWith("delvpsacc_")) {
    const [, accIndex, dropletId] = data.split("_");
    const apiKey = getDoApiKey(accIndex);

    if (!apiKey) {
      return bot.answerCallbackQuery(cbq.id, { text: "API tidak ditemukan" });
    }

    try {
      const vps = await getDropletInfo(apiKey, dropletId);

      const confirmMsg = [
        `⚠ *KONFIRMASI DELETE VPS*`,
        ``,
        `▭ Name: *${vps.name}*`,
        `⌇ ID: \`${dropletId}\``,
        `⟐ IP: \`${vps.networks?.v4?.[0]?.ip_address || "No IP"}\``,
        ``,
        `❢ *PERINGATAN:*`,
        `• Semua data akan hilang permanen`,
        `• VPS tidak dapat dikembalikan`,
        `• Proses delete tidak bisa dibatalkan`,
        ``,
        `Yakin ingin menghapus VPS ini?`
      ].join("\n");

      bot.sendMessage(chatId, confirmMsg, {
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "✓ Ya, Hapus", callback_data: `confirmdel_${accIndex}_${dropletId}` },
              { text: "✕ Batal", callback_data: "canceldelete" }
            ]
          ]
        }
      });
    } catch (err) {
      bot.sendMessage(chatId, `✕ Gagal ambil info VPS\n\n⌗ Error: ${err.message}`);
    }
  }

  if (data.startsWith("confirmdel_")) {
    const [, accIndex, dropletId] = data.split("_"); // FIX
    const apiKey = getDoApiKey(accIndex);

    if (!apiKey) {
      return bot.answerCallbackQuery(cbq.id, { text: "API tidak ditemukan" });
    }

    try {
      await deleteVPS(apiKey, dropletId);
      bot.sendMessage(chatId, `✓ VPS \`${dropletId}\` berhasil dihapus`, { parse_mode: "Markdown" });
    } catch (err) {
      bot.sendMessage(chatId, `✕ Gagal delete VPS\n\n⌗ Error: ${err.message}`);
    }
  }

  if (data === "canceldelete") {
    bot.sendMessage(chatId, "✕ Delete VPS dibatalkan.");
  }

  bot.answerCallbackQuery(cbq.id).catch(() => {});
});

// FIX: dulu tombol ini pakai callback_data "infodo_1".."infodo_10", sama
// persis kayak tombol /statusdo. Akibatnya klik salah satu SELALU memicu
// KEDUA handler ("infodo_" di /statusdo dan di /rebuild sekaligus) -> mecet
// akun DO di /statusdo malah ikut ngubah keyboard pesan itu jadi daftar OS
// rebuild (dropletId undefined), dan sebaliknya /rebuild ikut nampilin info
// akun DO yang gak diminta. Sekarang pakai prefix "rbacc_" sendiri.
const opts = {
  reply_markup: {
    inline_keyboard: [
      [{ text: "⟐ Digital Ocean 1", callback_data: "rbacc_1" }],
      [{ text: "⟐ Digital Ocean 2", callback_data: "rbacc_2" }],
      [{ text: "⟐ Digital Ocean 3", callback_data: "rbacc_3" }],
      [{ text: "⟐ Digital Ocean 4", callback_data: "rbacc_4" }],
      [{ text: "⟐ Digital Ocean 5", callback_data: "rbacc_5" }],
      [{ text: "⟐ Digital Ocean 6", callback_data: "rbacc_6" }],
      [{ text: "⟐ Digital Ocean 7", callback_data: "rbacc_7" }],
      [{ text: "⟐ Digital Ocean 8", callback_data: "rbacc_8" }],
      [{ text: "⟐ Digital Ocean 9", callback_data: "rbacc_9" }],
      [{ text: "⟐ Digital Ocean 10", callback_data: "rbacc_10" }]
    ]
  }
};

bot.onText(/^\/rebuild(?:\s+(\d+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const dropletId = match[1];

  const ressVps = loadJsonData(RESSVPS_FILE);
  if (msg.from.id !== OWNER_ID && !ressVps.includes(msg.from.id)) {
    return bot.sendMessage(chatId, "✕ Khusus reseller VPS");
  }

  if (!dropletId)
    return bot.sendMessage(chatId, "⚠ Contoh:\n/rebuild 123456789");

  rebuildState[String(msg.from.id)] = { dropletId };

  return bot.sendMessage(
    chatId,
    `⚒ Pilih akun DigitalOcean\n⌇ Droplet: \`${dropletId}\``,
    { ...opts, parse_mode: "Markdown" }
  );
});

async function animateLoading(bot, chatId, textList, delay = 500) {
  let index = 0;
  const sent = await bot.sendMessage(chatId, textList[0], { parse_mode: "Markdown" });

  const interval = setInterval(async () => {
    index = (index + 1) % textList.length;
    try {
      await bot.editMessageText(textList[index], {
        chat_id: chatId,
        message_id: sent.message_id,
        parse_mode: "Markdown"
      });
    } catch {}
  }, delay);

  return { interval, message_id: sent.message_id };
}

bot.on("callback_query", async (query) => {
  const data = query.data;
  const chatId = query.message.chat.id;
  const msgId = query.message.message_id;

  if (data.startsWith("rbacc_")) {
    let apiKey, tag;

    if (data === "rbacc_1") { apiKey = settings.apiDigitalOcean; tag = "1"; }
    if (data === "rbacc_2") { apiKey = settings.apiDigitalOcean2; tag = "2"; }
    if (data === "rbacc_3") { apiKey = settings.apiDigitalOcean3; tag = "3"; }
    if (data === "rbacc_4") { apiKey = settings.apiDigitalOcean4; tag = "4"; }
    if (data === "rbacc_5") { apiKey = settings.apiDigitalOcean5; tag = "5"; }
    if (data === "rbacc_6") { apiKey = settings.apiDigitalOcean6; tag = "6"; }
    if (data === "rbacc_7") { apiKey = settings.apiDigitalOcean7; tag = "7"; }
    if (data === "rbacc_8") { apiKey = settings.apiDigitalOcean8; tag = "8"; }
    if (data === "rbacc_9") { apiKey = settings.apiDigitalOcean9; tag = "9"; }
    if (data === "rbacc_10") { apiKey = settings.apiDigitalOcean10; tag = "10"; }

    if (!apiKey)
      return bot.answerCallbackQuery(query.id, { text: "API Key belum diatur!", show_alert: true });

    const userKey = String(query.from.id);
    const dropletId = rebuildState[userKey]?.dropletId;

    if (!dropletId)
      return bot.answerCallbackQuery(query.id, { text: "Sesi /rebuild sudah kadaluarsa, ulangi /rebuild <id>.", show_alert: true });

    const osList = [
      { name: "Ubuntu 20.04", slug: "ubuntu-20-04-x64" },
      { name: "Ubuntu 22.04", slug: "ubuntu-22-04-x64" },
      { name: "Ubuntu 24.04", slug: "ubuntu-24-04-x64" },
      { name: "Ubuntu 25.04", slug: "ubuntu-25-04-x64" },
      { name: "Ubuntu 25.10", slug: "ubuntu-25-10-x64" },
      { name: "Fedora 42", slug: "fedora-42-x64" },
      { name: "Debian 12", slug: "debian-12-x64" },
      { name: "Debian 13", slug: "debian-13-x64" },
      { name: "CentOS Stream 9", slug: "centos-stream-9-x64" },
      { name: "CentOS Stream 10", slug: "centos-stream-10-x64" },
      { name: "AlmaLinux 8", slug: "almalinux-8-x64" },
      { name: "AlmaLinux 9", slug: "almalinux-9-x64" },
      { name: "AlmaLinux 10", slug: "almalinux-10-x64" },
      { name: "Rocky Linux 8", slug: "rockylinux-8-x64" },
      { name: "Rocky Linux 9", slug: "rockylinux-9-x64" },
      { name: "Rocky Linux 10", slug: "rockylinux-10-x64" }
    ];

    const keyboard = osList.map(os => [{
      text: os.name,
      callback_data: `rb_os:${dropletId}:${tag}:${os.slug}`
    }]);

    rebuildState[userKey] = { dropletId, apiKey, tag };

    return bot.editMessageReplyMarkup(
      { inline_keyboard: keyboard },
      { chat_id: chatId, message_id: msgId }
    );
  }

  if (data.startsWith("rb_os")) {
    const [, dropletId, version, osSlug] = data.split(":");
    const userKey = String(query.from.id);
    const apiKey = rebuildState[userKey]?.apiKey;

    if (!apiKey)
      return bot.answerCallbackQuery(query.id, { text: "API Key invalid!", show_alert: true });

    delete rebuildState[userKey];

    bot.answerCallbackQuery(query.id);
    await bot.deleteMessage(chatId, msgId).catch(() => {});

    const frames = [
      "⟳ *Rebuild sedang diproses...*\n\n⏳ Mohon tunggu...",
      "⟳ *Rebuild sedang diproses...*\n\n⌛ Mohon tunggu...",
      "⟳ *Rebuild sedang diproses...*\n\n⟳ Mohon tunggu...",
      "⟳ *Rebuild sedang diproses...*\n\n⟡ Mohon tunggu..."
    ];

    const loading = await animateLoading(bot, chatId, frames, 600);

    const imgList = await fetch(
      "https://api.digitalocean.com/v2/images?type=distribution",
      { headers: { Authorization: `Bearer ${apiKey}` } }
    );

    const img = await imgList.json();
    const target = img.images.find(i => i.slug === osSlug);

    if (!target) {
      clearInterval(loading.interval);
      await bot.deleteMessage(chatId, loading.message_id).catch(() => {});
      return bot.sendMessage(chatId, `✕ Image *${osSlug}* tidak ditemukan!`, { parse_mode: "Markdown" });
    }

    const rebuild = await fetch(
      `https://api.digitalocean.com/v2/droplets/${dropletId}/actions`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${apiKey}`
        },
        body: JSON.stringify({ type: "rebuild", image: target.id })
      }
    );

    const res = await rebuild.json();

    await bot.editMessageText(
      `⟳ *Rebuild dimulai!*\n\n⌇ ID: \`${dropletId}\`\n⟐ API: V${version}\n⟡ OS: *${osSlug}*\n⊙ Status: ${res.action.status}`,
      {
        chat_id: chatId,
        message_id: loading.message_id,
        parse_mode: "Markdown"
      }
    );

    setTimeout(async () => {
      const info = await fetch(
        `https://api.digitalocean.com/v2/droplets/${dropletId}`,
        { headers: { Authorization: `Bearer ${apiKey}` } }
      );

      const vps = await info.json();
      const droplet = vps.droplet;

      const ip =
        droplet.networks.v4.find(n => n.type === "public")?.ip_address ||
        "IP belum muncul";

      await bot.deleteMessage(chatId, loading.message_id).catch(() => {});

      return bot.sendMessage(
        chatId,
        `⟡ *Rebuild Selesai!*\n\n⌇ ID: \`${dropletId}\`\n⟐ IP: \`${ip}\`\n⟡ OS: *${droplet.image.distribution} ${droplet.image.name}*`,
        { parse_mode: "Markdown" }
      );
    }, 60000);
  }
});
}