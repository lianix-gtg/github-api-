// src/audio.js
// Nyimpen link audio yang diputer pas /start, biar bisa diganti Owner/Dev
// lewat tombol di Dev Panel tanpa harus edit kode / restart bot.

const fs = require("fs");
const path = require("path");

const DB_FILE = path.join(__dirname, "..", "db", "audioUrl.json");

// Default: audio yang dikasih pas request awal.
const DEFAULT_URL = "https://files.catbox.moe/vqd8rt.mp3";

function ensureFile() {
  if (!fs.existsSync(DB_FILE)) {
    fs.writeFileSync(DB_FILE, JSON.stringify({ url: DEFAULT_URL, enabled: true }, null, 2));
  }
}

// enabled:false artinya sengaja dimatikan lewat tombol "Hapus Audio" ->
// /start harus SKIP kirim audio sama sekali, jangan fallback ke DEFAULT_URL.
function getAudioUrl() {
  try {
    ensureFile();
    const data = JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
    if (data.enabled === false) return null;
    return data.url || DEFAULT_URL;
  } catch (e) {
    return DEFAULT_URL;
  }
}

function setAudioUrl(url) {
  const data = { url, enabled: true };
  try {
    ensureFile();
    const current = JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
    if (current.cooldownUntil) data.cooldownUntil = current.cooldownUntil;
  } catch (e) {}
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
  return url;
}

// Matiin audio intro tanpa ngilangin link yang tersimpan, biar gampang
// dinyalain lagi (link lama masih ada, tinggal isEnabled balik true kalau
// nanti Owner set link baru lewat "Tambah Audio").
function disableAudio() {
  let data = { url: DEFAULT_URL };
  try {
    ensureFile();
    data = JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
  } catch (e) {}
  data.enabled = false;
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
}

function isAudioEnabled() {
  try {
    ensureFile();
    const data = JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
    return data.enabled !== false;
  } catch (e) {
    return true;
  }
}

// Telegram kadang balikin 429 "Too Many Requests: retry after N" kalau bot
// kebanyakan request (flood control), bukan cuma buat 1 chat tapi bisa
// se-akun bot. Kalau kejadian, kita simpen "sampai jam berapa harus nunggu"
// biar /start selanjutnya SKIP kirim audio dulu (gak nambahin request baru
// yang bakal 429 lagi juga & bikin cooldown-nya makin lama).
function getCooldownUntil() {
  try {
    ensureFile();
    const data = JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
    return data.cooldownUntil || 0;
  } catch (e) {
    return 0;
  }
}

function setCooldownFromError(errMessage) {
  const match = /retry after (\d+)/i.exec(String(errMessage || ""));
  const retryAfterSec = match ? parseInt(match[1], 10) : 60; // fallback 1 menit kalau format beda
  const until = Date.now() + retryAfterSec * 1000;

  try {
    ensureFile();
    const data = JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
    data.cooldownUntil = until;
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
  } catch (e) {}

  return until;
}

function isOnCooldown() {
  return Date.now() < getCooldownUntil();
}

function getCooldownRemainingSec() {
  const remaining = Math.ceil((getCooldownUntil() - Date.now()) / 1000);
  return remaining > 0 ? remaining : 0;
}

function formatDuration(sec) {
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  const parts = [];
  if (h) parts.push(`${h}j`);
  if (m) parts.push(`${m}m`);
  if (s || parts.length === 0) parts.push(`${s}d`);
  return parts.join(" ");
}

// Validasi simpel: harus http/https, biar Telegram bisa fetch dari server-nya.
function isValidAudioUrl(url) {
  return /^https?:\/\/\S+$/i.test(String(url || "").trim());
}

module.exports = { getAudioUrl, setAudioUrl, disableAudio, isAudioEnabled, isValidAudioUrl, isOnCooldown, setCooldownFromError, getCooldownRemainingSec, formatDuration, DEFAULT_URL };
