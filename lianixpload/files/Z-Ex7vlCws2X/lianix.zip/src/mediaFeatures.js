// src/mediaFeatures.js
// ============================================================
// MEDIA + GAME FEATURES
// Ported from OURIN MD 3 for Telegram.
// Includes: Games, Downloader, ToURL, HD Image, HD Video.
// Semua balasan utama memakai reply_to_message_id (quoted).
// ============================================================

const fs = require("fs");
const path = require("path");
const axios = require("axios");
const https = require("https");
const FormData = require("form-data");
const sharp = require("sharp");
const settings = require("../settings.js");

// ToURL interactive sessions: one UI message per request, no chat spam.
const tourlSessions = new Map();
const TOURL_SESSION_TTL = 10 * 60 * 1000;
function tourlSessionKey(msg) {
  return `${msg?.chat?.id}:${msg?.from?.id || 0}`;
}
function cleanupTourlSession(key) {
  const s = tourlSessions.get(key);
  if (!s) return;
  if (s.timer) clearTimeout(s.timer);
  tourlSessions.delete(key);
}
function saveTourlSession(key, session) {
  cleanupTourlSession(key);
  session.timer = setTimeout(() => cleanupTourlSession(key), TOURL_SESSION_TTL);
  tourlSessions.set(key, session);
}
async function sendBufferFile(bot, method, chatId, buffer, filename, options = {}) {
  if (!Buffer.isBuffer(buffer)) return bot[method](chatId, buffer, options);
  const tmp = path.join(require('os').tmpdir(), `lianix_${Date.now()}_${Math.random().toString(36).slice(2)}_${filename}`);
  await fs.promises.writeFile(tmp, buffer);
  try {
    return await bot[method](chatId, tmp, options);
  } finally {
    fs.promises.unlink(tmp).catch(() => {});
  }
}

/**
 * safeReply — sendMessage with reply_to_message_id fallback.
 */
async function safeReply(bot, chatId, text, opts = {}) {
  try {
    return await bot.sendMessage(chatId, text, opts);
  } catch (err) {
    const desc = String(err?.response?.body?.description || err?.message || '');
    if (/message to be replied not found/i.test(desc) && opts.reply_to_message_id) {
      const { reply_to_message_id: _, ...safeOpts } = opts;
      return await bot.sendMessage(chatId, text, safeOpts);
    }
    throw err;
  }
}


const GAME_DIR = path.join(__dirname, "..", "db", "games");
const sessions = new Map();
const gameTimers = new Map();

const UA = "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/130.0 Mobile Safari/537.36";

function q(msg) {
  return msg?.message_id ? { reply_to_message_id: msg.message_id } : {};
}

function htmlEscape(v) {
  return String(v ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
function makeLoadingBar(percent) {
  const total = 10;
  const filled = Math.max(0, Math.min(total, Math.round((Number(percent) || 0) / 10)));
  return `[${"█".repeat(filled)}${"░".repeat(total - filled)}] ${Math.round(percent || 0)}%`;
}

async function runLoading(bot, chatId, messageId, title, stages, finalTextFactory) {
  let stopped = false;
  for (let i = 0; i < stages.length; i++) {
    const stage = stages[i];
    const pct = Math.round(((i + 1) / stages.length) * 100);
    try {
      await bot.editMessageText(`<b>${htmlEscape(title)}</b>\n\n<code>${makeLoadingBar(pct)}</code>\n${htmlEscape(stage)}`, { chat_id: chatId, message_id: messageId, parse_mode: "HTML", reply_markup: { inline_keyboard: [] } });
    } catch {}
    if (i < stages.length - 1) await sleep(350);
  }
  return finalTextFactory ? finalTextFactory() : null;
}

function formatBytes(bytes) {
  if (!Number.isFinite(bytes)) return "-";
  const units = ["B", "KB", "MB", "GB"];
  let n = bytes;
  let i = 0;
  while (n >= 1024 && i < units.length - 1) {
    n /= 1024;
    i++;
  }
  return `${n.toFixed(n >= 10 || i === 0 ? 0 : 2)} ${units[i]}`;
}

async function downloadBuffer(url, maxBytes = 48 * 1024 * 1024) {
  const res = await axios.get(url, {
    responseType: "arraybuffer",
    timeout: 90000,
    maxContentLength: maxBytes,
    maxBodyLength: maxBytes,
    headers: { "User-Agent": UA },
  });
  const buf = Buffer.from(res.data);
  if (buf.length > maxBytes) throw new Error("File terlalu besar.");
  return buf;
}

// ------------------------------------------------------------
// GAME ENGINE
// ------------------------------------------------------------
const GAME_CONFIG = {
  family100: {
    file: "family100.json",
    title: "FAMILY 100",
    question: "soal",
    answer: "jawaban",
    timeout: 90000,
    aliases: ["f100", "family"],
    description: "Tebak jawaban teratas dari sebuah survei.",
  },
  caklontong: {
    file: "caklontong.json",
    title: "CAK LONTONG",
    question: "soal",
    answer: "jawaban",
    timeout: 90000,
    aliases: ["caklontong", "cak"],
    description: "Tebak jawaban absurd ala Cak Lontong.",
  },
  tekateki: {
    file: "tekateki.json",
    title: "TEKA-TEKI",
    question: "soal",
    answer: "jawaban",
    timeout: 90000,
    aliases: ["teka", "riddle"],
    description: "Jawab teka-teki singkat.",
  },
  tebaktebakan: {
    file: "tebaktebakan.json",
    title: "TEBAK-TEBAKAN",
    question: "soal",
    answer: "jawaban",
    timeout: 90000,
    aliases: ["tebak", "tebakan"],
    description: "Tebak-tebakan santai.",
  },
  asahotak: {
    file: "asahotak.json",
    title: "ASAH OTAK",
    question: "soal",
    answer: "jawaban",
    timeout: 90000,
    aliases: ["asah", "otak"],
    description: "Uji logika dan pengetahuan.",
  },
  tebakepep: {
    file: "tebakepep.json",
    title: "TEBAK EPEP",
    question: null,
    answer: "jawaban",
    timeout: 90000,
    aliases: ["epep", "tebakff"],
    description: "Tebak karakter Free Fire dari gambar.",
    image: "img",
    descriptionField: "deskripsi",
  },
};

function loadGameData(cfg) {
  try {
    const p = path.join(GAME_DIR, cfg.file);
    if (!fs.existsSync(p)) return [];
    const data = JSON.parse(fs.readFileSync(p, "utf8"));
    return Array.isArray(data) ? data : [];
  } catch {
    return [];
  }
}

function normalizeAnswer(v) {
  return String(v ?? "")
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9\s]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

function similarity(a, b) {
  a = normalizeAnswer(a);
  b = normalizeAnswer(b);
  if (!a || !b) return 0;
  if (a === b) return 1;
  if (a.includes(b) || b.includes(a)) return Math.min(a.length, b.length) / Math.max(a.length, b.length);

  const m = a.length, n = b.length;
  const prev = Array(n + 1).fill(0).map((_, i) => i);
  for (let i = 1; i <= m; i++) {
    const cur = [i];
    for (let j = 1; j <= n; j++) {
      cur[j] = a[i - 1] === b[j - 1]
        ? prev[j - 1]
        : 1 + Math.min(prev[j], cur[j - 1], prev[j - 1]);
    }
    for (let j = 0; j <= n; j++) prev[j] = cur[j];
  }
  return (Math.max(m, n) - prev[n]) / Math.max(m, n);
}

function isSurrender(text) {
  return [
    "nyerah", "menyerah", "skip", "lewat", "gatau",
    "ga tau", "gak tau", "nggak tau", "tidak tau", "give up",
  ].includes(normalizeAnswer(text));
}

function getHint(answer, count = 2) {
  const s = String(answer || "");
  let shown = 0;
  return [...s].map((c) => {
    if (c === " ") return " ";
    if (shown++ < count) return c;
    return "_";
  }).join("");
}

function getFamilyAnswers(item) {
  const a = item?.jawaban;
  if (Array.isArray(a)) return a;
  return [a].filter(Boolean);
}

function pick(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function gameMenuText() {
  const rows = Object.entries(GAME_CONFIG).map(([key, cfg]) =>
    `├ <code>/${key}</code> — ${htmlEscape(cfg.description)}`
  );
  return (
    `<b>🎮 GAME CENTER</b>\n\n` +
    `<blockquote expandable>` +
    `<b>Mini Games</b>\n${rows.join("\n")}\n\n` +
    `Balas jawaban langsung ke pesan soal. Ketik <code>nyerah</code> untuk menyerah.` +
    `</blockquote>`
  );
}

async function startGame(bot, msg, gameType) {
  const chatId = msg.chat.id;
  const cfg = GAME_CONFIG[gameType];
  if (!cfg) return;

  if (sessions.has(chatId)) {
    const old = sessions.get(chatId);
    return bot.sendMessage(
      chatId,
      `🎮 <b>Game masih berjalan</b>\n\nJawab soal yang sedang aktif dulu atau ketik <code>nyerah</code>.`,
      { parse_mode: "HTML", ...q(msg) }
    );
  }

  const data = loadGameData(cfg);
  if (!data.length) {
    return bot.sendMessage(chatId, "❌ Data game tidak tersedia.", q(msg));
  }

  const item = pick(data);
  const answers = getFamilyAnswers(item);
  const answerForHint = answers[0] || "";
  let caption =
    `🎮 <b>${cfg.title}</b>\n\n`;

  if (cfg.question) {
    caption += `<blockquote expandable>${htmlEscape(item[cfg.question])}</blockquote>\n`;
  } else {
    caption += `<blockquote expandable>Siapakah karakter pada gambar ini?</blockquote>\n`;
  }

  caption +=
    `💡 <b>Hint:</b> <code>${htmlEscape(getHint(answerForHint, 2))}</code>\n` +
    `⏱ <b>Waktu:</b> ${cfg.timeout / 1000} detik\n` +
    `🎁 <b>Reward:</b> bonus internal game\n\n` +
    `<i>Reply pesan ini dengan jawabanmu.</i>`;

  let sent;
  if (cfg.image && item[cfg.image]) {
    try {
      sent = await bot.sendPhoto(
        chatId,
        item[cfg.image],
        { caption, parse_mode: "HTML", ...q(msg) }
      );
    } catch {
      // fallback ke teks jika gambar eksternal sedang mati
      sent = await bot.sendMessage(chatId, caption, { parse_mode: "HTML", ...q(msg) });
    }
  } else {
    sent = await bot.sendMessage(chatId, caption, { parse_mode: "HTML", ...q(msg) });
  }

  const session = {
    gameType,
    answers: answers.map(normalizeAnswer).filter(Boolean),
    answerDisplay: answers.join(" / "),
    messageId: sent.message_id,
    startedAt: Date.now(),
  };
  sessions.set(chatId, session);

  const timer = setTimeout(async () => {
    const active = sessions.get(chatId);
    if (!active || active.messageId !== sent.message_id) return;
    sessions.delete(chatId);
    gameTimers.delete(chatId);

    await safeReply(bot, 
      chatId,
      `⌛ <b>WAKTU HABIS</b>\n\nJawaban: <code>${htmlEscape(active.answerDisplay)}</code>`,
      { parse_mode: "HTML", reply_to_message_id: sent.message_id }
    ).catch(() => {});
  }, cfg.timeout);

  gameTimers.set(chatId, timer);
}

async function handleGameAnswer(bot, msg) {
  const chatId = msg.chat.id;
  const session = sessions.get(chatId);
  if (!session || !msg.text || msg.text.startsWith("/")) return false;

  const answer = msg.text.trim();
  if (!answer) return false;

  if (isSurrender(answer)) {
    clearGame(chatId);
    await bot.sendMessage(
      chatId,
      `🏳 <b>MENYERAH</b>\n\nJawabannya: <code>${htmlEscape(session.answerDisplay)}</code>`,
      { parse_mode: "HTML", ...q(msg) }
    );
    return true;
  }

  // Hanya terima reply ke pesan game supaya obrolan grup tidak ikut dianggap jawaban.
  if (!msg.reply_to_message || msg.reply_to_message.message_id !== session.messageId) {
    return false;
  }

  const normalized = normalizeAnswer(answer);
  const exact = session.answers.includes(normalized);
  const close = session.answers.some((a) => similarity(a, normalized) >= 0.88);

  if (exact || close) {
    clearGame(chatId);
    await bot.sendMessage(
      chatId,
      `🎉 <b>JAWABAN BENAR!</b>\n\n` +
      `👤 ${htmlEscape(msg.from?.first_name || "Player")}\n` +
      `✅ Jawaban: <code>${htmlEscape(session.answerDisplay)}</code>\n` +
      `🏆 Mantap!`,
      { parse_mode: "HTML", ...q(msg) }
    );
    return true;
  }

  await bot.sendMessage(
    chatId,
    `❌ Belum benar. Coba lagi!\n💡 <code>${htmlEscape(getHint(session.answerDisplay.split(" / ")[0], 3))}</code>`,
    { parse_mode: "HTML", ...q(msg) }
  );
  return true;
}

function clearGame(chatId) {
  if (gameTimers.has(chatId)) clearTimeout(gameTimers.get(chatId));
  gameTimers.delete(chatId);
  sessions.delete(chatId);
}

// ------------------------------------------------------------
// DOWNLOADER
// ------------------------------------------------------------
async function tikwm(url) {
  const { data } = await axios.post(
    "https://www.tikwm.com/api/",
    {},
    {
      params: { url, count: 12, cursor: 0, web: 1, hd: 1 },
      headers: {
        Accept: "application/json",
        "User-Agent": UA,
        Origin: "https://www.tikwm.com",
        Referer: "https://www.tikwm.com/",
      },
      timeout: 60000,
    }
  );
  const r = data?.data;
  if (!r) throw new Error(data?.msg || "TikTok gagal mengambil data");
  return {
    title: r.title || "TikTok",
    video: r.hdplay ? `https://www.tikwm.com${r.hdplay}` :
      r.play ? `https://www.tikwm.com${r.play}` : null,
    images: Array.isArray(r.images) ? r.images : [],
    audio: r.music ? `https://www.tikwm.com${r.music}` : null,
  };
}

async function youtube(url) {
  const currentTs = Date.now().toString();
  const salt = "384d5028ee4a399f6cae0175025a1708aa924fc0ccb08be1aa359cd856dd1639";
  const signature = require("crypto").createHash("sha256")
    .update(url + currentTs + salt).digest("hex");

  const body = new URLSearchParams({
    sf_url: url,
    ts: currentTs,
    _ts: "1765962059039",
    _tsc: "0",
    _s: signature,
  }).toString();

  const { data } = await axios.post("https://ssyoutube.com/api/convert", body, {
    headers: {
      "User-Agent": UA,
      Accept: "application/json, text/plain, */*",
      "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
      Origin: "https://ssyoutube.com",
      Referer: "https://ssyoutube.com/",
    },
    timeout: 90000,
  });

  if (!data?.url) throw new Error("YouTube tidak mengembalikan link download.");
  const arr = Array.isArray(data.url) ? data.url : [];
  const video = arr.find((x) => !x.no_audio && /mp4/i.test(x.ext || "") && ["720", "480", "360"].includes(String(x.quality))) ||
    arr.find((x) => !x.no_audio && /mp4/i.test(x.ext || "")) ||
    arr.find((x) => !x.no_audio);
  if (!video?.url) throw new Error("Video YouTube tidak tersedia.");
  return { title: data.meta?.title || "YouTube", video: video.url, thumbnail: data.thumb };
}

async function instagram(url) {
  const cleanUrl = url.split("?")[0].replace(/\/?$/, "/");
  const home = await axios.get("https://fastdl.app/id", {
    headers: { "User-Agent": UA },
    timeout: 30000,
  });
  const cookie = Array.isArray(home.headers["set-cookie"])
    ? home.headers["set-cookie"].map((c) => c.split(";")[0]).join("; ")
    : "";

  const msec = await axios.get("https://fastdl.app/msec", {
    headers: { "User-Agent": UA, Cookie: cookie },
    timeout: 30000,
  });
  const ts = Math.floor(Number(msec.data.msec) * 1000) - 450;
  const key = Buffer.from("34ac9a1aa6aaa7d69a7075611898f16a85d496b1d8f1c7aaa5640a2d93d7af80", "hex");
  const crypto = require("crypto");
  const signature = crypto.createHmac("sha256", key).update(cleanUrl + ts).digest("hex");

  const params = new URLSearchParams();
  params.append("sf_url", cleanUrl);
  params.append("ts", String(ts));
  params.append("_ts", "1770240123231");
  params.append("_tsc", "0");
  params.append("_sv", "2");
  params.append("_s", signature);

  const { data } = await axios.post("https://api-wh.fastdl.app/api/convert", params.toString(), {
    headers: {
      "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
      "User-Agent": UA,
      Origin: "https://fastdl.app",
      Referer: "https://fastdl.app/id",
      Cookie: cookie,
    },
    timeout: 90000,
  });

  const result = data?.[0] || data?.result?.[0] || data;
  const media = [];
  const collect = (obj) => {
    if (Array.isArray(obj)) {
      for (const x of obj) collect(x);
      return;
    }
    if (!obj || typeof obj !== "object") return;
    if (obj.url) media.push({ type: obj.type || "video", url: obj.url });
    if (obj.url_wrapped) media.push({ type: obj.type || "video", url: obj.url_wrapped });
    if (obj.hd) media.push({ type: "video", url: obj.hd });
    if (obj.sd) media.push({ type: "video", url: obj.sd });
    if (obj.urls) collect(obj.urls);
  };
  collect(result);
  const unique = [];
  const seen = new Set();
  for (const item of media) {
    if (!item.url || seen.has(item.url)) continue;
    seen.add(item.url);
    unique.push(item);
  }
  if (!unique.length) throw new Error("Media Instagram tidak ditemukan.");
  return unique;
}

async function mediafire(url) {
  const { data: html } = await axios.get(url, {
    timeout: 60000,
    headers: { "User-Agent": UA },
  });
  const match = html.match(/id=["']downloadButton["'][^>]*href=["']([^"']+)/i) ||
    html.match(/aria-label=["']Download file["'][^>]*href=["']([^"']+)/i);
  if (!match?.[1]) throw new Error("Link MediaFire tidak ditemukan.");
  const title = (html.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1] || "MediaFire File")
    .replace(/\s+/g, " ").trim();
  return { title, url: match[1].replace(/&amp;/g, "&") };
}

async function downloadAny(bot, msg, url) {
  const lower = url.toLowerCase();
  if (/tiktok\.com/i.test(lower)) {
    const r = await tikwm(url);
    if (r.images.length) {
      for (const image of r.images.slice(0, 10)) {
        await bot.sendPhoto(msg.chat.id, image, {
          caption: `📸 <b>TIKTOK PHOTO</b>\n\n${htmlEscape(r.title)}`,
          parse_mode: "HTML",
          ...q(msg),
        });
      }
    } else if (r.video) {
      await bot.sendVideo(msg.chat.id, r.video, {
        caption: `🎬 <b>TIKTOK DOWNLOADER</b>\n\n${htmlEscape(r.title)}`,
        parse_mode: "HTML",
        ...q(msg),
      });
    } else {
      throw new Error("Video TikTok tidak tersedia.");
    }
    return;
  }

  if (/youtube\.com|youtu\.be/i.test(lower)) {
    const r = await youtube(url);
    await bot.sendVideo(msg.chat.id, r.video, {
      caption: `▶️ <b>YOUTUBE DOWNLOADER</b>\n\n${htmlEscape(r.title)}`,
      parse_mode: "HTML",
      ...q(msg),
    });
    return;
  }

  if (/instagram\.com/i.test(lower)) {
    const media = await instagram(url);
    for (const item of media.slice(0, 10)) {
      const type = String(item.type).toLowerCase();
      if (type.includes("image") || type.includes("photo") || /\.(jpg|jpeg|png|webp)(\?|$)/i.test(item.url)) {
        await bot.sendPhoto(msg.chat.id, item.url, { ...q(msg) });
      } else {
        await bot.sendVideo(msg.chat.id, item.url, { ...q(msg) });
      }
    }
    return;
  }

  if (/mediafire\.com/i.test(lower)) {
    const r = await mediafire(url);
    await bot.sendDocument(msg.chat.id, r.url, {
      caption: `📦 <b>MEDIAFIRE</b>\n\n${htmlEscape(r.title)}`,
      parse_mode: "HTML",
      ...q(msg),
    });
    return;
  }

  // Optional btch-downloader support for Facebook / CapCut.
  if (/facebook\.com|fb\.watch/i.test(lower)) {
    try {
      const mod = await import("btch-downloader");
      const fn = mod.fbdown || mod.default?.fbdown;
      if (!fn) throw new Error("Facebook downloader tidak tersedia.");
      const r = await fn(url);
      const video = r?.HD || r?.Normal_video;
      if (!video) throw new Error("Video Facebook tidak ditemukan.");
      await bot.sendVideo(msg.chat.id, video, { caption: "📘 <b>FACEBOOK DOWNLOADER</b>", parse_mode: "HTML", ...q(msg) });
      return;
    } catch (e) {
      throw new Error(`Facebook: ${e.message}`);
    }
  }

  if (/capcut\.com/i.test(lower)) {
    try {
      const mod = await import("btch-downloader");
      const fn = mod.capcut || mod.default?.capcut;
      if (!fn) throw new Error("CapCut downloader tidak tersedia.");
      const r = await fn(url);
      const video = r?.originalVideoUrl;
      if (!video) throw new Error("Video CapCut tidak ditemukan.");
      await bot.sendVideo(msg.chat.id, video, { caption: "✂️ <b>CAPCUT DOWNLOADER</b>", parse_mode: "HTML", ...q(msg) });
      return;
    } catch (e) {
      throw new Error(`CapCut: ${e.message}`);
    }
  }

  throw new Error("Platform belum didukung. Coba TikTok, YouTube, Instagram, Facebook, CapCut, atau MediaFire.");
}

// ------------------------------------------------------------
// TO URL
// ------------------------------------------------------------
function normalizeUploadUrl(raw) {
  const text = String(raw ?? "").trim().replace(/^['"]|['"]$/g, "");
  const match = text.match(/https?:\/\/[^\s"'<>]+/i);
  return match ? match[0].replace(/[),.;]+$/, "") : "";
}

async function extractUploadUrl(data) {
  const seen = new Set();
  const queue = [data];
  while (queue.length) {
    const value = queue.shift();
    if (value == null) continue;
    if (typeof value === "string") {
      const url = normalizeUploadUrl(value);
      if (url) return url;
      try {
        const parsed = JSON.parse(value);
        queue.push(parsed);
      } catch {}
      continue;
    }
    if (typeof value !== "object" || seen.has(value)) continue;
    seen.add(value);
    const preferred = ["url", "link", "file", "fileUrl", "file_url", "download", "downloadUrl", "download_url", "result", "data"];
    for (const key of preferred) if (Object.prototype.hasOwnProperty.call(value, key)) queue.unshift(value[key]);
    for (const v of Object.values(value)) queue.push(v);
  }
  return "";
}

async function uploadLianixUniversal(buffer, filename) {
  if (!Buffer.isBuffer(buffer) || !buffer.length) throw new Error("Media kosong.");
  const endpoint = String(process.env.LIANIX_UPLOAD_URL || "https://f24ntai-ai.biz.id/api/upload").trim();
  const apiKey = String(process.env.LIANIX_UPLOAD_API_KEY || "lianix").trim();
  const form = new FormData();
  form.append("file", buffer, {
    filename: path.basename(filename || `lianix_${Date.now()}`),
    contentType: "application/octet-stream",
    knownLength: buffer.length,
  });
  const res = await axios.post(endpoint, form, {
    headers: { ...form.getHeaders(), "X-API-Key": apiKey, "User-Agent": "Lianix-Uploader/2.0", Accept: "application/json,text/plain,*/*" },
    timeout: 60000,
    maxBodyLength: Infinity,
    maxContentLength: Infinity,
    validateStatus: () => true,
  });
  const url = await extractUploadUrl(res.data);
  if (res.status < 200 || res.status >= 300 || !url) {
    const raw = typeof res.data === "string" ? res.data : JSON.stringify(res.data);
    throw new Error(`Lianix Upload HTTP ${res.status}: ${String(raw || "response kosong").slice(0, 240)}`);
  }
  return { url, host: "Lianix Upload", transport: "api-fallback" };
}

async function uploadCatbox(buffer, filename) {
  if (!Buffer.isBuffer(buffer) || buffer.length === 0) throw new Error("Media kosong atau gagal dibaca.");
  if (buffer.length > 200 * 1024 * 1024) throw new Error("Catbox membatasi upload maksimal 200MB.");

  const safeName = path.basename(filename || `lianix_${Date.now()}`).replace(/[\r\n"]/g, "_");
  const configuredUserhash = String(process.env.CATBOX_USERHASH || "").trim();
  const endpoint = "https://catbox.moe/user/api.php";
  const errors = [];
  const mkAgent = family => new https.Agent({ keepAlive: false, ...(family ? { family } : {}) });

  // Jika userhash salah, anonymous upload masih boleh berhasil. Karena itu anonymous
  // dicoba tepat setelah request ber-userhash. Bila Catbox juga menolak anonymous
  // dengan 412 Invalid uploader, hentikan retry Catbox dan langsung pindah fallback.
  const attempts = [];
  if (configuredUserhash) attempts.push({ label: "IPv4-userhash", agent: mkAgent(4), userhash: configuredUserhash });
  attempts.push({ label: "IPv4-anonymous", agent: mkAgent(4), userhash: "" });
  if (configuredUserhash) attempts.push({ label: "default-userhash", agent: mkAgent(), userhash: configuredUserhash });
  attempts.push({ label: "default-anonymous", agent: mkAgent(), userhash: "" });

  let catboxHardRejected = false;
  for (const attempt of attempts) {
    try {
      const form = new FormData();
      form.append("reqtype", "fileupload");
      if (attempt.userhash) form.append("userhash", attempt.userhash);
      form.append("fileToUpload", buffer, {
        filename: safeName,
        contentType: "application/octet-stream",
        knownLength: buffer.length,
      });
      const headers = { ...form.getHeaders(), "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) Lianix/2.1", Accept: "text/plain,*/*" };
      try { const len = form.getLengthSync(); if (Number.isFinite(len) && len > 0) headers["Content-Length"] = String(len); } catch {}
      const res = await axios.post(endpoint, form, {
        headers,
        httpsAgent: attempt.agent,
        timeout: 45000,
        responseType: "text",
        maxBodyLength: Infinity,
        maxContentLength: Infinity,
        validateStatus: () => true,
        transitional: { clarifyTimeoutError: true },
      });
      const raw = String(res.data ?? "").trim();
      const url = normalizeUploadUrl(raw);
      if (res.status >= 200 && res.status < 300 && /^https:\/\/files\.catbox\.moe\/[A-Za-z0-9._~-]+$/i.test(url)) {
        return { url, host: "Catbox", transport: attempt.label };
      }
      errors.push(`${attempt.label} HTTP ${res.status}: ${(raw || "response kosong").slice(0, 220)}`);
      if (res.status === 412 && /invalid uploader/i.test(raw) && !attempt.userhash) {
        catboxHardRejected = true;
        break;
      }
    } catch (e) {
      const code = String(e?.code || "").toUpperCase();
      let hint = "";
      if (["ENOTFOUND", "EAI_AGAIN"].includes(code)) hint = " [DNS VPS gagal resolve catbox.moe]";
      else if (["ETIMEDOUT", "ECONNABORTED"].includes(code)) hint = " [koneksi/upload ke Catbox timeout]";
      else if (["ECONNRESET", "EPIPE"].includes(code)) hint = " [koneksi Catbox di-reset di tengah upload]";
      else if (["ECONNREFUSED", "EHOSTUNREACH", "ENETUNREACH"].includes(code)) hint = " [route/firewall VPS ke Catbox bermasalah]";
      errors.push(`${attempt.label}: ${String(e?.message || e).slice(0, 180)}${code ? ` (${code})` : ""}${hint}`);
    }
  }

  // Transport kedua memakai undici/Web FormData. Ini sengaja berbeda dari
  // axios + form-data agar Catbox tetap punya kesempatan jika edge mereka
  // menolak encoding multipart dari library form-data tertentu.
  try {
    const { fetch: uFetch, FormData: UFormData, File: UFile } = require("undici");
    const uf = new UFormData();
    uf.set("reqtype", "fileupload");
    if (configuredUserhash) uf.set("userhash", configuredUserhash);
    uf.set("fileToUpload", new UFile([buffer], safeName, { type: "application/octet-stream" }));
    const ctl = new AbortController();
    const tt = setTimeout(() => ctl.abort(), 45000);
    let ur;
    try {
      ur = await uFetch(endpoint, {
        method: "POST", body: uf, signal: ctl.signal,
        headers: { "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/120 Safari/537.36", "Accept": "text/plain,*/*" }
      });
    } finally { clearTimeout(tt); }
    const raw = String(await ur.text()).trim();
    const url = normalizeUploadUrl(raw);
    if (ur.ok && /^https:\/\/files\.catbox\.moe\/[A-Za-z0-9._~-]+$/i.test(url)) {
      return { url, host: "Catbox", transport: "undici-webform" };
    }
    errors.push(`undici-webform HTTP ${ur.status}: ${(raw || "response kosong").slice(0,220)}`);
  } catch (e) {
    errors.push(`undici-webform: ${String(e?.message || e).slice(0,220)}`);
  }

  // Transport ketiga: curl multipart, mengikuti contoh resmi Catbox persis.
  // Berguna bila edge Catbox menolak multipart dari library Node tertentu.
  try {
    const os = require("os");
    const { execFile } = require("child_process");
    const tmp = path.join(os.tmpdir(), `lianix_catbox_${Date.now()}_${Math.random().toString(36).slice(2)}_${safeName}`);
    await fs.promises.writeFile(tmp, buffer);
    try {
      const args = ["--fail-with-body", "--silent", "--show-error", "--max-time", "55", "-F", "reqtype=fileupload"];
      if (configuredUserhash) args.push("-F", `userhash=${configuredUserhash}`);
      args.push("-F", `fileToUpload=@${tmp}`, endpoint);
      const raw = await new Promise((resolve, reject) => execFile("curl", args, { timeout: 60000, maxBuffer: 1024 * 1024 }, (err, stdout, stderr) => err ? reject(new Error(String(stderr || stdout || err.message).trim())) : resolve(String(stdout || "").trim())));
      const url = normalizeUploadUrl(raw);
      if (/^https:\/\/files\.catbox\.moe\/[A-Za-z0-9._~-]+$/i.test(url)) return { url, host:"Catbox", transport:"curl-official-form" };
      errors.push(`curl-official-form: ${(raw || "response kosong").slice(0,220)}`);
    } finally { await fs.promises.unlink(tmp).catch(()=>{}); }
  } catch (e) {
    errors.push(`curl-official-form: ${String(e?.message || e).slice(0,220)}`);
  }

  try {
    const fallback = await uploadLianixUniversal(buffer, safeName);
    return { ...fallback, catboxFallback: true, catboxHardRejected, catboxError: [...new Set(errors)].slice(-4).join(" | ") };
  } catch (fallbackErr) {
    const unique = [...new Set(errors)].slice(-5);
    throw new Error(`Catbox gagal. ${unique.join(" | ") || "Tidak ada respons."} | Fallback upload gagal: ${String(fallbackErr?.message || fallbackErr).slice(0, 300)}`);
  }
}

async function uploadUguu(buffer, filename) {
  if (!Buffer.isBuffer(buffer) || !buffer.length) throw new Error("Media kosong.");
  const form = new FormData();
  form.append("files[]", buffer, { filename: path.basename(filename || `lianix_${Date.now()}`), knownLength: buffer.length });
  const res = await axios.post("https://uguu.se/upload.php", form, {
    headers: { ...form.getHeaders(), "User-Agent": "Mozilla/5.0 Lianix/1.0", Accept: "application/json" },
    timeout: 18000, maxBodyLength: Infinity, maxContentLength: Infinity, validateStatus: () => true
  });
  const url = normalizeUploadUrl(res.data?.files?.[0]?.url || res.data?.url || res.data);
  if (res.status < 200 || res.status >= 300 || !url) throw new Error(`Uguu HTTP ${res.status}: ${String(typeof res.data === "string" ? res.data : JSON.stringify(res.data)).slice(0, 240)}`);
  return { url, host: "Uguu" };
}

async function uploadTmpfiles(buffer, filename) {
  if (!Buffer.isBuffer(buffer) || !buffer.length) throw new Error("Media kosong.");
  const form = new FormData();
  form.append("file", buffer, { filename: path.basename(filename || `lianix_${Date.now()}`), knownLength: buffer.length });
  const res = await axios.post("https://tmpfiles.org/api/v1/upload", form, {
    headers: { ...form.getHeaders(), "User-Agent": "Mozilla/5.0 Lianix/1.0", Accept: "application/json" },
    timeout: 18000, maxBodyLength: Infinity, maxContentLength: Infinity, validateStatus: () => true
  });
  let url = normalizeUploadUrl(res.data?.data?.url || res.data?.url);
  if (url) url = url.replace(/^https?:\/\/tmpfiles\.org\/(?!dl\/)/i, "https://tmpfiles.org/dl/");
  if (res.status < 200 || res.status >= 300 || !url) throw new Error(`TmpFiles HTTP ${res.status}: ${String(typeof res.data === "string" ? res.data : JSON.stringify(res.data)).slice(0, 240)}`);
  return { url, host: "TmpFiles" };
}

function generateVisitorId() {
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = Math.random() * 16 | 0;
    return (c === "x" ? r : r & 3 | 8).toString(16);
  });
}

function videyVideoExtension(filename = "") {
  const ext = path.extname(filename).toLowerCase();
  return ext === '.webm' ? 'webm' : (ext === '.mov' || ext === '.m4v' ? 'quicktime' : 'mp4');
}

async function uploadVidey(buffer, filename) {
  const ext = path.extname(filename).toLowerCase();
  if (!buffer || ![".mp4", ".mov", ".m4v", ".webm"].includes(ext)) {
    throw new Error("Videy hanya menerima video MP4/MOV/M4V/WEBM.");
  }
  // Gunakan multipart request native seperti implementasi Videy yang stabil.
  const boundary = "----FormBoundary" + Math.random().toString(36).slice(2);
  const contentType = ext === ".webm" ? "video/webm" : (ext === ".mov" || ext === ".m4v" ? "video/quicktime" : "video/mp4");
  const safeName = path.basename(filename).replace(/[\"\r\n]/g, "_");
  const body = Buffer.concat([
    Buffer.from(`--${boundary}\r\n`),
    Buffer.from(`Content-Disposition: form-data; name="file"; filename="${safeName}"\r\n`),
    Buffer.from(`Content-Type: ${contentType}\r\n\r\n`),
    buffer,
    Buffer.from(`\r\n--${boundary}--\r\n`)
  ]);
  const visitorId = generateVisitorId();
  const result = await new Promise((resolve, reject) => {
    const req = require("https").request({
      hostname: "videy.co",
      path: `/api/upload?visitorId=${encodeURIComponent(visitorId)}`,
      method: "POST",
      headers: {
        "Content-Type": `multipart/form-data; boundary=${boundary}`,
        "Content-Length": body.length,
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Origin": "https://videy.co",
        "Referer": "https://videy.co/"
      },
      timeout: 120000
    }, res => {
      let raw = "";
      res.setEncoding("utf8");
      res.on("data", c => raw += c);
      res.on("end", () => {
        let json;
        try { json = JSON.parse(raw); } catch { return reject(new Error(`Videy response tidak valid (HTTP ${res.statusCode}).`)); }
        if (res.statusCode !== 200 || !json?.id) return reject(new Error(json?.error || `Videy upload gagal (HTTP ${res.statusCode}).`));
        resolve(json);
      });
    });
    req.on("timeout", () => req.destroy(new Error("Videy timeout setelah 120 detik.")));
    req.on("error", reject);
    req.write(body);
    req.end();
  });
  const videoExt = ext === ".webm" ? "webm" : (ext === ".mov" || ext === ".m4v" ? "mov" : "mp4");
  const pageUrl = result.link || `https://videy.co/v?id=${result.id}`;
  const directUrl = result.cdnUrl || `https://cdn.videy.co/${result.id}.${videoExt}`;
  return { url: pageUrl, host: "Videy", directUrl, videoId: result.id };
}

const TOURL_UPLOADERS = {
  catbox: ["Catbox", uploadCatbox],
  f24nt: ["F24nT Upload", uploadLianixUniversal],
  uguu: ["Uguu", uploadUguu],
  tmpfiles: ["TmpFiles", uploadTmpfiles],
  videy: ["Videy", uploadVidey],
};

async function withHardTimeout(promise, ms, label) {
  let timer;
  try {
    return await Promise.race([
      promise,
      new Promise((_, reject) => { timer = setTimeout(() => reject(new Error(`${label} timeout setelah ${Math.round(ms/1000)} detik.`)), ms); })
    ]);
  } finally { if (timer) clearTimeout(timer); }
}

async function uploadToUrl(buffer, filename, platform = "auto", onAttempt = null) {
  // Catbox menjadi provider utama untuk mode auto.
  // Jika user memilih Catbox secara eksplisit, JANGAN fallback ke provider lain:
  // hasil harus Catbox atau error Catbox yang diagnostik.
  const order = platform === "auto"
    ? ["catbox", "uguu", "tmpfiles"]
    : platform === "catbox" ? ["catbox"]
    : platform === "f24nt" ? ["f24nt"]
    : platform === "uguu" ? ["uguu"]
    : platform === "tmpfiles" ? ["tmpfiles"]
    : platform === "videy" ? ["videy"] : [];
  if (!order.length) throw new Error("Platform ToURL tidak dikenal.");

  const requestedKey = order[0];
  const requestedName = TOURL_UPLOADERS[requestedKey]?.[0] || requestedKey;
  const errors = [];

  const runUploader = async (key, index) => {
    const entry = TOURL_UPLOADERS[key];
    if (!entry) throw new Error(`${key}: uploader tidak tersedia`);
    if (typeof onAttempt === "function") {
      try { await onAttempt({ key, name: entry[0], index, total: order.length }); } catch {}
    }
    try {
      const maxMs = key === "videy" ? 120000 : key === "catbox" ? 100000 : 30000;
      const result = await withHardTimeout(entry[1](buffer, filename), maxMs, entry[0]);
      if (!result?.url || !/^https?:\/\//i.test(String(result.url))) throw new Error("Uploader tidak mengembalikan URL valid.");
      return { ...result, key };
    } catch (e) {
      const msg = `${entry[0]}: ${String(e?.message || e).slice(0, 900)}`;
      errors.push(msg);
      throw new Error(msg);
    }
  };

  // Explicit provider = strict. Tidak pernah diam-diam mengganti host.
  if (platform !== "auto") {
    const result = await runUploader(requestedKey, 0);
    return { ...result, requestedHost: requestedName, fallback: false, fallbackReason: "" };
  }

  // AUTO: Catbox tetap mendapat kesempatan nyata terlebih dahulu. Hanya jika Catbox
  // benar-benar gagal/timeout, baru provider berikutnya digunakan.
  try {
    const result = await runUploader("catbox", 0);
    return { ...result, requestedHost: "Catbox", fallback: false, fallbackReason: "" };
  } catch (catboxError) {
    for (let i = 1; i < order.length; i++) {
      const key = order[i];
      try {
        const result = await runUploader(key, i);
        return {
          ...result,
          requestedHost: "Catbox",
          fallback: true,
          fallbackReason: `Catbox gagal: ${String(catboxError?.message || catboxError).slice(0, 420)}`,
        };
      } catch {}
    }
  }

  throw new Error(errors.join("\n") || "Semua uploader gagal.");
}

async function getTelegramMedia(msg, bot) {
  const target = msg.reply_to_message || msg;
  const fileId =
    target.photo?.[target.photo.length - 1]?.file_id ||
    target.video?.file_id ||
    target.document?.file_id ||
    target.audio?.file_id ||
    target.voice?.file_id;

  if (!fileId) throw new Error("Balas/kirim foto, video, audio, atau file.");

  const file = await bot.getFile(fileId);
  if (!file?.file_path) throw new Error("Telegram tidak memberikan file_path untuk media tersebut.");

  // getFileLink memakai mekanisme resmi library dan lebih aman terhadap perubahan URL.
  let url;
  try {
    if (typeof bot.getFileLink === "function") url = await bot.getFileLink(fileId);
  } catch {}
  if (!url) url = `https://api.telegram.org/file/bot${settings.token}/${file.file_path}`;

  const buffer = await downloadBuffer(url, 100 * 1024 * 1024);
  if (!buffer.length) throw new Error("Media dari Telegram kosong.");

  const filename =
    target.document?.file_name ||
    target.audio?.file_name ||
    target.video?.file_name ||
    target.voice?.file_name ||
    path.basename(file.file_path) ||
    `media_${Date.now()}`;

  return { buffer, filename };
}

async function handleTourl(bot, msg) {
  const key = tourlSessionKey(msg);
  try {
    const { buffer, filename } = await getTelegramMedia(msg, bot);
    const target = msg.reply_to_message || msg;
    const isVideo = /\.(mp4|mov|m4v|webm)$/i.test(filename) || /^video\//i.test(target.document?.mime_type || "") || !!(target.video);

    const text =
      `🔗 <b>TOURL</b>\n\n` +
      `<blockquote expandable>Media siap di-upload.\n` +
      `Ukuran: <code>${formatBytes(buffer.length)}</code>\n` +
      `Pilih platform URL di bawah.</blockquote>`;
    const rows = [
      [{ text: "🗃 Catbox", callback_data: "tourl:catbox" }, { text: "🚀 F24nT", callback_data: "tourl:f24nt" }],
      [{ text: "☁ Uguu", callback_data: "tourl:uguu" }, { text: "📦 TmpFiles", callback_data: "tourl:tmpfiles" }],
    ];
    // Videy selalu ditampilkan di picker; callback akan menolak non-video dengan pesan yang jelas.
    rows.push([{ text: "🎬 Videy", callback_data: "tourl:videy" }]);
    rows.push([{ text: "✕ Batal", callback_data: "tourl:cancel" }]);

    const sent = await bot.sendMessage(msg.chat.id, text, {
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: rows },
      ...q(msg)
    });
    saveTourlSession(key, {
      chatId: msg.chat.id,
      messageId: sent.message_id,
      buffer,
      filename,
      isVideo,
    });
  } catch (e) {
    await bot.sendMessage(msg.chat.id, `❌ <b>TOURL GAGAL</b>\n\n${htmlEscape(e.message)}`, { parse_mode: "HTML", ...q(msg) }).catch(() => {});
  }
}


// ------------------------------------------------------------
// HD IMAGE / VIDEO
// ------------------------------------------------------------
async function handleHdImage(bot, msg) {
  try {
    const { buffer, filename } = await getTelegramMedia(msg, bot);
    const isImage = msg.reply_to_message?.photo || msg.reply_to_message?.document?.mime_type?.startsWith("image/") || msg.photo || msg.document?.mime_type?.startsWith("image/");
    if (!isImage) throw new Error("Balas/kirim foto untuk fitur HD Foto.");

    await bot.sendMessage(msg.chat.id, "🕕 <b>HD FOTO</b>\n\nSedang meningkatkan kualitas gambar...", {
      parse_mode: "HTML", ...q(msg)
    });

    let result;
    try {
      const url = await uploadCatbox(buffer, filename.replace(/\.[^.]+$/, ".jpg"));
      const { data } = await axios.get(
        `https://api-faa.my.id/faa/hdv4?image=${encodeURIComponent(url)}`,
        { timeout: 120000 }
      );
      result = data?.result?.image_upscaled;
    } catch {}

    if (result) {
      await bot.sendPhoto(msg.chat.id, result, {
        caption: "✨ <b>HD FOTO SELESAI</b>\n\nGambar berhasil di-enhance.",
        parse_mode: "HTML", ...q(msg)
      });
      return;
    }

    // Fallback lokal: upscale 2x + sharpening. Bukan AI, tapi membuat fitur tetap usable.
    const out = await sharp(buffer)
      .resize({ width: 2400, height: 2400, fit: "inside", withoutEnlargement: false, kernel: sharp.kernel.lanczos3 })
      .sharpen()
      .jpeg({ quality: 92 })
      .toBuffer();

    await bot.sendPhoto(msg.chat.id, out, {
      caption: "✨ <b>HD FOTO SELESAI</b>\n\nAI enhancer sedang tidak tersedia, jadi dipakai fallback sharpening lokal.",
      parse_mode: "HTML", ...q(msg)
    });
  } catch (e) {
    await bot.sendMessage(msg.chat.id, `❌ <b>HD FOTO GAGAL</b>\n\n${htmlEscape(e.message)}`, {
      parse_mode: "HTML", ...q(msg)
    });
  }
}

async function handleHdVideo(bot, msg) {
  let tempPath = null;
  try {
    const { buffer, filename } = await getTelegramMedia(msg, bot);
    const isVideo = msg.reply_to_message?.video ||
      msg.reply_to_message?.document?.mime_type?.startsWith("video/") ||
      msg.video ||
      msg.document?.mime_type?.startsWith("video/");
    if (!isVideo) throw new Error("Balas/kirim video untuk fitur HD Video.");
    if (buffer.length > 20 * 1024 * 1024) throw new Error("Ukuran video maksimal 20MB pada Bot API standar.");

    await bot.sendMessage(msg.chat.id, "🎬 <b>HD VIDEO</b>\n\nVideo sedang diproses. Jangan kirim ulang sampai selesai.", {
      parse_mode: "HTML", ...q(msg)
    });

    const form = new FormData();
    form.append("file", buffer, { filename: filename.endsWith(".mp4") ? filename : `video-${Date.now()}.mp4` });

    const apiKey = process.env.HD_VIDEO_APIKEY || "fgsiapi-20c1605c-6d";
    const { data } = await axios.post(
      "https://fgsi.dpdns.org/api/tools/enchantVideo",
      form,
      {
        headers: { ...form.getHeaders(), apikey: apiKey },
        maxBodyLength: Infinity,
        maxContentLength: Infinity,
        timeout: 120000,
      }
    );

    const pollUrl = data?.data?.pollUrl;
    if (!data?.status || !pollUrl) throw new Error(data?.message || "Task HD video gagal dibuat.");

    const started = Date.now();
    let resultUrl = null;
    while (Date.now() - started < 10 * 60 * 1000) {
      await sleep(3000);
      const poll = await axios.get(pollUrl, { headers: { apikey: apiKey }, timeout: 30000 });
      const status = String(poll.data?.data?.status || "").toLowerCase();

      if (status === "success") {
        resultUrl = poll.data?.data?.result?.res_url;
        break;
      }
      if (["failed", "error", "cancelled", "canceled"].includes(status)) {
        throw new Error(poll.data?.message || "Proses HD video gagal.");
      }
    }

    if (!resultUrl) throw new Error("Timeout menunggu hasil HD video.");

    await bot.sendVideo(msg.chat.id, resultUrl, {
      caption: "✨ <b>HD VIDEO SELESAI</b>\n\nVideo berhasil ditingkatkan kualitasnya.",
      parse_mode: "HTML",
      supports_streaming: true,
      ...q(msg),
    });
  } catch (e) {
    await bot.sendMessage(msg.chat.id, `❌ <b>HD VIDEO GAGAL</b>\n\n${htmlEscape(e.message)}`, {
      parse_mode: "HTML", ...q(msg)
    });
  } finally {
    if (tempPath) try { fs.unlinkSync(tempPath); } catch {}
  }
}

// ------------------------------------------------------------
// MENU + COMMAND REGISTRATION
// ------------------------------------------------------------
function featureMenuKeyboard(theme) {
  const styled = (text, callback_data) => {
    const b = { text, callback_data };
    return theme?.styled ? theme.styled(b) : b;
  };
  return {
    inline_keyboard: [
      [styled("🎮 GAME CENTER", "feature_games"), styled("⬇ DOWNLOADER", "feature_downloader")],
      [styled("🔗 UPLOADER • TOURL", "feature_tourl"), styled("🧰 TOOLS", "toolsmenu")],
      [styled("✨ HD FOTO", "feature_hdphoto"), styled("🎬 HD VIDEO", "feature_hdvideo")],
      [styled("⌂ MENU UTAMA", "back")],
    ],
  };
}

function featurePage(type, theme) {
  const common = {
    games:
      `<b>🎮 GAME CENTER</b>\n\n<blockquote expandable>` +
      `Main game langsung di chat.\n\n` +
      Object.entries(GAME_CONFIG).map(([key, cfg]) => `├ <code>/${key}</code> — ${htmlEscape(cfg.description)}`).join("\n") +
      `\n\nBalas pesan game dengan jawaban. Ketik <code>nyerah</code> untuk menyerah.</blockquote>`,
    downloader:
      `<b>⬇ DOWNLOADER</b>\n\n<blockquote expandable>` +
      `├ <code>/download URL</code> — Auto detect platform\n` +
      `├ <code>/tiktok URL</code> — TikTok tanpa watermark\n` +
      `├ <code>/youtube URL</code> — YouTube video\n` +
      `├ <code>/instagram URL</code> — Instagram foto/video\n` +
      `├ <code>/mediafire URL</code> — Download file\n` +
      `├ <code>/facebook URL</code> — Facebook video*\n` +
      `╰ <code>/capcut URL</code> — CapCut video*\n\n` +
      `<i>* membutuhkan dependency btch-downloader.</i></blockquote>`,
    tourl:
      `<b>🔗 TOURL</b>\n\n<blockquote expandable>` +
      `Balas/kirim foto, video, audio, atau dokumen dengan <code>/tourl</code>.\n\n` +
      `Platform yang tersedia: Catbox, Uguu, TmpFiles, dan Videy untuk video.\n` +
      `Jalankan <code>/tourl</code> sambil reply media, lalu pilih platform dari tombol yang muncul.</blockquote>`,
    hdphoto:
      `<b>✨ HD FOTO</b>\n\n<blockquote expandable>` +
      `Balas/kirim foto dengan <code>/hd</code>.\n\n` +
      `Prioritas AI enhancer, lalu fallback sharpening lokal jika API sedang tidak tersedia.</blockquote>`,
    hdvideo:
      `<b>🎬 HD VIDEO</b>\n\n<blockquote expandable>` +
      `Balas/kirim video dengan <code>/hdvideo</code>.\n\n` +
      `Proses menggunakan enhancer video dan polling sampai hasil siap. Maksimal 50MB.</blockquote>`,
  };
  return common[type] || common.games;
}

function register(bot, theme) {
  // Game commands + aliases
  for (const [key, cfg] of Object.entries(GAME_CONFIG)) {
    const aliases = Array.isArray(cfg.aliases) ? cfg.aliases : (Array.isArray(cfg.alias) ? cfg.alias : []);
    const commands = [key, ...aliases].map((x) => String(x).replace(/[.*+?^${}()|[\]\\]/g, "\\$&"));
    bot.onText(new RegExp(`^\\/(${commands.join("|")})(?:@\\w+)?$`, "i"), async (msg) => {
      await startGame(bot, msg, key);
    });
  }

  // Downloader
  bot.onText(/^\/(?:download|dl)(?:@\w+)?\s+(\S+)$/i, async (msg, match) => {
    const url = match[1];
    try {
      await bot.sendMessage(msg.chat.id, "🕕 <b>DOWNLOADER</b>\n\nSedang mengambil media...", { parse_mode: "HTML", ...q(msg) });
      await downloadAny(bot, msg, url);
    } catch (e) {
      await bot.sendMessage(msg.chat.id, `❌ <b>DOWNLOAD GAGAL</b>\n\n${htmlEscape(e.message)}`, { parse_mode: "HTML", ...q(msg) });
    }
  });

  bot.onText(/^\/(?:tiktok|tt)(?:@\w+)?\s+(\S+)$/i, async (msg, match) => {
    try { await downloadAny(bot, msg, match[1]); }
    catch (e) { await bot.sendMessage(msg.chat.id, `❌ ${htmlEscape(e.message)}`, { parse_mode: "HTML", ...q(msg) }); }
  });

  bot.onText(/^\/(?:youtube|yt|ytmp4)(?:@\w+)?\s+(\S+)$/i, async (msg, match) => {
    try { await downloadAny(bot, msg, match[1]); }
    catch (e) { await bot.sendMessage(msg.chat.id, `❌ ${htmlEscape(e.message)}`, { parse_mode: "HTML", ...q(msg) }); }
  });

  bot.onText(/^\/(?:instagram|ig|igdl)(?:@\w+)?\s+(\S+)$/i, async (msg, match) => {
    try { await downloadAny(bot, msg, match[1]); }
    catch (e) { await bot.sendMessage(msg.chat.id, `❌ ${htmlEscape(e.message)}`, { parse_mode: "HTML", ...q(msg) }); }
  });

  bot.onText(/^\/(?:mediafire|mfdl|mf)(?:@\w+)?\s+(\S+)$/i, async (msg, match) => {
    try { await downloadAny(bot, msg, match[1]); }
    catch (e) { await bot.sendMessage(msg.chat.id, `❌ ${htmlEscape(e.message)}`, { parse_mode: "HTML", ...q(msg) }); }
  });

  bot.onText(/^\/(?:facebook|fb|fbdown)(?:@\w+)?\s+(\S+)$/i, async (msg, match) => {
    try { await downloadAny(bot, msg, match[1]); }
    catch (e) { await bot.sendMessage(msg.chat.id, `❌ ${htmlEscape(e.message)}`, { parse_mode: "HTML", ...q(msg) }); }
  });

  bot.onText(/^\/(?:capcut|ccdl|cc)(?:@\w+)?\s+(\S+)$/i, async (msg, match) => {
    try { await downloadAny(bot, msg, match[1]); }
    catch (e) { await bot.sendMessage(msg.chat.id, `❌ ${htmlEscape(e.message)}`, { parse_mode: "HTML", ...q(msg) }); }
  });

  // ToURL
  bot.onText(/^\/(?:tourl|upload|url)(?:@\w+)?$/i, async (msg) => {
    await handleTourl(bot, msg);
  });

  // HD photo
  bot.onText(/^\/(?:hd|enhance|upscale)(?:@\w+)?$/i, async (msg) => {
    await handleHdImage(bot, msg);
  });

  // HD video
  bot.onText(/^\/(?:hdvideo|hdvid|enhancevid|hdv)(?:@\w+)?$/i, async (msg) => {
    await handleHdVideo(bot, msg);
  });

  // Game answer listener
  bot.on("message", async (msg) => {
    try { await handleGameAnswer(bot, msg); } catch {}
  });

  // Interactive ToURL platform picker. Reuses the same message so chat does not fill up.
  bot.on("callback_query", async (callbackQuery) => {
    const data = String(callbackQuery.data || "");
    if (!data.startsWith("tourl:")) return;
    // tourl:pick punya handler khusus di bawah. Jangan diproses dua listener.
    if (data === "tourl:pick") return;
    const m = callbackQuery.message;
    const key = `${m.chat.id}:${callbackQuery.from?.id || 0}`;
    const session = tourlSessions.get(key) || [...tourlSessions.entries()].find(([, v]) => v.chatId === m.chat.id && v.messageId === m.message_id)?.[1];
    if (!session) {
      await bot.editMessageText(`❌ <b>TOURL EXPIRED</b>\n\nJalankan <code>/tourl</code> lagi pada media yang ingin di-upload.`, { chat_id: m.chat.id, message_id: m.message_id, parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "‹‹‹", callback_data: "utilitymenu" }]] } }).catch(() => {});
      return;
    }

    if (data === "tourl:cancel") {
      await bot.answerCallbackQuery(callbackQuery.id, { text: "Upload dibatalkan." }).catch(() => {});
      cleanupTourlSession(key);
      await bot.editMessageText(`↩️ <b>TOURL DIBATALKAN</b>`, { chat_id: m.chat.id, message_id: m.message_id, parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "‹‹‹", callback_data: "utilitymenu" }]] } }).catch(() => {});
      return;
    }

    const platform = data.split(":")[1];
    if (!TOURL_UPLOADERS[platform]) {
      return bot.answerCallbackQuery(callbackQuery.id, { text: "Platform tidak tersedia.", show_alert: true }).catch(() => {});
    }
    if (platform === "videy" && !session.isVideo) {
      await bot.answerCallbackQuery(callbackQuery.id, { text: "Videy hanya untuk video MP4/MOV/M4V/WEBM.", show_alert: true }).catch(() => {});
      return;
    }
    if (session.uploading) {
      return bot.answerCallbackQuery(callbackQuery.id, { text: "Upload masih berjalan. Tunggu proses sebelumnya selesai.", show_alert: true }).catch(() => {});
    }
    session.uploading = true;
    await bot.answerCallbackQuery(callbackQuery.id, { text: `Memulai upload ke ${TOURL_UPLOADERS[platform][0]}...` }).catch(() => {});

    // Jangan pernah bergantung pada editMessageText sebagai satu-satunya output.
    // Jika edit gagal, kita tetap kirim status baru agar user tidak melihat "stuck".
    let statusMessageId = m.message_id;
    const sleepRetry = (ms) => new Promise(resolve => setTimeout(resolve, ms));
    const renderStatus = async (text, markup = { inline_keyboard: [] }) => {
      let lastError = null;
      for (let attempt = 0; attempt < 3; attempt++) {
        try {
          await bot.editMessageText(text, { chat_id: m.chat.id, message_id: statusMessageId, parse_mode: "HTML", reply_markup: markup });
          return true;
        } catch (e) {
          lastError = e;
          const desc = String(e?.response?.body?.description || e?.message || "");
          if (/message is not modified/i.test(desc)) return true;
          if (attempt < 2) await sleepRetry(400 * (attempt + 1));
        }
      }
      for (let attempt = 0; attempt < 3; attempt++) {
        try {
          const sent = await bot.sendMessage(m.chat.id, text, { parse_mode: "HTML", reply_markup: markup });
          if (sent?.message_id) {
            statusMessageId = sent.message_id;
            // Penting: tombol retry pada pesan fallback harus tetap menemukan sesi yang sama.
            session.messageId = sent.message_id;
          }
          return true;
        } catch (e) {
          lastError = e;
          if (attempt < 2) await sleepRetry(700 * (attempt + 1));
        }
      }
      console.error("[TOURL] gagal menampilkan status Telegram:", lastError?.message || lastError);
      return false;
    };

    try {
      // UI TOURL sengaja minimal: satu jam pasir selama seluruh proses upload.
      // Tidak ada progress palsu/provider ticker yang terlihat macet di angka tertentu.
      await renderStatus(`⏳`, { inline_keyboard: [] });

      let timeoutId;
      let result;
      try {
        // Catbox dapat membutuhkan waktu lebih lama pada upload dari VPS/datacenter.
        // Deadline luar HARUS lebih panjang dari timeout internal Catbox, kalau tidak
        // request valid akan dibunuh sebelum uploader sempat menyelesaikan retry.
        const totalTimeoutMs = platform === "catbox" ? 110000 : platform === "f24nt" ? 70000 : platform === "videy" ? 130000 : platform === "auto" ? 145000 : 45000;
        const timeout = new Promise((_, reject) => {
          timeoutId = setTimeout(() => reject(new Error(`Upload timeout total ${Math.round(totalTimeoutMs / 1000)} detik untuk ${TOURL_UPLOADERS[platform]?.[0] || platform}.`)), totalTimeoutMs);
        });
        result = await Promise.race([
          uploadToUrl(session.buffer, session.filename, platform),
          timeout
        ]);
      } finally {
        if (timeoutId) clearTimeout(timeoutId);
      }

      if (!result?.url || !/^https?:\/\//i.test(String(result.url))) {
        throw new Error("Server upload tidak mengembalikan URL yang valid.");
      }

      cleanupTourlSession(key);
      const direct = result.directUrl ? `\n\n<b>Direct URL:</b>\n<code>${htmlEscape(result.directUrl)}</code>` : "";
      const fallbackNote = result.fallback ? `\n\n⚠️ <b>${htmlEscape(result.requestedHost || "Platform pilihan")}</b> belum selesai/gagal dalam waktu prioritas, hasil dipercepat lewat <b>${htmlEscape(result.host)}</b>.` : "";
      const finalText = `🔗 <b>TOURL BERHASIL</b>\n\nHost: <b>${htmlEscape(result.host)}</b>${fallbackNote}\n\n<b>URL:</b>\n<code>${htmlEscape(result.url)}</code>${direct}`;

      // Sesuai UX yang diminta: hapus jam pasir, baru kirim hasil akhir.
      await bot.deleteMessage(m.chat.id, statusMessageId).catch(() => {});
      const sentResult = await bot.sendMessage(m.chat.id, finalText, {
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: [[{ text: "Buka Link", url: result.url }], [{ text: "‹‹‹", callback_data: "utilitymenu" }]] }
      }).catch(e => {
        console.error("[TOURL] final result tidak dapat dikirim ke Telegram:", e?.message || e);
        return null;
      });

      // Videy: URL tetap jadi hasil utama. Video hanya bonus bila CDN dapat diambil Telegram.
      if (platform === "videy" && result.directUrl) {
        try {
          await bot.sendVideo(m.chat.id, result.directUrl, { caption: "🎬 <b>VIDEY • VIDEO BERHASIL</b>", parse_mode: "HTML" });
        } catch {}
      }
      if (!sentResult) throw new Error("Upload berhasil, tetapi Telegram gagal mengirim pesan hasil.");
    } catch (e) {
      session.uploading = false;
      const name = TOURL_UPLOADERS[platform]?.[0] || platform;
      const failText = `❌ <b>${htmlEscape(name)} GAGAL</b>\n\n${htmlEscape(e.message || "Upload gagal tanpa pesan error.")}`;

      // Hapus jam pasir juga pada kegagalan. Pesan error baru menyimpan session agar retry tetap bekerja.
      await bot.deleteMessage(m.chat.id, statusMessageId).catch(() => {});
      const failMsg = await bot.sendMessage(m.chat.id, failText, {
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: [[{ text: "↻ Pilih Platform Lain", callback_data: "tourl:pick" }, { text: "‹‹‹", callback_data: "utilitymenu" }]] }
      }).catch(err => {
        console.error("[TOURL] error result tidak dapat dikirim ke Telegram:", err?.message || err);
        return null;
      });
      if (failMsg?.message_id) session.messageId = failMsg.message_id;
    }
  });

  // Re-open platform picker after a failed upload, still editing the same message.
  bot.on("callback_query", async (callbackQuery) => {
    if (callbackQuery.data !== "tourl:pick") return;
    await bot.answerCallbackQuery(callbackQuery.id).catch(() => {});
    const m = callbackQuery.message;
    const session = [...tourlSessions.entries()].find(([, v]) => v.chatId === m.chat.id && v.messageId === m.message_id)?.[1];
    if (!session) return;
    const rows = [
      [{ text: "🗃 Catbox", callback_data: "tourl:catbox" }, { text: "🚀 F24nT", callback_data: "tourl:f24nt" }],
      [{ text: "☁ Uguu", callback_data: "tourl:uguu" }, { text: "📦 TmpFiles", callback_data: "tourl:tmpfiles" }],
    ];
    rows.push([{ text: "🎬 Videy", callback_data: "tourl:videy" }]);
    rows.push([{ text: "✕ Batal", callback_data: "tourl:cancel" }]);
    await bot.editMessageText(`🔗 <b>TOURL</b>\n\n<blockquote expandable>Pilih platform upload untuk media yang sama.</blockquote>`, { chat_id: m.chat.id, message_id: m.message_id, parse_mode: "HTML", reply_markup: { inline_keyboard: rows } }).catch(() => {});
  });

  // ToURL platform information buttons. Actual upload still happens from /tourl picker.
  bot.on("callback_query", async (callbackQuery) => {
    const data = String(callbackQuery.data || "");
    if (!data.startsWith("tourl_info_")) return;
    await bot.answerCallbackQuery(callbackQuery.id).catch(() => {});
    const platform = data.slice("tourl_info_".length);
    const info = {
      catbox: ["🗃 CATBOX", "Upload file umum ke Catbox. Jika Catbox menolak uploader dengan HTTP 412, bot memakai fallback F24nT agar proses tidak berhenti."],
      f24nt: ["🚀 F24NT UPLOAD", "Upload langsung ke endpoint F24nT dengan X-API-Key dan menghasilkan URL publik."],
      uguu: ["☁ UGUU", "Upload file cepat dan menghasilkan URL langsung."],
      tmpfiles: ["📦 TMPFILES", "Upload file dan menghasilkan direct download URL."],
      videy: ["🎬 VIDEY", "Upload video MP4/MOV/M4V/WEBM dan menghasilkan URL Videy + direct CDN."]
    }[platform];
    if (!info) return;
    return bot.editMessageText(`<b>${info[0]}</b>\n\n<blockquote expandable>${info[1]}\n\nGunakan <code>/tourl</code> pada media untuk memilih platform saat upload.</blockquote>`, {
      chat_id: callbackQuery.message.chat.id, message_id: callbackQuery.message.message_id, parse_mode: "HTML",
      reply_markup: { inline_keyboard: [[{ text: "‹‹‹", callback_data: "feature_tourl" }], [{ text: "‹‹‹", callback_data: "utilitymenu" }]] }
    }).catch(() => {});
  });

  // Menu callback pages
  bot.on("callback_query", async (callbackQuery) => {
    const data = callbackQuery.data;
    if (!data || !data.startsWith("feature_")) return;

    await bot.answerCallbackQuery(callbackQuery.id).catch(() => {});
    const type = data.replace("feature_", "");
    const chatId = callbackQuery.message.chat.id;
    const messageId = callbackQuery.message.message_id;
    const text = featurePage(type, theme);
    const kb = type === "tourl" ? {
      inline_keyboard: [
        [{ text: "🗃 Catbox", callback_data: "tourl_info_catbox" }, { text: "☁ Uguu", callback_data: "tourl_info_uguu" }],
        [{ text: "📦 TmpFiles", callback_data: "tourl_info_tmpfiles" }, { text: "🎬 Videy", callback_data: "tourl_info_videy" }],
        [{ text: "‹‹‹", callback_data: "utilitymenu" }],
      ],
    } : {
      inline_keyboard: [
        [{ text: "‹‹‹", callback_data: "utilitymenu" }],
      ],
    };

    await bot.editMessageCaption(text, {
      chat_id: chatId, message_id: messageId, parse_mode: "HTML", reply_markup: kb,
    }).catch(async () => {
      await bot.editMessageText(text, {
        chat_id: chatId, message_id: messageId, parse_mode: "HTML", reply_markup: kb,
      }).catch(() => {});
    });
  });

  bot.on("callback_query", async (callbackQuery) => {
    if (callbackQuery.data !== "utilitymenu") return;
    await bot.answerCallbackQuery(callbackQuery.id).catch(() => {});
    const text =
      `<b>╭━━〔 MEDIA • TOOLS CENTER 〕━━╮</b>\n` +
      `<blockquote expandable>` +
      `<b>Control</b>  : Downloader • Uploader • Tools • Game\n` +
      `<b>Media</b>    : HD Foto • HD Video • ToURL\n` +
      `<b>Mode</b>     : Telegram Native • Live Button\n\n` +
      `<i>Pilih layanan di bawah atau gunakan command langsung.</i>` +
      `</blockquote>`;
    const kb = featureMenuKeyboard(theme);
    await bot.editMessageCaption(text, {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      parse_mode: "HTML",
      reply_markup: kb,
    }).catch(async () => {
      await bot.editMessageText(text, {
        chat_id: callbackQuery.message.chat.id,
        message_id: callbackQuery.message.message_id,
        parse_mode: "HTML",
        reply_markup: kb,
      }).catch(() => {});
    });
  });
}

const registeredBots = new WeakSet();

const originalRegister = register;
register = function guardedRegister(bot, theme) {
  if (!bot || registeredBots.has(bot)) return;
  registeredBots.add(bot);
  return originalRegister(bot, theme);
};

module.exports = {
  register,
  featureMenuKeyboard,
  featurePage,
  // Internal test hooks; no user-facing API change.
  __tourl: { uploadCatbox, uploadUguu, uploadTmpfiles, uploadToUrl, normalizeUploadUrl, getTelegramMedia }
};
