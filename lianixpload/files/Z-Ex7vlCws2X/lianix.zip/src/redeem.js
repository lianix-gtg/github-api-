// src/redeem.js
// Fitur "Code Redeem" lewat tombol di menu.
// - User pencet tombol "⬡ Code Redeem" -> bot minta ketik kode.
// - Kalau kode cocok & masih ada slot -> user dapat role sesuai kode.
// - Owner bisa BUAT / LIST / HAPUS kode redeem lewat tombol
//   "⚒ Kelola Kode Redeem" (di dalam Owner Menu), step-by-step:
//     1) Pilih role
//     2) Masukkan limit klaim (0 = unlimited)
//     3) Masukkan masa aktif role (contoh 7d, 12h, 30m, unlimited)
//     4) Masukkan kode sendiri atau generate random
//
// Setiap kode redeem sekarang punya limit klaim sendiri-sendiri.
// Tiap kali ada yang klaim, `used` nambah 1 (limit 9 -> kepake -> sisa 8, dst).
// Begitu `used` udah nyampe `limit`, kode otomatis dianggap kadaluarsa (non-aktif)
// dan gak bisa dipakai lagi walau ketikannya masih persis sama.
//
// Nambah role baru gampang: tinggal tambah entry baru di REDEEM_ROLES.

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { showMainMenu } = require("./menu");
const roleAccess = require("./roleAccess");

const ROOT = path.join(__dirname, "..");

const OWNER_FILE = path.join(ROOT, "db/users/adminID.json");
const REDEEM_FILE = path.join(ROOT, "db/redeemcodes.json");

// Daftar role yang bisa di-redeem. Key = id role, value = { label, file }.
// (Role "OWNER/ADMIN" sengaja TIDAK dimasukkan di sini karena itu daftar admin
// bot sendiri, terlalu sensitif buat dibagikan lewat kode redeem.)
const REDEEM_ROLES = {
  reseller: { label: "RESELLER", file: path.join(ROOT, "db/users/resellerUsers.json") },
  premium: { label: "PREMIUM", file: path.join(ROOT, "db/users/premiumUsers.json") },
  pt: { label: "PT", file: path.join(ROOT, "db/users/ptUsers.json") },
  tk: { label: "TK", file: path.join(ROOT, "db/users/tkUsers.json") },
  resellervps: { label: "RESELLER VPS", file: path.join(ROOT, "db/users/resellerVps.json") },
  ceo: { label: "CEO", file: path.join(ROOT, "db/users/ceoUsers.json") },
};

// Kode bawaan reseller: YUNRESS = RESELLER, unlimited klaim, unlimited masa aktif.
// Kode ini dipastikan tersedia setiap kali modul redeem dimuat.
const DEFAULT_RESELLER_CODE = "YUNRESS";

// state per chat: nyimpen lagi nunggu input apa dari user ini
const redeemState = {};

function loadJsonArray(file) {
  try {
    if (!fs.existsSync(file)) return [];
    return JSON.parse(fs.readFileSync(file));
  } catch {
    return [];
  }
}

function saveJsonArray(file, data) {
  const dir = path.dirname(file);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

function normCode(str) {
  return String(str || "").replace(/\s+/g, "").toLowerCase();
}

// ================= LOAD / SAVE KODE REDEEM =================
// Format baru: array of { code, role, limit, used, usedBy, active, createdBy, createdAt }
// limit = null artinya unlimited.
// Otomatis migrasi dari format lama { reseller: "mambo" } (single code per role,
// dianggap unlimited) biar kode2 lama yang udah kepake tetep jalan.
function loadCodes() {
  if (!fs.existsSync(REDEEM_FILE)) {
    saveJsonArray(REDEEM_FILE, []);
    return [];
  }
  let raw;
  try {
    raw = JSON.parse(fs.readFileSync(REDEEM_FILE));
  } catch {
    return [];
  }

  if (Array.isArray(raw)) return raw;

  // migrasi format lama (object per role)
  const migrated = Object.keys(raw)
    .filter((roleId) => REDEEM_ROLES[roleId] && raw[roleId])
    .map((roleId) => ({
      code: String(raw[roleId]),
      role: roleId,
      limit: null,
      used: 0,
      usedBy: [],
      active: true,
      createdBy: null,
      createdAt: new Date().toISOString(),
      legacy: true,
    }));

  saveJsonArray(REDEEM_FILE, migrated);
  return migrated;
}

function saveCodes(codes) {
  saveJsonArray(REDEEM_FILE, codes);
}

function ensureDefaultRedeemCode() {
  const codes = loadCodes();
  const existing = codes.find((c) => normCode(c.code) === normCode(DEFAULT_RESELLER_CODE));
  if (existing) {
    // Pastikan kode bawaan tetap unlimited klaim dan unlimited masa aktif.
    let changed = false;
    if (existing.role !== "reseller") { existing.role = "reseller"; changed = true; }
    if (existing.limit !== null) { existing.limit = null; changed = true; }
    if (existing.duration !== null) { existing.duration = null; changed = true; }
    if (existing.active !== true) { existing.active = true; changed = true; }
    if (!Array.isArray(existing.usedBy)) { existing.usedBy = []; changed = true; }
    if (!Number.isFinite(Number(existing.used))) { existing.used = existing.usedBy.length; changed = true; }
    if (changed) saveCodes(codes);
    return;
  }

  codes.push({
    code: DEFAULT_RESELLER_CODE,
    role: "reseller",
    limit: null,
    duration: null,
    used: 0,
    usedBy: [],
    active: true,
    createdBy: "system",
    createdAt: new Date().toISOString(),
    builtin: true,
  });
  saveCodes(codes);
}

function isOwner(userId) {
  const owners = loadJsonArray(OWNER_FILE);
  return owners.includes(String(userId));
}

function genRandomCode() {
  return crypto.randomBytes(5).toString("hex").toUpperCase(); // 10 karakter
}

function remainingText(entry) {
  if (entry.limit === null || entry.limit === undefined) return `${entry.used}x terpakai • Unlimited`;
  return `${entry.used}/${entry.limit} terpakai • sisa ${Math.max(entry.limit - entry.used, 0)}`;
}

function cancelKeyboard(cbData = "redeem_cancel") {
  return { inline_keyboard: [[{ text: "⊠ ʙᴀᴛᴀʟ", callback_data: cbData }]] };
}

function parseDuration(input) {
  const raw = String(input || "").trim().toLowerCase().replace(/\s+/g, "");
  if (raw === "0" || raw === "unlimited" || raw === "∞") return null;

  const m = /^(\d+(?:\.\d+)?)(m|h|d|w)$/.exec(raw);
  if (!m) return { error: true };

  const value = Number(m[1]);
  if (!Number.isFinite(value) || value <= 0) return { error: true };

  const multipliers = {
    m: 60 * 1000,
    h: 60 * 60 * 1000,
    d: 24 * 60 * 60 * 1000,
    w: 7 * 24 * 60 * 60 * 1000,
  };

  return { expiresAt: Date.now() + value * multipliers[m[2]], label: raw };
}

function durationLabel(expiresAt) {
  return roleAccess.formatExpiryDate(expiresAt);
}

function roleChoiceKeyboard() {
  const ids = Object.keys(REDEEM_ROLES);
  const rows = [];
  for (let i = 0; i < ids.length; i += 2) {
    rows.push(
      ids.slice(i, i + 2).map((id) => ({
        text: REDEEM_ROLES[id].label,
        callback_data: `redeem_role_${id}`,
      }))
    );
  }
  rows.push([{ text: "⊠ ʙᴀᴛᴀʟ", callback_data: "redeem_cancel" }]);
  return { inline_keyboard: rows };
}

function manageMenuKeyboard() {
  return {
    inline_keyboard: [
      [{ text: "+ ʙᴜᴀᴛ ᴋᴏᴅᴇ ʙᴀʀᴜ", callback_data: "redeem_new" }],
      [{ text: "☰ ʟɪꜱᴛ ᴋᴏᴅᴇ", callback_data: "redeem_list" }],
      [{ text: "⌫ ʜᴀᴘᴜꜱ ᴋᴏᴅᴇ", callback_data: "redeem_del" }],
      [{ text: "← ᴋᴇᴍʙᴀʟɪ", callback_data: "ownermenu" }],
    ],
  };
}

// ================= CEK FITUR / TOTAL FITUR =================
// Dua tombol ini sengaja ditaruh nempel di Code Redeem (menu.js) biar user
// baru gampang nemuin: "fitur apa aja yang ada" & "berapa banyak fitur".

function backToMenuKeyboard() {
  return {
    inline_keyboard: [
      [{ text: "Total Fitur", callback_data: "totalfitur" }],
      [{ text: "< ‹", callback_data: "back" }],
    ],
  };
}

// Daftar kategori fitur utama (ngikutin struktur menu yang beneran ada),
// biar user dapet gambaran fitur tanpa harus buka satu-satu.
function buildFeatureListText() {
  return `<b>✦ SPECIAL MENU</b>

<blockquote expandable>
<b>▣ CREATE PANEL</b>
Buat panel hosting baru • V1–V20 • ADP

<b>◈ INSTALL PANEL</b>
Tema • dependency • Nginx • Wings

<b>⌖ OWNER MENU</b>
Role • limit • broadcast • manajemen user

<b>◆ TOOLS MENU</b>
Downloader • stalk • search • AI tools

<b>◎ GROUP MENU</b>
Kick • ban • mute • promote • warn

<b>◒ PROTECT MENU</b>
Anti-kill • anti-culik • proteksi panel

<b>◉ CVPS MENU</b>
Monitor • CPU • disk • restart VPS

<b>◇ REDEEM</b>
Klaim kode untuk upgrade role

<b>⌁ CHAT OWNER</b>
Relay chat langsung ke Owner

<b>⚙ DEV PANEL</b>
Khusus Owner/Developer
</blockquote>

Pilih <b>Total Fitur</b> untuk melihat statistik command dan tombol aktif.`;
}

// Ngitung beneran (scan source code), bukan angka ngarang, biar akurat
// walau nanti ada fitur ditambah/dikurang.
// FIX: sebelumnya cuma nyisir file langsung di src/ (readdirSync non-recursive
// & gak ikut index.js), jadi command yang didaftarin di index.js (misal game
// tebak angka, dsb) kelewat gak ke-hitung. Sekarang nyisir index.js + SEMUA
// .js di src/ termasuk sub-folder (src/data/, dst) biar bener-bener lengkap.
function walkJsFiles(dir, out = []) {
  let entries;
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch {
    return out;
  }
  for (const entry of entries) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      walkJsFiles(full, out);
    } else if (entry.name.endsWith(".js")) {
      out.push(full);
    }
  }
  return out;
}

function computeTotalFitur() {
  const srcDir = path.join(__dirname);
  const rootIndex = path.join(__dirname, "..", "index.js");

  const files = walkJsFiles(srcDir);
  if (fs.existsSync(rootIndex)) files.push(rootIndex);

  const commandSet = new Set();
  const buttonSet = new Set();

  for (const file of files) {
    let content;
    try {
      content = fs.readFileSync(file, "utf8");
    } catch {
      continue;
    }

    const cmdMatches = content.matchAll(/bot\.onText\(\s*\/\^?\\\/([a-zA-Z0-9_]+)/g);
    for (const m of cmdMatches) commandSet.add(m[1].toLowerCase());

    const btnMatches = content.matchAll(/callback_data:\s*[`"']([^`"'$]+)/g);
    for (const m of btnMatches) buttonSet.add(m[1].toLowerCase());
  }

  return { commands: commandSet.size, buttons: buttonSet.size };
}

function collectFeatureCommands() {
  const files = walkJsFiles(path.join(__dirname));
  const rootIndex = path.join(__dirname, "..", "index.js");
  if (fs.existsSync(rootIndex)) files.push(rootIndex);
  const set = new Set();
  for (const file of files) {
    let content = "";
    try { content = fs.readFileSync(file, "utf8"); } catch { continue; }
    const re = /bot\.onText\(\s*\/\^?\\\/([a-zA-Z0-9_]+)/g;
    for (const m of content.matchAll(re)) set.add("/" + m[1].toLowerCase());
  }
  return [...set].sort((a,b) => a.localeCompare(b));
}

function featureUse(command) {
  const c = command.replace(/^\//, "");
  const rules = [
    [/^listuser/, "Melihat daftar user pada panel sesuai versi."],
    [/^listadp|^listadmin/, "Melihat daftar Admin Panel yang memiliki akses root."],
    [/^add/, "Menambahkan user atau akses sesuai jenis perintah."],
    [/^del|^delete|^hapus/, "Menghapus data, akses, atau item sesuai perintah."],
    [/^create|^buat/, "Membuat resource atau konfigurasi baru sesuai perintah."],
    [/^cek|^check|^status/, "Mengecek status atau kondisi resource."],
    [/^panel|^server|^srv/, "Mengelola atau melihat informasi panel/server."],
    [/^vps|^cvps/, "Mengelola atau memantau VPS."],
    [/^stalk/, "Mencari informasi publik berdasarkan target yang diberikan."],
    [/^ai|^ask|^chat/, "Menggunakan fitur AI untuk memproses permintaan."],
    [/^download|^dl|^yt/, "Mengambil atau memproses media sesuai perintah."],
    [/^group|^kick|^ban|^mute|^warn|^promote/, "Mengelola anggota dan moderasi grup."],
    [/^owner|^addowner|^delowner/, "Mengelola pengaturan atau akses owner."],
    [/^redeem|^code/, "Mengelola atau menggunakan kode redeem."],
    [/^broadcast|^bc/, "Mengirim pesan ke target yang ditentukan."],
    [/^menu|^start|^help/, "Membuka menu bantuan dan daftar fitur bot."],
  ];
  for (const [re, desc] of rules) if (re.test(c)) return desc;
  return "Menjalankan fitur bot sesuai nama perintah.";
}

function buildFeatureCatalogPage(page = 1, perPage = 8) {
  const commands = collectFeatureCommands();
  const totalPages = Math.max(1, Math.ceil(commands.length / perPage));
  const current = Math.min(Math.max(1, Number(page) || 1), totalPages);
  const start = (current - 1) * perPage;
  const items = commands.slice(start, start + perPage);
  const lines = items.length
    ? items.map((cmd, i) => `${start+i+1}. <code>${cmd}</code>\nKegunaan: ${featureUse(cmd)}`).join("\n\n")
    : "Tidak ada command yang terdeteksi.";
  return {
    text: `<b>╭━━〔 FITUR & COMMAND 〕━━╮</b>\n` +
      `<i>Command aktif yang terdeteksi dari source</i>\n\n` +
      `<blockquote expandable>Total command : <b>${commands.length}</b>\nHalaman : <b>${current}/${totalPages}</b></blockquote>\n\n${lines}`,
    page: current,
    totalPages,
  };
}

function featureCatalogKeyboard(page, totalPages) {
  const row = [];
  if (page > 1) row.push({ text: "⟸ Sebelumnya", callback_data: `totalfitur:${page-1}` });
  if (page < totalPages) row.push({ text: "Berikutnya ⟹", callback_data: `totalfitur:${page+1}` });
  const rows = row.length ? [row] : [];
  rows.push([{ text: "< ‹", callback_data: "cekfitur" }]);
  return { inline_keyboard: rows };
}

function buildTotalFiturText() {
  const { commands, buttons } = computeTotalFitur();
  const total = commands + buttons;
  return `<b>╭━━〔 TOTAL FITUR 〕━━╮</b>\n` +
    `<i>Statistik fitur yang terdeteksi dari source bot</i>\n\n` +
    `<blockquote expandable><b>STATISTIK</b>\n` +
    `◈ Commands : <b>${commands}</b>\n` +
    `◈ Buttons  : <b>${buttons}</b>\n` +
    `◈ Total UI : <b>${total}</b>\n` +
    `</blockquote>\n` +
    `<blockquote expandable><b>FITUR UTAMA</b>\n` +
    `◆ Panel & VPS\n◆ Group & Protection\n◆ AI & Downloader\n◆ Tools & Search\n◆ Redeem & Owner\n◆ Developer & Utilities\n` +
    `</blockquote>\n` +
    `<i>Pilih halaman untuk melihat daftar command beserta kegunaannya.</i>`;
}

async function renderOrSend(bot, chatId, messageId, text, reply_markup) {
  // Menu di bot ini kebanyakan dikirim sebagai foto (caption), jadi coba
  // editMessageCaption dulu (sama kayak pola di menu.js), baru fallback ke
  // editMessageText (kalau pesan sebelumnya murni teks), baru fallback kirim
  // pesan baru.
  if (messageId) {
    try {
      await bot.editMessageCaption(text, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML",
        reply_markup,
      });
      return;
    } catch {
      try {
        await bot.editMessageText(text, {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: "HTML",
          reply_markup,
        });
        return;
      } catch {
        // fallback di bawah
      }
    }
  }
  await bot.sendMessage(chatId, text, { parse_mode: "HTML", reply_markup });
}

// Coba redeem 1 kode buat 1 user. Return { ok, message }
function tryRedeem(inputText, userId) {
  ensureDefaultRedeemCode();
  const codes = loadCodes();
  const input = normCode(inputText);

  const entry = codes.find((c) => normCode(c.code) === input);

  if (!entry) {
    return { ok: false, message: "◇ Kode redeem tidak valid." };
  }

  const isFull = entry.limit !== null && entry.limit !== undefined && entry.used >= entry.limit;
  if (!entry.active || isFull) {
    return { ok: false, message: "⌛ Kode redeem ini sudah kadaluarsa (limit klaim habis)." };
  }

  const role = REDEEM_ROLES[entry.role];
  if (!role) {
    return { ok: false, message: "◇ Role pada kode ini sudah tidak tersedia." };
  }

  entry.usedBy = entry.usedBy || [];
  if (entry.usedBy.includes(userId)) {
    return { ok: false, message: "ℹ Kamu sudah pernah pakai kode ini." };
  }

  // Kalau role sebelumnya sudah expired, bersihkan dulu sebelum mengecek duplikat.
  roleAccess.hasActiveRole(entry.role, userId);
  const users = loadJsonArray(role.file);
  if (users.includes(userId)) {
    return { ok: false, message: `ℹ Kamu sudah punya role ${role.label}.` };
  }

  // ◉ Sah, proses klaim
  users.push(userId);
  saveJsonArray(role.file, users);

  // Masa aktif role mengikuti durasi yang diset Owner saat membuat kode.
  if (entry.duration !== null && entry.duration !== undefined) {
    roleAccess.setRoleExpiry(entry.role, userId, Date.now() + entry.duration);
  } else {
    roleAccess.setRoleExpiry(entry.role, userId, null);
  }

  entry.usedBy.push(userId);
  entry.used = (entry.used || 0) + 1;
  if (entry.limit !== null && entry.limit !== undefined && entry.used >= entry.limit) {
    entry.active = false; // otomatis kadaluarsa begitu limit abis
  }
  saveCodes(codes);

  const sisa =
    entry.limit === null || entry.limit === undefined
      ? "Unlimited"
      : `${Math.max(entry.limit - entry.used, 0)} slot lagi`;

  return {
    ok: true,
    message: `✦ <b>REDEEM BERHASIL</b>\n\n<blockquote expandable>Role berhasil ditambahkan\n<b>${role.label}</b></blockquote>\n<b>Sisa klaim</b>  ${sisa}\n\nTerima kasih sudah menggunakan Code Redeem.`,
  };
}

module.exports = (bot) => {
  // Pastikan kode reseller bawaan selalu tersedia.
  ensureDefaultRedeemCode();

  // ================= COMMAND TERSEMBUNYI: /redeem [kode] =================
  bot.onText(/^\/redeem(?:\s+(.+))?$/i, async (msg, match) => {
    const chatId = msg.chat.id;
    const userId = String(msg.from.id);
    const inputRaw = (match && match[1] ? match[1] : "").trim();

    delete redeemState[chatId];

    if (!inputRaw) {
      return bot.sendMessage(
        chatId,
        "◇ Format salah!\nGunakan: /redeem KODEKAMU",
        { parse_mode: "HTML" }
      );
    }

    const result = tryRedeem(inputRaw, userId);
    return bot.sendMessage(chatId, result.message, { parse_mode: "HTML" });
  });

  // ================= TOMBOL: BUKA CODE REDEEM (USER) =================
  // Beberapa versi menu memakai callback berbeda. Terima semuanya agar tombol
  // Redeem memakai pesan/menu yang sama: callback mengedit kartu lama agar chat tidak penuh.
  bot.on("callback_query", async (query) => {
    if (!["coderedeem", "redeem", "redeem_menu", "open_redeem"].includes(query.data)) return;

    const chatId = query.message?.chat?.id;
    if (!chatId) return;

    await bot.answerCallbackQuery(query.id).catch(() => {});
    redeemState[chatId] = {
      type: "redeem_code",
      userId: String(query.from.id),
      messageId: query.message?.message_id,
    };

    await renderOrSend(
      bot,
      chatId,
      query.message?.message_id,
      `✦ <b>CODE REDEEM</b>\n\n<blockquote expandable>Masukkan kode redeem kamu di pesan berikutnya.</blockquote>\n\n<b>Kode Reseller</b>\n<code>YUNRESS</code> — unlimited orang\n\n<b>Catatan</b>\n• Satu akun hanya dapat memakai kode yang sama sekali\n• Kode yang sudah mencapai batas klaim tidak dapat digunakan lagi`,
      cancelKeyboard()
    );
  });

  // ================= TOMBOL: CEK FITUR =================
  bot.on("callback_query", async (query) => {
    if (query.data !== "cekfitur") return;
    await bot.answerCallbackQuery(query.id);

    await renderOrSend(
      bot,
      query.message.chat.id,
      query.message.message_id,
      buildFeatureListText(),
      backToMenuKeyboard()
    );
  });

  // ================= TOMBOL: TOTAL FITUR =================
  bot.on("callback_query", async (query) => {
    const data = String(query.data || "");
    if (data !== "totalfitur" && !/^totalfitur:\d+$/.test(data)) return;
    await bot.answerCallbackQuery(query.id).catch(() => {});

    const page = data === "totalfitur" ? 1 : Number(data.split(":")[1]);
    const catalog = buildFeatureCatalogPage(page, 8);
    await renderOrSend(
      bot,
      query.message.chat.id,
      query.message.message_id,
      catalog.text,
      featureCatalogKeyboard(catalog.page, catalog.totalPages)
    );
  });

  // ================= TOMBOL: OWNER - BUKA MENU KELOLA KODE REDEEM =================
  bot.on("callback_query", async (query) => {
    if (query.data !== "redeem_setcode") return;
    await bot.answerCallbackQuery(query.id);

    const chatId = query.message.chat.id;
    const userId = String(query.from.id);

    if (!isOwner(userId)) {
      return bot.sendMessage(chatId, "◇ Hanya Owner yang bisa mengubah kode redeem!");
    }

    delete redeemState[chatId];

    await renderOrSend(
      bot,
      chatId,
      query.message.message_id,
      "✦ <b>REDEEM CENTER</b>\n\n<blockquote expandable>Kelola kode, limit klaim, dan daftar redeem aktif.</blockquote>\n\n<b>Kode bawaan:</b> <code>YUNRESS</code> = RESELLER • Unlimited\n\nPilih tindakan di bawah:",
      manageMenuKeyboard()
    );
  });

  // ================= TOMBOL: BUAT KODE BARU (STEP 1 - PILIH ROLE) =================
  bot.on("callback_query", async (query) => {
    if (query.data !== "redeem_new") return;
    await bot.answerCallbackQuery(query.id);

    const chatId = query.message.chat.id;
    const userId = String(query.from.id);
    if (!isOwner(userId)) {
      return bot.sendMessage(chatId, "◇ Hanya Owner yang bisa mengubah kode redeem!");
    }

    redeemState[chatId] = { type: "redeem_pick_role", userId, messageId: query.message.message_id };

    await renderOrSend(
      bot,
      chatId,
      query.message.message_id,
      "✦ <b>CREATE REDEEM</b>\n\n<blockquote expandable>Pilih role yang akan diberikan saat kode berhasil digunakan.</blockquote>",
      roleChoiceKeyboard()
    );
  });

  // ================= TOMBOL: PILIH ROLE (STEP 2 - MINTA LIMIT) =================
  bot.on("callback_query", async (query) => {
    const m = /^redeem_role_(.+)$/.exec(query.data || "");
    if (!m) return;
    await bot.answerCallbackQuery(query.id);

    const chatId = query.message.chat.id;
    const userId = String(query.from.id);
    if (!isOwner(userId)) {
      return bot.sendMessage(chatId, "◇ Hanya Owner yang bisa mengubah kode redeem!");
    }

    const roleId = m[1];
    const role = REDEEM_ROLES[roleId];
    if (!role) return bot.sendMessage(chatId, "◇ Role tidak dikenali.");

    redeemState[chatId] = {
      type: "redeem_input_limit",
      userId,
      role: roleId,
      messageId: query.message.message_id,
    };

    await renderOrSend(
      bot,
      chatId,
      query.message.message_id,
      `✦ <b>REDEEM • ${role.label}</b>\n\n<blockquote expandable>Tentukan jumlah akun yang dapat menggunakan kode ini.</blockquote>\n\n<b>Contoh</b>  9\n<b>Unlimited</b>  ketik 0\n\nSetelah ini kamu akan menentukan masa aktif role.`,
      cancelKeyboard()
    );
  });

  // ================= TOMBOL: PILIH DURASI CEPAT =================
  bot.on("callback_query", async (query) => {
    const m = /^redeem_duration_(.+)$/.exec(query.data || "");
    if (!m) return;
    await bot.answerCallbackQuery(query.id);

    const chatId = query.message.chat.id;
    const state = redeemState[chatId];
    if (!state || state.type !== "redeem_input_duration") return;
    if (!isOwner(state.userId)) return;

    const parsed = parseDuration(m[1]);
    if (parsed && parsed.error) return bot.sendMessage(chatId, "◇ Durasi tidak valid.");

    state.duration = parsed.expiresAt === null ? null : (parsed.expiresAt - Date.now());
    state.durationInput = m[1];
    state.type = "redeem_input_code";
    redeemState[chatId] = state;

    await renderOrSend(
      bot,
      chatId,
      query.message.message_id,
      `✦ <b>REDEEM • ${REDEEM_ROLES[state.role].label}</b>\n\n<blockquote expandable>Durasi role: <b>${m[1] === "unlimited" ? "Unlimited" : m[1]}</b>\nSekarang masukkan kode custom atau generate kode otomatis.</blockquote>`,
      {
        inline_keyboard: [
          [{ text: "⬡ ʀᴀɴᴅᴏᴍ", callback_data: "redeem_random" }],
          [{ text: "⊠ ʙᴀᴛᴀʟ", callback_data: "redeem_cancel" }],
        ],
      }
    );
  });

  // ================= TOMBOL: RANDOM CODE (STEP 3b) =================
  bot.on("callback_query", async (query) => {
    if (query.data !== "redeem_random") return;
    await bot.answerCallbackQuery(query.id);

    const chatId = query.message.chat.id;
    const state = redeemState[chatId];
    if (!state || state.type !== "redeem_input_code") return;
    if (!isOwner(state.userId)) return;

    const code = genRandomCode();
    finalizeNewCode(bot, chatId, state, code, query.message.message_id);
  });

  // ================= TOMBOL: LIST KODE =================
  bot.on("callback_query", async (query) => {
    if (query.data !== "redeem_list") return;
    await bot.answerCallbackQuery(query.id);

    const chatId = query.message.chat.id;
    const userId = String(query.from.id);
    if (!isOwner(userId)) {
      return bot.sendMessage(chatId, "◇ Hanya Owner yang bisa melihat ini!");
    }

    const codes = loadCodes();
    let text;
    if (!codes.length) {
      text = "✦ <b>REDEEM LIST</b>\n\n<blockquote expandable>Belum ada kode redeem.</blockquote>";
    } else {
      text = "✦ <b>REDEEM LIST</b>\n\n";
      codes.forEach((c) => {
        const role = REDEEM_ROLES[c.role];
        const status = c.active && !(c.limit !== null && c.used >= c.limit) ? "◉ Aktif" : "⌛ Kadaluarsa";
        const duration = c.duration === null || c.duration === undefined
          ? "∞ Unlimited"
          : `${Math.max(1, Math.round(c.duration / 3600000))} jam`;
        text += `✦ <b>${role ? role.label : c.role}</b>\n   Kode  ${c.code}\n   ${remainingText(c)}\n   Durasi role  ${duration} • ${status}\n\n`;
      });
    }

    await renderOrSend(bot, chatId, query.message.message_id, text, {
      inline_keyboard: [[{ text: "← ᴋᴇᴍʙᴀʟɪ", callback_data: "redeem_setcode" }]],
    });
  });

  // ================= TOMBOL: HAPUS KODE (MINTA INPUT) =================
  bot.on("callback_query", async (query) => {
    if (query.data !== "redeem_del") return;
    await bot.answerCallbackQuery(query.id);

    const chatId = query.message.chat.id;
    const userId = String(query.from.id);
    if (!isOwner(userId)) {
      return bot.sendMessage(chatId, "◇ Hanya Owner yang bisa menghapus kode redeem!");
    }

    redeemState[chatId] = { type: "redeem_delcode", userId, messageId: query.message.message_id };

    await renderOrSend(
      bot,
      chatId,
      query.message.message_id,
      "⌫ <b>DELETE REDEEM</b>\n\n<blockquote expandable>Kirim kode yang ingin dihapus.</blockquote>",
      cancelKeyboard()
    );
  });

  // ================= TOMBOL: BATAL =================
  bot.on("callback_query", async (query) => {
    if (query.data !== "redeem_cancel") return;
    await bot.answerCallbackQuery(query.id);

    const chatId = query.message.chat.id;
    delete redeemState[chatId];

    await showMainMenu(bot, chatId, query.message.message_id, query.from.id, query.from);
  });

  // ================= TERIMA INPUT TEKS =================
  bot.on("message", async (msg) => {
    const chatId = msg.chat.id;
    const text = (msg.text || "").trim();
    if (!text || text.startsWith("/")) return;

    const state = redeemState[chatId];
    if (!state) return;

    // --- User lagi masukin kode redeem ---
    if (state.type === "redeem_code") {
      delete redeemState[chatId];
      const userId = String(msg.from.id);
      const result = tryRedeem(text, userId);
      await bot.sendMessage(chatId, result.message, { parse_mode: "Markdown" });
      return showMainMenu(bot, chatId, state.messageId, userId, msg.from);
    }

    // --- Owner lagi input limit kode baru ---
    if (state.type === "redeem_input_limit") {
      if (!isOwner(state.userId)) {
        delete redeemState[chatId];
        return bot.sendMessage(chatId, "◇ Hanya Owner yang bisa mengubah kode redeem!");
      }

      const num = Number(text.replace(/\s+/g, ""));
      if (!Number.isInteger(num) || num < 0) {
        return bot.sendMessage(chatId, "◇ Limit harus berupa angka bulat ≥ 0 (0 = unlimited). Coba lagi:");
      }

      redeemState[chatId] = {
        type: "redeem_input_duration",
        userId: state.userId,
        role: state.role,
        limit: num === 0 ? null : num,
        messageId: state.messageId,
      };

      const role = REDEEM_ROLES[state.role];
      return bot.sendMessage(
        chatId,
        `✦ <b>REDEEM • ${role.label}</b>\n\n<blockquote expandable>Tentukan berapa lama role akan aktif setelah kode diklaim.</blockquote>\n\n<b>Contoh:</b> <code>7d</code> = 7 hari\n<code>12h</code> = 12 jam\n<code>30m</code> = 30 menit\n<code>1w</code> = 1 minggu\n<code>unlimited</code> = tanpa masa berlaku`,
        {
          parse_mode: "HTML",
          reply_markup: {
            inline_keyboard: [
              [
                { text: "1 Hari", callback_data: "redeem_duration_1d" },
                { text: "7 Hari", callback_data: "redeem_duration_7d" },
                { text: "30 Hari", callback_data: "redeem_duration_30d" },
              ],
              [
                { text: "∞ Unlimited", callback_data: "redeem_duration_unlimited" },
              ],
              [{ text: "⊠ Batal", callback_data: "redeem_cancel" }],
            ],
          },
        }
      );
    }

    // --- Owner lagi input durasi role ---
    if (state.type === "redeem_input_duration") {
      if (!isOwner(state.userId)) {
        delete redeemState[chatId];
        return bot.sendMessage(chatId, "◇ Hanya Owner yang bisa mengubah kode redeem!");
      }

      const parsed = parseDuration(text);
      if (!parsed || parsed.error) {
        return bot.sendMessage(
          chatId,
          "◇ Durasi tidak valid. Gunakan contoh: 30m, 12h, 7d, 1w, atau unlimited."
        );
      }

      redeemState[chatId] = {
        type: "redeem_input_code",
        userId: state.userId,
        role: state.role,
        limit: state.limit,
        duration: parsed.expiresAt === null ? null : (parsed.expiresAt - Date.now()),
        durationInput: text,
        messageId: state.messageId,
      };

      const role = REDEEM_ROLES[state.role];
      return bot.sendMessage(
        chatId,
        `✦ <b>REDEEM • ${role.label}</b>\n\n<blockquote expandable>Durasi: <b>${parsed.expiresAt === null ? "Unlimited" : text}</b>\nMasukkan kode custom tanpa spasi, atau generate kode otomatis.</blockquote>`,
        {
          parse_mode: "HTML",
          reply_markup: {
            inline_keyboard: [
              [{ text: "⬡ ʀᴀɴᴅᴏᴍ", callback_data: "redeem_random" }],
              [{ text: "⊠ ʙᴀᴛᴀʟ", callback_data: "redeem_cancel" }],
            ],
          },
        }
      );
    }

    // --- Owner lagi input kode custom ---
    if (state.type === "redeem_input_code") {
      if (!isOwner(state.userId)) {
        delete redeemState[chatId];
        return bot.sendMessage(chatId, "◇ Hanya Owner yang bisa mengubah kode redeem!");
      }

      const newCode = text.replace(/\s+/g, "");
      if (!newCode) {
        return bot.sendMessage(chatId, "◇ Kode tidak boleh kosong! Coba lagi:");
      }

      return finalizeNewCode(bot, chatId, state, newCode);
    }

    // --- Owner lagi hapus kode ---
    if (state.type === "redeem_delcode") {
      delete redeemState[chatId];
      if (!isOwner(state.userId)) {
        return bot.sendMessage(chatId, "◇ Hanya Owner yang bisa menghapus kode redeem!");
      }

      const target = normCode(text);
      const codes = loadCodes();
      const idx = codes.findIndex((c) => normCode(c.code) === target);

      if (idx === -1) {
        return bot.sendMessage(chatId, "◇ Kode redeem tidak ditemukan.");
      }

      const removed = codes.splice(idx, 1)[0];
      saveCodes(codes);

      const role = REDEEM_ROLES[removed.role];
      return bot.sendMessage(
        chatId,
        `✦ <b>REDEEM DIHAPUS</b>\n\n<b>${role ? role.label : removed.role}</b>\nKode  ${removed.code}\nStatus  Nonaktif`,
        { parse_mode: "HTML" }
      );
    }
  });

  // Helper buat nyimpen kode baru & kasih konfirmasi (dipakai dari input teks & tombol random)
  async function finalizeNewCode(botRef, chatId, state, code) {
    delete redeemState[chatId];

    const codes = loadCodes();
    const dup = codes.find(
      (c) => normCode(c.code) === normCode(code) && c.active && !(c.limit !== null && c.used >= c.limit)
    );
    if (dup) {
      return botRef.sendMessage(chatId, "◇ Kode itu udah dipakai kode lain yang masih aktif. Pakai kode lain ya.");
    }

    const role = REDEEM_ROLES[state.role];
    const entry = {
      code,
      role: state.role,
      limit: state.limit === undefined ? null : state.limit,
      duration: state.duration === undefined ? null : state.duration,
      used: 0,
      usedBy: [],
      active: true,
      createdBy: state.userId,
      createdAt: new Date().toISOString(),
    };
    codes.push(entry);
    saveCodes(codes);

    const limitLabel = entry.limit === null ? "Unlimited" : entry.limit;
    const durationLabelText = entry.duration === null
      ? "Unlimited"
      : `${Math.max(1, Math.round(entry.duration / 3600000))} jam`;

    return botRef.sendMessage(
      chatId,
      `✦ <b>REDEEM BERHASIL DIBUAT</b>\n\n<blockquote expandable><b>${role.label}</b>\nKode  <code>${code}</code>\nLimit  ${limitLabel}\nMasa aktif  ${durationLabelText}</blockquote>\n\nKode siap dibagikan.`,

      { parse_mode: "HTML" }
    );
  }
};
