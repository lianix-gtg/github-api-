'use strict';

const axios = require('axios');

const DEFAULT_TIMEOUT = 120000;
const RETRIES_PER_PROVIDER = 1;

function cleanText(value) {
  if (value == null) return '';
  if (typeof value === 'string') return value.trim();
  return String(value).trim();
}

function normalizeOpenAIResponse(data) {
  return cleanText(data?.choices?.[0]?.message?.content || data?.choices?.[0]?.text || data?.response || data?.result || data?.text);
}

async function callPollinations(prompt, model) {
  const pollModel = model || process.env.AI_POLLINATIONS_MODEL || 'openai';
  const url = `https://text.pollinations.ai/${encodeURIComponent(prompt)}?model=${encodeURIComponent(pollModel)}&seed=${Math.floor(Math.random() * 99999)}&json=false`;
  const r = await axios.get(url, { timeout: DEFAULT_TIMEOUT, responseType: 'text', headers: { Accept: 'text/plain' } });
  const text = cleanText(r.data);
  if (!text) throw new Error('Pollinations mengembalikan respons kosong.');
  return text;
}

async function callPollinationsV1(prompt, model) {
  const key = process.env.POLLINATIONS_API_KEY || process.env.POLLINATIONS_KEY;
  if (!key) throw new Error('POLLINATIONS_API_KEY belum diatur.');

  const r = await axios.post('https://gen.pollinations.ai/v1/chat/completions', {
    model: model || process.env.AI_POLLINATIONS_MODEL || 'openai',
    messages: [{ role: 'user', content: prompt }],
    temperature: 0.1,
    stream: false,
  }, {
    timeout: DEFAULT_TIMEOUT,
    responseType: 'json',
    headers: {
      Authorization: `Bearer ${key}`,
      'Content-Type': 'application/json',
      Accept: 'application/json',
    },
  });

  const text = normalizeOpenAIResponse(r.data);
  if (!text) throw new Error('Pollinations API mengembalikan respons kosong.');
  return text;
}

async function callPollinationsPost(prompt, model) {
  const r = await axios.post('https://text.pollinations.ai/', {
    messages: [{ role: 'user', content: prompt }],
    model: model || process.env.AI_POLLINATIONS_MODEL || 'openai',
    seed: Math.floor(Math.random() * 99999),
    stream: false,
  }, { timeout: DEFAULT_TIMEOUT, responseType: 'text', headers: { 'Content-Type': 'application/json', Accept: 'text/plain' } });
  const text = cleanText(r.data);
  if (!text) throw new Error('Pollinations POST mengembalikan respons kosong.');
  return text;
}

async function callOpenRouter(prompt) {
  const key = process.env.OPENROUTER_API_KEY;
  if (!key) throw new Error('OPENROUTER_API_KEY belum diatur.');
  const r = await axios.post('https://openrouter.ai/api/v1/chat/completions', {
    model: process.env.OPENROUTER_MODEL || 'openai/gpt-4o-mini',
    messages: [{ role: 'user', content: prompt }],
    temperature: 0.1,
  }, {
    timeout: DEFAULT_TIMEOUT,
    headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
  });
  const text = normalizeOpenAIResponse(r.data);
  if (!text) throw new Error('OpenRouter mengembalikan respons kosong.');
  return text;
}

async function callGroq(prompt) {
  const key = process.env.GROQ_API_KEY;
  if (!key) throw new Error('GROQ_API_KEY belum diatur.');
  const r = await axios.post('https://api.groq.com/openai/v1/chat/completions', {
    model: process.env.GROQ_MODEL || 'llama-3.3-70b-versatile',
    messages: [{ role: 'user', content: prompt }],
    temperature: 0.1,
  }, {
    timeout: DEFAULT_TIMEOUT,
    headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
  });
  const text = normalizeOpenAIResponse(r.data);
  if (!text) throw new Error('Groq mengembalikan respons kosong.');
  return text;
}

async function callGemini(prompt) {
  const key = process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY;
  if (!key) throw new Error('GEMINI_API_KEY belum diatur.');
  const model = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(key)}`;
  const r = await axios.post(url, { contents: [{ parts: [{ text: prompt }] }] }, {
    timeout: DEFAULT_TIMEOUT,
    headers: { 'Content-Type': 'application/json' },
  });
  const text = cleanText(r.data?.candidates?.[0]?.content?.parts?.map(p => p.text || '').join(''));
  if (!text) throw new Error('Gemini mengembalikan respons kosong.');
  return text;
}

async function generateText(prompt, options = {}) {
  const configured = [];
  if (process.env.OPENROUTER_API_KEY) configured.push(['OpenRouter', () => callOpenRouter(prompt)]);
  if (process.env.GROQ_API_KEY) configured.push(['Groq', () => callGroq(prompt)]);
  if (process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY) configured.push(['Gemini', () => callGemini(prompt)]);
  // Pollinations versi baru mewajibkan API key. Prioritaskan endpoint resmi
  // /v1 agar error 402 dari endpoint legacy tidak membuat AI FIX langsung mati.
  if (process.env.POLLINATIONS_API_KEY || process.env.POLLINATIONS_KEY) {
    configured.push(['Pollinations API', () => callPollinationsV1(prompt, options.pollinationsModel)]);
  }
  // Legacy fallback hanya dicoba jika tersedia; endpoint ini sekarang dapat
  // mengembalikan 402 ketika tidak terautentikasi.
  configured.push(['Pollinations', () => callPollinations(prompt, options.pollinationsModel)]);
  configured.push(['Pollinations POST', () => callPollinationsPost(prompt, options.pollinationsModel)]);

  const errors = [];
  for (const [name, fn] of configured) {
    for (let attempt = 0; attempt <= RETRIES_PER_PROVIDER; attempt++) {
      try {
        const result = await fn();
        if (result) return { text: result, provider: name };
      } catch (err) {
        errors.push(`${name}: ${err?.response?.data?.error?.message || err?.message || 'unknown error'}`);
        if (attempt < RETRIES_PER_PROVIDER) await new Promise(resolve => setTimeout(resolve, 900));
      }
    }
  }
  throw new Error(`Semua API AI gagal. ${errors.slice(-4).join(' | ')}`);
}

module.exports = { generateText };
