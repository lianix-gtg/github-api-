/**
 * LianiX — Archive Feature Exposure Hub
 * 
 * The feature implementations already live in src/features/.
 * This file only exposes missing commands and keeps them grouped by category.
 * Existing commands are intentionally NOT registered again.
 */
'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const axios = require('axios');

const FEATURE_DIR = path.join(__dirname, 'features');

function esc(s = '') {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

async function load(name) {
  return import(path.join(FEATURE_DIR, name));
}

async function reply(bot, msg, text) {
  return bot.sendMessage(msg.chat.id, text, {
    parse_mode: 'HTML',
    reply_to_message_id: msg.message_id
  });
}

function textArg(m) {
  return String(m?.[1] || '').trim();
}

async function getReplyBuffer(bot, msg) {
  const r = msg.reply_to_message;
  if (!r) return null;

  let fileId = null;
  if (r.photo?.length) fileId = r.photo[r.photo.length - 1].file_id;
  else if (r.document?.file_id) fileId = r.document.file_id;
  else if (r.video?.file_id) fileId = r.video.file_id;

  if (!fileId) return null;
  const url = await bot.getFileLink(fileId);
  const { data } = await axios.get(url, {
    responseType: 'arraybuffer',
    timeout: 60000,
    maxContentLength: 25 * 1024 * 1024
  });
  return Buffer.from(data);
}

function pickUrl(value) {
  if (!value) return null;
  if (typeof value === 'string' && /^https?:\/\//i.test(value)) return value;
  if (Array.isArray(value)) {
    for (const x of value) {
      const u = pickUrl(x);
      if (u) return u;
    }
  }
  if (typeof value === 'object') {
    const preferred = [
      'url', 'download_url', 'downloadUrl', 'video', 'audio', 'image',
      'imageUrl', 'resultUrl', 'result', 'source', 'link', 'download', 'output'
    ];
    for (const k of preferred) {
      const u = pickUrl(value[k]);
      if (u) return u;
    }
    for (const v of Object.values(value)) {
      const u = pickUrl(v);
      if (u) return u;
    }
  }
  return null;
}

async function sendResult(bot, msg, result, caption = 'Selesai') {
  if (Buffer.isBuffer(result)) return bot.sendDocument(msg.chat.id, result, { caption, reply_to_message_id: msg.message_id });
  if (Buffer.isBuffer(result?.image)) return bot.sendPhoto(msg.chat.id, result.image, { caption, reply_to_message_id: msg.message_id });
  if (Buffer.isBuffer(result?.video)) return bot.sendVideo(msg.chat.id, result.video, { caption, reply_to_message_id: msg.message_id });
  if (Buffer.isBuffer(result?.audio)) return bot.sendAudio(msg.chat.id, result.audio, { caption, reply_to_message_id: msg.message_id });
  if (Buffer.isBuffer(result?.buffer)) return bot.sendDocument(msg.chat.id, result.buffer, {}, { filename: result.filename || 'lianix-result.bin', contentType: result.mime || 'application/octet-stream' });
  const localPath = result?.filePath || result?.path;
  if (localPath && fs.existsSync(localPath)) return bot.sendDocument(msg.chat.id, localPath, { caption, reply_to_message_id: msg.message_id });
  const url = pickUrl(result);
  if (url) {
    try {
      if (/\.(?:jpg|jpeg|png|webp)(?:\?|$)/i.test(url) || result?.type === 'image') {
        return bot.sendPhoto(msg.chat.id, url, { caption, reply_to_message_id: msg.message_id });
      }
      return bot.sendMessage(msg.chat.id, `${caption}\n\n<a href="${esc(url)}">Buka hasil</a>`, { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
    } catch {}
  }
  let out;
  try { out = JSON.stringify(result, null, 2); } catch { out = String(result); }
  if (out.length > 3900) out = out.slice(0, 3890) + '\n…';
  return reply(bot, msg, `<b>${esc(caption)}</b>\n\n<pre>${esc(out)}</pre>`);
}

async function register(bot) {
  // ================= AI CENTER =================

  bot.onText(/^\/unlimitedai(?:@\w+)?(?:\s+([\s\S]+))?$/i, async (msg, m) => {
    const prompt = textArg(m);
    if (!prompt) return reply(bot, msg, 'Gunakan: <code>/unlimitedai &lt;pesan&gt;</code>');
    try {
      const { UnlimitedAI } = await load('unlimitedai.js');
      const r = await UnlimitedAI(prompt);
      return sendResult(bot, msg, r, 'Unlimited AI');
    } catch (e) {
      return reply(bot, msg, `Gagal: <code>${esc(e.message)}</code>`);
    }
  });

  bot.onText(/^\/gpt52(?:@\w+)?(?:\s+([\s\S]+))?$/i, async (msg, m) => {
    const prompt = textArg(m);
    if (!prompt) return reply(bot, msg, 'Gunakan: <code>/gpt52 &lt;pesan&gt;</code>');
    try {
      const { chat } = await load('gpt52.js');
      const r = await chat({ message: prompt });
      return sendResult(bot, msg, r, 'GPT-5.2');
    } catch (e) {
      return reply(bot, msg, `Gagal: <code>${esc(e.message)}</code>`);
    }
  });

  bot.onText(/^\/feeb(?:@\w+)?(?:\s+([\s\S]+))?$/i, async (msg, m) => {
    const prompt = textArg(m);
    if (!prompt) return reply(bot, msg, 'Gunakan: <code>/feeb &lt;pesan&gt;</code>');
    try {
      const { FeelBetter } = await load('feeb.js');
      const r = await FeelBetter(prompt);
      return sendResult(bot, msg, r, 'FeelBetter AI');
    } catch (e) {
      return reply(bot, msg, `Gagal: <code>${esc(e.message)}</code>`);
    }
  });

  bot.onText(/^\/logicbell(?:@\w+)?(?:\s+([\s\S]+))?$/i, async (msg, m) => {
    const prompt = textArg(m);
    if (!prompt) return reply(bot, msg, 'Gunakan: <code>/logicbell &lt;pesan&gt;</code>');
    try {
      const { chat } = await load('logic-bell.js');
      const r = await chat({
        message: prompt,
        senderId: String(msg.from?.id || ''),
        senderName: String(msg.from?.first_name || ''),
        aiFullName: 'Logic Bell'
      });
      return sendResult(bot, msg, r, 'Logic Bell');
    } catch (e) {
      return reply(bot, msg, `Gagal: <code>${esc(e.message)}</code>`);
    }
  });

  bot.onText(/^\/geminivision(?:@\w+)?(?:\s+([\s\S]+))?$/i, async (msg, m) => {
    const prompt = textArg(m);
    if (!prompt) return reply(bot, msg, 'Gunakan: <code>/geminivision &lt;pertanyaan&gt;</code> sebagai reply foto.');
    try {
      const imageBuffer = await getReplyBuffer(bot, msg);
      if (!imageBuffer) return reply(bot, msg, 'Reply foto/gambar lalu gunakan <code>/geminivision &lt;pertanyaan&gt;</code>.');
      const { chat } = await load('geminiVision.js');
      const r = await chat({ message: prompt, imageBuffer });
      return sendResult(bot, msg, r, 'Gemini Vision');
    } catch (e) {
      return reply(bot, msg, `Gagal: <code>${esc(e.message)}</code>`);
    }
  });

  // ================= IMAGE / CREATIVE TOOLS =================

  bot.onText(/^\/seaart(?:@\w+)?(?:\s+([\s\S]+))?$/i, async (msg, m) => {
    const prompt = textArg(m);
    if (!prompt) return reply(bot, msg, 'Gunakan: <code>/seaart &lt;prompt&gt;</code>');
    try {
      const { fluxImage } = await load('seaart.js');
      const r = await fluxImage(prompt);
      return sendResult(bot, msg, r, 'SeaArt / Flux');
    } catch (e) {
      return reply(bot, msg, `Gagal: <code>${esc(e.message)}</code>`);
    }
  });

  bot.onText(/^\/seaart3d(?:@\w+)?(?:\s+([\s\S]+))?$/i, async (msg, m) => {
    const prompt = textArg(m) || 'tingkatkan kualitas gambar';
    try {
      const imageBuffer = await getReplyBuffer(bot, msg);
      if (!imageBuffer) return reply(bot, msg, 'Reply gambar lalu gunakan <code>/seaart3d [prompt]</code>.');
      const { live3d } = await load('seaart.js');
      const r = await live3d(imageBuffer, prompt);
      return sendResult(bot, msg, r, 'SeaArt 3D');
    } catch (e) {
      return reply(bot, msg, `Gagal: <code>${esc(e.message)}</code>`);
    }
  });

  bot.onText(/^\/img2img(?:@\w+)?(?:\s+([\s\S]+))?$/i, async (msg, m) => {
    const prompt = textArg(m);
    if (!prompt) return reply(bot, msg, 'Reply gambar lalu gunakan <code>/img2img &lt;prompt&gt;</code>.');
    try {
      const imageBuffer = await getReplyBuffer(bot, msg);
      if (!imageBuffer) return reply(bot, msg, 'Reply gambar lalu gunakan <code>/img2img &lt;prompt&gt;</code>.');
      const { Img2Img } = await load('img2img.js');
      const r = await Img2Img(prompt, imageBuffer, 'lianix.png');
      if (!r?.status) throw new Error(r?.error || 'Img2Img gagal');
      return sendResult(bot, msg, r, 'Image → Image');
    } catch (e) { return reply(bot, msg, `Gagal: <code>${esc(e.message)}</code>`); }
  });

  bot.onText(/^\/wink(?:@\w+)?$/i, async msg => {
    let dir = null;
    try {
      const r = msg.reply_to_message;
      const fileId = r?.video?.file_id || r?.document?.file_id;
      if (!fileId) return reply(bot, msg, 'Reply video lalu gunakan <code>/wink</code>.');
      const link = await bot.getFileLink(fileId);
      const res = await axios.get(link, { responseType:'arraybuffer', timeout:120000, maxContentLength:100*1024*1024 });
      const { default: winkEnhance } = await load('wink.js');
      const out = await winkEnhance(Buffer.from(res.data), { filename:'lianix-wink.mp4' });
      return sendResult(bot, msg, out, 'Wink Enhance');
    } catch (e) { return reply(bot, msg, `Gagal: <code>${esc(e.message)}</code>`); }
    finally { if (dir) try { fs.rmSync(dir,{recursive:true,force:true}); } catch {} }
  });

  bot.onText(/^\/mconverter(?:@\w+)?(?:\s+(\w+))?$/i, async (msg, m) => {
    const format = String(m?.[1] || '').toLowerCase();
    if (!format) return reply(bot, msg, 'Reply file/media lalu gunakan <code>/mconverter mp3</code> (ganti mp3 dengan format tujuan).');
    let dir;
    try {
      const r = msg.reply_to_message;
      const fileId = r?.document?.file_id || r?.video?.file_id || r?.audio?.file_id || r?.voice?.file_id;
      if (!fileId) return reply(bot, msg, 'Reply file/media yang mau dikonversi.');
      const name = r?.document?.file_name || `input.${r?.video?'mp4':r?.audio?'mp3':r?.voice?'ogg':'bin'}`;
      const link = await bot.getFileLink(fileId);
      const res = await axios.get(link,{responseType:'arraybuffer',timeout:120000,maxContentLength:100*1024*1024});
      dir=fs.mkdtempSync(path.join(os.tmpdir(),'lianix-convert-')); const input=path.join(dir,path.basename(name)); fs.writeFileSync(input,Buffer.from(res.data));
      const { mconverter } = await load('mconverter.js');
      const out = await mconverter.convert(input,format);
      if (out?.error) throw new Error(out.error);
      return sendResult(bot,msg,out,`Media Converter → ${format}`);
    } catch(e) { return reply(bot,msg,`Gagal: <code>${esc(e.message)}</code>`); }
    finally { if(dir) try{fs.rmSync(dir,{recursive:true,force:true});}catch{} }
  });

  bot.onText(/^\/img2prompt(?:@\w+)?$/i, async msg => {
    try {
      const imageBuffer = await getReplyBuffer(bot, msg);
      if (!imageBuffer) return reply(bot, msg, 'Reply gambar lalu gunakan <code>/img2prompt</code>.');
      const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'lianix-img2prompt-'));
      const file = path.join(dir, 'input.jpg');
      fs.writeFileSync(file, imageBuffer);
      try {
        const { default: imgtoprompt } = await load('img2prompt.js');
        const r = await imgtoprompt(file);
        return sendResult(bot, msg, r, 'Image → Prompt');
      } finally {
        fs.rmSync(dir, { recursive: true, force: true });
      }
    } catch (e) {
      return reply(bot, msg, `Gagal: <code>${esc(e.message)}</code>`);
    }
  });

  bot.onText(/^\/txt2img2(?:@\w+)?(?:\s+([\s\S]+))?$/i, async (msg, m) => {
    const prompt = textArg(m);
    if (!prompt) return reply(bot, msg, 'Gunakan: <code>/txt2img2 &lt;prompt&gt;</code>');
    try {
      const { Txt2Img2 } = await load('txt2img2.js');
      const r = await Txt2Img2(prompt);
      return sendResult(bot, msg, r, 'TXT2IMG 2');
    } catch (e) {
      return reply(bot, msg, `Gagal: <code>${esc(e.message)}</code>`);
    }
  });

  bot.onText(/^\/txt2imgv2(?:@\w+)?(?:\s+([\s\S]+))?$/i, async (msg, m) => {
    const prompt = textArg(m);
    if (!prompt) return reply(bot, msg, 'Gunakan: <code>/txt2imgv2 &lt;prompt&gt;</code>');
    try {
      const { Txt2ImgV2 } = await load('txt2imgv2.js');
      const r = await Txt2ImgV2(prompt);
      return sendResult(bot, msg, r, 'TXT2IMG V2');
    } catch (e) {
      return reply(bot, msg, `Gagal: <code>${esc(e.message)}</code>`);
    }
  });

  bot.onText(/^\/tts(?:@\w+)?(?:\s+([\s\S]+))?$/i, async (msg, m) => {
    const text = textArg(m);
    if (!text) return reply(bot, msg, 'Gunakan: <code>/tts &lt;teks&gt;</code>');
    try {
      const { default: generateCustomTTS } = await load('topmedia.js');
      const r = await generateCustomTTS('', text);
      return sendResult(bot, msg, r, 'Text to Speech');
    } catch (e) {
      return reply(bot, msg, `Gagal: <code>${esc(e.message)}</code>`);
    }
  });

  // ================= SEARCH / INFO CENTER =================

  bot.onText(/^\/wwchar(?:@\w+)?(?:\s+([\s\S]+))?$/i, async (msg, m) => {
    const q = textArg(m);
    if (!q) return reply(bot, msg, 'Gunakan: <code>/wwchar &lt;nama karakter&gt;</code>');
    try {
      const { default: fn } = await load('wwchar.js');
      return sendResult(bot, msg, await fn(q), 'Wuthering Waves Character');
    } catch (e) {
      return reply(bot, msg, `Gagal: <code>${esc(e.message)}</code>`);
    }
  });

  bot.onText(/^\/hokinfo(?:@\w+)?(?:\s+([\s\S]+))?$/i, async (msg, m) => {
    const q = textArg(m);
    if (!q) return reply(bot, msg, 'Gunakan: <code>/hokinfo &lt;nama hero&gt;</code>');
    try {
      const { default: fn } = await load('hokinfo.js');
      return sendResult(bot, msg, await fn(q), 'Honor of Kings Info');
    } catch (e) {
      return reply(bot, msg, `Gagal: <code>${esc(e.message)}</code>`);
    }
  });

  bot.onText(/^\/dramabox(?:@\w+)?(?:\s+([\s\S]+))?$/i, async (msg, m) => {
    const q = textArg(m);
    if (!q) return reply(bot, msg, 'Gunakan: <code>/dramabox &lt;judul&gt;</code>');
    try {
      const { default: fn } = await load('dramabox.js');
      return sendResult(bot, msg, await fn(q), 'DramaBox Search');
    } catch (e) {
      return reply(bot, msg, `Gagal: <code>${esc(e.message)}</code>`);
    }
  });

  bot.onText(/^\/tiktoksearch(?:@\w+)?(?:\s+([\s\S]+))?$/i, async (msg, m) => {
    const q = textArg(m);
    if (!q) return reply(bot, msg, 'Gunakan: <code>/tiktoksearch &lt;kata kunci&gt;</code>');
    try {
      const { tiktokSearchVideo } = await load('tiktoksearch.js');
      return sendResult(bot, msg, await tiktokSearchVideo(q), 'TikTok Search');
    } catch (e) {
      return reply(bot, msg, `Gagal: <code>${esc(e.message)}</code>`);
    }
  });

  bot.onText(/^\/gsmarena(?:@\w+)?(?:\s+([\s\S]+))?$/i, async (msg, m) => {
    const q = textArg(m);
    if (!q) return reply(bot, msg, 'Gunakan: <code>/gsmarena &lt;nama HP&gt;</code>');
    try {
      const { search } = await load('gsmarena.js');
      return sendResult(bot, msg, await search(q), 'GSMArena');
    } catch (e) {
      return reply(bot, msg, `Gagal: <code>${esc(e.message)}</code>`);
    }
  });

  bot.onText(/^\/dafont(?:@\w+)?(?:\s+([\s\S]+))?$/i, async (msg, m) => {
    const q = textArg(m);
    if (!q) return reply(bot, msg, 'Gunakan: <code>/dafont &lt;nama font&gt;</code>');
    try {
      const { DaFont } = await load('dafont.js');
      return sendResult(bot, msg, await DaFont(q), 'DaFont Search');
    } catch (e) {
      return reply(bot, msg, `Gagal: <code>${esc(e.message)}</code>`);
    }
  });

  bot.onText(/^\/wallpaper(?:@\w+)?(?:\s+([\s\S]+))?$/i, async (msg, m) => {
    const q = textArg(m);
    if (!q) return reply(bot, msg, 'Gunakan: <code>/wallpaper &lt;kata kunci&gt;</code>');
    try {
      const { default: fn } = await load('wallpapersearch.js');
      return sendResult(bot, msg, await fn(q), 'Wallpaper Search');
    } catch (e) {
      return reply(bot, msg, `Gagal: <code>${esc(e.message)}</code>`);
    }
  });

  bot.onText(/^\/sfiledl(?:@\w+)?(?:\s+([\s\S]+))?$/i, async (msg, m) => {
    const url = textArg(m);
    if (!url) return reply(bot, msg, 'Gunakan: <code>/sfiledl &lt;url&gt;</code>');
    try {
      const { default: fn } = await load('sfiledl.js');
      return sendResult(bot, msg, await fn(url), 'SFile Downloader');
    } catch (e) {
      return reply(bot, msg, `Gagal: <code>${esc(e.message)}</code>`);
    }
  });

  bot.onText(/^\/douyin(?:@\w+)?(?:\s+([\s\S]+))?$/i, async (msg, m) => {
    const url = textArg(m);
    if (!url) return reply(bot, msg, 'Gunakan: <code>/douyin &lt;url&gt;</code>');
    try {
      const { DouyinDL } = await load('douyin.js');
      return sendResult(bot, msg, await DouyinDL(url), 'Douyin Downloader');
    } catch (e) {
      return reply(bot, msg, `Gagal: <code>${esc(e.message)}</code>`);
    }
  });

  bot.onText(/^\/hdvideo2(?:@\w+)?$/i, async msg => {
    try {
      const image = await getReplyBuffer(bot, msg);
      if (!image) return reply(bot, msg, 'Reply video lalu gunakan <code>/hdvideo2</code>.');
      const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'lianix-hdvideo2-'));
      const file = path.join(dir, 'input.mp4');
      fs.writeFileSync(file, image);
      try {
        const { default: fn } = await load('hdvid2.js');
        return sendResult(bot, msg, await fn(file), 'HD Video 2');
      } finally {
        fs.rmSync(dir, { recursive: true, force: true });
      }
    } catch (e) {
      return reply(bot, msg, `Gagal: <code>${esc(e.message)}</code>`);
    }
  });

  // ================= FEATURE LIST =================

  bot.onText(/^\/featurelist(?:@\w+)?$/i, async msg => {
    const text = [
      '<b>╭━━〔 FEATURE CENTER 〕━━╮</b>',
      '<i>Prefix resmi fitur yang ditambahkan/ditampilkan</i>',
      '',
      '<b>◇ AI CENTER</b>',
      '<code>/haiku</code> • Claude Haiku',
      '<code>/gemini</code> • Gemini',
      '<code>/geminivision</code> • Gemini Vision (reply foto)',
      '<code>/deepseek</code> • DeepSeek',
      '<code>/gpt5</code> • GPT-5',
      '<code>/gpt52</code> • GPT-5.2',
      '<code>/qwen</code> • Qwen3',
      '<code>/unlimitedai</code> • Unlimited AI',
      '<code>/feeb</code> • FeelBetter',
      '<code>/logicbell</code> • Logic Bell',
      '',
      '<b>▣ DOWNLOADER CENTER</b>',
      '<code>/ytdl</code> • YouTube',
      '<code>/igdl</code> • Instagram',
      '<code>/tiktokdl</code> • TikTok',
      '<code>/twitterdl</code> • Twitter/X',
      '<code>/fbdl</code> • Facebook',
      '<code>/pindl</code> • Pinterest',
      '<code>/redditdl</code> • Reddit',
      '<code>/spotdl</code> • Spotify',
      '<code>/dailydl</code> • Dailymotion',
      '<code>/teraxdl</code> • Terabox',
      '<code>/sclouddl</code> • SoundCloud',
      '<code>/mediafiredl</code> • MediaFire',
      '<code>/douyin</code> • Douyin',
      '<code>/sfiledl</code> • SFile',
      '<code>/aio</code> • Auto detect',
      '',
      '<b>▣ TOOLS / SEARCH CENTER</b>',
      '<code>/txt2img</code> • Text to Image',
      '<code>/txt2img2</code> • Text to Image 2',
      '<code>/img2img</code> • Image to Image',
      '<code>/img2prompt</code> • Image to Prompt (reply)',
      '<code>/rembg</code> • Remove Background',
      '<code>/upscale</code> • Image Upscaler',
      '<code>/seaart</code> • SeaArt/Flux',
      '<code>/seaart3d</code> • Image 3D (reply)',
      '<code>/tts</code> • Text to Speech',
      '<code>/hd</code> • Image Enhance',
      '<code>/hdvideo</code> • Video Enhance',
      '<code>/hdvideo2</code> • Video Enhance 2 (reply)',
      '<code>/wink</code> • Wink Enhance',
      '<code>/mconverter</code> • Media Converter',
      '<code>/dafont</code> • Font Search',
      '<code>/wallpaper</code> • Wallpaper Search',
      '<code>/gsmarena</code> • Phone Search',
      '<code>/wwchar</code> • Wuthering Waves Info',
      '<code>/hokinfo</code> • Honor of Kings Info',
      '<code>/dramabox</code> • DramaBox Search',
      '<code>/tiktoksearch</code> • TikTok Search',
      '',
      '<b>◇ OTHER EXISTING</b>',
      '<code>/tempmail</code> • Temp Mail',
      '<code>/logicbell</code> • Logic Bell',
      '',
      'Gunakan <code>/ailist</code> untuk AI dan <code>/dllist</code> untuk downloader.'
    ].join('\n');
    return reply(bot, msg, text);
  });
}

module.exports = register;
