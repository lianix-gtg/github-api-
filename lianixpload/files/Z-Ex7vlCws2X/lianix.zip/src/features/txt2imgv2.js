/**
 * LianiX TXT2IMG V2
 *
 * Uses the bot's existing image-generation provider instead of automating
 * or bypassing third-party CAPTCHA/Turnstile challenges.
 */
import { Txt2Img2 } from "./txt2img2.js";

async function Txt2ImgV2(prompt, width = 1024, height = 1024) {
  const cleanPrompt = String(prompt || "").trim();
  if (!cleanPrompt) throw new Error("Prompt wajib diisi");

  // Keep the existing provider and safety checks used by TXT2IMG 2.
  // Width/height are accepted for API compatibility; the provider currently
  // renders at 1024x1024.
  const result = await Txt2Img2(cleanPrompt);

  if (!result?.status || !result?.url) {
    return {
      status: false,
      code: result?.code || 500,
      prompt: cleanPrompt,
      resolution: `${width}x${height}`,
      error: result?.error || "Gagal membuat gambar",
    };
  }

  return {
    status: true,
    code: 200,
    prompt: cleanPrompt,
    resolution: "1024x1024",
    url: result.url,
  };
}

export { Txt2ImgV2 };
export default Txt2ImgV2;
