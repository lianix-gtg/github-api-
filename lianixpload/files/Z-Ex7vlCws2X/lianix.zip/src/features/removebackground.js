'use strict';
/**
 * removebackground.js
 * Unified remove-background — pixa.com (free, no key) → HF briaai fallback.
 * CJS compatible; exported as { removeBg }.
 */

const path = require('path');
const os   = require('os');
const fs   = require('fs');
const axios = require('axios');

const REMBG_HF = 'https://briaai-bria-rmbg-2-0.hf.space';

// ── Pixa.com (primary, no API key needed) ──────────────────
async function pixaRemoveBg(imageBuffer) {
  const FormData = require('form-data');
  const form = new FormData();

  // Write buffer to temp file so we can read it back as Blob-equivalent
  const tmp = path.join(os.tmpdir(), `rembg_${Date.now()}.jpg`);
  fs.writeFileSync(tmp, imageBuffer);

  try {
    form.append('image', fs.createReadStream(tmp), {
      filename: 'input.jpg',
      contentType: 'image/jpeg',
    });
    form.append('format', 'png');
    form.append('model', 'v1');

    const res = await axios.post('https://api2.pixelcut.app/image/matte/v1', form, {
      headers: {
        ...form.getHeaders(),
        'User-Agent':
          'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36',
        Accept: 'application/json, text/plain, */*',
        'sec-ch-ua': '"Chromium";v="139", "Not;A=Brand";v="99"',
        'x-locale': 'en',
        'x-client-version': 'web:pixa.com:4a5b0af2',
        'sec-ch-ua-mobile': '?1',
        'sec-ch-ua-platform': '"Android"',
        origin: 'https://www.pixa.com',
        referer: 'https://www.pixa.com/',
        'accept-language': 'id-ID,id;q=0.9,en-AU;q=0.8,en;q=0.7,en-US;q=0.6',
      },
      responseType: 'arraybuffer',
      timeout: 90000,
      maxContentLength: 30 * 1024 * 1024,
    });

    if (!res.data || !res.data.length) throw new Error('Pixa response kosong.');
    return Buffer.from(res.data);
  } finally {
    try { fs.unlinkSync(tmp); } catch {}
  }
}

// ── HuggingFace briaai (fallback) ──────────────────────────
async function hfRemoveBg(imageBuffer) {
  const FormData = require('form-data');
  const form = new FormData();
  form.append('file', imageBuffer, { filename: 'input.jpg', contentType: 'image/jpeg' });

  const up = await axios.post(`${REMBG_HF}/gradio_api/upload`, form, {
    headers: form.getHeaders(),
    timeout: 120000,
  });
  const uploaded = up.data?.[0];
  if (!uploaded) throw new Error('Upload HF remove background gagal.');

  const call = await axios.post(`${REMBG_HF}/gradio_api/call/image`, {
    data: [{ path: uploaded, meta: { _type: 'gradio.FileData' }, orig_name: 'input.jpg', mime_type: 'image/jpeg' }],
  }, { headers: { 'Content-Type': 'application/json' }, timeout: 60000 });

  const evt = call?.data?.event_id;
  if (!evt) throw new Error('Job remove background HF gagal.');

  for (let i = 0; i < 30; i++) {
    await new Promise((r) => setTimeout(r, 2000));
    const r = await axios.get(`${REMBG_HF}/gradio_api/call/image/${evt}`, {
      timeout: 30000,
      responseType: 'text',
    });
    const line = r.data.split('\n').find((x) => x.startsWith('data:') && x.includes('path'));
    if (line) {
      try {
        const p = JSON.parse(line.slice(5));
        const f = p?.find?.((x) => x?.path);
        if (f) {
          return Buffer.from(
            (await axios.get(`${REMBG_HF}/gradio_api/file=${f.path}`, { responseType: 'arraybuffer' })).data,
          );
        }
      } catch {}
    }
  }
  throw new Error('Remove background HF timeout/gagal.');
}

/**
 * removeBg(imageBuffer) → Buffer (PNG transparent)
 * Tries pixa.com first, falls back to HuggingFace briaai.
 */
async function removeBg(imageBuffer) {
  try {
    return await pixaRemoveBg(imageBuffer);
  } catch (pixaErr) {
    // pixa gagal → coba HF
    try {
      return await hfRemoveBg(imageBuffer);
    } catch (hfErr) {
      throw new Error(`Remove BG gagal (pixa: ${pixaErr.message} | HF: ${hfErr.message})`);
    }
  }
}

module.exports = { removeBg, pixaRemoveBg, hfRemoveBg };
