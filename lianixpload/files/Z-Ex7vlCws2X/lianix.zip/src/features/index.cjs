/**
 * LIANIX FEATURES BRIDGE
 * Converts ESM archive features to CJS-compatible dynamic loaders.
 * Uses dynamic import() so the ESM modules load cleanly into the CJS project.
 */
'use strict';

const path = require('path');
const FEAT_DIR = path.join(__dirname);

// Cache loaded modules
const _cache = new Map();

async function _load(name) {
  if (_cache.has(name)) return _cache.get(name);
  const mod = await import(path.join(FEAT_DIR, name));
  _cache.set(name, mod);
  return mod;
}

/**
 * Universal downloader — wraps aio.js
 * Returns: { platform, title, thumbnail, author, media: [{type, url, quality}] }
 */
async function aiodl(url) {
  const mod = await _load('aio.js');
  return mod.aiodl(url);
}

/**
 * Detect platform from URL string
 */
async function detectPlatform(url) {
  const mod = await _load('aio.js');
  return mod.detectPlatform(url);
}

/**
 * TikTok downloader
 */
async function tiktokDl(url) {
  const mod = await _load('tiktok.js');
  return mod.default(url);
}

/**
 * Instagram downloader
 */
async function instagramDl(url) {
  const mod = await _load('ig.js');
  return mod.default(url);
}

/**
 * Twitter/X downloader
 */
async function twitterDl(url) {
  const mod = await _load('twitter.js');
  return mod.default(url);
}

/**
 * Gemini AI chat
 * @param {string} message
 * @param {Object} opts - { instruction, sessionId }
 */
async function geminiChat(message, opts = {}) {
  const mod = await _load('gemini.js');
  return mod.default({ message, ...opts });
}

/**
 * DeepSeek thinking
 * @param {string} prompt
 * @param {Array} history
 */
async function deepseekThinking(prompt, history = []) {
  const mod = await _load('deepseek.js');
  return mod.DeepSeekThinking(prompt, history);
}

/**
 * GPT-5 chat
 */
async function gpt5Chat(message, model = 'gpt-4.5', chatId = null) {
  const mod = await _load('gpt5.js');
  return mod.GPT5(message, model, chatId);
}

/**
 * GPT-5 variant 2
 */
async function gpt52Chat(message, model = 'gpt-4.5') {
  const mod = await _load('gpt52.js');
  const fn = mod.default || mod.GPT5;
  return fn(message, model);
}

/**
 * Claude Haiku AI
 */
async function claudeHaikuChat(message) {
  const mod = await _load('claudehaiku.js');
  const fn = mod.default || mod.claudehaiku || mod.claude;
  return fn(message);
}

/**
 * Qwen3 AI
 */
async function qwen3Chat(message) {
  const mod = await _load('qwen3.js');
  const fn = mod.default || mod.qwen3 || mod.qwen;
  return fn(message);
}

/**
 * Reddit downloader
 */
async function redditDl(url) {
  const mod = await _load('reddit.js');
  return mod.RedditDL(url);
}

/**
 * Spotify downloader
 */
async function spotifyDl(url) {
  const mod = await _load('spotify.js');
  const fn = mod.default || mod.downloadSpotify;
  return fn(url);
}

/**
 * Dailymotion downloader
 */
async function dailymotionDl(url) {
  const mod = await _load('dailymotion.js');
  const fn = mod.default || mod.dailymotion;
  return fn(url);
}

/**
 * Terabox downloader
 */
async function teraboxDl(url) {
  const mod = await _load('terabox.js');
  const fn = mod.default || mod.terabox;
  return fn(url);
}

/**
 * Soundcloud downloader
 */
async function soundcloudDl(url) {
  const mod = await _load('soundclouddl.js');
  const fn = mod.default || mod.soundcloud;
  return fn(url);
}

/**
 * Facebook downloader
 */
async function facebookDl(url) {
  const mod = await _load('fbdown.js');
  const fn = mod.default || mod.fbdown;
  return fn(url);
}

/**
 * Remove background
 */
async function removeBg(imageUrl) {
  const mod = await _load('removebackground.js');
  const fn = mod.default || mod.removeBg || mod.removeBackground;
  return fn(imageUrl);
}

/**
 * Image upscaler / HD
 */
async function upscaleImage(imageUrl) {
  const mod = await _load('upscaler.js');
  const fn = mod.default || mod.upscale || mod.upscaler;
  return fn(imageUrl);
}

module.exports = {
  aiodl,
  detectPlatform,
  tiktokDl,
  instagramDl,
  twitterDl,
  geminiChat,
  deepseekThinking,
  gpt5Chat,
  gpt52Chat,
  claudeHaikuChat,
  qwen3Chat,
  redditDl,
  spotifyDl,
  dailymotionDl,
  teraboxDl,
  soundcloudDl,
  facebookDl,
  removeBg,
  upscaleImage,
};
