/**
 * LIANIX CPANEL — Extra Tools Pack
 * Ported/adapted from the useful tools concept in OURIN MD 3.
 * Telegram-native implementation; no WhatsApp runtime dependencies.
 */
const fs = require("fs");
const os = require("os");
const path = require("path");
const crypto = require("crypto");
const { execFile } = require("child_process");
const { promisify } = require("util");
const axios = require("axios");
const sharp = require("sharp");
const QRCode = require("qrcode");
const settings = require("../settings.js");
/**
 * safeReply — sendMessage with reply_to_message_id fallback.
 */
async function safeReply(bot, chatId, text, opts = {}) {
  try {
    return await bot.sendMessage(chatId, text, opts);
  } catch (err) {
    const desc = String(err?.response?.body?.description || err?.message || '');
    if (/message to be replied not found/i.test(desc) && opts.reply_to_message_id) {
      const { reply_to_message_id: _, ...safeOpts } = opts;
      return await bot.sendMessage(chatId, text, safeOpts);
    }
    throw err;
  }
}


const execFileAsync = promisify(execFile);
const MAX_MEDIA = 20 * 1024 * 1024;

function q(msg) {
  return msg?.message_id ? { reply_to_message_id: msg.message_id } : {};
}
function esc(s = "") {
  return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
}
function bytes(n) {
  if (!Number.isFinite(n)) return "-";
  const u=["B","KB","MB","GB"]; let i=0;
  while(n>=1024 && i<u.length-1){n/=1024;i++;}
  return `${n.toFixed(i ? 1 : 0)} ${u[i]}`;
}
async function getMedia(bot,msg) {
  const t = msg.reply_to_message || msg;
  const fileId =
    t.photo?.[t.photo.length-1]?.file_id ||
    t.video?.file_id ||
    t.document?.file_id ||
    t.sticker?.file_id ||
    t.animation?.file_id ||
    t.audio?.file_id ||
    t.voice?.file_id;
  if (!fileId) throw new Error("Balas atau kirim media yang didukung.");
  const f = await bot.getFile(fileId);
  const url = `https://api.telegram.org/file/bot${settings.token}/${f.file_path}`;
  const r = await axios.get(url,{responseType:"arraybuffer",timeout:90000,maxContentLength:MAX_MEDIA,maxBodyLength:MAX_MEDIA});
  const name = t.document?.file_name || t.audio?.file_name || t.video?.file_name ||
    t.animation?.file_name || path.basename(f.file_path) || `media_${Date.now()}`;
  return { buffer:Buffer.from(r.data), name, target:t };
}
function hasVideo(t){return !!(t?.video || t?.animation || /video\//i.test(t?.document?.mime_type||""));}
function hasImage(t){return !!(t?.photo || t?.sticker || /image\//i.test(t?.document?.mime_type||""));}
async function ffmpegAvailable() {
  try { await execFileAsync("ffmpeg",["-version"],{timeout:5000}); return true; } catch { return false; }
}
async function runFfmpeg(args, timeout=120000) {
  if (!(await ffmpegAvailable())) throw new Error("FFmpeg belum tersedia di server. Install ffmpeg terlebih dahulu.");
  return execFileAsync("ffmpeg",args,{timeout,maxBuffer:1024*1024*4});
}
function progressBar(percent, width=18) {
  const n = Math.max(0, Math.min(100, Number.isFinite(percent) ? percent : 0));
  const filled = Math.round((n / 100) * width);
  return `[` + `▰`.repeat(filled) + `▱`.repeat(width - filled) + `] ${Math.round(n)}%`;
}

function loadingText(title, stage, percent) {
  return `⏳ <b>${esc(title)}</b>\n\n` +
    `▸ ${esc(stage)}\n` +
    `${progressBar(percent)}\n\n` +
    `🔄 <i>Mohon tunggu, proses sedang berjalan...</i>`;
}

async function createLoading(bot, msg, title) {
  let sent = null;
  try {
    sent = await bot.sendMessage(msg.chat.id, loadingText(title, "Menyiapkan...", 0), {parse_mode:"HTML", ...q(msg)});
  } catch {}
  let last = 0;
  let lastAt = 0;
  async function update(stage, percent) {
    if (!sent) return;
    const now = Date.now();
    const value = Math.max(last, Math.min(100, Number(percent) || 0));
    if (value === last && now - lastAt < 3000) return;
    if (now - lastAt < 1200) return;
    last = value; lastAt = now;
    try {
      await bot.editMessageText(loadingText(title, stage, value), {
        chat_id: msg.chat.id, message_id: sent.message_id, parse_mode:"HTML"
      });
    } catch (e) {
      const text = String(e?.response?.body?.description || e?.message || e);
      if (!/429|too many requests|message is not modified|query is too old/i.test(text)) {}
    }
  }
  async function finish(ok=true) {
    if (!sent) return;
    try {
      await bot.editMessageText(
        `⏳ <b>${esc(title)}</b>\n\n${ok ? `✅ ${progressBar(100)}\n\n<b>Selesai.</b>` : `❌ Proses gagal.`}`,
        {chat_id:msg.chat.id, message_id:sent.message_id, parse_mode:"HTML"}
      );
      setTimeout(() => bot.deleteMessage(msg.chat.id, sent.message_id).catch(()=>{}), 1200);
    } catch {}
  }
  return {update, finish};
}

async function editPage(bot,msg,text,reply_markup) {
  const opts={chat_id:msg.chat.id,message_id:msg.message_id,parse_mode:"HTML",reply_markup};
  try {
    if (msg.photo || msg.video || msg.animation) return await bot.editMessageCaption(text,opts);
    return await bot.editMessageText(text,opts);
  } catch {
    try { return await bot.editMessageText(text,opts); } catch {}
  }
}


const ASCII_GRADIENTS = [
  "alphabetic", "alphanumeric", "arrow", "codepage437", "extended",
  "grayscale", "minimalist", "math", "normal", "normal2",
  "numerical", "max", "blockelement",
];

function getAsciiDriver(headless = true) {
  let Builder, By, until, chrome;
  try {
    ({Builder, By, until} = require("selenium-webdriver"));
    chrome = require("selenium-webdriver/chrome");
  } catch {
    throw new Error("Fitur Image to ASCII membutuhkan package selenium-webdriver. Jalankan npm install.");
  }

  const options = new chrome.Options();
  const chromeBin = process.env.CHROME_BIN || "/usr/bin/chromium-browser";
  const driverBin = process.env.CHROMEDRIVER || "/usr/bin/chromedriver";
  if (fs.existsSync(chromeBin)) options.setBinaryPath(chromeBin);
  options.addArguments("--no-sandbox", "--disable-dev-shm-usage", "--disable-gpu", "--window-size=1280,1024");
  if (headless) options.addArguments("--headless=new");

  const service = new chrome.ServiceBuilder(driverBin);
  return new Builder().forBrowser("chrome").setChromeOptions(options).setChromeService(service).build();
}

async function imageToAscii(imagePath, {chars=100, gradient="normal", headless=true}={}) {
  const driver = getAsciiDriver(headless);
  try {
    const {By, until} = require("selenium-webdriver");
    await driver.get("https://www.asciiart.eu/image-to-ascii");
    const fileInput = await driver.wait(until.elementLocated(By.id("fileElem")), 30000);
    await fileInput.sendKeys(path.resolve(imagePath));

    if (chars !== 100) {
      const slider = await driver.wait(until.elementLocated(By.id("asciiWidth")), 30000);
      await driver.executeScript(`arguments[0].value = arguments[1]; arguments[0].dispatchEvent(new Event('input', {bubbles:true})); arguments[0].dispatchEvent(new Event('change', {bubbles:true}));`, slider, chars);
    }
    if (gradient !== "normal") {
      const scale = await driver.findElement(By.id("asciiScale"));
      await driver.executeScript(`arguments[0].value = arguments[1]; arguments[0].dispatchEvent(new Event('change', {bubbles:true}));`, scale, gradient);
    }

    const output = await driver.wait(until.elementLocated(By.id("output")), 30000);
    await driver.wait(async () => {
      const text = await output.getText();
      return text && text.trim().length > 0;
    }, 30000);
    return await output.getText();
  } finally {
    await driver.quit().catch(()=>{});
  }
}


function extractGitReverseSlug(url) {
  try {
    const { hostname, pathname } = new URL(url);
    const cleanPath = pathname.replace(/\/+$/, "");
    return (hostname + cleanPath)
      .replace(/^www\./, "")
      .replace(/[^a-zA-Z0-9]/g, "-")
      .replace(/-+/g, "-")
      .replace(/^-|-$/g, "")
      .toLowerCase();
  } catch {
    throw new Error(`URL tidak valid: ${url}`);
  }
}

async function gitReverseWebsite(targetUrl) {
  const siteSlug = extractGitReverseSlug(targetUrl);
  const res = await fetch("https://www.gitreverse.com/api/reverse-website", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ siteSlug, targetUrl, stream: true })
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}: ${res.statusText}`);
  const text = await res.text();
  for (const line of text.split(/\r?\n/).filter(x => x.startsWith("data: "))) {
    try {
      const data = JSON.parse(line.slice(6));
      if (data.prompt) return {
        prompt: data.prompt,
        designPath: data.designPath || null,
        fromCache: data.fromCache ?? false
      };
    } catch {}
  }
  throw new Error("Tidak ditemukan prompt dalam response SSE");
}

async function gitReverseRepo(repoUrl) {
  const cleanRepo = String(repoUrl)
    .replace(/^https?:\/\/(www\.)?github\.com\//, "")
    .replace(/\/+$/, "");
  const res = await fetch("https://www.gitreverse.com/api/reverse-prompt", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ repoUrl: cleanRepo })
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}: ${res.statusText}`);
  const data = await res.json();
  if (!data.prompt) throw new Error("Tidak ditemukan prompt dalam response");
  return { prompt: data.prompt };
}

async function gitReversePrompt(target, mode="auto") {
  let value = String(target || "").trim();
  if (!value) throw new Error("URL website atau repository GitHub belum diberikan.");
  const isRepo = mode === "repo" || (mode === "auto" && (
    value.includes("github.com") || /^[a-zA-Z0-9_-]+\/[a-zA-Z0-9_.-]+$/.test(value)
  ));
  if (isRepo) return { ...(await gitReverseRepo(value)), mode: "repo", target: value };
  if (!/^https?:\/\//i.test(value)) value = "https://" + value;
  return { ...(await gitReverseWebsite(value)), mode: "website", target: value };
}

function imageToolsMenuKeyboard() {
  return {inline_keyboard:[
    [{text:"▤ Image → ASCII Art",callback_data:"tools_img2ascii"},{text:"◎ Image Metadata",callback_data:"tools_imginfo"}],
    [{text:"⌘ OCR • Text Extractor",callback_data:"tools_ocr"},{text:"◇ AI Remove Background",callback_data:"tools_airembg"}],
    [{text:"◈ Sticker → Image",callback_data:"tools_toimg"},{text:"◫ Web Screenshot",callback_data:"tools_ssweb"}],
    [{text:"🎨 Text → Image • AI",callback_data:"tools_txt2img"},{text:"🎬 Image → Video • AI",callback_data:"tools_img2video"}],
    [{text:"✨ AI Image Enhance",callback_data:"tools_aienhance"}],
    [{text:"‹ Tools Center",callback_data:"toolsmenu"},{text:"‹ Menu Utama",callback_data:"back"}]
  ]};
}

function toolsMenuKeyboard() {
  return {inline_keyboard:[
    [{text:"▣ QR Generator",callback_data:"tools_qr"},{text:"⌘ OCR • Text Extractor",callback_data:"tools_ocr"}],
    [{text:"◇ AI Remove Background",callback_data:"tools_airembg"},{text:"◫ Web Screenshot",callback_data:"tools_ssweb"}],
    [{text:"◈ Sticker → Image",callback_data:"tools_toimg"},{text:"♪ Video → Audio",callback_data:"tools_toaudio"}],
    [{text:"▶ Media → Video",callback_data:"tools_tovideo"},{text:"◎ Image Metadata",callback_data:"tools_imginfo"}],
    [{text:"▤ Image → ASCII Art",callback_data:"tools_img2ascii"},{text:"⌁ GitReverse • AI Prompt",callback_data:"tools_gitreverse"}],
    [{text:"🎨 Text → Image • AI",callback_data:"tools_txt2img"},{text:"🎬 Image → Video • AI",callback_data:"tools_img2video"}],
    [{text:"✨ AI Image Enhance",callback_data:"tools_aienhance"}],
    [{text:"‹ Back to Main Menu",callback_data:"back"}]
  ]};
}
function toolsPage(type) {
  const pages={
    qr:`<b>▣ QR CODE</b>\n\n<blockquote expandable>Ubah teks atau URL menjadi QR PNG 1024×1024 dengan error correction H.\n\n<code>/qr Halo guys</code>\n<code>/qr https://example.com</code>\n<code>/qr tel:+6285777489196</code>\n<code>/qr mailto:user@gmail.com?subject=Test&body=Hello</code>\n<code>/qr WIFI:S:NamaWifi;T:WPA;P:PasswordWifi;;</code>\n\nOutput dikirim langsung sebagai PNG.</blockquote>`,
    ocr:`<b>⌘ OCR</b>\n\n<blockquote expandable>Ambil teks dari gambar.\n\n<code>/ocr</code> lalu reply gambar.\n\nAPI key opsional: <code>OCR_SPACE_KEY</code>. Jika tidak diatur, bot memakai endpoint demo dengan batasan.</blockquote>`,
    removebg:`<b>◇ AI REMOVE BG</b>\n\n<blockquote expandable>Hapus background foto secara otomatis, gratis tanpa API key.\n\n<code>/rembg</code> lalu reply foto.\n\nProvider: pixa.com (utama) → HuggingFace briaai (fallback).\nOutput: PNG transparan.</blockquote>`,
    ssweb:`<b>◫ WEB SCREENSHOT</b>\n\n<blockquote expandable>Ambil screenshot halaman web.\n\n<code>/ssweb https://example.com</code>\n\nCocok untuk preview website atau dokumentasi cepat.</blockquote>`,
    toimg:`<b>◈ TO IMAGE</b>\n\n<blockquote expandable>Konversi sticker/file gambar WebP menjadi PNG.\n\n<code>/toimg</code> lalu reply sticker.</blockquote>`,
    toaudio:`<b>♪ TO AUDIO</b>\n\n<blockquote expandable>Ekstrak audio dari video menjadi MP3.\n\n<code>/toaudio</code> lalu reply video.</blockquote>`,
    tovideo:`<b>▶ TO VIDEO</b>\n\n<blockquote expandable>Konversi media WebP/video menjadi MP4.\n\n<code>/tovideo</code> lalu reply sticker animasi atau media video.</blockquote>`,
    imginfo:`<b>◎ IMAGE INFO</b>\n\n<blockquote expandable>Cek ukuran, format, dan dimensi gambar.\n\n<code>/imginfo</code> lalu reply gambar.</blockquote>`,
    img2ascii:`<b>▤ IMAGE → ASCII</b>\n\n<blockquote expandable>Ubah gambar menjadi ASCII Art menggunakan ASCIIArt.eu.\n\n<code>/img2ascii</code> lalu reply gambar.\n<code>/img2ascii 120 grayscale</code>\n\nWidth: 20–200. Gradient: alphabetic, alphanumeric, arrow, codepage437, extended, grayscale, minimalist, math, normal, normal2, numerical, max, blockelement.\n\nOutput dikirim sebagai file TXT agar ASCII tidak terpotong Telegram.</blockquote>`,
    gitreverse:`<b>⌁ GITREVERSE</b>\n\n<blockquote expandable>Ambil prompt AI untuk membuat ulang desain website atau repository dari GitReverse.\n\n<code>/gitreverse https://example.com</code>\n<code>/gitreverse --website https://example.com</code>\n<code>/gitreverse --repo owner/repo</code>\n\nWebsite menggunakan reverse-website, sedangkan GitHub/repo menggunakan reverse-prompt. Prompt panjang dikirim sebagai file TXT.</blockquote>`,
    txt2img:`<b>🎨 TEXT → IMAGE</b>\n\n<blockquote expandable>Generate gambar dari prompt menggunakan Fireworks, dengan fallback Pollinations.\n\n<code>/txt2img a cyberpunk city</code>\n<code>/txt2img anime girl --style anime --model flux-dev</code>\n\nSet <code>FIREWORKS_API_KEY</code> untuk provider utama.</blockquote>`,
    img2video:`<b>🎬 IMAGE → VIDEO</b>\n\n<blockquote expandable>Balas gambar lalu gunakan <code>/img2video cinematic camera movement</code>.\n\nMemerlukan <code>FIREWORKS_API_KEY</code>.</blockquote>`,
    aienhance:`<b>✨ AI ENHANCE</b>\n\n<blockquote expandable>Tools: <code>/upscale</code>, <code>/enhance</code>, <code>/unblur</code>, <code>/denoise</code>, <code>/restore</code>, <code>/colorize</code>.\n\nBalas gambar untuk menjalankan proses.</blockquote>`,
    airembg:`<b>◇ AI REMOVE BG</b>\n\n<blockquote expandable>Hapus background gambar gratis tanpa API key.\n\n<code>/rembg</code> lalu reply foto.\n\nProvider: pixa.com (utama) → HuggingFace briaai (fallback).\nOutput: PNG transparan.</blockquote>`
  };
  return pages[type] || pages.qr;
}

async function registerCommands(bot) {
  bot.onText(/^\/qr(?:@\w+)?(?:\s+([\s\S]+))?$/i, async(msg,m)=>{
    const text=(m[1]||"").trim();
    if(!text) return bot.sendMessage(msg.chat.id,"▣ <b>QR CODE</b>\n\nGunakan:\n<code>/qr https://example.com</code>",{parse_mode:"HTML",...q(msg)});
    const load=await createLoading(bot,msg,"QR CODE");
    try {
      await load.update("Menyiapkan QR...",15);
      const buf=await QRCode.toBuffer(text,{type:"png",width:1024,margin:4,errorCorrectionLevel:"H",color:{dark:"#000000",light:"#FFFFFF"}});
      await load.update("QR berhasil dibuat, mengirim hasil...",85);
      await bot.sendPhoto(msg.chat.id,buf,{caption:`▣ <b>QR CODE</b>\n\n<code>${esc(text.slice(0,500))}</code>`,parse_mode:"HTML",...q(msg)});
      await load.finish(true);
    } catch(e){await load.finish(false); await bot.sendMessage(msg.chat.id,`❌ QR gagal: ${esc(e.message)}`,{parse_mode:"HTML",...q(msg)});}
  });

  bot.onText(/^\/ocr(?:@\w+)?$/i, async msg=>{
    let inputPath = null;
    let scribe = null;
    const load=await createLoading(bot,msg,"OCR");
    try {
      await load.update("Mengambil media...",10);
      const {buffer, name} = await getMedia(bot,msg);
      if(buffer.length > MAX_MEDIA) throw new Error("Media maksimal 20MB.");

      const originalName = String(name || "media.jpg");
      let ext = path.extname(originalName).toLowerCase();
      if(!ext) ext = ".jpg";

      const IMAGE_EXTS = [".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tif", ".tiff"];
      const PDF_EXTS = [".pdf"];
      const isImage = IMAGE_EXTS.includes(ext);
      const isPdf = PDF_EXTS.includes(ext);
      if(!isImage && !isPdf) throw new Error(`Format tidak support: ${ext || "tanpa ekstensi"}`);

      const tmpDir = path.join(os.tmpdir(), "lianix-ocr");
      fs.mkdirSync(tmpDir, {recursive:true});
      inputPath = path.join(tmpDir, `ocr_${Date.now()}_${Math.random().toString(36).slice(2)}${ext}`);
      fs.writeFileSync(inputPath, buffer);

      await load.update("Memuat engine OCR...",35);
      // Gunakan engine OCR yang diminta: scribe.js-ocr.
      // Require dilakukan saat /ocr dipanggil agar engine tidak membebani startup bot.
      scribe = require("scribe.js-ocr");
      await load.update("Menganalisis gambar/PDF...",65);
      const text = await scribe.extractText([inputPath]);
      await load.update("Merapikan hasil OCR...",90);

      await bot.sendMessage(msg.chat.id, JSON.stringify({
        Status: true,
        Code: 200,
        Type: isPdf ? "pdf" : "image",
        Input: inputPath,
        Result: String(text || "").trim()
      }, null, 2), {...q(msg)});
      await load.finish(true);
    } catch(e) {
      await load.finish(false);
      await bot.sendMessage(msg.chat.id, JSON.stringify({
        Status: false,
        Code: 500,
        Input: inputPath,
        Result: null,
        Error: e.message
      }, null, 2), {...q(msg)});
    } finally {
      try { await scribe?.terminate?.(); } catch {}
      try { if(inputPath && fs.existsSync(inputPath)) fs.unlinkSync(inputPath); } catch {}
    }
  });

  // /removebg → redirect ke /rembg (unified free API, no key needed)
  bot.onText(/^\/removebg(?:@\w+)?$/i, async msg=>{
    await bot.sendMessage(msg.chat.id,
      '◇ <b>REMOVE BACKGROUND</b>\n\nGunakan <code>/rembg</code> — gratis, tanpa API key.\nBalas foto dengan perintah <code>/rembg</code>.',
      {parse_mode:'HTML',...q(msg)}
    );
  });

  bot.onText(/^\/ssweb(?:@\w+)?(?:\s+(\S+))?$/i, async(msg,m)=>{
    const url=(m[1]||"").trim();
    if(!/^https?:\/\//i.test(url)) return bot.sendMessage(msg.chat.id,"◫ <b>WEB SCREENSHOT</b>\n\nContoh:\n<code>/ssweb https://example.com</code>",{parse_mode:"HTML",...q(msg)});
    const load=await createLoading(bot,msg,"WEB SCREENSHOT");
    try {
      await load.update("Membuka halaman...",25);
      const shot=`https://image.thum.io/get/fullpage/${url}`;
      await load.update("Screenshot selesai, mengirim hasil...",90);
      await bot.sendPhoto(msg.chat.id,shot,{caption:`◫ <b>WEB SCREENSHOT</b>\n\n<code>${esc(url)}</code>`,parse_mode:"HTML",...q(msg)});
      await load.finish(true);
    } catch(e){await load.finish(false); await bot.sendMessage(msg.chat.id,`❌ Screenshot gagal: ${esc(e.message)}`,{parse_mode:"HTML",...q(msg)});}
  });

  bot.onText(/^\/toimg(?:@\w+)?$/i, async msg=>{
    const load=await createLoading(bot,msg,"TO IMAGE");
    try {
      await load.update("Mengambil media...",20);
      const {buffer,target}=await getMedia(bot,msg);
      if(!target.sticker && !/image\//i.test(target.document?.mime_type||"")) throw new Error("Reply sticker atau gambar WebP.");
      await load.update("Mengonversi ke PNG...",65);
      const out=await sharp(buffer).png().toBuffer();
      await load.update("Mengirim hasil...",90);
      await bot.sendPhoto(msg.chat.id,out,{caption:"◈ <b>TO IMAGE</b>\n\nMedia berhasil dikonversi menjadi PNG.",parse_mode:"HTML",...q(msg)});
      await load.finish(true);
    } catch(e){await load.finish(false); await bot.sendMessage(msg.chat.id,`❌ <b>TO IMAGE GAGAL</b>\n\n${esc(e.message)}`,{parse_mode:"HTML",...q(msg)});}
  });

  bot.onText(/^\/toaudio(?:@\w+)?$/i, async msg=>{
    let input,output;
    const load=await createLoading(bot,msg,"TO AUDIO");
    try {
      await load.update("Mengambil video...",15);
      const {buffer,target}=await getMedia(bot,msg);
      if(!hasVideo(target)) throw new Error("Reply video/animation.");
      const dir=fs.mkdtempSync(path.join(os.tmpdir(),"yoen-audio-"));
      input=path.join(dir,"input");
      output=path.join(dir,"output.mp3");
      fs.writeFileSync(input,buffer);
      await load.update("Mengekstrak audio...",65);
      await runFfmpeg(["-y","-i",input,"-vn","-ar","44100","-ac","2","-b:a","192k",output],180000);
      await load.update("Mengirim audio...",90);
      await bot.sendAudio(msg.chat.id,output,{caption:"♪ <b>TO AUDIO</b>\n\nAudio berhasil diekstrak menjadi MP3.",parse_mode:"HTML",...q(msg)});
      fs.rmSync(dir,{recursive:true,force:true});
      await load.finish(true);
    } catch(e){await load.finish(false); if(input) try{fs.rmSync(path.dirname(input),{recursive:true,force:true})}catch{}; await bot.sendMessage(msg.chat.id,`❌ <b>TO AUDIO GAGAL</b>\n\n${esc(e.message)}`,{parse_mode:"HTML",...q(msg)});}
  });

  bot.onText(/^\/tovideo(?:@\w+)?$/i, async msg=>{
    let dir;
    const load=await createLoading(bot,msg,"TO VIDEO");
    try {
      await load.update("Mengambil media...",15);
      const {buffer,target}=await getMedia(bot,msg);
      if(!target.sticker && !hasVideo(target)) throw new Error("Reply sticker animasi atau video.");
      dir=fs.mkdtempSync(path.join(os.tmpdir(),"yoen-video-"));
      const input=path.join(dir,"input.webp");
      const output=path.join(dir,"output.mp4");
      fs.writeFileSync(input,buffer);
      await load.update("Mengonversi video...",65);
      await runFfmpeg(["-y","-i",input,"-movflags","faststart","-pix_fmt","yuv420p","-vf","scale=trunc(iw/2)*2:trunc(ih/2)*2","-c:v","libx264","-preset","veryfast","-crf","23",output],180000);
      await load.update("Mengirim video...",90);
      await bot.sendVideo(msg.chat.id,output,{caption:"▶ <b>TO VIDEO</b>\n\nMedia berhasil dikonversi menjadi MP4.",parse_mode:"HTML",supports_streaming:true,...q(msg)});
      await load.finish(true);
    } catch(e){await load.finish(false); await bot.sendMessage(msg.chat.id,`❌ <b>TO VIDEO GAGAL</b>\n\n${esc(e.message)}`,{parse_mode:"HTML",...q(msg)});}
    finally{if(dir) try{fs.rmSync(dir,{recursive:true,force:true})}catch{}}
  });

  bot.onText(/^\/img2ascii(?:@\w+)?(?:\s+(\d+))?(?:\s+([a-z0-9]+))?$/i, async (msg,m)=>{
    let inputPath=null, outPath=null;
    const load=await createLoading(bot,msg,"IMAGE → ASCII");
    try {
      await load.update("Mengambil gambar...",10);
      const {buffer,name,target}=await getMedia(bot,msg);
      if(!hasImage(target)) throw new Error("Reply/kirim gambar yang valid.");
      if(buffer.length > MAX_MEDIA) throw new Error("Media maksimal 20MB.");

      const width = m[1] ? parseInt(m[1],10) : 100;
      const gradient = (m[2] || "normal").toLowerCase();
      if(!Number.isInteger(width) || width < 20 || width > 200) throw new Error("Width harus 20–200.");
      if(!ASCII_GRADIENTS.includes(gradient)) throw new Error(`Gradient tidak valid. Pilihan: ${ASCII_GRADIENTS.join(", ")}`);

      const dir=fs.mkdtempSync(path.join(os.tmpdir(),"lianix-ascii-"));
      inputPath=path.join(dir, path.basename(String(name||"image.jpg")).replace(/[^a-zA-Z0-9._-]/g,"_") || "image.jpg");
      outPath=path.join(dir,`ascii_${Date.now()}.txt`);
      fs.writeFileSync(inputPath,buffer);

      await load.update("Menjalankan browser headless...",25);
      await load.update(`Mengunggah ${esc(name||"gambar")} ke converter...`,40);
      const text=await imageToAscii(inputPath,{chars:width,gradient,headless:true});
      if(!text || !text.trim()) throw new Error("Converter tidak menghasilkan ASCII.");

      fs.writeFileSync(outPath,text,"utf8");
      await load.update("ASCII berhasil dibuat, menyiapkan file TXT...",85);
      await bot.sendDocument(msg.chat.id,outPath,{caption:`▤ <b>IMAGE → ASCII</b>\n\nWidth: <b>${width}</b>\nGradient: <b>${esc(gradient)}</b>\nSource: <code>${esc(name||"image")}</code>`,parse_mode:"HTML",...q(msg)});
      await load.finish(true);
    } catch(e){
      await load.finish(false);
      await bot.sendMessage(msg.chat.id,`❌ <b>IMAGE → ASCII GAGAL</b>\n\n${esc(e.message)}`,{parse_mode:"HTML",...q(msg)});
    } finally {
      try { if(inputPath) fs.rmSync(path.dirname(inputPath),{recursive:true,force:true}); } catch {}
    }
  });

  bot.onText(/^\/gitreverse(?:@\w+)?(?:\s+(--website|--repo))?\s+(.+)$/i, async (msg,m)=>{
    const modeFlag=(m[1]||"").toLowerCase();
    const target=(m[2]||"").trim();
    const mode=modeFlag==="--repo" ? "repo" : modeFlag==="--website" ? "website" : "auto";
    const load=await createLoading(bot,msg,"GITREVERSE");
    let outPath=null;
    try {
      await load.update("Memvalidasi URL/repository...",10);
      const result=await gitReversePrompt(target,mode);
      await load.update(`Mengambil prompt AI (${result.mode === "repo" ? "repository" : "website"})...`,55);
      const prompt=String(result.prompt||"").trim();
      if(!prompt) throw new Error("Prompt kosong dari GitReverse.");
      const dir=fs.mkdtempSync(path.join(os.tmpdir(),"lianix-gitreverse-"));
      outPath=path.join(dir,`gitreverse_${Date.now()}.txt`);
      const header=[
        "LIANIX — GITREVERSE AI PROMPT",
        `Mode: ${result.mode}`,
        `Target: ${result.target}`,
        result.designPath ? `Design: https://www.gitreverse.com${result.designPath}` : null,
        result.fromCache ? "Source: cache" : null,
        "",
        prompt
      ].filter(Boolean).join("\\n");
      fs.writeFileSync(outPath,header,"utf8");
      await load.update("Prompt berhasil ditemukan, menyiapkan output...",85);
      await bot.sendDocument(msg.chat.id,outPath,{
        caption:`⌁ <b>GITREVERSE</b>\n\nMode: <b>${esc(result.mode)}</b>\nTarget: <code>${esc(result.target)}</code>\n\nPrompt AI berhasil dibuat.`,
        parse_mode:"HTML", ...q(msg)
      });
      await load.finish(true);
    } catch(e) {
      await load.finish(false);
      await bot.sendMessage(msg.chat.id,`❌ <b>GITREVERSE GAGAL</b>\n\n${esc(e.message)}`,{parse_mode:"HTML",...q(msg)});
    } finally {
      try { if(outPath) fs.rmSync(path.dirname(outPath),{recursive:true,force:true}); } catch {}
    }
  });

  bot.onText(/^\/imginfo(?:@\w+)?$/i, async msg=>{
    const load=await createLoading(bot,msg,"IMAGE INFO");
    try {
      await load.update("Membaca metadata gambar...",55);
      const {buffer,name}=await getMedia(bot,msg);
      const meta=await sharp(buffer).metadata();
      await load.update("Metadata ditemukan, menyiapkan hasil...",90);
      await bot.sendMessage(msg.chat.id,
        `◎ <b>IMAGE INFO</b>\n\n`+
        `<blockquote expandable>`+
        `File   : <code>${esc(name)}</code>\n`+
        `Format : <b>${esc(meta.format||"unknown")}</b>\n`+
        `Dimensi: <b>${meta.width||"-"} × ${meta.height||"-"}</b>\n`+
        `Ukuran : <b>${bytes(buffer.length)}</b>\n`+
        `Alpha  : <b>${meta.hasAlpha?"Ya":"Tidak"}</b>`+
        `</blockquote>`,
        {parse_mode:"HTML",...q(msg)}
      );
      await load.finish(true);
    } catch(e){await load.finish(false); await bot.sendMessage(msg.chat.id,`❌ <b>IMAGE INFO GAGAL</b>\n\n${esc(e.message)}`,{parse_mode:"HTML",...q(msg)});}
  });
}

function register(bot) {
  registerCommands(bot);
  bot.on("callback_query",async cb=>{
    const d=cb.data||"";
    if(d === "tools_image") {
      await bot.answerCallbackQuery(cb.id).catch(()=>{});
      const text = `<b>╭━━〔 IMAGE TOOLS 〕━━╮</b>\n<blockquote expandable>Semua fitur pengolahan gambar dikumpulkan di sini.\n\n▤ ASCII • ◎ Metadata • ⌘ OCR • Remove BG • Sticker → Image • Screenshot • AI Image</blockquote>`;
      return editPage(bot,cb.message,text,imageToolsMenuKeyboard());
    }
    if(!d.startsWith("tools_")) return;
    await bot.answerCallbackQuery(cb.id).catch(()=>{});
    const type=d.slice(6);
    await editPage(bot,cb.message,toolsPage(type),toolsMenuKeyboard());
  });
  bot.on("callback_query",async cb=>{
    if(cb.data!=="group_tools") return;
    await bot.answerCallbackQuery(cb.id).catch(()=>{});
    const text=`<b>╭━━〔 TOOLS CENTER 〕━━╮</b>\n` +
      `<blockquote expandable>` +
      `<b>Utility</b> — QR Generator, OCR, Image Metadata\n` +
      `<b>Media</b> — Sticker → Image, Video → Audio, Media → Video\n` +
      `<b>Visual</b> — Remove Background, Web Screenshot, Image → ASCII\n` +
      `<b>AI</b> — Text → Image, Image → Video, AI Enhance, AI Remove BG\n` +
      `<b>Web / Dev</b> — GitReverse untuk mengambil prompt AI dari website / repository\n\n` +
      `<i>Pilih fitur di bawah untuk melihat fungsi, command, dan output-nya.</i>` +
      `</blockquote>\n<b>╰━━━━━━━━━━━━━━━━━━━━╯</b>`;
    await editPage(bot,cb.message,text,toolsMenuKeyboard());
  });
}
module.exports={register,toolsMenuKeyboard,imageToolsMenuKeyboard,toolsPage,gitReversePrompt,gitReverseWebsite,gitReverseRepo,extractGitReverseSlug};
