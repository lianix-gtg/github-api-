// Owner-only developer controls: source browser/replacement, Anti Kill settings, backup scheduler.
const fs = require("fs");
const path = require("path");
const archiver = require("archiver");
const settings = require("../settings.js");
const antikill = require("./antikill.js");
const theme = require("./theme.js");
const crypto = require("crypto");
const encEngine = require("./encrypt.js");

const ROOT = path.join(__dirname, "..");
const DEV_FILE = path.join(ROOT, "db", "devTools.json");
const BACKUP_FILE = path.join(ROOT, "lianix.zip");
const backupTimers = { timer: null };
const sourceState = new Map();     // ambil/replace via tombol
const customBackupState = new Map();
const customCpuIntervalState = new Map();
const ubahJsState = new Map();     // /ubahjs flow
const backupFeatureState = new Map();
const backupMixedState = new Map();
const backupPwState = new Map(); // state menunggu input password untuk backup bersih

function isOwner(id) {
  if (typeof settings.isOwner === 'function') return settings.isOwner(id);
  const ownerStore = require('./data/ownerStore');
  try { return ownerStore.getOwnerIds().map(String).includes(String(id)); } catch (_) {
    return settings.isOwner(id);
  }
}
function loadCfg() { try { return JSON.parse(fs.readFileSync(DEV_FILE, "utf8")); } catch { return { backup: { mode: "off", intervalMs: 0 } }; } }
function saveCfg(v) { fs.mkdirSync(path.dirname(DEV_FILE), { recursive: true }); fs.writeFileSync(DEV_FILE, JSON.stringify(v, null, 2)); }
function safeHtml(s) { return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }

function editPanel(bot, q, text, markup) {
  const o = { chat_id: q.message.chat.id, message_id: q.message.message_id, parse_mode: "HTML", reply_markup: markup };
  if (q.message.photo || q.message.video || q.message.animation || q.message.document)
    return bot.editMessageCaption(text, o).catch(() => bot.editMessageText(text, o));
  return bot.editMessageText(text, o);
}

function sourceFiles() {
  const root = ["index.js", "settings.js", "package.json"];
  const src = fs.existsSync(path.join(ROOT, "src"))
    ? fs.readdirSync(path.join(ROOT, "src")).filter(x => x.endsWith(".js")).sort().map(x => `src/${x}`)
    : [];
  return [...root, ...src];
}

function devHomeText() {
  const a = antikill.getSettings(), b = loadCfg().backup || {};
  let backupInfo = `Mode: <b>${b.mode || "off"}</b>`;
  if (b.intervalMs) backupInfo += `\nInterval: <b>${Math.round(b.intervalMs / 60000)} menit</b>`;
  if (b.nextRun) {
    const diff = b.nextRun - Date.now();
    if (diff > 0) {
      const mnt = Math.ceil(diff / 60000);
      backupInfo += `\nBackup berikutnya: <b>${mnt} menit lagi</b>`;
    }
  }
  return `<b>╭━━〔 DEV CONTROL CENTER 〕━━╮</b>\n<i>Owner-only system controls</i>\n╰━━━━━━━━━━━━━━━━━━━━━━━━╯\n\n<blockquote expandable><b>CODE TOOLS</b>\nAmbil source JS satu per satu atau ganti satu file JS penuh dengan upload baru.\nGunakan /ubahjs untuk ganti file JS via command.</blockquote>\n\n<blockquote expandable><b>ANTI KILL</b>\nMonitor CPU: <b>${a.enabled ? "ON" : "OFF"}</b>\nBatas CPU: <b>${a.cpuThreshold}%</b>\nInterval: <b>${Math.round(a.intervalMs / 60000)} menit</b>\nBatas Disk: <b>${a.diskThresholdMb} MB</b></blockquote>\n\n<blockquote expandable><b>BACKUP</b>\n${backupInfo}</blockquote>`;
}

function autoCpuText() {
  const a = antikill.getSettings();
  return `<blockquote expandable><b>AUTO CEK CPU</b>\n\n` +
    `Status: <b>${a.enabled ? "AKTIF" : "MATI"}</b>\n` +
    `Interval: <b>${Math.round(a.intervalMs / 60000)} menit</b>\n` +
    `Batas CPU: <b>${a.cpuThreshold}%</b>\n\n` +
    `Bot akan mengecek server yang sedang running. Jika CPU melewati batas, server akan diproses otomatis.</blockquote>`;
}
function autoCpuKeyboard() {
  const a = antikill.getSettings();
  return { inline_keyboard: [
    [{ text: a.enabled ? "● AUTO CHECK ON" : "○ AUTO CHECK OFF", callback_data: "dev_cpu_toggle" }],
    [{ text: "1 Menit", callback_data: "dev_cpu_interval:1" }, { text: "5 Menit", callback_data: "dev_cpu_interval:5" }, { text: "10 Menit", callback_data: "dev_cpu_interval:10" }],
    [{ text: "30 Menit", callback_data: "dev_cpu_interval:30" }, { text: "60 Menit", callback_data: "dev_cpu_interval:60" }],
    [{ text: "⏱ Atur Waktu Sendiri", callback_data: "dev_cpu_interval_custom" }],
    [{ text: "− CPU", callback_data: "dev_cpu_threshold_down" }, { text: `Limit ${a.cpuThreshold}%`, callback_data: "dev_noop" }, { text: "+ CPU", callback_data: "dev_cpu_threshold_up" }],
    [{ text: "↻ Cek Sekarang", callback_data: "dev_cpu_run_now" }],
    [{ text: "‹ ‹", callback_data: "devpanel" }]
  ]};
}

function devHomeKeyboard() {
  return { inline_keyboard: [
    [{ text: "⌘ Ambil JS", callback_data: "dev_src_list" }, { text: "⇄ Ganti JS", callback_data: "dev_replace_list" }],
    [{ text: "⚙ Kill Panel", callback_data: "dev_kill_settings" }, { text: "◉ Auto CPU", callback_data: "dev_cpu_settings" }],
    [{ text: "▣ Backup Center", callback_data: "dev_backup" }],
    [{ text: "‹ ‹", callback_data: "back" }]
  ]};
}

// ===== BACKUP: hanya backup file JS yang dipilih =====
async function makeBackupFiles(bot, chatId, files) {
  // files: array of relative paths e.g. ["index.js","src/panel.js"]
  const tmpFile = path.join(ROOT, "lianix.zip");
  return new Promise((resolve, reject) => {
    const output = fs.createWriteStream(tmpFile);
    const archive = archiver("zip", { zlib: { level: 9 } });
    let done = false;
    const fail = e => { if (done) return; done = true; try { output.destroy(); } catch {} reject(e); };
    archive.on("error", fail); output.on("error", fail); archive.pipe(output);
    for (const f of files) {
      const fp = path.join(ROOT, f);
      if (fs.existsSync(fp)) archive.file(fp, { name: f });
    }
    output.on("close", async () => {
      if (done) return; done = true;
      try {
        const mb = fs.statSync(tmpFile).size / 1048576;
        if (mb > 49) throw new Error(`Backup ${mb.toFixed(1)} MB melewati batas Telegram`);
        const label = files.length === 1 ? files[0] : `${files.length} file JS`;
        await bot.sendDocument(chatId, tmpFile, { caption: `▣ Backup selesai: ${label}`, filename: "lianix.zip", contentType: "application/zip" });
        fs.unlinkSync(tmpFile);
        resolve();
      } catch (e) {
        try { if (fs.existsSync(tmpFile)) fs.unlinkSync(tmpFile); } catch {}
        reject(e);
      }
    });
    archive.finalize();
  });
}

// ===== BACKUP: backup seluruh project (mode lama, untuk auto-backup) =====
async function makeBackup(bot, chatId) {
  return new Promise((resolve, reject) => {
    const output = fs.createWriteStream(BACKUP_FILE);
    const archive = archiver("zip", { zlib: { level: 9 } });
    let done = false;
    const fail = e => { if (done) return; done = true; try { output.destroy(); } catch {} reject(e); };
    archive.on("error", fail); output.on("error", fail); archive.pipe(output);
    ["index.js", "settings.js", "package.json"].forEach(f => { const p = path.join(ROOT, f); if (fs.existsSync(p)) archive.file(p, { name: f }); });
    ["src", "db"].forEach(d => { const p = path.join(ROOT, d); if (fs.existsSync(p)) archive.directory(p, d); });
    output.on("close", async () => {
      if (done) return; done = true;
      try {
        const mb = fs.statSync(BACKUP_FILE).size / 1048576;
        if (mb > 49) throw new Error(`Backup ${mb.toFixed(1)} MB melewati batas Telegram`);
        await bot.sendDocument(chatId, BACKUP_FILE, { caption: "▣ Backup selesai", filename: "lianix.zip", contentType: "application/zip" });
        fs.unlinkSync(BACKUP_FILE);
        resolve();
      } catch (e) {
        try { if (fs.existsSync(BACKUP_FILE)) fs.unlinkSync(BACKUP_FILE); } catch {}
        reject(e);
      }
    });
    archive.finalize();
  });
}

// ===== AUTO BACKUP TIMER =====
function restartBackupTimer(bot) {
  if (backupTimers.timer) { clearInterval(backupTimers.timer); backupTimers.timer = null; }
  const c = loadCfg().backup || {};
  if ((c.mode !== "auto" && c.mode !== "custom") || !c.intervalMs) return;

  // catat nextRun ke config supaya bisa ditampilkan
  const scheduleNext = () => {
    const cfg = loadCfg();
    cfg.backup.nextRun = Date.now() + cfg.backup.intervalMs;
    saveCfg(cfg);
  };
  scheduleNext();

  backupTimers.timer = setInterval(async () => {
    try {
      await makeBackup(bot, settings.ownerId);
    } catch (e) {
      await bot.sendMessage(settings.ownerId, `◇ Auto backup gagal: ${safeHtml(e.message)}`, { parse_mode: "HTML" }).catch(() => {});
    }
    scheduleNext();
  }, c.intervalMs);
}

// ===== BACKUP FILE PICKER STATE =====
const backupPickState = new Map(); // userId -> { files: Set, chatId, messageId }

function backupPickText(files) {
  const all = sourceFiles();
  const selected = files.size;
  return `<b>BACKUP — Pilih File JS</b>\n\nPilih file yang mau di-backup. Klik untuk toggle ✓/○.\nDipilih: <b>${selected}</b> file\n\n<i>Tekan "Backup Sekarang" kalau sudah selesai memilih.</i>`;
}

function backupPickKeyboard(selected) {
  const all = sourceFiles();
  const rows = [];
  for (let i = 0; i < all.length; i += 2) {
    rows.push(all.slice(i, i + 2).map(f => ({
      text: `${selected.has(f) ? "✓" : "○"} ${f}`,
      callback_data: `dev_bpick:${Buffer.from(f).toString("base64url")}`
    })));
  }
  rows.push([
    { text: "✓ Semua", callback_data: "dev_bpick_all" },
    { text: "✗ Reset", callback_data: "dev_bpick_reset" }
  ]);
  rows.push([{ text: "▣ Backup Sekarang", callback_data: "dev_bpick_run" }]);
  rows.push([{ text: "‹ ‹", callback_data: "dev_backup" }]);
  return { inline_keyboard: rows };
}



// ===== BACKUP V2 =====
// Feature -> source files.
const BACKUP_FEATURES = {
  core:      { label: "Core & System", files: ["src/start.js","src/main.js","src/menu.js","src/status.js","src/runtimeGuard.js","src/mode.js","src/theme.js","index.js","settings.js","package.json"] },
  am:        { label: "AM Premium", files: ["src/am.js","src/amCustom.js"] },
  group:     { label: "Jaga Grup", files: ["src/group.js","src/groupGuard.js","src/protect.js","src/relaychat.js"] },
  panel:     { label: "Panel & VPS", files: ["src/panel.js","src/panelCreate.js","src/panelToolsV5.js","src/panelsettings.js","src/panelwa.js","src/privateCpanel.js","src/cvps.js","src/cekserver.js"] },
  downloader:{ label: "Downloader / Media", files: ["src/mediaFeatures.js","src/portedPack.js","src/audio.js"] },
  ai:        { label: "AI & Feature Hub", files: ["src/featureHub.js","src/megaFeatures.js","src/extraTools.js","src/random.js"] },
  tools:     { label: "Tools", files: ["src/extraTools.js","src/cekserver.js","src/checklist.js","src/status.js"] },
  roles:     { label: "Role & Access", files: ["src/roleAccess.js","src/limit.js","src/expiry.js","src/redeem.js"] },
  security:  { label: "Encrypt & Security", files: ["src/encrypt.js","src/antikill.js","src/killfix.js"] },
  web:       { label: "Web / Panel Mini", files: ["src/webserver.js","src/optionalCanvas.js","src/install.js"] }
};

function uniqueExistingFiles(files) {
  return [...new Set(files)].filter(f => {
    const n = path.normalize(f);
    return !n.startsWith("..") && !path.isAbsolute(n) && fs.existsSync(path.join(ROOT, n));
  });
}

function sanitizeSettingsForClean(raw) {
  // FULL BERSIH: hanya menghapus nilai yang memang harus diisi pemilik/deployer.
  // Backup biasa TIDAK melewati fungsi ini.
  let out = String(raw || "");

  const blankValue = (key, value = '""') => {
    const re = new RegExp(`(^\\s*${key}\\s*:\\s*)([^,\\n]+)(,?)(\\s*)$`, "gm");
    out = out.replace(re, `$1${value}$3$4`);
  };
  const blankArray = (key) => {
    const re = new RegExp(`(^\\s*${key}\\s*:\\s*)\\[[^\\n]*\\](,?)(\\s*(?://.*)?)$`, "gm");
    out = out.replace(re, `$1[]$2$3`);
  };

  // Nilai deployment/credential milik pemilik SC.
  for (const k of [
    "token", "apikey", "ownerId", "dev", "dana", "notifChannelImage",
    "alightfreeCookie", "apiDigitalOcean", "apiDigitalOcean2", "apiDigitalOcean3",
    "apiDigitalOcean4", "apiDigitalOcean5", "apiDigitalOcean6", "apiDigitalOcean7",
    "apiDigitalOcean8", "apiDigitalOcean9", "apiDigitalOcean10", "pp", "ppVid",
    "panel", "qris", "loc", "allocation", "dockerImagePython"
  ]) blankValue(k);

  blankArray("groupId");
  blankValue("notifChannelId", "null");

  // Web panel publik adalah konfigurasi deployment, bukan bawaan source.
  out = out.replace(/(^\s*url\s*:\s*)[^,\n]+(,?)(\s*)$/gm, '$1""$2$3');

  // Anti-kill deployment-specific settings dibersihkan.
  for (const k of ["enabled", "intervalMs", "cpuThreshold", "diskThresholdMb", "selfIdentifier", "cpuCapPercent"]) {
    const re = new RegExp(`(^\\s*${k}\\s*:\\s*)([^,\\n]+)(,?)(\\s*)$`, "gm");
    const value = k === "enabled" ? "false" : k === "selfIdentifier" ? '""' : "0";
    out = out.replace(re, `$1${value}$3$4`);
  }

  // PENTING: startPassword/checkPassword dan licenseGithub JANGAN disentuh.
  return out;
}

// Inject password baru ke settings.js hasil backup bersih.
// Mengganti hash di _START_PASSWORD_HASH dengan hash dari newPw.
function injectNewPassword(raw, newPw) {
  const hash = crypto.createHash("sha256").update(String(newPw)).digest("hex");
  // Ganti baris _START_PASSWORD_HASH = "..." dengan hash baru
  let out = raw.replace(
    /(const _START_PASSWORD_HASH\s*=\s*")[^"]*(";)/,
    `$1${hash}$2`
  );
  // Juga update komentar "hash dari: ..." kalau ada
  out = out.replace(
    /(\/\/ hash dari:\s*).+/,
    `$1${newPw}`
  );
  return out;
}

// DB yang berisi identitas/access/config yang memang harus diisi ulang oleh pemilik.
// DB operasional (filter, history, statistik, warning, welcome, dll.) TETAP dipertahankan.
function isCleanableDb(relPath) {
  const p = relPath.replace(/\\/g, "/");
  return (
    // owner.json is identity/configuration, not disposable user data.
    // Preserve the currently configured owner in a clean backup so the
    // restored bot does not fall back to the original/default owner.
    p.startsWith("db/users/") ||
    p === "db/panels.json" ||
    p === "db/channels.json" ||
    p === "db/panel.json" ||
    p === "db/panelres.json" ||
    p === "db/cadmin.json" ||
    p === "db/userExpiry.json" ||
    p === "db/redeemRoleExpiry.json" ||
    p === "db/devTools.json"
  );
}

function emptyDbValue(filePath) {
  try {
    const data = JSON.parse(fs.readFileSync(filePath, "utf8"));
    if (Array.isArray(data)) return [];
    if (data && typeof data === "object") return {};
  } catch {}
  return {};
}


function addTreeToArchive(archive, dir, base, options = {}) {
  if (!fs.existsSync(dir)) return;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    const rel = `${base}/${entry.name}`;
    if (entry.name === "node_modules" || entry.name === ".git" || entry.name === ".dev_backups") continue;
    if (entry.isDirectory()) addTreeToArchive(archive, full, rel, options);
    else if (options.cleanDb && rel.startsWith("db/") && entry.name.endsWith(".json")) {
      archive.append(Buffer.from(JSON.stringify(emptyDbValue(full), null, 2)), { name: rel });
    } else archive.file(full, { name: rel });
  }
}

function buildZipFile(files, clean = false) {
  const out = path.join(ROOT, "lianix.zip");
  return new Promise((resolve, reject) => {
    const output = fs.createWriteStream(out);
    const archive = archiver("zip", { zlib: { level: 9 } });
    let finished = false;
    const fail = e => { if (finished) return; finished = true; try { output.destroy(); } catch {} reject(e); };
    archive.on("error", fail); output.on("error", fail); archive.pipe(output);
    for (const f of uniqueExistingFiles(files)) {
      const fp = path.join(ROOT, f);
      if (clean && f === "settings.js") archive.append(Buffer.from(sanitizeSettingsForClean(fs.readFileSync(fp,"utf8"))), { name:f });
      else archive.file(fp, { name:f });
    }
    output.on("close", () => { if (finished) return; finished=true; resolve(out); });
    archive.finalize();
  });
}

function buildFullBackup(clean = false, newPassword = null) {
  const files = ["index.js","settings.js","package.json"];
  const collect = (dir, base) => {
    if (!fs.existsSync(dir)) return;
    for (const dirent of fs.readdirSync(dir,{withFileTypes:true})) {
      const full=path.join(dir,dirent.name), rel=`${base}/${dirent.name}`;
      if (dirent.name === "node_modules" || dirent.name === ".git" || dirent.name === ".dev_backups") continue;
      if (dirent.isDirectory()) collect(full,rel); else files.push(rel);
    }
  };
  collect(path.join(ROOT,"src"),"src");
  collect(path.join(ROOT,"db"),"db");
  collect(path.join(ROOT,"@rexzystore"),"@rexzystore");
  collect(path.join(ROOT,"scripts"),"scripts");
  if (!clean) return buildZipFile(files,false);
  const out = path.join(ROOT, "lianix.zip");
  return new Promise((resolve,reject)=>{
    const output=fs.createWriteStream(out), archive=archiver("zip",{zlib:{level:9}}); let done=false;
    const fail=e=>{if(done)return;done=true;try{output.destroy()}catch{}reject(e)};
    archive.on("error",fail); output.on("error",fail); archive.pipe(output);
    for (const f of files) {
      const fp=path.join(ROOT,f);
      if (!fs.existsSync(fp)) continue;
      if (f === "settings.js") {
        let src = sanitizeSettingsForClean(fs.readFileSync(fp,"utf8"));
        if (newPassword) src = injectNewPassword(src, newPassword);
        archive.append(Buffer.from(src),{name:f});
      } else if (isCleanableDb(f)) archive.append(Buffer.from(JSON.stringify(emptyDbValue(fp),null,2)),{name:f});
      else archive.file(fp,{name:f});
    }
    output.on("close",()=>{if(done)return;done=true;resolve(out)}); archive.finalize();
  });
}

function getAllBackupFiles() {
  const files = ["index.js", "settings.js", "package.json"];
  const collect = (dir, base) => {
    if (!fs.existsSync(dir)) return;
    for (const dirent of fs.readdirSync(dir, { withFileTypes: true })) {
      if (["node_modules", ".git", ".dev_backups"].includes(dirent.name)) continue;
      const full = path.join(dir, dirent.name);
      const rel = `${base}/${dirent.name}`;
      if (dirent.isDirectory()) collect(full, rel);
      else files.push(rel);
    }
  };
  collect(path.join(ROOT, "src"), "src");
  collect(path.join(ROOT, "db"), "db");
  collect(path.join(ROOT, "@rexzystore"), "@rexzystore");
  collect(path.join(ROOT, "scripts"), "scripts");
  return uniqueExistingFiles(files);
}


function startBackupLoading(bot, chatId, messageId, title = "BACKUP", encTotal = 0) {
  let stopped = false;
  let state = { done: 0, total: 0, file: "Menyiapkan...", enc: false, encTotal: Number.isFinite(Number(encTotal)) ? Math.max(0, Number(encTotal)) : 0, startedAt: Date.now() };
  let lastText = "";

  const makeBar = (done, total, width = 18) => {
    const ratio = total > 0 ? Math.max(0, Math.min(1, done / total)) : 0;
    const filled = Math.round(ratio * width);
    return "▰".repeat(filled) + "▱".repeat(width - filled);
  };

  const formatEta = () => {
    if (state.done <= 0 || state.total <= state.done) return "00:00";
    const elapsed = (Date.now() - state.startedAt) / 1000;
    const perFile = elapsed / state.done;
    const eta = Math.max(0, Math.ceil(perFile * (state.total - state.done)));
    const m = Math.floor(eta / 60).toString().padStart(2, "0");
    const sec = (eta % 60).toString().padStart(2, "0");
    return `${m}:${sec}`;
  };

  const render = () => {
    const safeDone = Number.isFinite(Number(state.done)) ? Math.max(0, Number(state.done)) : 0;
    const safeTotal = Number.isFinite(Number(state.total)) ? Math.max(0, Number(state.total)) : 0;
    const percent = safeTotal > 0 ? Math.max(0, Math.min(100, Math.floor((safeDone / safeTotal) * 100))) : 0;
    const bar = makeBar(safeDone, safeTotal);
    const text =
      `⏳ <b>${safeHtml(title)}</b>\n\n` +
      `📁 Memproses file: <code>${safeHtml(state.file)}</code>\n` +
      `<code>[${bar}]</code> <b>${percent}%</b>\n` +
      `📊 Progress: <b>${safeDone}/${safeTotal}</b> file  •  🔐 ENC: <b>${state.encTotal}</b> file\n` +
      `⏱ ETA: <b>${formatEta()}</b>\n\n` +
      `${state.enc ? "🔐 <b>ENC aktif</b> — file ini diproses memakai ENC bawaan bot" : "📄 <b>Original</b> — file ini tidak di-ENC"}\n` +
      `\n🔄 <i>Mohon tunggu, sedang membuat backup lengkap...</i>`;
    return text;
  };

  const update = async (done = state.done, total = state.total, file = state.file, enc = state.enc) => {
    if (stopped) return;
    const safeDone = Number.isFinite(Number(done)) ? Math.max(0, Number(done)) : state.done;
    const safeTotal = Number.isFinite(Number(total)) ? Math.max(0, Number(total)) : state.total;
    state = { ...state, done: safeDone, total: safeTotal, file: String(file || "Menyiapkan..."), enc: Boolean(enc) };
    const text = render();
    if (text === lastText) return;
    lastText = text;
    await bot.editMessageText(text, { chat_id: chatId, message_id: messageId, parse_mode: "HTML" }).catch(() => {});
  };

  const timer = setInterval(() => update(), 3000);
  update();

  return {
    update,
    stop: async (finalText = null) => {
      if (stopped) return;
      stopped = true;
      clearInterval(timer);
      if (finalText) {
        await bot.editMessageText(finalText, {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: "HTML"
        }).catch(() => {});
      }
    }
  };
}

function buildMixedFullBackup(encFiles, level = "high", label = "Backup Lengkap + ENC", progress = null) {
  try { if (fs.existsSync(path.join(ROOT, "lianix.zip"))) fs.unlinkSync(path.join(ROOT, "lianix.zip")); } catch {}
  const selected = new Set(uniqueExistingFiles(encFiles || []).filter(f => f.toLowerCase().endsWith(".js")));
  const files = getAllBackupFiles();
  const out = path.join(ROOT, "lianix.zip");

  return new Promise((resolve, reject) => {
    const output = fs.createWriteStream(out);
    const archive = archiver("zip", { zlib: { level: 9 } });
    let done = false;
    const manifest = [];
    const fail = e => {
      if (done) return;
      done = true;
      try { output.destroy(); } catch {}
      try { if (fs.existsSync(out)) fs.unlinkSync(out); } catch {}
      reject(e);
    };

    archive.on("error", fail);
    output.on("error", fail);
    archive.pipe(output);

    (async () => {
      try {
        let processed = 0;
        for (const f of files) {
          const fp = path.join(ROOT, f);
          processed++;
          if (progress) await progress(processed, files.length, f, selected.has(f));
          if (!fs.existsSync(fp)) continue;

          if (selected.has(f)) {
            // Gunakan encoder yang sama persis dengan command /enc.
            const source = fs.readFileSync(fp, "utf8");
            const obfuscated = await encEngine.obfuscateSource(source, level);
            archive.append(Buffer.from(obfuscated, "utf8"), { name: f });
            manifest.push({ source: f, output: f, encrypted: true, mode: String(level).toUpperCase(), engine: "bot-/enc" });
          } else {
            archive.file(fp, { name: f });
            manifest.push({ source: f, output: f, encrypted: false });
          }
        }

        archive.append(
          Buffer.from(JSON.stringify({
            format: "LIANIX MIXED BACKUP",
            version: 2,
            label,
            encryption: "existing /enc engine",
            encryptedFiles: [...selected],
            files: manifest
          }, null, 2)),
          { name: "LIANIX-ENC-MANIFEST.json" }
        );

        output.on("close", () => {
          if (done) return;
          done = true;
          resolve(out);
        });
        await archive.finalize();
      } catch (e) {
        fail(e);
      }
    })();
  });
}


function buildMixedFullBackupClean(encFiles, level = "high", label = "Backup Lengkap + ENC • Bersih", progress = null, newPassword = null) {
  const selected = new Set(uniqueExistingFiles(encFiles || []).filter(f => f.toLowerCase().endsWith(".js")));
  const files = getAllBackupFiles();
  const out = path.join(ROOT, "lianix.zip");
  try { if (fs.existsSync(out)) fs.unlinkSync(out); } catch {}
  return new Promise((resolve, reject) => {
    const output = fs.createWriteStream(out);
    const archive = archiver("zip", { zlib: { level: 9 } });
    let done = false;
    const fail = e => { if (done) return; done = true; try { output.destroy(); } catch {} try { if (fs.existsSync(out)) fs.unlinkSync(out); } catch {} reject(e); };
    archive.on("error", fail); output.on("error", fail); archive.pipe(output);
    (async () => {
      try {
        let processed = 0;
        for (const f of files) {
          const fp = path.join(ROOT, f);
          processed++;
          if (progress) await progress(processed, files.length, f, selected.has(f));
          if (!fs.existsSync(fp)) continue;
          if (f === "settings.js") {
            let source = sanitizeSettingsForClean(fs.readFileSync(fp, "utf8"));
            if (newPassword) source = injectNewPassword(source, newPassword);
            if (selected.has(f)) source = await encEngine.obfuscateSource(source, level);
            archive.append(Buffer.from(source, "utf8"), { name: f });
          } else if (isCleanableDb(f)) {
            // Hanya DB identitas/access/config yang dibersihkan; DB operasional tetap original.
            archive.append(Buffer.from(JSON.stringify(emptyDbValue(fp), null, 2), "utf8"), { name: f });
          } else if (selected.has(f)) {
            const source = await encEngine.obfuscateSource(fs.readFileSync(fp, "utf8"), level);
            archive.append(Buffer.from(source, "utf8"), { name: f });
          } else archive.file(fp, { name: f });
        }
        archive.append(Buffer.from(JSON.stringify({ format:"LIANIX CLEAN MIXED BACKUP", version:2, label, encryption:"existing /enc engine", settings:"deployment settings + user access + panel/channel config cleared; active owner preserved", preserved:["active owner","startup password","github license","operational db"], cleared:["settings deployment values","db/users/**","db/panels.json","db/channels.json","db/panel.json","db/panelres.json","db/cadmin.json","db/userExpiry.json","db/redeemRoleExpiry.json","db/devTools.json"], encryptedFiles:[...selected] }, null, 2)), { name:"LIANIX-ENC-MANIFEST.json" });
        output.on("close", () => { if (done) return; done = true; resolve(out); });
        await archive.finalize();
      } catch (e) { fail(e); }
    })();
  });
}

async function sendBackupResult(bot, chatId, zipFile, label) {
  try {
    const mb = fs.statSync(zipFile).size / 1048576;
    if (mb > 49) throw new Error(`File ${mb.toFixed(1)} MB melewati batas Telegram`);
    await bot.sendDocument(chatId, zipFile, {
      caption: `<b>◉ BACKUP SELESAI</b>\n\n⌁ Mode: <b>${safeHtml(label)}</b>\n⌁ Size: <b>${mb.toFixed(2)} MB</b>`,
      parse_mode: "HTML",
      filename: "lianix.zip",
      contentType: "application/zip"
    });
  } finally {
    try { if (fs.existsSync(zipFile)) fs.unlinkSync(zipFile); } catch {}
  }
}

function backupFeatureKeyboard(selected, encrypted=false) {
  const rows=[];
  for (const [key,meta] of Object.entries(BACKUP_FEATURES)) rows.push([{text:`${selected.has(key)?"✓":"○"} ${meta.label}`,callback_data:`dev_bfeat:${key}`}]);
  rows.push([{text:"✓ Semua Fitur",callback_data:"dev_bfeat_all"},{text:"✗ Reset",callback_data:"dev_bfeat_reset"}]);
  rows.push([{text:encrypted?"🔐 Backup & ENCRYPT":"▣ Backup Biasa",callback_data:encrypted?"dev_bfeat_run_enc":"dev_bfeat_run"}]);
  rows.push([{text:encrypted?"🔓 Mode Biasa":"🔐 Mode ENCRYPT",callback_data:encrypted?"dev_bfeat_mode_plain":"dev_bfeat_mode_enc"}]);
  rows.push([{text:"‹ ‹",callback_data:"dev_backup"}]);
  return {inline_keyboard:rows};
}
function backupFeatureText(selected, encrypted) {
  return `<b>BACKUP FITUR</b>\n\nPilih fitur yang mau dimasukkan ke backup.${encrypted?"\n\n🔐 <b>Mode ENCRYPT aktif</b>":"\n\n▣ <b>Mode biasa</b>"}\n\nDipilih: <b>${selected.size}</b> fitur`;
}

function filesCountSafe(zipFile) {
  try {
    const AdmZip = require("adm-zip");
    return new AdmZip(zipFile).getEntries().length;
  } catch {
    return "selesai";
  }
}

function register(bot) {
  restartBackupTimer(bot);

  // ===== CALLBACK HANDLER =====
  bot.on("callback_query", async q => {
    const d = q.data;
    if (!d || !d.startsWith("dev_")) return;
    if (!isOwner(q.from.id)) return bot.answerCallbackQuery(q.id, { text: "Khusus owner", show_alert: true });
    await bot.answerCallbackQuery(q.id).catch(() => {});
    const uid = q.from.id;

    // Home
    if (d === "devtools_home") { return editPanel(bot, q, devHomeText(), devHomeKeyboard()); }

    if (d === "dev_cpu_settings") {
      return editPanel(bot, q, autoCpuText(), autoCpuKeyboard());
    }

    if (d === "dev_cpu_toggle") {
      const on = !antikill.getSettings().enabled;
      antikill.setEnabled(bot, on);
      return editPanel(bot, q, autoCpuText(), autoCpuKeyboard());
    }

    if (d.startsWith("dev_cpu_interval:")) {
      const min = Number(d.split(":")[1]);
      if (!Number.isFinite(min)) return;
      antikill.setIntervalMs(min * 60000);
      return editPanel(bot, q, autoCpuText(), autoCpuKeyboard());
    }

    if (d === "dev_cpu_interval_custom") {
      customCpuIntervalState.set(uid, { chatId: q.message.chat.id });
      return bot.sendMessage(
        q.message.chat.id,
        `<blockquote expandable><b>ATUR INTERVAL AUTO CEK CPU</b>\n\nKirim angka menit.\nContoh: <code>15</code> = cek setiap 15 menit.\nMinimal 1 menit, maksimal 1440 menit.\n\nKetik /batal untuk membatalkan.</blockquote>`,
        { parse_mode: "HTML" }
      );
    }

    if (d === "dev_cpu_threshold_up" || d === "dev_cpu_threshold_down") {
      const a = antikill.getSettings();
      const next = a.cpuThreshold + (d.endsWith("up") ? 10 : -10);
      antikill.setCpuThreshold(Math.max(10, Math.min(5000, next)));
      return editPanel(bot, q, autoCpuText(), autoCpuKeyboard());
    }

    if (d === "dev_cpu_run_now") {
      const wait = await bot.sendMessage(q.message.chat.id, "<blockquote expandable>↻ <b>AUTO CEK CPU</b>\nSedang mengecek semua server...</blockquote>", { parse_mode: "HTML" });
      try {
        const result = await antikill.runCheck(bot);
        const abnormal = result.flagged?.length || 0;
        const text = abnormal
          ? `⚠️ <b>CEK CPU SELESAI</b>\n\nServer diperiksa: <b>${result.checked}</b>\nServer abnormal: <b>${abnormal}</b>\n\n` +
            result.flagged.map((f,i) => `• ${i+1} <b>${safeHtml(f.name)}</b> — ${Number(f.cpuPct).toFixed(2)}% (${f.suspended ? "DiSTOP" : f.selfServer ? "Dilewati" : "Gagal diSTOP"})`).join("\n")
          : `✅ <b>CEK CPU SELESAI</b>\n\nServer diperiksa: <b>${result.checked}</b>\nTidak ada server yang melewati batas CPU <b>${antikill.getSettings().cpuThreshold}%</b>.`;
        await bot.editMessageText(text, { chat_id: wait.chat.id, message_id: wait.message_id, parse_mode: "HTML" }).catch(() => {});
      } catch (e) {
        await bot.editMessageText(`❌ <b>CEK CPU GAGAL</b>\n<code>${safeHtml(e.message)}</code>`, { chat_id: wait.chat.id, message_id: wait.message_id, parse_mode: "HTML" }).catch(() => {});
      }
      return;
    }


    // Ambil JS list
    if (d === "dev_src_list") {
      const files = sourceFiles();
      const rows = [];
      for (let i = 0; i < files.length; i += 2) {
        rows.push(files.slice(i, i + 2).map(f => ({
          text: "⌘ " + f,
          callback_data: `dev_source:${Buffer.from(f).toString("base64url")}`
        })));
      }
      rows.push([{ text: "‹ ‹", callback_data: "devpanel" }]);
      return editPanel(bot, q, `<b>SOURCE JS</b>\n\nPilih file untuk diunduh.`, { inline_keyboard: rows });
    }

    // Ganti JS list (via tombol, lama)
    if (d === "dev_replace_list") {
      const files = sourceFiles();
      const rows = [];
      for (let i = 0; i < files.length; i += 2) {
        rows.push(files.slice(i, i + 2).map(f => ({
          text: "⇄ " + f,
          callback_data: `dev_replace:${Buffer.from(f).toString("base64url")}`
        })));
      }
      rows.push([{ text: "‹ ‹", callback_data: "devpanel" }]);
      return editPanel(bot, q, `<b>REPLACE JS</b>\n\nPilih file yang mau diganti, lalu kirim file .js baru.`, { inline_keyboard: rows });
    }

    // Kirim satu file JS
    if (d.startsWith("dev_source:")) {
      const f = Buffer.from(d.split(":")[1], "base64url").toString();
      if (!sourceFiles().includes(f)) return;
      const fp = path.join(ROOT, f);
      return bot.sendDocument(q.message.chat.id, fp, { caption: `⌘ ${f}`, filename: path.basename(f), contentType: "application/javascript" }).catch(e => bot.sendMessage(q.message.chat.id, `◇ Gagal kirim: ${safeHtml(e.message)}`));
    }

    // Mulai replace flow via tombol
    if (d.startsWith("dev_replace:")) {
      const f = Buffer.from(d.split(":")[1], "base64url").toString();
      if (!sourceFiles().includes(f)) return;
      sourceState.set(uid, { file: f, chatId: q.message.chat.id, messageId: q.message.message_id });
      return bot.sendMessage(q.message.chat.id,
        `<blockquote expandable><b>REPLACE ${safeHtml(f)}</b>\nKirim file <b>.js</b> baru sebagai document. File lama disimpan ke backup internal.\n\n/batal untuk batal.</blockquote>`,
        { parse_mode: "HTML", reply_to_message_id: q.message.message_id });
    }

    // Kill panel settings
    if (d === "dev_kill_settings") {
      const a = antikill.getSettings();
      const kb = { inline_keyboard: [
        [{ text: "− CPU", callback_data: "dev_kill_cpu_down" }, { text: `CPU ${a.cpuThreshold}%`, callback_data: "dev_noop" }, { text: "+ CPU", callback_data: "dev_kill_cpu_up" }],
        [{ text: "− Disk", callback_data: "dev_kill_disk_down" }, { text: `Disk ${a.diskThresholdMb} MB`, callback_data: "dev_noop" }, { text: "+ Disk", callback_data: "dev_kill_disk_up" }],
        [{ text: a.enabled ? "● Auto Check ON" : "○ Auto Check OFF", callback_data: "dev_cpu_toggle" }],
        [{ text: "✓ Selesai", callback_data: "devpanel" }]
      ]};
      return editPanel(bot, q, `<b>KILL PANEL SETTINGS</b>\n\nAtur batas resource dengan tombol + / −.\nCPU sekarang: <b>${a.cpuThreshold}%</b>\nDisk sekarang: <b>${a.diskThresholdMb} MB</b>\nAuto CPU check: <b>${a.enabled ? "ON" : "OFF"}</b>`, kb);
    }
    if (d === "dev_cpu_toggle") { const on = !antikill.getSettings().enabled; antikill.setEnabled(bot, on); return editPanel(bot, q, devHomeText(), devHomeKeyboard()); }
    if (d === "dev_kill_cpu_up" || d === "dev_kill_cpu_down") {
      const a = antikill.getSettings(); antikill.setCpuThreshold(a.cpuThreshold + (d.endsWith("up") ? 10 : -10));
      const n = antikill.getSettings();
      return editPanel(bot, q, `<b>KILL PANEL SETTINGS</b>\n\nCPU: <b>${n.cpuThreshold}%</b>\nDisk: <b>${n.diskThresholdMb} MB</b>`, { inline_keyboard: [
        [{ text: "− CPU", callback_data: "dev_kill_cpu_down" }, { text: `CPU ${n.cpuThreshold}%`, callback_data: "dev_noop" }, { text: "+ CPU", callback_data: "dev_kill_cpu_up" }],
        [{ text: "− Disk", callback_data: "dev_kill_disk_down" }, { text: `Disk ${n.diskThresholdMb} MB`, callback_data: "dev_noop" }, { text: "+ Disk", callback_data: "dev_kill_disk_up" }],
        [{ text: "✓ Selesai", callback_data: "devpanel" }]
      ]});
    }
    if (d === "dev_kill_disk_up" || d === "dev_kill_disk_down") {
      const a = antikill.getSettings(); antikill.setDiskThreshold(a.diskThresholdMb + (d.endsWith("up") ? 256 : -256));
      const n = antikill.getSettings();
      return editPanel(bot, q, `<b>KILL PANEL SETTINGS</b>\n\nCPU: <b>${n.cpuThreshold}%</b>\nDisk: <b>${n.diskThresholdMb} MB</b>`, { inline_keyboard: [
        [{ text: "− CPU", callback_data: "dev_kill_cpu_down" }, { text: `CPU ${n.cpuThreshold}%`, callback_data: "dev_noop" }, { text: "+ CPU", callback_data: "dev_kill_cpu_up" }],
        [{ text: "− Disk", callback_data: "dev_kill_disk_down" }, { text: `Disk ${n.diskThresholdMb} MB`, callback_data: "dev_noop" }, { text: "+ Disk", callback_data: "dev_kill_disk_up" }],
        [{ text: "✓ Selesai", callback_data: "devpanel" }]
      ]});
    }

    // ===== BACKUP CENTER =====
    if (d === "dev_backup") {
      const c = loadCfg().backup || {};
      let info = `Mode: <b>${c.mode || "off"}</b>`;
      if (c.intervalMs) info += `\nInterval: <b>${Math.round(c.intervalMs / 60000)} menit</b>`;
      if (c.nextRun && c.nextRun > Date.now()) info += `\nBackup berikutnya: <b>${Math.ceil((c.nextRun - Date.now()) / 60000)} menit lagi</b>`;
      return editPanel(bot, q, `<b>BACKUP CENTER</b>\n\n${info}\n\nPilih metode backup.`, { inline_keyboard: [
        [{ text: "🧼 Full Bersih • Reset Data Pemilik", callback_data: "dev_backup_clean" }],
        [{ text: "🧼🔐 Full Bersih + ENC • Reset Data Pemilik", callback_data: "dev_backup_mixed_enc_clean" }],
        [{ text: "◉ Full Backup • Semua Data", callback_data: "dev_backup_now" }],
        [{ text: "🔐 Backup Lengkap • Pilih ENC", callback_data: "dev_backup_mixed_enc" }],
        [{ text: "🧩 Pilih Fitur", callback_data: "dev_backup_features" }, { text: "🔐 Pilih + ENCRYPT", callback_data: "dev_backup_features_enc" }],
        [{ text: "◉ Backup Pilih JS", callback_data: "dev_backup_pick" }],
        [{ text: "↻ Auto 30 Menit", callback_data: "dev_backup_30" }],
        [{ text: "⌁ Atur Waktu Auto", callback_data: "dev_backup_custom" }],
        [{ text: "■ Matikan Auto", callback_data: "dev_backup_off" }],
        [{ text: "‹ ‹", callback_data: "devpanel" }]
      ]});
    }

    // Full backup bersih: source lengkap, data DB yang bisa dibersihkan dikosongkan;
    // identitas owner tetap dipertahankan agar owner aktif tidak kembali ke default.
    if (d === "dev_backup_clean") {
      backupPwState.set(uid, { type: "clean", chatId: q.message.chat.id });
      await bot.sendMessage(q.message.chat.id,
        "<blockquote expandable><b>🧼 FULL BERSIH — SET PASSWORD</b>\n\nMasukkan <b>password baru</b> untuk backup ini.\nPassword ini akan dipakai sebagai password startup bot oleh pembeli.\n\nKetik password lalu kirim. Minimal 4 karakter.\n/batal untuk batal.</blockquote>",
        { parse_mode: "HTML", reply_to_message_id: q.message.message_id }
      );
      return;
    }

    if (d === "dev_backup_mixed_enc_clean") {
      const files = sourceFiles().filter(f => f.toLowerCase().endsWith(".js"));
      const selected = new Set();
      backupMixedState.set(uid, { selected, files, chatId: q.message.chat.id, messageId: q.message.message_id, clean: true });
      const rows = [];
      for (let i = 0; i < files.length; i += 2) rows.push(files.slice(i, i + 2).map(f => ({ text: `☐ ${f}`, callback_data: `dev_menc:${Buffer.from(f).toString("base64url")}` })));
      rows.push([{ text: "☑ Pilih Semua", callback_data: "dev_menc_all" }, { text: "↺ Reset", callback_data: "dev_menc_reset" }]);
      rows.push([{ text: "🧼🔐 Lanjut & Set Password", callback_data: "dev_menc_run" }]);
      rows.push([{ text: "‹ ‹", callback_data: "dev_backup" }]);
      return editPanel(bot, q, "<b>FULL BERSIH + ENC</b>\n\nSeluruh project tetap masuk ZIP.\nSemua database JSON dikosongkan dan <b>semua nilai settings.js dikosongkan</b>.\nHanya file JS yang dipilih yang diproses memakai <b>ENC bawaan bot</b>.\n\n⚠ Setelah pilih file, kamu akan diminta input <b>password baru</b> untuk backup ini.", { inline_keyboard: rows });
    }

    if (d === "dev_backup_mixed_enc") {
      const files = sourceFiles().filter(f => f.toLowerCase().endsWith(".js"));
      const selected = new Set();
      backupMixedState.set(uid, { selected, files, chatId: q.message.chat.id, messageId: q.message.message_id });

      const rows = [];
      for (let i = 0; i < files.length; i += 2) {
        rows.push(files.slice(i, i + 2).map(f => ({
          text: `☐ ${f}`,
          callback_data: `dev_menc:${Buffer.from(f).toString("base64url")}`
        })));
      }
      rows.push([{ text: "☑ Pilih Semua", callback_data: "dev_menc_all" }, { text: "↺ Reset", callback_data: "dev_menc_reset" }]);
      rows.push([{ text: "🔐 Backup Lengkap + ENC", callback_data: "dev_menc_run" }]);
      rows.push([{ text: "‹ ‹", callback_data: "dev_backup" }]);

      return editPanel(bot, q,
        "<b>BACKUP LENGKAP + ENC</b>\n\n" +
        "Backup tetap memasukkan <b>seluruh project</b>.\n" +
        "Hanya file JS yang dicentang yang akan diproses memakai <b>ENC bawaan bot</b> dan tetap disimpan sebagai <code>.js</code>.\n" +
        "File yang tidak dicentang tetap original.\n\n" +
        "Contoh: centang <code>src/start.js</code> dan <code>index.js</code> → keduanya menjadi JS ter-ENC yang tetap bisa dijalankan.",
        { inline_keyboard: rows });
    }

    if (d.startsWith("dev_menc:")) {
      const st = backupMixedState.get(uid);
      if (!st) return;
      const f = Buffer.from(d.split(":")[1], "base64url").toString();
      if (!st.files.includes(f)) return;
      st.selected.has(f) ? st.selected.delete(f) : st.selected.add(f);

      const rows = [];
      for (let i = 0; i < st.files.length; i += 2) {
        rows.push(st.files.slice(i, i + 2).map(file => ({
          text: `${st.selected.has(file) ? "☑" : "☐"} ${file}`,
          callback_data: `dev_menc:${Buffer.from(file).toString("base64url")}`
        })));
      }
      rows.push([{ text: "☑ Pilih Semua", callback_data: "dev_menc_all" }, { text: "↺ Reset", callback_data: "dev_menc_reset" }]);
      rows.push([{ text: "🔐 Backup Lengkap + ENC", callback_data: "dev_menc_run" }]);
      rows.push([{ text: "‹ ‹", callback_data: "dev_backup" }]);
      return editPanel(bot, q,
        `<b>BACKUP LENGKAP + ENC</b>\n\nDipilih: <b>${st.selected.size}</b> file JS\nFile lain tetap original.`,
        { inline_keyboard: rows });
    }

    if (d === "dev_menc_all" || d === "dev_menc_reset") {
      const st = backupMixedState.get(uid);
      if (!st) return;
      if (d === "dev_menc_all") st.files.forEach(f => st.selected.add(f));
      else st.selected.clear();

      const rows = [];
      for (let i = 0; i < st.files.length; i += 2) {
        rows.push(st.files.slice(i, i + 2).map(file => ({
          text: `${st.selected.has(file) ? "☑" : "☐"} ${file}`,
          callback_data: `dev_menc:${Buffer.from(file).toString("base64url")}`
        })));
      }
      rows.push([{ text: "☑ Pilih Semua", callback_data: "dev_menc_all" }, { text: "↺ Reset", callback_data: "dev_menc_reset" }]);
      rows.push([{ text: "🔐 Backup Lengkap + ENC", callback_data: "dev_menc_run" }]);
      rows.push([{ text: "‹ ‹", callback_data: "dev_backup" }]);
      return editPanel(bot, q,
        `<b>BACKUP LENGKAP + ENC</b>\n\nDipilih: <b>${st.selected.size}</b> file JS\nFile lain tetap original.`,
        { inline_keyboard: rows });
    }

    if (d === "dev_menc_run") {
      const st = backupMixedState.get(uid);
      if (!st) return;
      if (!st.selected.size) {
        return bot.answerCallbackQuery(q.id, { text: "Pilih minimal 1 file JS untuk ENC.", show_alert: true });
      }
      // Jika mode clean, minta password dulu sebelum generate backup
      if (st.clean) {
        backupPwState.set(uid, { type: "clean_enc", chatId: q.message.chat.id, encSelected: [...st.selected] });
        backupMixedState.delete(uid);
        await bot.sendMessage(q.message.chat.id,
          "<blockquote expandable><b>🧼🔐 FULL BERSIH + ENC — SET PASSWORD</b>\n\nMasukkan <b>password baru</b> untuk backup ini.\nPassword ini akan dipakai sebagai password startup bot oleh pembeli.\n\nKetik password lalu kirim. Minimal 4 karakter.\n/batal untuk batal.</blockquote>",
          { parse_mode: "HTML", reply_to_message_id: q.message.message_id }
        );
        return;
      }
      backupMixedState.delete(uid);
      try {
        const loadingMsg = await bot.sendMessage(q.message.chat.id,
          "⏳ <b>BACKUP LENGKAP + ENC</b>\n\nMenyiapkan proses...",
          { parse_mode: "HTML", reply_to_message_id: q.message.message_id });
        const loading = startBackupLoading(bot, q.message.chat.id, loadingMsg.message_id, "BACKUP LENGKAP + ENC", st.selected.size);
        const zip = await buildMixedFullBackup([...st.selected], "high", "Backup Lengkap + ENC", async (done, total, file, enc) => {
          await loading.update(done, total, file, enc);
        });
        const sizeMb = fs.existsSync(zip) ? (fs.statSync(zip).size / 1048576).toFixed(2) : "0.00";
        await loading.stop(
          `✅ <b>BACKUP LENGKAP + ENC SELESAI</b>\n\n` +
          `<code>[${"▰".repeat(18)}]</code> <b>100%</b>\n` +
          `📦 Total file: <b>${filesCountSafe(zip)}</b>\n` +
          `🔐 File di-ENC: <b>${st.selected.size}</b>\n` +
          `💾 Ukuran ZIP: <b>${sizeMb} MB</b>\n\n` +
          `File terpilih di-ENC, file lain original.\n📤 Mengirim <b>lianix.zip</b> ke chat...`
        );
        await sendBackupResult(bot, q.message.chat.id, zip, `lianix.zip • Backup Lengkap + ENC (${st.selected.size} file)`);
      } catch (e) {
        await bot.sendMessage(q.message.chat.id, `◇ Backup ENC gagal: ${safeHtml(e.message)}`, { parse_mode: "HTML" });
      }
      return;
    }

    if (d === "dev_backup_full_enc") {
      try {
        const allJs = getAllBackupFiles().filter(f => f.toLowerCase().endsWith(".js"));
        await bot.sendMessage(q.message.chat.id,"↻ <b>FULL BACKUP + ENC</b>\nMenggunakan ENC bawaan bot, tanpa password...",{parse_mode:"HTML",reply_to_message_id:q.message.message_id});
        const zip=await buildMixedFullBackup(allJs,"high","Full Backup + ENC");
        await sendBackupResult(bot,q.message.chat.id,zip,"Full Backup + ENC");
      } catch(e) { await bot.sendMessage(q.message.chat.id,`◇ Full backup ENC gagal: ${safeHtml(e.message)}`,{parse_mode:"HTML"}); }
      return;
    }

    if (d === "dev_backup_features" || d === "dev_backup_features_enc") {
      const enc=d.endsWith("_enc");
      backupFeatureState.set(uid,{selected:new Set(),encrypted:enc,chatId:q.message.chat.id});
      return editPanel(bot,q,backupFeatureText(new Set(),enc),backupFeatureKeyboard(new Set(),enc));
    }

    if (d.startsWith("dev_bfeat:")) {
      const st=backupFeatureState.get(uid); if(!st) return;
      const key=d.split(":")[1]; if(!BACKUP_FEATURES[key]) return;
      st.selected.has(key)?st.selected.delete(key):st.selected.add(key);
      return editPanel(bot,q,backupFeatureText(st.selected,st.encrypted),backupFeatureKeyboard(st.selected,st.encrypted));
    }
    if (d === "dev_bfeat_all" || d === "dev_bfeat_reset") {
      const st=backupFeatureState.get(uid); if(!st)return;
      if(d.endsWith("all")) Object.keys(BACKUP_FEATURES).forEach(k=>st.selected.add(k)); else st.selected.clear();
      return editPanel(bot,q,backupFeatureText(st.selected,st.encrypted),backupFeatureKeyboard(st.selected,st.encrypted));
    }
    if (d === "dev_bfeat_mode_enc" || d === "dev_bfeat_mode_plain") {
      const st=backupFeatureState.get(uid); if(!st)return;
      st.encrypted=d.endsWith("enc");
      return editPanel(bot,q,backupFeatureText(st.selected,st.encrypted),backupFeatureKeyboard(st.selected,st.encrypted));
    }
    if (d === "dev_bfeat_run" || d === "dev_bfeat_run_enc") {
      const st=backupFeatureState.get(uid); if(!st || !st.selected.size) return bot.answerCallbackQuery(q.id,{text:"Pilih minimal 1 fitur",show_alert:true});
      if(d.endsWith("_enc")) {
        try {
          const files=[...st.selected].flatMap(k=>BACKUP_FEATURES[k].files);
          backupFeatureState.delete(uid);
          const zip=await buildMixedFullBackup(files, "high", `Backup Fitur + ENC: ${[...st.selected].map(k=>BACKUP_FEATURES[k].label).join(", ")}`);
          await sendBackupResult(bot,q.message.chat.id,zip,`Fitur + ENC: ${[...st.selected].map(k=>BACKUP_FEATURES[k].label).join(", ")}`);
        } catch(e) { await bot.sendMessage(q.message.chat.id,`◇ Backup fitur ENC gagal: ${safeHtml(e.message)}`,{parse_mode:"HTML"}); }
        return;
      }
      try {
        const files=[...st.selected].flatMap(k=>BACKUP_FEATURES[k].files);
        backupFeatureState.delete(uid);
        const zip=await buildZipFile(files,false);
        await sendBackupResult(bot,q.message.chat.id,zip,`Fitur: ${[...st.selected].map(k=>BACKUP_FEATURES[k].label).join(", ")}`);
      } catch(e) { await bot.sendMessage(q.message.chat.id,`◇ Backup fitur gagal: ${safeHtml(e.message)}`,{parse_mode:"HTML"}); }
      return;
    }

    // Backup semua sekarang
    if (d === "dev_backup_now") {
      try {
        await bot.sendMessage(q.message.chat.id, "↻ Membuat backup seluruh project...");
        await makeBackup(bot, q.message.chat.id);
      } catch (e) {
        await bot.sendMessage(q.message.chat.id, `◇ Backup gagal: ${safeHtml(e.message)}`, { parse_mode: "HTML" });
      }
      return;
    }

    // Backup pilih file JS
    if (d === "dev_backup_pick") {
      const sel = new Set();
      backupPickState.set(uid, { files: sel, chatId: q.message.chat.id, messageId: q.message.message_id });
      return editPanel(bot, q, backupPickText(sel), backupPickKeyboard(sel));
    }

    // Toggle file di picker
    if (d.startsWith("dev_bpick:")) {
      const st = backupPickState.get(uid);
      if (!st) return;
      const f = Buffer.from(d.split(":")[1], "base64url").toString();
      if (st.files.has(f)) st.files.delete(f); else st.files.add(f);
      return editPanel(bot, q, backupPickText(st.files), backupPickKeyboard(st.files));
    }

    // Pilih semua
    if (d === "dev_bpick_all") {
      const st = backupPickState.get(uid);
      if (!st) return;
      sourceFiles().forEach(f => st.files.add(f));
      return editPanel(bot, q, backupPickText(st.files), backupPickKeyboard(st.files));
    }

    // Reset pilihan
    if (d === "dev_bpick_reset") {
      const st = backupPickState.get(uid);
      if (!st) return;
      st.files.clear();
      return editPanel(bot, q, backupPickText(st.files), backupPickKeyboard(st.files));
    }

    // Jalankan backup file terpilih
    if (d === "dev_bpick_run") {
      const st = backupPickState.get(uid);
      if (!st || st.files.size === 0) {
        return bot.answerCallbackQuery(q.id, { text: "◇ Belum ada file yang dipilih.", show_alert: true });
      }
      const selected = [...st.files];
      backupPickState.delete(uid);
      try {
        await bot.sendMessage(q.message.chat.id, `↻ Membackup ${selected.length} file JS...`);
        await makeBackupFiles(bot, q.message.chat.id, selected);
      } catch (e) {
        await bot.sendMessage(q.message.chat.id, `◇ Backup gagal: ${safeHtml(e.message)}`, { parse_mode: "HTML" });
      }
      return;
    }

    // Auto 30 menit
    if (d === "dev_backup_30") {
      const c = loadCfg(); c.backup = { mode: "auto", intervalMs: 1800000 }; saveCfg(c);
      restartBackupTimer(bot);
      await bot.sendMessage(q.message.chat.id, "◉ Auto backup diset tiap <b>30 menit</b>.", { parse_mode: "HTML" });
      return editPanel(bot, q, devHomeText(), devHomeKeyboard());
    }

    // Matikan auto
    if (d === "dev_backup_off") {
      const c = loadCfg(); c.backup = { mode: "off", intervalMs: 0 }; saveCfg(c);
      restartBackupTimer(bot);
      await bot.sendMessage(q.message.chat.id, "■ Auto backup dimatikan.");
      return editPanel(bot, q, devHomeText(), devHomeKeyboard());
    }

    // Custom timer
    if (d === "dev_backup_custom") {
      customBackupState.set(uid, { chatId: q.message.chat.id, messageId: q.message.message_id });
      return bot.sendMessage(q.message.chat.id,
        "<blockquote expandable><b>ATUR WAKTU AUTO BACKUP</b>\nKirim interval dalam menit.\nContoh: <code>60</code> = backup tiap 1 jam.\nMinimal 5 menit, maksimal 10080 menit (7 hari).\n\n/batal untuk batal.</blockquote>",
        { parse_mode: "HTML", reply_to_message_id: q.message.message_id });
    }
  });

  // noop
  bot.on("callback_query", q => { if (q.data === "dev_noop") bot.answerCallbackQuery(q.id).catch(() => {}); });

  // ===== MESSAGE HANDLER =====
  bot.on("message", async msg => {
    const uid = msg.from?.id;
    if (!uid || !isOwner(uid)) return;

    // Replace JS via tombol (lama)
    if (sourceState.has(uid)) {
      const st = sourceState.get(uid);
      if (msg.text === "/batal") { sourceState.delete(uid); return bot.sendMessage(msg.chat.id, "◇ Replace dibatalkan."); }
      const doc = msg.document;
      if (!doc || !doc.file_name?.toLowerCase().endsWith(".js"))
        return bot.sendMessage(msg.chat.id, "◇ Kirim document .js baru atau /batal.");
      const target = st.file;
      try {
        const data = await bot.getFileLink(doc.file_id);
        const fetch = (await import("node-fetch")).default;
        const res = await fetch(data);
        if (!res.ok) throw new Error(`Download gagal ${res.status}`);
        const buf = Buffer.from(await res.arrayBuffer());
        const dest = path.join(ROOT, target);
        const backupDir = path.join(ROOT, ".dev_backups");
        fs.mkdirSync(backupDir, { recursive: true });
        if (fs.existsSync(dest)) fs.copyFileSync(dest, path.join(backupDir, `${Date.now()}_${path.basename(target)}`));
        fs.writeFileSync(dest, buf);
        sourceState.delete(uid);
        return bot.sendMessage(msg.chat.id,
          `<blockquote expandable>◉ <b>FILE DIGANTI</b>\n${safeHtml(target)} berhasil diganti.\nBackup file lama tersimpan di .dev_backups.\nRestart bot diperlukan untuk memuat kode baru.</blockquote>`,
          { parse_mode: "HTML" });
      } catch (e) {
        return bot.sendMessage(msg.chat.id, `◇ Gagal mengganti file: ${safeHtml(e.message)}`, { parse_mode: "HTML" });
      }
    }

    // Replace JS via /ubahjs (baru)
    if (ubahJsState.has(uid)) {
      const st = ubahJsState.get(uid);
      if (msg.text === "/batal") { ubahJsState.delete(uid); return bot.sendMessage(msg.chat.id, "◇ Ubah JS dibatalkan."); }
      const doc = msg.document;
      if (!doc || !doc.file_name?.toLowerCase().endsWith(".js"))
        return bot.sendMessage(msg.chat.id, "◇ Kirim file .js baru atau /batal.");
      const target = st.file;
      try {
        const data = await bot.getFileLink(doc.file_id);
        const fetch = (await import("node-fetch")).default;
        const res = await fetch(data);
        if (!res.ok) throw new Error(`Download gagal ${res.status}`);
        const buf = Buffer.from(await res.arrayBuffer());
        const dest = path.join(ROOT, target);
        const backupDir = path.join(ROOT, ".dev_backups");
        fs.mkdirSync(backupDir, { recursive: true });
        if (fs.existsSync(dest)) fs.copyFileSync(dest, path.join(backupDir, `${Date.now()}_${path.basename(target)}`));
        fs.writeFileSync(dest, buf);
        ubahJsState.delete(uid);
        return bot.sendMessage(msg.chat.id,
          `<blockquote expandable>◉ <b>BERHASIL DIUBAH</b>\n📄 File: <code>${safeHtml(target)}</code>\n✓ File lama disimpan ke .dev_backups.\n⚠ Restart bot untuk memuat perubahan.</blockquote>`,
          { parse_mode: "HTML" });
      } catch (e) {
        return bot.sendMessage(msg.chat.id, `◇ Gagal mengubah file: ${safeHtml(e.message)}`, { parse_mode: "HTML" });
      }
    }

    // Custom CPU interval input
    if (customCpuIntervalState.has(uid) && msg.text) {
      const st = customCpuIntervalState.get(uid);
      if (msg.text === "/batal") {
        customCpuIntervalState.delete(uid);
        return bot.sendMessage(msg.chat.id, "◇ Pengaturan interval CPU dibatalkan.");
      }
      const min = Number(String(msg.text).replace(",", "."));
      if (!Number.isFinite(min) || min < 1 || min > 1440) {
        return bot.sendMessage(msg.chat.id, "◇ Masukkan menit antara 1–1440.");
      }
      antikill.setIntervalMs(Math.round(min * 60000));
      customCpuIntervalState.delete(uid);
      await bot.sendMessage(msg.chat.id, `◉ Auto cek CPU diset tiap <b>${min} menit</b>.`, { parse_mode: "HTML" });
      return;
    }

    // Custom backup interval input
    if (customBackupState.has(uid) && msg.text) {
      const st = customBackupState.get(uid);
      if (msg.text === "/batal") { customBackupState.delete(uid); return bot.sendMessage(msg.chat.id, "◇ Custom backup dibatalkan."); }
      const min = Number(msg.text.replace(",", "."));
      if (!Number.isFinite(min) || min < 5 || min > 10080)
        return bot.sendMessage(msg.chat.id, "◇ Masukkan menit antara 5–10080.");
      const c = loadCfg();
      c.backup = { mode: "custom", intervalMs: Math.round(min * 60000) };
      saveCfg(c);
      customBackupState.delete(uid);
      restartBackupTimer(bot);
      return bot.sendMessage(msg.chat.id,
        `◉ Auto backup diset tiap <b>${min} menit</b>.\nBackup pertama akan berjalan ${min} menit lagi.`,
        { parse_mode: "HTML" });
    }

    // ===== HANDLER INPUT PASSWORD BACKUP BERSIH =====
    if (backupPwState.has(uid) && msg.text) {
      const pwSt = backupPwState.get(uid);
      if (msg.text === "/batal") {
        backupPwState.delete(uid);
        return bot.sendMessage(msg.chat.id, "◇ Backup dibatalkan.");
      }
      const newPw = msg.text.trim();
      if (newPw.length < 4) {
        return bot.sendMessage(msg.chat.id, "◇ Password terlalu pendek. Minimal 4 karakter. Coba lagi atau /batal.");
      }
      backupPwState.delete(uid);

      if (pwSt.type === "clean") {
        // Full Bersih biasa
        const progressMsg = await bot.sendMessage(pwSt.chatId, "🧼 Membuat Full Bersih...");
        try {
          const zip = await buildFullBackup(true, newPw);
          await bot.editMessageText(
            `✅ Full Bersih selesai!\n🔑 Password backup: <code>${safeHtml(newPw)}</code>\n📤 Mengirim lianix.zip...`,
            { chat_id: pwSt.chatId, message_id: progressMsg.message_id, parse_mode: "HTML" }
          ).catch(() => {});
          await sendBackupResult(bot, pwSt.chatId, zip, `Full Bersih • password: ${newPw}`);
        } catch (e) {
          await bot.sendMessage(pwSt.chatId, `◇ Full Bersih gagal: ${safeHtml(e.message)}`, { parse_mode: "HTML" });
        }
      } else if (pwSt.type === "clean_enc") {
        // Full Bersih + ENC
        const encSelected = pwSt.encSelected || [];
        const loadingMsg = await bot.sendMessage(pwSt.chatId,
          "⏳ <b>FULL BERSIH + ENC</b>\n\nMenyiapkan proses...",
          { parse_mode: "HTML" });
        const loading = startBackupLoading(bot, pwSt.chatId, loadingMsg.message_id, "FULL BERSIH + ENC", encSelected.length);
        try {
          const zip = await buildMixedFullBackupClean(encSelected, "high", "Full Bersih + ENC", async (done, total, file, enc) => {
            await loading.update(done, total, file, enc);
          }, newPw);
          const sizeMb = fs.existsSync(zip) ? (fs.statSync(zip).size / 1048576).toFixed(2) : "0.00";
          await loading.stop(
            `✅ <b>FULL BERSIH + ENC SELESAI</b>\n\n` +
            `<code>${"▰".repeat(18)}</code> <b>100%</b>\n` +
            `📦 Total file: <b>${filesCountSafe(zip)}</b>\n` +
            `🔐 File di-ENC: <b>${encSelected.length}</b>\n` +
            `💾 Ukuran ZIP: <b>${sizeMb} MB</b>\n` +
            `🔑 Password: <code>${safeHtml(newPw)}</code>\n\n` +
            `🧼 Semua setting & DB sudah dikosongkan.\n📤 Mengirim <b>lianix.zip</b> ke chat...`
          );
          await sendBackupResult(bot, pwSt.chatId, zip, `Full Bersih + ENC • password: ${newPw}`);
        } catch (e) {
          await bot.sendMessage(pwSt.chatId, `◇ Backup ENC gagal: ${safeHtml(e.message)}`, { parse_mode: "HTML" });
        }
      }
      return;
    }
    // ===== END HANDLER PASSWORD =====
  });

  // ===== /backup command =====
  bot.onText(/^\/backup$/i, async msg => {
    if (!isOwner(msg.from.id)) {
      return bot.sendMessage(msg.chat.id, "◇ Fitur backup hanya dapat digunakan oleh owner.", { reply_to_message_id: msg.message_id });
    }
    // Selalu gunakan chat asal. Jangan pernah mengalihkan hasil manual backup ke owner private.
    await bot.sendMessage(msg.chat.id, "▣ Buka Backup Center lewat Dev Menu untuk memilih metode.\n\n📍 Hasil backup akan dikirim ke chat tempat /backup dijalankan.", {
      reply_markup: { inline_keyboard: [[{ text: "▣ Backup Center", callback_data: "dev_backup" }]] }
    });
  });

  // ===== /ubahjs command — tombol pilih file yang mau diganti =====
  bot.onText(/^\/ubahjs$/i, async msg => {
    if (!isOwner(msg.from.id)) return;
    const files = sourceFiles();
    const rows = [];
    for (let i = 0; i < files.length; i += 2) {
      rows.push(files.slice(i, i + 2).map(f => ({
        text: "📄 " + f,
        callback_data: `dev_ubahjs:${Buffer.from(f).toString("base64url")}`
      })));
    }
    rows.push([{ text: "✗ Batal", callback_data: "dev_noop" }]);
    await bot.sendMessage(msg.chat.id,
      "<blockquote expandable><b>UBAH FILE JS</b>\nPilih file yang mau diganti, lalu kirim file .js baru.\n\n/batal untuk batal kapan saja.</blockquote>",
      { parse_mode: "HTML", reply_markup: { inline_keyboard: rows } });
  });

  // callback untuk /ubahjs file picker
  bot.on("callback_query", async q => {
    if (!q.data || !q.data.startsWith("dev_ubahjs:")) return;
    if (!isOwner(q.from.id)) return bot.answerCallbackQuery(q.id, { text: "Khusus owner", show_alert: true });
    await bot.answerCallbackQuery(q.id).catch(() => {});
    const f = Buffer.from(q.data.split(":")[1], "base64url").toString();
    if (!sourceFiles().includes(f)) return;
    ubahJsState.set(q.from.id, { file: f, chatId: q.message.chat.id });
    await bot.sendMessage(q.message.chat.id,
      `<blockquote expandable><b>UBAH ${safeHtml(f)}</b>\nKirim file <b>.js</b> baru sebagai document.\nFile lama akan dibackup otomatis ke .dev_backups.\n\n/batal untuk batal.</blockquote>`,
      { parse_mode: "HTML", reply_to_message_id: q.message.message_id });
  });
}

module.exports = { register };
