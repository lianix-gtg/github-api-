
/**
 * LIANIX MEGA FEATURE HUB
 * Telegram-native adaptation of safe/useful features found in ZETA-MD and OURIN MD.
 * Categories: Downloader, AI, Stalker, Tools, Fun, Game, Search/Random.
 * Commands that already exist in the core pack are intentionally skipped.
 */
const axios = require("axios");
const fs = require("fs");
const path = require("path");
const os = require("os");
const crypto = require("crypto");
const { execFile } = require("child_process");
const { promisify } = require("util");
const settings = require("../settings.js");

// Archive feature bridge — ESM features loaded via dynamic import()
let _features = null;
function features() {
  if (!_features) _features = require('./features/index.cjs');
  return _features;
}
/**
 * safeReply — sendMessage with reply_to_message_id fallback.
 */
async function safeReply(bot, chatId, text, opts = {}) {
  try {
    return await bot.sendMessage(chatId, text, opts);
  } catch (err) {
    const desc = String(err?.response?.body?.description || err?.message || '');
    if (/message to be replied not found/i.test(desc) && opts.reply_to_message_id) {
      const { reply_to_message_id: _, ...safeOpts } = opts;
      return await bot.sendMessage(chatId, text, safeOpts);
    }
    throw err;
  }
}


const execFileAsync = promisify(execFile);
const UA = "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/130 Safari/537.36";
const q = m => m?.message_id ? {reply_to_message_id:m.message_id} : {};
const esc = s => String(s ?? "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
const pick = a => a[Math.floor(Math.random()*a.length)];

const CLAIMED = new Set([
  "download","dl","tiktok","tt","youtube","yt","ytmp4","instagram","ig","igdl","mediafire","mfdl","mf",
  "facebook","fb","fbdown","capcut","ccdl","cc","tourl","upload","url","hd","enhance","upscale","hdvideo","hdvid","enhancevid","hdv",
  "qr","ocr","removebg","rmbg","nobg","hapusbg","ssweb","screenshot","ss","webss","toimg","toimage","stickertoimage","stimg",
  "toaudio","tomp3","videotoaudio","extractaudio","tovideo","tovid","stickertovideo","giftomp4","webmtomp4",
  "family100","f100","family","caklontong","cak","tekateki","teka","riddle","tebaktebakan","tebak","tebakan","asahotak","asah","otak","tebakepep","epep","tebakff",
  "game","games","suit","rps","dadu","tebakangka","guess","susunkata","scramble","rate","nilai","rating","can","is","when","where","how"
]);

const CATS = {
  downloader: {
    title:"⬇ DOWNLOADER",
    commands:[
      ["capcutdl",["ccdl","capcut","cc"]],["cocofundl",["cfdl","cocofun","cf"]],["dailymotiondl",["dailymotion","dmdl"]],
      ["douyindl",["douyin","dydl"]],["githubdl",["gitdl","gitclone","repodownload"]],["likeedl",["lkdl","likee","lk"]],
      ["pindl",["pinterestdl","pindownload","pintdl"]],["pixeldraindl",["pddl","pixeldrain","pddownload"]],
      ["rednotedl",["rednote","xhsdl","xiaohongshu"]],["sfiledl",["sfile","sfiledownload"]],
      ["shopeedl",["shopeevideo","shopeevid"]],["snackvideodl",["svdl","snackvideo","sv"]],
      ["spotifydl",["spdl","spotify-dl","spotdl"]],["terabox",["tb","tera","teraboxdl","tbdl"]],
      ["threaddl",["tdl","threads","threadsdl"]],["videy",["vdl","videydownload","videydl"]],
      ["ytmp3",["youtubemp3","ytaudio"]]
    ]
  },
  ai: {
    title:"✦ AI CENTER",
    commands:[
      ["ai4chat",["ai"]],["claudehaiku",["claude","haiku","chiku"]],["deepseek",["ds","dsv4","deepthink"]],
      ["dolphin",["dolphinai","dphn"]],["gpt4o",["gpt4"]],["gpt5",["gpt5nano","gpt41"]],
      ["qwen3",["qwen","qw3"]],["simi",["simisimi"]],["ourin-ai",["ourinai","ourin"]],
      ["matematika",["mathgpt","math","mathsolver"]],["text2img",[]],["text2img2",["t2i2","genimg"]],
      ["anime-gen",["animegen","aianimegen","genai-anime"]],["toanime",["anime","animefy","ghibli"]],
      ["toblack",["black","hitamkan","hitam","tohitam"]],["tocartoon",["cartoon","cartoonify","tooncartoon"]],
      ["tocermin",["mirror","tomirror"]],["tochibi",["chibi","chibistyle"]],["toemotebatu",["emotebatu","moai","tomoai"]],
      ["tofigure",["figure","figurestyle"]],["tofigurev2",["figurev2","figure2"]],["tofigure3",["figurine3","tofigure3","bandai3","actionfigure3"]],
      ["toghibli",["ghibli","ghiblistyle"]],["tohijab",["hijab","hijabstyle","addhijab"]],
      ["toisland",["island","tropical"]],["tojapanese",["japanese","japanesestyle"]],["tomanga",["manga","mangafy","mangastyle"]],
      ["tomekah",["mekah","mecca","tomecca"]],["tooilpainting",["oilpainting","tooil","oil"]],
      ["sologo",["ailogo","bikinlogo"]]
    ]
  },
  stalker: {
    title:"◉ STALKER",
    commands:[
      ["discordstalk",["dcstalk","dsstalk","stalkdc","stalkdiscord"]],["ffstalk",["freefireid","stalkff","ff"]],
      ["genshinstalk",["genshin","stalkgenshin","gi"]],["githubstalk",["ghstalk","stalkgh"]],
      ["igstalk",["instagramstalk","stalking"]],["npmstalk",["stalknpm","npms"]],
      ["pintereststalk",["pinterestid","stalkpinterest","stalkpin"]],["robloxplayer",["robloxsearch","searchroblox","robloxfind"]],
      ["robloxstalk",["rblxstalk","rbxstalk","stalkroblox","stalkrbx"]],["tiktokstalk",["ttstalk","stalktt"]],
      ["wastalk",["whatsappstalk","stalkwa"]],["ytstalk",["youtubestalk","stalkyt"]]
    ]
  },
  tools: {
    title:"🧰 TOOLS",
    commands:[
      ["quoted",["q","inspect"]],["carbon",["carbonify","carboncode"]],["cekidch",["idch","channelid","infoch","channelinfo"]],
      ["cekxl",["checkxl","xlcheck","xlcek"]],["cjstoesm",["cjs2esm","cjsconvert"]],["converter",["convert","konversi"]],
      ["dafont",["font","daffont","carifont"]],["delpp",["delprofilebot","delppbot","hapusppbot"]],
      ["emojitoanimasi",["emoji2sticker","emojisticker","e2s"]],["emojitoimage",["emoji2img","emojiimg","e2i"]],
      ["esmtocjs",["esm2cjs","esmconvert"]],["getpaste",["pastebin","getpb"]],["ipwho",["ip","iplookup","ipinfo"]],
      ["lookup",["dnslookup","dns","whois"]],["nulis",["tulis","write"]],["pastebin",["paste","pb"]],
      ["qwa",["quotewa","fakeqwa"]],["readmore",["selengkapnya","spoiler"]],["rvo",["readvo","readviewonce","readview"]],
      ["setbio",["setbiobot","setstatus","setabout"]],["setname",["setnamebot","setbotnama"]],["setpp",["setprofilebot","setppbot","setfotobot"]],
      ["tempmail",["tmpmail","tmp","trashmail"]],["tovn",["tovoicenote","toptt","audiotovn"]],
      ["transkrip",["stt","speechtotext","transcribe"]],["txt2qr",["texttoqr","qrcode","qrcreate"]],
      ["videotranscribe",["video-transcribe","transkripvideo"]],["wink",["winkenhance","winkhd","wenhance"]],
      ["translate",["tr","terjemah"]],["wiki",["wikipedia","wp"]],["weather",["cuaca"]],["uuid",["genuuid"]],
      ["base64",["b64"]],["hash",["md5","sha256"]],["json",["jsonfmt","jsonbeauty"]]
    ]
  },
  fun: {
    title:"♧ FUN",
    commands:[
      ["akankah",["akan","will"]],["apakah",["apa"]],["bagaimana",["gimana","how"]],["berapa",["howmuch","howmany"]],
      ["bisakah",["bisa"]],["bucin",["gombal","love","romantis"]],["cekkhodam",["khodam","cekhodam"]],
      ["cekpacar",["pacar","pasangan","gebetan"]],["coba",["try"]],["confess",["confession","menfess","anonim"]],
      ["dare",["dareq","tantang"]],["dimana",["where","mana"]],["fuckmylife",["fml"]],["gay",["howgay"]],
      ["haruskah",["harus","should"]],["jodoh",["match","shipcouple","ship"]],["kapan",["when"]],
      ["mengapa",["kenapa","why"]],["mimpi",["dream","dreamworld"]],["puisi",["puisiku","sajak"]],
      ["putus",["breakup","cerai"]],["rate",["nilai","rating"]],["renungan",["motivasi","mutiara"]],
      ["senja",["katacinta","romanticquotes"]],["soulmatch",[]],["sulap",["magic","magictrick"]],
      ["tembak",["nembak","propose"]],["terima",["accept","yes"]],["tolak",["reject","no","gaktau"]],
      ["top",["top5","toplist"]],["truth",["truthq"]]
    ]
  },
  game: {
    title:"🎮 GAME",
    commands:[
      ["dungeon",["dg","explore","labirin"]],["fisht",["fishit"]],["kyubigame",["kyubi","naruto","shinobi"]],
      ["mct",["minecraft"]],["suitpvp",["janken"]],["tictactoe",["ttt","xo"]],["ulartangga",["ut","snakeladder","sl"]],
      ["werewolf",["ww","wwgc"]],["wwkill",["wolfkill","wk"]],["wwprotect",["protect","guardian","wpr"]],
      ["wwsee",["seer","vision","wse"]],["wwsorcerer",["sorcerer","wws"]]
    ]
  },
  search: {
    title:"⌕ SEARCH",
    commands:[
      ["animeapaini",["whatanime","animesearch","sauceanime","searchanime"]],["applemusic",["amusic","am"]],
      ["bingimage",["imagesearch","carigambar","bingimg"]],["chords",["chord","kunci","kuncigitar"]],
      ["google",["gsearch","googlenews"]],["gsmarena",["gsm","phonespec","spesifikasi"]],
      ["lirik",["lyric","lyrics","liriklagu"]],["npm",["npmsearch","npmjs","npmfind"]],
      ["pins",["pinsearch","pinterestsearch"]],["pinvid",["pinvideo","pinterestv","pinv"]],
      ["pixiv",["pixivsearch","caripixiv"]],["play",["playaudio"]],["playsoundcloud",["playsc"]],
      ["playtiktok",["ttplay","tiktokplay"]],["searchthatsong",["sts","carilagu"]],
      ["soundcloud",["scsearch","scs"]],["spotify",["spotifysearch","spsearch"]],["spotplay",["splay","sp"]],
      ["tiktokfoto",["ttfoto","ttphotosearch","searchtiktokfoto"]],["ttsearch",["tiktoksearch","tts","searchtiktok"]],
      ["wikipedia",["wiki","wp"]],["yts",["ytsearch","youtubesearch"]]
    ]
  },
  random: {
    title:"✺ RANDOM",
    commands:[
      ["barandom",["bluearchive","ba"]],["ppcouple",["cp","ppcp"]],["meme",["randommeme","memeindonesia"]],
      ["quotesimage",["quoteimg","quotes-image","qimg"]],["anime",["randomanime"]]
    ]
  }
};

function flattenCommands(cat) {
  return cat.commands.flatMap(([name, aliases]) => [name,...aliases]).filter(Boolean);
}
function availableAliases(cat) {
  return flattenCommands(cat).filter(x => !CLAIMED.has(String(x).toLowerCase()));
}

async function getJson(url, opts={}) {
  const r=await axios.get(url,{timeout:60000,headers:{...opts.headers}});
  return r.data;
}

async function aiText(query, model="openai") {
  const prompt = String(query || "").trim();
  if (!prompt) throw new Error("Masukkan pertanyaan.");

  // Route specific models to archive feature implementations
  try {
    if (model === "gemini") {
      const { geminiChat } = features();
      const res = await geminiChat(prompt);
      return res?.text || res || "";
    }
    if (model === "deepseek" || model === "ds") {
      const { deepseekThinking } = features();
      const res = await deepseekThinking(prompt);
      return res?.answer || res?.reasoning || String(res || "");
    }
    if (model === "gpt5" || model === "gpt4.5") {
      const { gpt5Chat } = features();
      const res = await gpt5Chat(prompt);
      return res?.answer || String(res || "");
    }
    if (model === "claude" || model === "haiku") {
      const { claudeHaikuChat } = features();
      const res = await claudeHaikuChat(prompt);
      return String(res?.text || res || "");
    }
    if (model === "qwen" || model === "qwen3") {
      const { qwen3Chat } = features();
      const res = await qwen3Chat(prompt);
      return String(res?.text || res || "");
    }
  } catch (archiveErr) {
    // Archive feature failed — fall through to pollinations fallback
    console.warn(`[megaFeatures] archive AI (${model}) gagal:`, archiveErr.message, "— fallback pollinations");
  }

  // Default: pollinations.ai
  const url = `https://text.pollinations.ai/${encodeURIComponent(prompt)}?model=${encodeURIComponent(model)}&seed=${Math.floor(Math.random()*1e9)}`;
  const r = await axios.get(url, { timeout: 120000, responseType: "text" });
  return String(r.data || "").trim();
}

async function aiImage(prompt) {
  const url=`https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=1024&height=1024&nologo=true&seed=${Math.floor(Math.random()*1e9)}`;
  return url;
}

async function sendAi(bot,msg,text,model="openai") {
  const answer=await aiText(text,model);
  await bot.sendMessage(msg.chat.id,`✦ <b>LIANIX AI</b>\n\n<blockquote expandable>${esc(answer.slice(0,12000))}</blockquote>`,{parse_mode:"HTML",...q(msg)});
}

function imagePromptFor(cmd,text) {
  const map={
    "anime":"anime style, detailed clean line art","anime-gen":"anime style, cinematic",
    "toanime":"anime style, cinematic Japanese illustration","ghibli":"whimsical hand-painted animation style",
    "chibi":"cute chibi character, big head","tochibi":"cute chibi character, big head",
    "cartoon":"stylized cartoon illustration","tocartoon":"stylized cartoon illustration",
    "manga":"black and white manga illustration","tomanga":"black and white manga illustration",
    "ghibl":"whimsical hand-painted animation","ghibli":"whimsical hand-painted animation",
    "oilpainting":"classical oil painting","tooilpainting":"classical oil painting",
    "japanese":"Japanese art aesthetic","tojapanese":"Japanese art aesthetic",
    "tropical":"tropical island scenery","toisland":"tropical island scenery",
    "mirror":"symmetrical mirrored portrait","tocermin":"symmetrical mirrored portrait",
    "black":"black monochrome portrait","toblack":"black monochrome portrait",
    "figure":"collectible action figure render","tofigure":"collectible action figure render",
    "figurev2":"premium collectible figure render","tofigure2":"premium collectible figure render",
    "3d":"3D character render","to3d":"3D character render",
    "hijab":"modest hijab fashion portrait","tohijab":"modest hijab fashion portrait",
    "mekah":"Mecca inspired travel illustration","tomekah":"Mecca inspired travel illustration",
    "logo":"clean modern professional logo","sologo":"clean modern professional logo"
  };
  const key=cmd.toLowerCase();
  return `${map[key]||"high quality digital artwork"}: ${text||"a beautiful creative scene"}`;
}

async function stalkGithub(bot,msg,user) {
  const d=await getJson(`https://api.github.com/users/${encodeURIComponent(user)}`,{headers:{"User-Agent":"LianiX"}});
  const txt=`<b>◉ GITHUB STALK</b>\n\n<b>Username:</b> ${esc(d.login)}\n<b>Name:</b> ${esc(d.name||"-")}\n<b>ID:</b> <code>${d.id}</code>\n<b>Public Repo:</b> ${d.public_repos}\n<b>Followers:</b> ${d.followers}\n<b>Following:</b> ${d.following}\n<b>Location:</b> ${esc(d.location||"-")}\n<b>Bio:</b> ${esc(d.bio||"-")}\n<a href="${esc(d.html_url)}">Open Profile</a>`;
  if(d.avatar_url) await bot.sendPhoto(msg.chat.id,d.avatar_url,{caption:txt,parse_mode:"HTML",...q(msg)});
  else await bot.sendMessage(msg.chat.id,txt,{parse_mode:"HTML",...q(msg)});
}
async function stalkNpm(bot,msg,pkg) {
  const d=await getJson(`https://registry.npmjs.org/${encodeURIComponent(pkg)}`);
  await bot.sendMessage(msg.chat.id,`<b>◉ NPM STALK</b>\n\n<b>Package:</b> <code>${esc(d.name)}</code>\n<b>Latest:</b> ${esc(d["dist-tags"]?.latest||"-")}\n<b>Description:</b> ${esc(d.description||"-")}\n<b>License:</b> ${esc(d.license||"-")}\n<b>Repo:</b> ${esc(d.repository?.url||"-")}`,{parse_mode:"HTML",...q(msg)});
}
async function stalkRoblox(bot,msg,name) {
  const d=await axios.post("https://users.roblox.com/v1/usernames/users",{usernames:[name],excludeBannedUsers:false},{timeout:30000}).then(r=>r.data);
  const u=d?.data?.[0]; if(!u) throw new Error("User Roblox tidak ditemukan.");
  const info=await getJson(`https://users.roblox.com/v1/users/${u.id}`);
  await bot.sendMessage(msg.chat.id,`<b>◉ ROBLOX STALK</b>\n\n<b>Username:</b> ${esc(u.name)}\n<b>Display:</b> ${esc(u.displayName)}\n<b>ID:</b> <code>${u.id}</code>\n<b>Created:</b> ${esc(info.created||"-")}\n<b>Description:</b> ${esc(info.description||"-")}\n\nhttps://www.roblox.com/users/${u.id}/profile`,{parse_mode:"HTML",...q(msg)});
}
async function stalkTikTok(bot,msg,user) {
  const d=await getJson(`https://www.tikwm.com/api/user/info?unique_id=${encodeURIComponent(user.replace(/^@/,""))}`);
  const u=d?.data?.user||d?.data;
  if(!u) throw new Error("Data TikTok tidak tersedia dari endpoint.");
  await bot.sendMessage(msg.chat.id,`<b>◉ TIKTOK STALK</b>\n\n<b>Username:</b> @${esc(u.unique_id||user)}\n<b>Nickname:</b> ${esc(u.nickname||"-")}\n<b>Followers:</b> ${u.follower_count??"-"}\n<b>Following:</b> ${u.following_count??"-"}\n<b>Likes:</b> ${u.total_favorited??"-"}\n<b>Videos:</b> ${u.aweme_count??"-"}`,{parse_mode:"HTML",...q(msg)});
}
async function stalkInstagram(bot,msg,user) {
  const name=String(user).replace(/^@/,"").trim();
  const url=`https://www.instagram.com/${encodeURIComponent(name)}/`;
  try {
    const r=await axios.get(url,{headers:{"User-Agent":UA,"Accept":"text/html"},timeout:30000});
    const html=String(r.data||"");
    const m=html.match(/<meta[^>]+name=["']description["'][^>]+content=["']([^"']+)/i);
    await bot.sendMessage(msg.chat.id,`<b>◉ INSTAGRAM STALK</b>\n\n<b>Username:</b> @${esc(name)}\n<b>Profile:</b> <a href="${esc(url)}">Open Instagram</a>\n${m?`\n${esc(m[1])}`:"\n<i>Metadata profil tidak tersedia dari Instagram saat ini.</i>"}`,{parse_mode:"HTML",...q(msg)});
  } catch { throw new Error("Instagram membatasi metadata publik. Link profil tetap tersedia: "+url); }
}

async function translate(bot,msg,text) {
  const m=text.match(/^(?:([a-z]{2})-([a-z]{2})\s+)?([\s\S]+)$/i);
  const from=m?.[1]||"auto", to=m?.[2]||"en", qtext=m?.[3]||text;
  const d=await getJson(`https://api.mymemory.translated.net/get?q=${encodeURIComponent(qtext)}&langpair=${encodeURIComponent(from)}|${encodeURIComponent(to)}`);
  const out=d?.responseData?.translatedText;
  if(!out) throw new Error("Terjemahan tidak tersedia.");
  await bot.sendMessage(msg.chat.id,`⌘ <b>TRANSLATE</b>\n\n<b>${from} → ${to}</b>\n\n${esc(out)}`,{parse_mode:"HTML",...q(msg)});
}
async function wiki(bot,msg,text) {
  const d=await getJson("https://id.wikipedia.org/w/api.php",{params:{}}).catch(()=>null);
  // Use the REST summary endpoint for a compact, reliable result.
  const r=await axios.get(`https://id.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(text.replace(/\s+/g,"_"))}`,{timeout:30000,headers:{"User-Agent":UA}});
  const x=r.data;
  await bot.sendMessage(msg.chat.id,`<b>⌕ WIKIPEDIA</b>\n\n<b>${esc(x.title||text)}</b>\n\n${esc(x.extract||"Ringkasan tidak tersedia.")}\n\n<a href="${esc(x.content_urls?.desktop?.page||"https://id.wikipedia.org") }">Buka artikel</a>`,{parse_mode:"HTML",...q(msg)});
}
async function weather(bot,msg,text) {
  const g=await getJson(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(text)}&count=1&language=id&format=json`);
  const loc=g?.results?.[0]; if(!loc) throw new Error("Lokasi tidak ditemukan.");
  const w=await getJson(`https://api.open-meteo.com/v1/forecast?latitude=${loc.latitude}&longitude=${loc.longitude}&current=temperature_2m,relative_humidity_2m,apparent_temperature,wind_speed_10m&timezone=auto`);
  const c=w.current;
  await bot.sendMessage(msg.chat.id,`☁ <b>WEATHER</b>\n\n<b>${esc(loc.name)}, ${esc(loc.country||"")}</b>\n\n🌡 ${c.temperature_2m}°C\n💧 ${c.relative_humidity_2m}%\n🌬 ${c.wind_speed_10m} km/h\n🥵 Feels ${c.apparent_temperature}°C`,{parse_mode:"HTML",...q(msg)});
}
async function npmSearch(bot,msg,text) {
  const d=await getJson(`https://registry.npmjs.org/-/v1/search?text=${encodeURIComponent(text)}&size=8`);
  const rows=(d.objects||[]).map((x,i)=>`${i+1}. <code>${esc(x.package?.name)}</code> — ${esc(x.package?.description||"-")}`);
  await bot.sendMessage(msg.chat.id,`⌘ <b>NPM SEARCH</b>\n\n${rows.join("\n")||"Tidak ada hasil."}`,{parse_mode:"HTML",...q(msg)});
}
async function googleSearch(bot,msg,text) {
  const d=await getJson(`https://api.duckduckgo.com/?q=${encodeURIComponent(text)}&format=json&no_html=1&skip_disambig=1`);
  let body=d?.AbstractText||"";
  if(d?.AbstractURL) body+=`\n\n<a href="${esc(d.AbstractURL)}">Buka sumber</a>`;
  if(!body && d?.RelatedTopics?.length) body=d.RelatedTopics.slice(0,6).map(x=>`• ${esc(x.Text||"")}`).join("\n");
  await bot.sendMessage(msg.chat.id,`⌕ <b>SEARCH</b>\n\n<b>${esc(text)}</b>\n\n${body||"Tidak ada ringkasan. Coba query lebih spesifik."}`,{parse_mode:"HTML",...q(msg)});
}
async function lyrics(bot,msg,text) {
  const d=await getJson(`https://api.nexray.eu.cc/search/lyrics?q=${encodeURIComponent(text)}`);
  const x=d?.result;
  const lyrics=x?.lyrics?.plain_lyrics;
  if(!lyrics) throw new Error("Lirik tidak ditemukan.");
  await bot.sendMessage(msg.chat.id,`♪ <b>LYRICS</b>\n\n<b>${esc(x.title||text)}</b> — ${esc(x.artist||x.lyrics?.artist_name||"-")}\n\n<blockquote expandable>${esc(lyrics.slice(0,12000))}</blockquote>`,{parse_mode:"HTML",...q(msg)});
}
async function randomMeme(bot,msg) {
  const d=await getJson("https://meme-api.com/gimme/IndonesianMemes").catch(()=>null) || await getJson("https://meme-api.com/gimme/memes");
  if(!d?.url) throw new Error("Meme tidak tersedia.");
  await bot.sendPhoto(msg.chat.id,d.url,{caption:`✺ <b>RANDOM MEME</b>\n\n${esc(d.title||"")}`,parse_mode:"HTML",...q(msg)});
}
async function randomAnime(bot,msg) {
  const d=await getJson("https://api.waifu.im/search?included_tags=waifu&is_nsfw=false");
  const u=d?.images?.[0]?.url; if(!u) throw new Error("Gambar anime tidak tersedia.");
  await bot.sendPhoto(msg.chat.id,u,{caption:"✺ <b>RANDOM ANIME</b>",parse_mode:"HTML",...q(msg)});
}

const FUN_ANSWERS = {
  apakah:["Ya","Tidak","Mungkin","Bisa jadi","Kemungkinan besar iya","Kemungkinan kecil"],
  bisakah:["Bisa banget","Bisa, coba dulu","Belum tentu","Sepertinya bisa","Tidak disarankan"],
  akankah:["Kemungkinan besar","Mungkin saja","Belum waktunya","Bisa jadi minggu depan","Hanya waktu yang tahu"],
  bagaimana:["Pelan-pelan","Mulai dari yang paling mudah","Coba dan evaluasi","Tanya orang yang berpengalaman"],
  berapa:["3","7","10","42","99","Tergantung situasinya"],
  dimana:["Di rumah","Di luar","Di tempat favoritmu","Di suatu tempat yang tidak kamu sangka"],
  kapan:["Hari ini","Besok","Minggu depan","Bulan depan","Suatu saat"],
  mengapa:["Karena keadaan","Karena pilihanmu","Karena kebetulan","Ada alasannya, tapi belum ketahuan"],
  haruskah:["Kalau memang siap, iya","Tidak perlu dipaksakan","Coba pertimbangkan dulu"],
};
const FUN_TEXT = {
  bucin:["Kamu 97% bucin 💘","Bucin tipis-tipis 😭","Level bucin: maksimal"],
  "cekkhodam":["Khodammu hari ini: Naga Mager 🐉","Khodammu: Kucing Sultan 🐈","Khodammu: Penjaga Wi-Fi 📡"],
  "cekkhodam2":["Khodammu: Naga Mager 🐉","Khodammu: Kucing Sultan 🐈"]
};
function funReply(cmd,text){
  const key=cmd.replace(/[^a-z]/g,"");
  if(FUN_ANSWERS[key]) return pick(FUN_ANSWERS[key]);
  if(key==="rate"||key==="nilai"||key==="rating") return `Nilai untuk "${text}": ${Math.floor(Math.random()*101)}%`;
  if(["jodoh","match","shipcouple","ship"].includes(key)) return `Kecocokan: ${Math.floor(Math.random()*101)}% 💞`;
  if(["gay","howgay"].includes(key)) return `Indeks random hari ini: ${Math.floor(Math.random()*101)}%`;
  if(["puisi","puisiku","sajak"].includes(key)) return `Di antara malam dan cahaya,\nada cerita yang belum selesai.\n${text||"Semoga besok lebih baik."}`;
  if(["renungan","motivasi","mutiara"].includes(key)) return pick(["Jangan takut mulai kecil.","Konsisten lebih penting daripada sempurna.","Istirahat boleh, menyerah jangan."]);
  if(["truth","truthq"].includes(key)) return pick(["Apa keputusan yang paling kamu syukuri?","Siapa yang paling kamu percaya?","Apa target yang ingin kamu capai tahun ini?"]);
  if(["dare","dareq","tantang"].includes(key)) return pick(["Kirim emoji terakhir yang kamu pakai.","Tulis satu hal yang kamu syukuri.","Ganti bio dengan satu kata selama 10 menit."]);
  if(["cekkhodam","khodam"].includes(key)) return pick(["Naga Mager 🐉","Kucing Sultan 🐈","Penjaga Wi-Fi 📡","Burung Wi-Fi 🐦"]);
  if(["bucin","gombal","love","romantis"].includes(key)) return pick(FUN_TEXT.bucin);
  return pick(["Coba lagi 😎","Jawabannya misterius.","Bisa jadi.","Tergantung kamu."]);
}

async function handleTool(bot,msg,cmd,text) {
  const key=cmd.toLowerCase();
  if(["translate","tr","terjemah"].includes(key)) return translate(bot,msg,text);
  if(["wiki","wikipedia","wp"].includes(key)) return wiki(bot,msg,text);
  if(["weather","cuaca"].includes(key)) return weather(bot,msg,text);
  if(["npm","npmsearch","npmjs","npmfind"].includes(key)) return npmSearch(bot,msg,text);
  if(["google","gsearch","googlenews"].includes(key)) return googleSearch(bot,msg,text);
  if(["lirik","lyric","lyrics","liriklagu"].includes(key)) return lyrics(bot,msg,text);
  if(["ip","iplookup","ipinfo"].includes(key)) {
    const ip=text||"";
    const d=await getJson(`https://ipwho.is/${encodeURIComponent(ip)}`);
    if(d?.success===false) throw new Error(d.message||"IP tidak ditemukan.");
    return bot.sendMessage(msg.chat.id,`◎ <b>IP INFO</b>\n\n<b>IP:</b> ${esc(d.ip)}\n<b>Country:</b> ${esc(d.country)}\n<b>City:</b> ${esc(d.city)}\n<b>ISP:</b> ${esc(d.connection?.isp||"-")}\n<b>Org:</b> ${esc(d.connection?.org||"-")}`,{parse_mode:"HTML",...q(msg)});
  }
  if(["dns","dnslookup","whois","lookup"].includes(key)) {
    const host=(text||"").replace(/^https?:\/\//,"").split("/")[0];
    if(!host) throw new Error("Masukkan domain.");
    const d=await getJson(`https://dns.google/resolve?name=${encodeURIComponent(host)}&type=A`);
    return bot.sendMessage(msg.chat.id,`◎ <b>DNS LOOKUP</b>\n\n<b>${esc(host)}</b>\n\n${(d.Answer||[]).map(x=>`• ${esc(x.data)}`).join("\n")||"Tidak ada record A."}`,{parse_mode:"HTML",...q(msg)});
  }
  if(["uuid","genuuid"].includes(key)) return bot.sendMessage(msg.chat.id,`⌘ <b>UUID</b>\n\n<code>${crypto.randomUUID()}</code>`,{parse_mode:"HTML",...q(msg)});
  if(["base64","b64"].includes(key)) {
    const [mode,...rest]=(text||"").split(/\s+/); const raw=rest.join(" ");
    if(!raw) throw new Error("Gunakan /base64 encode teks atau /base64 decode base64");
    const out=/^decode$/i.test(mode)?Buffer.from(raw,"base64").toString("utf8"):Buffer.from(rest.join(" "),"utf8").toString("base64");
    return bot.sendMessage(msg.chat.id,`⌘ <b>BASE64</b>\n\n<code>${esc(out)}</code>`,{parse_mode:"HTML",...q(msg)});
  }
  if(["hash","md5","sha256"].includes(key)) {
    const algo=key==="md5"?"md5":key==="sha256"?"sha256":((text||"").split(/\s+/)[0]||"sha256").toLowerCase();
    const raw=key==="hash"?(text||"").replace(/^(md5|sha256)\s+/i,""):text;
    if(!raw) throw new Error("Masukkan teks.");
    return bot.sendMessage(msg.chat.id,`⌘ <b>HASH</b>\n\n<code>${crypto.createHash(algo).update(raw).digest("hex")}</code>`,{parse_mode:"HTML",...q(msg)});
  }
  if(["json","jsonfmt","jsonbeauty"].includes(key)) {
    try { return bot.sendMessage(msg.chat.id,`⌘ <b>JSON FORMAT</b>\n\n<pre>${esc(JSON.stringify(JSON.parse(text),null,2).slice(0,12000))}</pre>`,{parse_mode:"HTML",...q(msg)}); }
    catch { throw new Error("JSON tidak valid."); }
  }
  if(["temp-mail","tempmail","tmpmail","tmp","trashmail"].includes(key)) {
    const d=await axios.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1",{timeout:30000}).then(r=>r.data);
    return bot.sendMessage(msg.chat.id,`✉ <b>TEMP MAIL</b>\n\n<code>${esc(d?.[0]||"Gagal")}</code>\n\n<i>Gunakan provider/fitur histori AM untuk pengelolaan mailbox.</i>`,{parse_mode:"HTML",...q(msg)});
  }
  if(["texttoqr","qrcode","qrcreate","txt2qr"].includes(key)) {
    const u=`https://api.qrserver.com/v1/create-qr-code/?size=900x900&data=${encodeURIComponent(text||"")}`;
    return bot.sendPhoto(msg.chat.id,u,{caption:"⌘ <b>QR CODE</b>",parse_mode:"HTML",...q(msg)});
  }
  // Safe fallbacks for source utilities that need WhatsApp-only state or private APIs.
  const desc={
    quoted:"Telegram-native inspect: reply to a message to inspect its sender/type.",
    readmore:"Telegram already supports expandable quotes; use the native quote UI.",
    converter:"Use /toimg, /toaudio, /tovideo for Telegram media conversion.",
    nulis:"Kirim teks dengan /nulis untuk membuat kartu teks sederhana.",
    carbon:"Carbon-style code cards are generated by /carbon when implemented.",
    lookup:"DNS/WHOIS lookup is available through /dns.",
    rvo:"Telegram does not expose WhatsApp ViewOnce semantics.",
    setbio:"Bot profile management is restricted; use BotFather for bot profile settings.",
    setname:"Bot name management is restricted; use BotFather.",
    setpp:"Bot profile photo management is restricted; use BotFather."
  };
  const d=desc[key];
  if(d) return bot.sendMessage(msg.chat.id,`🧰 <b>${esc(cmd.toUpperCase())}</b>\n\n${esc(d)}`,{parse_mode:"HTML",...q(msg)});
  throw new Error(`Tool ${cmd} belum punya adapter Telegram yang aman.`);
}

async function handleDownload(bot,msg,cmd,url) {
  if(!url) throw new Error(`Gunakan /${cmd} <URL>.`);
  const lower=url.toLowerCase();
  // Existing, stable core downloader handles these.
  if(/tiktok\.com/i.test(lower)) {
    let tiktokHandled = false;
    try {
      const d=await getJson(`https://www.tikwm.com/api/?url=${encodeURIComponent(url)}`);
      const r=d?.data;
      if(r) {
        if(r.images?.length) { for(const x of r.images.slice(0,10)) await bot.sendPhoto(msg.chat.id,x,{...q(msg)}); tiktokHandled=true; }
        else if(r.play) { await bot.sendVideo(msg.chat.id,r.play,{caption:`⬇ <b>TIKTOK</b>\n\n${esc(r.title||"")}`,parse_mode:"HTML",...q(msg)}); tiktokHandled=true; }
      }
    } catch {}
    if (!tiktokHandled) {
      // Fallback: archive tiktokDl
      const { tiktokDl } = features();
      const result = await tiktokDl(url);
      if (result?.media?.length) {
        for (const item of result.media.slice(0,3)) {
          if (item.type === 'video') await bot.sendVideo(msg.chat.id, item.url, {caption:`⬇ <b>TIKTOK</b> (${item.quality||""})\n\n${esc(result.title||"")}`,parse_mode:"HTML",...q(msg)});
          else await bot.sendPhoto(msg.chat.id, item.url, {...q(msg)});
        }
      } else throw new Error("Video TikTok tidak tersedia.");
    }
    return;
  }
  if(/youtube\.com|youtu\.be/i.test(lower)) {
    const yts=require("ytdl-core");
    if(!yts.validateURL(url)) throw new Error("URL YouTube tidak valid.");
    const info=await yts.getInfo(url); const title=info.videoDetails?.title||"YouTube";
    const out=path.join(os.tmpdir(),`lianix-${Date.now()}-${crypto.randomBytes(3).toString("hex")}.mp4`);
    try {
      const stream=yts(url,{quality:"18"}); await new Promise((res,rej)=>{const w=fs.createWriteStream(out);stream.pipe(w);stream.on("error",rej);w.on("finish",res);});
      await bot.sendVideo(msg.chat.id,out,{caption:`⬇ <b>YOUTUBE</b>\n\n${esc(title)}`,parse_mode:"HTML",supports_streaming:true,...q(msg)});
    } finally {try{fs.unlinkSync(out)}catch{}}
    return;
  }
  if(/facebook\.com|fb\.watch/i.test(lower)) {
    const mod=require("btch-downloader"); const fn=mod.fbdown||mod.default?.fbdown; if(!fn) throw new Error("Facebook adapter tidak tersedia.");
    const r=await fn(url); const v=r?.HD||r?.Normal_video; if(!v) throw new Error("Video Facebook tidak ditemukan.");
    return bot.sendVideo(msg.chat.id,v,{caption:"⬇ <b>FACEBOOK</b>",parse_mode:"HTML",...q(msg)});
  }
  if(/capcut\.com/i.test(lower)) {
    const mod=require("btch-downloader"); const fn=mod.capcut||mod.default?.capcut; if(!fn) throw new Error("CapCut adapter tidak tersedia.");
    const r=await fn(url); if(!r?.originalVideoUrl) throw new Error("Video CapCut tidak ditemukan.");
    return bot.sendVideo(msg.chat.id,r.originalVideoUrl,{caption:"⬇ <b>CAPCUT</b>",parse_mode:"HTML",...q(msg)});
  }
  if(/github\.com/i.test(lower)) {
    const m=url.match(/github\.com[/:]([^/]+)\/([^/#?]+?)(?:\.git)?$/i); if(!m) throw new Error("Link GitHub repo tidak valid.");
    const r=await axios.get(`https://api.github.com/repos/${m[1]}/${m[2]}/zipball`,{responseType:"arraybuffer",timeout:120000,headers:{"User-Agent":"LianiX"}});
    return bot.sendDocument(msg.chat.id,Buffer.from(r.data),{filename:`${m[1]}-${m[2]}.zip`,caption:"⬇ <b>GITHUB CLONE</b>",parse_mode:"HTML",...q(msg)});
  }
  if(/pinterest|pin\.it/i.test(lower)) {
    const d=await getJson(`https://api.siputzx.my.id/api/s/pinterest?query=${encodeURIComponent(url)}`);
    const item=d?.data?.[0]; if(item?.image_url) return bot.sendPhoto(msg.chat.id,item.image_url,{caption:"⬇ <b>PINTEREST</b>",parse_mode:"HTML",...q(msg)});
  }
  if(/pixeldrain\.com/i.test(lower)) {
    const id=url.match(/\/u\/([^/?#]+)/i)?.[1]; if(!id) throw new Error("PixelDrain ID tidak ditemukan.");
    const r=await axios.get(`https://pixeldrain.com/api/file/${id}`,{responseType:"arraybuffer",timeout:120000,maxContentLength:49*1024*1024});
    return bot.sendDocument(msg.chat.id,Buffer.from(r.data),{filename:`pixeldrain-${id}`,caption:"⬇ <b>PIXELDRAIN</b>",parse_mode:"HTML",...q(msg)});
  }
  if(/mediafire\.com/i.test(lower)) {
    const r=await axios.get(url,{headers:{"User-Agent":UA},timeout:60000});
    const m=String(r.data).match(/href="(https?:\/\/download[^"]+)"/i);
    if(!m) throw new Error("Direct MediaFire URL tidak ditemukan.");
    return bot.sendDocument(msg.chat.id,m[1],{caption:"⬇ <b>MEDIAFIRE</b>",parse_mode:"HTML",...q(msg)});
  }
  if(/instagram\.com|instagr\.am/i.test(lower)) {
    try {
      const { instagramDl } = features();
      const result = await instagramDl(url);
      if (result?.media?.length) {
        for (const item of result.media.slice(0, 5)) {
          if (item.type === 'video') {
            await bot.sendVideo(msg.chat.id, item.url, {caption:`⬇ <b>INSTAGRAM</b>\n\n${esc(result.title||"")}`,parse_mode:"HTML",...q(msg)});
          } else {
            await bot.sendPhoto(msg.chat.id, item.url, {caption:`⬇ <b>INSTAGRAM</b>`,parse_mode:"HTML",...q(msg)});
          }
        }
        return;
      }
    } catch (igErr) { throw new Error("Instagram download gagal: " + igErr.message); }
  }
  if(/twitter\.com|x\.com|t\.co/i.test(lower)) {
    const { twitterDl } = features();
    const result = await twitterDl(url);
    if (result?.media?.length) {
      for (const item of result.media.slice(0,3)) {
        await bot.sendVideo(msg.chat.id, item.url, {caption:`⬇ <b>TWITTER/X</b>\n\n${esc(result.title||"")}`,parse_mode:"HTML",...q(msg)}).catch(()=>{});
      }
      return;
    }
    throw new Error("Twitter media tidak tersedia.");
  }
  if(/reddit\.com/i.test(lower)) {
    const { redditDl } = features();
    const result = await redditDl(url);
    const media = result?.data?.media || result?.media;
    if (media?.length) {
      for (const item of media.slice(0,3)) {
        await bot.sendVideo(msg.chat.id, item.url||item, {caption:`⬇ <b>REDDIT</b>\n\n${esc(result.data?.title||result.title||"")}`,parse_mode:"HTML",...q(msg)}).catch(()=>{});
      }
      return;
    }
    throw new Error("Reddit media tidak tersedia.");
  }
  if(/open\.spotify\.com/i.test(lower)) {
    const { spotifyDl } = features();
    const result = await spotifyDl(url);
    const audio = result?.download || result?.url || result;
    if (typeof audio === 'string' && audio.startsWith('http')) {
      await bot.sendAudio(msg.chat.id, audio, {caption:`⬇ <b>SPOTIFY</b>\n\n${esc(result?.title||result?.name||"")}`,parse_mode:"HTML",...q(msg)});
      return;
    }
    throw new Error("Spotify audio tidak tersedia.");
  }
  if(/dailymotion\.com/i.test(lower)) {
    const { dailymotionDl } = features();
    const result = await dailymotionDl(url);
    const video = result?.url || result?.video_url || (Array.isArray(result) ? result[0]?.url : null);
    if (video) {
      await bot.sendVideo(msg.chat.id, video, {caption:`⬇ <b>DAILYMOTION</b>\n\n${esc(result?.title||"")}`,parse_mode:"HTML",...q(msg)});
      return;
    }
    throw new Error("Dailymotion video tidak tersedia.");
  }
  // Fallback: try archive aiodl universal downloader
  try {
    const { aiodl } = features();
    const result = await aiodl(url);
    if (result?.media?.length) {
      for (const item of result.media.slice(0, 5)) {
        if (item.type === 'video' || item.type === 'audio') {
          await bot.sendVideo(msg.chat.id, item.url, {
            caption: `⬇ <b>${esc(result.platform?.toUpperCase() || 'DOWNLOADER')}</b>\n\n${esc(result.title || '')}`,
            parse_mode: 'HTML', ...q(msg)
          }).catch(() => bot.sendDocument(msg.chat.id, item.url, {
            caption: `⬇ <b>${esc(result.platform?.toUpperCase() || 'DOWNLOADER')}</b>`,
            parse_mode: 'HTML', ...q(msg)
          }));
        } else {
          await bot.sendPhoto(msg.chat.id, item.url, {
            caption: `⬇ <b>${esc(result.platform?.toUpperCase() || 'DOWNLOADER')}</b>\n\n${esc(result.title || '')}`,
            parse_mode: 'HTML', ...q(msg)
          }).catch(() => {});
        }
      }
      return;
    }
  } catch (_fallbackErr) {}
  throw new Error("Platform belum punya adapter Telegram yang stabil. Gunakan /download URL untuk platform yang didukung.");
}

function funCommand(cmd,text) {
  return funReply(cmd,text);
}

function pageFor(catKey) {
  const c=CATS[catKey]; if(!c) return "";
  const lines=[];
  for(const [name,aliases] of c.commands) {
    const all=[name,...aliases].filter(Boolean);
    if(!all.length) continue;
    const claimed=all.some(x=>CLAIMED.has(String(x).toLowerCase()));
    lines.push(`├ <code>/${all[0]}</code>${all.length>1?` <i>(${all.slice(1,5).join(", ")})</i>`:""}${claimed?` <i>• core</i>`:""}`);
  }
  return `<b>${c.title}</b>\n\n<blockquote expandable>${lines.join("\n")||"Belum ada fitur."}</blockquote>`;
}

function canonicalGroupMenuText() {
  return `<blockquote expandable><b>GROUP MENU</b>⪼ Management, moderation, protection

`+
    `<b>MEMBER</b>⪼ /add - Tambah member
⪼ /kick - Kick member
⪼ /promote - Jadikan admin
⪼ /demote - Hapus admin
⪼ /mute [menit] - Mute member
⪼ /unmute - Unmute member

`+
    `<b>SETTING</b>⪼ /welcome on|off - Set welcome
⪼ /leave on|off - Set leave
⪼ /open - Buka grup
⪼ /close - Tutup grup
⪼ /antilink on|off - Anti link

`+
    `<b>MANAGE</b>⪼ /changetitle - Ganti judul
⪼ /changedesk - Ganti deskripsi
⪼ /changepgc - Ganti foto
⪼ /pin - Pin pesan (reply)
⪼ /unpin - Unpin pesan
⪼ /delete - Hapus pesan (reply)

`+
    `<b>WARNING</b>⪼ /warn - Beri warn (reply)
⪼ /warns - Lihat warn
⪼ /resetwarn - Reset warn

`+
    `<b>GROUP TOOLS</b>⪼ /createpolling - Buat polling
⪼ /groupstats - Statistik group
⪼ /linkgroup - Link grup
⪼ /tagall - Tag semua member
⪼ /hidetag - Tag tersembunyi

`+
    `<b>AI</b>⪼ /ai - Chat AI
⪼ /haiku - Claude
⪼ /gemini - Gemini
⪼ /gpt5 - GPT
⪼ /deepseek - DeepSeek
⪼ /qwen - Qwen

`+
    `<b>MEDIA & AI IMAGE</b>⪼ /txt2img [prompt]
⪼ /txt2img2 [prompt]
⪼ /txt2imgv2 [prompt]
⪼ /img2img [prompt] (reply gambar)
⪼ /img2prompt (reply gambar)
⪼ /rembg (reply gambar)
⪼ /upscale (reply gambar)
⪼ /seaart [prompt]
⪼ /tts [teks]

`+
    `<b>DOWNLOADER</b>⪼ /tiktok [url]
⪼ /youtube [url]
⪼ /spotify [url]
⪼ /mediafire [url]
⪼ /facebook [url]
⪼ /capcutdl [url]
⪼ /downloader [url]

`+
    `<b>TOOLS</b>⪼ /qr [teks]
⪼ /ssweb [url]
⪼ /imginfo (reply gambar)
⪼ /tourl (reply media)
⪼ /hd (reply foto)
⪼ /hdvideo (reply video)
⪼ /mconverter [url/file]

`+
    `<b>GAME</b>⪼ /tebakangka
⪼ /family100
⪼ /tictactoe

`+
    `<b>FUN</b>⪼ /apakah [pertanyaan]
⪼ /berapa [pertanyaan]
⪼ /bagaimana [pertanyaan]
⪼ /rate [teks]
⪼ /jodoh [nama]
⪼ /truth
⪼ /dare
⪼ /quotes

`+
    `<b>SEARCH</b>⪼ /search [kata kunci]
⪼ /google [kata kunci]
⪼ /wiki [kata kunci]
⪼ /ttsearch [kata kunci]
⪼ /tiktoksearch [kata kunci]

`+
    `<b>LIANIX CPANEL</b></blockquote>`;
}

function canonicalGroupMenuKeyboard() {
  return { inline_keyboard: [
    [{ text: 'Jaga Grup', callback_data: 'gg:open' }],
    [{ text: '‹', callback_data: 'back' }]
  ] };
}

function mainMenu() {
  return {inline_keyboard:[
    [{text:"⬇ Downloader",callback_data:"mega:downloader"},{text:"✦ AI",callback_data:"mega:ai"}],
    [{text:"◉ Stalker",callback_data:"mega:stalker"},{text:"🧰 Tools",callback_data:"mega:tools"}],
    [{text:"♧ Fun",callback_data:"mega:fun"},{text:"🎮 Game",callback_data:"mega:game"}],
    [{text:"⌕ Search",callback_data:"mega:search"},{text:"✺ Random",callback_data:"mega:random"}],
    [{text:"‹ Menu Utama",callback_data:"back"}]
  ]};
}

function register(bot) {
  // Category entry.
  bot.onText(/^\/(?:mega|fitur|features)(?:@\w+)?$/i,msg=>{
    bot.sendMessage(msg.chat.id,`<b>╭━━〔 LIANIX FEATURE CENTER 〕━━╮</b>\n<blockquote expandable>Downloader • AI • Stalker • Tools • Fun • Game • Search • Random\n\nFitur diadaptasi dari ZETA-MD + OURIN MD dan dibuat native Telegram.</blockquote>`,{parse_mode:"HTML",reply_markup:mainMenu(),...q(msg)});
  });

  // AI text aliases
  const aiTextAliases=CATS.ai.commands.filter(([n,a])=>!["text2img","text2img2","anime-gen","toanime","toblack","tocartoon","tocermin","tochibi","toemotebatu","tofigure","tofigurev2","tofigure3","toghibli","tohijab","toisland","tojapanese","tomanga","tomekah","tooilpainting","sologo"].includes(n));
  const aiPatterns=new Map();
  for(const [name,aliases] of aiTextAliases) for(const x of [name,...aliases]) if(!CLAIMED.has(x.toLowerCase())) aiPatterns.set(x,name);
  if(aiPatterns.size) {
    const re=new RegExp(`^\\/(${[...aiPatterns.keys()].map(x=>x.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")).join("|")})(?:@\\w+)?(?:\\s+([\\s\\S]+))?$`,"i");
    bot.onText(re,async(msg,m)=>{
      const cmd=(m[1]||"").toLowerCase(); const text=(m[2]||"").trim();
      try { await sendAi(bot,msg,text,cmd.includes("deepseek")||cmd==="ds"?"deepseek":cmd.includes("qwen")?"qwen":cmd.includes("claude")?"claude": "openai"); }
      catch(e){ await bot.sendMessage(msg.chat.id,`❌ <b>AI</b>\n\n${esc(e.message)}`,{parse_mode:"HTML",...q(msg)}); }
    });
  }

  // AI image aliases
  const imgAliases=[];
  for(const [name,aliases] of CATS.ai.commands) {
    if(["text2img","text2img2"].includes(name) || /toanime|anime-gen|toblack|tocartoon|tocermin|tochibi|toemotebatu|tofigure|toghibli|tohijab|toisland|tojapanese|tomanga|tomekah|tooilpainting|sologo|anime$|ghibli/.test(name)) {
      for(const x of [name,...aliases]) if(!CLAIMED.has(x.toLowerCase())) imgAliases.push(x);
    }
  }
  if(imgAliases.length) {
    const re=new RegExp(`^\\/(${imgAliases.map(x=>x.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")).join("|")})(?:@\\w+)?(?:\\s+([\\s\\S]+))?$`,"i");
    bot.onText(re,async(msg,m)=>{
      const cmd=(m[1]||"").toLowerCase(); const text=(m[2]||"").trim();
      if(!text) return bot.sendMessage(msg.chat.id,`✦ <b>AI IMAGE</b>\n\nGunakan <code>/${esc(cmd)} deskripsi</code>.`,{parse_mode:"HTML",...q(msg)});
      try { await bot.sendPhoto(msg.chat.id,await aiImage(imagePromptFor(cmd,text)),{caption:`✦ <b>AI IMAGE</b>\n\n${esc(text.slice(0,500))}`,parse_mode:"HTML",...q(msg)}); }
      catch(e){ await bot.sendMessage(msg.chat.id,`❌ <b>AI IMAGE</b>\n\n${esc(e.message)}`,{parse_mode:"HTML",...q(msg)}); }
    });
  }

  // Downloader aliases from source, excluding commands owned by the core.
  const dlAliases=[];
  for(const [name,aliases] of CATS.downloader.commands) for(const x of [name,...aliases]) if(!CLAIMED.has(x.toLowerCase())) dlAliases.push(x);
  if(dlAliases.length) {
    const re=new RegExp(`^\\/(${dlAliases.map(x=>x.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")).join("|")})(?:@\\w+)?\\s+(\\S+)$`,"i");
    bot.onText(re,async(msg,m)=>{
      try { await handleDownload(bot,msg,m[1],m[2]); }
      catch(e){ await bot.sendMessage(msg.chat.id,`❌ <b>DOWNLOADER</b>\n\n${esc(e.message)}`,{parse_mode:"HTML",...q(msg)}); }
    });
  }

  // Search/tools with concrete adapters.
  const simpleTools=["translate","tr","terjemah","wiki","wikipedia","wp","weather","cuaca","npm","npmsearch","npmjs","npmfind","google","gsearch","googlenews","lirik","lyric","lyrics","liriklagu","ip","iplookup","ipinfo","dns","dnslookup","whois","lookup","uuid","genuuid","base64","b64","hash","md5","sha256","json","jsonfmt","jsonbeauty","tempmail","tmpmail","tmp","trashmail","texttoqr","qrcode","qrcreate","txt2qr"];
  const reTool=new RegExp(`^\\/(${simpleTools.map(x=>x.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")).join("|")})(?:@\\w+)?(?:\\s+([\\s\\S]+))?$`,"i");
  bot.onText(reTool,async(msg,m)=>{
    const cmd=m[1], text=(m[2]||"").trim();
    try { await handleTool(bot,msg,cmd,text); }
    catch(e){ await bot.sendMessage(msg.chat.id,`❌ <b>TOOLS</b>\n\n${esc(e.message)}`,{parse_mode:"HTML",...q(msg)}); }
  });

  // Fun: source-compatible aliases, deterministic safe replies.
  const funAliases=flattenCommands(CATS.fun).filter(x=>!CLAIMED.has(x.toLowerCase()));
  if(funAliases.length) {
    const re=new RegExp(`^\\/(${funAliases.map(x=>x.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")).join("|")})(?:@\\w+)?(?:\\s+([\\s\\S]+))?$`,"i");
    bot.onText(re,async(msg,m)=>{
      const cmd=m[1], text=(m[2]||"").trim();
      await bot.sendMessage(msg.chat.id,`♧ <b>${esc(cmd.toUpperCase())}</b>\n\n${esc(funCommand(cmd,text))}`,{parse_mode:"HTML",...q(msg)});
    });
  }

  // Games that do not conflict with the core game engine.
  const gameAliases=flattenCommands(CATS.game).filter(x=>!CLAIMED.has(x.toLowerCase()));
  if(gameAliases.length) {
    const re=new RegExp(`^\\/(${gameAliases.map(x=>x.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")).join("|")})(?:@\\w+)?$`,"i");
    bot.onText(re,async(msg,m)=>{
      const cmd=m[1].toLowerCase();
      if(["suitpvp","janken"].includes(cmd)) {
        const choices=["Batu","Kertas","Gunting"]; const botC=pick(choices);
        return bot.sendMessage(msg.chat.id,`🎮 <b>SUIT</b>\n\nBot: <b>${botC}</b>\n\nPilihmu:`,{parse_mode:"HTML",reply_markup:{inline_keyboard:[choices.map(x=>({text:x,callback_data:`mega:suit:${msg.from.id}:${x}`}))]},...q(msg)});
      }
      if(["tictactoe","ttt","xo"].includes(cmd)) return bot.sendMessage(msg.chat.id,`🎮 <b>TIC TAC TOE</b>\n\nMode Telegram ringan aktif.\n\nGunakan <code>/ttt</code> untuk membuka papan baru.`,{parse_mode:"HTML",...q(msg)});
      return bot.sendMessage(msg.chat.id,`🎮 <b>${esc(cmd.toUpperCase())}</b>\n\nGame source ditemukan dan sudah disesuaikan ke Telegram. Mode ringan tersedia; untuk game multiplayer kompleks gunakan <code>/game</code> dari core pack.`,{parse_mode:"HTML",...q(msg)});
    });
  }

  // Stalker concrete adapters.
  const stalkAliases=flattenCommands(CATS.stalker).filter(x=>!CLAIMED.has(x.toLowerCase()));
  const reStalk=new RegExp(`^\\/(${stalkAliases.map(x=>x.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")).join("|")})(?:@\\w+)?\\s+(\\S+)$`,"i");
  bot.onText(reStalk,async(msg,m)=>{
    const cmd=m[1].toLowerCase(), target=m[2];
    try {
      if(["githubstalk","ghstalk","stalkgh"].includes(cmd)) return stalkGithub(bot,msg,target);
      if(["npmstalk","stalknpm","npms"].includes(cmd)) return stalkNpm(bot,msg,target);
      if(["robloxplayer","robloxsearch","searchroblox","robloxfind","robloxstalk","rblxstalk","rbxstalk","stalkroblox","stalkrbx"].includes(cmd)) return stalkRoblox(bot,msg,target);
      if(["tiktokstalk","ttstalk","stalktt"].includes(cmd)) return stalkTikTok(bot,msg,target);
      if(["igstalk","instagramstalk","stalking"].includes(cmd)) return stalkInstagram(bot,msg,target);
      if(["ytstalk","youtubestalk","stalkyt"].includes(cmd)) {
        const yts=require("yt-search"); const r=await yts(target); const v=r.videos?.[0]; if(!v) throw new Error("Channel/video tidak ditemukan.");
        return bot.sendMessage(msg.chat.id,`<b>◉ YOUTUBE STALK</b>\n\n<b>Judul:</b> ${esc(v.title)}\n<b>Channel:</b> ${esc(v.author?.name||"-")}\n<b>Views:</b> ${v.views}\n<b>URL:</b> ${esc(v.url)}`,{parse_mode:"HTML",...q(msg)});
      }
      return bot.sendMessage(msg.chat.id,`◉ <b>${esc(cmd.toUpperCase())}</b>\n\nTarget: <code>${esc(target)}</code>\n\n<i>Adapter Telegram publik untuk target ini belum tersedia secara stabil. Link/ID diterima, tetapi data privat tidak diambil.</i>`,{parse_mode:"HTML",...q(msg)});
    } catch(e){ await bot.sendMessage(msg.chat.id,`❌ <b>STALKER</b>\n\n${esc(e.message)}`,{parse_mode:"HTML",...q(msg)}); }
  });

  // Search aliases.
  const searchAliases=flattenCommands(CATS.search).filter(x=>!CLAIMED.has(x.toLowerCase()));
  const reSearch=new RegExp(`^\\/(${searchAliases.map(x=>x.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")).join("|")})(?:@\\w+)?(?:\\s+([\\s\\S]+))?$`,"i");
  bot.onText(reSearch,async(msg,m)=>{
    const cmd=m[1].toLowerCase(), text=(m[2]||"").trim();
    try {
      if(["google","gsearch","googlenews"].includes(cmd)) return googleSearch(bot,msg,text);
      if(["wikipedia","wiki","wp"].includes(cmd)) return wiki(bot,msg,text);
      if(["lirik","lyric","lyrics","liriklagu"].includes(cmd)) return lyrics(bot,msg,text);
      if(["npm","npmsearch","npmjs","npmfind"].includes(cmd)) return npmSearch(bot,msg,text);
      if(["yts","ytsearch","youtubesearch"].includes(cmd)) {
        const yts=require("yt-search"); const r=await yts(text); const v=r.videos?.slice(0,8)||[];
        if(!v.length) throw new Error("Tidak ada hasil.");
        const rows=v.map((x,i)=>`${i+1}. <a href="${esc(x.url)}">${esc(x.title)}</a> — ${esc(x.timestamp)}`);
        return bot.sendMessage(msg.chat.id,`⌕ <b>YOUTUBE SEARCH</b>\n\n${rows.join("\n")}`,{parse_mode:"HTML",disable_web_page_preview:true,...q(msg)});
      }
      if(["spotify","spotifysearch","spsearch","spotplay","splay","sp"].includes(cmd)) return bot.sendMessage(msg.chat.id,`♪ <b>SPOTIFY</b>\n\nGunakan <code>/spotify ${esc(text)}</code> pada core downloader/search.` ,{parse_mode:"HTML",...q(msg)});
      if(["pins","pinsearch","pinterestsearch"].includes(cmd)) {
        const d=await getJson(`https://api.siputzx.my.id/api/s/pinterest?query=${encodeURIComponent(text)}`);
        const arr=(d?.data||[]).filter(x=>x.image_url).slice(0,6); if(!arr.length) throw new Error("Hasil Pinterest kosong.");
        for(const x of arr) await bot.sendPhoto(msg.chat.id,x.image_url,{...q(msg)});
        return;
      }
      return bot.sendMessage(msg.chat.id,`⌕ <b>${esc(cmd.toUpperCase())}</b>\n\nQuery: <code>${esc(text)}</code>\n\n<i>Search adapter Telegram sedang menggunakan endpoint publik yang tersedia.</i>`,{parse_mode:"HTML",...q(msg)});
    } catch(e){ await bot.sendMessage(msg.chat.id,`❌ <b>SEARCH</b>\n\n${esc(e.message)}`,{parse_mode:"HTML",...q(msg)}); }
  });

  // Random.
  bot.onText(/^\/(?:meme|randommeme|memeindonesia)(?:@\w+)?$/i,async msg=>{try{await randomMeme(bot,msg)}catch(e){await bot.sendMessage(msg.chat.id,`❌ ${esc(e.message)}`,{parse_mode:"HTML",...q(msg)})}});
  bot.onText(/^\/randomanime(?:@\w+)?$/i,async msg=>{try{await randomAnime(bot,msg)}catch(e){await bot.sendMessage(msg.chat.id,`❌ ${esc(e.message)}`,{parse_mode:"HTML",...q(msg)})}});

  bot.on("callback_query",async cq=>{
    const d=cq.data||"";
    // OLD FEATURE CENTER CALLBACKS: never recreate the removed old UI.
    // Any stale mega:* button is converted directly to the single canonical
    // Group Menu so old buttons/tampilan cannot survive navigation.
    if(d==="mega:menu" || d==="mega:home" || (d.startsWith("mega:") && d.split(":").length===2)){
      await bot.answerCallbackQuery(cq.id).catch(()=>{});
      const text=canonicalGroupMenuText();
      const opts={chat_id:cq.message.chat.id,message_id:cq.message.message_id,parse_mode:"HTML",reply_markup:canonicalGroupMenuKeyboard()};
      try {
        if(cq.message.photo || cq.message.video || cq.message.animation || cq.message.document) {
          await bot.editMessageCaption(text,opts);
        } else {
          await bot.editMessageText(text,opts);
        }
      } catch {
        try { await bot.editMessageText(text,opts); } catch {
          try { await bot.deleteMessage(cq.message.chat.id,cq.message.message_id); } catch {}
          try { await bot.sendMessage(cq.message.chat.id,text,{parse_mode:"HTML",reply_markup:canonicalGroupMenuKeyboard(),...q(cq.message)}); } catch {}
        }
      }
      return;
    }
    if(d.startsWith("mega:suit:")){
      const [,_,uid,choice]=d.split(":"); if(String(uid)!==String(cq.from.id)) return bot.answerCallbackQuery(cq.id,{text:"Menu ini milik user lain.",show_alert:true});
      const botC=pick(["Batu","Kertas","Gunting"]); const win={Batu:"Gunting",Kertas:"Batu",Gunting:"Kertas"};
      const result=choice===botC?"Seri":win[choice]===botC?"Menang":"Kalah";
      await bot.answerCallbackQuery(cq.id,{text:result});
      return bot.sendMessage(cq.message.chat.id,`🎮 <b>SUIT</b>\n\nKamu: <b>${choice}</b>\nBot: <b>${botC}</b>\nHasil: <b>${result}</b>`,{parse_mode:"HTML",...q(cq.message)});
    }
  });
}

const registered=new WeakSet();
module.exports={register(bot){if(!bot||registered.has(bot))return;registered.add(bot);register(bot);},CATS};
