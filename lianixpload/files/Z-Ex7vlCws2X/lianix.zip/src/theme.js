// src/theme.js
// ============================================================
//  THEME ENGINE - Auto Cycle KHUSUS warna inline button.
//  Timer cycle tidak boleh mengubah/edit isi text atau caption pesan.
//  Yang direfresh saat warna berganti hanyalah reply_markup keyboard.
//  Dikontrol lewat Dev Panel (khusus Owner).
// ============================================================

// Telegram Bot API terbaru mendukung `style` pada KeyboardButton dan
// InlineKeyboardButton: primary (biru), success (hijau), danger (merah).
// Tema Lianix memakai field resmi ini agar Auto Cycle benar-benar mengubah
// warna background tombol, bukan sekadar mengganti emoji pada label.
const THEMES = [
  { key: "primary", name: "Biru", style: "primary", deco: "⟐", accent: "🔵" },
  { key: "danger", name: "Merah", style: "danger", deco: "⟠", accent: "🔴" },
  { key: "success", name: "Hijau", style: "success", deco: "⟡", accent: "🟢" },
  { key: "mono", name: "Hitam Putih", style: null, deco: "⌇", accent: "⬛" },
];

// Sama seperti implementasi Kairux: default netral, lalu cycle
// primary -> danger -> success -> mono. Yang berubah HANYA style button.
let currentIndex = 3;
let cycling = false;
let intervalMs = 10000;
let timer = null;
let lastBot = null;
let lastBuildFn = null;
let watchdog = null;
let rateLimitedUntil = 0;
let cycleInFlight = false;

const registry = new Map();

function getTheme() {
  return THEMES[currentIndex];
}

// Nempelin field `style` resmi Telegram ke sebuah tombol, sesuai tema
// yang lagi aktif (atau tema yang di-pass manual). Kalau style-nya null
// (tema mono), field style sengaja gak ditambahin sama sekali.
function cleanButtonLabel(value, callbackData) {
  const original = String(value ?? '');
  if (/buy script|dev panel/i.test(original)) return original;

  const normalized = original.normalize('NFKC');
  const controlCallback = String(callbackData || '');
  const isControl = /(?:^|[:_])(plus|minus|inc|dec|increase|decrease|adjust|threshold_(?:up|down)|cpu_(?:up|down)|disk_(?:up|down)|add|del)(?:$|[:_\-])/i.test(controlCallback);
  const controlOnly = /^[+−–—±＋－➕➖-]\s*$/.test(normalized);

  const statusPrefix = normalized.includes('🟢') ? '🟢 ' : normalized.includes('🔴') ? '🔴 ' : '';
  let cleaned = normalized
    // Hapus ikon dekoratif umum. Status ON/OFF hijau/merah dipertahankan secara eksplisit.
    .replace(/[\p{Extended_Pictographic}\u200B-\u200D\uFE0E\uFE0F\u{1F3FB}-\u{1F3FF}]/gu, '')
    // Hapus dekorasi visual yang memang bukan bagian dari teks button.
    .replace(/[•·◆◇◈◉⟐⟡⌖↯◌✦✧★☆✓✔✕✖⚙▣◒]/gu, '')
    .replace(/\s{2,}/g, ' ')
    .trim();

  // Kontrol +/- harus tetap ada karena memang merupakan bagian dari fungsi.
  if (isControl || controlOnly) {
    const controlPrefix = normalized.match(/^[\s]*(?:\+|-|−|–|—|±|＋|－|➕|➖)/u);
    if (controlPrefix) {
      cleaned = controlPrefix[0].trim() + (cleaned.replace(/^[+−–—±＋－➕➖-]\s*/u, '') ? ' ' + cleaned.replace(/^[+−–—±＋－➕➖-]\s*/u, '') : '');
    }
  }

  // Jangan mengganti tombol ikon dengan placeholder "Back". Ikon asli
  // harus tetap terlihat dan tidak boleh berubah menjadi tombol palsu.
  cleaned = cleaned.replace(/^(?:ON|OFF)\s*[•·-]?\s*/i, m => m);
  return (statusPrefix + (cleaned || normalized.trim() || 'Menu')).trim();
}

function styled(btn, t) {
  const theme_ = t || getTheme();
  const out = { ...btn };
  if (theme_ && ["primary", "success", "danger"].includes(theme_.style)) out.style = theme_.style;
  else delete out.style;
  return out;
}

function getThemeList() {
  return THEMES;
}

function setThemeIndex(i) {
  if (i < 0 || i >= THEMES.length) return getTheme();
  currentIndex = i;
  return getTheme();
}

function nextTheme() {
  currentIndex = (currentIndex + 1) % THEMES.length;
  return getTheme();
}

function registerMenuMessage(chatId, messageId, userId, username, buildFn = null) {
  const key = String(chatId);
  const previous = registry.get(key);
  // A chat may only have one canonical dashboard registered. If a fallback
  // created a new message, remove the previous dashboard so its old buttons
  // can never remain visible beside the new UI.
  if (previous && String(previous.messageId) !== String(messageId)) {
    try {
      if (global.__lianixBotForMenuRegistry?.deleteMessage) {
        global.__lianixBotForMenuRegistry.deleteMessage(chatId, previous.messageId).catch(() => {});
      }
    } catch {}
  }
  registry.set(key, { messageId, userId, username, buildFn: typeof buildFn === "function" ? buildFn : null });
}

function unregisterMenuMessage(chatId) {
  registry.delete(String(chatId));
}

function bindMenuBot(bot) {
  global.__lianixBotForMenuRegistry = bot;
}

// buildFn(userId, username) harus balikin { text, reply_markup }
async function refreshAllRegistered(bot, buildFn) {
  if (!bot || typeof bot.editMessageReplyMarkup !== "function") return;
  if (Date.now() < rateLimitedUntil) return;
  for (const [chatId, entry] of registry.entries()) {
    if (Date.now() < rateLimitedUntil) break;
    const { messageId, userId, username } = entry;
    try {
      const builder = typeof entry.buildFn === "function" ? entry.buildFn : buildFn;
      if (typeof builder !== "function") continue;
      const payload = builder(userId, username) || {};
      const replyMarkup = payload.reply_markup;
      if (!replyMarkup || !Array.isArray(replyMarkup.inline_keyboard)) continue;
      // Cycle hanya refresh markup. Text/caption tidak disentuh.
      await bot.editMessageReplyMarkup(replyMarkup, { chat_id: chatId, message_id: messageId });
      if (registry.size > 1) await new Promise(r => setTimeout(r, 60));
    } catch (e) {
      const desc = String(e?.response?.body?.description || e?.message || e || "");
      const retryAfter = Number(e?.response?.body?.parameters?.retry_after || 0);
      if (retryAfter > 0 || /429|too many requests|retry after/i.test(desc)) {
        const wait = retryAfter > 0 ? retryAfter : 5;
        rateLimitedUntil = Date.now() + wait * 1000 + 250;
        break;
      }
      if (/message to edit not found|message.*not found|chat not found|blocked|kicked/i.test(desc)) registry.delete(chatId);
    }
  }
}

function startAutoCycle(bot, buildFn, ms) {
  if (!bot || typeof buildFn !== "function") return false;
  if (ms && Number.isFinite(Number(ms)) && Number(ms) >= 1000) intervalMs = Number(ms);
  lastBot = bot; lastBuildFn = buildFn;
  if (timer) clearInterval(timer);
  if (watchdog) clearInterval(watchdog);
  cycling = true;
  const tick = () => {
    if (!cycling || cycleInFlight || Date.now() < rateLimitedUntil) return;
    cycleInFlight = true;
    nextTheme();
    Promise.resolve(refreshAllRegistered(lastBot, lastBuildFn)).finally(() => { cycleInFlight = false; });
  };
  timer = setInterval(tick, intervalMs);
  watchdog = setInterval(() => {
    if (cycling && !timer) timer = setInterval(tick, intervalMs);
  }, 30000);
  return true;
}

function stopAutoCycle() {
  cycling = false;
  if (timer) clearInterval(timer);
  if (watchdog) clearInterval(watchdog);
  timer = null;
  watchdog = null;
}

function isCycling() {
  return cycling;
}

function getIntervalMs() {
  return intervalMs;
}

function setIntervalMs(ms) {
  intervalMs = ms;
  if (cycling) {
    // restart pake interval baru, tapi butuh bot+buildFn lagi dari luar,
    // jadi ini cuma nyimpen nilainya -> caller yang panggil ulang startAutoCycle
  }
  return intervalMs;
}

module.exports = {
  THEMES,
  getTheme,
  getThemeList,
  setThemeIndex,
  nextTheme,
  styled,
  registerMenuMessage,
  unregisterMenuMessage,
  bindMenuBot,
  startAutoCycle,
  stopAutoCycle,
  isCycling,
  getIntervalMs,
  setIntervalMs,
};
