const fs = require('fs-extra');
const Plfs = require('fs');
const { exec } = require("child_process");
const path = require('path');
const fetch = require('node-fetch');
const AdmZip = require("adm-zip");
const axios = require('axios');
const FormData = require('form-data');
const settings = require('../settings.js');
const { createCanvas, loadImage } = require("./optionalCanvas");
const sharp = require("sharp");

const OWNER_ID = settings.ownerId;

// State percakapan sementara untuk fitur /sendgmail.
// Gunakan object tanpa prototype agar key chat ID aman.
const pendingMessages = Object.create(null);

// Helper: ambil buffer gambar dari API pihak ketiga yang kadang flaky.
// Retry beberapa kali + validasi content-type, biar ga ngirim JSON error sebagai gambar.
async function fetchImageWithRetry(url, { retries = 2, timeout = 15000 } = {}) {
  let lastErr;
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      const resp = await axios.get(url, {
        responseType: "arraybuffer",
        timeout,
        validateStatus: () => true, // biar body error-nya bisa kita baca sendiri
      });

      const contentType = String(resp.headers["content-type"] || "");

      if (resp.status !== 200 || !contentType.startsWith("image/")) {
        let detail = `HTTP ${resp.status}`;
        try {
          const bodyText = Buffer.from(resp.data).toString("utf8").slice(0, 200);
          if (bodyText) detail += ` — ${bodyText}`;
        } catch {}
        const err = new Error(detail);
        err.status = resp.status;
        throw err;
      }

      return Buffer.from(resp.data);
    } catch (err) {
      lastErr = err;
      // kalau ini error client (400/404, dll) ga usah diulang-ulang, pasti tetep gagal
      if (err.status && err.status >= 400 && err.status < 500) break;
      if (attempt < retries) {
        await new Promise((r) => setTimeout(r, 900 * (attempt + 1)));
      }
    }
  }
  throw lastErr;
}

module.exports = (bot) => {

bot.onText(/\/tts(?:\s+(.+))?/, async (msg, match) => {
    const chatId = msg.chat.id;
    const text = match[1];

    if (text?.toLowerCase() === 'ttstalk') return;

    if (!text) {
        return bot.sendMessage(chatId, "Usage: /tts teksnya");
    }

    if (text.length > 200) {
        return bot.sendMessage(chatId, '◈ Teks terlalu panjang (maks 200 karakter).');
    }

    try {
        const ttsUrl = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(text)}&tl=id&client=tw-ob`;

        await bot.sendVoice(chatId, ttsUrl, {
            reply_to_message_id: msg.message_id
        });
    } catch (error) {
        bot.sendMessage(chatId, '◇ Gagal membuat audio TTS.');
    }
});


// WEB2APK
bot.onText(/\/web2apk(?:\s+(.+))?/, async (msg, match) => {
    const chatId = msg.chat.id;
    const url = match[1];

    if (!url) {
        return bot.sendMessage(chatId, "Usage: /web2apk https://website.com");
    }

    try {
        bot.sendMessage(chatId, "↻ Creating APK from website... Please wait 2-3 minutes.");
        
        const response = await axios.post('https://api.web2apk.com/generate', {
            url: url,
            appName: `App_${Date.now()}`,
            packageName: `com.webapp.${Date.now()}`,
            version: "1.0",
            versionCode: 1,
            icon: "https://cdn-icons-png.flaticon.com/512/1006/1006771.png",
            splashScreen: "https://via.placeholder.com/1080x1920/3B82F6/FFFFFF?text=Loading..."
        });

        const { data } = response;

        if (data.success && data.apkUrl) {
            const apkResponse = await axios.get(data.apkUrl, { responseType: 'stream' });
            const apkPath = `./apk_${Date.now()}.apk`;

            const writer = fs.createWriteStream(apkPath);
            apkResponse.data.pipe(writer);

            writer.on('finish', async () => {
                await bot.sendDocument(chatId, apkPath, {
                    caption: `▭ APK Generated!\n⟐ Website: ${url}\n⬢ Size: ${(fs.statSync(apkPath).size / 1024 / 1024).toFixed(2)} MB`
                });
                fs.unlinkSync(apkPath);
            });
        }
    } catch (error) {
        bot.sendMessage(chatId, "◇ Gagal generate APK.");
    }
});
bot.onText(/\/nsw/, async (msg) => {
  const chatId = msg.chat.id;

  const loading = await bot.sendMessage(chatId, "⏳ Mengambil foto...");

  try {
    const res = await fetch("https://api.waifu.pics/nsfw/waifu");
    const data = await res.json();

    if (!data.url) {
      return bot.editMessageText("◇ Gagal mengambil gambar.", {
        chat_id: chatId,
        message_id: loading.message_id
      });
    }

    await bot.editMessageText("✦ Sukses!", {
      chat_id: chatId,
      message_id: loading.message_id
    });

    await bot.sendPhoto(chatId, data.url, {
      caption: "⟡ Random NSFW"
    });

  } catch (err) {
    console.error(err);
    bot.editMessageText("◇ Error saat mengambil gambar.", {
      chat_id: chatId,
      message_id: loading.message_id
    });
  }
});
// LYRICS
bot.onText(/\/lyrics(?:\s+(.+))?/, async (msg, match) => {
    const chatId = msg.chat.id;
    const query = match[1];

    if (!query) {
        return bot.sendMessage(chatId, `⌖ *Usage:* /lyrics artist - title`, {
            parse_mode: "Markdown"
        });
    }

    try {
        const response = await axios.get(`https://api.lyrics.ovh/v1/${encodeURIComponent(query)}`);
        const lyrics = response.data.lyrics;

        if (!lyrics) {
            return bot.sendMessage(chatId, "◇ Lirik tidak ditemukan");
        }

        if (lyrics.length > 3000) {
            const parts = lyrics.match(/[\s\S]{1,3000}/g);

            bot.sendMessage(chatId, `
♪ *LYRICS - ${query.toUpperCase()}*

${parts[0]}
...
(1/${parts.length})
            `.trim(), {
                parse_mode: 'Markdown'
            });

            for (let i = 1; i < parts.length; i++) {
                setTimeout(() => {
                    bot.sendMessage(chatId, parts[i], {
                        parse_mode: 'Markdown'
                    });
                }, i * 800);
            }

        } else {
            bot.sendMessage(chatId, `
♪ *LYRICS - ${query.toUpperCase()}*

${lyrics}

⌕ /lyrics artist - title
            `.trim(), {
                parse_mode: 'Markdown'
            });
        }

    } catch (error) {
        bot.sendMessage(chatId, "◇ Lirik tidak ditemukan");
    }
});
// [removed] /spamngl - message-flooding/harassment tool
bot.onText(/\/sendgmail(?:\s+(.+))?/, async (msg, match) => {
    const chatId = msg.chat.id;
    const email = match[1];

    if (!email) {
        return bot.sendMessage(chatId, '◇ Cara penggunaan: /sendgmail target@gmail.com');
    }

    if (!email.endsWith('@gmail.com')) {
        return bot.sendMessage(chatId, '◇ Hanya email @gmail.com yang diperbolehkan. Contoh: /sendgmail example@gmail.com');
    }

    pendingMessages[chatId] = { email };
    const promptMsg = await bot.sendMessage(chatId, '✎ Masukkan SUBJECT email:');
    pendingMessages[chatId].promptMsgId = promptMsg.message_id;
});

bot.on('message', async (msg) => {
    const chatId = msg.chat.id;
    const messageId = msg.message_id;

    if (!pendingMessages[chatId]) return;

    const state = pendingMessages[chatId];

    try {
        if (state.promptMsgId) {
            await bot.deleteMessage(chatId, state.promptMsgId).catch(() => {});
        }
    } catch {}

    if (!state.subject) {
        state.subject = msg.text;
        const promptMsg = await bot.sendMessage(chatId, '✉ Masukkan PESAN yang ingin dikirim:');
        state.promptMsgId = promptMsg.message_id;
        return;
    }

    if (!state.message) {
        state.message = msg.text;
        const promptMsg = await bot.sendMessage(chatId, '⌗ Masukkan JUMLAH pengiriman:');
        state.promptMsgId = promptMsg.message_id;
        return;
    }

    if (!state.count) {
        const count = parseInt(msg.text);
        if (isNaN(count) || count <= 0) {
            const promptMsg = await bot.sendMessage(chatId, '◇ Masukkan angka yang valid.');
            state.promptMsgId = promptMsg.message_id;
            return;
        }

        state.count = count;

        if (state.promptMsgId) {
            await bot.deleteMessage(chatId, state.promptMsgId).catch(() => {});
        }

        bot.sendMessage(chatId, `⏳ Mengirim ${state.count} email ke ${state.email}...`);

        let success = 0;
        let failed = 0;

        for (let i = 0; i < state.count; i++) {
            try {
                await axios.get('https://api.fikmydomainsz.xyz/tools/sendmail/send', {
                    params: {
                        to: state.email,
                        subject: state.subject,
                        message: state.message
                    }
                });
                success++;
            } catch {
                failed++;
            }
        }

        const report = `
\`\`\`
◉ Selesai mengirim pesan!
Target : ${state.email}
Subject : ${state.subject}
Pesan : ${state.message}
Jumlah : ${state.count}

Informasi:
◉ Berhasil : ${success}
◇ Gagal : ${failed}
\`\`\`
        `;
        bot.sendMessage(chatId, report, { parse_mode: 'Markdown' });
        delete pendingMessages[chatId];
    }
});
bot.onText(/\/infogempa/, async (msg) => {
  const chatId = msg.chat.id;
  const sentMsg = await bot.sendMessage(chatId, '⏳ Mengambil informasi gempa terbaru...');

  try {
    const res = await axios.get('https://piereeapi.vercel.app/search/gempa');
    const data = res.data;

    if (!data || !data.status || !data.data) {
      return bot.editMessageText('◇ Tidak ada informasi gempa terbaru.', {
        chat_id: chatId,
        message_id: sentMsg.message_id
      });
    }

    const g = data.data;
    const replyText = 
`⟐ *Info Gempa Terkini*
*Tanggal:* ${g.tanggal || "-"}
*Jam:* ${g.jam || "-"}
*Magnitude:* ${g.magnitude || "-"}
*Kedalaman:* ${g.kedalaman || "-"}
*Wilayah:* ${g.wilayah || "-"}
*Potensi:* ${g.potensi || "-"}
*Koordinat:* ${g.koordinat || "-"}
*Lintang:* ${g.lintang || "-"}
*Bujur:* ${g.bujur || "-"}`;

    await bot.sendPhoto(chatId, g.shakemap || g.map || g.image, {
      caption: replyText,
      parse_mode: 'Markdown'
    });

    await bot.deleteMessage(chatId, sentMsg.message_id);

  } catch (err) {
    bot.editMessageText('◇ Terjadi kesalahan saat mengambil data gempa.', {
      chat_id: chatId,
      message_id: sentMsg.message_id
    });
  }
});

bot.onText(/\/ytsearch(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const query = match[1]?.trim();

  if (!query) {
    return bot.sendMessage(chatId, '◇ Contoh penggunaan: /ytsearch lucu');
  }

  const sentMsg = await bot.sendMessage(chatId, '⌕ Mencari video YouTube...');

  try {
    const res = await axios.get(`https://piereeapi.vercel.app/search/youtube?q=${encodeURIComponent(query)}&type=video`);
    const data = res.data;

    if (!data || !data.status || !data.data || !data.data.length) {
      return bot.editMessageText('◇ Video tidak ditemukan.', {
        chat_id: chatId,
        message_id: sentMsg.message_id
      });
    }

    const video = data.data[0];
    const caption = 
`▶ *${video.title}*
▭ Channel: [${video.channel?.name || "-"}](${video.channel?.url || video.url})
⏱ Durasi: ${video.duration || "-"}
⌂ Views: ${video.viewCount || "-"}
▦ Tayang: ${video.publishedTime || "-"}
↠ [Tonton di YouTube](${video.url})`;

    await bot.sendPhoto(chatId, video.thumbnail || video.thumbnails?.[0], {
      caption,
      parse_mode: 'Markdown'
    });

    await bot.deleteMessage(chatId, sentMsg.message_id);

  } catch (err) {
    bot.editMessageText('◇ Terjadi kesalahan saat mencari video.', {
      chat_id: chatId,
      message_id: sentMsg.message_id
    });
  }
});
bot.onText(/\/ttsearch (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const query = match[1];

  if (!query) return bot.sendMessage(chatId, '◇ Contoh penggunaan:\n/ttsearch lucu');

  const loadingMsg = await bot.sendMessage(chatId, '⏳ Mencari video TikTok...');

  try {
    const res = await fetch(`https://piereeapi.vercel.app/search/tiktok?q=${encodeURIComponent(query)}`);
    const data = await res.json();

    if (!data.status || !data.result || data.result.length === 0) {
      return bot.editMessageText('◇ Video tidak ditemukan.', { chat_id: chatId, message_id: loadingMsg.message_id });
    }

    // Ambil video pertama
    const video = data.result[0];

    let caption = `▶ *${video.title}*\n◉ ${video.author.nickname}\n⬢ Durasi: ${video.duration}s\n⟡ Download: ${video.download_count}\n↠ [Link Video](${video.play})`;
    
    // Kirim Video
    await bot.sendVideo(chatId, video.play, { caption, parse_mode: 'Markdown' });

    // Kirim Audio
    await bot.sendAudio(chatId, video.music, { 
      caption: `♪ Musik: ${video.music_info.title}\n◉ ${video.music_info.author}`, 
      parse_mode: 'Markdown' 
    });

    await bot.editMessageText('◉ Selesai mengirim video dan audio!', { chat_id: chatId, message_id: loadingMsg.message_id });
    
  } catch (err) {
    console.error(err);
    await bot.editMessageText('◇ Terjadi kesalahan saat mengambil data.', { chat_id: chatId, message_id: loadingMsg.message_id });
  }
});
bot.onText(/\/spotifysearch (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const query = match[1];
  if (!query) return bot.sendMessage(chatId, '◇ Contoh: /spotifysearch Graze The Roof');

  const wait = await bot.sendMessage(chatId, '⌕ Mencari lagu di Spotify...');

  try {
    const res = await fetch(`https://piereeapi.vercel.app/search/spotify?q=${encodeURIComponent(query)}`);
    const data = await res.json();

    if (!data.status || !data.results || data.results.length === 0) {
      return bot.editMessageText('◇ Tidak ditemukan hasil untuk pencarian tersebut.', { chat_id: chatId, message_id: wait.message_id });
    }

    const first = data.results[0];

    const caption = `♪ *${first.title}*\n◉ Artist: ${first.artist}\n⟡ Album: ${first.album}\n▦ Rilis: ${first.release_date}\n⏱ Durasi: ${first.duration}\n↠ [Dengarkan di Spotify](${first.url})`;

    await bot.editMessageText('◉ Ditemukan! Mengirim preview audio...', { chat_id: chatId, message_id: wait.message_id });

    await bot.sendPhoto(chatId, first.thumbnail, { caption, parse_mode: 'Markdown', disable_web_page_preview: false });

    // Coba kirim preview audio jika tersedia di API (optional)
    if (first.preview_url) {
      await bot.sendAudio(chatId, first.preview_url, { title: first.title, performer: first.artist });
    } else {
      await bot.sendMessage(chatId, '⚠ Tidak ada preview audio untuk lagu ini.');
    }

  } catch (err) {
    console.error(err);
    bot.editMessageText('◇ Terjadi kesalahan saat mencari lagu.', { chat_id: chatId, message_id: wait.message_id });
  }
});
bot.onText(/\/tvsearch(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const channelName = match[1]?.trim();

  if (!channelName) {
    return bot.sendMessage(chatId, '◇ Contoh penggunaan: /tvsearch trans7');
  }

  // Kirim pesan proses
  const sentMsg = await bot.sendMessage(chatId, '↻ Proses mengambil jadwal...');

  try {
    const res = await axios.get(`https://piereeapi.vercel.app/search/jadwaltv?channel=${encodeURIComponent(channelName)}`);
    const data = res.data;

    if (!data.status) {
      return bot.editMessageText(`◇ Jadwal TV untuk channel "${channelName}" tidak ditemukan.`, {
        chat_id: chatId,
        message_id: sentMsg.message_id
      });
    }

    const replyText = `Channel Name : ${data.channel}\nSchedule :\n${data.schedule.replace(/\\n/g, '\n')}`;

    bot.editMessageText(replyText, {
      chat_id: chatId,
      message_id: sentMsg.message_id
    });
  } catch (err) {
    bot.editMessageText('◇ Terjadi kesalahan saat mengambil jadwal TV.', {
      chat_id: chatId,
      message_id: sentMsg.message_id
    });
  }
});
bot.onText(/\/cekcuaca(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const kota = match[1];

  if (!kota) {
    return bot.sendMessage(chatId,
      '◇ Format salah.\n\nContoh penggunaan:\n/cekcuaca Jakarta'
    );
  }

  const wait = await bot.sendMessage(chatId, '⏳ Mengambil data cuaca...');

  try {
    const res = await fetch(`https://api.resellergaming.my.id/tools/cekcuaca?kota=${encodeURIComponent(kota)}`);
    const data = await res.json();

    if (!data.status) {
      return bot.editMessageText('◇ Gagal mendapatkan data cuaca.', {
        chat_id: chatId,
        message_id: wait.message_id
      });
    }

    const result = `
⟐ Kota: ${data.kota}
⟡ Suhu: ${data.suhu}
⌇ Deskripsi: ${data.deskripsi}
⌇ Kelembaban: ${data.kelembaban}
⌇ Angin: ${data.angin}
⌗ Tekanan: ${data.tekanan}
⌂ Visibility: ${data.visibility}
⏰ Update: ${data.update}
    `.trim();

    await bot.editMessageText(result, {
      chat_id: chatId,
      message_id: wait.message_id
    });

  } catch (err) {
    await bot.editMessageText('◇ Terjadi kesalahan.', {
      chat_id: chatId,
      message_id: wait.message_id
    });
  }
});
  bot.onText(/\/githubstalk (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const username = match[1]?.trim();

    if (!username) return bot.sendMessage(chatId, "Usage: /githubstalk <username>");

    try {
      const response = await axios.get(`https://piereeapi.vercel.app/stalk/github?user=${encodeURIComponent(username)}`);
      const data = response.data;

      if (!data || data.status === false || !data.data) {
        return bot.sendMessage(chatId, "◇ Username tidak di temukan");
      }

      const user = data.data;
      const caption = 
`◉ *GitHub Profile*
────────────────────────
⌕ *Username:* ${user.username}
⌇ *ID:* ${user.id}
⟐ *URL:* ${user.url}
◉ *Type:* ${user.type}
⟠ *Admin:* ${user.admin ? "Ya" : "Tidak"}

⌗ *Bio:* ${user.bio || "-"}
▭ *Company:* ${user.company || "-"}
⬡ *Location:* ${user.location || "-"}
✉ *Email:* ${user.email || "-"}
↠ *Blog:* ${user.blog || "-"}

⬢ *Public Repos:* ${user.public_repo}
✎ *Public Gists:* ${user.public_gists}
⌂ *Followers:* ${user.followers}
⌂ *Following:* ${user.following}

▦ *Dibuat:* ${new Date(user.created_at).toLocaleDateString()}
⟲ *Update Terakhir:* ${new Date(user.updated_at).toLocaleDateString()}
`;

      return bot.sendPhoto(chatId, user.profile_pic, { caption, parse_mode: "Markdown" });

    } catch (err) {
      console.error(err);
      return bot.sendMessage(chatId, "◇ Username tidak di temukan");
    }
  });

  bot.onText(/\/twitterstalk (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const username = match[1]?.trim();

    if (!username) return bot.sendMessage(chatId, "◇ Masukkan username Twitter!\nContoh: /twitterstalk siputzx");

    try {
      const { data } = await axios.post("https://api.siputzx.my.id/api/stalk/twitter", { user: username });

      if (!data.status) return bot.sendMessage(chatId, "◇ Gagal mengambil data Twitter.");

      const user = data.data;
      const caption = `
⌂ *${user.name}* (@${user.username})
⌇ ID: \`${user.id}\`
◉ Verified: ${user.verified ? "Yes" : "No"}
⬡ Lokasi: ${user.location || "-"}
▦ Bergabung: ${new Date(user.created_at).toLocaleDateString("id-ID")}
✎ Bio: ${user.description || "-"}

⌗ *Statistik*
⬡ Tweets: ${user.stats.tweets}
⌂ Followers: ${user.stats.followers}
⌂ Following: ${user.stats.following}
♥ Likes: ${user.stats.likes}
⬢ Media: ${user.stats.media}
      `;
      await bot.sendPhoto(chatId, user.profile.image, { caption, parse_mode: "Markdown" });

    } catch (err) {
      console.error(err);
      return bot.sendMessage(chatId, "⊘ Terjadi kesalahan saat mengambil data Twitter.");
    }
  });

  bot.onText(/\/pinstalk(?:\s+(.+))?/, async (msg, match) => {
    const chatId = msg.chat.id;
    const username = match[1]?.trim();

    if (!username) return bot.sendMessage(chatId, "◇ Gunakan: /pinstalk <username>");

    try {
      const response = await axios.get(`https://piereeapi.vercel.app/stalk/pinterest?q=${encodeURIComponent(username)}`);
      const data = response.data;

      if (!data || data.status === false || !data.data) {
        return bot.sendMessage(chatId, "◇ Username tidak di temukan");
      }

      const user = data.data;
      const caption =
`⬡ *Pinterest Profile*
────────────────────────
◉ *Username:* ${user.username}
⌇ *ID:* ${user.id}
⌂ *Full Name:* ${user.full_name || "-"}

⟐ *URL:* ${user.profile_url}
⚐ *Country:* ${user.country || "-"}
⬡ *Location:* ${user.location || "-"}

✎ *Bio:* ${user.bio || "-"}

⌗ *Stats*
• Pins: ${user.stats.pins}
• Followers: ${user.stats.followers}
• Following: ${user.stats.following}
• Boards: ${user.stats.boards}
• Likes: ${user.stats.likes}
• Saves: ${user.stats.saves}

↠ *Website:* ${user.website || "-"}
⟐ *Domain Verified:* ${user.domain_verified ? "Ya" : "Tidak"}

▦ *Dibuat:* ${user.created_at}
`;

      return bot.sendPhoto(chatId, user.image.original, { caption, parse_mode: "Markdown" });

    } catch (err) {
      console.error(err);
      return bot.sendMessage(chatId, "◇ Username tidak di temukan");
    }
  });

  bot.onText(/\/robloxstalk(?:\s+(.+))?/, async (msg, match) => {
    const chatId = msg.chat.id;
    const username = match[1]?.trim();

    if (!username) return bot.sendMessage(chatId, "◇ Gunakan: /robloxstalk <username>");

    try {
      const response = await axios.get(`https://piereeapi.vercel.app/stalk/roblox?user=${encodeURIComponent(username)}`);
      const data = response.data;

      if (!data || data.status === false || !data.data) {
        return bot.sendMessage(chatId, "◇ Username tidak di temukan");
      }

      const user = data.data;
      const basic = user.basic;
      const social = user.social;
      const avatarUrl = user.avatar?.data?.[0]?.imageUrl || "";

      const caption = 
`⬡ *Roblox Profile*
────────────────────────
◉ *Username:* ${basic.name}
⌇ *User ID:* ${basic.id}
⌖ *Display Name:* ${basic.displayName}
✎ *Description:* ${basic.description || "-"}

⏳ *Created:* ${new Date(basic.created).toLocaleDateString()}
⊘ *Banned:* ${basic.isBanned ? "Ya" : "Tidak"}
◉ *Verified Badge:* ${basic.hasVerifiedBadge ? "Ya" : "Tidak"}

⌗ *Social Stats*
• Friends: ${social.friends?.count || 0}
• Followers: ${social.followers?.count || 0}
• Following: ${social.following?.count || 0}
`;

      return bot.sendPhoto(chatId, avatarUrl, { caption, parse_mode: "Markdown" });

    } catch (err) {
      console.error(err);
      return bot.sendMessage(chatId, "◇ Username tidak di temukan");
    }
  });

bot.onText(/\/ytstalk(?: (.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const username = match[1];

  if (!username) {
    return bot.sendMessage(chatId, `◇ /ytstalk <username>`);
  }

  try {
    const res = await fetch(`https://piereeapi.vercel.app/stalk/youtube?username=${encodeURIComponent(username)}`);
    const data = await res.json();

    if (!data.status || !data.data?.channel) {
      return bot.sendMessage(chatId, `◇ Channel tidak ditemukan untuk username: ${username}`);
    }

    const ch = data.data.channel;
    const caption = 
`▭ *YouTube Stalk Result*
──────────────────
◉ *Username:* ${ch.username}
⌂ *Subscriber:* ${ch.subscriberCount}
▶ *Video Count:* ${ch.videoCount}
↠ *Channel URL:* ${ch.channelUrl}
✎ *Description:*
${ch.description ? ch.description.slice(0, 800) + (ch.description.length > 800 ? "..." : "") : "Tidak ada deskripsi."}`;

    await bot.sendPhoto(chatId, ch.avatarUrl, {
      caption,
      parse_mode: "Markdown"
    });
  } catch (e) {
    console.error(e);
    bot.sendMessage(chatId, "◇ Terjadi kesalahan saat mengambil data.");
  }
});
bot.onText(/\/ttstalk(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const username = match[1];

  if (!username) {
    return bot.sendMessage(chatId, `◇ /ttstalk <username>`);
  }

  bot.sendMessage(chatId, `⌕ Sedang mencari data TikTok @${username}...`);

  try {
    const res = await axios.get(`https://piereeapi.vercel.app/stalk/tiktok?username=${encodeURIComponent(username)}`);
    const data = res.data;

    if (!data.status || !data.data || !data.data.user) {
      return bot.sendMessage(chatId, `◇ Tidak ditemukan data untuk username: ${username}`);
    }

    const user = data.data.user;
    const stats = data.data.stats || {};

    const caption = `
▭ *TIKTOK STALK RESULT*
────────────────────
◉ *Username:* @${user.uniqueId || "-"}
⬡ *Nama:* ${user.nickname || "-"}
⟐ *Verified:* ${user.verified ? "◉ Ya" : "◇ Tidak"}
✎ *Bio:* ${user.signature || "-"}
⬢ *Follower:* ${stats.followerCount || 0}
⌂ *Following:* ${stats.followingCount || 0}
♥ *Likes:* ${stats.heartCount || stats.heart || 0}
▶ *Video:* ${stats.videoCount || 0}
⟠ *Akun Privat:* ${user.privateAccount ? "Ya" : "Tidak"}
────────────────────
◷ Data diperbarui: ${new Date(data.timestamp || Date.now()).toLocaleString("id-ID")}
`;

    await bot.sendPhoto(chatId, user.avatarLarger || user.avatarMedium || user.avatarThumb, {
      caption,
      parse_mode: "Markdown",
    });
  } catch (err) {
    console.error(err);
    bot.sendMessage(chatId, `⚠ Gagal mengambil data. Coba lagi nanti.`);
  }
});
bot.onText(/\/igdl(?:\s+(.+))?/, async (msg, match) => {
    const chatId = msg.chat.id;
    const url = match[1];

    if (!url) {
        return bot.sendMessage(chatId, "Usage: /igdl link_instagram");
    }
    
    try {
        const loadingMsg = await bot.sendMessage(chatId, "⬢ Mengunduh dari Instagram...");
        
        const apiUrl = `https://instagram-post-reels-stories-downloader.p.rapidapi.com/instagram/?url=${encodeURIComponent(url)}`;
        
        const response = await fetch(apiUrl, {
            headers: {
                'x-rapidapi-host': 'instagram-post-reels-stories-downloader.p.rapidapi.com',
                'x-rapidapi-key': 'c7de8dbae6msh28b2f2d11e3aec5p115350jsn2388a88272c5',
                'Accept': 'application/json'
            }
        });
        
        const data = await response.json();
        
        if (data.media && data.media.length > 0) {
            await bot.editMessageText(`◉ Ditemukan ${data.media.length} media!`, {
                chat_id: chatId,
                message_id: loadingMsg.message_id
            });
            
            for (let i = 0; i < Math.min(data.media.length, 5); i++) {
                const media = data.media[i];
                
                if (media.type === 'video' || media.type === 'reel') {
                    await bot.sendVideo(chatId, media.url, {
                        caption: i === 0
                        ? `⬢ *Instagram Downloader*\n\n◉ *Username:* ${data.username || 'Unknown'}\n✎ *Caption:* ${data.caption?.substring(0, 200) || 'No caption'}\n\n▼ *Downloaded via* @kinzxxoffc *Bot*`
                        : "",
                        parse_mode: 'Markdown',
                        supports_streaming: true
                    });
                } else {
                    await bot.sendPhoto(chatId, media.url, {
                        caption: i === 0
                        ? `⬢ *Instagram Downloader*\n\n◉ *Username:* ${data.username || 'Unknown'}\n\n▼ *Downloaded via* @kinzxxoffc *Bot*`
                        : "",
                        parse_mode: 'Markdown'
                    });
                }
                
                if (i < Math.min(data.media.length, 5) - 1) {
                    await new Promise(resolve => setTimeout(resolve, 1000));
                }
            }
            
            await bot.deleteMessage(chatId, loadingMsg.message_id);
            
        } else {
            throw new Error("Tidak ada media ditemukan");
        }
        
    } catch (error) {
        bot.sendMessage(chatId, `◇ Error: ${error.message}\n\nPastikan:\n1. Link valid\n2. Tidak private\n3. Coba ulang`, {
            reply_to_message_id: msg.message_id
        });
    }
});
  bot.onText(/^\/facebook(?:\s+(.+))?$/i, async (msg, match) => {
    const chatId = msg.chat.id;
    const url = match[1]?.trim();

    if (!url) {
      return bot.sendMessage(chatId,
        "⊘ Masukkan link Facebook!\n\nContoh:\n/facebook https://www.facebook.com/...",
        { parse_mode: "Markdown" }
      );
    }

    try {
      const api = `https://piereeapi.vercel.app/download/facebook?url=${encodeURIComponent(url)}`;
      const res = await axios.get(api).catch(() => null);

      if (!res?.data?.status || !res.data.result) {
        return bot.sendMessage(chatId, "◇ Gagal mengambil video dari Facebook. Pastikan link valid.");
      }

      const video = res.data.result;
      const videoUrl = video.hd || video.sd || null;

      if (!videoUrl) {
        return bot.sendMessage(chatId, "◇ Tidak ditemukan URL video valid.");
      }

      const caption = `⌗ *Facebook Video*\n▶ Resolusi: ${video.hd ? "HD" : "SD"}`;

      await bot.sendVideo(chatId, videoUrl, {
        caption,
        parse_mode: "Markdown"
      });

    } catch (err) {
      return bot.sendMessage(chatId, "◇ Terjadi kesalahan saat mengambil video dari Facebook.");
    }
  });
  
  bot.onText(/^\/capcutdl(?:\s+(.+))?$/i, async (msg, match) => {
    const chatId = msg.chat.id;
    const url = match[1]?.trim();

    if (!url || !url.includes("capcut.com")) {
      return bot.sendMessage(
        chatId,
        "⊘ Contoh penggunaan:\n`/capcutdl https://www.capcut.com/tv2/ZSBr4BaK6/`",
        { parse_mode: "Markdown" }
      );
    }

    let loadingMsg;
    try {
      loadingMsg = await bot.sendMessage(chatId, "↻ Mengambil video dari CapCut...");

      // Panggil API yang benar
      const res = await axios.get("https://api.resellergaming.my.id/download/capcut", {
        params: { url },
        headers: { accept: "application/json" }
      });

      const data = res.data.data;

      if (!res.data.status || !data || !data.videoUrl) {
        return bot.sendMessage(chatId, "◇ Gagal mengambil video. Pastikan link valid.");
      }

      const caption = `▶ *CapCut Downloader*

⬡ *Judul:* ${data.title || "-"}
◉ *Likes:* ${data.likes || "-"}
⌂ *Pengguna:* ${data.pengguna || "-"}
↠ *Source:* [Klik untuk lihat](${url})

_Sedang mengirim video..._`;

      // Kirim poster jika ada
      if (data.posterUrl) {
        await bot.sendPhoto(chatId, data.posterUrl, {
          caption,
          parse_mode: "Markdown"
        });
      } else {
        await bot.sendMessage(chatId, caption, { parse_mode: "Markdown" });
      }

      // Kirim video via URL langsung lebih aman
      await bot.sendVideo(chatId, data.videoUrl, {
        caption: "◉ Video berhasil didapatkan!",
        parse_mode: "Markdown"
      });

      if (loadingMsg) await bot.deleteMessage(chatId, loadingMsg.message_id);

    } catch (e) {
      console.error("CAPCUT ERROR:", e);
      try { if (loadingMsg) await bot.deleteMessage(chatId, loadingMsg.message_id); } catch(e){}
      return bot.sendMessage(chatId, "◇ Terjadi kesalahan saat mengambil video. Coba lagi.");
    }
  });

bot.onText(/^\/pindl(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const args = match[1]; // argumen setelah /pindl

  if (!args) {
    return bot.sendMessage(chatId, "⊘ Masukkan link Pinterest!\n\nContoh:\n/pindl https://id.pinterest.com/...");
  }

  try {
    const res = await axios.post("https://api.siputzx.my.id/api/d/pinterest", {
      url: args.trim()
    });

    const { status, data } = res.data;
    if (!status || !data?.url) {
      return bot.sendMessage(chatId, "◇ Gagal mengambil media dari Pinterest. Pastikan link valid.");
    }

    const head = await axios.head(data.url);
    const contentType = head.headers["content-type"];

    const caption = `⬡ *Pinterest Media*\n⌇ ID: ${data.id || "-"}\n◷ Dibuat: ${data.created_at || "-"}`;

    if (contentType.includes("video")) {
      await bot.sendVideo(chatId, data.url, { caption, parse_mode: "Markdown" });
    } else if (contentType.includes("image")) {
      await bot.sendPhoto(chatId, data.url, { caption, parse_mode: "Markdown" });
    } else {
      await bot.sendMessage(chatId, `? File tidak dikenali (tipe: ${contentType})`);
    }
  } catch (err) {
    console.error("Pinterest Error:", err?.response?.data || err.message);
    return bot.sendMessage(chatId, "◇ Terjadi kesalahan saat mengambil media dari Pinterest.");
  }
});
  
bot.onText(/\/ytdl(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const url = match[1];

  if (!url) {
    return bot.sendMessage(chatId, "◇ Contoh penggunaan:\n/ytdl <link YouTube>");
  }

  const loadingMsg = await bot.sendMessage(chatId, "⏳ Sedang memproses audio & video...");

  try {
    const audioApi = `https://piereeapi.vercel.app/download/ytmp3?url=${encodeURIComponent(url)}`;
    const audioFetch = await axios.get(audioApi).catch(() => null);

    if (!audioFetch?.data?.status) {
      return bot.editMessageText("◇ Gagal mengambil audio.", {
        chat_id: chatId,
        message_id: loadingMsg.message_id,
      });
    }

    const audioURL = audioFetch.data.result.download;
    const audioTitle = audioFetch.data.result.title || "Audio";
    const audioBuffer = await axios.get(audioURL, { responseType: "arraybuffer" }).catch(() => null);

    if (!audioBuffer?.data) {
      return bot.editMessageText("◇ Gagal mengunduh audio.", {
        chat_id: chatId,
        message_id: loadingMsg.message_id,
      });
    }

    const audioPath = path.join(process.cwd(), `${Date.now()}-audio.mp3`);
    fs.writeFileSync(audioPath, Buffer.from(audioBuffer.data));

    const videoApi = `https://piereeapi.vercel.app/download/ytmp4?url=${encodeURIComponent(url)}`;
    const videoFetch = await axios.get(videoApi).catch(() => null);

    if (!videoFetch?.data?.status) {
      return bot.editMessageText("◇ Gagal mengambil video.", {
        chat_id: chatId,
        message_id: loadingMsg.message_id,
      });
    }

    const videoURL = videoFetch.data.result.download;
    const videoTitle = videoFetch.data.result.title || "Video";
    const videoBuffer = await axios.get(videoURL, { responseType: "arraybuffer" }).catch(() => null);

    if (!videoBuffer?.data) {
      return bot.editMessageText("◇ Gagal mengunduh video.", {
        chat_id: chatId,
        message_id: loadingMsg.message_id,
      });
    }

    const videoPath = path.join(process.cwd(), `${Date.now()}-video.mp4`);
    fs.writeFileSync(videoPath, Buffer.from(videoBuffer.data));

    // KIRIM VIDEO DULU
    await bot.sendVideo(chatId, videoPath, {
      caption: `▶ *${videoTitle}*`,
      parse_mode: "Markdown",
    });

    // BARU KIRIM AUDIO
    await bot.sendAudio(chatId, audioPath, {
      title: audioTitle,
      caption: `♪ *${audioTitle}*`,
      parse_mode: "Markdown",
    });

    await bot.deleteMessage(chatId, loadingMsg.message_id);

    try { fs.unlinkSync(audioPath); } catch {}
    try { fs.unlinkSync(videoPath); } catch {}

  } catch (e) {
    await bot.editMessageText("◇ Terjadi kesalahan saat memproses.", {
      chat_id: chatId,
      message_id: loadingMsg.message_id,
    });
  }
});
  bot.onText(/\/videydl(?:\s+(.+))?/, async (msg, match) => {
    const chatId = msg.chat.id;
    const input = match[1]; // Ambil URL setelah perintah

    if (!input || !input.startsWith("http")) {
      return bot.sendMessage(
        chatId,
        "◇ Kirim perintah dengan menyertakan URL video dari videy.co\nContoh: `/videydl https://videy.co/v?id=XXXX`",
        { parse_mode: "Markdown" }
      );
    }

    await bot.sendMessage(chatId, "⏳ Sedang memproses video...");

    try {
      const res = await axios.post(
        "https://fastapi.acodes.my.id/api/downloader/videy",
        { text: input },
        {
          headers: {
            accept: "*/*",
            "Content-Type": "application/json",
          },
        }
      );

      if (res.data?.status && res.data?.data) {
        await bot.sendVideo(chatId, res.data.data, {
          caption: "◉ Video berhasil diunduh dari videy.co!",
        });
      } else {
        await bot.sendMessage(chatId, "◇ Gagal mendapatkan video. Coba cek ulang link-nya.");
      }
    } catch (err) {
      console.error("VideyDL error:", err.message || err);
      bot.sendMessage(chatId, "◇ Terjadi kesalahan saat memproses video.");
    }
  });
  bot.onText(/\/twitter (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const args = match[1].trim();

    if (!args) {
      return bot.sendMessage(chatId, "⊘ Masukkan link Twitter!\n\nContoh:\n/twitter https://twitter.com/...");
    }

    try {
      const res = await axios.post("https://api.siputzx.my.id/api/d/twitter", {
        url: args
      });

      const { status, data } = res.data;
      if (!status || !data?.downloadLink) {
        return bot.sendMessage(chatId, "◇ Gagal mengambil video dari Twitter. Pastikan link valid.");
      }

      const head = await axios.head(data.downloadLink);
      const contentType = head.headers["content-type"];

      // Fungsi cek extension URL
      const isImageExt = (url) => /\.(jpg|jpeg|png|gif|webp)$/i.test(url);
      const isVideoExt = (url) => /\.(mp4|mov|mkv|webm|avi|flv)$/i.test(url);

      const caption = `⌂ *${data.videoTitle || "Twitter Video"}*\n✎ ${data.videoDescription || ""}`;

      if (contentType.includes("video")) {
        await bot.sendVideo(chatId, data.downloadLink, { caption, parse_mode: "Markdown" });
      } else if (contentType.includes("image")) {
        await bot.sendPhoto(chatId, data.downloadLink, { caption, parse_mode: "Markdown" });
      } else if (contentType === "application/octet-stream") {
        if (isImageExt(data.downloadLink)) {
          await bot.sendPhoto(chatId, data.downloadLink, { caption, parse_mode: "Markdown" });
        } else if (isVideoExt(data.downloadLink)) {
          await bot.sendVideo(chatId, data.downloadLink, { caption, parse_mode: "Markdown" });
        } else {
          await bot.sendVideo(chatId, data.downloadLink, { caption, parse_mode: "Markdown" });
        }
      } else {
        await bot.sendMessage(chatId, `? File tidak dikenali (tipe: ${contentType})`);
      }
    } catch (err) {
      console.error("Twitter Error:", err?.response?.data || err.message);
      return bot.sendMessage(chatId, "◇ Terjadi kesalahan saat mengambil media dari Twitter.");
    }
  });
const pendingDownloads = new Map();
const MAX_SIZE = 48 * 1024 * 1024; // 48MB aman telegram

// ===== COMMAND MEDIAFIRE =====
bot.onText(/^\/mediafire(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const url = match[1]?.trim();

  if (!url) return bot.sendMessage(chatId, '◇ Contoh penggunaan:\n/mediafire <link_mediafire>');

  const loading = await bot.sendMessage(chatId, '⏳ Sedang memproses link...');

  try {
    const res = await fetch(`https://piereeapi.vercel.app/download/mediafire?url=${encodeURIComponent(url)}`);
    const data = await res.json();

    if (!data.status) {
      return bot.editMessageText('◇ Gagal mengambil data dari API!', {
        chat_id: chatId,
        message_id: loading.message_id
      });
    }

    const urlObj = new URL(url);
    const parts = urlObj.pathname.split('/').filter(Boolean);
    const filename = parts[2] || 'file.zip';
    const ext = path.extname(filename).replace('.', '').toLowerCase();

    const fileResp = await fetch(data.url);
    const fileBuffer = Buffer.from(await fileResp.arrayBuffer());

    // ===== INFO ISI ZIP ROOT =====
    let isiFile = '-';
    if (ext === 'zip') {
      const zip = new AdmZip(fileBuffer);
      const entries = zip.getEntries();
      const folderLevels = new Set();

      entries.forEach(e => {
        const parts = e.entryName.split('/').filter(Boolean);
        const level = parts.slice(0, 3).join(' / ');
        if (level) folderLevels.add(level);
      });

      isiFile = [...folderLevels].map(v => `• ${v}`).join('\n');
    }

    // ===== APK → ZIP =====
    let sendBuffer = fileBuffer;
    let sendFilename = filename;

    if (ext === 'apk') {
      const zipWrap = new AdmZip();
      zipWrap.addFile(filename, fileBuffer);
      sendBuffer = zipWrap.toBuffer();
      sendFilename = filename.replace(/\.apk$/i, '') + '.zip';
    }

    pendingDownloads.set(chatId, {
      buffer: sendBuffer,
      filename: sendFilename
    });

    await bot.sendMessage(chatId,
`⌗ *${filename}*

⌗ Type: ${data.filetype || '-'}
⬢ Ekstensi: ${ext}
⟡ Ukuran: ${data.filesizeH || '-'}
▦ Upload: ${data.aploud || '-'}

*INFO ISI FILE (ROOT):*
${isiFile}

Ketik *y* untuk kirim file
Ketik *n* untuk batal`, { parse_mode: 'Markdown' });

    await bot.deleteMessage(chatId, loading.message_id);

  } catch (err) {
    console.error(err);
    bot.sendMessage(chatId, '◇ Error memproses file');
  }
});


// ===== HANDLER YES / NO =====
bot.on('message', async (msg) => {
  const chatId = msg.chat.id;
  const text = (msg.text || '').toLowerCase();

  if (!pendingDownloads.has(chatId)) return;

  if (text === 'y') {

    const data = pendingDownloads.get(chatId);
    const buffer = data.buffer;
    const filename = data.filename;

    // ===== jika >48MB → split =====
    if (buffer.length > MAX_SIZE) {

      const totalParts = Math.ceil(buffer.length / MAX_SIZE);

      await bot.sendMessage(chatId,
`⬢ File melebihi limit Telegram
File akan dikirim dalam ${totalParts} bagian`);

      for (let i = 0; i < totalParts; i++) {

        const start = i * MAX_SIZE;
        const end = Math.min(start + MAX_SIZE, buffer.length);
        const partBuffer = buffer.slice(start, end);

        try {

          await bot.sendDocument(chatId, partBuffer, {
            filename: `${filename}.part${i+1}`,
            caption:
`⌗ ${filename}
⬢ Part ${i+1}/${totalParts}
⌗ Split byte: ${start} - ${end}`
          });

        } catch (err) {
          console.error("SEND ERROR:", err);
          await bot.sendMessage(chatId, `◇ Gagal mengirim part ${i+1}`);
        }
      }

    } else {

      await bot.sendDocument(chatId, buffer, {
        filename: filename
      });

    }

    pendingDownloads.delete(chatId);

  } else if (text === 'n') {
    pendingDownloads.delete(chatId);
    bot.sendMessage(chatId, '◇ Download dibatalkan.');
  }
});
bot.onText(/\/spotify (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const url = match[1];

  if (!url) return bot.sendMessage(chatId, '◇ Contoh penggunaan:\n/spotify <link Spotify>');

  const loadingMsg = await bot.sendMessage(chatId, '⏳ Sedang memproses audio Spotify...');

  try {
    const res = await axios.get(`https://piereeapi.vercel.app/download/spotify?url=${encodeURIComponent(url)}`);
    const data = res.data;

    if (!data.status || !data.download)
      return bot.editMessageText('◇ Gagal mengambil audio.', { chat_id: chatId, message_id: loadingMsg.message_id });

    const { title, artis, image, download } = data;

    await bot.sendAudio(chatId, download, {
      title: `${title} - ${artis}`,
      caption: `♪ *${title}*\n◉ ${artis}`,
      parse_mode: 'Markdown',
      thumb: image
    });

    await bot.deleteMessage(chatId, loadingMsg.message_id);
  } catch (err) {
    await bot.editMessageText('◇ Terjadi kesalahan.', { chat_id: chatId, message_id: loadingMsg.message_id });
  }
});
bot.onText(/\/tiktok (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const url = match[1];

  if (!url.includes("tiktok.com")) {
    return bot.sendMessage(chatId, `◇ Masukkan URL TikTok yang valid.\nContoh: /tiktok https://vt.tiktok.com/xxxx`);
  }

  const waitMsg = await bot.sendMessage(chatId, "◷ Mengambil video dari TikTok...");

  try {
    const { data } = await axios.get("https://restapi-v2.simplebot.my.id/download/tiktok", {
      params: { url },
    });

    const result = data?.result;
    if (!data.status || !result || !result.video_nowm) {
      return bot.editMessageText("◇ Gagal mengambil video TikTok.", {
        chat_id: chatId,
        message_id: waitMsg.message_id,
      });
    }

    // kirim video tanpa watermark
    await bot.sendVideo(chatId, result.video_nowm, {
      caption: "▶ Video TikTok",
    });

    // kalau ada audio
    if (result.audio_url) {
      await bot.sendAudio(chatId, result.audio_url, {
        caption: "♪ Audio TikTok",
      });
    }

    await bot.editMessageText("◉ Selesai mengunduh video TikTok!", {
      chat_id: chatId,
      message_id: waitMsg.message_id,
    });
  } catch (err) {
    console.error("TikTok Error:", err);
    bot.editMessageText("⚠ Terjadi kesalahan saat mengunduh video TikTok.", {
      chat_id: chatId,
      message_id: waitMsg.message_id,
    });
  }
});

// jika hanya ketik /tiktok tanpa argumen
bot.onText(/\/tiktok$/, (msg) => {
  bot.sendMessage(msg.chat.id, `◇ Masukkan URL TikTok yang valid.\nContoh: /tiktok https://vt.tiktok.com/xxxx`);
});
  bot.onText(/\/gitclone (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const repoUrl = match[1]?.trim();

    if (!repoUrl) {
      return bot.sendMessage(chatId, '◇ Contoh penggunaan:\n/gitclone https://github.com/user/repo');
    }

    const loading = await bot.sendMessage(chatId, '⏳ Sedang memproses repo GitHub...');

    try {
      const res = await fetch(`https://piereeapi.vercel.app/download/github?url=${encodeURIComponent(repoUrl)}`);
      const data = await res.json();

      if (!data.status || !data.result?.download) {
        return bot.editMessageText('◇ Gagal mengambil repo dari API!', {
          chat_id: chatId,
          message_id: loading.message_id
        });
      }

      const fileUrl = data.result.download;
      const filename = data.result.filename || 'github_repo.zip';

      const fileResp = await fetch(fileUrl);
      const fileBuffer = await fileResp.arrayBuffer();

      const filePath = path.join(__dirname, filename);
      fs.writeFileSync(filePath, Buffer.from(fileBuffer));

      await bot.sendDocument(chatId, filePath); // TANPA caption

      fs.unlinkSync(filePath);
      await bot.deleteMessage(chatId, loading.message_id);
    } catch (err) {
      console.error('GitClone Error:', err);
      await bot.editMessageText('◇ Terjadi kesalahan saat mengunduh repo!', {
        chat_id: chatId,
        message_id: loading.message_id
      });
    }
  });
  
function qcRoundedRectPath(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

bot.onText(/^\/qc(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];

  if (!text) {
    return bot.sendMessage(chatId, "⚠ Contoh: /qc teksnya", {
      reply_to_message_id: msg.message_id
    });
  }

  const waitingMsg = await bot.sendMessage(chatId, '⏳ ᴍᴇᴍʙᴜᴀᴛ ǫᴜᴏᴛᴇ ᴄᴀʀᴅ...', {
    reply_to_message_id: msg.message_id
  });

  // Ambil foto profil user (kalau gagal/gak ada, pakai avatar default abu-abu)
  let avatarBuffer = null;
  try {
    const photos = await bot.getUserProfilePhotos(msg.from.id, { limit: 1 });
    if (photos.total_count > 0) {
      const link = await bot.getFileLink(photos.photos[0][0].file_id);
      const resp = await axios.get(link, { responseType: "arraybuffer", timeout: 10000 });
      avatarBuffer = resp.data;
    }
  } catch (err) {
    avatarBuffer = null;
  }

  try {
    const name = msg.from.first_name || "User";

    const scale = 2; // render 2x lalu discale biar tajam (anti buram/pecah)
    const measureCanvas = createCanvas(10, 10);
    const mctx = measureCanvas.getContext("2d");
    const cardWidth = 720;
    const maxTextWidth = cardWidth - 160;

    let fontSize = 40;
    if (text.length > 60) fontSize = 33;
    if (text.length > 120) fontSize = 27;
    if (text.length > 220) fontSize = 21;
    const lineHeight = Math.round(fontSize * 1.42);

    mctx.font = `600 ${fontSize}px "DejaVu Sans", Arial`;
    const words = text.split(/\s+/);
    const lines = [];
    let line = "";
    for (const w of words) {
      const test = line ? line + " " + w : w;
      if (mctx.measureText(test).width > maxTextWidth && line) {
        lines.push(line);
        line = w;
      } else {
        line = test;
      }
    }
    if (line) lines.push(line);
    if (lines.length > 12) {
      lines.length = 12;
      lines[11] = lines[11].replace(/.{0,3}$/, "...");
    }

    const avatarSize = 116;
    const topPad = 64;
    const textTop = topPad + avatarSize + 58;
    const textBlockHeight = lines.length * lineHeight;
    const bottomPad = 96;
    const cardHeight = Math.max(560, textTop + textBlockHeight + bottomPad);

    const canvas = createCanvas(cardWidth * scale, cardHeight * scale);
    const ctx = canvas.getContext("2d");
    ctx.scale(scale, scale);

    // background gradient elegan + vignette halus
    const bg = ctx.createLinearGradient(0, 0, cardWidth, cardHeight);
    bg.addColorStop(0, "#1c1b26");
    bg.addColorStop(1, "#0e0e14");
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, cardWidth, cardHeight);

    const vignette = ctx.createRadialGradient(
      cardWidth / 2, cardHeight / 2, cardHeight / 4,
      cardWidth / 2, cardHeight / 2, cardHeight
    );
    vignette.addColorStop(0, "rgba(0,0,0,0)");
    vignette.addColorStop(1, "rgba(0,0,0,0.35)");
    ctx.fillStyle = vignette;
    ctx.fillRect(0, 0, cardWidth, cardHeight);

    qcRoundedRectPath(ctx, 6, 6, cardWidth - 12, cardHeight - 12, 28);
    ctx.strokeStyle = "rgba(255,255,255,0.08)";
    ctx.lineWidth = 2;
    ctx.stroke();

    ctx.fillStyle = "rgba(255,255,255,0.05)";
    ctx.font = "bold 200px Georgia";
    ctx.textAlign = "left";
    ctx.fillText("\u201C", -14, 200);

    const ringGrad = ctx.createLinearGradient(
      cardWidth / 2 - avatarSize / 2, topPad,
      cardWidth / 2 + avatarSize / 2, topPad + avatarSize
    );
    ringGrad.addColorStop(0, "#8b5cf6");
    ringGrad.addColorStop(1, "#ec4899");
    ctx.beginPath();
    ctx.arc(cardWidth / 2, topPad + avatarSize / 2, avatarSize / 2 + 5, 0, Math.PI * 2, true);
    ctx.fillStyle = ringGrad;
    ctx.fill();

    ctx.save();
    ctx.beginPath();
    ctx.arc(cardWidth / 2, topPad + avatarSize / 2, avatarSize / 2, 0, Math.PI * 2, true);
    ctx.closePath();
    ctx.clip();
    if (avatarBuffer) {
      try {
        const img = await loadImage(avatarBuffer);
        ctx.drawImage(img, cardWidth / 2 - avatarSize / 2, topPad, avatarSize, avatarSize);
      } catch {
        ctx.fillStyle = "#3a3a42";
        ctx.fillRect(cardWidth / 2 - avatarSize / 2, topPad, avatarSize, avatarSize);
      }
    } else {
      ctx.fillStyle = "#3a3a42";
      ctx.fillRect(cardWidth / 2 - avatarSize / 2, topPad, avatarSize, avatarSize);
      ctx.fillStyle = "#6b6b76";
      ctx.font = "600 46px Arial";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText((name[0] || "U").toUpperCase(), cardWidth / 2, topPad + avatarSize / 2 + 2);
      ctx.textBaseline = "alphabetic";
    }
    ctx.restore();

    ctx.textAlign = "center";
    ctx.fillStyle = "#f5f5f7";
    ctx.font = `600 ${fontSize}px "DejaVu Sans", Arial`;
    ctx.shadowColor = "rgba(0,0,0,0.35)";
    ctx.shadowBlur = 6;
    lines.forEach((l, i) => {
      ctx.fillText(l, cardWidth / 2, textTop + i * lineHeight);
    });
    ctx.shadowBlur = 0;

    const sepY = cardHeight - bottomPad + 24;
    ctx.strokeStyle = "rgba(255,255,255,0.15)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(cardWidth / 2 - 30, sepY);
    ctx.lineTo(cardWidth / 2 + 30, sepY);
    ctx.stroke();

    ctx.font = "italic 600 24px Arial";
    ctx.fillStyle = "#a9a9b4";
    ctx.fillText(`— ${name}`, cardWidth / 2, cardHeight - 44);

    const pngBuffer = canvas.toBuffer("image/png");

    // Konversi ke WEBP asli (bukan PNG yang cuma diganti ekstensi kayak sebelumnya)
    // + resize biar muat batas sticker Telegram (maks 512x512, <512KB)
    const webpBuffer = await sharp(pngBuffer)
      .resize({ width: 512, height: 512, fit: "inside", withoutEnlargement: true })
      .webp({ quality: 90 })
      .toBuffer();

    await bot.sendSticker(chatId, webpBuffer, {
      reply_to_message_id: msg.message_id
    }, {
      filename: "qc.webp",
      contentType: "image/webp"
    });

    await bot.deleteMessage(chatId, waitingMsg.message_id).catch(() => {});
  } catch (err) {
    console.error("[qc] Gagal generate quote card:", err.message);
    await bot.deleteMessage(chatId, waitingMsg.message_id).catch(() => {});
    bot.sendMessage(chatId, "◇ Gagal membuat QC, coba lagi.", {
      reply_to_message_id: msg.message_id
    });
  }
});
bot.onText(/^\/brat(?: (.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
    
  const argsRaw = match[1];

  if (!argsRaw) {
    return bot.sendMessage(chatId, 'Format: /brat <teks> [--gif] [--delay=500]');
  }

  try {
    const args = argsRaw.split(' ');

    const textParts = [];
    let isAnimated = false;
    let delay = 500;

    for (let arg of args) {
      if (arg === '--gif') isAnimated = true;
      else if (arg.startsWith('--delay=')) {
        const val = parseInt(arg.split('=')[1]);
        if (!isNaN(val)) delay = val;
      } else {
        textParts.push(arg);
      }
    }

    const text = textParts.join(' ');
    if (!text) {
      return bot.sendMessage(chatId, 'Teks tidak boleh kosong!');
    }

    if (isAnimated && (delay < 100 || delay > 1500)) {
      return bot.sendMessage(chatId, 'Delay harus antara 100–1500 ms.');
    }

    const waitingMsg = await bot.sendMessage(chatId, '⏳ ᴍᴇᴍʙᴜᴀᴛ sᴛɪᴄᴋᴇʀ ʙʀᴀᴛ...');

    const apiUrl = `https://api.siputzx.my.id/api/m/brat?text=${encodeURIComponent(text)}&isAnimated=${isAnimated}&delay=${delay}`;
    const buffer = await fetchImageWithRetry(apiUrl);

    await bot.sendSticker(chatId, buffer);
    await bot.deleteMessage(chatId, waitingMsg.message_id).catch(() => {});
  } catch (error) {
    console.error('◇ Error brat:', error.message);
    bot.sendMessage(chatId, `◇ Gagal membuat stiker brat. API pihak ketiga lagi ngambek, coba lagi beberapa saat lagi.\n(${error.message})`);
  }
});

bot.onText(/\/iqc(.+)?/, async (msg, match) => {
  const chatId = msg.chat.id;
    
  const text = match[1] ? match[1].trim() : '';

  if (!text) {
    return bot.sendMessage(chatId, '◇ Format Salah: /iqc jam|batre|carrier|pesan\nContoh: /iqc 18:00|40|Indosat|hai hai', {
      reply_to_message_id: msg.message_id
    });
  }

  const parts = text.split('|');
  if (parts.length < 4) {
    return bot.sendMessage(chatId, '◇ Format salah! Gunakan:\n/iqc jam|batre|carrier|pesan\nContoh:\n/iqc 18:00|40|Indosat|hai hai', {
      reply_to_message_id: msg.message_id
    });
  }

  const time = parts[0].trim();
  const battery = parts[1].trim();
  const carrier = parts[2].trim();
  const messageParts = parts.slice(3);
  const messageText = messageParts.join('|').trim();

  if (!time || !battery || !carrier || !messageText) {
    return bot.sendMessage(chatId, '⚠ Format salah! Pastikan semua field terisi:\n/iqc jam|batre|carrier|pesan', {
      reply_to_message_id: msg.message_id
    });
  }

  const waitingMsg = await bot.sendMessage(chatId, '⏳', {
    reply_to_message_id: msg.message_id
  });

  try {
    const encodedTime = encodeURIComponent(time);
    const encodedCarrier = encodeURIComponent(carrier);
    const encodedMessage = encodeURIComponent(messageText);
    
    const url = `https://brat.siputzx.my.id/iphone-quoted?time=${encodedTime}&batteryPercentage=${battery}&carrierName=${encodedCarrier}&messageText=${encodedMessage}&emojiStyle=apple`;

    const buffer = await fetchImageWithRetry(url);

    await bot.sendPhoto(chatId, buffer, {
      caption: `◉ *ꜱᴜᴋꜱᴇꜱ ʙᴀɴɢ*`,
      parse_mode: 'Markdown',
      reply_to_message_id: msg.message_id
    });

    await bot.deleteMessage(chatId, waitingMsg.message_id).catch(() => {});

  } catch (error) {
    console.error('Error iqc:', error.message);

    await bot.deleteMessage(chatId, waitingMsg.message_id).catch(() => {});

    await bot.sendMessage(chatId, `◇ Terjadi kesalahan, coba lagi! API pihak ketiga lagi tidak stabil.\n(${error.message})`, {
      reply_to_message_id: msg.message_id
    });
  }
});
  bot.onText(/\/groq(?: (.+))?$/, async (msg, match) => {
    const chatId = msg.chat.id;
    let prompt = match[1];
    if (!prompt && msg.reply_to_message?.text) prompt = msg.reply_to_message.text;
    if (!prompt) return bot.sendMessage(chatId, '◇ Gunakan: /groq <teks> atau reply ke pesan.');
    const wait = await bot.sendMessage(chatId, '⏳ Memproses dengan Groq...');
    try {
      const res = await fetch(`https://piereeapi.vercel.app/ai/groq?text=${encodeURIComponent(prompt)}`);
      const data = await res.json();
      const hasil = data.result || data.data?.result || data.text || '◇ Tidak ada hasil.';
      bot.editMessageText(hasil, { chat_id: chatId, message_id: wait.message_id });
    } catch {
      bot.editMessageText('◇ Gagal memproses dari Groq API.', { chat_id: chatId, message_id: wait.message_id });
    }
  });

  bot.onText(/\/fixcode/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const replyMsg = msg.reply_to_message;

    try {
      let code = null;
      if (replyMsg?.text) code = replyMsg.text;
      else if (replyMsg?.document) {
        const doc = replyMsg.document;
        if (doc.mime_type === "application/javascript" || doc.file_name.endsWith(".js")) {
          const fileLink = await bot.getFileLink(doc.file_id);
          const res = await fetch(fileLink);
          code = await res.text();
        }
      }
      if (!code) return bot.sendMessage(chatId, "◇ Balas pesan teks error atau file .js dulu bre.");
      await bot.sendMessage(chatId, "⌘ Sedang memproses kode Anda, mohon tunggu sebentar...");
      const prompt = `
Anda adalah AI yang sangat ahli dalam memperbaiki semua jenis kode pemrograman, termasuk JavaScript, Python, C++, dan bahasa pemrograman lainnya. Tugas Anda adalah membantu pengguna memperbaiki kode yang error, tidak efisien, atau memiliki bug, sehingga kode tersebut dapat dijalankan dengan benar.

Instruksi rinci:

1. Periksa kode yang diberikan dan temukan semua kesalahan, bug, atau masalah potensial.
2. Perbaiki semua masalah tersebut dan tuliskan ulang kode yang sudah diperbaiki.
3. Jangan menambahkan penjelasan, komentar, atau catatan apapun di dalam kode. Fokus hanya pada perbaikan kode.
4. Jangan gunakan pembungkus \`\`\` atau format khusus apapun. Hasil harus berupa kode bersih yang siap digunakan.
5. Pastikan struktur kode rapi, indentasi konsisten, dan sintaks benar.

Kode yang perlu diperbaiki adalah sebagai berikut:

${code}
`;
      const url = `https://piereeapi.vercel.app/ai/gpt4o?prompt=${encodeURIComponent(prompt)}`;
      const response = await fetch(url);
      const data = await response.json();
      if (data?.result) {
        const reply = data.result.trim();
        const filePath = path.join(__dirname, "fix.txt");
        Plfs.writeFileSync(filePath, reply, "utf8");
        await bot.sendDocument(chatId, filePath, { caption: "◉ Nih Hasil Fixnya!" });
      } else {
        bot.sendMessage(chatId, "◇ Gagal mendapatkan balasan dari AI.");
      }
    } catch {
      bot.sendMessage(chatId, "◇ Terjadi error saat memproses perbaikan kode.");
    }
  });

  bot.onText(/\/chatgpt/, async (msg) => {
    const chatId = msg.chat.id;
    const replyMsg = msg.reply_to_message;
    try {
      let code = null;
      if (replyMsg?.text) code = replyMsg.text;
      else if (replyMsg?.document) {
        const doc = replyMsg.document;
        if (doc.mime_type === "application/javascript" || doc.file_name.endsWith(".js")) {
          const fileLink = await bot.getFileLink(doc.file_id);
          const res = await fetch(fileLink);
          code = await res.text();
        }
      }
      if (!code) return bot.sendMessage(chatId, "◇ Reply ke pesan untuk menggunakan /chatgpt..");
      await bot.sendMessage(chatId, "⌘ Sedang Memproses...");
      const prompt = `
kamu adalah asisten ai pintar, dan ikuti aturan ini
- Gunakan bahasa Indonesia
- Kasih hasilnya pake format \`\`\`(bahasa pemograman) di awal dan \`\`\` di akhir biar gua gampang salin.
- Jangan ada gunakan \`

Ini kodenya bre:

${code}
`;
      const url = `https://piereeapi.vercel.app/ai/gpt4o?prompt=${encodeURIComponent(prompt)}`;
      const response = await fetch(url);
      const data = await response.json();
      if (data?.result) {
        const reply = data.result.trim();
        const output = reply.includes("```") ? reply : `\`\`\`javascript\n${reply}\n\`\`\``;
        const hasil = output.length > 4000 ? output.slice(0, 4000) + "..." : output;
        return bot.sendMessage(chatId, hasil, { parse_mode: "Markdown" });
      } else {
        bot.sendMessage(chatId, "◇ Gagal dapet balasan dari AI bre.");
      }
    } catch {
      bot.sendMessage(chatId, "◇ Terjadi error pas proses perbaikan kode.");
    }
  });

  // [removed] old /ai handler — digantikan oleh aiCodeAnalyzer.js yang lebih lengkap
  // (mendukung /ai <pesan>, /modelai, shortcut per-model: /mimo, /deepseekpro, dll)
  
// [removed] /worm (AI jailbreak prompt) and /spamotp + helpers (OTP bombing/harassment tool)
// [removed] doxnik / checkNIK - unauthorized personal-data (NIK) doxxing lookup

bot.onText(/\/toprompt/i, async (msg) => {
  console.log("COMMAND KEDETECT"); // ⟡ debug

  const chatId = msg.chat.id;
  const q = msg.reply_to_message;

  if (!q) {
    return bot.sendMessage(chatId, '◇ Reply ke gambar dulu!');
  }

  if (!q.photo) {
    return bot.sendMessage(chatId, '◇ Itu bukan gambar!');
  }

  const waitMsg = await bot.sendMessage(
    chatId,
    '↻ Proses...\n⏳ Tunggu sebentar...'
  );

  try {
    const fileId = q.photo[q.photo.length - 1].file_id;

    const file = await bot.getFile(fileId);
    console.log("FILE:", file); // ⟡ debug

    if (!file.file_path) throw new Error('file_path tidak ada');

    const fileUrl = `https://api.telegram.org/file/bot${bot.token}/${file.file_path}`;

    const res = await axios.get(fileUrl, {
      responseType: 'arraybuffer',
      timeout: 20000
    });

    const temp = `./tmp_${Date.now()}.jpg`;
    fs.writeFileSync(temp, res.data);

    console.log("DOWNLOAD BERHASIL");

    const data = await topromt(temp);
    console.log("API RESULT:", data);

    const promptText =
      data?.prompt ||
      data?.result ||
      data?.data?.prompt ||
      JSON.stringify(data);

    await bot.sendMessage(
      chatId,
      `<b>◉ Prompt:</b>\n\n<code>${promptText}</code>`,
      { parse_mode: 'HTML' }
    );

    fs.unlinkSync(temp);

  } catch (e) {
    console.log("ERROR:", e);

    await bot.sendMessage(
      chatId,
      `◇ Error:\n<code>${e.message || e}</code>`,
      { parse_mode: 'HTML' }
    );
  }
});

bot.onText(/\/githubdl (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const url = match[1];

    if (!url) {
        return bot.sendMessage(chatId, "◇ Masukkan URL GitHub!");
    }

    bot.sendMessage(chatId, "⬢ Mengambil dan mengirim repo...");

    const apiUrl = `https://piereeapi.vercel.app/download/github?url=${encodeURIComponent(url)}`;
    const filePath = path.join(__dirname, `repo_${Date.now()}.zip`);

    exec(`curl -s "${apiUrl}"`, (err, stdout) => {
        if (err || !stdout) {
            return bot.sendMessage(chatId, "◇ Gagal mengambil data!");
        }

        try {
            const res = JSON.parse(stdout);

            if (!res.status || !res.result || !res.result.download) {
                return bot.sendMessage(chatId, "◇ Repo tidak ditemukan!");
            }

            const downloadUrl = res.result.download;

            // Download file zip
            exec(`curl -L "${downloadUrl}" -o "${filePath}"`, async (err2) => {
                if (err2 || !fs.existsSync(filePath)) {
                    return bot.sendMessage(chatId, "◇ Gagal download file!");
                }

                // Kirim ke user
                await bot.sendDocument(chatId, filePath, {
                    caption: "⬢ Repo berhasil didownload!"
                });

                // Hapus file setelah dikirim
                fs.unlinkSync(filePath);

            });

        } catch (e) {
            bot.sendMessage(chatId, "◇ Response tidak valid!");
        }
    });
});
};