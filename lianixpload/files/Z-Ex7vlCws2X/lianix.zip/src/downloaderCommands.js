/**
 * ============================================================
 * LianiX — Downloader Commands Hub
 * ============================================================
 * Semua perintah downloader terpusat di sini.
 * Prefix sesuai nama platform.
 *
 * COMMAND LIST:
 *   /ytdl    <url>   → YouTube (video + audio MP3)
 *   /igdl    <url>   → Instagram (foto/video/reels)
 *   /tiktokdl <url>  → TikTok (video tanpa watermark)
 *   /twitterdl <url> → Twitter / X
 *   /fbdl    <url>   → Facebook
 *   /pindl   <url>   → Pinterest
 *   /redditdl <url>  → Reddit
 *   /spotdl  <url>   → Spotify
 *   /dailydl <url>   → Dailymotion
 *   /teraxdl <url>   → Terabox
 *   /sclouddl <url>  → SoundCloud
 *   /mediafiredl <url> → Mediafire
 *   /aio     <url>   → Auto-detect semua platform di atas
 *   /dllist           → Daftar semua platform yang didukung
 *
 * Core downloader: src/features/aio.js (aiodl)
 * Platform-specific: masing-masing features/*.js sebagai fallback
 * ============================================================
 */

'use strict';

const path  = require('path');
const axios = require('axios');
const settings = require('../settings.js');

// ── Helpers ────────────────────────────────────────────────
function esc(s = '') {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function q(msg) {
  return msg?.message_id ? { reply_to_message_id: msg.message_id } : {};
}

function fmtSize(bytes) {
  if (!bytes) return '?';
  if (bytes < 1024) return `${bytes}B`;
  if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)}KB`;
  return `${(bytes / 1048576).toFixed(1)}MB`;
}

const MAX_FILE = 50 * 1024 * 1024; // 50MB Telegram limit

async function loading(bot, msg, title) {
  const bar = (p, w = 18) => {
    const n = Math.round(Math.max(0, Math.min(100, p)) / 100 * w);
    return `[${'▰'.repeat(n)}${'▱'.repeat(w - n)}] ${Math.round(p)}%`;
  };
  const text = (stage, p) =>
    `⏳ <b>${esc(title)}</b>\n\n▸ ${esc(stage)}\n${bar(p)}\n\n🔄 <i>Mohon tunggu...</i>`;

  let sent = null;
  try {
    sent = await bot.sendMessage(msg.chat.id, text('Menyiapkan...', 0), {
      parse_mode: 'HTML',
      ...q(msg),
    });
  } catch {}

  let last = -1, lastAt = 0;
  return {
    async update(stage, p) {
      if (!sent) return;
      const now = Date.now();
      const v = Math.max(last, Math.min(100, Number(p) || 0));
      if (v === last && now - lastAt < 2500) return;
      if (now - lastAt < 900) return;
      last = v; lastAt = now;
      try {
        await bot.editMessageText(text(stage, v), {
          chat_id: msg.chat.id,
          message_id: sent.message_id,
          parse_mode: 'HTML',
        });
      } catch {}
    },
    async finish(ok = true) {
      if (!sent) return;
      try {
        await bot.editMessageText(
          `⏳ <b>${esc(title)}</b>\n\n${ok
            ? '✅ ' + bar(100) + '\n\n<b>Selesai.</b>'
            : '❌ Proses gagal.'}`,
          { chat_id: msg.chat.id, message_id: sent.message_id, parse_mode: 'HTML' }
        );
        setTimeout(() => bot.deleteMessage(msg.chat.id, sent.message_id).catch(() => {}), 1200);
      } catch {}
    },
  };
}

// ── Dynamic ESM feature loader ─────────────────────────────
const _cache = new Map();
async function loadFeature(name) {
  if (_cache.has(name)) return _cache.get(name);
  const mod = await import(path.join(__dirname, 'features', name));
  _cache.set(name, mod);
  return mod;
}

// ── Download buffer dari URL, dengan size guard ────────────
async function fetchBuffer(url) {
  const res = await axios.get(url, {
    responseType: 'arraybuffer',
    timeout: 120_000,
    maxContentLength: MAX_FILE,
    maxBodyLength: MAX_FILE,
  });
  return Buffer.from(res.data);
}

// ── Core: send media hasil downloader ─────────────────────
/**
 * Kirim media dari hasil aiodl ke chat.
 * result: { platform, title, thumbnail, author, media: [{type, url, quality}] }
 */
async function sendDownloadResult(bot, msg, result, platformLabel) {
  const { platform, title, thumbnail, author, media = [] } = result;

  if (!media.length) throw new Error('Tidak ada media yang ditemukan.');

  const caption = [
    `◉ <b>${esc(platformLabel || platform || 'Downloader')}</b>`,
    title  ? `✎ ${esc(title.slice(0, 180))}` : null,
    author ? `◷ ${esc(author)}` : null,
  ].filter(Boolean).join('\n');

  let sent = 0;
  for (const item of media.slice(0, 5)) {
    try {
      if (item.type === 'video' || item.type === 'mp4') {
        await bot.sendVideo(msg.chat.id, item.url, {
          caption: sent === 0 ? caption : '',
          parse_mode: 'HTML',
          supports_streaming: true,
          ...q(msg),
        });
      } else if (item.type === 'audio' || item.type === 'mp3') {
        await bot.sendAudio(msg.chat.id, item.url, {
          caption: sent === 0 ? caption : '',
          parse_mode: 'HTML',
          title: title || 'Audio',
          ...q(msg),
        });
      } else {
        // image / default
        await bot.sendPhoto(msg.chat.id, item.url, {
          caption: sent === 0 ? caption : '',
          parse_mode: 'HTML',
          ...q(msg),
        });
      }
      sent++;
      if (sent < Math.min(media.length, 5)) {
        await new Promise(r => setTimeout(r, 700));
      }
    } catch {
      // Skip media yang gagal kirim, coba lanjut
    }
  }

  if (!sent) throw new Error('Semua media gagal dikirim (mungkin URL expired atau ukuran terlalu besar).');
}

// ── Generic handler factory ────────────────────────────────
/**
 * Buat handler untuk satu platform.
 * @param {string} platformLabel  — Label tampilan (e.g. "YouTube")
 * @param {string} featureFile    — Nama file di features/ (e.g. "yt.js")
 * @param {string} exportFn       — Nama fungsi export dari featureFile, atau null → pakai aiodl
 * @param {string[]} validDomains — Array domain untuk validasi URL (opsional)
 */
function makePlatformHandler(platformLabel, featureFile, exportFn, validDomains = []) {
  return async function(bot, msg, url) {
    if (!url) {
      return bot.sendMessage(
        msg.chat.id,
        `◇ Gunakan: <code>/${platformLabel.toLowerCase()}dl &lt;url&gt;</code>`,
        { parse_mode: 'HTML', ...q(msg) }
      );
    }

    // Validasi domain kalau diisi
    if (validDomains.length) {
      const lower = url.toLowerCase();
      const valid = validDomains.some(d => lower.includes(d));
      if (!valid) {
        return bot.sendMessage(
          msg.chat.id,
          `◇ URL tidak valid untuk <b>${esc(platformLabel)}</b>.\nContoh domain: ${validDomains.slice(0,3).join(', ')}`,
          { parse_mode: 'HTML', ...q(msg) }
        );
      }
    }

    const load = await loading(bot, msg, `${platformLabel} Downloader`);
    try {
      await load.update(`Mengambil media dari ${platformLabel}...`, 20);

      let result;
      if (exportFn && featureFile) {
        // Pakai feature file spesifik
        const mod = await loadFeature(featureFile);
        const fn  = mod[exportFn] || mod.default;
        if (typeof fn !== 'function') throw new Error(`Modul ${featureFile} tidak export fungsi ${exportFn}.`);
        const raw = await fn(url);
        // Normalize ke format { platform, title, media }
        result = normalizeResult(raw, platformLabel.toLowerCase(), url);
      } else {
        // Pakai aio.js universal
        const { aiodl } = await loadFeature('aio.js');
        result = await aiodl(url);
      }

      await load.update('Mengirim media...', 80);
      await sendDownloadResult(bot, msg, result, platformLabel);
      await load.finish(true);
    } catch (e) {
      await load.finish(false);
      await bot.sendMessage(
        msg.chat.id,
        `❌ <b>${esc(platformLabel)} Downloader Gagal</b>\n\n${esc(e.message)}`,
        { parse_mode: 'HTML', ...q(msg) }
      );
    }
  };
}

/**
 * Normalize bermacam format return dari feature files
 * ke format standar { platform, title, thumbnail, author, media }
 */
function normalizeResult(raw, platform, originalUrl) {
  if (!raw) throw new Error('Tidak ada hasil dari provider.');

  // Sudah format standar (dari aio.js)
  if (Array.isArray(raw.media)) return raw;

  // Format dari ig.js / twitter.js: { media: [{type, url}], title, username }
  if (raw.media) {
    return {
      platform,
      title:     raw.title || raw.caption || '',
      author:    raw.username || raw.author || '',
      thumbnail: raw.thumbnail || null,
      media:     Array.isArray(raw.media) ? raw.media : [],
    };
  }

  // Format dari tiktok.js: { url, noWatermark, thumb, desc, author }
  if (raw.url || raw.noWatermark) {
    return {
      platform,
      title:     raw.desc || raw.title || '',
      author:    raw.author?.nickname || raw.author || '',
      thumbnail: raw.thumb || raw.thumbnail || null,
      media: [
        { type: 'video', url: raw.noWatermark || raw.url }
      ],
    };
  }

  // Format dari spotdl: { url, title, artist, thumbnail }
  if (raw.url && raw.title) {
    return {
      platform,
      title:     raw.title,
      author:    raw.artist || raw.author || '',
      thumbnail: raw.thumbnail || null,
      media: [
        { type: 'audio', url: raw.url }
      ],
    };
  }

  // Format dari reddit.js: { RedditDL: { media, ... } }
  if (raw.data || raw.result) {
    const inner = raw.data || raw.result;
    return normalizeResult(inner, platform, originalUrl);
  }

  throw new Error('Format hasil tidak dikenali dari provider.');
}

// ── Platform handlers ──────────────────────────────────────

const handleYtdl      = makePlatformHandler('YouTube',      'ytdl.js',          null, ['youtube.com', 'youtu.be']);
const handleIgdl      = makePlatformHandler('Instagram',    'ig.js',            'default', ['instagram.com']);
const handleTiktokdl  = makePlatformHandler('TikTok',       'tiktok.js',        'default', ['tiktok.com', 'vt.tiktok.com']);
const handleTwitterdl = makePlatformHandler('Twitter',      'twitter.js',       'default', ['twitter.com', 'x.com', 't.co']);
const handleFbdl      = makePlatformHandler('Facebook',     'fbdown.js',        'default', ['facebook.com', 'fb.watch', 'fb.com']);
const handlePindl     = makePlatformHandler('Pinterest',    'pindl.js',         'default', ['pinterest.com', 'pin.it']);
const handleRedditdl  = makePlatformHandler('Reddit',       'reddit.js',        'RedditDL', ['reddit.com']);
const handleSpotdl    = makePlatformHandler('Spotify',      'spotify.js',       'default', ['spotify.com', 'open.spotify.com']);
const handleDailydl   = makePlatformHandler('Dailymotion',  'dailymotion.js',   'default', ['dailymotion.com', 'dai.ly']);
const handleTeraxdl   = makePlatformHandler('Terabox',      'terabox.js',       'default', ['terabox.com', '1024terabox.com']);
const handleSclouddl  = makePlatformHandler('SoundCloud',   'soundclouddl.js',  'default', ['soundcloud.com', 'on.soundcloud.com']);
const handleMedifire  = makePlatformHandler('Mediafire',    'mediafire.js',     'default', ['mediafire.com']);

// /aio — universal auto-detect
async function handleAio(bot, msg, url) {
  if (!url) {
    return bot.sendMessage(
      msg.chat.id,
      '◇ Gunakan: <code>/aio &lt;url&gt;</code>\nSupport: YouTube, Instagram, TikTok, Twitter, Facebook, Pinterest, Reddit, Spotify, Dailymotion, Terabox, SoundCloud, Mediafire.',
      { parse_mode: 'HTML', ...q(msg) }
    );
  }

  const load = await loading(bot, msg, 'Auto Downloader');
  try {
    await load.update('Mendeteksi platform...', 10);
    const { aiodl, detectPlatform } = await loadFeature('aio.js');
    const platform = detectPlatform(url) || 'unknown';
    await load.update(`Platform: ${platform} — Mengunduh...`, 30);
    const result = await aiodl(url);
    await load.update('Mengirim media...', 80);
    await sendDownloadResult(bot, msg, result, platform.charAt(0).toUpperCase() + platform.slice(1));
    await load.finish(true);
  } catch (e) {
    await load.finish(false);
    await bot.sendMessage(
      msg.chat.id,
      `❌ <b>Auto Downloader Gagal</b>\n\n${esc(e.message)}\n\n<i>Coba gunakan command spesifik: /ytdl /igdl /tiktokdl dll</i>`,
      { parse_mode: 'HTML', ...q(msg) }
    );
  }
}

// ── Register ───────────────────────────────────────────────
function register(bot) {

  // YouTube
  bot.onText(/^\/ytdl(?:@\w+)?(?:\s+([\s\S]+))?$/i, (msg, m) =>
    handleYtdl(bot, msg, (m[1] || '').trim())
  );

  // Instagram
  bot.onText(/^\/igdl(?:@\w+)?(?:\s+([\s\S]+))?$/i, (msg, m) =>
    handleIgdl(bot, msg, (m[1] || '').trim())
  );

  // TikTok — prefix /tiktokdl supaya konsisten, /tiktok juga tetap support
  bot.onText(/^\/tiktokdl(?:@\w+)?(?:\s+([\s\S]+))?$/i, (msg, m) =>
    handleTiktokdl(bot, msg, (m[1] || '').trim())
  );

  // Twitter / X
  bot.onText(/^\/twitterdl(?:@\w+)?(?:\s+([\s\S]+))?$/i, (msg, m) =>
    handleTwitterdl(bot, msg, (m[1] || '').trim())
  );

  // Facebook
  bot.onText(/^\/fbdl(?:@\w+)?(?:\s+([\s\S]+))?$/i, (msg, m) =>
    handleFbdl(bot, msg, (m[1] || '').trim())
  );

  // Pinterest
  bot.onText(/^\/pindl(?:@\w+)?(?:\s+([\s\S]+))?$/i, (msg, m) =>
    handlePindl(bot, msg, (m[1] || '').trim())
  );

  // Reddit
  bot.onText(/^\/redditdl(?:@\w+)?(?:\s+([\s\S]+))?$/i, (msg, m) =>
    handleRedditdl(bot, msg, (m[1] || '').trim())
  );

  // Spotify
  bot.onText(/^\/spotdl(?:@\w+)?(?:\s+([\s\S]+))?$/i, (msg, m) =>
    handleSpotdl(bot, msg, (m[1] || '').trim())
  );

  // Dailymotion
  bot.onText(/^\/dailydl(?:@\w+)?(?:\s+([\s\S]+))?$/i, (msg, m) =>
    handleDailydl(bot, msg, (m[1] || '').trim())
  );

  // Terabox
  bot.onText(/^\/teraxdl(?:@\w+)?(?:\s+([\s\S]+))?$/i, (msg, m) =>
    handleTeraxdl(bot, msg, (m[1] || '').trim())
  );

  // SoundCloud
  bot.onText(/^\/sclouddl(?:@\w+)?(?:\s+([\s\S]+))?$/i, (msg, m) =>
    handleSclouddl(bot, msg, (m[1] || '').trim())
  );

  // Mediafire
  bot.onText(/^\/mediafiredl(?:@\w+)?(?:\s+([\s\S]+))?$/i, (msg, m) =>
    handleMedifire(bot, msg, (m[1] || '').trim())
  );

  // Universal AIO
  bot.onText(/^\/aio(?:@\w+)?(?:\s+([\s\S]+))?$/i, (msg, m) =>
    handleAio(bot, msg, (m[1] || '').trim())
  );

  // /dllist — daftar semua platform
  bot.onText(/^\/dllist(?:@\w+)?$/i, async (msg) => {
    await bot.sendMessage(
      msg.chat.id,
      `<b>◉ DOWNLOADER CENTER — LianiX</b>\n\n` +
      `<blockquote expandable>` +
      `<b>VIDEO & SOSMED</b>\n` +
      `├ <code>/ytdl &lt;url&gt;</code>       — YouTube\n` +
      `├ <code>/igdl &lt;url&gt;</code>       — Instagram\n` +
      `├ <code>/tiktokdl &lt;url&gt;</code>   — TikTok (no watermark)\n` +
      `├ <code>/twitterdl &lt;url&gt;</code>  — Twitter / X\n` +
      `├ <code>/fbdl &lt;url&gt;</code>       — Facebook\n` +
      `├ <code>/pindl &lt;url&gt;</code>      — Pinterest\n` +
      `├ <code>/redditdl &lt;url&gt;</code>   — Reddit\n` +
      `╰ <code>/dailydl &lt;url&gt;</code>    — Dailymotion\n` +
      `</blockquote>\n\n` +
      `<blockquote expandable>` +
      `<b>AUDIO & FILE</b>\n` +
      `├ <code>/spotdl &lt;url&gt;</code>     — Spotify\n` +
      `├ <code>/sclouddl &lt;url&gt;</code>   — SoundCloud\n` +
      `├ <code>/mediafiredl &lt;url&gt;</code> — Mediafire\n` +
      `╰ <code>/teraxdl &lt;url&gt;</code>    — Terabox\n` +
      `</blockquote>\n\n` +
      `<blockquote>` +
      `<b>AUTO-DETECT</b>\n` +
      `╰ <code>/aio &lt;url&gt;</code> — Otomatis deteksi semua platform\n` +
      `\n<b>DOWNLOADER TAMBAHAN</b>\n` +
      `├ <code>/douyin &lt;url&gt;</code> — Douyin\n` +
      `├ <code>/sfiledl &lt;url&gt;</code> — SFile\n` +
      `╰ <code>/tiktoksearch &lt;kata&gt;</code> — TikTok Search\n` +
      `</blockquote>`,
      { parse_mode: 'HTML', ...q(msg) }
    );
  });
}

module.exports = (bot) => register(bot);
