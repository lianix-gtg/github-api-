const fs = require("fs-extra");
const path = require("path");
const axios = require("axios");
const settings = require("../settings.js");
const { createCanvas, loadImage } = require("./optionalCanvas");

// Telegram tidak mengizinkan restrictChatMember terhadap creator/admin.
async function canRestrictTarget(bot, chatId, userId) {
  try {
    const member = await bot.getChatMember(chatId, userId);
    return !!member && member.status !== 'creator' && member.status !== 'administrator';
  } catch (err) {
    const d = String(err?.response?.body?.description || err?.message || err || '');
    if (/chat not found|user not found/i.test(d)) return false;
    // Do not turn a failed status lookup into an administrator restriction attempt.
    return false;
  }
}

let warnDB = {};
const pendingWarns = new Map();

async function loadWarnDB() {
  try {
    if (await fs.pathExists("./db/warnDB.json")) {
      warnDB = await fs.readJson("./db/warnDB.json");
    } else {
      warnDB = {};
      await saveWarnDB();
    }
  } catch (e) {
    console.error("Gagal load warnDB:", e);
  }
}

async function saveWarnDB() {
  try {
    await fs.ensureDir("./db");
    await fs.writeJson("./db/warnDB.json", warnDB, { spaces: 2 });
  } catch (e) {
    console.error("Gagal save warnDB:", e);
  }
}

loadWarnDB();

const autodelFile = "./db/autodel.json";

function loadAutodel() {
  try {
    if (!fs.existsSync(autodelFile)) {
      fs.ensureDirSync("./db");
      fs.writeJsonSync(autodelFile, { words: [] }, { spaces: 2 });
    }
    return fs.readJsonSync(autodelFile);
  } catch (e) {
    console.error("Gagal load autodel:", e);
    return { words: [] };
  }
}

function saveAutodel(data) {
  try {
    fs.ensureDirSync("./db");
    fs.writeJsonSync(autodelFile, data, { spaces: 2 });
  } catch (e) {
    console.error("Gagal save autodel:", e);
  }
}

const WELCOME_FILE = "./db/welcomeStatus.json";

// Load atau buat file welcomeStatus.json
let welcomeStatus = {};
if (fs.existsSync(WELCOME_FILE)) {
  welcomeStatus = JSON.parse(fs.readFileSync(WELCOME_FILE, "utf-8"));
} else {
  fs.writeFileSync(WELCOME_FILE, JSON.stringify({}));
}
// Fungsi cek owner
function notOwner(msg, chatId, botInstance) {
  return botInstance.sendMessage(chatId, "◈ Khusus owner grup.");
}

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}


// safeRestrict — wrapper restrictChatMember yang cek canRestrictTarget dulu.
// Signature: safeRestrict(bot, chatId, userId, permissions, untilDate?)
async function safeRestrict(bot, chatId, userId, permissions, untilDate) {
  const ok = await canRestrictTarget(bot, chatId, userId);
  if (!ok) return; // creator/admin tidak bisa di-restrict
  const opts = { chat_id: chatId, user_id: userId };
  // Support both flat permissions object and {permissions:{...}} shape
  if (permissions && permissions.permissions) {
    Object.assign(opts, permissions);
  } else {
    opts.permissions = permissions || {};
  }
  if (untilDate !== undefined) opts.until_date = untilDate;
  if (opts.permissions.until_date === undefined && opts.until_date !== undefined) {
    // keep until_date at top level for node-telegram-bot-api
  }
  await bot.restrictChatMember(chatId, userId, opts.permissions || opts, opts.until_date ? { until_date: opts.until_date } : undefined);
}

module.exports = (bot) => {
  bot.onText(/^\/warn(?:\s+(.+))?$/, async (msg, match) => {
    const chatId = msg.chat.id;
    if (!msg.chat.type.includes("group")) return bot.sendMessage(chatId, "◈ Perintah ini khusus grup.");
    if (!settings.isOwner(msg.from.id)) return bot.sendMessage(chatId, "⌖ Perintah ini khusus owner.");

    const reason = match[1] || "Tanpa alasan";
    const target = msg.reply_to_message?.from;
    if (!target) return bot.sendMessage(chatId, "⚠ Balas pesan anggota yang ingin diberi peringatan.");

    const userId = target.id;
    if (!warnDB[userId]) warnDB[userId] = [];
    warnDB[userId].push(reason);
    await saveWarnDB();

    const warnCount = warnDB[userId].length;

    const sent = await bot.sendMessage(chatId,
      `⚠ ${target.first_name} telah diperingatkan!\n⬡ Alasan: ${reason}\n⬡ Total peringatan: ${warnCount}/3`, {
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [[{
            text: "⊠ Batalkan Perigatan",
            callback_data: `cancel_warn_${userId}`
          }]]
        }
      }
    );

    pendingWarns.set(userId, sent.message_id);

    if (msg.reply_to_message) {
      try { await bot.deleteMessage(chatId, msg.reply_to_message.message_id); } catch (e) {}
    }

    if (warnCount >= 3) {
      try {
        await bot.kickChatMember(chatId, userId);
        delete warnDB[userId];
        await saveWarnDB();
        bot.sendMessage(chatId, `⎔ ${target.first_name} telah dikeluarkan karena mencapai batas peringatan.`);
      } catch (e) {
        bot.sendMessage(chatId, `◇ Gagal mengeluarkan ${target.first_name}. Pastikan bot admin.`);
      }
    }
  });

  bot.onText(/^\/warns$/, async (msg) => {
    const chatId = msg.chat.id;
    if (!msg.chat.type.includes("group")) return bot.sendMessage(chatId, "◈ Perintah ini khusus grup.");
    if (!settings.isOwner(msg.from.id)) return bot.sendMessage(chatId, "⌖ Perintah ini khusus owner.");

    const target = msg.reply_to_message?.from;
    if (!target) return bot.sendMessage(chatId, "⚠ Balas pesan anggota untuk melihat peringatannya.");

    const warns = warnDB[target.id] || [];
    if (warns.length === 0) return bot.sendMessage(chatId, `◉ <b>${target.first_name}</b> belum memiliki peringatan.`, { parse_mode: "HTML" });

    const list = warns.map((r, i) => `${i + 1}. ${r}`).join("\n");
    bot.sendMessage(chatId, `⚠ Peringatan untuk <b>${target.first_name}</b>:\n\n${list}`, { parse_mode: "HTML" });
  });

  bot.onText(/^\/resetwarn$/, async (msg) => {
    const chatId = msg.chat.id;
    if (!msg.chat.type.includes("group")) return bot.sendMessage(chatId, "◈ Perintah ini khusus grup.");
    if (!settings.isOwner(msg.from.id)) return bot.sendMessage(chatId, "⌖ Perintah ini khusus owner.");

    const target = msg.reply_to_message?.from;
    if (!target) return bot.sendMessage(chatId, "⚠ Balas pesan anggota untuk menghapus peringatannya.");

    delete warnDB[target.id];
    await saveWarnDB();
    bot.sendMessage(chatId, `◉ Peringatan <b>${target.first_name}</b> telah dihapus.`, { parse_mode: "HTML" });
  });

// CLOSE
bot.onText(/^\/close$/, async (msg) => {
  const chatId = msg.chat.id;
  if (!msg.chat.type.includes("group")) return bot.sendMessage(chatId, "◈ Perintah ini khusus grup.");
  if (!settings.isOwner(msg.from.id)) return bot.sendMessage(chatId, "⌖ Perintah ini khusus owner.");

  try {
    await bot.setChatPermissions(chatId, {
      can_send_messages: false,
      can_send_media_messages: false,
      can_send_other_messages: false,
      can_add_web_page_previews: false
    });
    bot.sendMessage(chatId, "◉ Grup telah *ditutup*.", { parse_mode: "Markdown" });
  } catch {
    bot.sendMessage(chatId, "⚠ Gagal menutup grup.");
  }
});

// OPEN
bot.onText(/^\/open$/, async (msg) => {
  const chatId = msg.chat.id;
  if (!msg.chat.type.includes("group")) return bot.sendMessage(chatId, "◈ Perintah ini khusus grup.");
  if (!settings.isOwner(msg.from.id)) return bot.sendMessage(chatId, "⌖ Perintah ini khusus owner.");

  try {
    await bot.setChatPermissions(chatId, {
      can_send_messages: true,
      can_send_media_messages: true,
      can_send_other_messages: true,
      can_add_web_page_previews: true
    });
    bot.sendMessage(chatId, "◉ Grup telah *dibuka*.", { parse_mode: "Markdown" });
  } catch {
    bot.sendMessage(chatId, "⚠ Gagal membuka grup.");
  }
});
// PIN
bot.onText(/^\/pin$/, async (msg) => {
  const chatId = msg.chat.id;
  if (!msg.chat.type.includes("group")) return bot.sendMessage(chatId, "◈ Perintah ini khusus grup.");
  if (!settings.isOwner(msg.from.id)) return notOwner(msg, chatId);

  if (!msg.reply_to_message)
    return bot.sendMessage(chatId, "⚠ Balas pesan yang ingin disematkan.");

  try {
    await bot.pinChatMessage(chatId, msg.reply_to_message.message_id);
    bot.sendMessage(chatId, "⬡ Pesan disematkan.");
  } catch {
    bot.sendMessage(chatId, "◇ Gagal menyematkan pesan.");
  }
});

// UNPIN
bot.onText(/^\/unpin$/, async (msg) => {
  const chatId = msg.chat.id;
  if (!msg.chat.type.includes("group")) return bot.sendMessage(chatId, "◈ Perintah ini khusus grup.");
  if (!settings.isOwner(msg.from.id)) return notOwner(msg, chatId);

  if (!msg.reply_to_message)
    return bot.sendMessage(chatId, "⚠ Balas pesan yang ingin dilepas.");

  try {
    await bot.unpinChatMessage(chatId, msg.reply_to_message.message_id);
    bot.sendMessage(chatId, "⬡ Sematan dilepas.");
  } catch {
    bot.sendMessage(chatId, "◇ Gagal melepas sematan.");
  }
});

// /promote and /demote are handled centrally by src/featureHub.js.
// The legacy owner-only handlers were removed to prevent duplicate execution.
bot.onText(/^\/del$/, async (msg) => {
  const chatId = msg.chat.id;

  // hanya bisa di grup
  if (!msg.chat.type.includes("group"))
    return bot.sendMessage(chatId, "⌖ Fitur ini hanya untuk grup.");

  // hanya OWNER_ID
  if (!settings.isOwner(msg.from.id))
    return bot.sendMessage(chatId, "◇ Anda bukan owner");

  // harus reply
  const targetMsg = msg.reply_to_message;
  if (!targetMsg)
    return bot.sendMessage(chatId, "⚠ Balas pesan yang ingin dihapus, lalu ketik /del");

  try {
    // hapus pesan target
    await bot.deleteMessage(chatId, targetMsg.message_id);

    // hapus pesan /del dari owner
    await bot.deleteMessage(chatId, msg.message_id);

  } catch (err) {
    console.error(err);
    bot.sendMessage(chatId, "◇ Gagal menghapus pesan. Pastikan bot adalah admin dan memiliki izin hapus pesan.");
  }
});
function parseDuration(str) {
  const num = parseInt(str);
  const unit = str.slice(-1);

  if (isNaN(num)) return null;

  switch (unit) {
    case "d": return num * 24 * 60 * 60 * 1000;
    case "h": return num * 60 * 60 * 1000;
    case "m": return num * 60 * 1000;
    default: return null;
  }
}

// MUTE <time>
bot.onText(/^\/mute(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;

  if (!msg.chat.type.includes("group"))
    return bot.sendMessage(chatId, "⌖ Ini fitur khusus grup.");

  if (!settings.isOwner(msg.from.id))
    return bot.sendMessage(chatId, "◇ Anda bukan owner");

  const target = msg.reply_to_message?.from;
  if (!target)
    return bot.sendMessage(chatId, "⚠ Balas pesan target lalu ketik /mute <waktu>");

  const timeArg = match[1] ? match[1].trim() : null;
  let untilDate = 0;

  if (timeArg) {
    const ms = parseDuration(timeArg);
    if (!ms)
      return bot.sendMessage(chatId, "◇ Format waktu salah!\nGunakan: 1d, 1h, 1m");

    untilDate = Math.floor((Date.now() + ms) / 1000);
  }

  try {
    await safeRestrict(bot, chatId, target.id, {
      can_send_messages: false,
      can_send_media_messages: false,
      can_send_other_messages: false,
      can_add_web_page_previews: false,
      until_date: untilDate || undefined // undefined = permanent
    });

    bot.sendMessage(
      chatId,
      `⊘ <b>${target.first_name}</b> berhasil di-mute ${
        timeArg ? `selama <b>${timeArg}</b>` : "secara permanen"
      }.`,
      { parse_mode: "HTML" }
    );
  } catch {
    bot.sendMessage(chatId, "◇ Gagal mute user.");
  }
});

// UNMUTE
bot.onText(/^\/unmute$/, async (msg) => {
  const chatId = msg.chat.id;

  // Hanya grup
  if (!msg.chat.type.includes("group"))
    return bot.sendMessage(chatId, "⌖ Ini fitur khusus grup.");

  // Hanya owner
  if (!settings.isOwner(msg.from.id))
    return bot.sendMessage(chatId, "◈ Khusus owner grup.");

  // Harus reply pesan
  if (!msg.reply_to_message)
    return bot.sendMessage(chatId, "⚠ Reply pesan target lalu ketik /unmute");

  const target = msg.reply_to_message.from;

  try {
    await safeRestrict(bot, chatId, target.id, {
      can_send_messages: true,
      can_send_media_messages: true,
      can_send_other_messages: true,
      can_add_web_page_previews: true
    });

    bot.sendMessage(
      chatId,
      `♪ <b>${target.first_name}</b> berhasil di-unmute.`,
      { parse_mode: "HTML" }
    );
  } catch (err) {
    bot.sendMessage(chatId, "◇ Gagal unmute user.");
  }
});
// BAN
bot.onText(/^\/ban$/, async (msg) => {
  const chatId = msg.chat.id;

  if (!msg.chat.type.includes("group"))
    return bot.sendMessage(chatId, "⌖ Ini fitur khusus grup.");

  if (!settings.isOwner(msg.from.id))
    return bot.sendMessage(chatId, "◇ Anda bukan owner");

  const target = msg.reply_to_message?.from;
  if (!target)
    return bot.sendMessage(chatId, "⚠ Balas pesan target lalu ketik /ban");

  try {
    await bot.kickChatMember(chatId, target.id);
    bot.sendMessage(chatId, `⊘ <b>${target.first_name}</b> berhasil di-ban.`, { parse_mode: "HTML" });
  } catch {
    bot.sendMessage(chatId, "◇ Gagal ban user.");
  }
});

// UNBAN
bot.onText(/^\/unban$/, async (msg) => {
  const chatId = msg.chat.id;

  if (!msg.chat.type.includes("group"))
    return bot.sendMessage(chatId, "⌖ Ini fitur khusus grup.");

  if (!settings.isOwner(msg.from.id))
    return bot.sendMessage(chatId, "◇ Anda bukan owner");

  const target = msg.reply_to_message?.from;
  if (!target)
    return bot.sendMessage(chatId, "⚠ Balas pesan target lalu ketik /unban");

  try {
    await bot.unbanChatMember(chatId, target.id);
    bot.sendMessage(chatId, `⟲ <b>${target.first_name}</b> berhasil di-unban.`, { parse_mode: "HTML" });
  } catch {
    bot.sendMessage(chatId, "◇ Gagal unban user.");
  }
});

// KICK
bot.onText(/^\/kick$/, async (msg) => {
  const chatId = msg.chat.id;

  if (!msg.chat.type.includes("group"))
    return bot.sendMessage(chatId, "⌖ Ini fitur khusus grup.");

  if (!settings.isOwner(msg.from.id))
    return bot.sendMessage(chatId, "◇ Anda bukan owner");

  const target = msg.reply_to_message?.from;
  if (!target)
    return bot.sendMessage(chatId, "⚠ Balas pesan target lalu ketik /kick");

  try {
    await bot.kickChatMember(chatId, target.id);
    await bot.unbanChatMember(chatId, target.id); // agar bisa join lagi

    bot.sendMessage(chatId, `⬡ <b>${target.first_name}</b> berhasil di-kick.`, { parse_mode: "HTML" });
  } catch {
    bot.sendMessage(chatId, "◇ Gagal kick user.");
  }
});
bot.onText(/^\/sticker$/, async (msg) => {
  const chatId = msg.chat.id;

  // fitur hanya di grup / private juga bisa
  const target = msg.reply_to_message;
  if (!target)
    return bot.sendMessage(chatId, "⚠ Balas foto/video yang ingin dijadikan sticker.");

  let fileId = null;

  // Cek media
  if (target.photo) {
    fileId = target.photo[target.photo.length - 1].file_id; // kualitas tertinggi
  } else if (target.video) {
    fileId = target.video.file_id;
  } else if (target.document && target.document.mime_type.startsWith("image/")) {
    fileId = target.document.file_id;
  } else {
    return bot.sendMessage(chatId, "◇ Media tidak valid.\nBalas foto atau video pendek.");
  }

  try {
    // Kirim sebagai sticker
    await bot.sendSticker(chatId, fileId, {
      reply_to_message_id: msg.message_id
    });
  } catch (err) {
    console.error(err);
    bot.sendMessage(chatId, "◇ Gagal membuat sticker.");
  }
});
// /autodel
bot.onText(/^\/autodel(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (!settings.isOwner(userId)) return bot.sendMessage(chatId, "◇ Anda bukan owner");

  const param = match[1];
  if (!param) {
    return bot.sendMessage(chatId, "⌖ Cara penggunaan:\n/autodel kata1,kata2,kata3");
  }

  const words = param
    .split(",")
    .map((w) => w.trim().toLowerCase())
    .filter((w) => w.length > 0);

  const data = loadAutodel();
  data.words.push(...words);
  data.words = [...new Set(data.words)];
  saveAutodel(data);

  bot.sendMessage(chatId, `◉ Ditambahkan ke autodel:\n- ${words.join("\n- ")}`);
});

// /delautodel <kata>
bot.onText(/^\/delautodel(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (!settings.isOwner(userId)) return bot.sendMessage(chatId, "◇ Anda bukan owner");

  const word = match[1];
  if (!word) return bot.sendMessage(chatId, "⌖ Cara penggunaan:\n/delautodel <kata>");

  const data = loadAutodel();
  const lower = word.toLowerCase();

  if (!data.words.includes(lower)) {
    return bot.sendMessage(chatId, `◇ Kata '${lower}' tidak ada dalam autodel.`);
  }

  data.words = data.words.filter((w) => w !== lower);
  saveAutodel(data);

  bot.sendMessage(chatId, `◉ Kata '${lower}' dihapus dari autodel.`);
});

// Auto delete
bot.on("message", async (msg) => {
  if (!msg.text) return;

  const text = msg.text.toLowerCase();
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (settings.isOwner(userId)) return;

  const data = loadAutodel();
  if (data.words.length === 0) return;

  for (const word of data.words) {
    if (text.includes(word)) {
      try {
        await bot.deleteMessage(chatId, msg.message_id);
      } catch {}
      break;
    }
  }
});
// ==========================
// LOAD & SAVE DELALL
// ==========================
const DELALL_FILE = "./delall.json";

function loadDelall() {
  if (!fs.existsSync(DELALL_FILE)) {
    fs.writeFileSync(DELALL_FILE, JSON.stringify({ users: [] }, null, 2));
  }
  return JSON.parse(fs.readFileSync(DELALL_FILE));
}

function saveDelall(data) {
  fs.writeFileSync(DELALL_FILE, JSON.stringify(data, null, 2));
}

// ==========================
// COMMAND /delall (REPLY)
// ==========================
bot.onText(/^\/mampus$/, async (msg) => {
  const chatId = msg.chat.id;

  if (!msg.chat.type.includes("group"))
    return bot.sendMessage(chatId, "⌖ Fitur ini hanya untuk grup.");

  if (!settings.isOwner(msg.from.id))
    return bot.sendMessage(chatId, "◇ Anda bukan owner");

  if (!msg.reply_to_message)
    return bot.sendMessage(chatId, "⚠ Reply pesan target lalu ketik /delall");

  const target = msg.reply_to_message.from;

  const data = loadDelall();
  if (!data.users.includes(target.id)) {
    data.users.push(target.id);
    saveDelall(data);
  }

  bot.sendMessage(
    chatId,
    `⌫ <b>${target.first_name}</b> masuk mode DELALL.\nSemua pesan akan dihapus.`,
    { parse_mode: "HTML" }
  );
});

// ==========================
// AUTO DELETE MESSAGE
// ==========================
bot.on("message", async (msg) => {
  if (!msg.from) return;

  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (settings.isOwner(userId)) return;

  const data = loadDelall();
  if (!data.users.includes(userId)) return;

  try {
    await bot.deleteMessage(chatId, msg.message_id);
  } catch {}
});
bot.onText(/^\/welcome\s+(on|off)$/i, (msg, match) => {
  const chatId = msg.chat.id;
  const status = match[1].toLowerCase();

  welcomeStatus[chatId] = status === "on";
  fs.writeFileSync(WELCOME_FILE, JSON.stringify(welcomeStatus, null, 2));

  bot.sendMessage(
    chatId,
    `<blockquote expandable>◈ <b>WELCOME NOTIFICATION</b></blockquote>\n\n` +
    `Status welcome: <b>${status.toUpperCase()}</b>\n` +
    `Group ID: <code>${chatId}</code>`,
    { parse_mode: "HTML" }
  );
});

// Welcome member baru — memakai foto profil Telegram sebagai cover.
// Jika foto tidak tersedia, bot tetap mengirim welcome card tanpa avatar.
bot.on("new_chat_members", async (msg) => {
  const chatId = msg.chat.id;
  if (!welcomeStatus[chatId]) return;

  const groupName = msg.chat.title || "Group";
  const members = msg.new_chat_members || [];

  for (const member of members) {
    try {
      const fullName = `${member.first_name || ""} ${member.last_name || ""}`.trim() || "Member";
      const username = member.username ? `@${member.username}` : "Tidak ada username";

      let avatar = null;
      try {
        const photos = await bot.getUserProfilePhotos(member.id, { limit: 1 });
        if (photos.total_count > 0) {
          // Ambil resolusi terbesar dari foto pertama.
          const sizes = photos.photos[0];
          avatar = sizes[sizes.length - 1]?.file_id || null;
        }
      } catch (e) {
        console.log("[welcome] Gagal mengambil foto profil:", e.message);
      }

      // Kartu visual baru: lebih bersih daripada template welcome lama.
      const canvas = createCanvas(900, 520);
      const ctx = canvas.getContext("2d");

      const bg = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
      bg.addColorStop(0, "#07111f");
      bg.addColorStop(0.55, "#10243b");
      bg.addColorStop(1, "#0b6b61");
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Decorative glow.
      ctx.fillStyle = "rgba(255,255,255,0.06)";
      ctx.beginPath();
      ctx.arc(780, 80, 150, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(80, 470, 190, 0, Math.PI * 2);
      ctx.fill();

      // Main glass card.
      ctx.fillStyle = "rgba(255,255,255,0.10)";
      ctx.roundRect(35, 35, 830, 450, 28);
      ctx.fill();
      ctx.strokeStyle = "rgba(255,255,255,0.18)";
      ctx.lineWidth = 2;
      ctx.stroke();

      // Avatar.
      const cx = 165, cy = 250, r = 92;
      ctx.save();
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.closePath();
      ctx.clip();

      if (avatar) {
        try {
          const avatarFile = await bot.getFile(avatar);
          const avatarUrl = `https://api.telegram.org/file/bot${settings.token}/${avatarFile.file_path}`;
          const response = await axios.get(avatarUrl, { responseType: "arraybuffer", timeout: 10000 });
          const image = await loadImage(response.data);
          const size = Math.max(image.width, image.height);
          const sx = (image.width - size) / 2;
          const sy = (image.height - size) / 2;
          ctx.drawImage(image, sx, sy, size, size, cx - r, cy - r, r * 2, r * 2);
        } catch (e) {
          ctx.fillStyle = "#1b314a";
          ctx.fillRect(cx - r, cy - r, r * 2, r * 2);
        }
      } else {
        ctx.fillStyle = "#1b314a";
        ctx.fillRect(cx - r, cy - r, r * 2, r * 2);
      }
      ctx.restore();

      ctx.strokeStyle = "rgba(255,255,255,0.85)";
      ctx.lineWidth = 5;
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.stroke();

      ctx.textAlign = "left";
      ctx.fillStyle = "#ffffff";
      ctx.font = "bold 38px Arial";
      ctx.fillText("WELCOME!", 305, 125);

      ctx.fillStyle = "rgba(255,255,255,0.72)";
      ctx.font = "22px Arial";
      ctx.fillText("Member baru telah bergabung", 305, 162);

      ctx.fillStyle = "#ffffff";
      ctx.font = "bold 30px Arial";
      const safeName = fullName.length > 24 ? fullName.slice(0, 23) + "…" : fullName;
      ctx.fillText(safeName, 305, 225);

      ctx.fillStyle = "rgba(255,255,255,0.72)";
      ctx.font = "20px Arial";
      const safeUser = username.length > 28 ? username.slice(0, 27) + "…" : username;
      ctx.fillText(safeUser, 305, 260);

      ctx.fillStyle = "rgba(255,255,255,0.62)";
      ctx.font = "18px Arial";
      ctx.fillText(`Group: ${groupName.length > 30 ? groupName.slice(0, 29) + "…" : groupName}`, 305, 305);

      ctx.fillStyle = "#ffffff";
      ctx.font = "bold 19px Arial";
      ctx.fillText("Jaga group tetap nyaman & tertib.", 305, 370);

      ctx.fillStyle = "rgba(255,255,255,0.62)";
      ctx.font = "17px Arial";
      ctx.fillText("No spam • No promosi • No rusuh • Hormati member lain", 305, 405);

      ctx.fillStyle = "rgba(255,255,255,0.45)";
      ctx.font = "15px Arial";
      ctx.fillText("#LIANIX CPANEL", 305, 445);

      const buffer = canvas.toBuffer("image/png");

      const caption =
        `<blockquote expandable>` +
        `✦ <b>WELCOME TO ${escapeHtml(groupName)}</b>\n\n` +
        `👤 <b>${escapeHtml(fullName)}</b>\n` +
        `⌁ ${escapeHtml(username)}\n` +
        `🆔 <code>${member.id}</code>\n\n` +
        `Selamat bergabung! Baca rules sebelum mulai beraktivitas.` +
        `</blockquote>\n\n` +
        `<b>RULES</b>\n` +
        `• Jangan spam / flood\n` +
        `• Jangan promosi tanpa izin\n` +
        `• Jangan sebar domain sembarangan\n` +
        `• Jangan rusuh atau mengganggu member lain`;

      await bot.sendPhoto(chatId, buffer, {
        caption,
        parse_mode: "HTML"
      });
    } catch (err) {
      console.error("[welcome] gagal:", err.message);
      // Fallback agar member tetap mendapat welcome meskipun kartu gagal dibuat.
      try {
        const name = `${member.first_name || ""} ${member.last_name || ""}`.trim() || "Member";
        await bot.sendMessage(
          chatId,
          `<blockquote expandable>✦ <b>WELCOME</b>\n\n` +
          `Selamat datang <b>${escapeHtml(name)}</b>!\n` +
          `Silakan baca rules group sebelum beraktivitas.</blockquote>`,
          { parse_mode: "HTML" }
        );
      } catch {}
    }
  }
});
}
