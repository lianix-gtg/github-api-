// src/errorAudit.js
// LianiX — deeper startup/runtime error detection.
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const IGNORED_DIRS = new Set(['node_modules', '.git', '.cache', 'output', 'tmp']);
const ERROR_PATTERNS = [
  /\bETELEGRAM\b/i,
  /\bERROR\b/i,
  /\bERR_?\w+/i,
  /\b(?:TypeError|ReferenceError|SyntaxError|RangeError|URIError|EvalError|AxiosError|FetchError|TelegramError)\b/i,
  /Unhandled(?:Promise)?(?:Rejection|Exception)/i,
  /uncaught(?: exception| error)/i,
  /(?:bad request|bad gateway|service unavailable|gateway timeout)/i,
  /(?:request failed|fetch failed|failed to|timed out|timeout)/i,
  /(?:cannot read (?:properties|property)|cannot set (?:properties|property))/i,
  /(?:is not a function|is not defined|undefined is not|cannot destructure)/i,
  /(?:permission denied|forbidden|unauthorized|access denied)/i,
  /(?:ECONN(?:REFUSED|RESET|ABORTED)|ECONNRESET|EPIPE|EHOSTUNREACH)/i,
  /(?:ETIMEDOUT|ENOTFOUND|EAI_AGAIN|ENETUNREACH)/i,
  /\bHTTP\s*[45]\d\d\b/i,
  /\b(?:status|code)\s*[:=]?\s*[45]\d\d\b/i,
  /(?:gagal|kesalahan|terjadi error|tidak dapat|tidak berhasil|ditolak)/i,
];

function walk(dir, out = []) {
  if (!fs.existsSync(dir)) return out;
  for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
    if (IGNORED_DIRS.has(ent.name)) continue;
    const full = path.join(dir, ent.name);
    if (ent.isDirectory()) walk(full, out);
    else out.push(full);
  }
  return out;
}

function checkJavaScript(file) {
  try {
    execFileSync(process.execPath, ['--check', file], {
      stdio: ['ignore', 'pipe', 'pipe'],
      timeout: 15000,
      encoding: 'utf8'
    });
    return null;
  } catch (e) {
    return String(e.stderr || e.stdout || e.message || e).trim();
  }
}

function checkJson(file) {
  try {
    JSON.parse(fs.readFileSync(file, 'utf8'));
    return null;
  } catch (e) {
    return `${e.name}: ${e.message}`;
  }
}

function startupAudit(root) {
  const files = walk(root);
  const errors = [];
  for (const file of files) {
    const rel = path.relative(root, file);
    if (file.endsWith('.js')) {
      const err = checkJavaScript(file);
      if (err) errors.push({ file: rel, type: 'JS_SYNTAX', error: err });
    } else if (file.endsWith('.json')) {
      const err = checkJson(file);
      if (err) errors.push({ file: rel, type: 'JSON_PARSE', error: err });
    }
  }
  return { checked: files.length, errors };
}

function looksLikeError(value) {
  const text = String(value ?? '');
  if (!text.trim()) return false;
  return ERROR_PATTERNS.some(re => re.test(text));
}

function installConsoleMonitor({ report, cooldownMs = 3000 } = {}) {
  if (global.__LIANIX_ERROR_AUDIT_INSTALLED) return;
  global.__LIANIX_ERROR_AUDIT_INSTALLED = true;

  const originalError = console.error.bind(console);
  const originalWarn = console.warn.bind(console);
  const originalLog = console.log.bind(console);
  const recent = new Map();

  const inspect = (level, args) => {
    const text = args.map(v => {
      if (v instanceof Error) return v.stack || v.message;
      if (typeof v === 'string') return v;
      try { return JSON.stringify(v); } catch { return String(v); }
    }).join(' ');
    // Abaikan log internal/benign agar error-audit tidak membuat SYSTEM ERROR palsu.
    // Telegram returns this 400 when an edit is identical to the current
    // message. It is an idempotent no-op, not a real system error.
    if (/ETELEGRAM:\s*400\s+Bad Request:\s*message is not modified/i.test(text) ||
        /400\s+Bad Request:\s*message is not modified/i.test(text) ||
        /message is not modified:\s*specified new message content/i.test(text) ||
        // Safe Telegram edit wrapper already handles malformed reply_markup.
        // Do not turn this handled condition into a second SYSTEM ERROR.
        /\[(?:editMessageText|editMessageCaption|editMessageReplyMarkup)\] gagal:.*(?:can't parse reply keyboard markup|reply keyboard markup)/i.test(text) ||
        // Safe-edit converts overlong media captions into a fresh text message.
        /(?:MEDIA_CAPTION_TOO_LONG|caption.*too long|message caption is too long)/i.test(text) ||
        /Bad Request:\s*can't parse reply keyboard markup(?: JSON object)?/i.test(text) ||
        // Transient network errors — Telegram/hosting blip, bukan bug bot.
        // Jangan kirim ke monitor karena hanya akan spam owner tanpa manfaat.
        /ETELEGRAM:\s*(502|503|504)/i.test(text) ||
        /502 Bad Gateway|503 Service Unavailable|504 Gateway/i.test(text) ||
        /ECONNRESET|AggregateError|socket hang up/i.test(text) ||
        /\[polling\]\s*transient/i.test(text) ||
        /\[monitor\]\s*transient network error/i.test(text) ||
        /^\s*\[ERROR-AUDIT\]/i.test(text) ||
        /skip setMaxListeners: bot\.setMaxListeners is not a function/i.test(text) ||
        // Reply-to message was deleted — benign race condition, bukan bug bot.
        /message to be replied not found/i.test(text) ||
        /^\s*\[antikill\] ERROR:\s*Unauthenticated\.?\s*$/i.test(text) ||
        // antikill: panel unreachable/timeout adalah kondisi normal (panel off / network blip)
        /^\s*\[antikill\] panel unreachable/i.test(text) ||
        /^\s*\[antikill\].*(timeout|ETIMEDOUT|ECONNREFUSED|ENOTFOUND|ECONNRESET)/i.test(text) ||
        // AI tools: external AI endpoint unreachable, bukan error fatal bot
        /^\s*\[ai.{0,20}\].*(timeout|ETIMEDOUT|ECONNREFUSED|ENOTFOUND|unreachable)/i.test(text) ||
        // Native module warnings — non-fatal, bot tetap jalan
        /◈ PERINGATAN:.*tidak dapat dimuat/i.test(text) ||
        /◈ PERINGATAN:.*WhatsApp Bridge/i.test(text) ||
        /◈ PERINGATAN:.*bcrypt/i.test(text) ||
        /◈ PERINGATAN:.*native module/i.test(text) ||
        /Fitur WhatsApp.*Bot Telegram tetap berjalan/i.test(text) ||
        /Pastikan bcryptjs terinstall/i.test(text) ||
        // Temp Mail upstream can reject inbox polling with 403. The AM
        // provider layer now handles this and falls back automatically.
        /\[tempMail2CheckInbox\].*(Inbox HTTP 403|HTTP 403|forbidden)/i.test(text) ||
        /\[tempMail2Get\].*(HTTP 403|forbidden).*fallback Generator\.email/i.test(text) ||
        // Broadcast to another Telegram bot is prohibited by Telegram's Bot API.
        // It is an expected target-type limitation, not a bot runtime failure.
        /ETELEGRAM:\s*400\s+Bad Request:\s*USER_BOT_TO_BOT_DISABLED/i.test(text) ||
        /ETELEGRAM:\s*400\s+Bad Request:\s*chat not found/i.test(text)) return;
    if (!looksLikeError(text) || typeof report !== 'function') return;
    const key = `${level}:${text.slice(0, 1200)}`;
    const now = Date.now();
    if (recent.get(key) && now - recent.get(key) < cooldownMs) return;
    recent.set(key, now);
    Promise.resolve(report(`console.${level}`, new Error(text), { captured: true })).catch(() => {});
  };

  console.error = (...args) => {
    originalError(...args);
    inspect('error', args);
  };
  console.warn = (...args) => {
    originalWarn(...args);
    inspect('warn', args);
  };
  console.log = (...args) => {
    originalLog(...args);
    inspect('log', args);
  };

  return () => {
    console.error = originalError;
    console.warn = originalWarn;
    console.log = originalLog;
    delete global.__LIANIX_ERROR_AUDIT_INSTALLED;
  };
}

module.exports = { startupAudit, installConsoleMonitor, looksLikeError };
