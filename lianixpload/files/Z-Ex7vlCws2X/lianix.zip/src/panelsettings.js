// src/panelsettings.js
// Fitur "▭ Kelola Panel" — ganti domain/PLTA/PLTC slot panel (1, V2..V20, ADP)
// lewat tombol, satu-satu ATAU BANYAK SEKALIGUS (checklist + pilih semua),
// tanpa perlu edit settings.js manual.
//
// ALUR SATUAN:
// 1. Owner ketik /setpanel -> muncul grid tombol Panel 1, V2..V20, ADP.
// 2. Pencet salah satu -> bot nampilin domain/plta/pltc slot itu SEKARANG,
//    terus minta kirim 3 baris baru: domain, plta, pltc ("-" = biarin sama).
//
// ALUR BULK (BANYAK PANEL SEKALIGUS):
// 1. Dari menu /setpanel, pencet "◉ Pilih Banyak (Bulk Edit)".
// 2. Centang panel yang mau diseragamin (misal V1 + V5), atau pencet
//    "◉ Pilih Semua" buat centang semuanya sekaligus.
// 3. Pencet "▶ Terapkan ke N Panel Terpilih" -> kirim 3 baris domain/plta/pltc
//    yang SAMA, bakal diterapin ke SEMUA panel yang dicentang tadi.
//
const fs = require("fs");
const ownerStore = require("./data/ownerStore.js");
const panelStore = require("./data/panelStore.js");

// userId (string) -> panel key ("1".."20"/"adp") yang lagi ditunggu inputnya (mode satuan)
const pendingPanelEdit = {};
// userId -> field yang sedang diminta: domain | plta | pltc | eggs | eggsPython | all
const pendingPanelField = {};
// userId (string) -> Set<key> panel yang lagi dicentang (mode bulk)
const bulkSelection = {};
// userId (string) -> true kalau lagi nunggu input domain/plta/pltc buat diterapin ke seleksi bulk
const pendingBulkEdit = {};
// userId (string) -> "command" | "devpanel" — nentuin menu "Kelola Panel" ini lagi
// nampil di pesan teks baru (dari /setpanel) atau numpang di pesan Dev Panel yang
// sama (dari tombol "▭ Kelola Panel" di Dev Panel), soalnya cara edit pesannya
// beda: teks biasa pakai editMessageText, caption foto Dev Panel pakai editMessageCaption.
const panelOrigin = {};

function isOwner(userId) {
  return String(userId) === String(ownerStore.getOwnerId());
}

function getSelection(userId) {
  if (!bulkSelection[userId]) bulkSelection[userId] = new Set();
  return bulkSelection[userId];
}

// ============== Keyboard: menu utama (mode satuan) ==============
// fromDevPanel=true -> menu ini numpang di pesan Dev Panel, jadi tombol
// terakhir "‹ Kembali ke Dev Panel" (bukan "◇ Tutup", biar Dev Panel-nya
// gak ikut kehapus).
function buildPanelListKeyboard(fromDevPanel = false) {
  const rows = [
    [{ text: "◉ Pilih Banyak (Bulk Edit)", callback_data: "panelbulk_open" }],
    [{ text: "▭ Panel 1 (Utama)", callback_data: "panelset_1" }],
  ];

  let row = [];
  for (let i = 2; i <= 20; i++) {
    row.push({ text: `V${i}`, callback_data: `panelset_${i}` });
    if (row.length === 5) {
      rows.push(row);
      row = [];
    }
  }
  if (row.length) rows.push(row);

  rows.push([{ text: "⬡ Panel ADP", callback_data: "panelset_adp" }]);
  rows.push(
    fromDevPanel
      ? [{ text: "‹ ‹", callback_data: "devpanel" }]
      : [{ text: "⊠ Tutup", callback_data: "panelset_close" }]
  );

  return { inline_keyboard: rows };
}

// ============== Helper: edit pesan menu panel sesuai asalnya ==============
// Kalau dibuka dari Dev Panel, pesannya adalah caption foto -> editMessageCaption.
// Kalau dibuka dari /setpanel, pesannya teks biasa -> editMessageText.
function editPanelMessage(bot, q, text, reply_markup) {
  const uid = String(q.from.id);
  const payload = {
    chat_id: q.message.chat.id,
    message_id: q.message.message_id,
    parse_mode: "HTML",
    reply_markup,
  };
  return panelOrigin[uid] === "devpanel"
    ? bot.editMessageCaption(text, payload)
    : bot.editMessageText(text, payload);
}

// ============== Keyboard: mode bulk (checklist) ==============
function buildBulkKeyboard(userId) {
  const selected = getSelection(userId);
  const allSelected = panelStore.PANEL_KEYS.every((k) => selected.has(k));

  const chip = (key, label) => ({
    text: `${selected.has(key) ? "◉" : "□"} ${label}`,
    callback_data: `panelbulk_toggle_${key}`,
  });

  const rows = [[chip("1", "Panel 1")]];

  let row = [];
  for (let i = 2; i <= 20; i++) {
    row.push(chip(String(i), `V${i}`));
    if (row.length === 4) {
      rows.push(row);
      row = [];
    }
  }
  if (row.length) rows.push(row);

  rows.push([chip("adp", "ADP")]);
  rows.push([
    { text: allSelected ? "⊟ Kosongkan Semua" : "◉ Pilih Semua", callback_data: "panelbulk_toggleall" },
  ]);
  rows.push([
    { text: `▶ Terapkan ke ${selected.size} Panel Terpilih`, callback_data: "panelbulk_apply" },
  ]);
  rows.push([{ text: "⬅ Balik ke daftar panel", callback_data: "panelset_list" }]);

  return { inline_keyboard: rows };
}

function bulkMenuText(userId) {
  const selected = getSelection(userId);
  const list = selected.size
    ? [...selected].map((k) => panelStore.labelFor(k)).join(", ")
    : "(belum ada)";
  return (
    "◉ <b>Bulk Edit Panel</b>\n\n" +
    "Centang panel yang mau diseragamin domain/PLTA/PLTC-nya, boleh pilih beberapa " +
    "sekaligus (misal Panel 1 + V5), atau langsung \"Pilih Semua\".\n\n" +
    `Terpilih sekarang: <i>${list}</i>`
  );
}

function mask(secret) {
  if (!secret) return "-";
  if (secret.length <= 10) return secret;
  return `${secret.slice(0, 8)}...${secret.slice(-4)}`;
}

function panelSummaryText(key) {
  const p = panelStore.getPanel(key);
  return (
    `<b>${panelStore.labelFor(key)}</b>\n` +
    `Domain      : <code>${p.domain}</code>\n` +
    `PLTA        : <code>${mask(p.plta)}</code>\n` +
    `PLTC        : <code>${mask(p.pltc)}</code>\n` +
    `Egg Node.js : <code>${p.eggs || "20"}</code>\n` +
    `Egg Python  : <code>${p.eggsPython || "22"}</code>`
  );
}

function editKeyboard(key) {
  return {
    inline_keyboard: [
      [
        { text: "🌐 Domain", callback_data: `panelfield_${key}_domain` },
        { text: "🔑 PLTA", callback_data: `panelfield_${key}_plta` },
      ],
      [
        { text: "🔐 PLTC", callback_data: `panelfield_${key}_pltc` },
        { text: "🥚 Egg Node", callback_data: `panelfield_${key}_eggs` },
      ],
      [{ text: "🐍 Egg Python", callback_data: `panelfield_${key}_eggsPython` }],
      [{ text: "✎ Edit SEMUA", callback_data: `panelsetedit_${key}` }],
      [{ text: "⬅ Balik ke daftar panel", callback_data: "panelset_list" }],
    ],
  };
}

function fieldPrompt(field) {
  const labels = {
    domain: "🌐 Domain",
    plta: "🔑 PLTA",
    pltc: "🔐 PLTC",
    eggs: "🥚 Egg Node.js",
    eggsPython: "🐍 Egg Python",
    all: "✎ Semua Setting",
  };
  return labels[field] || "Setting";
}

function parseSingleField(field, text, current) {
  const value = String(text || "").trim();
  if (!value) return { ok: false, error: "◇ Nilai tidak boleh kosong." };
  if (value === "-") return { ok: true, value: current[field] };

  if (field === "domain" && !/^https?:\/\/.+/i.test(value)) {
    return { ok: false, error: "◇ Domain harus diawali http:// atau https://." };
  }
  if (field === "plta" && !/^ptla_/i.test(value)) {
    return { ok: false, error: '◇ PLTA harus diawali "ptla_".' };
  }
  if (field === "pltc" && !/^ptlc_/i.test(value)) {
    return { ok: false, error: '◇ PLTC harus diawali "ptlc_".' };
  }
  if ((field === "eggs" || field === "eggsPython") && !/^\d+$/.test(value)) {
    return { ok: false, error: "◇ Egg harus berupa angka (ID Egg Nest Pterodactyl)." };
  }
  return { ok: true, value };
}


// Validasi 5 baris: domain, plta, pltc, egg_node, egg_python
// "-" = biarin sama kayak nilai `current`.
// Return { ok:true, domain, plta, pltc, eggs, eggsPython } atau { ok:false, error }.
function parseFiveLines(text, current) {
  const lines = text.split("\n").map((l) => l.trim());
  if (lines.length < 5) {
    return { ok: false, error: "◇ Format salah. Kirim 5 baris:\ndomain\nPLTA\nPLTC\nEgg Node.js\nEgg Python\n(pisah pakai Enter, \"-\" buat skip baris)" };
  }
  const [domainLine, pltaLine, pltcLine, eggsLine, eggsPyLine] = lines;
  const domain      = domainLine  === "-" ? current.domain      : domainLine;
  const plta        = pltaLine    === "-" ? current.plta        : pltaLine;
  const pltc        = pltcLine    === "-" ? current.pltc        : pltcLine;
  const eggs        = eggsLine    === "-" ? (current.eggs      || "20") : eggsLine;
  const eggsPython  = eggsPyLine  === "-" ? (current.eggsPython || "22") : eggsPyLine;

  if (!/^https?:\/\/.+/i.test(domain)) {
    return { ok: false, error: "◇ Domain harus diawali http:// atau https://." };
  }
  if (!/^ptla_/i.test(plta)) {
    return { ok: false, error: '◇ PLTA harus diawali "ptla_" (Application API key Pterodactyl).' };
  }
  if (!/^ptlc_/i.test(pltc)) {
    return { ok: false, error: '◇ PLTC harus diawali "ptlc_" (Client API key Pterodactyl).' };
  }
  if (!/^\d+$/.test(eggs)) {
    return { ok: false, error: "◇ Egg Node.js harus berupa angka (ID egg di Nest Pterodactyl)." };
  }
  if (!/^\d+$/.test(eggsPython)) {
    return { ok: false, error: "◇ Egg Python harus berupa angka (ID egg di Nest Pterodactyl)." };
  }
  return { ok: true, domain, plta, pltc, eggs, eggsPython };
}

module.exports = function registerPanelSettings(bot) {
  // ============== Buka menu daftar panel ==============
  bot.onText(/^\/setpanel$/, async (msg) => {
    const chatId = msg.chat.id;
    if (!isOwner(msg.from.id)) {
      return bot.sendMessage(chatId, "⌖ Perintah ini khusus owner. bot.");
    }
    const uid = String(msg.from.id);
    delete bulkSelection[uid];
    panelOrigin[uid] = "command";
    await bot.sendMessage(
      chatId,
      "▭ <b>Kelola Panel</b>\n\nPilih panel yang mau kamu lihat/ganti (domain, PLTA, PLTC), atau pakai Bulk Edit buat ubah beberapa panel sekaligus:",
      { parse_mode: "HTML", reply_markup: buildPanelListKeyboard() }
    );
  });

  // ============== Tombol "▭ Kelola Panel" di Dev Panel ==============
  // Ganti /setpanel jadi tombol: pesan Dev Panel yang lagi kebuka langsung
  // disulap jadi menu Kelola Panel (caption-nya diedit di tempat), sama
  // kayak alur "⬡ Kelola Channel".
  bot.on("callback_query", async (q) => {
    if (q.data !== "devsetpanel") return;
    try {
      if (!isOwner(q.from.id)) {
        return bot.answerCallbackQuery(q.id, { text: "◇ Khusus Dev/Owner.", show_alert: true });
      }
      const uid = String(q.from.id);
      delete bulkSelection[uid];
      delete pendingPanelEdit[uid];
      delete pendingPanelField[uid];
      delete pendingBulkEdit[uid];
      panelOrigin[uid] = "devpanel";

      await bot.answerCallbackQuery(q.id);
      await bot.editMessageCaption(
        "▭ <b>Kelola Panel</b>\n\nPilih panel yang mau kamu lihat/ganti (domain, PLTA, PLTC), atau pakai Bulk Edit buat ubah beberapa panel sekaligus:",
        {
          chat_id: q.message.chat.id,
          message_id: q.message.message_id,
          parse_mode: "HTML",
          reply_markup: buildPanelListKeyboard(true),
        }
      );
    } catch (e) {
      console.error("[panelsettings] Gagal buka Kelola Panel dari Dev Panel:", e.message);
      try {
        await bot.answerCallbackQuery(q.id, { text: "◇ Gagal, coba lagi.", show_alert: true });
      } catch (_) {}
    }
  });

  // ============== Balik ke daftar panel ==============
  bot.on("callback_query", async (q) => {
    if (q.data !== "panelset_list") return;
    try {
      if (!isOwner(q.from.id)) {
        return bot.answerCallbackQuery(q.id, { text: "Khusus Owner.", show_alert: true });
      }
      const uid = String(q.from.id);
      delete pendingPanelEdit[uid];
      delete pendingPanelField[uid];
      delete pendingBulkEdit[uid];
      await bot.answerCallbackQuery(q.id);
      await editPanelMessage(
        bot,
        q,
        "▭ <b>Kelola Panel</b>\n\nPilih panel yang mau kamu lihat/ganti (domain, PLTA, PLTC), atau pakai Bulk Edit buat ubah beberapa panel sekaligus:",
        buildPanelListKeyboard(panelOrigin[uid] === "devpanel")
      );
    } catch (e) {
      console.error("[panelsettings] Gagal balik ke daftar panel:", e.message);
    }
  });

  // ============== Tutup menu ==============
  bot.on("callback_query", async (q) => {
    if (q.data !== "panelset_close") return;
    try {
      const uid = String(q.from.id);
      delete pendingPanelEdit[uid];
      delete pendingPanelField[uid];
      delete pendingBulkEdit[uid];
      delete bulkSelection[uid];
      delete panelOrigin[uid];
      await bot.answerCallbackQuery(q.id);
      await bot.deleteMessage(q.message.chat.id, q.message.message_id);
    } catch (e) {
      try {
        await bot.answerCallbackQuery(q.id);
      } catch (_) {}
    }
  });

  // ========================================================================
  // ==========================  MODE SATUAN  ==============================
  // ========================================================================

  // ============== Pilih satu panel -> tampilin ringkasan + tombol edit ==============
  bot.on("callback_query", async (q) => {
    if (!q.data || !q.data.startsWith("panelset_") || q.data.startsWith("panelsetedit_")) return;
    if (["panelset_list", "panelset_close"].includes(q.data)) return;

    const key = q.data.slice("panelset_".length);
    if (!panelStore.isValidKey(key)) return;

    try {
      if (!isOwner(q.from.id)) {
        return bot.answerCallbackQuery(q.id, { text: "Khusus Owner.", show_alert: true });
      }
      delete pendingPanelEdit[String(q.from.id)];
      delete pendingPanelField[String(q.from.id)];
      await bot.answerCallbackQuery(q.id);
      await editPanelMessage(bot, q, panelSummaryText(key), editKeyboard(key));
    } catch (e) {
      console.error("[panelsettings] Gagal nampilin ringkasan panel:", e.message);
      try {
        await bot.answerCallbackQuery(q.id, { text: "◇ Gagal, coba lagi.", show_alert: true });
      } catch (_) {}
    }
  });

  // ============== Pilih field yang mau diedit ==============
  bot.on("callback_query", async (q) => {
    if (!q.data || !q.data.startsWith("panelfield_")) return;
    const parts = q.data.split("_");
    const key = parts[1];
    const field = parts.slice(2).join("_");
    const allowed = ["domain", "plta", "pltc", "eggs", "eggsPython"];
    if (!panelStore.isValidKey(key) || !allowed.includes(field)) return;

    try {
      const uid = String(q.from.id);
      if (!isOwner(uid)) {
        return bot.answerCallbackQuery(q.id, { text: "Khusus Owner.", show_alert: true });
      }
      pendingPanelEdit[uid] = key;
      pendingPanelField[uid] = field;
      await bot.answerCallbackQuery(q.id);

      const cur = panelStore.getPanel(key);
      const currentValue = field === "plta" || field === "pltc" ? mask(cur[field]) : (cur[field] || "-");
      const examples = {
        domain: "https://panelkamu.com",
        plta: "ptla_xxxxxxxx",
        pltc: "ptlc_xxxxxxxx",
        eggs: "20",
        eggsPython: "22",
      };
      await bot.sendMessage(
        q.message.chat.id,
        `✎ <b>${fieldPrompt(field)} — ${panelStore.labelFor(key)}</b>\n\n` +
        `Kirim <b>1 nilai</b> untuk mengganti field ini.\n` +
        `Nilai sekarang: <code>${currentValue}</code>\n\n` +
        `Contoh:\n<code>${examples[field]}</code>\n\n` +
        `Kirim <code>-</code> untuk membatalkan perubahan field.\n` +
        `Ketik /batalpanel untuk keluar dari mode edit.`,
        { parse_mode: "HTML" }
      );
    } catch (e) {
      console.error("[panelsettings] Gagal memilih field:", e.message);
      try { await bot.answerCallbackQuery(q.id, { text: "◇ Gagal, coba lagi.", show_alert: true }); } catch (_) {}
    }
  });

  // ============== Edit SEMUA field sekaligus ==============
  bot.on("callback_query", async (q) => {
    if (!q.data || !q.data.startsWith("panelsetedit_")) return;

    const key = q.data.slice("panelsetedit_".length);
    if (!panelStore.isValidKey(key)) return;

    try {
      const requesterId = String(q.from.id);
      if (!isOwner(requesterId)) {
        return bot.answerCallbackQuery(q.id, { text: "Khusus Owner.", show_alert: true });
      }

      pendingPanelEdit[requesterId] = key;
      pendingPanelField[requesterId] = "all";
      await bot.answerCallbackQuery(q.id);
      const cur = panelStore.getPanel(key);
      await bot.sendMessage(
        q.message.chat.id,
        `✎ <b>Edit SEMUA — ${panelStore.labelFor(key)}</b>\n\n` +
          `Kirim 5 baris (Enter tiap baris):\n` +
          `<code>Domain\nPLTA\nPLTC\nEgg Node.js\nEgg Python</code>\n\n` +
          `Contoh:\n` +
          `<code>https://panelkamu.com\nptla_xxxxxxxx\nptlc_xxxxxxxx\n20\n22</code>\n\n` +
          `Nilai sekarang:\n` +
          `<pre>Domain     : ${cur.domain || "-"}\nPLTA       : ${mask(cur.plta)}\nPLTC       : ${mask(cur.pltc)}\nEgg Node   : ${cur.eggs || "20"}\nEgg Python : ${cur.eggsPython || "22"}</pre>` +
          `\nIsi <code>-</code> pada baris yang ingin dipertahankan.\n` +
          `Ketik /batalpanel untuk batal.`,
        { parse_mode: "HTML" }
      );
    } catch (e) {
      console.error("[panelsettings] Gagal mulai edit semua:", e.message);
      try { await bot.answerCallbackQuery(q.id, { text: "◇ Gagal, coba lagi.", show_alert: true }); } catch (_) {}
    }
  });

  // ========================================================================
  // ============================  MODE BULK  ===============================
  // ========================================================================

  // ============== Buka mode bulk ==============
  bot.on("callback_query", async (q) => {
    if (q.data !== "panelbulk_open") return;
    try {
      if (!isOwner(q.from.id)) {
        return bot.answerCallbackQuery(q.id, { text: "Khusus Owner.", show_alert: true });
      }
      const uid = String(q.from.id);
      bulkSelection[uid] = new Set();
      await bot.answerCallbackQuery(q.id);
      await editPanelMessage(bot, q, bulkMenuText(uid), buildBulkKeyboard(uid));
    } catch (e) {
      console.error("[panelsettings] Gagal buka mode bulk:", e.message);
    }
  });

  // ============== Toggle centang satu panel ==============
  bot.on("callback_query", async (q) => {
    if (!q.data || !q.data.startsWith("panelbulk_toggle_")) return;

    const key = q.data.slice("panelbulk_toggle_".length);
    if (!panelStore.isValidKey(key)) return;

    try {
      if (!isOwner(q.from.id)) {
        return bot.answerCallbackQuery(q.id, { text: "Khusus Owner.", show_alert: true });
      }
      const uid = String(q.from.id);
      const selected = getSelection(uid);
      if (selected.has(key)) selected.delete(key);
      else selected.add(key);

      await bot.answerCallbackQuery(q.id);
      await editPanelMessage(bot, q, bulkMenuText(uid), buildBulkKeyboard(uid));
    } catch (e) {
      console.error("[panelsettings] Gagal toggle centang panel:", e.message);
      try {
        await bot.answerCallbackQuery(q.id, { text: "◇ Gagal, coba lagi.", show_alert: true });
      } catch (_) {}
    }
  });

  // ============== "◉ Pilih Semua" / "⊟ Kosongkan Semua" ==============
  bot.on("callback_query", async (q) => {
    if (q.data !== "panelbulk_toggleall") return;
    try {
      if (!isOwner(q.from.id)) {
        return bot.answerCallbackQuery(q.id, { text: "Khusus Owner.", show_alert: true });
      }
      const uid = String(q.from.id);
      const selected = getSelection(uid);
      const allSelected = panelStore.PANEL_KEYS.every((k) => selected.has(k));

      if (allSelected) {
        selected.clear();
      } else {
        panelStore.PANEL_KEYS.forEach((k) => selected.add(k));
      }

      await bot.answerCallbackQuery(q.id);
      await editPanelMessage(bot, q, bulkMenuText(uid), buildBulkKeyboard(uid));
    } catch (e) {
      console.error("[panelsettings] Gagal pilih/kosongkan semua:", e.message);
    }
  });

  // ============== "▶ Terapkan ke N Panel Terpilih" -> minta input ==============
  bot.on("callback_query", async (q) => {
    if (q.data !== "panelbulk_apply") return;
    try {
      if (!isOwner(q.from.id)) {
        return bot.answerCallbackQuery(q.id, { text: "Khusus Owner.", show_alert: true });
      }
      const uid = String(q.from.id);
      const selected = getSelection(uid);
      if (selected.size === 0) {
        return bot.answerCallbackQuery(q.id, { text: "Centang minimal 1 panel dulu.", show_alert: true });
      }

      pendingBulkEdit[uid] = true;
      await bot.answerCallbackQuery(q.id);

      const list = [...selected].map((k) => panelStore.labelFor(k)).join(", ");
      await bot.sendMessage(
        q.message.chat.id,
        `✎ <b>Bulk Edit (${selected.size} panel)</b>\n${list}\n\n` +
          `Kirim 5 baris (domain, PLTA, PLTC, Egg Node.js, Egg Python) yang mau diterapin ke SEMUA panel di atas.\n\n` +
          `Contoh:\n<code>https://panelkamu.com\nptla_xxxxxxxx\nptlc_xxxxxxxx\n20\n22</code>\n\n` +
          `Isi baris dengan <code>-</code> buat skip (tiap panel tetap pakai nilai lamanya).\n\n` +
          `Ketik /batalpanel buat batalin.`,
        { parse_mode: "HTML" }
      );
    } catch (e) {
      console.error("[panelsettings] Gagal mulai bulk apply:", e.message);
      try {
        await bot.answerCallbackQuery(q.id, { text: "◇ Gagal, coba lagi.", show_alert: true });
      } catch (_) {}
    }
  });

  // ========================================================================
  // ====================  INPUT TEKS (satuan & bulk)  ======================
  // ========================================================================

  bot.on("message", async (msg) => {
    const requesterId = String(msg.from?.id || "");
    if (!requesterId) return;
    if (!isOwner(requesterId)) return;
    if (!msg.text) return;

    const singleKey = pendingPanelEdit[requesterId];
    const field = pendingPanelField[requesterId];
    const isBulk = !!pendingBulkEdit[requesterId];
    if (!singleKey && !isBulk) return;

    if (msg.text === "/batalpanel") {
      delete pendingPanelEdit[requesterId];
      delete pendingPanelField[requesterId];
      delete pendingBulkEdit[requesterId];
      return bot.sendMessage(msg.chat.id, "◇ Ganti panel dibatalin.");
    }
    if (msg.text.startsWith("/")) return; // biarin command lain jalan normal

    // -------- Mode satuan: edit satu field --------
    if (singleKey && field && field !== "all") {
      const current = panelStore.getPanel(singleKey);
      const parsedField = parseSingleField(field, msg.text, current);
      if (!parsedField.ok) {
        return bot.sendMessage(msg.chat.id, `${parsedField.error}\n\nCoba kirim ulang, atau /batalpanel.`);
      }

      const values = {
        domain: current.domain,
        plta: current.plta,
        pltc: current.pltc,
        eggs: current.eggs || "20",
        eggsPython: current.eggsPython || "22",
      };
      values[field] = parsedField.value;
      const updated = panelStore.setPanel(singleKey, values);
      delete pendingPanelEdit[requesterId];
      delete pendingPanelField[requesterId];

      return bot.sendMessage(
        msg.chat.id,
        `◉ <b>${panelStore.labelFor(singleKey)}</b> — ${fieldPrompt(field)} berhasil diupdate.\n\n` +
        `Nilai baru: <code>${field === "plta" || field === "pltc" ? mask(updated[field]) : updated[field]}</code>\n\n` +
        `Gunakan menu edit lagi jika mau mengganti field lainnya.`,
        { parse_mode: "HTML" }
      );
    }

    // -------- Mode satuan: edit semua field --------
    if (singleKey && (field === "all" || !field)) {
      const current = panelStore.getPanel(singleKey);
      const parsed = parseFiveLines(msg.text, current);
      if (!parsed.ok) {
        return bot.sendMessage(msg.chat.id, `${parsed.error}\n\nCoba kirim ulang, atau /batalpanel.`);
      }

      const updated = panelStore.setPanel(singleKey, parsed);
      delete pendingPanelEdit[requesterId];
      delete pendingPanelField[requesterId];

      return bot.sendMessage(
        msg.chat.id,
        `◉ <b>${panelStore.labelFor(singleKey)}</b> berhasil diupdate:\n` +
          `Domain     : <code>${updated.domain}</code>\n` +
          `PLTA       : <code>${mask(updated.plta)}</code>\n` +
          `PLTC       : <code>${mask(updated.pltc)}</code>\n` +
          `Egg Node   : <code>${updated.eggs}</code>\n` +
          `Egg Python : <code>${updated.eggsPython}</code>\n\n` +
          `⚠ Beberapa fitur (misal /status) nge-cache daftar panel pas bot start. ` +
          `✅ Perubahan Egg/Panel sudah disimpan dan langsung dipakai pada proses berikutnya.`,
        { parse_mode: "HTML" }
      );
    }

    // -------- Mode bulk --------
    const selected = [...getSelection(requesterId)];
    if (selected.length === 0) {
      delete pendingBulkEdit[requesterId];
      return bot.sendMessage(msg.chat.id, "◇ Seleksi panel kosong, ulang lagi dari /setpanel.");
    }

    // Buat validasi format pakai panel pertama sebagai acuan "current" (buat cek "-").
    const refCurrent = panelStore.getPanel(selected[0]);
    const parsed = parseFiveLines(msg.text, refCurrent);
    if (!parsed.ok) {
      return bot.sendMessage(msg.chat.id, `${parsed.error}\n\nCoba kirim ulang, atau /batalpanel.`);
    }

    const results = [];
    const lines = msg.text.split("\n").map((l) => l.trim());
    for (const key of selected) {
      const current = panelStore.getPanel(key);
      // "-" per baris ditentukan dari input asli (relatif ke masing2 panel),
      // bukan cuma dari refCurrent, biar tiap panel yang dibiarin ("-") tetap pakai nilai die sendiri.
      const domain     = lines[0] === "-" ? current.domain                  : parsed.domain;
      const plta       = lines[1] === "-" ? current.plta                    : parsed.plta;
      const pltc       = lines[2] === "-" ? current.pltc                    : parsed.pltc;
      const eggs       = lines[3] === "-" ? (current.eggs || "20")          : parsed.eggs;
      const eggsPython = lines[4] === "-" ? (current.eggsPython || "22")    : parsed.eggsPython;
      const updated = panelStore.setPanel(key, { domain, plta, pltc, eggs, eggsPython });
      results.push(`• <b>${panelStore.labelFor(key)}</b>: <code>${updated.domain}</code> | Node: <code>${updated.eggs}</code> | Py: <code>${updated.eggsPython}</code>`);
    }

    delete pendingBulkEdit[requesterId];
    bulkSelection[requesterId] = new Set();

    const updatedSummary =
      `<b>Panel berhasil diperbarui</b>\n` +
      `<b>Total:</b> <code>${results.length}</code>\n\n` +
      `<blockquote expandable>${results.join("\n")}</blockquote>\n\n` +
      `<b>Status perubahan</b>\n` +
      `Perubahan Egg dan Panel sudah disimpan dan akan digunakan pada proses berikutnya.\n` +
      `<b>Catatan:</b> fitur yang menyimpan daftar panel di cache saat bot mulai mungkin memerlukan restart bot untuk membaca konfigurasi terbaru.`;

    return bot.sendMessage(
      msg.chat.id,
      updatedSummary,
      { parse_mode: "HTML" }
    );
  });
};
