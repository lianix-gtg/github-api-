/*
 * Optional Canvas adapter.
 * The bot must not crash at startup when the native `canvas` binary
 * is unavailable (common on Pterodactyl images without canvas build deps).
 * Features that actually need canvas will report a clear error instead.
 */
let canvasMod = null;
let canvasError = null;

try {
  canvasMod = require("canvas");
} catch (err) {
  canvasError = err;
}

function unavailable() {
  const msg =
    "Canvas native module tidak tersedia. " +
    "Fitur gambar yang membutuhkan canvas dinonaktifkan pada environment ini.";
  const err = new Error(msg);
  err.code = "CANVAS_UNAVAILABLE";
  err.cause = canvasError;
  throw err;
}

module.exports = {
  get available() {
    return !!canvasMod;
  },
  get error() {
    return canvasError;
  },
  createCanvas: (...args) => canvasMod ? canvasMod.createCanvas(...args) : unavailable(),
  loadImage: (...args) => canvasMod ? canvasMod.loadImage(...args) : unavailable()
};
