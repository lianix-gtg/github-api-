// src/expiry.js
// Sistem expiry role berdasarkan hari.
// day = 0 → unlimited (tidak ada tanggal kadaluarsa)
// day > 0 → expired setelah N hari dari tanggal add
//
// DB disimpan di db/userExpiry.json sebagai object:
// { "userId::roleKey": { days, addedAt, expiresAt } }
// expiresAt = null artinya unlimited selamanya.

const fs   = require("fs");
const path = require("path");

const EXPIRY_FILE = path.join(__dirname, "../db/userExpiry.json");

function loadDB() {
  try {
    if (!fs.existsSync(EXPIRY_FILE)) return {};
    return JSON.parse(fs.readFileSync(EXPIRY_FILE, "utf8")) || {};
  } catch {
    return {};
  }
}

function saveDB(db) {
  fs.mkdirSync(path.dirname(EXPIRY_FILE), { recursive: true });
  fs.writeFileSync(EXPIRY_FILE, JSON.stringify(db, null, 2));
}

function makeKey(userId, roleKey) {
  return `${userId}::${roleKey}`;
}

// Simpan expiry saat user di-add ke role.
// days = 0 → unlimited (expiresAt = null)
function setExpiry(userId, roleKey, days) {
  const db  = loadDB();
  const key = makeKey(String(userId), roleKey);
  const now = new Date();
  db[key] = {
    days,
    addedAt:   now.toISOString(),
    expiresAt: days > 0
      ? new Date(now.getTime() + days * 86400000).toISOString()
      : null,
  };
  saveDB(db);
}

// Hapus expiry saat user di-del dari role.
function removeExpiry(userId, roleKey) {
  const db  = loadDB();
  const key = makeKey(String(userId), roleKey);
  delete db[key];
  saveDB(db);
}

// Ambil info expiry 1 user+role. Return null kalau tidak ada.
function getExpiry(userId, roleKey) {
  const db = loadDB();
  return db[makeKey(String(userId), roleKey)] || null;
}

// Cek apakah user sudah expired untuk role tertentu.
// Return false jika unlimited atau belum expired.
function isExpired(userId, roleKey) {
  const info = getExpiry(userId, roleKey);
  if (!info || !info.expiresAt) return false;
  return new Date() > new Date(info.expiresAt);
}

// Format sisa hari untuk display di /rolemem
// Return "Unlimited" kalau 0/null, atau "X hari lagi" / "EXPIRED"
function formatExpiry(userId, roleKey) {
  const info = getExpiry(userId, roleKey);
  if (!info) return "Unlimited";
  if (!info.expiresAt) return "Unlimited";
  const now      = Date.now();
  const expires  = new Date(info.expiresAt).getTime();
  const diffMs   = expires - now;
  if (diffMs <= 0) return "⚠ EXPIRED";
  const diffDays = Math.ceil(diffMs / 86400000);
  return `${diffDays} hari lagi`;
}

// Ambil semua expiry records (buat /rolemem list)
function getAllExpiry() {
  return loadDB();
}

// Prune expired users dari role file — panggil ini di startup atau scheduler
// files = array of { file, roleKey } — semua file role yang mau di-clean
function pruneExpiredFromFiles(files, loadJson, saveJson) {
  const db = loadDB();
  for (const { file, roleKey } of files) {
    if (!fs.existsSync(file)) continue;
    let users;
    try { users = loadJson(file); } catch { continue; }
    const before = users.length;
    users = users.filter(uid => !isExpired(uid, roleKey));
    if (users.length !== before) saveJson(file, users);
  }
}

module.exports = {
  setExpiry,
  removeExpiry,
  getExpiry,
  isExpired,
  formatExpiry,
  getAllExpiry,
  pruneExpiredFromFiles,
};
