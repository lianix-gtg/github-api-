/*
 * ============================================================
 * 🏠 MENU /START & UI UTAMA
 * ============================================================
 * Tampilan /start, menu, teks akses terbatas, dan tombol utama berada
 * di file ini. Jika hanya ingin mengubah tampilan, edit bagian UI di sini.
 */
const fs = require("fs");
const fetch = require("node-fetch");
const unzipper = require("unzipper");
const os = require("os");
const { exec } = require("child_process");

const usersFile = "./db/users/users.json";
const adminfile = "./db/users/adminID.json";
const premiumUsersFile = "./db/users/premiumUsers.json";
const ressUsersFile = "./db/users/resellerUsers.json";


const settings = require("../settings.js");
const config = require("../settings.js");
const { checkLimit, isOwner: isLimitOwner } = require("./limit.js");
const { isOwner: isModeOwner } = require("./mode.js");
const { showMainMenu } = require("./menu");
const theme = require("./theme");
const audio = require("./audio");
const channelStore = require("./data/channelStore.js");
const mediaFeatures = require("./mediaFeatures.js");
const extraTools = require("./extraTools.js");
const aiTools = require("./aiTools.js");
const devTools = require("./devTools.js");
const portedPack = require("./portedPack.js");
const megaFeatures = require("./megaFeatures.js");
const runtimeGuard = require("./runtimeGuard.js");
const antikill = require("./antikill.js");

const developer = settings.dev;
const pp = settings.pp;
const ppVid = settings.ppVid;

let ownerUsers = [];
let premiumUsers = [];
let ressUsers = [];
    
let users = [];
let userState = {};
let userUploads = {}
let web2zipSessions = {}
let broadcastState = {}

  if (fs.existsSync(usersFile)) {
    users = JSON.parse(fs.readFileSync(usersFile));
  }

  const total = users.length;

  if (fs.existsSync(adminfile)) {
    ownerUsers = JSON.parse(fs.readFileSync(adminfile));
  }

  if (fs.existsSync(premiumUsersFile)) {
    premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  }
    
  if (fs.existsSync(ressUsersFile)) {
    ressUsers = JSON.parse(fs.readFileSync(ressUsersFile));
  }

const now = new Date();
const waktu = now.toLocaleTimeString("id-ID", { timeZone: "Asia/Jakarta" });

module.exports = (bot) => {
  if (typeof theme.bindMenuBot === "function") theme.bindMenuBot(bot);
  runtimeGuard.install(bot);
  // Media/Game pack dari OURIN MD 3
  mediaFeatures.register(bot, theme);
  extraTools.register(bot);
  aiTools.register(bot);
  devTools.register(bot);
  portedPack.register(bot);
  megaFeatures.register(bot);
module.exports.buildMainMenuPayload = buildMainMenuPayload;
bot.onText(/^\/cek$/, async (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  // khusus grup (bisa di apus)
  if (msg.chat.type === "private") {
    return bot.sendMessage(chatId, "<blockquote expandable>◈ <b>Khusus Grup</b>\nPerintah ini hanya bisa dipakai di dalam grup.</blockquote>", { parse_mode: "HTML" });
  }

  let targetUser = msg.from;
  if (msg.reply_to_message) targetUser = msg.reply_to_message.from;

  const userId = targetUser.id;
  const firstName = targetUser.first_name || "User";

  try {
    await bot.sendMessage(
      userId,
      "⟐ Halo! Silakan mulai bot terlebih dahulu."
    );

    // simpen ke database (opsional) bisa diapus
    let users = JSON.parse(fs.readFileSync(usersFile));
    if (!users.includes(userId)) {
      users.push(userId);
      fs.writeFileSync(usersFile, JSON.stringify(users, null, 2));
    }

    // kirim ke grup
    await bot.sendMessage(
      chatId,
      `◉ [${firstName}](tg://user?id=${userId}) sudah start bot! silahkan create.`,
      { parse_mode: "Markdown", reply_to_message_id: msg.message_id }
    );
  } catch (err) {
    await bot.sendMessage(
      chatId,
      `◇ [${firstName}](tg://user?id=${userId}) belum start bot di private chat. dilarang create!`,
      { parse_mode: "Markdown", reply_to_message_id: msg.message_id }
    );
  }
});
function sanitizeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function asHtmlBlockFromPlain(captionPlain) {
  const safeHtml = sanitizeHtml(captionPlain);
  return `<blockquote expandable><pre>${safeHtml}</pre></blockquote>`;
}

// ============================================================
//  ⟡ #LianiX — PREMIUM UI THEME ⟡
//  Font tebal unicode + expandable blockquote, dengan daftar
//  perintah yang dirapikan memanjang ke samping (grid), bukan
//  ditumpuk satu-satu ke bawah.
// ============================================================

// -- konversi teks ke unicode bold sans (buat judul section) --
function mapAlpha(str, upperBase, lowerBase) {
  return str.replace(/[A-Za-z]/g, (ch) => {
    const code = ch.charCodeAt(0);
    if (code >= 65 && code <= 90) return String.fromCodePoint(upperBase + (code - 65));
    if (code >= 97 && code <= 122) return String.fromCodePoint(lowerBase + (code - 97));
    return ch;
  });
}
function toBoldSans(str) {
  let out = mapAlpha(str, 0x1d5d4, 0x1d5ee); // 𝗕𝗢𝗟𝗗 𝗦𝗔𝗡𝗦
  out = out.replace(/[0-9]/g, (d) => String.fromCodePoint(0x1d7ec + (d.charCodeAt(0) - 48)));
  return out;
}
function toBoldScript(str) {
  return mapAlpha(str, 0x1d4d0, 0x1d4ea); // 𝓑𝓸𝓵𝓭 𝓢𝓬𝓻𝓲𝓹𝓽
}

const UI = { deco: "⟐" };

// Susun daftar item jadi baris-baris memanjang ke samping kanan
// (bukan satu item per baris ke bawah). Baris yang diawali "»"/"△"
// dianggap catatan/format dan selalu berdiri sendiri di barisnya.
const ROW_WIDTH = 34;
function packItemsToRows(items) {
  const rows = [];
  let cur = [];
  let curLen = 0;
  const flush = () => {
    if (cur.length) rows.push(cur.join("   "));
    cur = [];
    curLen = 0;
  };
  for (const raw of items) {
    const it = String(raw);
    if (it.startsWith("»") || it.startsWith("△")) {
      flush();
      rows.push(it);
      continue;
    }
    const addLen = it.length + (cur.length ? 3 : 0);
    if (cur.length && curLen + addLen > ROW_WIDTH) flush();
    cur.push(it);
    curLen += addLen;
  }
  flush();
  return rows;
}

// Satu blok menu premium: judul font tebal + isi dibungkus quote
// "expandable" (defaultnya keliatan setengah/collapsed, tinggal
// di-tap buat buka penuh), item-itemnya dirapikan ke samping kanan.
function premiumSection(icon, title, items) {
  const rows = packItemsToRows(items);
  const body = rows.map((row, i) => (i === rows.length - 1 ? `╰ ${row}` : `├ ${row}`)).join("\n");
  return `${UI.deco} ${icon}  <b>${toBoldSans(title)}</b>  ${UI.deco}\n<blockquote expandable>${body}</blockquote>`;
}

function premiumPage(...sections) {
  return sections.join("\n\n");
}

// Kartu identitas premium (dipakai di /start & tombol "buka menu")
function identityCard({ username, status, timeLabel, timeValue, footer }) {
  const statusIcon =
    status === "Owner"    ? "⌖" :
    status === "Premium"  ? "◈" :
    status === "Reseller" ? "◆" : "⌀";

  return (
    `${UI.deco} ${toBoldScript("#LianiX")} ${UI.deco}\n\n` +
    `<blockquote expandable>` +
    `${toBoldScript("Member")}  : ${username}\n` +
    `${toBoldScript("Rank")}    : ${statusIcon} ${toBoldSans(status)}\n` +
    `${toBoldScript(timeLabel)}  : ${timeValue}` +
    `</blockquote>\n\n` +
    `→ ${footer}`
  );
}


// ============================================================
//  MAIN MENU BUILDER — dipakai bareng oleh /start & tombol "back"
//  biar tampilannya konsisten dan ikut tema warna yang lagi aktif.
//  Grid: Create Panel + Install Menu (2 kolom), CVPS Menu + Protect Menu +
//  Tools Menu (3 kolom), Owner Menu + Group Menu (2 kolom), Code Redeem &
//  Buy Script lebar penuh. Ikonnya simbol polos, bukan emoji.
// ============================================================
function buildMainMenuPayload(userId, usernameDisplay) {
  const t = theme.getTheme();

  const vpsUptime = os.uptime();
  const vpsUptimeStr = `${Math.floor(vpsUptime / 86400)}d ${Math.floor((vpsUptime % 86400) / 3600)}h ${Math.floor((vpsUptime % 3600) / 60)}m`;

  const botUptime = process.uptime();
  const botUptimeStr = `${Math.floor(botUptime / 86400)}d ${Math.floor((botUptime % 86400) / 3600)}h ${Math.floor((botUptime % 3600) / 60)}m`;

  const uidStr = userId.toString();
  const status = ownerUsers.includes(uidStr)
    ? "OWNER"
    : premiumUsers.includes(uidStr)
    ? "PREMIUM"
    : ressUsers?.includes(uidStr)
    ? "ILEGAL RESS"
    : "USER";

  const { getUserRoleExtended: _gre, ROLE_DISPLAY_LABELS: _rdl } = require('./limit.js');
  const _rk = _gre(uidStr);
  const statusFull = _rdl[_rk] || status;

  const text =
    `<blockquote expandable>` +
    `<b>𝙸𝙽𝙵𝙾 𝚄𝚂𝙴𝚁</b>\n` +
    `⪼ <b>Username :</b> ${usernameDisplay}\n` +
    `⪼ <b>ID :</b> <code>${uidStr}</code>\n` +
    `⪼ <b>Role :</b> ${statusFull}` +
    `</blockquote>\n\n` +
    `<blockquote expandable>` +
    `<b>𝙸𝙽𝙵𝙾 𝙱𝙾𝚃</b>\n` +
    `⪼ <b>Name Bot :</b> Lianix Asisten\n` +
    `⪼ <b>Version Bot :</b> 6.1 Premium\n` +
    `⪼ <b>Runtime Bot :</b> ${botUptimeStr}` +
    `</blockquote>\n\n` +
    `<blockquote expandable>` +
    `<b>𝚂ＰＥ𝙲𝙸𝙰𝙻 𝙼𝙴𝙽𝚄</b>\n` +
    `⪼ <b>/info</b> - Cek info user\n` +
    `⪼ <b>/cekserver</b> - Cek server on\n` +
    `⪼ <b>/cekid</b> - Cek ID\n` +
    `⪼ <b>/totalserver</b> - Total server\n` +
    `⪼ <b>/servercpu</b> - Cek CPU server\n` +
    `⪼ <b>/backup</b> - Backup file\n` +
    `⪼ <b>/unli namaserver</b> - Create Panel\n` +
    `⪼ <b>/installpanel</b> - Panduan & Install Panel\n` +
    `⪼ <b>/cvps</b> - Create VPS\n` +
    `⪼ <b>/enc</b> - Encryption` +
    `</blockquote>\n\n` +
    `<blockquote><b>LIANIX CPANEL</b></blockquote>`;

  const btn = (text, cb) => theme.styled({ text, callback_data: cb }, t);
  const uBtn = (text, url) => theme.styled({ text, url }, t);

  const rows = [
    [ btn("Create Panel", "createpanel"), btn("Install Panel", "installmenu") ],
    [ btn("WhatsApp Panel", "cpanelwa"), btn("VPS / CVPS", "cvpsmenu") ],
    [ btn("Tools Center", "toolsmenu") ],
    [ btn("Protection", "protectmenu"), btn("Encryption", "encryptmenu") ],
    [ btn("Group Tools", "groupmenu"), btn("Special Features", "cekfitur") ],
    [ btn("Code Redeem", "coderedeem"), btn("Owner Center", "ownermenu") ],
    ...(settings.isOwner && settings.isOwner(userId) ? [[ btn("DevPanel", "devpanel") ]] : []),
  ];
  // My Panel hanya muncul bila minimal satu konfigurasi panel benar-benar terhubung.
  try {
    const ps = require('./data/panelStore.js');
    if (ps.PANEL_KEYS.some(k => { const x = ps.getPanel(k); return x?.domain && x?.plta; })) {
      rows.splice(2, 0, [btn("My Panel", "mypanel")]);
    }
  } catch {}

  rows.push([ btn("Chat Owner", "relay_start") ]);

  rows.push([ uBtn("Buy Script", settings.buyScriptUrl) ]);
  rows.push([ btn("‹‹‹", "dashboard_back_start") ]);

  return { text, reply_markup: { inline_keyboard: rows } };
}

function buildStartReturnPayload(userId, fromUser) {
  const uid = String(userId);
  const usernameDisplay = `@${fromUser?.username || fromUser?.first_name || "User"}`;
  const botUptime = process.uptime();
  const botUptimeStr = `${Math.floor(botUptime / 86400)} hari ${Math.floor((botUptime % 86400) / 3600)} jam ${Math.floor((botUptime % 3600) / 60)} menit`;
  const { getUserRoleExtended, ROLE_DISPLAY_LABELS } = require('./limit.js');
  const roleBadge = ROLE_DISPLAY_LABELS[getUserRoleExtended(uid)] || 'USER';

  const text =
    `<blockquote expandable>` +
    `<b>𝙸𝙽𝙵𝙾 𝚄𝚂𝙴𝚁</b>⪼ <b>Username :</b> ${sanitizeHtml(usernameDisplay)}\n` +
    `⪼ <b>ID :</b> <code>${sanitizeHtml(uid)}</code>\n` +
    `⪼ <b>Role :</b> ${sanitizeHtml(roleBadge)}` +
    `</blockquote>\n\n` +
    `<blockquote expandable>` +
    `<b>𝙸𝙽𝙵𝙾 𝙱𝙾𝚃</b>\n` +
    `⪼ <b>Name Bot :</b> Lianix Asisten\n` +
    `⪼ <b>Version Bot :</b> 6.1 Premium\n` +
    `⪼ <b>Runtime Bot :</b> ${botUptimeStr}` +
    `</blockquote>\n\n` +
    `<blockquote expandable>` +
    `<b>𝚂ＰＥ𝙲𝙸𝙰𝙻 𝙼𝙴𝙽𝚄</b>\n` +
    `⪼ <b>/info</b> - Cek info user\n` +
    `⪼ <b>/cekserver</b> - Cek server on\n` +
    `⪼ <b>/cekid</b> - Cek ID\n` +
    `⪼ <b>/totalserver</b> - total server\n` +
    `⪼ <b>/servercpu</b> - Cek cpu server\n` +
    `⪼ <b>/backup</b> - Backup File` +
    `</blockquote>\n\n` +
    `<blockquote><b>LIANIX CPANEL</b></blockquote>`;

  const reply_markup = {
    inline_keyboard: [
      [
        { text: "Buy Script", url: settings.buyScriptUrl },
        { text: "Developer", url: `https://t.me/${String(settings.dev).replace(/^@/, "")}` },
      ],
      [{ text: "Open Dashboard", callback_data: "open_dashboard" }],
    ],
  };
  return { text, reply_markup };
}

async function restoreStartFromDashboard(callbackQuery) {
  const msg = callbackQuery?.message;
  if (!msg) return;
  const chatId = msg.chat.id;
  const user = callbackQuery.from || {};
  const payload = buildStartReturnPayload(user.id, user);
  const opts = { chat_id: chatId, message_id: msg.message_id, parse_mode: "HTML", reply_markup: payload.reply_markup };
  // Jika sumbernya foto, prioritaskan caption. Ini menghindari editMessageText
  // 400 pada media dan tidak bergantung pada fallback wrapper.
  if (msg.photo || msg.caption !== undefined) {
    try {
      const result = await bot.editMessageCaption(payload.text, opts);
      if (!(result == null || result?.ok === false || result?.skipped === true)) return;
    } catch {}
  } else {
    try {
      const result = await bot.editMessageText(payload.text, opts);
      if (!(result == null || result?.ok === false || result?.skipped === true)) return;
    } catch {}
  }

  // Fallback silang: berguna jika metadata media dari Telegram tidak lengkap.
  try {
    const result = await bot.editMessageText(payload.text, opts);
    if (!(result == null || result?.ok === false || result?.skipped === true)) return;
  } catch {}
  try {
    const result = await bot.editMessageCaption(payload.text, opts);
    if (!(result == null || result?.ok === false || result?.skipped === true)) return;
  } catch {}
  await bot.sendMessage(chatId, payload.text, { parse_mode: "HTML", reply_markup: payload.reply_markup }).catch(() => {});
}

async function enterMainMenuAfterStart(msg) {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const firstName = msg.from.first_name || "User";

  // START loading: satu pesan progress, lalu dihapus tepat sebelum hasil intro.
  // Ini hanya untuk /start agar chat tidak dipenuhi pesan progress.
  let startLoading = null;
  const renderStartLoader = async (pct, label) => {
    const filled = Math.max(0, Math.min(10, Math.round(pct / 10)));
    const text = `<b>${label}</b>\n\n<code>[${"█".repeat(filled)}${"░".repeat(10-filled)}] ${pct}%</code>`;
    if (startLoading?.message_id) {
      try {
        await bot.editMessageText(text, { chat_id: chatId, message_id: startLoading.message_id, parse_mode: "HTML" });
        return true;
      } catch (e) {
        const d = String(e?.response?.body?.description || e?.message || "");
        if (/message is not modified/i.test(d)) return true;
      }
    }
    // Kalau edit loader lama gagal, buat loader baru. Hasil /start tetap belum boleh dikirim.
    try {
      startLoading = await bot.sendMessage(chatId, text, { parse_mode: "HTML" });
      return true;
    } catch (e) {
      console.error("[start] loader gagal ditampilkan:", e?.message || e);
      return false;
    }
  };

  // Animasi /start memang sengaja dibuat santai untuk mempercantik transisi.
  // Hasil utama tidak boleh muncul sebelum progress benar-benar 100%.
  await renderStartLoader(0, "sebentar ya bre");
  const stages = [
    [10, "sebentar ya bre"],
    [20, "sebentar ya bre"],
    [30, "lagi mau masuk server ni"],
    [40, "lagi mau masuk server ni"],
    [50, "lagi mau masuk server ni"],
    [60, "wops dikit lagi bre"],
    [70, "wops dikit lagi bre"],
    [80, "wops dikit lagi bre"],
    [90, "anjay masuk bre"]
  ];
  for (const [pct, label] of stages) {
    await new Promise(r => setTimeout(r, 520));
    await renderStartLoader(pct, label);
  }
  // 100% sengaja BELUM ditampilkan. Persiapan lokal di bawah harus selesai dulu.

  // Simpan/registrasi user ke database (dipakai untuk fitur broadcast dkk)
  try {
    let usersDb = fs.existsSync(usersFile) ? JSON.parse(fs.readFileSync(usersFile)) : [];
    const idStr = String(userId);
    if (!usersDb.map(String).includes(idStr)) {
      usersDb.push(userId);
      fs.writeFileSync(usersFile, JSON.stringify(usersDb, null, 2));
    }
  } catch (e) {
    console.error("[start] Gagal simpan user ke users.json:", e.message);
  }

  const usernameDisplay = `@${msg.from.username || firstName}`;

  // Kartu intro sederhana pas /start (bukan langsung nampilin menu penuh).
  // Menu penuh baru kebuka pas user pencet tombol "Buka Menu".
  const botUptime = process.uptime();
  const botUptimeStr = `${Math.floor(botUptime / 86400)} hari ${Math.floor((botUptime % 86400) / 3600)} jam ${Math.floor((botUptime % 3600) / 60)} menit`;

  const vpsUptime = os.uptime();
  const vpsUptimeStr = `${Math.floor(vpsUptime / 86400)} hari ${Math.floor((vpsUptime % 86400) / 3600)} jam ${Math.floor((vpsUptime % 3600) / 60)} menit`;

  const totalMemGb = (os.totalmem() / (1024 ** 3)).toFixed(2);
  const cpuCores = os.cpus().length;

  const { getUserRoleExtended, ROLE_DISPLAY_LABELS } = require('./limit.js');
  const roleKey   = getUserRoleExtended(userId);
  const roleBadge = ROLE_DISPLAY_LABELS[roleKey] || 'USER';

  const introText =
    `<blockquote expandable>` +
    `<b>𝙸𝙽𝙵𝙾 𝚄𝚂𝙴𝚁</b>\n` +
    `⪼ <b>Username :</b> ${usernameDisplay}\n` +
    `⪼ <b>ID :</b> <code>${userId}</code>\n` +
    `⪼ <b>Role :</b> ${roleBadge}` +
    `</blockquote>\n\n` +
    `<blockquote expandable>` +
    `<b>𝙸𝙽𝙵𝙾 𝙱𝙾𝚃</b>\n` +
    `⪼ <b>Name Bot :</b> Lianix Asisten\n` +
    `⪼ <b>Version Bot :</b> 6.1 Premium\n` +
    `⪼ <b>Runtime Bot :</b> ${botUptimeStr}` +
    `</blockquote>\n\n` +
    `<blockquote expandable>` +
    `<b>𝚂ＰＥ𝙲𝙸𝙰𝙻 𝙼𝙴𝙽𝚄</b>\n` +
    `⪼ <b>/info</b> - Cek info user\n` +
    `⪼ <b>/cekserver</b> - Cek server on\n` +
    `⪼ <b>/cekid</b> - Cek ID\n` +
    `⪼ <b>/totalserver</b> - Total server\n` +
    `⪼ <b>/servercpu</b> - Cek CPU server\n` +
    `⪼ <b>/backup</b> - Backup file` +
    `</blockquote>\n\n` +
    `<blockquote><b>LIANIX CPANEL</b></blockquote>`;

  const startKeyboard = {
    inline_keyboard: [
      [
        { text: "Buy Script", url: settings.buyScriptUrl },
        { text: "Developer", url: `https://t.me/${settings.dev}` },
      ],
      [{ text: "Open Dashboard", callback_data: "open_dashboard" }],
    ],
  };

  // Semua data untuk /start sudah disiapkan. Hasil TIDAK dikirim sebelum progress 100%.
  const ppValid = pp && (
    /^https?:\/\/.+/i.test(String(pp)) ||
    /^[A-Za-z0-9_\-]{10,}$/.test(String(pp))
  );

  const sendIntro = async () => {
    if (ppValid) {
      try {
        await bot.sendPhoto(chatId, pp, {
          caption: introText,
          parse_mode: "HTML",
          reply_to_message_id: msg.message_id,
          reply_markup: startKeyboard,
        });
      } catch (photoErr) {
        await bot.sendMessage(chatId, introText, {
          parse_mode: "HTML",
          reply_to_message_id: msg.message_id,
          reply_markup: startKeyboard,
        }).catch(() => {});
      }
    } else {
      await bot.sendMessage(chatId, introText, {
        parse_mode: "HTML",
        reply_to_message_id: msg.message_id,
        reply_markup: startKeyboard,
      });
    }

    const audioUrl = audio.getAudioUrl();
    if (audioUrl) {
      const sendAudioOnce = () =>
        bot.sendAudio(chatId, audioUrl, {
          caption: "♪ Welcome to #LianiX",
          title: "velquira.mp3",
          performer: "#LianiX",
        });

      try {
        await sendAudioOnce();
      } catch (e) {
        console.error("[start] Gagal kirim audio intro:", e.message);
        // Audio gagal tidak boleh membatalkan hasil /start yang sudah siap.
      }
    }
  };

  // Semua persiapan lokal sudah selesai. Baru sekarang loader boleh mencapai 100%.
  await renderStartLoader(100, "anjay masuk bre");
  // Biar 100% benar-benar terlihat sebelum intro/menu muncul.
  await new Promise(r => setTimeout(r, 1200));
  // Beri kesempatan update 100% benar-benar terlihat sebelum loader dihapus.
  await new Promise(r => setTimeout(r, 900));

  // Pastikan progress selesai dan pesan loader hilang SEBELUM intro/menu dikirim.
  if (startLoading?.message_id) {
    // Loader sudah mencapai 100% di atas. Hapus dulu, BARU hasil /start boleh muncul.
    await bot.deleteMessage(chatId, startLoading.message_id).catch(() => {});
  }

  await sendIntro();

  // Tombol "Buka Menu" pakai callback_data "back", yang render menu utama
  // lewat buildMainMenuPayload -- jadi belum perlu register ke theme registry
  // di sini (baru diregister pas menu utama beneran kebuka).
}

// /start dibuat mandiri dan tidak bergantung pada getChat()/sendPhoto().
// Kalau foto intro gagal, user tetap mendapat balasan teks. Ini mencegah
// kondisi "/start tidak muncul apa-apa" hanya karena media/Telegram API gagal.
bot.onText(/^\/start(?:@[^\s]+)?(?:\s+.*)?$/i, async (msg) => {
  const chatId = msg?.chat?.id;
  const userId = msg?.from?.id;
  const firstName = msg?.from?.first_name || "User";
  if (!chatId || !userId) return;

  try {
    await enterMainMenuAfterStart(msg);
  } catch (err) {
    console.error("[start] Handler /start gagal:", err?.stack || err?.message || err);
    try {
      await bot.sendMessage(
        chatId,
        `<blockquote expandable>◇ <b>LIANIX CPANEL</b>\nHalo ${sanitizeHtml(firstName)}. Menu utama gagal dimuat, tapi bot masih aktif. Silakan kirim /start lagi.</blockquote>`,
        { parse_mode: "HTML" }
      );
    } catch (fallbackErr) {
      console.error("[start] Fallback /start juga gagal:", fallbackErr?.message || fallbackErr);
    }
  }
});


// ============================================================
//  FIX: "tiap pencet tombol langsung balik ke menu utama"
//  Penyebabnya: theme.js nyimpen pesan menu utama di registry buat
//  di-refresh otomatis pas Auto Cycle tema nyala (Dev Panel). Tapi
//  registry itu gak pernah dihapus pas user pindah ke submenu
//  (Owner Menu, Install Menu, Tools Menu, Profile, dll), jadi begitu
//  Auto Cycle jalan (atau developer lagi nyalain), pesan yang lagi
//  nampilin submenu ke-timpa balik jadi tampilan menu utama lagi.
//  Fix-nya: begitu ada tombol APAPUN yang dipencet SELAIN "back",
//  langsung unregister dulu dari registry, biar Auto Cycle gak nimpa
//  submenu yang lagi kebuka. Nanti pas user pencet "back", handler
//  "back" bakal register ulang otomatis (lihat bawah).
bot.on("callback_query", (callbackQuery) => {
  if (!callbackQuery.message) return;
  if (callbackQuery.data === "back") return;
  theme.unregisterMenuMessage(callbackQuery.message.chat.id);
});

bot.on("callback_query", async (callbackQuery) => {
  if (callbackQuery.data !== "mypanel") return;
  try {
    await bot.answerCallbackQuery(callbackQuery.id);
    const ownerFeatures = require("./ownerFeatures.js");
    await ownerFeatures.__mypanel?.(bot, { from: callbackQuery.from, chat: callbackQuery.message.chat, message_id: callbackQuery.message.message_id });
  } catch (e) {
    try { await bot.sendMessage(callbackQuery.message.chat.id, `<blockquote expandable><b>PANEL SAYA</b>\\n\\nGagal membuka data panel.</blockquote>`, {parse_mode:"HTML"}); } catch {}
  }
});
bot.on("callback_query", (callbackQuery) => {
  if (callbackQuery.data === "cpanelwa") {
    bot.answerCallbackQuery(callbackQuery.id);
     const text = premiumPage(
       premiumSection("◆", "RESELLER MENU", [
         "/1gbwa",
         "/2gbwa",
         "/3gbwa",
         "/4gbwa",
         "/5gbwa",
         "/6gbwa",
         "/7gbwa",
         "/8gbwa",
         "/9gbwa",
         "/10gbwa",
         "/unliwa",
         "/cadpwa",
         "» Format: nama,nomor",
       ])
     );
 bot.editMessageCaption(text, {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
        [
          { text: `${toBoldSans("Server 2")}`, callback_data: "serverduawa" },
          { text: `${toBoldSans("Server 3")}`, callback_data: "servertigawa" },
          { text: `${toBoldSans("Server 4")}`, callback_data: "serverempatwa" }
        ],
        [
          { text: `${toBoldSans("Server 5")}`, callback_data: "serverlimawa" }, 
          { text: `${toBoldSans("Server 6")}`, callback_data: "serverenamwa" }, 
          { text: `${toBoldSans("Server 7")}`, callback_data: "servertujuwa" }
        ],
        [
            { text: `${toBoldSans("‹‹‹")}`, callback_data: "back" },
        ]
      ],
      },
    });
  }
});
bot.on("callback_query", (callbackQuery) => {
  if (callbackQuery.data === "serverduawa") {

    const userId = callbackQuery.from.id.toString();
    const isResellerV2 = JSON.parse(fs.readFileSync("./db/users/version/resellerV2.json"));

    if (!isResellerV2.includes(userId)) {
      return bot.answerCallbackQuery(callbackQuery.id, { text: "◇ Kamu tidak mempunyai akses server 2", show_alert: true });
    }

    bot.answerCallbackQuery(callbackQuery.id);
    const text = premiumPage(
      premiumSection("◆", "RESELLER V2 MENU", [
        "/1gbwav2",
        "/2gbwav2",
        "/3gbwav2",
        "/4gbwav2",
        "/5gbwav2",
        "/6gbwav2",
        "/7gbwav2",
        "/8gbwav2",
        "/9gbwav2",
        "/10gbwav2",
        "/unliwav2",
        "/cadpwav2",
        "» Format: nama,nomor",
      ])
    );

    bot.editMessageCaption(text, {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: `${toBoldSans("‹‹‹")}`, callback_data: "cpanelwa" }]
        ]
      },
    });
  }
});
bot.on("callback_query", (callbackQuery) => {
  if (callbackQuery.data === "servertigawa") {

    const userId = callbackQuery.from.id.toString();
    const isResellerV3 = JSON.parse(fs.readFileSync("./db/users/version/resellerV3.json"));

    if (!isResellerV3.includes(userId)) {
      return bot.answerCallbackQuery(callbackQuery.id, { text: "◇ Kamu tidak mempunyai akses server 3", show_alert: true });
    }

    bot.answerCallbackQuery(callbackQuery.id);
    const text = premiumPage(
      premiumSection("◆", "RESELLER V3 MENU", [
        "/1gbwav3",
        "/2gbwav3",
        "/3gbwav3",
        "/4gbwav3",
        "/5gbwav3",
        "/6gbwav3",
        "/7gbwav3",
        "/8gbwav3",
        "/9gbwav3",
        "/10gbwav3",
        "/unliwav3",
        "/cadpwav3",
        "» Format: nama,nomor",
      ])
    );

    bot.editMessageCaption(text, {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: `${toBoldSans("‹‹‹")}`, callback_data: "cpanelwa" }]
        ]
      },
    });
  }
});
bot.on("callback_query", (callbackQuery) => {
  if (callbackQuery.data === "serverempatwa") {

    const userId = callbackQuery.from.id.toString();
    const isResellerV4 = JSON.parse(fs.readFileSync("./db/users/version/resellerV4.json"));

    if (!isResellerV4.includes(userId)) {
      return bot.answerCallbackQuery(callbackQuery.id, { text: "◇ Kamu tidak mempunyai akses server 4", show_alert: true });
    }

    bot.answerCallbackQuery(callbackQuery.id);
    const text = premiumPage(
      premiumSection("◆", "RESELLER V4 MENU", [
        "/1gbwav4",
        "/2gbwav4",
        "/3gbwav4",
        "/4gbwav4",
        "/5gbwav4",
        "/6gbwav4",
        "/7gbwav4",
        "/8gbwav4",
        "/9gbwav4",
        "/10gbwav4",
        "/unliwav4",
        "/cadpwav4",
        "» Format: nama,nomor",
      ])
    );

    bot.editMessageCaption(text, {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: `${toBoldSans("‹‹‹")}`, callback_data: "cpanelwa" }]
        ]
      },
    });
  }
});
bot.on("callback_query", (callbackQuery) => {
  if (callbackQuery.data === "serverlimawa") {

    const userId = callbackQuery.from.id.toString();
    const isResellerV5 = JSON.parse(fs.readFileSync("./db/users/version/resellerV5.json"));

    if (!isResellerV5.includes(userId)) {
      return bot.answerCallbackQuery(callbackQuery.id, { text: "◇ Kamu tidak mempunyai akses server 5", show_alert: true });
    }

    bot.answerCallbackQuery(callbackQuery.id);
    const text = premiumPage(
      premiumSection("◆", "RESELLER V5 MENU", [
        "/1gbwav5",
        "/2gbwav5",
        "/3gbwav5",
        "/4gbwav5",
        "/5gbwav5",
        "/6gbwav5",
        "/7gbwav5",
        "/8gbwav5",
        "/9gbwav5",
        "/10gbwav5",
        "/unliwav5",
        "/cadpwav5",
        "» Format: nama,nomor",
      ])
    );

    bot.editMessageCaption(text, {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: `${toBoldSans("‹‹‹")}`, callback_data: "cpanelwa" }]
        ]
      },
    });
  }
});
bot.on("callback_query", (callbackQuery) => {
  if (callbackQuery.data === "serverenamwa") {

    const userId = callbackQuery.from.id.toString();
    const isResellerV6 = JSON.parse(fs.readFileSync("./db/users/version/resellerV6.json"));

    if (!isResellerV6.includes(userId)) {
      return bot.answerCallbackQuery(callbackQuery.id, { text: "◇ Kamu tidak mempunyai akses server 6", show_alert: true });
    }

    bot.answerCallbackQuery(callbackQuery.id);
    const text = premiumPage(
      premiumSection("◆", "RESELLER V6 MENU", [
        "/1gbwav6",
        "/2gbwav6",
        "/3gbwav6",
        "/4gbwav6",
        "/5gbwav6",
        "/6gbwav6",
        "/7gbwav6",
        "/8gbwav6",
        "/9gbwav6",
        "/10gbwav6",
        "/unliwav6",
        "/cadpwav6",
        "» Format: nama,nomor",
      ])
    );

    bot.editMessageCaption(text, {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: `${toBoldSans("‹‹‹")}`, callback_data: "cpanelwa" }]
        ]
      },
    });
  }
});
bot.on("callback_query", (callbackQuery) => {
  if (callbackQuery.data === "servertujuwa") {

    const userId = callbackQuery.from.id.toString();
    const isResellerV7 = JSON.parse(fs.readFileSync("./db/users/version/resellerV7.json"));

    if (!isResellerV7.includes(userId)) {
      return bot.answerCallbackQuery(callbackQuery.id, { text: "◇ Kamu tidak mempunyai akses server 7", show_alert: true });
    }

    bot.answerCallbackQuery(callbackQuery.id);
    const text = premiumPage(
      premiumSection("◆", "RESELLER V7 MENU", [
        "/1gbwav7",
        "/2gbwav7",
        "/3gbwav7",
        "/4gbwav7",
        "/5gbwav7",
        "/6gbwav7",
        "/7gbwav7",
        "/8gbwav7",
        "/9gbwav7",
        "/10gbwav7",
        "/unliwav7",
        "/cadpwav7",
        "» Format: nama,nomor",
      ])
    );

    bot.editMessageCaption(text, {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: `${toBoldSans("‹‹‹")}`, callback_data: "cpanelwa" }]
        ]
      },
    });
  }
});
    
// ============================================================
//  PANEL MENU (gaya list [ SECTION ] + navigasi 3 halaman)
//  Dipicu tombol "Panel Menu"/"Reseller Panel" (callback: createpanel)
// ============================================================
function panelMenuPage1Text() {
  return `<b>╭━━〔 CREATE PANEL 〕━━╮</b>
` +
`<i>Page 01 / 03 • Server & Management</i>

` +
`<blockquote expandable>` +
`▣ <b>CREATE SERVER</b>
` +
`├ /1gb - /10gb   <i>V1</i>
` +
`├ /1gbv2 - /10gbv2   <i>V2</i>
` +
`├ /1gbv3 - /10gbv3   <i>V3</i>
` +
`├ /1gbv4 - /10gbv4   <i>V4</i>
` +
`├ /1gbv5 - /10gbv5   <i>V5</i>
` +
`╰ /unli [username]` +
`</blockquote>

` +
`<blockquote expandable>` +
`◈ <b>CREATE ADMIN</b>
` +
`├ /cadp [username]
` +
`├ Server otomatis mengikuti kuota
` +
`╰ Legal ADP / OWN / CEO tersedia sesuai akses` +
`</blockquote>

` +
`<blockquote expandable>` +
`⌕ <b>SEARCH & LIST</b>
` +
`├ /searchuser - /searchuserv5
` +
`├ /listegg
` +
`├ /listsrv - /listsrvv5
` +
`├ /listuser - /listuserv5
` +
`╰ /listadp - /listadpv5` +
`</blockquote>`;
}

function panelMenuPage2Text() {
  return `<b>╭━━〔 PANEL CONTROL 〕━━╮</b>
` +
`<i>Page 02 / 03 • Monitor, Protect & Tools</i>

` +
`<blockquote expandable>` +
`◉ <b>MONITORING</b>
` +
`├ /monitoringram ip,pw
` +
`├ /monitoringramstop ip,pw
` +
`╰ /monitoringramlist` +
`</blockquote>

` +
`<blockquote expandable>` +
`⚙ <b>KILLPANEL & PROTECTION</b>
` +
`├ /mkillpanel ip,pw
` +
`├ /mkillpanellist
` +
`├ /mkillpanelstop ip,pw
` +
`├ /leozyp IP USER PORT
` +
`├ /statusleozyp
` +
`├ /repairleozyp
` +
`├ /rollbackleozyp
` +
`╰ /unleozyp` +
`</blockquote>

` +
`<blockquote expandable>` +
`◇ <b>PANEL TOOLS</b>
` +
`├ /suspend ID/#username
` +
`├ /unsuspend ID/#username
` +
`├ /cekapikey
` +
`├ /backup
` +
`╰ /restore` +
`</blockquote>`;
}

function panelMenuPage3Text(usersTotal) {
  return `<b>╭━━〔 ADVANCED PANEL 〕━━╮</b>
` +
`<i>Page 03 / 03 • Resource & Access</i>
` +
`${usersTotal ? `
<code>◉ ${usersTotal} users registered</code>
` : ""}
` +
`<blockquote expandable>` +
`⌫ <b>DELETE</b>
` +
`├ /delusr - /delusrv5
` +
`├ /deladp - /deladpv5
` +
`├ /delsrv - /delsrvv5
` +
`╰ /delsrvoff - /delsrvoffv5` +
`</blockquote>

` +
`<blockquote expandable>` +
`▤ <b>MASS DELETE</b>
` +
`├ /dellallsrv - /delallsrvv5
` +
`├ /dellalluser - /delalluserv5
` +
`╰ /dellalladp - /delalladpv5` +
`</blockquote>

` +
`<blockquote expandable>` +
`◒ <b>RESOURCE MONITOR</b>
` +
`├ CPU  : /autocpuonv5 / /autocpuoffv5
` +
`├ RAM  : /autoramonv5 / /autoramoffv5
` +
`├ DISK : /autodiskonv5 / /autodiskoffv5
` +
`╰ LIMIT: /setcpulimit • /setramlimit • /setdisklimit` +
`</blockquote>

` +
`<blockquote expandable>` +
`⊞ <b>CREATE LIMIT</b>
` +
`├ /slimitcprv1 - /slimitcprv5
` +
`╰ /unlimitcprv1 - /unlimitcprv5` +
`</blockquote>`;
}

function panelMenuAllText(usersTotal = "") {
  return `<blockquote expandable><b>CREATE PANEL</b>⪼ Server & Management</blockquote>
` +
    `<blockquote expandable><b>CREATE SERVER</b>
├ /1gb - /10gb V1
├ /1gbv2 - /10gbv2 V2
├ /1gbv3 - /10gbv3 V3
├ /1gbv4 - /10gbv4 V4
├ /1gbv5 - /10gbv5 V5
╰ /unli [username]</blockquote>
` +
    `<blockquote expandable><b>CREATE ADMIN</b>
├ /cadp [username]
├ Server otomatis mengikuti kuota
╰ Legal ADP / OWN / CEO sesuai akses</blockquote>
` +
    `<blockquote expandable><b>SEARCH & LIST</b>
├ /searchuser - /searchuserv5
├ /listegg
├ /listsrv - /listsrvv5
├ /listuser - /listuserv5
╰ /listadp - /listadpv5</blockquote>
` +
    `<blockquote expandable><b>PANEL CONTROL</b>⪼ Page 02 / 03 • Monitor, Protect & Tools

<b>MONITORING</b>
├ /monitoringram ip,pw
├ /monitoringramstop ip,pw
╰ /monitoringramlist

<b>KILLPANEL & PROTECTION</b>
├ /mkillpanel ip,pw
├ /mkillpanellist
├ /mkillpanelstop ip,pw
├ /leozyp IP USER PORT
├ /statusleozyp
├ /repairleozyp
├ /rollbackleozyp
╰ /unleozyp

<b>PANEL TOOLS</b>
├ /suspend ID/#username
├ /unsuspend ID/#username
├ /cekapikey
├ /backup
╰ /restore</blockquote>
` +
    `<blockquote expandable><b>ADVANCED PANEL</b>⪼ Page 03 / 03 • Resource & Access${usersTotal ? `

Registered users: <b>${usersTotal}</b>` : ""}

<b>DELETE</b>
├ /delusr - /delusrv5
├ /deladp - /deladpv5
├ /delsrv - /delsrvv5
╰ /delsrvoff - /delsrvoffv5

<b>MASS DELETE</b>
├ /dellallsrv - /delallsrvv5
├ /dellalluser - /delalluserv5
╰ /dellalladp - /delalladpv5

<b>MODERATION</b>
/warn • /kick • /ban • /mute • /promote • /demote • /pin

<b>RESOURCE MONITOR</b>
├ /autocpuonv5 / /autocpuoffv5
├ /autoramonv5 / /autoramoffv5
├ /autodiskonv5 / /autodiskoffv5
╰ /setcpulimit • /setramlimit • /setdisklimit</blockquote>
` +
    `<blockquote><b>LIANIX CPANEL</b></blockquote>`;
}

function panelMenuKeyboard() {
  const t = theme.getTheme();
  return { inline_keyboard: [
    [
      { text: `${toBoldSans("Server 2")}`, callback_data: "serverdua" },
      { text: `${toBoldSans("Server 3")}`, callback_data: "servertiga" },
      { text: `${toBoldSans("Server 4")}`, callback_data: "serverempat" },
    ],
    [
      { text: `${toBoldSans("Server 5")}`, callback_data: "serverlima" },
      { text: `${toBoldSans("Server 6")}`, callback_data: "serverenam" },
      { text: `${toBoldSans("Server 7")}`, callback_data: "servertuju" },
    ],
    [theme.styled({ text: toBoldSans("‹‹‹"), callback_data: "back" }, t)]
  ] };
}

bot.on("callback_query", async (callbackQuery) => {
  if (!["createpanel", "panelmenu1", "panelmenu2", "panelmenu3"].includes(callbackQuery.data)) return;
  await bot.answerCallbackQuery(callbackQuery.id).catch(() => {});
  let usersTotal = "";
  try {
    const usersDb = JSON.parse(fs.readFileSync(usersFile));
    usersTotal = usersDb.length;
  } catch {}
  const text = panelMenuAllText(usersTotal);
  const opts = {
    chat_id: callbackQuery.message.chat.id,
    message_id: callbackQuery.message.message_id,
    parse_mode: "HTML",
    reply_markup: panelMenuKeyboard(),
  };
  try {
    if (callbackQuery.message.photo || callbackQuery.message.video || callbackQuery.message.animation || callbackQuery.message.document) {
      await bot.editMessageCaption(text, opts);
    } else {
      await bot.editMessageText(text, opts);
    }
  } catch {
    try { await bot.editMessageText(text, opts); } catch {}
  }
});
bot.on("callback_query", (callbackQuery) => {
  if (callbackQuery.data === "serverdua") {

    const userId = callbackQuery.from.id.toString();
    const isResellerV2 = JSON.parse(fs.readFileSync("./db/users/version/resellerV2.json"));

    if (!isResellerV2.includes(userId)) {
      return bot.answerCallbackQuery(callbackQuery.id, { text: "◇ Kamu tidak mempunyai akses server 2", show_alert: true });
    }

    bot.answerCallbackQuery(callbackQuery.id);
    const text = premiumPage(
      premiumSection("⌗", "CPANEL V2", ["/addpremv2", "/delpremv2"]),
      premiumSection("⟡", "MENU ADMIN V2", ["/addressv2", "/delressv2"]),
      premiumSection("§", "MENU SETTING V2", [
        "/listsrv2", "/listadmin2", "/listsrvoff2",
        "/clearoff2", "/delsrv2", "/totalserverv2",
      ]),
      premiumSection("◆", "RESELLER MENU V2", [
                "/1gbv2 nama,id",
        "/2gbv2 nama,id",
        "/3gbv2 nama,id",
        "/4gbv2 nama,id",
        "/5gbv2 nama,id",
        "/6gbv2 nama,id",
        "/7gbv2 nama,id",
        "/8gbv2 nama,id",
        "/9gbv2 nama,id",
        "/10gbv2 nama,id",
        "/unliv2 nama,id",
        "/cadpv2 nama,id",
      ])
    );

    bot.editMessageCaption(text, {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: `${toBoldSans("‹‹‹")}`, callback_data: "createpanel" }]
        ]
      },
    });
  }
});
bot.on("callback_query", (callbackQuery) => {
  if (callbackQuery.data === "servertiga") {

    const userId = callbackQuery.from.id.toString();
    const isResellerV3 = JSON.parse(fs.readFileSync("./db/users/version/resellerV3.json"));

    if (!isResellerV3.includes(userId)) {
      return bot.answerCallbackQuery(callbackQuery.id, { text: "◇ Kamu tidak mempunyai akses server 3", show_alert: true });
    }

    bot.answerCallbackQuery(callbackQuery.id);
    const text = premiumPage(
      premiumSection("⌗", "CPANEL V3", ["/addpremv3", "/delpremv3"]),
      premiumSection("⟡", "MENU ADMIN V3", ["/addressv3", "/delressv3"]),
      premiumSection("§", "MENU SETTING V3", [
        "/listsrv3", "/listadmin3", "/listsrvoff3",
        "/clearoff3", "/delsrv3", "/totalserverv3",
      ]),
      premiumSection("◆", "RESELLER MENU V3", [
                "/1gbv3 nama,id",
        "/2gbv3 nama,id",
        "/3gbv3 nama,id",
        "/4gbv3 nama,id",
        "/5gbv3 nama,id",
        "/6gbv3 nama,id",
        "/7gbv3 nama,id",
        "/8gbv3 nama,id",
        "/9gbv3 nama,id",
        "/10gbv3 nama,id",
        "/unliv3 nama,id",
        "/cadpv3 nama,id",
      ])
    );

    bot.editMessageCaption(text, {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: `${toBoldSans("‹‹‹")}`, callback_data: "createpanel" }]
        ]
      },
    });
  }
});
bot.on("callback_query", (callbackQuery) => {
  if (callbackQuery.data === "serverempat") {

    const userId = callbackQuery.from.id.toString();
    const isResellerV4 = JSON.parse(fs.readFileSync("./db/users/version/resellerV4.json"));

    if (!isResellerV4.includes(userId)) {
      return bot.answerCallbackQuery(callbackQuery.id, { text: "◇ Kamu tidak mempunyai akses server 4", show_alert: true });
    }

    bot.answerCallbackQuery(callbackQuery.id);
    const text = premiumPage(
      premiumSection("⌗", "CPANEL V4", ["/addpremv4", "/delpremv4"]),
      premiumSection("⟡", "MENU ADMIN V4", ["/addressv4", "/delressv4"]),
      premiumSection("§", "MENU SETTING V4", [
        "/listsrv4", "/listadmin4", "/listsrvoff4",
        "/clearoff4", "/delsrv4", "/totalserverv4",
      ]),
      premiumSection("◆", "RESELLER MENU V4", [
                "/1gbv4 nama,id",
        "/2gbv4 nama,id",
        "/3gbv4 nama,id",
        "/4gbv4 nama,id",
        "/5gbv4 nama,id",
        "/6gbv4 nama,id",
        "/7gbv4 nama,id",
        "/8gbv4 nama,id",
        "/9gbv4 nama,id",
        "/10gbv4 nama,id",
        "/unliv4 nama,id",
        "/cadpv4 nama,id",
      ])
    );

    bot.editMessageCaption(text, {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: `${toBoldSans("‹‹‹")}`, callback_data: "createpanel" }]
        ]
      },
    });
  }
});
bot.on("callback_query", (callbackQuery) => {
  if (callbackQuery.data === "serverlima") {

    const userId = callbackQuery.from.id.toString();
    const isResellerV5 = JSON.parse(fs.readFileSync("./db/users/version/resellerV5.json"));

    if (!isResellerV5.includes(userId)) {
      return bot.answerCallbackQuery(callbackQuery.id, { text: "◇ Kamu tidak mempunyai akses server 5", show_alert: true });
    }

    bot.answerCallbackQuery(callbackQuery.id);
    const text = premiumPage(
      premiumSection("⌗", "CPANEL V5", ["/addpremv5", "/delpremv5"]),
      premiumSection("⟡", "MENU ADMIN V5", ["/addressv5", "/delressv5"]),
      premiumSection("§", "MENU SETTING V5", [
        "/listsrv5", "/listadmin5", "/listsrvoff5",
        "/clearoff5", "/delsrv5", "/totalserverv5",
      ]),
      premiumSection("◆", "RESELLER MENU V5", [
                "/1gbv5 nama,id",
        "/2gbv5 nama,id",
        "/3gbv5 nama,id",
        "/4gbv5 nama,id",
        "/5gbv5 nama,id",
        "/6gbv5 nama,id",
        "/7gbv5 nama,id",
        "/8gbv5 nama,id",
        "/9gbv5 nama,id",
        "/10gbv5 nama,id",
        "/unliv5 nama,id",
        "/cadpv5 nama,id",
      ])
    );

    bot.editMessageCaption(text, {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: `${toBoldSans("‹‹‹")}`, callback_data: "createpanel" }]
        ]
      },
    });
  }
});
bot.on("callback_query", (callbackQuery) => {
  if (callbackQuery.data === "serverenam") {

    const userId = callbackQuery.from.id.toString();
    const isResellerV6 = JSON.parse(fs.readFileSync("./db/users/version/resellerV6.json"));

    if (!isResellerV6.includes(userId)) {
      return bot.answerCallbackQuery(callbackQuery.id, { text: "◇ Kamu tidak mempunyai akses server 6", show_alert: true });
    }

    bot.answerCallbackQuery(callbackQuery.id);
    const text = premiumPage(
      premiumSection("⌗", "CPANEL V6", ["/addpremv6", "/delpremv6"]),
      premiumSection("⟡", "MENU ADMIN V6", ["/addressv6", "/delressv6"]),
      premiumSection("§", "MENU SETTING V6", [
        "/listsrv6", "/listadmin6", "/listsrvoff6",
        "/clearoff6", "/delsrv6", "/totalserverv6",
      ]),
      premiumSection("◆", "RESELLER MENU V6", [
                "/1gbv6 nama,id",
        "/2gbv6 nama,id",
        "/3gbv6 nama,id",
        "/4gbv6 nama,id",
        "/5gbv6 nama,id",
        "/6gbv6 nama,id",
        "/7gbv6 nama,id",
        "/8gbv6 nama,id",
        "/9gbv6 nama,id",
        "/10gbv6 nama,id",
        "/unliv6 nama,id",
        "/cadpv6 nama,id",
      ])
    );

    bot.editMessageCaption(text, {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: `${toBoldSans("‹‹‹")}`, callback_data: "createpanel" }]
        ]
      },
    });
  }
});
bot.on("callback_query", (callbackQuery) => {
  if (callbackQuery.data === "servertuju") {

    const userId = callbackQuery.from.id.toString();
    const isResellerV7 = JSON.parse(fs.readFileSync("./db/users/version/resellerV7.json"));

    if (!isResellerV7.includes(userId)) {
      return bot.answerCallbackQuery(callbackQuery.id, { text: "◇ Kamu tidak mempunyai akses server 7", show_alert: true });
    }

    bot.answerCallbackQuery(callbackQuery.id);
    const text = premiumPage(
      premiumSection("⌗", "CPANEL V7", ["/addpremv7", "/delpremv7"]),
      premiumSection("⟡", "MENU ADMIN V7", ["/addressv7", "/delressv7"]),
      premiumSection("§", "MENU SETTING V7", [
        "/listsrv7", "/listadmin7", "/listsrvoff7",
        "/clearoff7", "/delsrv7", "/totalserverv7",
      ]),
      premiumSection("◆", "RESELLER MENU V7", [
                "/1gbv7 nama,id",
        "/2gbv7 nama,id",
        "/3gbv7 nama,id",
        "/4gbv7 nama,id",
        "/5gbv7 nama,id",
        "/6gbv7 nama,id",
        "/7gbv7 nama,id",
        "/8gbv7 nama,id",
        "/9gbv7 nama,id",
        "/10gbv7 nama,id",
        "/unliv7 nama,id",
        "/cadpv7 nama,id",
      ])
    );

    bot.editMessageCaption(text, {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: `${toBoldSans("‹‹‹")}`, callback_data: "createpanel" }]
        ]
      },
    });
  }
});
bot.on("callback_query", (callbackQuery) => {
  if (callbackQuery.data === "ownermenu") {
    bot.answerCallbackQuery(callbackQuery.id);
    const userId = callbackQuery.from.id;
    const text = premiumPage(
      premiumSection("⌖", "OWNER BOT", [
        "/addtk", "/addpt", "/addown", "/addall",
      ]),
      premiumSection("‡", "KHUSUS DEV", [
        "/backup", "/restart", "/stop", "/settingv1-7",
        "/panelres on/off", "/paneladp on/off", "/anticulikbot on/off",
        "/connect 628×××", "/broadcast",
        "/antikill on/off", "/checkkill", "/cekkill ip|password",
      ]),
      premiumSection("⟡", "OWNER PANEL", [
        "/address", "/ressall", "/delressall", "/delress",
        "/addprem", "/premall", "/delpremall", "/delprem",
      ])
    );
    bot.editMessageCaption(text, {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            { text: `${toBoldSans("⊕ Create Panel")}`, callback_data: "createpanel" },
          ],
          [
            { text: `${toBoldSans("⊞ Install Menu")}`, callback_data: "installmenu" },
            { text: `${toBoldSans("▶ Broadcast")}`, callback_data: "broadcastmenu" }
          ],
          [
            { text: `${toBoldSans("◈ Profile Saya")}`, callback_data: "profile" },
            ...(isLimitOwner(userId) ? [{ text: `${toBoldSans("⌗ Limit Menu")}`, callback_data: "limit_menu" }] : []),
          ],
          ...(isModeOwner(userId) ? [[{ text: `${toBoldSans("⌂ Mode Private/Public")}`, callback_data: "mode_menu" }]] : []),
          ...(isModeOwner(userId) ? [[{ text: `${toBoldSans("🛠 Bot Maintenance")}`, callback_data: "botmaintenance_menu" }]] : []),
          [
            { text: `${toBoldSans("⟡ Kelola Kode Redeem")}`, callback_data: "redeem_setcode" }
          ],
          [
            { text: `${toBoldSans("▣ Private CPanel")}`, callback_data: "private_cpanel_info" }
          ],
          [
            { text: `${toBoldSans("⚙ Auto Egg")}`, callback_data: "ownerfeat:autoegg" },
            { text: `${toBoldSans("☑ First Join")}`, callback_data: "ownerfeat:joinfirst" }
          ],
          [
            { text: `${toBoldSans("‹‹‹")}`, callback_data: "back" }
          ],
        ],
      },
    });
 }
});
bot.on("callback_query", async (callbackQuery) => {
  if (callbackQuery.data !== "installmenu") return;
  try {
    await bot.answerCallbackQuery(callbackQuery.id);
    const text = premiumPage(
      premiumSection("📥", "INSTALASI & DOMAIN", [
        "/subdomain namabebas|ipvps[|port]",
        "/installpanel host|password|domain_panel|domain_node",
        "/installdepend host|password",
        "/installwings host|password",
        "/installnginx host|password",
        "/uninstallpanel host|password",
        "/uninstallwings host|password",
      ]),
      premiumSection("🎨", "TEMA & MODIFIKASI", [
        "/installtema host|password",
        "/uninstalltema host|password",
      ]),
      premiumSection("⚙", "MANAJEMEN VPS", [
        "/fixkillpanel host|password",
        "/ubahpwvps host|password_lama|password_baru",
        "/ubahhostname host|password|hostname_baru",
      ]),
      premiumSection("🛡", "PROTEKSI", [
        "/installprotect host|password|id_admin_utama",
        "/uninstallprotect host|password",
      ])
    );
    await bot.editMessageCaption(text, {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: [
        [{ text: "‹‹‹", callback_data: "back" }]
      ] }
    });
  } catch (e) {
    try { await bot.answerCallbackQuery(callbackQuery.id, { text: "Menu installer gagal dimuat.", show_alert: true }); } catch {}
  }
});

bot.on("callback_query", async (callbackQuery) => {
  if (callbackQuery.data === "installtema") {
    await bot.answerCallbackQuery(callbackQuery.id);

    const maintTextTema = premiumPage(
      premiumSection("🎨", "INSTALL TEMA", [
        "/installtema host|password",
        "/uninstalltema host|password"
      ])
    );

    bot.editMessageCaption(maintTextTema, {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: `${toBoldSans("‹‹‹")}`, callback_data: "back" }]
        ]
      },
    });
  }
});
// Lakukan hal sama untuk callback "cvpsmenu"
bot.on("callback_query", (callbackQuery) => {
  if (callbackQuery.data === "cvpsmenu") {
    bot.answerCallbackQuery(callbackQuery.id);

    const text = premiumPage(
      premiumSection("▧", "INSTALL VPS", [
        "/createvps [host_name]", "/statusdo [option]",
      ]),
      premiumSection("⟡", "STATUS VPS", [
        "/rebuild [dropletId]", "/listvps [option]", "/delvps [dropletId]",
      ]),
      premiumSection("●", "AKSES VPS", [
        "/addresvps", "/delresvps",
      ])
    );

    bot.editMessageCaption(text, {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "Create VPS", callback_data: "cvps_create" }],
          [{ text: `${toBoldSans("‹‹‹")}`, callback_data: "back" }]
        ]
      },
    });
  }
});
bot.on("callback_query", async (callbackQuery) => {
  if (callbackQuery.data === "protectmenu") {
    await bot.answerCallbackQuery(callbackQuery.id);

    const maintTextProtect = premiumPage(
      premiumSection("🛡", "PROTECT PANEL", [
        "/installprotect host|password|id_admin_utama",
        "/uninstallprotect host|password"
      ])
    );

    bot.editMessageCaption(maintTextProtect, {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: `${toBoldSans("‹‹‹")}`, callback_data: "back" }]
        ]
      },
    });
  }
});
bot.on("callback_query", (callbackQuery) => {
  if (callbackQuery.data === "protectmenuv2") {
    bot.answerCallbackQuery(callbackQuery.id, { text: "[ ] Maintenance", show_alert: false });

    const maintTextProtect2 = premiumPage(
      premiumSection("🛡", "PROTECT PANEL • LIANIX", [
        "/installprotect host|password|id_admin_utama",
        "Pilih level 1–20 melalui tombol setelah validasi SSH/admin.",
        "/uninstallprotect host|password"
      ])
    );

    bot.editMessageCaption(maintTextProtect2, {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: `${toBoldSans("‹‹‹")}`, callback_data: "back" }]
        ]
      },
    });
  }
});
bot.on("callback_query", (callbackQuery) => {
  if (callbackQuery.data === "uninstallprotecn") {
    bot.answerCallbackQuery(callbackQuery.id);

const text = premiumPage(
      premiumSection("◇", "UNINSTALL PROTECT • LIANIX", [
        "/uninstallprotect host|password",
        "Menghapus middleware/config Protect Lianix yang dipasang installer baru."
      ])
    );

    bot.editMessageCaption(text, {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: `${toBoldSans("› Lanjut 9-16")}`, callback_data: "uninstallprotecnv2" }], 
          [{ text: `${toBoldSans("‹‹‹")}`, callback_data: "protectmenuv2" }]
        ]
      },
    });
  }
});
bot.on("callback_query", (callbackQuery) => {
  if (callbackQuery.data === "uninstallprotecnv2") {
    bot.answerCallbackQuery(callbackQuery.id);

const text = premiumPage(
      premiumSection("◇", "UNINSTALL PROTECT • LIANIX", [
        "/uninstallprotect host|password",
        "Proteksi level 1–20 disimpan sebagai satu konfigurasi Lianix; uninstall melepas sistem tersebut secara aman."
      ])
    );

    bot.editMessageCaption(text, {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: `${toBoldSans("‹‹‹")}`, callback_data: "uninstallprotecn" }]
        ]
      },
    });
  }
});
function getGroupGuardUiStatus(chatId) {
  try {
    const file = require("path").join(process.cwd(), "db", "groupGuard.json");
    const raw = JSON.parse(require("fs").readFileSync(file, "utf8"));
    return !!raw?.[String(chatId)]?.enabled;
  } catch (_) { return false; }
}

bot.on("callback_query", async (callbackQuery) => {
  if (callbackQuery.data !== "groupmenu") return;
  const chatId = callbackQuery.message.chat.id;
  const messageId = callbackQuery.message.message_id;
  try {
    await bot.answerCallbackQuery(callbackQuery.id).catch(() => {});
    const text =
      `<blockquote expandable>` +
      `<b>╭━━〔 GROUP MENU 〕━━╮</b>\n` +
      `│ 👥 Member & Admin\n` +
      `│ 🔐 Lock / Unlock\n` +
      `│ 📣 Tag All\n` +
      `│ 🛡️ Moderation & Protection\n` +
      `╰━━━━━━━━━━━━━━━━━━━━╯\n\n` +
      `<b>QUICK ACTION</b>\n` +
      `⪼ /tagall — tag semua member yang sudah dikenali bot\n` +
      `⪼ /lock — kunci chat member\n` +
      `⪼ /unlock — buka chat member\n` +
      `⪼ /addadmin — reply user untuk jadikan admin\n` +
      `⪼ /adduser — buat invite link untuk member\n\n` +
      `<b>MODERATION</b>\n` +
      `⪼ /kick • /ban • /unban\n` +
      `⪼ /mute • /unmute\n` +
      `⪼ /warn • /warns • /resetwarn\n` +
      `⪼ /antilink on|off\n\n` +
      `<i>Member akan otomatis tercatat saat berinteraksi dengan bot.</i>` +
      `</blockquote>`;
    const t = theme.getTheme();
    const keyboard = { inline_keyboard: [
      [theme.styled({ text: `${getGroupGuardUiStatus(chatId) ? "🟢" : "🔴"} Jaga Grup`, callback_data: "gg:open" }, t)],
      [theme.styled({ text: "Dashboard", callback_data: "back" }, t)]
    ]};
    const opts = { chat_id: chatId, message_id: messageId, parse_mode: "HTML", reply_markup: keyboard };
    if (callbackQuery.message.photo || callbackQuery.message.video || callbackQuery.message.animation || callbackQuery.message.document) {
      await bot.editMessageCaption(text, opts).catch(() => bot.editMessageText(text, opts));
    } else {
      await bot.editMessageText(text, opts);
    }
  } catch (e) {
    console.error("[groupmenu]", e?.stack || e);
  }
});

bot.on("callback_query", (callbackQuery) => {
  if (callbackQuery.data === "downloadmenu") {
    bot.answerCallbackQuery(callbackQuery.id);

    const text = premiumPage(
      premiumSection("▾", "DOWNLOAD MENU", [
        "/tiktok", "/spotify", "/mediafire", "/videydl",
        "/twitter", "/facebook", "/capcutdl", "/ytdl",
      ])
    );

    bot.editMessageCaption(text, {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: `${toBoldSans("‹‹‹")}`, callback_data: "toolsmenu" }]
        ]
      },
    });
  }
});
bot.on("callback_query", (callbackQuery) => {
  if (callbackQuery.data === "serachmenu") {
    bot.answerCallbackQuery(callbackQuery.id);

    const text = premiumPage(
      premiumSection("⌂", "SEARCH MENU", [
        "/ttsearch [kata kunci]",
        "/tvsearch [channel]",
        "/spotifysearch [judul]",
        "/stickersearch [kata_kunci]",
        "/cekcuaca [kota]",
        "/infogempa",
      ])
    );

    bot.editMessageCaption(text, {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: `${toBoldSans("‹‹‹")}`, callback_data: "toolsmenu" }]
        ]
      },
    });
  }
});


bot.on("callback_query", (callbackQuery) => {
  if (callbackQuery.data === "stalkmenu") {
    bot.answerCallbackQuery(callbackQuery.id);

    const text = premiumPage(
      premiumSection("◉", "STALK MENU", [
        "/ttstalk [username]",
        "/ytstalk [username]",
        "/pinstalk [username]",
        "/twitterstalk [username]",
        "/githubstalk [username]",
        "/robloxstalk [username]",
      ])
    );

    bot.editMessageCaption(text, {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: `${toBoldSans("‹‹‹")}`, callback_data: "toolsmenu" }]
        ]
      },
    });
  }
});

bot.on("callback_query", (callbackQuery) => {
  if (callbackQuery.data === "toolsmenu") {
    bot.answerCallbackQuery(callbackQuery.id);

    const text = `<b>╭━━〔 TOOLS CENTER 〕━━╮</b>\n` +
      `<blockquote expandable>` +
      `Semua fitur tools ditampilkan di sini. Tidak ada tombol yang disembunyikan.\n\n` +
      `▣ QR • OCR • Remove BG • Screenshot\n` +
      `◈ Sticker → Image • Video → Audio • Media → Video\n` +
      `◎ Image Info • Image → ASCII • GitReverse\n` +
      `🎨 Text → Image • 🎬 Image → Video\n` +
      `✨ AI Enhance • AI Remove BG` +
      `</blockquote>`;

    const kb = extraTools.toolsMenuKeyboard();
    bot.editMessageCaption(text, {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      parse_mode: "HTML",
      reply_markup: kb,
    }).catch(() => bot.editMessageText(text, {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      parse_mode: "HTML",
      reply_markup: kb,
    }));
  }
});
bot.on("callback_query", async (callbackQuery) => {
  if (callbackQuery.data !== "open_dashboard") return;

  const q = callbackQuery;
  const msg = q.message;
  if (!msg?.chat?.id || !msg.message_id) {
    await bot.answerCallbackQuery(q.id, { text: "Dashboard tidak tersedia.", show_alert: true }).catch(() => {});
    return;
  }

  const chatId = msg.chat.id;
  const userId = q.from?.id || msg.from?.id;
  const username = q.from?.username
    ? "@" + q.from.username
    : q.from?.first_name || "Pengguna";

  // Hentikan loading pada tombol secepat mungkin. Jangan menunggu proses edit.
  await bot.answerCallbackQuery(q.id, { text: "Membuka dashboard…" }).catch(() => {});

  try {
    // Gunakan renderer menu utama yang memang dipakai seluruh bot.
    // Ini menghindari payload dashboard yang berbeda dari src/menu.js.
    await showMainMenu(bot, chatId, msg.message_id, userId, q.from || msg.from || {});
    theme.registerMenuMessage(chatId, msg.message_id, userId, username);
  } catch (err) {
    console.error("[dashboard] open_dashboard gagal:", err?.stack || err?.message || err);

    // Fallback keras: jangan biarkan tombol terlihat "tidak melakukan apa-apa".
    try {
      const payload = buildMainMenuPayload(userId, username);
      const opts = {
        chat_id: chatId,
        message_id: msg.message_id,
        parse_mode: "HTML",
        reply_markup: payload.reply_markup,
      };

      if (msg.photo || msg.caption !== undefined) {
        await bot.editMessageCaption(payload.text, opts);
      } else {
        await bot.editMessageText(payload.text, opts);
      }
      theme.registerMenuMessage(chatId, msg.message_id, userId, username);
    } catch (editErr) {
      console.error("[dashboard] fallback edit gagal:", editErr?.message || editErr);
      try {
        const payload = buildMainMenuPayload(userId, username);
        const sent = await bot.sendMessage(chatId, payload.text, {
          parse_mode: "HTML",
          reply_markup: payload.reply_markup,
        });
        if (sent?.message_id) {
          theme.registerMenuMessage(chatId, sent.message_id, userId, username);
        }
      } catch (sendErr) {
        console.error("[dashboard] fallback send gagal:", sendErr?.message || sendErr);
        await bot.answerCallbackQuery(q.id, {
          text: "Dashboard gagal dibuka. Cek log bot.",
          show_alert: true,
        }).catch(() => {});
      }
    }
  }
});

bot.on("callback_query", async (callbackQuery) => {
  if (callbackQuery.data !== "dashboard_back_start") return;
  await bot.answerCallbackQuery(callbackQuery.id).catch(() => {});
  await restoreStartFromDashboard(callbackQuery);
});

bot.on("callback_query", (callbackQuery) => {
  if (callbackQuery.data === "back") {
    bot.answerCallbackQuery(callbackQuery.id);

    const userId = callbackQuery.from.id;
    const chatId = callbackQuery.message.chat.id;
    const messageId = callbackQuery.message.message_id;

    const username = callbackQuery.from.username
      ? "@" + callbackQuery.from.username
      : callbackQuery.from.first_name || "Pengguna";

    const { text, reply_markup } = buildMainMenuPayload(userId, username);

    const opts = { chat_id: chatId, message_id: messageId, parse_mode: "HTML", reply_markup };
    bot.editMessageText(text, opts).catch((err) => {
      const d = String(err?.response?.body?.description || err?.message || "");
      if (/message is not modified|message to edit not found/i.test(d)) return null;
      return bot.editMessageCaption(text, opts).catch(() => null);
    }).catch(() => {});

    theme.registerMenuMessage(chatId, messageId, userId, username);
  }
});

// ============================================================
//  DEV PANEL (khusus Owner) — kelola tema warna: pilih manual,
//  atau nyalain auto-cycle ganti warna tiap 1 detik / 10 detik.
// ============================================================
function isDevPanelAllowed(userId) {
  return settings.isOwner(userId);
}

function buildDevPanelPayload() {
  const t = theme.getTheme();
  const cyclingOn = theme.isCycling();
  const speedSec = Math.round((theme.getIntervalMs() / 1000) * 10) / 10;

  const themeListText = theme.getThemeList()
    .map((th) => `${th.key === t.key ? "→" : "⌁"} ${th.deco} ${th.name}`)
    .join("\n");

  const text = `${t.deco} <b>${toBoldSans("DEV PANEL")}</b> ${t.deco}

<blockquote expandable>❖ <b>${toBoldSans("STATUS")}</b> ❖
├ Tema aktif  : ${t.deco} ${t.name}
├ Auto Cycle  : ${cyclingOn ? "Nyala ▶" : "Mati ■"}
├ Kecepatan   : ${speedSec} detik
╰ Audio Intro : ${audio.getAudioUrl() || "Nonaktif (dihapus)"}

❖ <b>${toBoldSans("DAFTAR TEMA")}</b> ❖
${themeListText}</blockquote>

→ Fitur ini khusus Dev/Owner.`;

  const rows = theme.getThemeList().map((th) => ([
    theme.styled({ text: `${th.deco} ${toBoldSans(th.name)}`, callback_data: `devtheme_${th.key}` }, th),
  ]));

  rows.push([
    theme.styled(
      {
        text: cyclingOn ? `🟢 ${toBoldSans("Auto Cycle • ON")}` : `🔴 ${toBoldSans("Auto Cycle • OFF")}`,
        callback_data: cyclingOn ? "devcycle_off" : "devcycle_on",
      },
      cyclingOn ? { style: "danger" } : { style: "success" }
    ),
  ]);
  rows.push([
    theme.styled({ text: `${toBoldSans("Speed 1 Detik")}`, callback_data: "devspeed_1" }, { style: "primary" }),
    theme.styled({ text: `${toBoldSans("Speed 10 Detik")}`, callback_data: "devspeed_10" }, { style: "primary" }),
  ]);
  rows.push([
    theme.styled({ text: `${toBoldSans("⊙ Speed Custom")}`, callback_data: "devspeed_custom" }, { style: "primary" }),
  ]);
  rows.push([
    theme.styled({ text: `+ ${toBoldSans("Tambah Audio")}`, callback_data: "devaudio_set" }, { style: "success" }),
    theme.styled({ text: `x ${toBoldSans("Hapus Audio")}`, callback_data: "devaudio_remove" }, { style: "danger" }),
  ]);
  rows.push([
    theme.styled({ text: `◉ ${toBoldSans("Auto Cek CPU")}`, callback_data: "dev_cpu_settings" }, { style: "primary" }),
  ]);
  rows.push([
    theme.styled({ text: `◈ ${toBoldSans("Kelola Channel")}`, callback_data: "devchannel" }, { style: "primary" }),
  ]);
  rows.push([
    theme.styled({ text: `▭ ${toBoldSans("Kelola Panel")}`, callback_data: "devsetpanel" }, { style: "primary" }),
  ]);
  rows.push([
    { text: `⌘ ${toBoldSans("Ambil JS")}`, callback_data: "dev_src_list" },
    { text: `⇄ ${toBoldSans("Ganti JS")}`, callback_data: "dev_replace_list" },
  ]);
  rows.push([
    { text: `⚙ ${toBoldSans("Kill Panel")}`, callback_data: "dev_kill_settings" },
    { text: `▣ ${toBoldSans("Backup Center")}`, callback_data: "dev_backup" },
  ]);
  rows.push([{ text: `‹ ${toBoldSans("‹‹‹")}`, callback_data: "back" }]);

  return { text, reply_markup: { inline_keyboard: rows } };
}

function refreshDevPanel(callbackQuery) {
  const { text, reply_markup } = buildDevPanelPayload();
  bot.editMessageCaption(text, {
    chat_id: callbackQuery.message.chat.id,
    message_id: callbackQuery.message.message_id,
    parse_mode: "HTML",
    reply_markup,
  }).catch(() => {
    // Fallback: pesan mungkin tidak punya caption (plain text message)
    bot.editMessageText(text, {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      parse_mode: "HTML",
      reply_markup,
    }).catch(e => console.error("[devpanel] refreshDevPanel fallback gagal:", e.message));
  });
}

bot.on("callback_query", (callbackQuery) => {
  if (callbackQuery.data !== "devpanel") return;
  bot.answerCallbackQuery(callbackQuery.id);

  if (!isDevPanelAllowed(callbackQuery.from.id)) {
    return bot.answerCallbackQuery(callbackQuery.id, { text: "◇ Khusus Dev/Owner!", show_alert: true });
  }

  // DevPanel ikut didaftarkan ke registry cycle dengan builder khusus, sehingga
  // warna tombol di halaman DevPanel sendiri ikut berubah saat Auto Cycle aktif.
  const devUsername = callbackQuery.from.username ? "@" + callbackQuery.from.username : (callbackQuery.from.first_name || "Owner");
  theme.registerMenuMessage(
    callbackQuery.message.chat.id,
    callbackQuery.message.message_id,
    callbackQuery.from.id,
    devUsername,
    () => buildDevPanelPayload()
  );
  refreshDevPanel(callbackQuery);
});

// ============================================================
//  KELOLA CHANNEL (khusus Owner) — list, tambah, ubah, hapus channel
//  lewat tombol. Data disimpen di db/channels.json (src/data/channelStore.js)
//  jadi bisa lebih dari satu channel, gak dibatasin cuma 1 kayak
//  settings.chUsn dulu.
// ============================================================
const channelInputState = {}; // userId -> { mode: "add" | "edit", id?, chatId }

function buildChannelPanelPayload() {
  const t = theme.getTheme();
  const channels = channelStore.getChannels();

  const listText = channels.length
    ? channels.map((c, i) => `${i + 1}. ${c.username}`).join("\n")
    : "Belum ada channel yang ditambahin.";

  const text = `${t.deco} ${toBoldSans("KELOLA CHANNEL")} ${t.deco}

<blockquote expandable>${listText}</blockquote>

→ Pencet channel buat ubah/hapus, atau tambah baru di bawah.`;

  const rows = channels.map((c) => ([
    { text: `✎ ${c.username}`, callback_data: `devchannel_edit_${c.id}` },
    { text: "⌫", callback_data: `devchannel_del_${c.id}` },
  ]));

  rows.push([
    theme.styled({ text: `+ ${toBoldSans("Tambah Channel")}`, callback_data: "devchannel_add" }, { style: "success" }),
  ]);
  rows.push([{ text: `‹ ${toBoldSans("‹‹‹")}`, callback_data: "devpanel" }]);

  return { text, reply_markup: { inline_keyboard: rows } };
}

function refreshChannelPanel(callbackQuery) {
  const { text, reply_markup } = buildChannelPanelPayload();
  bot.editMessageCaption(text, {
    chat_id: callbackQuery.message.chat.id,
    message_id: callbackQuery.message.message_id,
    parse_mode: "HTML",
    reply_markup,
  }).catch(() => {});
}

bot.on("callback_query", (callbackQuery) => {
  if (callbackQuery.data !== "devchannel") return;
  if (!isDevPanelAllowed(callbackQuery.from.id)) {
    return bot.answerCallbackQuery(callbackQuery.id, { text: "◇ Khusus Dev/Owner!", show_alert: true });
  }
  bot.answerCallbackQuery(callbackQuery.id);
  refreshChannelPanel(callbackQuery);
});

bot.on("callback_query", (callbackQuery) => {
  if (callbackQuery.data !== "devchannel_add") return;
  if (!isDevPanelAllowed(callbackQuery.from.id)) {
    return bot.answerCallbackQuery(callbackQuery.id, { text: "◇ Khusus Dev/Owner!", show_alert: true });
  }

  const userId = callbackQuery.from.id;
  const chatId = callbackQuery.message.chat.id;
  channelInputState[userId] = { mode: "add", chatId, messageId: callbackQuery.message.message_id };
  bot.answerCallbackQuery(callbackQuery.id);

  bot.sendMessage(
    chatId,
    "◈ Kirim username channel baru (contoh: <code>@namachannel</code>).\nKetik /batal untuk membatalkan.",
    { parse_mode: "HTML", reply_to_message_id: callbackQuery.message.message_id }
  );
});

bot.on("callback_query", (callbackQuery) => {
  if (!String(callbackQuery.data || "").startsWith("devchannel_edit_")) return;
  if (!isDevPanelAllowed(callbackQuery.from.id)) {
    return bot.answerCallbackQuery(callbackQuery.id, { text: "◇ Khusus Dev/Owner!", show_alert: true });
  }

  const id = callbackQuery.data.replace("devchannel_edit_", "");
  const channel = channelStore.getChannel(id);
  if (!channel) {
    return bot.answerCallbackQuery(callbackQuery.id, { text: "◇ Channel ini sudah tidak ada.", show_alert: true });
  }

  const userId = callbackQuery.from.id;
  const chatId = callbackQuery.message.chat.id;
  channelInputState[userId] = { mode: "edit", id: channel.id, chatId, messageId: callbackQuery.message.message_id };
  bot.answerCallbackQuery(callbackQuery.id);

  bot.sendMessage(
    chatId,
    `✎ Channel saat ini: <code>${channel.username}</code>\nKirim username baru buat ganti (contoh: <code>@namachannel</code>).\nKetik /batal untuk membatalkan.`,
    { parse_mode: "HTML", reply_to_message_id: callbackQuery.message.message_id }
  );
});

bot.on("message", (msg) => {
  const userId = msg.from?.id;
  if (!userId || !channelInputState[userId]) return;
  if (!isDevPanelAllowed(userId)) return;
  if (!msg.text) return;

  const state = channelInputState[userId];
  const chatId = msg.chat.id;

  if (msg.text === "/batal") {
    delete channelInputState[userId];
    return bot.sendMessage(chatId, "<blockquote expandable>◇ <b>Dibatalkan</b>\nProses telah dibatalkan.</blockquote>", { parse_mode: "HTML" });
  }

  const usernameRaw = msg.text.trim();
  if (!/^@?[A-Za-z0-9_]{5,32}$/.test(usernameRaw)) {
    return bot.sendMessage(
      chatId,
      "<blockquote expandable>◇ <b>Format Tidak Valid</b>\nUsername channel tidak valid.\nContoh yang benar: <code>@namachannel</code>\nCoba lagi atau ketik /batal.</blockquote>",
      { parse_mode: "HTML" }
    );
  }

  delete channelInputState[userId];

  let resultText;
  if (state.mode === "add") {
    const entry = channelStore.addChannel(usernameRaw);
    resultText = `◉ Channel <code>${entry.username}</code> berhasil ditambahin.`;
  } else {
    const updated = channelStore.updateChannel(state.id, usernameRaw);
    resultText = updated
      ? `◉ Channel berhasil diubah jadi <code>${updated.username}</code>.`
      : "◇ Channel ini udah gak ada (mungkin kehapus duluan).";
  }

  const { text, reply_markup } = buildChannelPanelPayload();
  const combinedText = `${resultText}\n\n${text}`;

  // Balikin ke pesan Dev Panel/Kelola Channel yang ASLI (edit caption di tempat),
  // biar tombol-tombol di panel itu (edit/hapus/tambah lagi) tetep numpang di
  // pesan yang sama dan gak "ketinggalan" jadi pesan teks baru yang captionnya
  // gak ada (itu yang bikin tombol lanjutan diem aja / keliatan gak ngefek).
  // Auto-hapus pesan input username dari user (agar chat bersih)
  try { bot.deleteMessage(chatId, msg.message_id).catch(() => {}); } catch (_) {}

  bot.editMessageCaption(combinedText, {
    chat_id: state.chatId,
    message_id: state.messageId,
    parse_mode: "HTML",
    reply_markup,
  }).catch(() => {
    bot.sendMessage(chatId, combinedText, { parse_mode: "HTML", reply_markup });
  });
});

bot.on("callback_query", (callbackQuery) => {
  if (!String(callbackQuery.data || "").startsWith("devchannel_del_")) return;
  if (!isDevPanelAllowed(callbackQuery.from.id)) {
    return bot.answerCallbackQuery(callbackQuery.id, { text: "◇ Khusus Dev/Owner!", show_alert: true });
  }

  const id = callbackQuery.data.replace("devchannel_del_", "");
  const channel = channelStore.getChannel(id);
  if (!channel) {
    return bot.answerCallbackQuery(callbackQuery.id, { text: "◇ Channel ini sudah tidak ada.", show_alert: true });
  }
  bot.answerCallbackQuery(callbackQuery.id);

  const t = theme.getTheme();
  bot.editMessageCaption(
    `${t.deco} ${toBoldSans("HAPUS CHANNEL")} ${t.deco}\n\nYakin mau hapus <code>${channel.username}</code>?`,
    {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            theme.styled({ text: `◉ ${toBoldSans("Ya, Hapus")}`, callback_data: `devchannel_delconfirm_${id}` }, { style: "danger" }),
            { text: `◇ ${toBoldSans("Batal")}`, callback_data: "devchannel" },
          ],
        ],
      },
    }
  ).catch(() => {});
});

bot.on("callback_query", (callbackQuery) => {
  if (!String(callbackQuery.data || "").startsWith("devchannel_delconfirm_")) return;
  if (!isDevPanelAllowed(callbackQuery.from.id)) {
    return bot.answerCallbackQuery(callbackQuery.id, { text: "◇ Khusus Dev/Owner!", show_alert: true });
  }

  const id = callbackQuery.data.replace("devchannel_delconfirm_", "");
  const removed = channelStore.removeChannel(id);
  bot.answerCallbackQuery(callbackQuery.id, { text: removed ? "◉ Channel dihapus." : "Channel udah gak ada." });
  refreshChannelPanel(callbackQuery);
});

bot.on("callback_query", (callbackQuery) => {
  if (!String(callbackQuery.data || "").startsWith("devtheme_")) return;
  if (!isDevPanelAllowed(callbackQuery.from.id)) {
    return bot.answerCallbackQuery(callbackQuery.id, { text: "◇ Khusus Dev/Owner!", show_alert: true });
  }
  const key = callbackQuery.data.replace("devtheme_", "");
  const idx = theme.getThemeList().findIndex((th) => th.key === key);
  if (idx >= 0) theme.setThemeIndex(idx);
  bot.answerCallbackQuery(callbackQuery.id, { text: "◉ Tema diganti" });
  refreshDevPanel(callbackQuery);
});

bot.on("callback_query", (callbackQuery) => {
  if (callbackQuery.data !== "devcycle_on" && callbackQuery.data !== "devcycle_off") return;
  if (!isDevPanelAllowed(callbackQuery.from.id)) {
    return bot.answerCallbackQuery(callbackQuery.id, { text: "◇ Khusus Dev/Owner!", show_alert: true });
  }

  if (callbackQuery.data === "devcycle_on") {
    theme.startAutoCycle(bot, (uid, username) => buildMainMenuPayload(uid, username || "Pengguna"), theme.getIntervalMs());
    bot.answerCallbackQuery(callbackQuery.id, { text: "▶ Auto cycle dinyalain" });
  } else {
    theme.stopAutoCycle();
    bot.answerCallbackQuery(callbackQuery.id, { text: "⏹ Auto cycle dimatiin" });
  }

  refreshDevPanel(callbackQuery);
});

bot.on("callback_query", (callbackQuery) => {
  if (callbackQuery.data !== "devspeed_1" && callbackQuery.data !== "devspeed_10") return;
  if (!isDevPanelAllowed(callbackQuery.from.id)) {
    return bot.answerCallbackQuery(callbackQuery.id, { text: "◇ Khusus Dev/Owner!", show_alert: true });
  }

  const ms = callbackQuery.data === "devspeed_1" ? 1000 : 10000;
  theme.setIntervalMs(ms);

  // kalo lagi nyala, restart interval-nya pake kecepatan baru
  if (theme.isCycling()) {
    theme.startAutoCycle(bot, (uid, username) => buildMainMenuPayload(uid, username || "Pengguna"), ms);
  }

  bot.answerCallbackQuery(callbackQuery.id, { text: `◉ Speed diset ${ms / 1000} detik` });
  refreshDevPanel(callbackQuery);
});

// ============================================================
//  SPEED CUSTOM — biar Owner bisa atur kecepatan ganti warna
//  button sesuka hati (bukan cuma pilihan 1 detik / 10 detik).
// ============================================================
const devSpeedState = {};

bot.on("callback_query", (callbackQuery) => {
  if (callbackQuery.data !== "devspeed_custom") return;
  if (!isDevPanelAllowed(callbackQuery.from.id)) {
    return bot.answerCallbackQuery(callbackQuery.id, { text: "◇ Khusus Dev/Owner!", show_alert: true });
  }

  const userId = callbackQuery.from.id;
  const chatId = callbackQuery.message.chat.id;

  const speedMsgId = callbackQuery.message.message_id;
  devSpeedState[userId] = { waiting: true, chatId };
  devSpeedState._lastMsgId = speedMsgId;
  bot.answerCallbackQuery(callbackQuery.id);

  bot.sendMessage(
    chatId,
    "⊙ Kirim angka kecepatan ganti warna dalam <b>detik</b>\n(contoh: <code>3</code> atau <code>0.5</code>, minimal 0.5 detik)\n\nKetik /batal untuk membatalkan.",
    { parse_mode: "HTML", reply_to_message_id: callbackQuery.message.message_id }
  );
});

bot.on("message", async (msg) => {
  const userId = msg.from?.id;
  if (!userId || !devSpeedState[userId] || !devSpeedState[userId].waiting) return;
  if (!isDevPanelAllowed(userId)) return;
  if (!msg.text) return;

  const chatId = msg.chat.id;

  if (msg.text === "/batal") {
    delete devSpeedState[userId];
    return bot.sendMessage(chatId, "<blockquote expandable>◇ <b>Dibatalkan</b>\nPengaturan speed custom dibatalkan.</blockquote>", { parse_mode: "HTML" });
  }

  const detik = parseFloat(msg.text.trim().replace(",", "."));

  if (isNaN(detik) || detik < 0.5 || detik > 3600) {
    return bot.sendMessage(
      chatId,
      "<blockquote expandable>◇ <b>Input Tidak Valid</b>\nKirim angka detik antara 0.5 s/d 3600.\nAtau ketik /batal untuk membatalkan.</blockquote>"
    );
  }

  delete devSpeedState[userId];

  const ms = Math.round(detik * 1000);
  theme.setIntervalMs(ms);

  // kalo lagi nyala, restart interval-nya pake kecepatan baru
  if (theme.isCycling()) {
    theme.startAutoCycle(bot, (uid, username) => buildMainMenuPayload(uid, username || "Pengguna"), ms);
  }

  // Hapus pesan input user supaya chat tidak bertumpuk
  try { await bot.deleteMessage(chatId, msg.message_id); } catch (_) {}

  // Update dev panel yang sudah ada (pakai messageId dari devSpeedState)
  const savedSpeedMsgId = devSpeedState._lastMsgId || null;
  delete devSpeedState._lastMsgId;

  const { text: spText, reply_markup: spMarkup } = buildDevPanelPayload();
  if (savedSpeedMsgId) {
    bot.editMessageCaption(spText, {
      chat_id: chatId, message_id: savedSpeedMsgId,
      parse_mode: "HTML", reply_markup: spMarkup,
    }).catch(() => {
      bot.editMessageText(spText, {
        chat_id: chatId, message_id: savedSpeedMsgId,
        parse_mode: "HTML", reply_markup: spMarkup,
      }).catch(() => {});
    });
  }
  // Kirim notifikasi singkat yang auto-hapus sendiri
  bot.sendMessage(chatId, `◉ Speed diset ke <b>${detik} detik</b>.`, { parse_mode: "HTML" })
    .then(notif => {
      setTimeout(() => bot.deleteMessage(chatId, notif.message_id).catch(() => {}), 3000);
    }).catch(() => {});
});

// ============================================================
//  ATUR AUDIO — Owner/Dev kirim link baru, dipakai buat musik
//  intro di /start selanjutnya. Kelakuannya sama kaya Speed Custom
//  di atas: pencet tombol -> bot minta kirim link -> link disimpen.
// ============================================================
const devAudioState = {};

bot.on("callback_query", (callbackQuery) => {
  if (callbackQuery.data !== "devaudio_set") return;
  if (!isDevPanelAllowed(callbackQuery.from.id)) {
    return bot.answerCallbackQuery(callbackQuery.id, { text: "◇ Khusus Dev/Owner!", show_alert: true });
  }

  const userId = callbackQuery.from.id;
  const chatId = callbackQuery.message.chat.id;

  devAudioState[userId] = { waiting: true, chatId, messageId: callbackQuery.message.message_id };
  bot.answerCallbackQuery(callbackQuery.id);

  bot.sendMessage(
    chatId,
    `⊙ Kirim link audio baru (format mp3, harus link langsung yang bisa diakses publik).\n\nContoh: link dari Catbox.moe\n\nAudio aktif sekarang:\n<code>${audio.getAudioUrl() || "Nonaktif"}</code>\n\nKetik /batal untuk membatalkan.`,
    { parse_mode: "HTML", reply_to_message_id: callbackQuery.message.message_id }
  );
});

// ============================================================
//  HAPUS AUDIO — Owner/Dev matiin audio intro tanpa ganti link.
//  /start selanjutnya SKIP kirim audio sama sekali sampai
//  "Tambah Audio" dipencet lagi.
// ============================================================
bot.on("callback_query", (callbackQuery) => {
  if (callbackQuery.data !== "devaudio_remove") return;
  if (!isDevPanelAllowed(callbackQuery.from.id)) {
    return bot.answerCallbackQuery(callbackQuery.id, { text: "x Khusus Dev/Owner!", show_alert: true });
  }

  const chatId = callbackQuery.message.chat.id;

  if (!audio.isAudioEnabled()) {
    return bot.answerCallbackQuery(callbackQuery.id, { text: "- Audio memang lagi nonaktif.", show_alert: true });
  }

  audio.disableAudio();
  bot.answerCallbackQuery(callbackQuery.id, { text: "◉ Audio intro dihapus.", show_alert: true });

  const { text: devText, reply_markup: devMarkup } = buildDevPanelPayload();
  bot.editMessageCaption(devText, {
    chat_id: chatId,
    message_id: callbackQuery.message.message_id,
    parse_mode: "HTML",
    reply_markup: devMarkup,
  }).catch(() => {
    bot.editMessageText(devText, {
      chat_id: chatId,
      message_id: callbackQuery.message.message_id,
      parse_mode: "HTML",
      reply_markup: devMarkup,
    }).catch(e => console.error("[devaudio_remove] edit gagal:", e.message));
  });
});

bot.on("message", async (msg) => {
  const userId = msg.from?.id;
  if (!userId || !devAudioState[userId] || !devAudioState[userId].waiting) return;
  if (!isDevPanelAllowed(userId)) return;
  if (!msg.text) return;

  const chatId = msg.chat.id;

  if (msg.text === "/batal") {
    delete devAudioState[userId];
    return bot.sendMessage(chatId, "<blockquote expandable>◇ <b>Dibatalkan</b>\nPengaturan audio dibatalkan.</blockquote>", { parse_mode: "HTML" });
  }

  const url = msg.text.trim();

  if (!audio.isValidAudioUrl(url)) {
    return bot.sendMessage(
      chatId,
      "<blockquote expandable>◇ <b>Link Tidak Valid</b>\nHarus diawali http:// atau https://.\nKetik /batal untuk membatalkan.</blockquote>"
    );
  }

  const savedMsgId = devAudioState[userId]?.messageId || null;
  delete devAudioState[userId];
  audio.setAudioUrl(url);

  // Kirim preview biar Owner langsung dengar hasilnya sebelum dipakai di /start.
  try {
    await bot.sendAudio(chatId, url, {
      caption: "◉ Audio intro berhasil diganti. Preview:",
      title: "velquira.mp3",
      performer: "#LianiX",
    });
  } catch (e) {
    await bot.sendMessage(
      chatId,
      `<blockquote expandable>◈ <b>Audio Tersimpan</b>\nLink berhasil disimpan, tapi preview gagal: ${e.message}\n\nCek kembali link valid dan bisa diakses publik.</blockquote>`
    );
  }

  const { text: devText, reply_markup: devMarkup } = buildDevPanelPayload();
  // Edit panel yang sudah ada (pakai messageId yang disimpan sebelum state dihapus)
  if (savedMsgId) {
    bot.editMessageCaption(devText, {
      chat_id: chatId, message_id: savedMsgId,
      parse_mode: "HTML", reply_markup: devMarkup,
    }).catch(() => {
      bot.editMessageText(devText, {
        chat_id: chatId, message_id: savedMsgId,
        parse_mode: "HTML", reply_markup: devMarkup,
      }).catch(() => {
        bot.sendMessage(chatId, devText, { parse_mode: "HTML", reply_markup: devMarkup });
      });
    });
  }
  // Auto-hapus pesan input URL user (agar chat bersih)
  try { await bot.deleteMessage(chatId, msg.message_id); } catch (_) {}
});

// ================= PROFILE (FOTO ASLI USER) =================
bot.on("callback_query", async (callbackQuery) => {
  if (callbackQuery.data !== "profile") return;
  await bot.answerCallbackQuery(callbackQuery.id);

  const chatId = callbackQuery.message.chat.id;
  const messageId = callbackQuery.message.message_id;
  const from = callbackQuery.from;
  const userId = from.id.toString();

  const username = from.username ? "@" + from.username : (from.first_name || "Pengguna");
  const fullName = [from.first_name, from.last_name].filter(Boolean).join(" ") || "Tidak diketahui";

  const status = ownerUsers.includes(userId)
    ? "Owner"
    : premiumUsers.includes(userId)
    ? "Premium"
    : ressUsers?.includes(userId)
    ? "Reseller"
    : "User";

  const limitRes = checkLimit(from.id);
  const limitText =
    limitRes.remaining === null
      ? "∞ Unlimited"
      : `${limitRes.used}/${limitRes.limit} (sisa ${limitRes.remaining})`;

  const nowP = new Date();
  const waktuNow = nowP.toLocaleTimeString("id-ID", { timeZone: "Asia/Jakarta" });

  const statusIconP =
    status === "Owner" ? "⌖" :
    status === "Premium" ? "◈" :
    status === "Reseller" ? "◆" : "⌀";

  const profileText = `${UI.deco} ${toBoldScript("Profil Akun")} ${UI.deco}

<blockquote expandable>⌁ Nama     : ${fullName}
⌇ ID       : <code>${userId}</code>
⌁ Rank     : ${statusIconP} ${status}
⌗ Limit    : ${limitText}
⌁ Waktu    : ${waktuNow}
⌁ Bot      : #LianiX</blockquote>

→ Ketik /status untuk melihat semua server yg online maupun offline`;

  // Ambil foto profil ASLI milik user dari Telegram
  let photoSource = pp; // fallback: foto default bot kalau user gak punya foto profil
  try {
    const photos = await bot.getUserProfilePhotos(from.id, { limit: 1 });
    if (photos && photos.total_count > 0) {
      const sizes = photos.photos[0];
      photoSource = sizes[sizes.length - 1].file_id; // ambil resolusi paling tinggi
    }
  } catch (e) {
    console.error("[profile] Gagal ambil foto profil user:", e.message);
  }

  const backBtn = { text: `${toBoldSans("‹‹‹")}`, callback_data: "back" };
  const limitBtn = { text: `${toBoldSans("⌗ Limit Saya")}`, callback_data: "limit_mine" };

  try {
    await bot.editMessageMedia(
      { type: "photo", media: photoSource, caption: profileText, parse_mode: "HTML" },
      { chat_id: chatId, message_id: messageId, reply_markup: { inline_keyboard: [[limitBtn], [backBtn]] } }
    );
  } catch (e) {
    // Kalau gagal edit media (mis. pesan asal bukan foto), kirim sebagai pesan foto baru
    await bot.sendPhoto(chatId, photoSource, {
      caption: profileText,
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: [[limitBtn], [backBtn]] },
    });
  }
});

// ================= BROADCAST (KHUSUS DEV) =================
function isBroadcastDev(userId) {
  return settings.isOwner(userId);
}

function getAllStartedUsers() {
  try {
    const list = JSON.parse(fs.readFileSync(usersFile));
    // normalisasi jadi string unik, buang entry kosong/duplikat
    return [...new Set(list.map((id) => String(id).trim()).filter(Boolean))];
  } catch {
    return [];
  }
}

async function runBroadcast(bot, fromChatId, sourceMessageId) {
  const targets = getAllStartedUsers();

  if (targets.length === 0) {
    return bot.sendMessage(fromChatId, "<blockquote expandable>◈ <b>Tidak Ada Target</b>\nBelum ada user yang start bot di private chat.</blockquote>");
  }

  const statusMsg = await bot.sendMessage(
    fromChatId,
    `⏳ Memulai broadcast ke <b>${targets.length}</b> pengguna...\n◉ Terkirim: 0\n◇ Gagal: 0`,
    { parse_mode: "HTML" }
  );

  let success = 0;
  let failed = 0;
  const deadIds = []; // ID yang chat-nya ga ketemu / user block bot -> layak dibersihkan dari db
  const errorSamples = {}; // ringkasan alasan gagal, biar gampang didiagnosis
  const skippedBots = []; // Telegram memang melarang bot mengirim ke bot lain

  // Cache tipe chat supaya target bot tidak perlu dicoba copyMessage terlebih dahulu.
  // USER_BOT_TO_BOT_DISABLED adalah batasan Bot API, bukan error implementasi.
  const chatTypeCache = new Map();

  for (let i = 0; i < targets.length; i++) {
    const targetId = targets[i];

    try {
      let chatType = chatTypeCache.get(String(targetId));
      if (!chatType) {
        try {
          const chat = await bot.getChat(targetId);
          chatType = String(chat?.type || '').toLowerCase();
          chatTypeCache.set(String(targetId), chatType);
        } catch {
          // Jika getChat gagal, tetap coba copyMessage agar error asli
          // bisa diklasifikasikan di catch di bawah.
        }
      }

      if (chatType === 'bot') {
        skippedBots.push(targetId);
        continue;
      }

      await bot.copyMessage(targetId, fromChatId, sourceMessageId);
      success++;
    } catch (err) {
      const reason = err?.response?.body?.description || err.message || "unknown error";

      // Jangan menghitung larangan bot-to-bot sebagai kegagalan broadcast.
      // Target tersebut tidak dapat menerima pesan dari bot ini berdasarkan
      // kebijakan Telegram Bot API.
      if (/USER_BOT_TO_BOT_DISABLED/i.test(reason)) {
        skippedBots.push(targetId);
        continue;
      }

      failed++;
      errorSamples[reason] = (errorSamples[reason] || 0) + 1;
      if (/chat not found|blocked|deactivated|user is deactivated/i.test(reason)) {
        deadIds.push(targetId);
      }
    }

    // update progress tiap 15 pengguna biar ga kena flood limit edit message
    if (i % 15 === 0 || i === targets.length - 1) {
      await bot.editMessageText(
        `⏳ Broadcast berjalan... (${i + 1}/${targets.length})\n◉ Terkirim: ${success}\n◇ Gagal: ${failed}`,
        { chat_id: fromChatId, message_id: statusMsg.message_id }
      ).catch(() => {});
    }

    // jeda kecil biar aman dari rate limit Telegram
    await new Promise((r) => setTimeout(r, 120));
  }

  // Bersihkan ID mati (chat not found / blocked / deactivated) dari users.json
  if (deadIds.length > 0) {
    try {
      const deadSet = new Set(deadIds.map(String));
      const remaining = getAllStartedUsers().filter((id) => !deadSet.has(String(id)));
      fs.writeFileSync(usersFile, JSON.stringify(remaining, null, 2));
    } catch (e) {
      console.error("[broadcast] Gagal bersihin dead ID:", e.message);
    }
  }

  const reasonLines = Object.entries(errorSamples)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([reason, count]) => `• ${reason} (${count}x)`)
    .join("\n");

  let summary = `◉ <b>Broadcast selesai!</b>\n\n⌁ Total target: ${targets.length}\n◉ Berhasil: ${success}\n◇ Gagal: ${failed}`;
  if (skippedBots.length > 0) {
    summary += `\n◇ Dilewati (akun bot): ${skippedBots.length}`;
  }
  if (deadIds.length > 0) {
    summary += `\n↺ ${deadIds.length} ID mati (chat not found/blocked) sudah dibersihkan dari database.`;
  }
  if (reasonLines) {
    summary += `\n\n<b>Alasan gagal:</b>\n${reasonLines}`;
  }

  // Diagnostik: kalau SEMUA target gagal dengan "chat not found", ini nyaris selalu
  // bukan bug di kode broadcast, tapi karena users.json berisi ID lama/bawaan
  // (misal dari instalasi/bot lain) yang belum pernah /start ke BOT TOKEN yang
  // sekarang aktif. Kode broadcast cuma bisa kirim ke chat yang sudah pernah
  // dibuka user dengan bot ini.
  if (success === 0 && targets.length > 0 && /chat not found/i.test(reasonLines)) {
    summary += `\n\n△ <b>Diagnosa:</b> Semua target gagal dengan "chat not found". Ini biasanya berarti ID di <code>db/users/users.json</code> belum pernah /start ke bot dengan TOKEN yang sekarang aktif (misal token baru, atau file db ini dibawa dari instalasi lain). Solusi: kosongkan <code>users.json</code> lalu minta user mengetik /start ke bot ini supaya ID mereka tercatat ulang, baru broadcast akan berhasil.`;
  }

  await bot.editMessageText(summary, {
    chat_id: fromChatId, message_id: statusMsg.message_id, parse_mode: "HTML"
  }).catch(() => {});
}

bot.on("callback_query", (callbackQuery) => {
  if (callbackQuery.data === "broadcastmenu") {
    const userId = callbackQuery.from.id;

    if (!isBroadcastDev(userId)) {
      return bot.answerCallbackQuery(callbackQuery.id, {
        text: "◇ Khusus Dev!",
        show_alert: true
      });
    }

    bot.answerCallbackQuery(callbackQuery.id);

    broadcastState[userId] = { waiting: true };

    bot.sendMessage(
      callbackQuery.message.chat.id,
      "► <b>Mode Broadcast</b>\n\nKirim/reply pesan yang ingin di-broadcast sekarang (bisa teks, foto, video, dsb).\nPesan akan dikirim ke semua PV yang sudah start bot.\n\nKetik /batal untuk membatalkan.",
      {
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [[{ text: `${toBoldSans("⊠ Batal")}`, callback_data: "broadcast_cancel" }]]
        }
      }
    );
  }
});

bot.on("callback_query", (callbackQuery) => {
  if (callbackQuery.data === "broadcast_cancel") {
    const userId = callbackQuery.from.id;

    if (!isBroadcastDev(userId)) {
      return bot.answerCallbackQuery(callbackQuery.id, {
        text: "◇ Khusus Dev!",
        show_alert: true
      });
    }

    delete broadcastState[userId];
    bot.answerCallbackQuery(callbackQuery.id, { text: "Broadcast dibatalkan." });
    bot.editMessageText("◇ Broadcast dibatalkan.", {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id
    }).catch(() => {});
  }
});

// Trigger via command langsung, selain lewat tombol
bot.onText(/^\/broadcast$/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (!isBroadcastDev(userId)) {
    return bot.sendMessage(chatId, "◇ Khusus Dev!");
  }

  broadcastState[userId] = { waiting: true };

  bot.sendMessage(
    chatId,
    "► <b>Mode Broadcast</b>\n\nKirim/reply pesan yang ingin di-broadcast sekarang (bisa teks, foto, video, dsb).\nPesan akan dikirim ke semua PV yang sudah start bot.\n\nKetik /batal untuk membatalkan.",
    {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [[{ text: `${toBoldSans("⊠ Batal")}`, callback_data: "broadcast_cancel" }]]
      }
    }
  );
});

bot.on("message", async (msg) => {
  const userId = msg.from?.id;
  if (!userId || !broadcastState[userId] || !broadcastState[userId].waiting) return;
  if (!isBroadcastDev(userId)) return;

  const chatId = msg.chat.id;

  if (msg.text === "/batal") {
    delete broadcastState[userId];
    return bot.sendMessage(chatId, "◇ Broadcast dibatalkan.");
  }

  if (msg.text === "/broadcast") return; // hindari trigger ulang command-nya sendiri

  // matikan mode nunggu dulu biar ga ke-trigger dobel
  delete broadcastState[userId];

  await runBroadcast(bot, chatId, msg.message_id);
});
// ============================================================
// ENCRYPT MENU
// ============================================================
bot.on("callback_query", async (callbackQuery) => {
  if (callbackQuery.data !== "encryptmenu") return;

  const chatId = callbackQuery.message.chat.id;
  const messageId = callbackQuery.message.message_id;

  const text =
    `<b>ENCRYPT</b>\n` +
    `<blockquote expandable>` +
    `<b>JavaScript Obfuscator</b>\n` +
    `Lindungi source JavaScript dengan beberapa preset enkripsi.\n\n` +
    `<b>Cara pakai</b>\n` +
    `Balas file <code>.js</code>, lalu pilih preset di bawah.` +
    `</blockquote>`;

  const btn = (text, cb) => theme.styled({ text: toBoldSans(text), callback_data: cb }, theme.getTheme());

  await bot.answerCallbackQuery(callbackQuery.id);
  await bot.editMessageCaption(text, {
    chat_id: chatId,
    message_id: messageId,
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [btn("Basic", "enc_help_basic"), btn("Strong", "enc_help_strong")],
        [btn("Nova", "enc_help_nova"), btn("Ultra", "enc_help_ultra")],
        [btn("Custom", "enc_help_custom"), btn("Time Locked", "enc_help_locked")],
        [btn("China", "enc_help_china"), btn("Japan", "enc_help_japan")],
        [btn("‹ Kembali", "back")]
      ]
    }
  }).catch(async () => {
    await bot.editMessageText(text, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [btn("Basic", "enc_help_basic"), btn("Strong", "enc_help_strong")],
          [btn("Nova", "enc_help_nova"), btn("Ultra", "enc_help_ultra")],
          [btn("Custom", "enc_help_custom"), btn("Time Locked", "enc_help_locked")],
          [btn("China", "enc_help_china"), btn("Japan", "enc_help_japan")],
          [btn("‹ Kembali", "back")]
        ]
      }
    }).catch(() => {});
  });
});

bot.on("callback_query", async (callbackQuery) => {
  const help = {
    enc_help_basic: ["Basic", "<code>/enc low</code>, <code>/enc medium</code>, atau <code>/enc high</code>"],
    enc_help_strong: ["Strong", "<code>/encstrong</code>"],
    enc_help_nova: ["Nova", "<code>/encnova</code>"],
    enc_help_ultra: ["Ultra", "<code>/encultra</code>"],
    enc_help_custom: ["Custom", "<code>/customenc NamaKustom</code>"],
    enc_help_locked: ["Time Locked", "<code>/enclocked 7</code>"],
    enc_help_china: ["China", "<code>/encchina</code>"],
    enc_help_japan: ["Japan", "<code>/encjapan</code>"]
  };
  const item = help[callbackQuery.data];
  if (!item) return;

  await bot.answerCallbackQuery(callbackQuery.id);
  const [title, usage] = item;
  const text =
    `<b>ENCRYPT · ${title}</b>\n` +
    `<blockquote expandable>` +
    `${usage}\n\n` +
    `Balas file <code>.js</code> dengan perintah tersebut.` +
    `</blockquote>`;

  const kb = { inline_keyboard: [[
    { text: toBoldSans("‹‹‹"), callback_data: "encryptmenu" }
  ]]};

  await bot.editMessageCaption(text, {
    chat_id: callbackQuery.message.chat.id,
    message_id: callbackQuery.message.message_id,
    parse_mode: "HTML",
    reply_markup: kb
  }).catch(() => {});
  await bot.editMessageText(text, {
    chat_id: callbackQuery.message.chat.id,
    message_id: callbackQuery.message.message_id,
    parse_mode: "HTML",
    reply_markup: kb
  }).catch(() => {});
});


// ===== PRIVATE CPANEL OWNER+ CALLBACKS =====
function isOwnerPlusMenu(userId) {
  const uid = String(userId);
  if (settings.isOwner(uid)) return true;
  const files = [
    "./db/users/adminID.json",
    "./db/users/rootUsers.json",
    "./db/users/founderUsers.json",
    "./db/users/developerUsers.json"
  ];
  return files.some((file) => {
    try {
      if (!fs.existsSync(file)) return false;
      const data = JSON.parse(fs.readFileSync(file, "utf8"));
      return Array.isArray(data) && data.map(String).includes(uid);
    } catch {
      return false;
    }
  });
}

bot.on("callback_query", async (callbackQuery) => {
  if (callbackQuery.data !== "private_cpanel_info") return;
  await bot.answerCallbackQuery(callbackQuery.id).catch(() => {});

  if (!isOwnerPlusMenu(callbackQuery.from.id)) {
    return bot.sendMessage(
      callbackQuery.message.chat.id,
      "⛔ <b>PRIVATE CPANEL</b>\n\nFitur ini khusus <b>OWNER / FOUNDER+</b>.",
      { parse_mode: "HTML" }
    );
  }

  const text = `<blockquote expandable><b>▣ PRIVATE CPANEL</b>

Fitur Private CPanel dari modul Naeri telah diaktifkan.

<b>OWNER / FOUNDER+</b> dapat menggunakan:
• /cadmin — buat admin panel
• /listcadmin — daftar admin panel
• /cunli — buat server unlimited
• /pinfo — informasi panel
• /srvlist — daftar server
• /totalsrv — total server
• /srvcpu — monitoring CPU
• /srvofflist — daftar server offline
• /srvoffdel — hapus data server offline
• /srvdel — hapus server
• /1gbp sampai /10gbp — buat panel sesuai resource

Semua command Private CPanel dibatasi otomatis ke OWNER / FOUNDER+.</blockquote>`;

  return bot.sendMessage(callbackQuery.message.chat.id, text, {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [{ text: "▣ Buka Private CPanel", callback_data: "private_cpanel_commands" }],
        [{ text: "‹‹‹", callback_data: "ownermenu" }]
      ]
    }
  });
});

bot.on("callback_query", async (callbackQuery) => {
  if (callbackQuery.data !== "private_cpanel_commands") return;
  await bot.answerCallbackQuery(callbackQuery.id).catch(() => {});

  if (!isOwnerPlusMenu(callbackQuery.from.id)) return;

  const text = `<blockquote expandable><b>▣ PRIVATE CPANEL — COMMANDS</b>

<b>ADMIN</b>
/cadmin nama,id
/listcadmin

<b>SERVER</b>
/cunli nama,id
/srvlist
/totalsrv
/srvcpu
/srvofflist
/srvoffdel
/srvdel id

<b>RESOURCE</b>
/1gbp nama,id
/2gbp nama,id
/3gbp nama,id
/4gbp nama,id
/5gbp nama,id
/6gbp nama,id
/7gbp nama,id
/8gbp nama,id
/9gbp nama,id
/10gbp nama,id

Gunakan command langsung di private chat bot.</blockquote>`;

  return bot.sendMessage(callbackQuery.message.chat.id, text, {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[{ text: "‹‹‹", callback_data: "private_cpanel_info" }]]
    }
  });
});

}
