/**
 * webserver.js — Panel Mini App HTTP server
 * Serve login.html & dashboard.html + REST API untuk auth
 */

const http    = require("http");
const fs      = require("fs");
const path    = require("path");
const crypto  = require("crypto");
const bcrypt  = require("bcryptjs");

const WEBPANEL_DIR = path.join(__dirname, "..", "webpanel");
const DB_PANEL_PW  = path.join(__dirname, "..", "db", "panelPasswords.json");

// ─── DB helpers ─────────────────────────────────────────────────────────────
function readPanelDb() {
  try {
    if (!fs.existsSync(DB_PANEL_PW)) fs.writeFileSync(DB_PANEL_PW, "{}", "utf8");
    return JSON.parse(fs.readFileSync(DB_PANEL_PW, "utf8"));
  } catch { return {}; }
}
function writePanelDb(data) {
  fs.writeFileSync(DB_PANEL_PW, JSON.stringify(data, null, 2), "utf8");
}

// ─── JWT minimal (HMAC-SHA256) ───────────────────────────────────────────────
function jwtSecret(botToken) {
  return crypto.createHmac("sha256", "panel_jwt_secret").update(botToken).digest("hex");
}
function signToken(payload, secret) {
  const header  = Buffer.from(JSON.stringify({ alg:"HS256", typ:"JWT" })).toString("base64url");
  const body    = Buffer.from(JSON.stringify(payload)).toString("base64url");
  const sig     = crypto.createHmac("sha256", secret).update(`${header}.${body}`).digest("base64url");
  return `${header}.${body}.${sig}`;
}
function verifyToken(token, secret) {
  try {
    const [h, b, s] = token.split(".");
    const expected  = crypto.createHmac("sha256", secret).update(`${h}.${b}`).digest("base64url");
    if (s !== expected) return null;
    const payload = JSON.parse(Buffer.from(b, "base64url").toString());
    if (payload.exp && Date.now() > payload.exp) return null;
    return payload;
  } catch { return null; }
}

// ─── Telegram initData validator ────────────────────────────────────────────
function validateInitData(initData, botToken) {
  try {
    if (!initData) return false;
    const params  = new URLSearchParams(initData);
    const hash    = params.get("hash");
    if (!hash) return false;
    params.delete("hash");
    const checkStr = [...params.entries()].sort((a,b) => a[0].localeCompare(b[0]))
      .map(([k,v]) => `${k}=${v}`).join("\n");
    const secret   = crypto.createHmac("sha256","WebAppData").update(botToken).digest();
    const expected = crypto.createHmac("sha256", secret).update(checkStr).digest("hex");
    return expected === hash;
  } catch { return false; }
}

// ─── Detect role dari db SC ──────────────────────────────────────────────────
function detectRole(telegramId) {
  const id  = String(telegramId);
  const DB  = path.join(__dirname, "..", "db", "users");
  const check = (file) => {
    try {
      const arr = JSON.parse(fs.readFileSync(path.join(DB, file), "utf8"));
      return arr.map(String).includes(id);
    } catch { return false; }
  };
  const admins = (() => {
    try { return JSON.parse(fs.readFileSync(path.join(DB, "adminID.json"),"utf8")).map(String); } catch { return []; }
  })();
  if (admins.includes(id)) return "owner";
  if (check("ceoUsers.json"))       return "ceo";
  if (check("tkUsers.json"))        return "tk";
  if (check("ptUsers.json"))        return "pt";
  if (check("resellerUsers.json"))  return "reseller";
  if (check("premiumUsers.json"))   return "premium";
  if (check("users.json"))          return "user";
  return null; // belum terdaftar
}

// ─── HTTP routing ────────────────────────────────────────────────────────────
function serveFile(res, filePath, contentType) {
  try {
    const content = fs.readFileSync(filePath);
    res.writeHead(200, { "Content-Type": contentType });
    res.end(content);
  } catch {
    res.writeHead(404); res.end("Not found");
  }
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = "";
    req.on("data", chunk => data += chunk);
    req.on("end", () => {
      try { resolve(JSON.parse(data)); } catch { resolve({}); }
    });
    req.on("error", reject);
  });
}

function jsonRes(res, status, obj) {
  res.writeHead(status, { "Content-Type": "application/json" });
  res.end(JSON.stringify(obj));
}

function getBearerToken(req) {
  const auth = req.headers["authorization"] || "";
  return auth.startsWith("Bearer ") ? auth.slice(7) : null;
}

// ─── Exports ─────────────────────────────────────────────────────────────────
module.exports = function(bot) {
  const settings   = require("../settings");
  const BOT_TOKEN  = '8853303612:AAGuCGNyZnYwrq3_P1KsvJMDTFAE8e_Dl1o'
  const SECRET     = jwtSecret(BOT_TOKEN);
  const PORT       = settings.webpanel && settings.webpanel.port ? settings.webpanel.port : 3000;

  const server = http.createServer(async (req, res) => {
    const url    = req.url.split("?")[0];
    const method = req.method;

    // CORS (untuk testing dari browser)
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
    if (method === "OPTIONS") { res.writeHead(200); res.end(); return; }

    // ── Static pages ──────────────────────────────────────────────────────────
    if (method === "GET" && (url === "/" || url === "/login" || url === "/index.html")) {
      return serveFile(res, path.join(WEBPANEL_DIR, "login.html"), "text/html; charset=utf-8");
    }
    if (method === "GET" && url === "/dashboard") {
      return serveFile(res, path.join(WEBPANEL_DIR, "dashboard.html"), "text/html; charset=utf-8");
    }

    // ── API: POST /api/panel/login ────────────────────────────────────────────
    if (method === "POST" && url === "/api/panel/login") {
      const body     = await readBody(req);
      const { username, password, initData } = body;

      if (!username || !password) {
        return jsonRes(res, 400, { ok: false, message: "Username dan password wajib diisi." });
      }

      const db = readPanelDb();

      // cari user berdasarkan username atau telegramId
      const entry = Object.values(db).find(u =>
        String(u.username).toLowerCase() === String(username).toLowerCase() ||
        String(u.telegramId) === String(username)
      );

      if (!entry) {
        return jsonRes(res, 401, { ok: false, message: "Akun tidak ditemukan. Ketik /setpanelpw di bot dulu." });
      }

      const match = await bcrypt.compare(password, entry.passwordHash);
      if (!match) {
        return jsonRes(res, 401, { ok: false, message: "Password salah." });
      }

      // update role dari db SC realtime
      const role = detectRole(entry.telegramId) || entry.role || "user";

      const token = signToken({
        telegramId: entry.telegramId,
        username:   entry.username,
        role,
        exp: Date.now() + 24 * 60 * 60 * 1000  // 24 jam
      }, SECRET);

      return jsonRes(res, 200, {
        ok: true,
        token,
        user: { telegramId: entry.telegramId, username: entry.username, role }
      });
    }

    // ── API: GET /api/panel/me ────────────────────────────────────────────────
    if (method === "GET" && url === "/api/panel/me") {
      const tok     = getBearerToken(req);
      const payload = tok ? verifyToken(tok, SECRET) : null;
      if (!payload) return jsonRes(res, 401, { ok: false, message: "Token tidak valid atau kadaluarsa." });

      const role = detectRole(payload.telegramId) || payload.role || "user";
      return jsonRes(res, 200, {
        ok: true,
        user: { telegramId: payload.telegramId, username: payload.username, role }
      });
    }

    // ── 404 ───────────────────────────────────────────────────────────────────
    res.writeHead(404, { "Content-Type": "text/plain" });
    res.end("Not found");
  });

  server.listen(PORT, () => {
    console.log(`\x1b[32m◉ Webpanel running → http://localhost:${PORT}\x1b[0m`);
  });

  server.on("error", (err) => {
    console.error(`\x1b[31m◇ Webpanel error: ${err.message}\x1b[0m`);
  });

  // expose helper untuk bot command /setpanelpw
  module.exports._setPassword = async function(telegramId, username, rawPassword) {
    const hash  = await bcrypt.hash(rawPassword, 10);
    const db    = readPanelDb();
    const role  = detectRole(telegramId) || "user";
    db[String(telegramId)] = {
      telegramId: String(telegramId),
      username:   String(username || telegramId),
      passwordHash: hash,
      role,
      updatedAt: new Date().toISOString()
    };
    writePanelDb(db);
  };
};
