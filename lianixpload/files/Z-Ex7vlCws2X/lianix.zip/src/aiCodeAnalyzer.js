/**
 * ============================================================
 * LianiX — AI Code Analyzer & Auto-Patcher + AI Chat
 * ------------------------------------------------------------
 * ENGINE: Pollinations AI (text.pollinations.ai) — gratis, tanpa key
 *
 * FITUR:
 *  1. Upload .zip → tombol [AI Analisis] + [AI Fix & Download]
 *  2. /ai <pesan>          → chat ke model aktif user
 *  3. /modelai             → tampilkan semua model + tombol pilih
 *  4. Shortcut per-model:
 *       /chatgptai  /geminiflash  /deepseekr1
 *       /gptbig  /deepseek  /mistralai
 * ============================================================
 */

'use strict';

const fs      = require('fs');
const path    = require('path');
const os      = require('os');
const crypto  = require('crypto');
const axios   = require('axios');
const AdmZip  = require('adm-zip');
const settings = require('../settings.js');

// ── Config ────────────────────────────────────────────────
const MAX_ZIP_MB    = 20;
const MAX_JS_BYTES  = 80_000;
const MAX_FILES     = 40;
const TMP_DIR       = path.join(os.tmpdir(), 'lianix-aicode');
const OWNER_ID      = String(settings.ownerId || '');

// ── Session: zip upload ───────────────────────────────────
const SESSION     = new Map();
const SESSION_TTL = 30 * 60 * 1000;

// ── Session: model pilihan per-user ──────────────────────
const USER_MODEL  = new Map();  // userId → modelId
const DEFAULT_MODEL = 'openai/gpt-4o-mini';

// ── Session: AI Chat (reply-based, multi-turn) ────────────
// Struktur: { history: [{role,content}], botMsgId, ts }
const CHAT_SESSION     = new Map();  // userId → session /ai
const HAIKU_SESSION    = new Map();  // userId → session /haiku
const CHAT_SESSION_TTL = 60 * 60 * 1000; // 1 jam

function getChatSession(store, userId) {
  const s = store.get(String(userId));
  if (!s) return null;
  if (Date.now() - s.ts > CHAT_SESSION_TTL) { store.delete(String(userId)); return null; }
  return s;
}

function saveChatSession(store, userId, data) {
  store.set(String(userId), { ...data, ts: Date.now() });
}

function clearChatSession(store, userId) {
  store.delete(String(userId));
}

// Cek apakah msg adalah reply ke pesan bot yang punya session
// Kalau ya → return session, kalau tidak → return null (fresh)
function resolveSession(store, userId, msg, botId) {
  const replyTo = msg?.reply_to_message;
  if (!replyTo) return null; // tidak reply → fresh
  if (String(replyTo.from?.id) !== String(botId)) return null; // reply bukan ke bot → fresh
  const s = getChatSession(store, userId);
  if (!s) return null;
  if (String(s.botMsgId) !== String(replyTo.message_id)) return null; // reply ke pesan bot lain → fresh
  return s;
}

// ── Model registry (Pollinations AI — gratis tanpa key) ───
const MODEL_REGISTRY = [
  { id: 'openai/gpt-4o-mini',            name: 'ChatGPT (Default)',       short: 'gpt',          cmd: 'chatgptai',    premium: false },
  { id: 'openai/gpt-oss-120b',           name: 'GPT Large (120B)',        short: 'gptbig',       cmd: 'gptbig',       premium: false },
  { id: 'google/gemini-2.5-flash-lite',  name: 'Gemini Flash',           short: 'gemini',       cmd: 'geminiflash',  premium: false },
  { id: 'deepseek/deepseek-v4-flash',    name: 'DeepSeek V4 Flash',      short: 'deepseek',     cmd: 'deepseek',     premium: false },
  { id: 'deepseek/deepseek-v3.2',        name: 'DeepSeek R1 (Think)',    short: 'dsr1',         cmd: 'deepseekr1',   premium: false },
  { id: 'mistralai/mistral-small-2603',  name: 'Mistral Small',          short: 'mistral',      cmd: 'mistralai',    premium: false },
];

// ── AI Chat — Pollinations (gratis, tanpa key) ───────────
// Primary: text.pollinations.ai  |  Fallback: duckduckgo AI proxy
async function mimoChat(messages, modelId = DEFAULT_MODEL) {
  // Map model registry ID ke nama model Pollinations / fallback label
  const POLLINATIONS_MODEL_MAP = {
    'openai/gpt-4o-mini':           'openai',
    'openai/gpt-4.1-nano':          'openai',
    'openai/gpt-5-nano':            'openai',
    'openai/gpt-oss-120b':          'openai-large',
    'google/gemini-2.5-flash-lite': 'gemini',
    'google/gemma-4-26b-a4b-it':    'gemini',
    'google/gemma-3-27b-it':        'gemini',
    'deepseek/deepseek-v4-flash':   'deepseek',
    'deepseek/deepseek-v4-pro':     'deepseek',
    'deepseek/deepseek-v3.2':       'deepseek-r1',
    'xiaomi/mimo-v2.5':             'openai',
    'xiaomi/mimo-v2-flash':         'openai',
    'xiaomi/mimo-v2.5-pro':         'openai-large',
    'mistralai/mistral-small-2603': 'mistral',
    'z-ai/glm-4.7-flash':           'openai',
    'z-ai/glm-4.7':                 'openai-large',
    'ibm-granite/granite-4.1-8b':   'openai',
    'inclusionai/ling-2.6-flash':   'openai',
    'rekaai/reka-edge':             'openai',
    'inception/mercury-2':          'openai-large',
  };

  const pollModel = POLLINATIONS_MODEL_MAP[modelId] || 'openai';

  // Pollinations text API — GET endpoint, gratis tanpa auth
  const lastMsg = messages[messages.length - 1]?.content || '';
  const systemMsg = messages.find(m => m.role === 'system')?.content || '';
  const userPrompt = systemMsg ? `${systemMsg}\n\n${lastMsg}` : lastMsg;

  try {
    const url = `https://text.pollinations.ai/${encodeURIComponent(userPrompt)}?model=${pollModel}&seed=${Math.floor(Math.random()*99999)}&json=false`;
    const resp = await axios.get(url, {
      timeout: 90_000,
      responseType: 'text',
      headers: { 'Accept': 'text/plain' },
    });
    const text = String(resp.data || '').trim();
    if (!text) throw new Error('Pollinations: respons kosong');
    return text;
  } catch (primaryErr) {
    // Fallback: Pollinations POST (multi-turn support)
    try {
      const body = {
        messages: messages.length > 0 ? messages : [{ role: 'user', content: userPrompt }],
        model: pollModel,
        seed: Math.floor(Math.random() * 99999),
        stream: false,
      };
      const resp2 = await axios.post('https://text.pollinations.ai/', body, {
        timeout: 90_000,
        responseType: 'text',
        headers: { 'Content-Type': 'application/json', 'Accept': 'text/plain' },
      });
      const text2 = String(resp2.data || '').trim();
      if (!text2) throw new Error('Pollinations POST: respons kosong');
      return text2;
    } catch (pollPostErr) {
      // Fallback API terkonfigurasi. Dipakai hanya jika key tersedia.
      if (process.env.OPENROUTER_API_KEY) {
        try {
          const rr = await axios.post('https://openrouter.ai/api/v1/chat/completions', {
            model: process.env.OPENROUTER_MODEL || 'openai/gpt-4o-mini',
            messages,
            temperature: 0.1,
          }, { timeout: 90_000, headers: { Authorization: `Bearer ${process.env.OPENROUTER_API_KEY}`, 'Content-Type': 'application/json' } });
          const result = rr.data?.choices?.[0]?.message?.content;
          if (result) return String(result).trim();
        } catch {}
      }
      if (process.env.GROQ_API_KEY) {
        try {
          const rr = await axios.post('https://api.groq.com/openai/v1/chat/completions', {
            model: process.env.GROQ_MODEL || 'llama-3.3-70b-versatile',
            messages,
            temperature: 0.1,
          }, { timeout: 90_000, headers: { Authorization: `Bearer ${process.env.GROQ_API_KEY}`, 'Content-Type': 'application/json' } });
          const result = rr.data?.choices?.[0]?.message?.content;
          if (result) return String(result).trim();
        } catch {}
      }
      // Last fallback: public provider.
      const fallUrl = `https://piereeapi.vercel.app/ai/gpt4o?prompt=${encodeURIComponent(userPrompt)}`;
      const fr = await axios.get(fallUrl, { timeout: 60_000 });
      const result = fr.data?.result || fr.data?.response || fr.data?.text;
      if (!result) throw new Error(`AI tidak tersedia. Error utama: ${primaryErr.message}; fallback: ${pollPostErr.message}`);
      return String(result).trim();
    }
  }
}

// ── Helpers ───────────────────────────────────────────────
function esc(v = '') {
  return String(v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}
function isOwner(userId) { return String(userId) === OWNER_ID; }
function fmtSize(b) {
  if (b < 1024) return `${b} B`;
  if (b < 1048576) return `${(b/1024).toFixed(1)} KB`;
  return `${(b/1048576).toFixed(2)} MB`;
}
function shortId() { return crypto.randomBytes(4).toString('hex'); }
function ensureTmp() { fs.mkdirSync(TMP_DIR, { recursive: true }); }

function getModelById(id) { return MODEL_REGISTRY.find(m => m.id === id); }
function getUserModel(userId) { return USER_MODEL.get(String(userId)) || DEFAULT_MODEL; }
function setUserModel(userId, modelId) { USER_MODEL.set(String(userId), modelId); }

// ── Zip helpers ───────────────────────────────────────────
function readZipFiles(buffer) {
  const zip = new AdmZip(buffer);
  const files = [];
  for (const entry of zip.getEntries()) {
    if (entry.isDirectory) continue;
    const name = entry.entryName;
    if (!/\.(js|json)$/i.test(name)) continue;
    if (/node_modules[\\/]/.test(name)) continue;
    const raw = entry.getData();
    files.push({
      entryName: name,
      content: raw.toString('utf8').slice(0, MAX_JS_BYTES),
      size: raw.length,
      truncated: raw.length > MAX_JS_BYTES,
    });
    if (files.length >= MAX_FILES) break;
  }
  return files;
}

function rebuildZip(originalBuffer, patches) {
  const zip = new AdmZip(originalBuffer);
  for (const { entryName, newContent } of patches) {
    zip.updateFile(entryName, Buffer.from(newContent, 'utf8'));
  }
  return zip.toBuffer();
}

async function downloadZip(bot, fileId) {
  const file = await bot.getFile(fileId);
  const url  = `https://api.telegram.org/file/bot${settings.token}/${file.file_path}`;
  const resp = await axios.get(url, {
    responseType: 'arraybuffer',
    timeout: 60_000,
    maxContentLength: MAX_ZIP_MB * 1048576,
    maxBodyLength:    MAX_ZIP_MB * 1048576,
  });
  return Buffer.from(resp.data);
}

// ── Session (zip) ─────────────────────────────────────────
function saveSession(userId, data) {
  SESSION.set(String(userId), { ...data, ts: Date.now() });
}
function getSession(userId) {
  const s = SESSION.get(String(userId));
  if (!s || Date.now() - s.ts > SESSION_TTL) { SESSION.delete(String(userId)); return null; }
  return s;
}

// ── Prompts ───────────────────────────────────────────────
function buildAnalyzePrompt(files) {
  const chunks = files.map(f =>
    `=== FILE: ${f.entryName} (${fmtSize(f.size)}${f.truncated ? ', DIPOTONG' : ''}) ===\n${f.content}`
  ).join('\n\n');

  return `Kamu adalah senior Node.js code reviewer untuk bot Telegram.
Analisis kode berikut dari project bot Telegram (node-telegram-bot-api).
Temukan: BUG, SECURITY ISSUE, PERFORMANCE PROBLEM, DEAD CODE, SARAN PERBAIKAN.

Format jawaban:
## RINGKASAN
## TEMUAN KRITIS
## TEMUAN SEDANG
## SARAN PERBAIKAN
## KESIMPULAN

Bahasa Indonesia. Langsung ke poin.

KODE:
${chunks}`;
}

function buildFixPrompt(files) {
  const chunks = files.map(f =>
    `=== FILE: ${f.entryName} ===\n${f.content}`
  ).join('\n\n');

  return `Kamu adalah senior Node.js developer. PERBAIKI kode berikut dari bot Telegram.

ATURAN:
- Hanya perbaiki masalah nyata (bug, error, security, crash)
- Jangan ubah logika bisnis yang benar
- Jangan tambah dependensi baru
- Semua async/await harus benar

OUTPUT FORMAT (ikuti persis):
Untuk setiap file yang DIUBAH:
<<<FILE:nama/file.js>>>
[isi file lengkap setelah diperbaiki]
<<<ENDFILE>>>

Setelah semua file:
<<<LAPORAN>>>
[ringkasan singkat apa yang diperbaiki]
<<<ENDLAPORAN>>>

KODE:
${chunks}`;
}

function parseFixes(aiResponse) {
  const patches = [];
  const fileRegex = /<<<FILE:([^>]+)>>>([\s\S]*?)<<<ENDFILE>>>/g;
  let match;
  while ((match = fileRegex.exec(aiResponse)) !== null)
    patches.push({ entryName: match[1].trim(), newContent: match[2].trim() });

  const lm = /<<<LAPORAN>>>([\s\S]*?)<<<ENDLAPORAN>>>/.exec(aiResponse);
  return { patches, laporan: lm ? lm[1].trim() : '' };
}

// ── Keyboards ─────────────────────────────────────────────
function zipKeyboard(userId) {
  return {
    inline_keyboard: [[
      { text: 'AI Analisis', callback_data: `aica:analyze:${userId}` },
      { text: 'AI Fix & Download', callback_data: `aica:fix:${userId}` },
    ]],
  };
}

function modelListKeyboard() {
  // Bagi model jadi baris 2 kolom
  const rows = [];
  for (let i = 0; i < MODEL_REGISTRY.length; i += 2) {
    const row = [];
    for (let j = i; j < Math.min(i + 2, MODEL_REGISTRY.length); j++) {
      const m = MODEL_REGISTRY[j];
      const label = `${m.premium ? '⭐' : '○'} ${m.name}`;
      row.push({ text: label, callback_data: `aimodel:${m.id}` });
    }
    rows.push(row);
  }
  return { inline_keyboard: rows };
}

function modelListText(userId) {
  const cur = getUserModel(userId);
  const curM = getModelById(cur);
  let txt = `<b>🤖 PILIH MODEL AI</b>\n`;
  txt += `<i>Model aktif: <b>${esc(curM?.name || cur)}</b></i>\n\n`;
  txt += `<b>Shortcut command:</b>\n`;

  // Group by provider
  const byProvider = {};
  for (const m of MODEL_REGISTRY) {
    if (!byProvider[m.id.split('/')[0]]) byProvider[m.id.split('/')[0]] = [];
    byProvider[m.id.split('/')[0]].push(m);
  }

  const providerNames = {
    'xiaomi': 'Xiaomi', 'deepseek': 'DeepSeek', 'google': 'Google',
    'openai': 'OpenAI', 'z-ai': 'Z.AI', 'ibm-granite': 'IBM',
    'inclusionai': 'InclusionAI', 'mistralai': 'MistralAI',
    'rekaai': 'RekaAI', 'inception': 'Inception'
  };

  for (const [prov, models] of Object.entries(byProvider)) {
    txt += `\n<b>${esc(providerNames[prov] || prov)}</b>\n`;
    for (const m of models) {
      const tag = m.premium ? '⭐' : '○';
      txt += `  ${tag} <code>/${m.cmd}</code> — ${esc(m.name)}\n`;
    }
  }

  txt += `\n<i>Pilih lewat tombol atau ketik command langsung.</i>`;
  return txt;
}

// ── Progress helper ───────────────────────────────────────
async function sendProgress(bot, chatId, text, msgId = null) {
  if (msgId) {
    try {
      const m = await bot.editMessageText(text, { chat_id: chatId, message_id: msgId, parse_mode: 'HTML' });
      return m?.message_id || msgId;
    } catch { return msgId; }
  }
  const m = await bot.sendMessage(chatId, text, { parse_mode: 'HTML' });
  return m?.message_id;
}

// ── REGISTER ──────────────────────────────────────────────
function register(bot) {

  // ── Ambil bot ID untuk deteksi reply ke bot ──────────────
  let BOT_ID = null;
  bot.getMe().then(me => { BOT_ID = String(me.id); }).catch(() => {});

  // ── Helper: jalankan AI chat + simpan/update session ─────
  async function runAiChat(chatId, userId, prompt, modelId, msgToReply, sessionStore) {
    const modelInfo = getModelById(modelId);
    const modelName = modelInfo?.name || modelId;

    const existing = resolveSession(sessionStore, userId, msgToReply, BOT_ID);
    const history  = existing ? existing.history : [];

    const sent = await bot.sendMessage(chatId,
      `PROSES <b>${esc(modelName)}</b> sedang mengetik...`,
      { parse_mode: 'HTML', reply_to_message_id: msgToReply.message_id }
    ).catch(() => null);

    try {
      const messages = [...history, { role: 'user', content: prompt }];
      const reply = await mimoChat(messages, modelId);
      const text  = reply || '_(tidak ada respons)_';

      const newHistory = [...history,
        { role: 'user',      content: prompt },
        { role: 'assistant', content: text   },
      ].slice(-20);

      const header = existing
        ? `<b>${esc(modelName)}</b> <i>(lanjut sesi)</i>`
        : `<b>${esc(modelName)}</b>`;
      const footer = `\n\n<i>💬 Reply pesan ini untuk lanjut sesi</i>`;

      let botMsg = null;
      if (sent) {
        botMsg = await bot.editMessageText(
          `${header}\n\n${esc(text)}${footer}`,
          { chat_id: chatId, message_id: sent.message_id, parse_mode: 'HTML' }
        ).catch(async () => {
          await bot.deleteMessage(chatId, sent.message_id).catch(() => {});
          return bot.sendMessage(chatId,
            `${header}\n\n${esc(text.slice(0, 4000))}${footer}`,
            { parse_mode: 'HTML', reply_to_message_id: msgToReply.message_id }
          ).catch(() => null);
        });
      }

      const botMsgId = botMsg?.message_id || sent?.message_id;
      if (botMsgId) saveChatSession(sessionStore, userId, { history: newHistory, botMsgId, modelId });

    } catch (e) {
      const errTxt = `GAGAL <b>${esc(modelName)} Error</b>\n<code>${esc(e.message)}</code>`;
      if (sent) await bot.editMessageText(errTxt, { chat_id: chatId, message_id: sent.message_id, parse_mode: 'HTML' }).catch(() => {});
      else await bot.sendMessage(chatId, errTxt, { parse_mode: 'HTML' });
    }
  }

  // ── Helper: Claude Haiku via overchat.ai ─────────────────
  async function runHaikuChat(chatId, userId, prompt, msgToReply) {
    const existing = resolveSession(HAIKU_SESSION, userId, msgToReply, BOT_ID);
    const history  = existing?.haikuHistory || [];
    const chatId_h = existing?.haikuChatId  || null;
    const deviceId = existing?.haikuDeviceId || null;

    const sent = await bot.sendMessage(chatId,
      `PROSES <b>Claude Haiku</b> sedang mengetik...`,
      { parse_mode: 'HTML', reply_to_message_id: msgToReply.message_id }
    ).catch(() => null);

    try {
      const { ClaudeHaiku } = await import('./features/claudehaiku.js');
      const res = await ClaudeHaiku(prompt, {
        history,
        ...(chatId_h ? { chatId: chatId_h }   : {}),
        ...(deviceId ? { deviceId: deviceId } : {}),
      });
      if (!res?.status) throw new Error(res?.error || 'Haiku tidak merespons');

      const answer = res.answer || '_(tidak ada respons)_';
      const newHistory = [...history,
        { role: 'user',      content: prompt },
        { role: 'assistant', content: answer },
      ].slice(-20);

      const header = existing
        ? `<b>Claude Haiku</b> <i>(lanjut sesi)</i>`
        : `<b>Claude Haiku</b>`;
      const footer = `\n\n<i>💬 Reply pesan ini untuk lanjut sesi</i>`;

      let botMsg = null;
      if (sent) {
        botMsg = await bot.editMessageText(
          `${header}\n\n${esc(answer)}${footer}`,
          { chat_id: chatId, message_id: sent.message_id, parse_mode: 'HTML' }
        ).catch(async () => {
          await bot.deleteMessage(chatId, sent.message_id).catch(() => {});
          return bot.sendMessage(chatId,
            `${header}\n\n${esc(answer.slice(0, 4000))}${footer}`,
            { parse_mode: 'HTML', reply_to_message_id: msgToReply.message_id }
          ).catch(() => null);
        });
      }

      const botMsgId = botMsg?.message_id || sent?.message_id;
      if (botMsgId) saveChatSession(HAIKU_SESSION, userId, {
        haikuHistory:  newHistory,
        haikuChatId:   res.chatId,
        haikuDeviceId: res.deviceId,
        botMsgId,
      });

    } catch (e) {
      const errTxt = `GAGAL <b>Claude Haiku Error</b>\n<code>${esc(e.message)}</code>`;
      if (sent) await bot.editMessageText(errTxt, { chat_id: chatId, message_id: sent.message_id, parse_mode: 'HTML' }).catch(() => {});
      else await bot.sendMessage(chatId, errTxt, { parse_mode: 'HTML' });
    }
  }

  // ─────────────────────────────────────────────────────────
  // 2. /ai <pesan> — chat ke model aktif, session via reply
  // ─────────────────────────────────────────────────────────
  bot.onText(/^\/ai(?:@\w+)?\s+([\s\S]+)$/i, async (msg, m) => {
    const chatId  = msg.chat.id;
    const userId  = String(msg.from?.id);
    const prompt  = m[1].trim();
    const modelId = getUserModel(userId);
    await runAiChat(chatId, userId, prompt, modelId, msg, CHAT_SESSION);
  });

  // ─────────────────────────────────────────────────────────
  // 3. /modelai — tampilkan semua model + keyboard pilih
  // ─────────────────────────────────────────────────────────
  bot.onText(/^\/modelai(?:@\w+)?$/i, async (msg) => {
    const userId = String(msg.from?.id);
    await bot.sendMessage(msg.chat.id, modelListText(userId), {
      parse_mode: 'HTML',
      reply_markup: modelListKeyboard(),
    }).catch(() => {});
  });

  // ─────────────────────────────────────────────────────────
  // 4. Shortcut per-model — session via reply berlaku
  // ─────────────────────────────────────────────────────────
  for (const model of MODEL_REGISTRY) {
    const re = new RegExp(`^\\/\${model.cmd}(?:@\\w+)?(?:\\s+([\\s\\S]+))?$`, 'i');
    bot.onText(re, async (msg, match) => {
      const chatId = msg.chat.id;
      const userId = String(msg.from?.id);
      const prompt = match[1]?.trim() || '';

      if (!prompt) {
        setUserModel(userId, model.id);
        return bot.sendMessage(chatId,
          `SELESAI Model aktif diset ke <b>${esc(model.name)}</b>\n\n` +
          `Sekarang ketik <code>/ai pesan kamu</code> untuk mulai chat.`,
          { parse_mode: 'HTML', reply_to_message_id: msg.message_id }
        ).catch(() => {});
      }

      await runAiChat(chatId, userId, prompt, model.id, msg, CHAT_SESSION);
    });
  }

  // ─────────────────────────────────────────────────────────
  // 4. Upload .zip → tampilkan info + tombol analisis/fix
  //    (Khusus Owner)
  // ─────────────────────────────────────────────────────────
  bot.on('message', async (msg) => {
    if (!msg.document) return;
    if (!isOwner(msg.from?.id)) return;

    const doc  = msg.document;
    const name = doc.file_name || '';
    if (!name.toLowerCase().endsWith('.zip')) return;

    const chatId = msg.chat.id;
    const userId = String(msg.from.id);
    const sizeMB = (doc.file_size || 0) / 1048576;

    if (sizeMB > MAX_ZIP_MB) {
      return bot.sendMessage(chatId,
        `GAGAL <b>Zip terlalu besar.</b>\nMaks ${MAX_ZIP_MB} MB, file ini ${sizeMB.toFixed(2)} MB.`,
        { parse_mode: 'HTML', reply_to_message_id: msg.message_id }
      );
    }

    saveSession(userId, { fileId: doc.file_id, fileName: name, chatId });

    let infoText = `ZIP <b>${esc(name)}</b> (${fmtSize(doc.file_size || 0)})\n\n`;
    try {
      const buf   = await downloadZip(bot, doc.file_id);
      const files = readZipFiles(buf);
      const jsFiles = files.filter(f => f.entryName.endsWith('.js'));
      infoText += `<b>File JS terdeteksi:</b> ${jsFiles.length} file\n`;
      infoText += jsFiles.slice(0, 10)
        .map(f => `  ├ <code>${esc(f.entryName)}</code> (${fmtSize(f.size)})`)
        .join('\n');
      if (jsFiles.length > 10) infoText += `\n  └ ...dan ${jsFiles.length - 10} lainnya`;
      infoText += `\n\n<i>Pilih aksi:</i>`;
    } catch (e) {
      infoText += `PERINGATAN Gagal baca zip: ${esc(e.message)}\n\n<i>Coba tetap pilih aksi:</i>`;
    }

    return bot.sendMessage(chatId, infoText, {
      parse_mode: 'HTML',
      reply_to_message_id: msg.message_id,
      reply_markup: zipKeyboard(userId),
    });
  });

  // ─────────────────────────────────────────────────────────
  // 5. Callback: pilih model + analisis/fix zip
  // ─────────────────────────────────────────────────────────
  bot.on('callback_query', async (cb) => {
    const data   = String(cb.data || '');
    const chatId = cb.message?.chat?.id;
    const msgId  = cb.message?.message_id;
    const userId = String(cb.from?.id);

    // ── Pilih model dari /modelai ──────────────────────────
    if (data.startsWith('aimodel:')) {
      const modelId   = data.slice(8);
      const modelInfo = getModelById(modelId);
      if (!modelInfo) return bot.answerCallbackQuery(cb.id, { text: 'Model tidak dikenal.' }).catch(() => {});

      setUserModel(userId, modelId);
      await bot.answerCallbackQuery(cb.id, {
        text: `SELESAI Model diset ke ${modelInfo.name}`,
        show_alert: false,
      }).catch(() => {});

      return bot.editMessageText(
        `SELESAI Model aktif: <b>${esc(modelInfo.name)}</b>\n\n` +
        `Ketik <code>/ai pesan kamu</code> untuk mulai chat.\n` +
        `Atau pakai <code>/${modelInfo.cmd} pesan kamu</code> langsung.`,
        { chat_id: chatId, message_id: msgId, parse_mode: 'HTML' }
      ).catch(() => {});
    }

    // ── Analisis / Fix zip ─────────────────────────────────
    const m = data.match(/^aica:(analyze|fix):(\d+)$/);
    if (!m) return;

    const action  = m[1];
    const ownerId = m[2];
    const actionKey = `aica:${chatId}:${ownerId}:${action}`;
    if (global.__lianixAiActions?.has(actionKey)) {
      return bot.answerCallbackQuery(cb.id, { text: 'Proses masih berjalan.', show_alert: false }).catch(() => {});
    }
    global.__lianixAiActions = global.__lianixAiActions || new Set();
    global.__lianixAiActions.add(actionKey);

    if (!isOwner(cb.from?.id)) {
      return bot.answerCallbackQuery(cb.id, { text: 'DITOLAK Khusus Owner.', show_alert: true }).catch(() => {});
    }

    const session = getSession(ownerId);
    if (!session) {
      return bot.answerCallbackQuery(cb.id, { text: 'PROSES Sesi expired. Upload zip lagi.', show_alert: true }).catch(() => {});
    }

    await bot.answerCallbackQuery(cb.id, {
      text: action === 'analyze' ? 'Menganalisis...' : 'Memperbaiki kode...'
    }).catch(() => {});

    let progressMsgId = null;
    try {
      progressMsgId = await sendProgress(bot, chatId,
        `PROSES <b>AI ${action === 'analyze' ? 'Analisis' : 'Fix'}</b>\n\n- Mengunduh zip...`, null);

      const zipBuffer = await downloadZip(bot, session.fileId);

      await sendProgress(bot, chatId,
        `PROSES <b>AI ${action === 'analyze' ? 'Analisis' : 'Fix'}</b>\n\n- Membaca file...`, progressMsgId);

      const files = readZipFiles(zipBuffer);
      if (files.length === 0) {
        await bot.editMessageText('GAGAL Tidak ada file .js/.json ditemukan dalam zip.',
          { chat_id: chatId, message_id: progressMsgId, parse_mode: 'HTML' });
        return;
      }

      await sendProgress(bot, chatId,
        `PROSES <b>AI ${action === 'analyze' ? 'Analisis' : 'Fix'}</b>\n\n- Mengirim ${files.length} file ke MimoAI...\n<i>Mohon tunggu 1–3 menit.</i>`,
        progressMsgId);

      const prompt   = action === 'analyze' ? buildAnalyzePrompt(files) : buildFixPrompt(files);
      const aiResult = await mimoChat([{ role: 'user', content: prompt }], 'xiaomi/mimo-v2.5-pro');

      if (action === 'analyze') {
        await bot.deleteMessage(chatId, progressMsgId).catch(() => {});
        const report = aiResult.trim();
        if (report.length <= 4000) {
          await bot.sendMessage(chatId,
            `<b>LAPORAN AI ANALISIS</b>\n<code>${esc(session.fileName)}</code>\n\n<blockquote expandable>${esc(report)}</blockquote>`,
            { parse_mode: 'HTML', reply_to_message_id: msgId });
        } else {
          ensureTmp();
          const outPath = path.join(TMP_DIR, `analisis-${shortId()}.txt`);
          fs.writeFileSync(outPath, `LAPORAN AI ANALISIS\nFile: ${session.fileName}\n\n${report}`, 'utf8');
          await bot.sendDocument(chatId, outPath, {
            caption: `<b>AI Analisis selesai.</b>\n<code>${esc(session.fileName)}</code>`,
            parse_mode: 'HTML',
            reply_to_message_id: msgId,
          });
          fs.unlink(outPath, () => {});
        }

      } else {
        await sendProgress(bot, chatId,
          `PROSES <b>AI Fix</b>\n\n- Menerapkan patch ke zip...`, progressMsgId);

        const { patches, laporan } = parseFixes(aiResult);

        if (patches.length === 0) {
          await bot.deleteMessage(chatId, progressMsgId).catch(() => {});
          await bot.sendMessage(chatId,
            `SELESAI <b>AI Fix selesai.</b>\n\nAI tidak menemukan masalah untuk dipatch.\n\n<blockquote expandable>${esc(aiResult.slice(0, 2000))}</blockquote>`,
            { parse_mode: 'HTML', reply_to_message_id: msgId });
          return;
        }

        let newZipBuffer = zipBuffer;
        try {
          newZipBuffer = rebuildZip(zipBuffer, patches);
        } catch {
          const zipEntries = new AdmZip(zipBuffer).getEntries().map(e => e.entryName);
          const fixedPatches = patches.map(p => {
            const base  = path.basename(p.entryName);
            const found = zipEntries.find(e => path.basename(e) === base) || p.entryName;
            return { ...p, entryName: found };
          });
          newZipBuffer = rebuildZip(zipBuffer, fixedPatches);
        }

        ensureTmp();
        const outName = session.fileName.replace(/\.zip$/i, '') + '-FIXED.zip';
        const outPath = path.join(TMP_DIR, outName);
        fs.writeFileSync(outPath, newZipBuffer);

        await bot.deleteMessage(chatId, progressMsgId).catch(() => {});

        const patchedList = patches.map(p => `  ├ <code>${esc(p.entryName)}</code>`).join('\n');
        await bot.sendDocument(chatId, outPath, {
          caption:
            `<b>AI FIX SELESAI</b>\n` +
            `<code>${esc(session.fileName)}</code> → <code>${esc(outName)}</code>\n\n` +
            `<b>Dipatch (${patches.length}):</b>\n${patchedList}\n\n` +
            (laporan ? `<b>Laporan:</b>\n<blockquote expandable>${esc(laporan.slice(0, 1200))}</blockquote>` : ''),
          parse_mode: 'HTML',
          reply_to_message_id: msgId,
        });
        fs.unlink(outPath, () => {});
      }

    } catch (err) {
      const errMsg = `GAGAL <b>AI ${action === 'analyze' ? 'Analisis' : 'Fix'} gagal.</b>\n\n<code>${esc(err.message)}</code>`;
      if (progressMsgId) {
        await bot.editMessageText(errMsg, {
          chat_id: chatId, message_id: progressMsgId, parse_mode: 'HTML'
        }).catch(() => bot.sendMessage(chatId, errMsg, { parse_mode: 'HTML' }));
      } else {
        await bot.sendMessage(chatId, errMsg, { parse_mode: 'HTML' });
      }
    }
    finally { global.__lianixAiActions.delete(actionKey); }
  });
}

module.exports = { register };
