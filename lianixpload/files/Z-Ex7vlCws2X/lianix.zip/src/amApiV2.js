/**
 * AM API V2
 * Robust browser bootstrap for VPS/container environments.
 */
'use strict';

const fs = require('fs');
const path = require('path');
const os = require('os');
const { spawn } = require('child_process');
const { connect } = require('puppeteer-real-browser');

const BASE_URL = 'https://spotifylohya.lanncodex.my.id';
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

function isExecutable(p) {
  try {
    if (!p || !fs.existsSync(p)) return false;
    const st = fs.statSync(p);
    if (!st.isFile()) return false;
    if (process.platform === 'win32') return true;
    fs.accessSync(p, fs.constants.X_OK);
    return true;
  } catch (_) { return false; }
}

function cacheDir() {
  return process.env.PUPPETEER_CACHE_DIR || path.join(os.homedir(), '.cache', 'puppeteer');
}

function configuredPaths() {
  const paths = [
    process.env.CHROME_PATH,
    process.env.PUPPETEER_EXECUTABLE_PATH,
    process.env.CHROME_BIN,
    '/usr/bin/google-chrome-stable',
    '/usr/bin/google-chrome',
    '/usr/bin/chromium',
    '/usr/bin/chromium-browser',
    '/snap/bin/chromium',
    '/opt/google/chrome/chrome',
    '/opt/google/chrome/google-chrome',
  ];
  if (process.platform === 'darwin') {
    paths.push('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome');
  }
  if (process.platform === 'win32') {
    paths.push(
      process.env.LOCALAPPDATA ? path.join(process.env.LOCALAPPDATA, 'Google', 'Chrome', 'Application', 'chrome.exe') : '',
      process.env.PROGRAMFILES ? path.join(process.env.PROGRAMFILES, 'Google', 'Chrome', 'Application', 'chrome.exe') : ''
    );
  }
  return paths.filter(Boolean);
}

function findSystemChrome() {
  return configuredPaths().find(isExecutable) || null;
}

function findPuppeteerChrome() {
  try {
    const pptr = require('puppeteer');
    const p = typeof pptr.executablePath === 'function' ? pptr.executablePath() : '';
    if (isExecutable(p)) return p;
  } catch (_) {}

  const root = cacheDir();
  const candidates = [];
  try {
    const chromeRoot = path.join(root, 'chrome');
    for (const version of fs.readdirSync(chromeRoot, { withFileTypes: true })) {
      if (!version.isDirectory()) continue;
      candidates.push(path.join(chromeRoot, version.name, 'chrome-linux64', 'chrome'));
      candidates.push(path.join(chromeRoot, version.name, 'chrome-linux', 'chrome'));
      candidates.push(path.join(chromeRoot, version.name, 'chrome-win64', 'chrome.exe'));
      candidates.push(path.join(root, 'chrome', version.name, 'chrome-mac', 'Chromium.app', 'Contents', 'MacOS', 'Chromium'));
    }
  } catch (_) {}
  return candidates.reverse().find(isExecutable) || null;
}

async function installManagedChrome() {
  const browsers = require('@puppeteer/browsers');
  const platform = browsers.detectBrowserPlatform();
  if (!platform) throw new Error(`Platform tidak didukung: ${process.platform}/${process.arch}`);

  const cache = cacheDir();
  fs.mkdirSync(cache, { recursive: true });

  const buildId = await browsers.resolveBuildId(
    browsers.Browser.CHROME,
    platform,
    browsers.ChromeReleaseChannel.STABLE
  );
  if (!buildId) throw new Error('Build Chrome Stable tidak dapat ditentukan.');

  const executable = browsers.computeExecutablePath({
    browser: browsers.Browser.CHROME,
    buildId,
    platform,
    cacheDir: cache,
  });

  // Puppeteer refuses to install when a half-created browser directory already
  // exists. This is exactly what happens after an interrupted download:
  // chrome/<buildId>/ exists but chrome-linux64/chrome is missing.
  if (!isExecutable(executable)) {
    const versionDir = path.dirname(path.dirname(executable));
    if (versionDir.startsWith(path.join(cache, 'chrome') + path.sep) && fs.existsSync(versionDir)) {
      fs.rmSync(versionDir, { recursive: true, force: true });
    }
  }

  await browsers.install({
    browser: browsers.Browser.CHROME,
    buildId,
    platform,
    cacheDir: cache,
    unpack: true,
  });

  if (!isExecutable(executable)) {
    throw new Error(`Chrome terunduh tetapi executable tidak valid: ${executable}`);
  }
  return executable;
}

async function installFreshChromeFallback() {
  const browsers = require('@puppeteer/browsers');
  const platform = browsers.detectBrowserPlatform();
  if (!platform) throw new Error(`Platform tidak didukung: ${process.platform}/${process.arch}`);

  // Use a clean cache only as a last resort. This avoids being poisoned by a
  // previous interrupted download while preserving the user's normal cache.
  const fallbackCache = path.join(os.tmpdir(), `lianix-puppeteer-${process.pid}`);
  fs.rmSync(fallbackCache, { recursive: true, force: true });
  fs.mkdirSync(fallbackCache, { recursive: true });

  const buildId = await browsers.resolveBuildId(
    browsers.Browser.CHROME,
    platform,
    browsers.ChromeReleaseChannel.STABLE
  );
  await browsers.install({
    browser: browsers.Browser.CHROME,
    buildId,
    platform,
    cacheDir: fallbackCache,
    unpack: true,
  });

  const executable = browsers.computeExecutablePath({
    browser: browsers.Browser.CHROME,
    buildId,
    platform,
    cacheDir: fallbackCache,
  });
  if (!isExecutable(executable)) {
    throw new Error(`Fallback Chrome terpasang tetapi executable tidak valid: ${executable}`);
  }
  return executable;
}

function runChromeVersion(executable) {
  return new Promise((resolve) => {
    let settled = false;
    const finish = (ok, detail) => {
      if (settled) return;
      settled = true;
      resolve({ ok, detail });
    };
    let child;
    try {
      child = spawn(executable, ['--version'], {
        stdio: ['ignore', 'pipe', 'pipe'],
        windowsHide: true,
      });
    } catch (e) {
      return finish(false, e?.message || String(e));
    }
    let out = '';
    let err = '';
    child.stdout?.on('data', d => { out += d.toString(); });
    child.stderr?.on('data', d => { err += d.toString(); });
    child.once('error', e => finish(false, e?.message || String(e)));
    child.once('exit', code => finish(code === 0, (out || err).trim() || `exit code ${code}`));
    setTimeout(() => {
      try { child.kill('SIGKILL'); } catch (_) {}
      finish(false, 'Chrome --version timeout');
    }, 15000).unref();
  });
}

async function ensureChrome() {
  let chrome = findSystemChrome() || findPuppeteerChrome();

  if (!chrome) {
    const errors = [];
    try {
      chrome = await installManagedChrome();
    } catch (e) {
      errors.push(`cache utama: ${e?.message || e}`);
      try {
        chrome = await installFreshChromeFallback();
      } catch (e2) {
        errors.push(`cache bersih: ${e2?.message || e2}`);
      }
    }

    // Never call a malformed `npx puppeteer ...` command here. Older npm/npx
    // versions can resolve the package incorrectly and return the CLI help
    // instead of installing anything. The @puppeteer/browsers API above is
    // deterministic and is the primary installer.
    if (!chrome) {
      throw new Error(`Chrome/Chromium gagal disiapkan. ${errors.join(' | ')}`);
    }
  }

  if (!chrome) throw new Error('Chrome/Chromium tidak ditemukan setelah instalasi otomatis.');

  const smoke = await runChromeVersion(chrome);
  if (!smoke.ok) {
    throw new Error(`Chrome ditemukan tetapi tidak dapat dijalankan: ${smoke.detail}`);
  }

  process.env.CHROME_PATH = chrome;
  process.env.PUPPETEER_EXECUTABLE_PATH = chrome;
  return chrome;
}

async function createAmApiV2() {
  let browser;
  try {
    const chromePath = await ensureChrome();
    const hasDisplay = !!process.env.DISPLAY || process.platform === 'win32' || process.platform === 'darwin';

    const connected = await connect({
      // puppeteer-real-browser can run headless when no X display exists.
      // On Linux with Xvfb/display available, use a real headed browser.
      headless: process.platform === 'linux' && !hasDisplay ? true : false,
      turnstile: true,
      customConfig: { chromePath },
      connectOption: {
        defaultViewport: { width: 1280, height: 800 },
        timeout: 120000,
        protocolTimeout: 300000,
      },
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-gpu',
        '--no-first-run',
        '--no-default-browser-check',
        '--disable-extensions',
      ],
      disableXvfb: false,
    });

    browser = connected.browser;
    const page = connected.page;
    if (!page) throw new Error('Browser berhasil start tetapi page tidak tersedia.');

    await page.goto(BASE_URL, { waitUntil: 'domcontentloaded', timeout: 60000 });

    const deadline = Date.now() + 60000;
    let ready = false;
    while (Date.now() < deadline) {
      const title = await page.title().catch(() => '');
      const html = await page.content().catch(() => '');
      const cookies = await page.cookies().catch(() => []);
      const clearance = cookies.some(c => c.name === 'cf_clearance');
      const challenge = /just a moment|checking your browser|challenge-platform/i.test(`${title}\n${html}`);
      if (!challenge || clearance) { ready = true; break; }
      await sleep(2000);
    }
    if (!ready) throw new Error('Halaman verifikasi belum selesai dalam 60 detik.');

    async function callApi(endpoint, body = {}) {
      return page.evaluate(async ({ endpoint, body }) => {
        try {
          const resp = await fetch(endpoint, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'x-am-pro-signature': 'vault-v3' },
            credentials: 'include',
            body: JSON.stringify(body),
          });
          return { status: resp.status, ok: resp.ok, body: await resp.text() };
        } catch (e) { return { error: e?.message || String(e) }; }
      }, { endpoint, body });
    }

    const generate = await callApi('/api/generate');
    const catcher = await callApi('/api/catcher');
    const manual = await callApi('/api/manual', { action: 'send', email: 'test@test.com' });

    return { success: true, url: BASE_URL, scraped_at: new Date().toISOString(), generate, catcher, manual };
  } catch (err) {
    return { success: false, url: BASE_URL, error: err?.message || String(err) };
  } finally {
    if (browser) await browser.close().catch(() => {});
  }
}

module.exports = { createAmApiV2, ensureChrome };
