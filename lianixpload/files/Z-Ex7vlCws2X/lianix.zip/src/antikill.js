// src/antikill.js
// "Anti Kill Panel" — monitor resource (CPU/Disk) semua server yang jalan
// di panel utama (settings.domain / plta / pltc).
//
// Kalau ada server yang makan CPU atau Disk kelewat batas, bot akan:
//   1) Lapor ke owner (atau chat di settings.antiKill.notifyChatId)
//      lengkap sama angka CPU & Disk-nya.
//   2a) Kalau server BUKAN server yang ngerun bot ini sendiri:
//       → Langsung suspend via Application API.
//   2b) Kalau server ADALAH server bot sendiri (self-server):
//       → SKIP suspend, hanya lapor ke owner.
//       → CPU di-cap ke 500% via Application API (bukan suspend).
//
// Self-server diidentifikasi lewat settings.antiKill.selfIdentifier
// (isi dengan short identifier / UUID server yang ngerun bot ini,
//  bisa dilihat di URL panel atau lewat /devpanel → Kelola Panel).
//
// Toggle otomatis: /antikill on|off
// Cek manual:      /checkkill

const axios  = require("axios");
const settings = require("../settings.js");
const fs = require("fs");
const path = require("path");
const PERSIST_FILE = path.join(__dirname, "..", "db", "antikillSettings.json");

const OWNER_UID = settings.ownerId;
const { domain, plta, pltc } = settings;

const cfg = Object.assign(
  {
    enabled:          true,
    intervalMs:       120000,
    cpuThreshold:     100,       // % CPU sebelum di-flag
    diskThresholdMb:  5120,      // MB disk sebelum di-flag
    selfIdentifier:   "",        // short identifier / UUID server bot sendiri
    cpuCapPercent:    500,       // batas CPU yang di-set ke server self saat over
    notifyChatId:     null,
  },
  settings.antiKill || {}
);

const NOTIFY_CHAT_ID   = cfg.notifyChatId || OWNER_UID;
const SELF_IDENTIFIERS = [
  cfg.selfIdentifier,
  cfg.selfServerId,
  cfg.selfServerIdentifier,
  process.env.P_SERVER_UUID,
  process.env.P_SERVER_UUID_SHORT,
  process.env.SELF_SERVER_ID,
  process.env.SELF_SERVER_IDENTIFIER,
].map(v => String(v || "").trim()).filter(Boolean);

function normalizeServerId(value) {
  return String(value || "").trim().toLowerCase();
}
let persisted = {};
try { if (fs.existsSync(PERSIST_FILE)) persisted = JSON.parse(fs.readFileSync(PERSIST_FILE, "utf8")) || {}; } catch {}
Object.assign(cfg, persisted);
const CPU_CAP          = Number(cfg.cpuCapPercent) || 500;
function persistCfg() { try { fs.mkdirSync(path.dirname(PERSIST_FILE), { recursive: true }); fs.writeFileSync(PERSIST_FILE, JSON.stringify({ enabled: !!cfg.enabled, cpuThreshold: Number(cfg.cpuThreshold), diskThresholdMb: Number(cfg.diskThresholdMb), intervalMs: Number(cfg.intervalMs) }, null, 2)); } catch (e) { console.error("[antikill] persist:", e.message); } }

let intervalHandle = null;
let isRunning      = false;

// ─── API helpers ────────────────────────────────────────────

function getPanelBaseUrl() {
  const raw = String(domain || "").trim();
  if (!raw) return null;
  try {
    const u = new URL(raw);
    if (!/^https?:$/.test(u.protocol)) return null;
    return u.toString().replace(/\/$/, "");
  } catch {
    return null;
  }
}

const ANTIKILL_TIMEOUT = 10000; // 10s max per request — cegah hang ETIMEDOUT

async function getAllServers() {
  const base = getPanelBaseUrl();
  if (!base) throw new Error("Domain panel belum dikonfigurasi dengan URL yang valid");
  const res = await axios.get(`${base}/api/application/servers?per_page=100`, {
    headers: { Accept: "application/json", Authorization: `Bearer ${plta}` },
    timeout: ANTIKILL_TIMEOUT,
  });
  return res.data?.data || [];
}

async function getResources(identifier) {
  const res = await axios.get(
    `${getPanelBaseUrl()}/api/client/servers/${identifier}/resources`,
    {
      headers: { Accept: "application/json", Authorization: `Bearer ${pltc}` },
      timeout: ANTIKILL_TIMEOUT,
    }
  );
  return res.data?.attributes;
}

async function suspendServer(serverId) {
  await axios.post(
    `${getPanelBaseUrl()}/api/application/servers/${serverId}/suspend`,
    {},
    {
      headers: { Accept: "application/json", Authorization: `Bearer ${plta}` },
      timeout: ANTIKILL_TIMEOUT,
    }
  );
}

// Cap CPU limit server (dipakai untuk self-server yang over CPU).
// Pterodactyl: cpu limit 0 = unlimited, >0 = % per core (500 = 5 core × 100%).
async function capCpuLimit(serverId, cpuPercent) {
  // Ambil build config sekarang dulu supaya field lain (memory, disk, dll) tidak ke-reset
  const res = await axios.get(
    `${getPanelBaseUrl()}/api/application/servers/${serverId}`,
    { headers: { Accept: "application/json", Authorization: `Bearer ${plta}` }, timeout: ANTIKILL_TIMEOUT }
  );
  const lim = res.data?.attributes?.limits || {};
  await axios.patch(
    `${getPanelBaseUrl()}/api/application/servers/${serverId}/build`,
    {
      allocation:    res.data?.attributes?.allocation,
      memory:        lim.memory  ?? 0,
      swap:          lim.swap    ?? 0,
      disk:          lim.disk    ?? 0,
      io:            lim.io      ?? 500,
      cpu:           cpuPercent,
      threads:       lim.threads ?? null,
      feature_limits: res.data?.attributes?.feature_limits || {},
    },
    { headers: { Accept: "application/json", Authorization: `Bearer ${plta}` }, timeout: ANTIKILL_TIMEOUT }
  );
}

// Cek apakah server ini adalah server yang ngerun bot
function isSelfServer(srv) {
  const s = srv?.attributes || {};
  const candidates = [
    s.identifier,
    s.uuid,
    s.id,
    s.uuidShort,
  ].map(normalizeServerId).filter(Boolean);

  if (!SELF_IDENTIFIERS.length || !candidates.length) return false;

  return SELF_IDENTIFIERS.some(raw => {
    const wanted = normalizeServerId(raw);
    return candidates.some(actual =>
      actual === wanted ||
      actual.startsWith(wanted) ||
      wanted.startsWith(actual)
    );
  });
}

// Format laporan ringkas setiap siklus auto-check CPU.
// Hanya dikirim jika ada server abnormal atau aksi gagal, supaya tidak spam.
async function sendAutoCheckSummary(bot, result) {
  if (!bot || !result || result.skipped) return;
  const abnormal = result.flagged || [];
  if (!abnormal.length) return;

  const stopped = abnormal.filter(f => f.suspended).length;
  const failed = abnormal.filter(f => !f.suspended && !f.selfServer).length;
  const skipped = abnormal.filter(f => f.selfServer && !f.suspended).length;

  let lines = abnormal.map((f, i) => {
    const action = f.selfServer
      ? (f.cpuCapped ? "CPU di-CAP" : "Dilewati (self-server)")
      : (f.suspended ? "DiSTOP" : "Gagal diSTOP");
    return `• ${i + 1} (${String(f.name || "SERVER")}) - ${Number(f.cpuPct || 0).toFixed(2)}% (${action})`;
  }).join("\n");

  const summary =
    `⚠️ <b>[AUTO-CHECK SELESAI] - V1</b> ⚠️\n` +
    `Total Server Abnormal: <b>${abnormal.length}</b>\n` +
    `- Dihentikan: <b>${stopped}</b>\n` +
    `- Gagal Dihentikan: <b>${failed}</b>\n` +
    `- Dilewati (Baru distop): <b>${skipped}</b>\n` +
    lines;

  await bot.sendMessage(NOTIFY_CHAT_ID, summary, { parse_mode: "HTML" }).catch(() => {});

  // Kirim detail AUTO-STOP per server yang benar-benar melebihi batas CPU.
  for (const f of abnormal) {
    if (!f.overCpu || f.selfServer || !f.suspended) continue;
    const limit = Number(cfg.cpuThreshold);
    const detail =
      `🚨 <b>[AUTO-STOP CPU] - V1</b> 🚨\n` +
      `Server <b>${String(f.name || "SERVER")}</b> (ID: <code>${String(f.id)}</code>) secara otomatis <b>dihentikan</b>!\n` +
      `📈 <b>CPU Usage</b>: ${Number(f.cpuPct || 0).toFixed(2)}% (Limit: ${limit}%)\n` +
      `⚠️ Melebihi batas wajar (${limit}%).`;
    await bot.sendMessage(NOTIFY_CHAT_ID, detail, { parse_mode: "HTML" }).catch(() => {});
  }
}

// ─── Main check cycle ───────────────────────────────────────

async function runCheck(bot) {
  if (isRunning) return { checked: 0, flagged: [], skipped: true };
  isRunning = true;

  const flagged = [];
  let checked   = 0;

  try {
    const servers = await getAllServers();

    for (const srv of servers) {
      const s = srv.attributes;
      if (!s || s.suspended) continue;

      let attrs;
      try {
        attrs = await getResources(s.identifier);
      } catch { continue; }

      if (!attrs || attrs.current_state !== "running") continue;
      checked++;

      const r       = attrs.resources || {};
      const cpuPct  = r.cpu_absolute || 0;
      const ramMb   = (r.memory_bytes || 0) / 1024 / 1024;
      const diskMb  = (r.disk_bytes  || 0) / 1024 / 1024;

      const overCpu  = cpuPct  >= cfg.cpuThreshold;
      const overDisk = diskMb  >= cfg.diskThresholdMb;

      if (!overCpu && !overDisk) continue;

      const selfServer = isSelfServer(srv);

      const reason = [];
      if (overCpu)  reason.push(`CPU ${cpuPct.toFixed(1)}% (batas ${cfg.cpuThreshold}%)`);
      if (overDisk) reason.push(`Disk ${diskMb.toFixed(0)} MB (batas ${cfg.diskThresholdMb} MB)`);

      const info = {
        id:         s.id,
        uuid:       s.uuid,
        identifier: s.identifier,
        name:       s.name,
        userId:     s.user,
        cpuPct,
        overCpu,
        ramMb,
        diskMb,
        reason:     reason.join(" & "),
        selfServer,
        suspended:  false,
        cpuCapped:  false,
      };
      flagged.push(info);

      // ── Lapor ke owner ──
      if (bot) {
        const selfTag = selfServer
          ? `\n\n<blockquote expandable>⊙ <b>SERVER BOT SENDIRI</b>\nStatus: <b>Tidak di-suspend otomatis</b>\nCPU limit proteksi: <b>${CPU_CAP}%</b></blockquote>`
          : `\n\n<blockquote expandable>⚠️ <b>AUTO-SUSPEND</b>\nServer terdeteksi melewati batas dan akan diproses otomatis.</blockquote>`;

        const cpuBar = cpuPct >= cfg.cpuThreshold ? "🔴" : "🟢";
        const diskBar = diskMb >= cfg.diskThresholdMb ? "🔴" : "🟢";

        await bot.sendMessage(
          NOTIFY_CHAT_ID,
          `<blockquote expandable>◈ <b>ANTI KILL PANEL</b>\n` +
          `╰─ <i>Resource monitor & protection</i></blockquote>\n\n` +
          `<b>▸ SERVER</b>\n` +
          `├ Name       : <b>${info.name}</b>\n` +
          `├ ID         : <code>${info.id}</code>\n` +
          `├ Identifier : <code>${info.identifier}</code>\n` +
          `╰ User ID    : <code>${info.userId}</code>\n\n` +
          `<b>▸ RESOURCE</b>\n` +
          `${cpuBar} CPU  : <b>${cpuPct.toFixed(1)}%</b> / ${cfg.cpuThreshold}%\n` +
          `🧠 RAM  : <b>${ramMb.toFixed(0)} MB</b>\n` +
          `${diskBar} Disk : <b>${diskMb.toFixed(0)} MB</b> / ${cfg.diskThresholdMb} MB\n\n` +
          `<b>▸ TRIGGER</b>\n` +
          `<code>${info.reason}</code>` +
          selfTag,
          { parse_mode: "HTML" }
        ).catch(() => {});
      }

      // ── Aksi: suspend atau cap CPU ──
      if (selfServer) {
        // Server bot sendiri — jangan di-suspend, cap CPU ke 500% saja
        if (overCpu) {
          try {
            await capCpuLimit(s.id, CPU_CAP);
            info.cpuCapped = true;
            if (bot) {
              await bot.sendMessage(
                NOTIFY_CHAT_ID,
                `<blockquote expandable>◉ <b>CPU Di-Cap</b>\nServer <b>${info.name}</b> (server bot sendiri) CPU-nya di-cap ke <b>${CPU_CAP}%</b>.\nTidak di-suspend.</blockquote>`,
                { parse_mode: "HTML" }
              ).catch(() => {});
            }
          } catch (err) {
            const errMsg = err.response?.data?.errors?.[0]?.detail || err.message;
            if (bot) {
              await bot.sendMessage(
                NOTIFY_CHAT_ID,
                `<blockquote expandable>◇ <b>Gagal Cap CPU</b>\nServer <b>${info.name}</b> gagal di-cap CPU-nya.\nAlasan: ${errMsg}</blockquote>`,
                { parse_mode: "HTML" }
              ).catch(() => {});
            }
          }
        }
        // overDisk pada self-server: hanya lapor, tidak ada aksi otomatis
        continue;
      }

      // DEFENSIVE GUARD:
      // Jangan pernah suspend server yang terdeteksi sebagai server bot sendiri.
      // Ini sengaja dicek sekali lagi tepat sebelum aksi destruktif.
      if (isSelfServer(srv)) {
        info.selfServer = true;
        continue;
      }

      // Server biasa (bukan self) — suspend
      try {
        await suspendServer(s.id);
        info.suspended = true;
      } catch (err) {
        info.suspended     = false;
        info.suspendError  = err.response?.data || err.message;
        if (bot) {
          await bot.sendMessage(
            NOTIFY_CHAT_ID,
            `<blockquote expandable>◇ <b>Gagal Auto-Suspend</b>\nServer <b>${info.name}</b> (ID: <code>${info.id}</code>) gagal di-suspend otomatis.\nSuspend manual lewat panel ya.</blockquote>`,
            { parse_mode: "HTML" }
          ).catch(() => {});
        }
      }
    }
  } catch (err) {
    const detail = err.response?.data?.errors?.[0]?.detail || err.response?.data?.message || err.message || String(err);
    // Skip spam: panel belum dikonfigurasi, timeout, atau unreachable — cukup log warn, JANGAN throw ke errorAudit
    const isConnErr = /timeout|ETIMEDOUT|ECONNREFUSED|ENOTFOUND|ECONNRESET|socket hang|network/i.test(String(detail));
    const isConfigErr = /Domain panel belum dikonfigurasi/.test(String(detail));
    if (!isConfigErr && !isConnErr) {
      console.error("[antikill] ERROR:", detail);
    } else if (isConnErr) {
      // Prefix "[antikill] panel unreachable" agar errorAudit mengabaikan baris ini (bukan error fatal)
      console.warn("[antikill] panel unreachable, skip siklus ini:", detail.slice(0, 120));
    }
    // isConfigErr: diam saja — panel memang belum dikonfigurasi, tidak perlu spam log
    await sendAutoCheckSummary(bot, { checked, flagged, skipped: false });
  } finally {
    isRunning = false;
  }

  return { checked, flagged, skipped: false };
}

// ─── Monitor lifecycle ──────────────────────────────────────

function startMonitor(bot) {
  lastBot = bot;
  if (intervalHandle) return;

  // Do not run a check immediately when the monitor is enabled. The first
  // check must happen exactly after the configured interval, just like every
  // subsequent check. This prevents an unexpected extra CPU check at startup
  // or when the interval is changed.
  intervalHandle = setInterval(() => {
    if (!isRunning) void runCheck(bot);
  }, cfg.intervalMs);
}

function stopMonitor() {
  if (!intervalHandle) return;
  clearInterval(intervalHandle);
  intervalHandle = null;
}

function isOwner(userId) {
  return settings.isOwner(userId);
}

function getSettings() { return { enabled: !!intervalHandle, cpuThreshold: Number(cfg.cpuThreshold), diskThresholdMb: Number(cfg.diskThresholdMb), intervalMs: Number(cfg.intervalMs) }; }
function setCpuThreshold(v) { cfg.cpuThreshold = Math.max(1, Math.min(5000, Number(v) || 1)); persistCfg(); return cfg.cpuThreshold; }
function setDiskThreshold(v) { cfg.diskThresholdMb = Math.max(128, Math.min(102400, Number(v) || 128)); persistCfg(); return cfg.diskThresholdMb; }
function setEnabled(bot, on) { if (on) { cfg.enabled = true; persistCfg(); startMonitor(bot); } else { cfg.enabled = false; persistCfg(); stopMonitor(); } return !!intervalHandle; }

function setIntervalMs(v) {
  const ms = Math.max(15000, Math.min(86400000, Number(v) || 120000));
  cfg.intervalMs = Math.round(ms);
  persistCfg();
  if (intervalHandle) {
    // Restart immediately with the new interval.
    stopMonitor();
    startMonitor(lastBot);
  }
  return cfg.intervalMs;
}
let lastBot = null;

// ─── Bot commands ───────────────────────────────────────────

function register(bot) {
  if (cfg.enabled) startMonitor(bot);

  // ── Toggle on/off ──
  bot.onText(/^\/antikill\s+(on|off)$/i, async (msg, match) => {
    const chatId = msg.chat.id;
    if (!isOwner(msg.from.id)) {
      return bot.sendMessage(
        chatId,
        "<blockquote expandable>◈ <b>Akses Ditolak</b>\nPerintah ini khusus owner.</blockquote>",
        { parse_mode: "HTML" }
      );
    }

    const mode = match[1].toLowerCase();
    if (mode === "on") {
      if (intervalHandle) {
        return bot.sendMessage(
          chatId,
          "<blockquote expandable>◈ <b>Sudah Aktif</b>\nAnti Kill Panel sudah berjalan.</blockquote>",
          { parse_mode: "HTML" }
        );
      }
      startMonitor(bot);
      return bot.sendMessage(
        chatId,
        `<blockquote expandable>◉ <b>Anti Kill Panel Aktif</b>\nCek otomatis setiap ${(cfg.intervalMs / 1000).toFixed(0)} detik.\nSelf-server: ${SELF_IDENTIFIER || "<i>belum diset</i>"}</blockquote>`,
        { parse_mode: "HTML" }
      );
    } else {
      if (!intervalHandle) {
        return bot.sendMessage(
          chatId,
          "<blockquote expandable>◈ <b>Belum Aktif</b>\nAnti Kill Panel belum berjalan.</blockquote>",
          { parse_mode: "HTML" }
        );
      }
      stopMonitor();
      return bot.sendMessage(
        chatId,
        "<blockquote expandable>◇ <b>Anti Kill Panel Dimatikan</b>\nMonitor otomatis dihentikan.</blockquote>",
        { parse_mode: "HTML" }
      );
    }
  });

  // ── Cek manual sekali jalan ──
  bot.onText(/^\/checkkill$/i, async (msg) => {
    const chatId = msg.chat.id;
    if (!isOwner(msg.from.id)) {
      return bot.sendMessage(
        chatId,
        "<blockquote expandable>◈ <b>Akses Ditolak</b>\nPerintah ini khusus owner.</blockquote>",
        { parse_mode: "HTML" }
      );
    }

    const wait = await bot.sendMessage(
      chatId,
      "<blockquote expandable>↻ <b>Sedang Mengecek</b>\nMengecek CPU/Disk semua server...</blockquote>",
      { parse_mode: "HTML" }
    );
    const result = await runCheck(bot);

    if (result.skipped) {
      return bot.editMessageText(
        "<blockquote expandable>◇ <b>Pengecekan Dilewati</b>\nTidak ada server yang dapat dicek saat ini.</blockquote>",
        { chat_id: chatId, message_id: wait.message_id, parse_mode: "HTML" }
      );
    }

    if (!result.flagged.length) {
      return bot.editMessageText(
        `<blockquote expandable>◉ <b>Semua Aman</b>\nSelesai cek ${result.checked} server. Tidak ada yang mencurigakan.</blockquote>`,
        { chat_id: chatId, message_id: wait.message_id, parse_mode: "HTML" }
      );
    }

    let lines = `<blockquote expandable>◈ <b>Hasil Pengecekan</b>\nDiperiksa: ${result.checked} server — Flagged: ${result.flagged.length}</blockquote>\n\n`;
    result.flagged.forEach((f, i) => {
      const aksi = f.selfServer
        ? (f.cpuCapped ? `◉ CPU di-cap ke ${CPU_CAP}%` : "◈ Self-server, hanya lapor")
        : (f.suspended ? "◉ Disuspend" : "◇ Gagal suspend");
      lines +=
        `${i + 1}. <b>${f.name}</b>\n` +
        `   ID: <code>${f.id}</code> | CPU: ${f.cpuPct.toFixed(1)}% | Disk: ${f.diskMb.toFixed(0)} MB\n` +
        `   ${aksi}\n\n`;
    });

    await bot.editMessageText(lines, {
      chat_id: chatId,
      message_id: wait.message_id,
      parse_mode: "HTML",
    });
  });

  // ── Status monitor ──
  bot.onText(/^\/antikillstatus$/i, async (msg) => {
    const chatId = msg.chat.id;
    if (!isOwner(msg.from.id)) {
      return bot.sendMessage(
        chatId,
        "<blockquote expandable>◈ <b>Akses Ditolak</b>\nPerintah ini khusus owner.</blockquote>",
        { parse_mode: "HTML" }
      );
    }
    const statusText =
      `<blockquote expandable>⌗ <b>Status Anti Kill Panel</b>\n\n` +
      `Monitor     : ${intervalHandle ? "◉ Aktif" : "◇ Mati"}\n` +
      `Interval    : ${(cfg.intervalMs / 1000).toFixed(0)} detik\n` +
      `Batas CPU   : ${cfg.cpuThreshold}%\n` +
      `Batas Disk  : ${cfg.diskThresholdMb} MB\n` +
      `Cap CPU     : ${CPU_CAP}%\n` +
      `Self-server : ${SELF_IDENTIFIER || "<i>belum diset (isi di settings.antiKill.selfIdentifier)</i>"}` +
      `</blockquote>`;
    return bot.sendMessage(chatId, statusText, { parse_mode: "HTML" });
  });
}

module.exports = register;
module.exports.getSettings = getSettings;
module.exports.setCpuThreshold = setCpuThreshold;
module.exports.setDiskThreshold = setDiskThreshold;
module.exports.setEnabled = setEnabled;
module.exports.setIntervalMs = setIntervalMs;
module.exports.runCheck = runCheck;

