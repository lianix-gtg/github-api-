/*
 * ============================================================
 * 🎬 AM PREMIUM — BULK EMAIL + TEMP MAIL OTOMATIS
 * ============================================================
 * 1) BULK EMAIL   : kirim magic link ke banyak email sekaligus
 * 2) TEMP MAIL    : generate email temp dari provider tempmail + bot
 *                   cek inbox otomatis dan ambil magic link
 * Jangan tambah fitur "jalankan otomatis" (am_run) di sini.
 */
/**
 * src/am.js — AM Premium Creator Tool
 * Credit By Zix | Ported ke Telegram Bot
 * Modified: Bulk Email + Temp Mail Otomatis (tempmail API)
 *
 * Command: /amprem
 * Akses: Premium ke atas
 */

const https    = require('https');
const http     = require('http');
const { URL }  = require('url');
const crypto   = require('crypto');
const zlib     = require('zlib');
const fs       = require('fs');
const settings = require('../settings.js');
const { getUserRoleExtended } = require('./limit.js');
const { reportError } = require('./data/errorReporter.js');
const { GeneratorEmail } = require('./generatorEmail.js');
const tempMailClients = new Map(); // provider 1 mailbox clients
const { createAmApiV2 } = require('./amApiV2.js');

// ─── Role check ───────────────────────────────────────────────────────────────
const AM_ALLOWED_ROLES = new Set(['developer','owner','god','khusus','king','cofounder','pemilik','premium','pt','tk','ceo','founder']);
const AM_UNLIMITED_ROLES = new Set(['developer','owner','cofounder','king','khusus','god']);
function userRole(userId) {
  return String(getUserRoleExtended(userId)).toLowerCase();
}
function isAllowed(userId) {
  return AM_ALLOWED_ROLES.has(userRole(userId));
}
function isOwner(userId) { return settings.isOwner(userId); }
function isDeveloper(userId) { return isOwner(userId) || userRole(userId) === 'developer'; }
function isAmChatAllowed(msg) {
  const type = String(msg?.chat?.type || '').toLowerCase();
  if (type === 'group' || type === 'supergroup') return true;
  return isDeveloper(msg?.from?.id);
}
function amChatDeniedText(msg) {
  const type = String(msg?.chat?.type || '').toLowerCase();
  if (type === 'private') {
    return '<b>AM PREMIUM hanya dapat dipakai di grup.</b>\n\nPrivate chat dibatasi untuk <b>DEVELOPER</b> saja.';
  }
  return '<b>AM PREMIUM hanya dapat dipakai di grup.</b>';
}
function accessDeniedText(role) {
  return `<b>⛔ AKSES AM PREMIUM DITOLAK</b>\n\nFitur <b>AM PREMIUM</b> khusus untuk <b>PREMIUM</b> ke atas.\nRole kamu: <b>${esc(String(role).toUpperCase())}</b>\n\nRole <b>RESELLER</b> dan <b>MEMBER</b> tidak dapat menggunakan fitur ini.`;
}
function esc(s='') { return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function q(msg)    { return msg?.message_id ? { reply_to_message_id: msg.message_id } : {}; }
function maskEmail(email='') {
  const v=String(email).trim(), at=v.indexOf('@');
  if(at<=0) return v.replace(/.(?=.)/g,'*');
  const local=v.slice(0,at), domain=v.slice(at);
  if(local.length<=2) return `${local[0]||'*'}*${domain}`;
  return `${local[0]}${'*'.repeat(Math.max(2,local.length-2))}${local[local.length-1]}${domain}`;
}
function sleep(ms) { return new Promise(r=>setTimeout(r,ms)); }

// ─── HTTP helpers (native, no axios) ──────────────────────────────────────────
function rawRequest(urlStr, options={}, body=null) {
  return new Promise((resolve,reject)=>{
    const url  = new URL(urlStr);
    const mod  = url.protocol==='https:' ? https : http;
    const opts = {
      hostname : url.hostname,
      port     : url.port || (url.protocol==='https:' ? 443 : 80),
      path     : url.pathname + url.search,
      method   : options.method || 'GET',
      headers  : options.headers || {},
      timeout  : options.timeout || 30000,
    };
    const req = mod.request(opts, r=>{
      const chunks=[];
      r.on('data',c=>chunks.push(c));
      r.on('end',()=>{
        let raw=Buffer.concat(chunks);
        try {
          const enc=r.headers['content-encoding'];
          if(enc==='gzip')    raw=zlib.gunzipSync(raw);
          else if(enc==='deflate') raw=zlib.inflateSync(raw);
          else if(enc==='br') raw=zlib.brotliDecompressSync(raw);
        } catch {}
        const text=raw.toString('utf8');
        let json=null; try{json=JSON.parse(text);}catch{}
        resolve({ statusCode:r.statusCode, headers:r.headers, text, json });
      });
    });
    req.on('error',reject);
    req.on('timeout',()=>{ req.destroy(); reject(new Error('Request timeout')); });
    if(body) req.write(body);
    req.end();
  });
}
function httpGet(urlStr, extraHeaders={}) {
  return rawRequest(urlStr, {
    method:'GET',
    headers:{
      'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/149.0.0.0 Safari/537.36',
      'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
      'Accept-Language':'en-US,en;q=0.9',
      'Accept-Encoding':'gzip, deflate, br',
      ...extraHeaders,
    }
  });
}
function httpPostJson(urlStr, body, extraHeaders={}) {
  const payload=JSON.stringify(body);
  return rawRequest(urlStr, {
    method:'POST',
    headers:{
      'User-Agent':'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 Chrome/150.0.0.0 Mobile Safari/537.36',
      'Accept':'application/json',
      'Content-Type':'application/json',
      'Content-Length':Buffer.byteLength(payload),
      ...extraHeaders,
    }
  }, payload);
}

// ─── Notify helpers ───────────────────────────────────────────────────────────
async function notifyAmFinal(bot,{msg,email,status,detail=''}) {
  const channelId=settings.notifChannelId;
  if(!channelId||!bot) return;
  const who=msg?.from||{};
  const name=[who.first_name,who.last_name].filter(Boolean).join(' ')||'-';
  const username=who.username?`@${who.username}`:'-';
  const ok=String(status).toLowerCase()==='success';
  const caption=
    `<b>╭━━〔 AM PREMIUM ${ok?'SUCCESS':'FAILED'} 〕━━╮</b>\n`+
    `👤 <b>User:</b> ${esc(name)}\n`+
    `🔗 <b>Username:</b> ${esc(username)}\n`+
    `🆔 <b>ID:</b> <code>${esc(who.id||'-')}</code>\n`+
    `📧 <b>Email:</b> <code>${esc(maskEmail(email))}</code>\n`+
    `${ok?'✅':'❌'} <b>Status:</b> ${ok?'PREMIUM AKTIF':'GAGAL'}\n`+
    (detail?`📌 <b>Detail:</b> ${esc(detail)}\n`:'')+
    `╰━━━━━━━━━━━━━━━━━━━━━━╯`;
  try {
    if(settings.notifChannelImage) {
      try { await bot.sendPhoto(channelId, settings.notifChannelImage, {caption, parse_mode:'HTML'}); }
      catch { await bot.sendMessage(channelId, caption, {parse_mode:'HTML'}); }
    } else {
      await bot.sendMessage(channelId, caption, {parse_mode:'HTML'});
    }
  } catch {}
}
async function notifyAmError(bot,{msg,stage='unknown',error,email='-'}) {
  const adminId=settings.ownerId||settings.dev;
  if(!adminId||!bot) return;
  const who=msg?.from||{};
  const raw=error?.stack||error?.message||String(error||'Unknown error');
  const code=`AM-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2,7).toUpperCase()}`;
  const caption=
    `<b>╭━━〔 AM ERROR REPORT 〕━━╮</b>\n`+
    `👤 <b>User:</b> ${esc([who.first_name,who.last_name].filter(Boolean).join(' ')||'-')}\n`+
    `🆔 <b>ID:</b> <code>${esc(who.id||'-')}</code>\n`+
    `📧 <b>Email:</b> <code>${esc(maskEmail(email))}</code>\n`+
    `⚙️ <b>Stage:</b> <code>${esc(stage)}</code>\n`+
    `🧾 <b>Error Code:</b> <code>${code}</code>\n\n`+
    `<pre>${esc(raw.slice(0,3500))}</pre>\n`+
    `╰━━━━━━━━━━━━━━━━━━━━━━╯`;
  try { await bot.sendMessage(adminId, caption, {parse_mode:'HTML'}); } catch {}
}

// ═══════════════════════════════════════════════════════════════════════════════
//  TEMP MAIL — generator.email backend
//  Provider: https://generator.email
// ═══════════════════════════════════════════════════════════════════════════════
// ═══════════════════════════════════════════════════════════════════════════════
// TEMP MAIL — provider dari JS terbaru yang diberikan
// Endpoint: https://creatett-seven.vercel.app/api/tempmail
// ═══════════════════════════════════════════════════════════════════════════════
const TEMP_MAIL_BASE = 'https://creatett-seven.vercel.app/api/tempmail';

function normalizeTempMessages(data) {
  if (Array.isArray(data)) return data;
  if (Array.isArray(data?.messages)) return data.messages;
  if (Array.isArray(data?.inbox)) return data.inbox;
  if (Array.isArray(data?.data)) return data.data;
  if (Array.isArray(data?.result)) return data.result;
  if (Array.isArray(data?.data?.messages)) return data.data.messages;
  if (Array.isArray(data?.data?.inbox)) return data.data.inbox;
  if (Array.isArray(data?.result?.messages)) return data.result.messages;
  return [];
}

// ─── Magic Link Helpers ──────────────────────────────────────────────────────

/**
 * Ekstrak URL pertama dari string body email.
 * Prioritas: URL yang mengandung alight / magic / verify / token.
 */
function extractMagicLink(text) {
  if (!text || typeof text !== 'string') return null;
  const all = [];
  const re = /https?:\/\/[^\s"'<>\)\]]+/gi;
  let m;
  while ((m = re.exec(text)) !== null) {
    all.push(m[0].replace(/[),.;>\]]+$/, ''));
  }
  if (!all.length) return null;
  // Prioritaskan URL yang mengandung kata kunci khas magic link
  const priority = all.find(u =>
    /alight|magic|verif|token|confirm|auth|login/i.test(u)
  );
  return priority || all[0];
}



function safeExtractMagicLink(text) {
  if (!text || typeof text !== 'string') return null;
  try {
    if (typeof extractMagicLink === 'function') return extractMagicLink(text);
  } catch {}
  const matches = String(text).match(/https?:\/\/[^\s\"'<>\)\]]+/gi) || [];
  const urls = matches.map(u => u.replace(/[),.;>\]]+$/, ''));
  return urls.find(u => /alight|magic|verif|token|confirm|auth|login/i.test(u)) || urls[0] || null;
}

/**
 * Validasi apakah string adalah URL valid.
 * Cukup longgar — user sudah tahu mereka harus kirim magic link AM.
 * Menerima URL http/https apapun yang panjangnya wajar.
 */
function isValidAlightMagicLink(link) {
  if (!link || typeof link !== 'string') return false;
  const trimmed = link.trim();
  // Harus dimulai dengan http:// atau https://
  if (!/^https?:\/\//i.test(trimmed)) return false;
  // Minimal panjang masuk akal untuk magic link (bukan URL kosong)
  if (trimmed.length < 20) return false;
  // Coba parse URL
  try { new URL(trimmed); } catch { return false; }
  return true;
}

// ─────────────────────────────────────────────────────────────────────────────

function deepFindLinks(value, out=[]) {
  if (value == null) return out;
  if (typeof value === 'string') {
    const matches = value.match(/https?:\/\/[^\s"'<>]+/gi) || [];
    for (const u of matches) if (!out.includes(u)) out.push(u.replace(/[),.;]+$/,''));
    return out;
  }
  if (Array.isArray(value)) for (const x of value) deepFindLinks(x,out);
  else if (typeof value === 'object') for (const v of Object.values(value)) deepFindLinks(v,out);
  return out;
}

function pickEmail(data) {
  const candidates = [data?.email,data?.address,data?.mail,data?.data?.email,data?.data?.address];
  for (const x of candidates) if (typeof x === 'string' && /@/.test(x)) return x.trim().toLowerCase();
  return null;
}

async function tempMail2ProbeInbox(email) {
  try {
    const res = await httpGet(`${TEMP_MAIL_BASE}/inbox/${encodeURIComponent(email)}`);
    return {
      ok: res.statusCode >= 200 && res.statusCode < 300,
      statusCode: res.statusCode,
    };
  } catch (e) {
    return { ok: false, statusCode: 0, error: e };
  }
}

async function tempMail2Get() {
  /*
   * Provider 2 sebelumnya langsung mengembalikan mailbox tanpa memastikan
   * endpoint inbox dapat diakses. Akibatnya mailbox berhasil dibuat, tetapi
   * setiap polling berikutnya selalu mendapat HTTP 403 selama 5 menit.
   *
   * Sekarang mailbox divalidasi SEBELUM magic-link dikirim:
   *   1. Coba creatett-seven.
   *   2. Probe endpoint inbox.
   *   3. Jika inbox 403/4xx/5xx, jangan gunakan mailbox tersebut.
   *   4. Fallback ke Generator.email (provider 1) secara otomatis.
   *
   * Dengan cara ini kita tidak mengirim magic-link ke alamat yang sejak awal
   * tidak bisa dibaca inbox-nya.
   */
  try {
    const res = await httpGet(`${TEMP_MAIL_BASE}/create`);
    const email = pickEmail(res.json);

    if (res.statusCode >= 200 && res.statusCode < 300 && email) {
      const probe = await tempMail2ProbeInbox(email);

      if (probe.ok) {
        const [username, domain] = email.split('@');
        console.log(`[tempMail2Get] creatett mailbox ready: ${email}`);
        return {
          email,
          username,
          domain,
          password: null,
          token: null,
          base: TEMP_MAIL_BASE,
          inboxUrl: `${TEMP_MAIL_BASE}/inbox/${encodeURIComponent(email)}`,
          provider: 2,
          providerBackend: 'creatett',
        };
      }

      console.warn(
        `[tempMail2Get] creatett inbox tidak dapat diakses (HTTP ${probe.statusCode || 'NETWORK'}); menggunakan fallback Generator.email`
      );
    } else {
      console.warn(`[tempMail2Get] creatett create gagal (HTTP ${res.statusCode}); menggunakan fallback Generator.email`);
    }
  } catch (e) {
    console.warn(`[tempMail2Get] creatett create/probe gagal: ${e.message}; menggunakan fallback Generator.email`);
  }

  // Fallback resmi dari project yang sama. Email baru dibuat di provider lain,
  // sehingga magic-link tetap dikirim ke mailbox yang benar-benar dapat dibaca.
  try {
    const fallback = await tempMail1Get();
    if (!fallback?.email) throw new Error('Generator.email tidak menghasilkan mailbox');

    console.log(`[tempMail2Get] fallback mailbox ready: ${fallback.email}`);
    return {
      ...fallback,
      provider: 2,
      providerBackend: 'generator-email',
      fallbackFrom: 'creatett-seven',
    };
  } catch (e) {
    console.error(`[tempMail2Get] semua provider gagal: ${e.message}`);
    return null;
  }
}

async function tempMail2CheckInbox(username, domain, meta = {}) {
  const email = username && domain ? `${username}@${domain}` : String(username || '');
  if (!email || !email.includes('@')) return [];

  // Provider 2 dapat transparan memakai Generator.email sebagai fallback.
  if (meta?.providerBackend === 'generator-email') {
    return tempMail1CheckInbox(username, domain);
  }

  try {
    const res = await httpGet(`${TEMP_MAIL_BASE}/inbox/${encodeURIComponent(email)}`);

    // 403 dari upstream bukan error Node.js; ini berarti provider menolak
    // akses inbox. Jangan spam console.warn pada setiap siklus polling.
    if (res.statusCode === 403) return [];
    if (res.statusCode < 200 || res.statusCode >= 300) {
      if (res.statusCode >= 500) {
        console.warn(`[tempMail2CheckInbox] upstream HTTP ${res.statusCode}`);
      }
      return [];
    }

    const messages = normalizeTempMessages(res.json);
    return messages.map((m) => {
      const links = deepFindLinks(m);
      const body = [m?.body,m?.text,m?.html,m?.content,m?.message].filter(Boolean).join('\n');
      const bodyLinks = deepFindLinks(body);
      return {
        id: m?.id || m?._id || '',
        from: m?.from?.address || m?.from?.email || m?.from || m?.sender || '',
        subject: m?.subject || m?.title || '',
        date: m?.date || m?.createdAt || m?.timestamp || '',
        body,
        verification_link:
          m?.verification_link ||
          m?.verificationLink ||
          m?.magic_link ||
          m?.magicLink ||
          bodyLinks[0] ||
          links[0] ||
          null,
        link: m?.link || ''
      };
    });
  } catch (e) {
    // Network failure ditangani sebagai inbox kosong. Error monitor tidak
    // dipanggil karena wait loop memang memiliki retry/polling sendiri.
    return [];
  }
}

async function tempMail2WaitForLink(username, domain, timeoutMs=300000, meta = {}) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const msgs = await tempMail2CheckInbox(username, domain, meta);
    for (const m of msgs) {
      if (m.verification_link) return m.verification_link;
      const link = safeExtractMagicLink(m.body) || safeExtractMagicLink(m.subject);
      if (link) return link;
    }
    await sleep(5000);
  }
  return null;
}


// ─── Provider 1: Generator.email ───────────────────────────────────────────
async function tempMail1Get() {
  const client = new GeneratorEmail({ timeout: 15000 });
  const email = await client.generateEmail();
  if (!email || !email.includes('@')) throw new Error('Generator.email tidak menghasilkan email valid');
  const [username, domain] = email.split('@');
  tempMailClients.set(email, client);
  return { email, username, domain, password:null, token:null, base:GeneratorEmail.BASE_URL, provider:1, inboxUrl:`${GeneratorEmail.BASE_URL}/${email}` };
}

async function tempMail1CheckInbox(username, domain) {
  const email = username && domain ? `${username}@${domain}` : String(username || '');
  if (!email.includes('@')) return [];
  let client = tempMailClients.get(email);
  if (!client) { client = new GeneratorEmail({ timeout:15000 }); tempMailClients.set(email, client); }
  try {
    const inbox = await client.checkInbox(email);
    const raw = Array.isArray(inbox?.messages) ? inbox.messages : [];
    const out=[];
    for (const m of raw.slice(0,20)) {
      let detail=null;
      if (m.link) { try { detail=await client.readMessage(email,m.link); } catch {} }
      const body=detail?.body || detail?.bodyText || '';
      out.push({
        id:m.link||'', from:detail?.from||m.from||'', subject:detail?.subject||m.subject||'',
        date:detail?.date||m.date||'', body,
        verification_link:detail?.verification_link||safeExtractMagicLink(body)||null, link:m.link||''
      });
    }
    return out;
  } catch(e) { console.warn('[tempMail1CheckInbox]',e.message); return []; }
}

async function tempMail1WaitForLink(username, domain, timeoutMs=300000) {
  const start=Date.now();
  while(Date.now()-start<timeoutMs) {
    const msgs=await tempMail1CheckInbox(username,domain);
    for(const m of msgs) { if(m.verification_link) return m.verification_link; const link=safeExtractMagicLink(m.body)||safeExtractMagicLink(m.subject); if(link) return link; }
    await sleep(5000);
  }
  return null;
}

function tempMailProviderInfo(provider) {
  return provider===1 ? { name:'Temp Mail 1', label:'Temp Mail 1 — Generator.email', base:GeneratorEmail.BASE_URL } : { name:'Temp Mail 2', label:'Temp Mail 2 — creatett-seven.vercel.app', base:TEMP_MAIL_BASE };
}

async function generateTempMail(provider) {
  return provider===1 ? tempMail1Get() : tempMail2Get();
}

async function checkTempMailInbox(entry) {
  return entry?.provider===1
    ? tempMail1CheckInbox(entry.username,entry.domain)
    : tempMail2CheckInbox(entry.username,entry.domain,entry);
}

async function waitTempMailLink(entry, timeoutMs=300000) {
  return entry?.provider===1
    ? tempMail1WaitForLink(entry.username,entry.domain,timeoutMs)
    : tempMail2WaitForLink(entry.username,entry.domain,timeoutMs,entry);
}

// ═══════════════════════════════════════════════════════════════════════════════
//  BULK EMAIL — API alightmotion (multi-endpoint + retry)
// ═══════════════════════════════════════════════════════════════════════════════
const BASE_CUSTOM   = 'https://alightfree.my.id/api';
const CUSTOM_ORIGIN = 'https://alightfree.my.id';

// Fallback endpoint list — dicoba satu per satu sampai ada yang berhasil.
// Tambahkan endpoint baru di sini jika endpoint utama mati.
const AM_SEND_ENDPOINTS = [
  {
    url: 'https://alightfree.my.id/api/send',
    origin: 'https://alightfree.my.id',
    buildBody: (email) => JSON.stringify({ email }),
  },
];

// Coba satu endpoint: return { success, data, response, error }
async function _trySendEndpoint(endpoint, email) {
  const body = endpoint.buildBody(email);
  const alightCookie = settings.alightfreeCookie || '';
  const res = await rawRequest(endpoint.url, {
    method: 'POST',
    timeout: 15000,
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36',
      'Accept': 'application/json, text/plain, */*',
      'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(body),
      'Origin': endpoint.origin,
      'Referer': `${endpoint.origin}/dashboard/activation`,
      'sec-ch-ua': '"Chromium";v="152", "Not?A_Brand";v="24", "Google Chrome";v="152"',
      'sec-ch-ua-mobile': '?0',
      'sec-ch-ua-platform': '"Windows"',
      'sec-fetch-dest': 'empty',
      'sec-fetch-mode': 'cors',
      'sec-fetch-site': 'same-origin',
      ...(alightCookie ? { 'Cookie': alightCookie } : {}),
    },
  }, body);

  const json = res.json || {};
  const rawText = String(res.text || '').trim();
  const message = String(json.message || json.statusText || '').trim() ||
                  (typeof json.error === 'string' ? json.error : '') ||
                  rawText.slice(0, 300);

  // Deteksi gagal: explicit false flag ATAU status 4xx/5xx
  const explicitFail =
    json.status === false ||
    json.success === false ||
    json.error === true ||
    (typeof json.error === 'string' && json.error.length > 0 && !json.message);

  const httpFail = res.statusCode < 200 || res.statusCode >= 300;

  console.log(`[AM send] ${endpoint.url} → HTTP ${res.statusCode} | body: ${rawText.slice(0, 200)}`);

  if (!explicitFail && !httpFail) {
    return { success: true, data: json, response: res };
  }
  return {
    success: false,
    error: `HTTP ${res.statusCode}${message ? `: ${message.slice(0, 400)}` : ''}`,
    response: res,
  };
}

async function customEmailSendVerif(email) {
  try {
    email = String(email || '').trim();
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return { success: false, error: 'Alamat email tidak valid.' };
    }
    globalThis.__YOEN_AM_MAGIC_SENDING = (globalThis.__YOEN_AM_MAGIC_SENDING || 0) + 1;

    const MAX_RETRY = 2; // per endpoint
    let lastError = '';

    for (const endpoint of AM_SEND_ENDPOINTS) {
      for (let attempt = 1; attempt <= MAX_RETRY; attempt++) {
        try {
          const result = await _trySendEndpoint(endpoint, email);
          if (result.success) return result;
          lastError = result.error;
          console.warn(`[AM send] attempt ${attempt}/${MAX_RETRY} failed on ${endpoint.url}: ${lastError}`);
          if (attempt < MAX_RETRY) await sleep(1500 * attempt);
        } catch (e) {
          lastError = e?.message || String(e);
          console.warn(`[AM send] attempt ${attempt}/${MAX_RETRY} threw on ${endpoint.url}: ${lastError}`);
          if (attempt < MAX_RETRY) await sleep(1500 * attempt);
        }
      }
    }

    return { success: false, error: `Semua endpoint gagal. Error terakhir: ${lastError}` };
  } catch (e) {
    return { success: false, error: `Provider tidak merespons: ${e?.message || e}` };
  } finally {
    globalThis.__YOEN_AM_MAGIC_SENDING = Math.max(0, Number(globalThis.__YOEN_AM_MAGIC_SENDING || 1) - 1);
  }
}

function extractFirebaseActionLink(rawLink) {
  let current = String(rawLink || '').trim();
  for (let i = 0; i < 3; i++) {
    try {
      const u = new URL(current);
      const nested = u.searchParams.get('link');
      if (!nested) return current;
      current = nested;
    } catch {
      try { current = decodeURIComponent(current); } catch { break; }
    }
  }
  return current;
}

function extractOobCode(rawLink) {
  const candidates = [String(rawLink || ''), extractFirebaseActionLink(rawLink)];
  for (const candidate of candidates) {
    try {
      const u = new URL(candidate);
      const value = u.searchParams.get('oobCode');
      if (value) return value;
    } catch {}

    // Menangani URL Firebase yang meng-encode tanda '=' dan '&' di parameter link.
    const decoded = (() => {
      try { return decodeURIComponent(candidate); } catch { return candidate; }
    })();
    const m = decoded.match(/[?&]oobCode=([^&#]+)/i) || decoded.match(/oobCode%3D([^%&#]+)/i);
    if (m?.[1]) return m[1];
  }
  return null;
}

async function customEmailVerify(email, link) {
  const originalLink = String(link || '').trim();

  if (!/^https?:\/\//i.test(originalLink)) {
    return { success: false, error: 'Magic link bukan URL HTTP/HTTPS.' };
  }

  const extraHeaders = {
    'Referer': `${CUSTOM_ORIGIN}/dashboard/activation`,
    'Origin': CUSTOM_ORIGIN,
    'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
    'sec-ch-ua': '"Chromium";v="152", "Not?A_Brand";v="24", "Google Chrome";v="152"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
  };

  // ── Step 1: /api/verify — confirmed payload: { email, rawLink }
  let verifyBody = {};
  try {
    const res = await httpPostJson(`${BASE_CUSTOM}/verify`, { email, rawLink: originalLink }, extraHeaders);
    verifyBody = res.json || {};
    const explicitFail = verifyBody.success === false || verifyBody.status === false;
    const message = String(verifyBody.message || verifyBody.error || res.text || '');
    console.log(`[AM verify] HTTP ${res.statusCode} | ${message.slice(0, 150)}`);
    if (explicitFail || res.statusCode < 200 || res.statusCode >= 300) {
      return { success: false, error: `[Verify] ${message.slice(0, 300) || 'API tidak merespons.'}` };
    }
  } catch (e) {
    return { success: false, error: `[Verify] ${e?.message || String(e)}` };
  }

  // ── Step 2: /api/premium — confirmed payload: { email, idToken }
  const idToken = verifyBody.idToken || verifyBody.profile?.idToken;
  if (!idToken) {
    return { success: false, error: '[Premium] idToken tidak ditemukan di response verify.' };
  }

  let premBody = {};
  try {
    const premRes = await httpPostJson(`${BASE_CUSTOM}/premium`, { email, idToken }, extraHeaders);
    premBody = premRes.json || {};
    const premMsg = String(premBody.message || premBody.error || premRes.text || '');
    console.log(`[AM premium] HTTP ${premRes.statusCode} | ${premMsg.slice(0, 150)}`);

    const premFail = premBody.success === false || premBody.status === false;
    if (premFail || premRes.statusCode < 200 || premRes.statusCode >= 300) {
      return { success: false, error: `[Premium] ${premMsg.slice(0, 300) || 'Gagal apply premium.'}` };
    }
  } catch (e) {
    return { success: false, error: `[Premium] ${e?.message || String(e)}` };
  }

  // ── Return shape yang cocok dengan caller:
  // caller cek: verifyRes.success===true && verifyBody.success===true && verifyBody.message match regex
  // verifyBody = verifyRes.data
  const finalMessage = String(premBody.message || verifyBody.message || 'Premium berhasil diaktifkan.');
  return {
    success: true,
    data: {
      success: true,
      status: true,
      message: finalMessage,
      email,
      verify: verifyBody,
      premium: premBody,
      quota: premBody.quota || null,
    },
  };
}

// ═══════════════════════════════════════════════════════════════════════════════
//  LIMIT SYSTEM
// ═══════════════════════════════════════════════════════════════════════════════
const AM_LIMIT_FILE     = require('path').join(__dirname,'..','db','amPremLimit.json');
const AM_LIMIT_DEFAULTS = { premium:1, pt:1, tk:1, ceo:1, founder:1, pemilik:1, cofounder:-1, king:-1, khusus:-1, god:-1, owner:-1, developer:-1 };

function loadAmLimitDb() {
  try { if(fs.existsSync(AM_LIMIT_FILE)) return JSON.parse(fs.readFileSync(AM_LIMIT_FILE,'utf8')); } catch {}
  const db={ limits:{...AM_LIMIT_DEFAULTS}, usage:{} };
  fs.mkdirSync(require('path').dirname(AM_LIMIT_FILE),{recursive:true});
  fs.writeFileSync(AM_LIMIT_FILE, JSON.stringify(db,null,2));
  return db;
}
function saveAmLimitDb(db) {
  fs.mkdirSync(require('path').dirname(AM_LIMIT_FILE),{recursive:true});
  fs.writeFileSync(AM_LIMIT_FILE, JSON.stringify(db,null,2));
}
function amLimitInfo(userId) {
  const role=String(getUserRoleExtended(userId)).toLowerCase();
  const db=loadAmLimitDb();
  const limit=db.limits[role]??0;
  if(AM_UNLIMITED_ROLES.has(role) || limit===-1) return { allowed:true, role, limit:null, used:0, remaining:null };
  const day=new Date().toISOString().slice(0,10);
  const key=String(userId), rec=db.usage[key];
  const used=rec?.date===day ? Number(rec.count||0) : 0;
  return { allowed:used<Number(limit), role, limit:Number(limit), used, remaining:Math.max(Number(limit)-used,0), day };
}
function consumeAmLimit(userId) {
  const info=amLimitInfo(userId);
  if(!info.allowed||info.limit===null) return;
  const db=loadAmLimitDb(), key=String(userId), day=info.day;
  db.usage[key]={ date:day, count:info.used+1 };
  saveAmLimitDb(db);
}

// ═══════════════════════════════════════════════════════════════════════════════
//  SESSION STORE
// ═══════════════════════════════════════════════════════════════════════════════
const customEmailSessions = new Map(); // userId -> currently selected interactive session
// Semua sesi AM milik user disimpan terpisah. customEmailSessions hanya menunjuk sesi
// yang sedang dipilih untuk menerima input/link; sesi lain tetap hidup di registry.
const amSessionRegistry = new Map(); // userId -> Map(sessionKey -> session)
const tempMailStore       = new Map(); // userId -> [{email,username,domain,base,createdAt,...}]

function sessionUserKey(userId) { return String(userId); }
function sessionKeyOf(session) {
  return String(session?.sessionKey || session?.batchId || session?.sessionId || `am_${Date.now()}_${Math.random().toString(36).slice(2,8)}`);
}
function registerAmSession(userId, session, makeActive=true) {
  const uid=sessionUserKey(userId);
  if(!amSessionRegistry.has(uid)) amSessionRegistry.set(uid,new Map());
  const key=sessionKeyOf(session);
  session.sessionKey=key;
  session.lastActivatedAt = makeActive ? Date.now() : Number(session.lastActivatedAt||0);
  amSessionRegistry.get(uid).set(key,session);
  if(makeActive) customEmailSessions.set(uid,session);
  return session;
}
function getAmSessions(userId) { return amSessionRegistry.get(sessionUserKey(userId)) || new Map(); }
function getActiveAmSession(userId) { return customEmailSessions.get(sessionUserKey(userId)) || null; }
function setActiveAmSession(userId, session) {
  if(!session) { customEmailSessions.delete(sessionUserKey(userId)); return; }
  registerAmSession(userId,session,false);
  customEmailSessions.set(sessionUserKey(userId),session);
}
function removeAmSession(userId, sessionOrKey) {
  const uid=sessionUserKey(userId);
  const key=typeof sessionOrKey==='string' ? sessionOrKey : sessionKeyOf(sessionOrKey);
  const sessions=amSessionRegistry.get(uid);
  if(sessions) { sessions.delete(key); if(!sessions.size) amSessionRegistry.delete(uid); }
  const active=customEmailSessions.get(uid);
  if(active && sessionKeyOf(active)===key) customEmailSessions.delete(uid);
}
const tempMailManualSessions = new Map();
const bulkManualTempReturns = new Map(); // userId -> { idx, chatId, messageId, createdAt }
const bulkCustomCounts = new Map(); // userId -> custom bulk email count

// Semua mailbox disimpan ke disk supaya /start maupun restart proses tidak menghapus histori.
const TEMP_MAIL_HISTORY_FILE = require('path').join(__dirname,'..','db','tempMailHistory.json');
function loadTempMailHistoryDb() {
  try {
    if (fs.existsSync(TEMP_MAIL_HISTORY_FILE)) {
      const db = JSON.parse(fs.readFileSync(TEMP_MAIL_HISTORY_FILE, 'utf8'));
      if (db && typeof db === 'object' && db.users && typeof db.users === 'object') return db;
    }
  } catch {}
  const db = { users: {} };
  try {
    fs.mkdirSync(require('path').dirname(TEMP_MAIL_HISTORY_FILE), {recursive:true});
    fs.writeFileSync(TEMP_MAIL_HISTORY_FILE, JSON.stringify(db, null, 2));
  } catch {}
  return db;
}
function saveTempMailHistoryDb(db) {
  fs.mkdirSync(require('path').dirname(TEMP_MAIL_HISTORY_FILE), {recursive:true});
  fs.writeFileSync(TEMP_MAIL_HISTORY_FILE, JSON.stringify(db, null, 2));
}
function hydrateTempMailStore() {
  const db = loadTempMailHistoryDb();
  for (const [uid, list] of Object.entries(db.users || {})) {
    if (Array.isArray(list) && list.length) tempMailStore.set(String(uid), list);
  }
}
hydrateTempMailStore();

function tmStoreAdd(userId, entry) {
  const key = String(userId);
  if (!tempMailStore.has(key)) tempMailStore.set(key, []);
  const list = tempMailStore.get(key);
  const createdAt = entry.createdAt || Date.now();
  const normalized = { ...entry, createdAt, updatedAt: Date.now() };
  list.push(normalized);
  const db = loadTempMailHistoryDb();
  if (!Array.isArray(db.users[key])) db.users[key] = [];
  db.users[key].push(normalized);
  saveTempMailHistoryDb(db);
}

function tmStoreGet(userId) { return tempMailStore.get(String(userId)) || []; }

function tmStoreUpdate(userId, email, patch={}) {
  const key = String(userId);
  const list = tmStoreGet(key);
  const item = [...list].reverse().find(x => String(x.email) === String(email));
  if (item) Object.assign(item, patch, {updatedAt: Date.now()});
  const db = loadTempMailHistoryDb();
  const dbList = Array.isArray(db.users[key]) ? db.users[key] : [];
  const dbItem = [...dbList].reverse().find(x => String(x.email) === String(email));
  if (dbItem) Object.assign(dbItem, patch, {updatedAt: Date.now()});
  db.users[key] = dbList;
  saveTempMailHistoryDb(db);
}

// ─── Persistent AM Premium statistics ─────────────────────────────────────────
const AM_STATS_FILE = require('path').join(__dirname,'..','db','amPremStats.json');

const AM_HISTORY_FILE = require('path').join(__dirname,'..','db','amEmailHistory.json');

function loadAmHistoryDb() {
  try {
    if (fs.existsSync(AM_HISTORY_FILE)) return JSON.parse(fs.readFileSync(AM_HISTORY_FILE, 'utf8'));
  } catch {}
  const db = { users: {} };
  fs.mkdirSync(require('path').dirname(AM_HISTORY_FILE), { recursive: true });
  fs.writeFileSync(AM_HISTORY_FILE, JSON.stringify(db, null, 2));
  return db;
}
function saveAmHistoryDb(db) {
  fs.mkdirSync(require('path').dirname(AM_HISTORY_FILE), { recursive: true });
  fs.writeFileSync(AM_HISTORY_FILE, JSON.stringify(db, null, 2));
}
function addAmHistory(userId, entry) {
  const db = loadAmHistoryDb();
  const key = String(userId);
  if (!Array.isArray(db.users[key])) db.users[key] = [];
  db.users[key].push({
    email: String(entry.email || ''),
    type: entry.type || 'TEMP MAIL',
    status: entry.status || 'created',
    step: entry.step || '',
    sessionId: entry.sessionId || '',
    createdAt: entry.createdAt || Date.now(),
    updatedAt: entry.updatedAt || Date.now(),
    chatId: entry.chatId || '',
    messageId: entry.messageId || 0,
    batchId: entry.batchId || '',
    username: entry.username || '',
    domain: entry.domain || '',
    base: entry.base || ''
  });
  saveAmHistoryDb(db);
}
function updateAmHistory(userId, email, patch = {}) {
  const db = loadAmHistoryDb();
  const list = Array.isArray(db.users[String(userId)]) ? db.users[String(userId)] : [];
  const item = [...list].reverse().find(x => x.email === email);
  if (item) Object.assign(item, patch, { updatedAt: Date.now() });
  saveAmHistoryDb(db);
}
function getAmHistory(userId) {
  const db = loadAmHistoryDb();
  return Array.isArray(db.users[String(userId)]) ? [...db.users[String(userId)]].reverse() : [];
}
function amMainKeyboard(userId) {
  return {
    inline_keyboard: [
      [{ text:'Create Temp Mail', callback_data:'am_tempmail_menu' },
       { text:'Bulk Email', callback_data:'am_bulk_email' }],
      [{ text:'Histori Email Saya', callback_data:'am_history' },
       ...(isOwner(userId) ? [{ text:'List Email User', callback_data:'am_owner_users' }] : [])],
      [{ text:'⬅️ ‹', callback_data:'groupmenu' }]
    ]
  };
}
function amMainText(userId) {
  const info = amLimitInfo(userId);
  const lim = info.limit===null ? '∞' : `${info.remaining}/${info.limit}`;
  return `<b>╭━━〔 AM PREMIUM CREATOR 〕━━╮</b>\n`+
    `<i>Aktivasi Alight Motion Premium via email</i>\n\n`+
    `Pilih metode:\n`+
    `• <b>Create Temp Mail</b> — buat email sementara, kirim magic link, cek inbox.\n`+
    `• <b>Bulk Email</b> — proses beberapa email milikmu sekaligus.\n\n`+
    `Limit hari ini: <b>${lim}</b>`;
}

function findAmHistoryEntry(userId, sessionId) {
  const db = loadAmHistoryDb();
  const list = Array.isArray(db.users[String(userId)]) ? db.users[String(userId)] : [];
  return [...list].reverse().find(x => String(x.sessionId || '') === String(sessionId)) || null;
}
function getAmBatchHistory(userId, batchId) {
  const db = loadAmHistoryDb();
  const list = Array.isArray(db.users[String(userId)]) ? db.users[String(userId)] : [];
  return list.filter(x => String(x.batchId || '') === String(batchId));
}

function formatAmHistory(userId) {
  const list = getAmHistory(userId);
  if (!list.length) {
    return `<b>╭━━〔 📜 RIWAYAT AM PREMIUM 〕━━╮</b>\n\n` +
      `<blockquote expandable>Belum ada email yang dibuat.\n\nGunakan <b>Temp Mail</b> dari menu AM Premium untuk membuat email.</blockquote>`;
  }
  const rows = list.map((x, i) => {
    const d = new Date(x.createdAt).toLocaleString('id-ID', {
      timeZone: 'Asia/Jakarta', day: '2-digit', month: '2-digit',
      year: 'numeric', hour: '2-digit', minute: '2-digit'
    });
    const status = x.status === 'success' ? '🟢 Berhasil' :
      x.status === 'failed' ? '🔴 Gagal' :
      x.status === 'processing' ? '🔵 Masih proses' :
      x.status === 'waiting' ? '🟡 Menunggu' : '⚪ Dibuat';
    const resume = (x.status === 'processing' || x.status === 'waiting') && x.sessionId
      ? `\n   ▶️ <b>Lanjutkan tersedia</b>` : '';
    return `${i + 1}. <code>${esc(x.email)}</code>\n   ${x.type} • ${status}\n   <i>${esc(d)}</i>${resume}`;
  });
  return `<b>╭━━〔 📜 RIWAYAT AM PREMIUM 〕━━╮</b>\n` +
    `<i>Email yang pernah dibuat oleh akun ini</i>\n` +
    `📊 <b>Total email dibuat:</b> ${list.length}\n\n` +
    `<blockquote expandable>${rows.join('\n\n')}</blockquote>`;
}


function loadAmStatsDb() {
  try {
    if(fs.existsSync(AM_STATS_FILE)) return JSON.parse(fs.readFileSync(AM_STATS_FILE,'utf8'));
  } catch {}
  const db={ users:{} };
  fs.mkdirSync(require('path').dirname(AM_STATS_FILE),{recursive:true});
  fs.writeFileSync(AM_STATS_FILE,JSON.stringify(db,null,2));
  return db;
}
function saveAmStatsDb(db) {
  fs.mkdirSync(require('path').dirname(AM_STATS_FILE),{recursive:true});
  fs.writeFileSync(AM_STATS_FILE,JSON.stringify(db,null,2));
}
function addAmStat(userId, field, amount=1) {
  const db=loadAmStatsDb();
  const key=String(userId);
  if(!db.users[key]) db.users[key]={created:0,processed:0,sent:0,success:0,failed:0};
  db.users[key][field]=Number(db.users[key][field]||0)+Number(amount||0);
  saveAmStatsDb(db);
}
function getAmStats(userId) {
  const db=loadAmStatsDb();
  return db.users[String(userId)] || {created:0,processed:0,sent:0,success:0,failed:0};
}
function statsText(userId) {
  const st=getAmStats(userId);
  return `<b>╭━━〔 AM PREMIUM — STATISTIK 〕━━╮</b>\n\n`+
    `<blockquote expandable>`+
    `📧 <b>Email dibuat/diterima:</b> ${st.created}\n`+
    `📨 <b>Email diproses:</b> ${st.processed}\n`+
    `📬 <b>Magic link terkirim:</b> ${st.sent}\n`+
    `✅ <b>Berhasil:</b> ${st.success}\n`+
    `❌ <b>Gagal:</b> ${st.failed}`+
    `</blockquote>`;
}

// ═══════════════════════════════════════════════════════════════════════════════
//  UI HELPERS
// ═══════════════════════════════════════════════════════════════════════════════
async function safeEdit(bot, chatId, msgId, text, replyMarkup={}) {
  try {
    return await bot.editMessageText(text, {
      chat_id:chatId, message_id:msgId,
      parse_mode:'HTML',
      reply_markup: replyMarkup,
    });
  } catch (editError) {
    // Jangan membuat bot terlihat diam hanya karena pesan lama/tidak bisa diedit.
    // Jika edit gagal, kirim pesan baru sebagai fallback.
    try {
      return await bot.sendMessage(chatId, text, {
        parse_mode:'HTML',
        reply_markup: replyMarkup,
      });
    } catch (sendError) {
      console.error('[AM safeEdit] edit & fallback send gagal:', editError?.message || editError, sendError?.message || sendError);
      return null;
    }
  }
}

function cancelBtn(userId) {
  return { inline_keyboard:[[{ text:'Temp Mail', callback_data:`am_bulk_manual_temp_${userId}` },{ text:'Batal', callback_data:`am_custom_cancel_${userId}` }]] };
}

function bulkManualPromptMarkup(userId) {
  return { inline_keyboard:[
    [{ text:'Temp Mail', callback_data:`am_bulk_manual_temp_${userId}` }],
    [{ text:'Batal', callback_data:`am_custom_cancel_${userId}` }]
  ] };
}

function renderBulkStatusText(bulkResults, allEmails, label='') {
  const lines = allEmails.map((em,i)=>{
    const res = bulkResults.find(r=>r.email===em);
    if(!res)                     return `${i+1}. <code>${esc(em)}</code> — ⏳`;
    if(res.status==='sent')      return `${i+1}. <code>${esc(em)}</code> — 📬 Terkirim`;
    if(res.status==='fail')      return `${i+1}. <code>${esc(em)}</code> — ❌ Gagal`;
    if(res.status==='verified')  return `${i+1}. <code>${esc(em)}</code> — ✅ Aktif`;
    if(res.status==='verif_fail')return `${i+1}. <code>${esc(em)}</code> — ⚠️ Gagal verif`;
    return `${i+1}. <code>${esc(em)}</code> — ⏳`;
  });
  return (
    `<b>╭━━〔 AM PREMIUM — BULK EMAIL 〕━━╮</b>\n\n`+
    `<blockquote expandable>${label ? `⏳ <b>${esc(label)}</b>\n\n` : ''}`+
    lines.join('\n')+
    `</blockquote>`
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
//  MAIN EXPORT
// ═══════════════════════════════════════════════════════════════════════════════
module.exports = (bot) => {

  // Terima magic link manual dari user. Tidak ada auto-open/auto-verify.
  bot.on('message', async (msg) => {
    const userId = String(msg?.from?.id || '');
    const sess = tempMailManualSessions.get(userId);
    if (!sess || !msg?.text || /^\//.test(msg.text.trim())) return;
    if (Date.now() - sess.createdAt > 10 * 60 * 1000) {
      tempMailManualSessions.delete(userId);
      return;
    }
    // Ambil URL dengan regex yang tidak memotong query Firebase/encoded URL.
    const match = msg.text.match(/https?:\/\/[^\s<>]+/i);
    if (!match) {
      try { await bot.sendMessage(msg.chat.id, '<b>Magic link belum terbaca.</b>\nKirim 1 pesan yang hanya berisi URL <code>https://...</code>.', {parse_mode:'HTML', ...q(msg)}); } catch {}
      return;
    }
    let link = match[0].trim();
    // Hanya buang tanda baca yang jelas berada di luar URL; jangan menghapus ) karena bisa muncul pada path/query.
    link = link.replace(/[.,;!?}\]]+$/,'');
    const stored = tmStoreGet(userId);
    const entry = stored[sess.idx];
    tempMailManualSessions.delete(userId);
    if (!entry) {
      try { await bot.sendMessage(msg.chat.id, '<b>Sesi temp mail sudah tidak aktif.</b>\nTekan <b>Tempel Magic Link</b> lagi lalu kirim URL.', {parse_mode:'HTML', ...q(msg)}); } catch {}
      return;
    }
    if (!isValidAlightMagicLink(link)) {
      try { await bot.sendMessage(msg.chat.id, '<b>URL tidak valid.</b>\nPastikan yang dikirim adalah magic link lengkap dari email.', {parse_mode:'HTML', ...q(msg)}); } catch {}
      tempMailManualSessions.set(userId, sess);
      return;
    }
    entry.manualLink = link;
    entry.status = 'manual_link';
    try {
      await bot.sendMessage(msg.chat.id,
        `<b>╭━━〔 MAGIC LINK DITERIMA 〕━━╮</b>\n\n`+
        `📧 <code>${esc(entry.email)}</code>\n\n`+
        `✓ Link berhasil diterima dan disimpan.\n\n`+
        `<i>Bot tidak membuka/menjalankan link autentikasi secara otomatis.</i>`,
        {parse_mode:'HTML',...q(msg)}
      );
    } catch (e) {
      console.error('[AM manual link] gagal kirim konfirmasi:', e?.message || e);
    }
  });

  // ── /amlimit ─────────────────────────────────────────────────────────────
  bot.onText(/^\/amlimit(?:@\w+)?$/i, async (msg)=>{
    const info=amLimitInfo(msg.from.id);
    if(!AM_ALLOWED_ROLES.has(info.role)) return;
    const lim=info.limit===null ? '∞ Unlimited' : `${info.remaining}/${info.limit}`;
    return bot.sendMessage(msg.chat.id,
      `<blockquote expandable>◈ <b>LIMIT AM PREMIUM</b>\n\nRole: <b>${esc(info.role.toUpperCase())}</b>\nSisa hari ini: <b>${lim}</b>\nReset otomatis: <b>00:00 UTC</b></blockquote>`,
      { parse_mode:'HTML', ...q(msg) });
  });

  // ── /amlimitmenu — pengaturan limit AM (developer/owner only) ────────
  bot.onText(/^\/amlimitmenu(?:@\w+)?$/i, async (msg)=>{
    if(!isDeveloper(msg.from.id))
      return bot.sendMessage(msg.chat.id, '<b>Menu ini khusus developer.</b>', { parse_mode:'HTML', ...q(msg) });
    const db=loadAmLimitDb();
    const rows=['premium','pt','tk','ceo','founder','pemilik','cofounder','king','khusus','god']
      .map(role=>{
        const value=db.limits[role] ?? 1;
        return [{text:`${role.toUpperCase()}: ${value===-1?'∞':value+'x'}`, callback_data:`am_limit_role:${role}`}];
      });
    rows.push([{text:'Reset non-unlimited → 1x',callback_data:'am_limit_reset_1'}]);
    rows.push([{text:'Tutup',callback_data:'am_limit_close'}]);
    return bot.sendMessage(msg.chat.id,
      '<b>╭━━〔 PENGATURAN LIMIT AM PREMIUM 〕━━╮</b>\n\n'+
      '<blockquote expandable>Atur limit harian per role.\n<b>∞</b> = unlimited.\n\nHanya developer yang dapat mengubah pengaturan ini.</blockquote>',
      {parse_mode:'HTML',reply_markup:{inline_keyboard:rows},...q(msg)});
  });

  bot.onText(/^\/setamlimit\s+(\w+)\s+(\d+|unlimited)$/i, async (msg,match)=>{
    if(!isDeveloper(msg.from.id)) return;
    const role=String(match[1]).toLowerCase();
    const allowed=new Set(['premium','pt','tk','ceo','founder','pemilik','cofounder','king','khusus','god']);
    if(!allowed.has(role)) return bot.sendMessage(msg.chat.id,'❌ Role tidak valid untuk limit AM Premium.',q(msg));
    const value=match[2].toLowerCase()==='unlimited' ? -1 : Number(match[2]);
    const db=loadAmLimitDb(); db.limits[role]=value; saveAmLimitDb(db);
    return bot.sendMessage(msg.chat.id,
      `✓ Limit AM Premium <b>${role.toUpperCase()}</b> diatur ke <b>${value===-1?'Unlimited':value+'x/hari'}</b>.`,
      { parse_mode:'HTML', ...q(msg) });
  });

  // ── /amprem — menu utama ──────────────────────────────────────────────────
  bot.onText(/^\/amprem(?:@\w+)?$/i, async (msg)=>{
    const chatId=msg.chat.id;
    if(!isAmChatAllowed(msg)) {
      return bot.sendMessage(chatId, amChatDeniedText(msg), { parse_mode:'HTML', ...q(msg) });
    }
    if(!isAllowed(msg.from.id)) {
      return bot.sendMessage(chatId, accessDeniedText(getUserRoleExtended(msg.from.id)),
        { parse_mode:'HTML', ...q(msg) });
    }
    const info=amLimitInfo(msg.from.id);
    const lim=info.limit===null ? '∞' : `${info.remaining}/${info.limit}`;

    const text=
      `<b>╭━━〔 AM PREMIUM CREATOR 〕━━╮</b>\n`+
      `<i>Aktivasi Alight Motion Premium via email kamu sendiri</i>\n`+
      `╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯\n\n`+
      `<blockquote expandable>`+
      `<b>CARA PAKAI — BULK EMAIL:</b>\n`+
      `├ 1. Tekan tombol <b>Bulk Email</b>\n`+
      `├ 2. Pilih jumlah email atau input kustom\n`+
      `├ 3. Kirim daftar email (satu per baris)\n`+
      `├ 4. Bot kirim magic link ke semua email\n`+
      `├ 5. Cek inbox / SPAM masing-masing email\n`+
      `╰ 6. Paste link verifikasi ke bot\n`+
      `</blockquote>\n\n`+
      `<blockquote expandable>`+
      `<b>CARA PAKAI — TEMP MAIL:</b>\n`+
      `├ 1. Tekan tombol <b>Temp Mail</b>\n`+
      `├ 2. Pilih jumlah email temp yang dibuat\n`+
      `├ 3. Bot auto generate & kirim magic link\n`+
      `╰ 4. Bot auto cek inbox & ambil link login\n`+
      `</blockquote>\n\n`+
      `💳 Limit hari ini: <b>${lim}</b>`;

    return bot.sendMessage(chatId, text, {
      parse_mode:'HTML', ...q(msg),
      reply_markup: {
        inline_keyboard:[
          [{ text:'Create Temp Mail', callback_data:'am_tempmail_menu' },
           { text:'Bulk Email', callback_data:'am_bulk_email' }],
          [{ text:'Create AM API V2', callback_data:'am_api_v2' }],
          [{ text:'Histori Email Saya', callback_data:'am_history' },
           ...(isOwner(msg.from.id) ? [{ text:'List Email User', callback_data:'am_owner_users' }] : [])],
          ...(isDeveloper(msg.from.id) ? [[{ text:'Pengaturan Limit AM', callback_data:'am_limit_settings' }]] : []),
          [{ text:'‹‹‹', callback_data:'groupmenu' }],
        ]
      }
    });
  });

  // ══════════════════════════════════════════════════════════════════════════
  //  CALLBACK QUERY HANDLER
  // ══════════════════════════════════════════════════════════════════════════
  bot.on('callback_query', async (cb)=>{
    let { data, from, message:msg } = cb;
    const chatId=msg?.chat?.id;
    const userId=from.id;
    const msgId=msg?.message_id;

    // Semua menu AM mengikuti aturan yang sama: grup/supergroup untuk user biasa,
    // private chat hanya developer.
    if (String(data || '').startsWith('am_') && msg) {
      const type = String(msg.chat?.type || '').toLowerCase();
      if (type === 'private' && !isDeveloper(userId)) {
        return bot.answerCallbackQuery(cb.id,{text:'AM Premium di private hanya untuk developer.',show_alert:true});
      }
      if (type !== 'private' && type !== 'group' && type !== 'supergroup') {
        return bot.answerCallbackQuery(cb.id,{text:'AM Premium hanya dapat dipakai di grup.',show_alert:true});
      }
    }

    // ── Create AM API V2 ────────────────────────────────────────────────
    if(data === 'am_api_v2') {
      if(!isAllowed(userId)) {
        return bot.answerCallbackQuery(cb.id,{text:'Akses ditolak.',show_alert:true});
      }

      await bot.answerCallbackQuery(cb.id).catch(()=>{});

      const progress = await bot.sendMessage(
        chatId,
        '<b>╭━━〔 CREATE AM API V2 〕━━╮</b>\n\n' +
        '<blockquote expandable>⏳ <b>Menjalankan API V2...</b>\n' +
        'Membuka provider dan menyiapkan endpoint.\n\n' +
        '<i>Proses dapat membutuhkan beberapa detik.</i></blockquote>',
        {parse_mode:'HTML'}
      );

      try {
        // Update pesan tiap 15 detik supaya user tahu progress, bukan stuck
        let _elapsed = 0;
        const _stages = [
          'Mencari Chrome/Chromium...',
          'Membuka browser dan navigasi...',
          'Melewati verifikasi Cloudflare...',
          'Memanggil endpoint API...',
          'Memproses respons...',
        ];
        const _progressTimer = setInterval(async () => {
          _elapsed += 15;
          const stageIdx = Math.min(Math.floor(_elapsed / 15) - 1, _stages.length - 1);
          const stage = _stages[Math.max(0, stageIdx)];
          const mins = Math.floor(_elapsed / 60);
          const secs = _elapsed % 60;
          const timeStr = mins > 0 ? `${mins}m ${secs}s` : `${secs}s`;
          await bot.editMessageText(
            '<b>╭━━〔 CREATE AM API V2 〕━━╮</b>\n\n' +
            `<blockquote expandable>⏳ <b>Menjalankan API V2...</b>\n` +
            `▸ ${esc(stage)}\n\n` +
            `<i>Waktu berjalan: ${timeStr}</i></blockquote>`,
            { chat_id: chatId, message_id: progress.message_id, parse_mode: 'HTML' }
          ).catch(() => {});
        }, 15000);

        // Timeout 120 detik supaya tidak stuck selamanya
        const _timeout120 = new Promise((_, rej) =>
          setTimeout(() => rej(new Error('Timeout: API V2 tidak merespons dalam 120 detik. Chrome mungkin gagal start atau Cloudflare memblokir.')), 120000)
        );

        let result;
        try {
          result = await Promise.race([createAmApiV2(), _timeout120]);
        } finally {
          clearInterval(_progressTimer);
        }
        const safe = (v) => esc(String(v ?? '-')).slice(0, 1800);
        const status = result.success ? '✅ BERHASIL' : '❌ GAGAL';

        const text =
          '<b>╭━━〔 CREATE AM API V2 〕━━╮</b>\n\n' +
          `<b>Status:</b> ${status}\n` +
          `<b>URL:</b> <code>${safe(result.url)}</code>\n` +
          (result.error ? `\n<b>Error:</b>\n<code>${safe(result.error)}</code>\n` : '') +
          (result.generate ? `\n<blockquote expandable><b>GENERATE</b>\nHTTP: <code>${safe(result.generate.status)}</code>\nBody:\n<code>${safe(result.generate.body)}</code></blockquote>\n` : '') +
          (result.catcher ? `<blockquote expandable><b>CATCHER</b>\nHTTP: <code>${safe(result.catcher.status)}</code>\nBody:\n<code>${safe(result.catcher.body)}</code></blockquote>\n` : '') +
          (result.manual ? `<blockquote expandable><b>MANUAL</b>\nHTTP: <code>${safe(result.manual.status)}</code>\nBody:\n<code>${safe(result.manual.body)}</code></blockquote>` : '');

        return bot.editMessageText(text, {
          chat_id: chatId,
          message_id: progress.message_id,
          parse_mode:'HTML',
          reply_markup:{inline_keyboard:[
            [{text:'🔄 Create Lagi',callback_data:'am_api_v2'}],
            [{text:'⬅️ ‹',callback_data:'am_history_back'}]
          ]}
        }).catch(()=>{});
      } catch(e) {
        return bot.editMessageText(
          '<b>╭━━〔 CREATE AM API V2 〕━━╮</b>\n\n' +
          `<blockquote expandable>❌ <b>Gagal menjalankan API V2</b>\n\n<code>${esc(e?.message || String(e))}</code></blockquote>`,
          {chat_id:chatId,message_id:progress.message_id,parse_mode:'HTML',
           reply_markup:{inline_keyboard:[[ {text:'🔄 Coba Lagi',callback_data:'am_api_v2'} ]]}}
        ).catch(()=>{});
      }
    }

    // ── pengaturan limit AM ─────────────────────────────────────────────
    if(data==='am_limit_close') {
      if(!isDeveloper(userId)) return bot.answerCallbackQuery(cb.id,{text:'Khusus developer.',show_alert:true});
      await bot.answerCallbackQuery(cb.id).catch(()=>{});
      return bot.deleteMessage(chatId,msgId).catch(()=>{});
    }

    if(data==='am_limit_reset_1') {
      if(!isDeveloper(userId)) return bot.answerCallbackQuery(cb.id,{text:'Khusus developer.',show_alert:true});
      const db=loadAmLimitDb();
      for (const role of ['premium','pt','tk','ceo','founder','pemilik']) db.limits[role]=1;
      for (const role of ['cofounder','king','khusus','god','owner','developer']) db.limits[role]=-1;
      saveAmLimitDb(db);
      await bot.answerCallbackQuery(cb.id,{text:'Limit direset: 1x, co-founder ke atas unlimited.'});
      return bot.editMessageText('<b>Limit AM berhasil direset.</b>\n\nSemua role di bawah co-founder: <b>1x/hari</b>.\nCo-founder dan di atas: <b>Unlimited</b>.',{chat_id:chatId,message_id:msgId,parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'Buka Pengaturan Lagi',callback_data:'am_limit_settings'}]]}}).catch(()=>{});
    }

    if(data==='am_limit_settings') {
      if(!isDeveloper(userId)) return bot.answerCallbackQuery(cb.id,{text:'Khusus developer.',show_alert:true});
      const db=loadAmLimitDb();
      const rows=['premium','pt','tk','ceo','founder','pemilik','cofounder','king','khusus','god']
        .map(role=>[{text:`${role.toUpperCase()}: ${db.limits[role]===-1?'∞':(db.limits[role]??1)+'x'}`,callback_data:`am_limit_role:${role}`}]);
      rows.push([{text:'Reset non-unlimited → 1x',callback_data:'am_limit_reset_1'}],[{text:'Tutup',callback_data:'am_limit_close'}]);
      await bot.answerCallbackQuery(cb.id).catch(()=>{});
      return bot.editMessageText('<b>╭━━〔 PENGATURAN LIMIT AM PREMIUM 〕━━╮</b>\n\nPilih role untuk mengubah limit hariannya.',{chat_id:chatId,message_id:msgId,parse_mode:'HTML',reply_markup:{inline_keyboard:rows}}).catch(()=>{});
    }

    if(data.startsWith('am_limit_role:')) {
      if(!isDeveloper(userId)) return bot.answerCallbackQuery(cb.id,{text:'Khusus developer.',show_alert:true});
      const role=data.split(':')[1];
      const db=loadAmLimitDb();
      const value=db.limits[role]??1;
      await bot.answerCallbackQuery(cb.id).catch(()=>{});
      return bot.editMessageText(`<b>LIMIT AM — ${esc(role.toUpperCase())}</b>\n\nNilai saat ini: <b>${value===-1?'Unlimited':value+'x/hari'}</b>\n\nGunakan perintah:\n<code>/setamlimit ${esc(role)} 1</code>\natau\n<code>/setamlimit ${esc(role)} unlimited</code>`,{chat_id:chatId,message_id:msgId,parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'‹‹‹',callback_data:'am_limit_settings'}]]}}).catch(()=>{});
    }

    // ── owner: list users with AM email history ─────────────────────────
    if(data==='am_owner_users') {
      if(!isOwner(userId)) return bot.answerCallbackQuery(cb.id,{text:'Khusus owner.',show_alert:true});
      const db=loadAmHistoryDb();
      const ids=Object.keys(db.users||{}).filter(id=>Array.isArray(db.users[id]) && db.users[id].length);
      const rows=[];
      for(let i=0;i<ids.length;i+=2) rows.push(ids.slice(i,i+2).map(id=>{
        const n=db.users[id].length;
        return {text:`👤 ${id} • ${n}`,callback_data:`am_owner_user:${id}`};
      }));

      // Owner langsung melihat email yang dibuat tiap user, bukan hanya jumlahnya.
      const userEmailBlocks = ids.map((id, index) => {
        const list = Array.isArray(db.users[id]) ? db.users[id] : [];
        const emails = list
          .map(x => x?.email)
          .filter(Boolean)
          .map((email, i) => `   ${i + 1}. <code>${esc(email)}</code>`)
          .join('\n');

        return `<b>${index + 1}. 👤 User:</b> <code>${esc(id)}</code>\n` +
               `📧 <b>${list.length} email</b>\n` +
               (emails || '   <i>Tidak ada email.</i>');
      }).join('\n\n');

      rows.push(
        [{text:'Refresh',callback_data:'am_owner_users'}],
        [{text:'‹‹‹',callback_data:'am_history_back'}]
      );

      await bot.answerCallbackQuery(cb.id).catch(()=>{});

      const ownerText = ids.length
        ? `<b>╭━━〔 👑 AM EMAIL USER LIST 〕━━╮</b>\n\n` +
          `👥 <b>Total user:</b> ${ids.length}\n` +
          `📧 <b>Total email:</b> ${ids.reduce((n,id)=>n+(db.users[id]?.length||0),0)}\n\n` +
          `<blockquote expandable>${userEmailBlocks}</blockquote>`
        : `<b>╭━━〔 👑 AM EMAIL USER LIST 〕━━╮</b>\n\n<blockquote expandable>Belum ada histori user.</blockquote>`;

      return bot.editMessageText(
        ownerText,
        {chat_id:chatId,message_id:msgId,parse_mode:'HTML',reply_markup:{inline_keyboard:rows}}
      ).catch(()=>{});
    }

    if(data.startsWith('am_owner_user:')) {
      if(!isOwner(userId)) return bot.answerCallbackQuery(cb.id,{text:'Khusus owner.',show_alert:true});
      const target=data.split(':')[1];
      const list=getAmHistory(target);
      const rows=list.map((x,i)=>{
        const status=x.status==='success'?'🟢':x.status==='failed'?'🔴':x.status==='waiting'?'🟡':'⚪';
        return `${i+1}. ${status} <code>${esc(x.email)}</code>\n   ${esc(x.type)} • ${new Date(x.createdAt).toLocaleString('id-ID',{timeZone:'Asia/Jakarta'})}`;
      });
      await bot.answerCallbackQuery(cb.id).catch(()=>{});
      return bot.editMessageText(
        `<b>╭━━〔 📧 HISTORI EMAIL USER 〕━━╮</b>\n\n`+
        `<b>ID:</b> <code>${esc(target)}</code>\n`+
        `📊 <b>Total email dibuat:</b> ${list.length}\n\n`+
        (rows.length?`<blockquote expandable>${rows.join('\n\n')}</blockquote>`:'<blockquote expandable>Belum ada email.</blockquote>'),
        {chat_id:chatId,message_id:msgId,parse_mode:'HTML',reply_markup:{inline_keyboard:[
          [{text:'Refresh',callback_data:`am_owner_user:${target}`}],
          [{text:'List User',callback_data:'am_owner_users'}]
        ]}}
      ).catch(()=>{});
    }

    
// Telegram callback_data maksimal 64 byte.
// Untuk history AM, jangan masukkan sessionId/email langsung ke callback_data.
// Gunakan index history yang pendek dan resolve kembali di server.
function amHistoryIndexForEntry(userId, entry) {
  const history = getAmHistory(userId);
  const idx = history.findIndex(x =>
    (entry?.sessionId && String(x.sessionId || '') === String(entry.sessionId)) ||
    (entry?.email && String(x.email || '').toLowerCase() === String(entry.email).toLowerCase())
  );
  return idx >= 0 ? idx : -1;
}

function amHistoryResumeCallback(userId, entry) {
  const idx = amHistoryIndexForEntry(userId, entry);
  return idx >= 0 ? `am_history_resume_i:${idx}` : 'am_history';
}

// ── Open one persisted AM history item by stable list index ───────────
    if(String(data).startsWith('am_history_item_i:')) {
      if(!isAllowed(userId)) return bot.answerCallbackQuery(cb.id,{text:'Akses ditolak.',show_alert:true});
      const idx=Number(String(data).slice('am_history_item_i:'.length));
      const history=getAmHistory(userId).slice(0,60);
      const entry=Number.isInteger(idx) && idx>=0 ? history[idx] : null;
      if(!entry) return bot.answerCallbackQuery(cb.id,{text:'Histori email tidak ditemukan.',show_alert:true});
      await bot.answerCallbackQuery(cb.id).catch(()=>{});
      const statusText=entry.status==='success'?'✅ Berhasil':entry.status==='failed'?'❌ Gagal':entry.status==='processing'?'🔵 Masih proses':entry.status==='waiting'?'🟡 Menunggu':'⚪ Dibuat';
      const buttons=[];
      if(entry.status==='processing'||entry.status==='waiting') buttons.push([{text:'▶️ Aktifkan Sesi Ini',callback_data:amHistoryResumeCallback(userId, entry)}]);
      const tm=tmStoreGet(userId).find(x=>String(x.email).toLowerCase()===String(entry.email).toLowerCase());
      if(tm?.inboxUrl) buttons.push([{text:'📬 Buka Inbox',url:tm.inboxUrl}]);
      if(Number(tm?.provider)===2) buttons.push([{text:'🔄 Lihat Inbox Temp Mail 2',callback_data:`am_bulk_tm2_inbox_${userId}`}]);
      buttons.push([{text:'⬅️ Histori',callback_data:'am_history'}]);
      return safeEdit(bot,chatId,msgId,
        `<b>╭━━〔 DETAIL HISTORI AM 〕━━╮</b>\n\n`+
        `<blockquote expandable>📧 <b>Email:</b> <code>${esc(entry.email)}</code>\n`+
        `📌 <b>Tipe:</b> ${esc(entry.type)}\n`+
        `📊 <b>Status:</b> ${statusText}\n`+
        `📝 <b>Step:</b> ${esc(entry.step||'-')}\n`+
        `🕐 <b>Dibuat:</b> ${esc(new Date(entry.createdAt).toLocaleString('id-ID',{timeZone:'Asia/Jakarta'}))}</blockquote>`,
        {inline_keyboard:buttons});
    }

    // ── Open one persisted AM history item (legacy email callback) ────────
    if(String(data).startsWith('am_history_item:')) {
      if(!isAllowed(userId)) return bot.answerCallbackQuery(cb.id,{text:'Akses ditolak.',show_alert:true});
      const key=String(data).slice('am_history_item:'.length);
      const history=getAmHistory(userId);
      let entry=null;
      try {
        const email=Buffer.from(key,'base64url').toString('utf8');
        entry=history.find(x=>String(x.email)===email);
      } catch {}
      if(!entry) entry=history.find(x=>String(x.sessionId||'')===key);
      if(!entry) return bot.answerCallbackQuery(cb.id,{text:'Histori email tidak ditemukan.',show_alert:true});
      await bot.answerCallbackQuery(cb.id).catch(()=>{});
      const statusText=entry.status==='success'?'✅ Berhasil':entry.status==='failed'?'❌ Gagal':entry.status==='processing'?'🔵 Masih proses':entry.status==='waiting'?'🟡 Menunggu':'⚪ Dibuat';
      const buttons=[];
      if(entry.status==='processing'||entry.status==='waiting') buttons.push([{text:'▶️ Aktifkan Sesi Ini',callback_data:amHistoryResumeCallback(userId, entry)}]);
      const tm=tmStoreGet(userId).find(x=>String(x.email).toLowerCase()===String(entry.email).toLowerCase());
      if(tm?.inboxUrl) buttons.push([{text:'📬 Buka Inbox',url:tm.inboxUrl}]);
      if(Number(tm?.provider)===2) buttons.push([{text:'🔄 Lihat Inbox Temp Mail 2',callback_data:`am_bulk_tm2_inbox_${userId}`}]);
      buttons.push([{text:'⬅️ Histori',callback_data:'am_history'}]);
      return safeEdit(bot,chatId,msgId,
        `<b>╭━━〔 DETAIL HISTORI AM 〕━━╮</b>\n\n`+
        `<blockquote expandable>📧 <b>Email:</b> <code>${esc(entry.email)}</code>\n`+
        `📌 <b>Tipe:</b> ${esc(entry.type)}\n`+
        `📊 <b>Status:</b> ${statusText}\n`+
        `📝 <b>Step:</b> ${esc(entry.step||'-')}\n`+
        `🕐 <b>Dibuat:</b> ${esc(new Date(entry.createdAt).toLocaleString('id-ID',{timeZone:'Asia/Jakarta'}))}</blockquote>`,
        {inline_keyboard:buttons});
    }

    // ── Resume persisted AM session via short history index ───────────────
    if(String(data).startsWith('am_history_resume_i:')) {
      if(!isAllowed(userId))
        return bot.answerCallbackQuery(cb.id,{text:'Akses ditolak.',show_alert:true});
      const idx = Number(String(data).slice('am_history_resume_i:'.length));
      const history = getAmHistory(userId);
      const entry = Number.isInteger(idx) && idx >= 0 && idx < history.length ? history[idx] : null;
      if(!entry)
        return bot.answerCallbackQuery(cb.id,{text:'Sesi histori tidak ditemukan.',show_alert:true});
      // Re-enter the existing resume flow using the stored sessionId.
      const resumeId = String(entry.sessionId || entry.email || '');
      if(!resumeId)
        return bot.answerCallbackQuery(cb.id,{text:'ID sesi tidak tersedia.',show_alert:true});
      const nextData = `am_history_resume:${resumeId}`;
      // Keep the original handler logic without sending another callback.
      // The remaining code below is shared by setting data to the legacy format.
      data = nextData;
    }

    // ── Resume persisted AM session ─────────────────────────────────────
    if(String(data).startsWith('am_history_resume:') || String(data).startsWith('am_history_resume_e:')) {
      if(!isAllowed(userId))
        return bot.answerCallbackQuery(cb.id,{text:'Akses ditolak.',show_alert:true});
      const isEmailResume=String(data).startsWith('am_history_resume_e:');
      let sessionId = isEmailResume ? '' : String(data).slice('am_history_resume:'.length);
      let entry = sessionId ? findAmHistoryEntry(userId, sessionId) : null;
      if(isEmailResume) {
        try {
          const value=Buffer.from(String(data).slice('am_history_resume_e:'.length),'base64url').toString('utf8');
          entry=findAmHistoryEntry(userId,value) ||
            getAmHistory(userId).find(x=>String(x.sessionId)===value && (x.status==='processing'||x.status==='waiting')) ||
            getAmHistory(userId).find(x=>String(x.email)===value && (x.status==='processing'||x.status==='waiting')) ||
            getAmHistory(userId).find(x=>String(x.email)===value) || null;
          sessionId=entry?.sessionId || value;
        } catch {}
      }
      if(!entry) return bot.answerCallbackQuery(cb.id,{text:'Sesi tidak ditemukan.',show_alert:true});

      if(entry.type === 'TEMP MAIL') {
        if(!entry.username || !entry.domain)
          return bot.answerCallbackQuery(cb.id,{text:'Data temp mail lama tidak lengkap.',show_alert:true});
        await bot.answerCallbackQuery(cb.id,{text:'Melanjutkan pengecekan inbox...'}).catch(()=>{});
        await safeEdit(bot,chatId,msgId,
          `<b>╭━━〔 LANJUTKAN TEMP MAIL 〕━━╮</b>\n\n<blockquote expandable>📬 Mengecek inbox <code>${esc(entry.email)}</code>...</blockquote>`,
          {inline_keyboard:[[{text:'Batal',callback_data:'am_history'}]]});
        try {
          const link = await waitTempMailLink(entry,300000);
          if(link) {
            updateAmHistory(userId,entry.email,{status:'success',step:'completed'}); tmStoreUpdate(userId, entry.email, {status:'success', step:'completed'});
            addAmStat(userId,'success');
            await safeEdit(bot,chatId,msgId,
              `<b>╭━━〔 TEMP MAIL — SELESAI 〕━━╮</b>\n\n<blockquote expandable>📧 <code>${esc(entry.email)}</code>\n\n✅ Magic link ditemukan:\n<code>${esc(link)}</code></blockquote>`,
              {inline_keyboard:[[{text:'⬅️ ‹',callback_data:'am_history'}]]});
          } else {
            updateAmHistory(userId,entry.email,{status:'failed',step:'no_link'}); tmStoreUpdate(userId, entry.email, {status:'failed', step:'no_link'});
            addAmStat(userId,'failed');
            await safeEdit(bot,chatId,msgId,
              `<b>╭━━〔 TEMP MAIL — GAGAL 〕━━╮</b>\n\n<blockquote expandable>📧 <code>${esc(entry.email)}</code>\n\n⚠️ Magic link belum ditemukan dalam 2 menit.</blockquote>`,
              {inline_keyboard:[[{text:'🔄 Coba Lagi',callback_data:amHistoryResumeCallback(userId, entry)}],[{text:'⬅️ ‹',callback_data:'am_history'}]]});
          }
        } catch(e) {
          updateAmHistory(userId,entry.email,{status:'failed',step:'resume_error'}); tmStoreUpdate(userId, entry.email, {status:'failed', step:'resume_error'});
          await reportError(bot,'am_history_resume_temp',e,{chatId,userId});
          return safeEdit(bot,chatId,msgId,`<b>❌ Gagal melanjutkan</b>\n\n<code>${esc(e.message)}</code>`,{inline_keyboard:[[{text:'⬅️ Histori',callback_data:'am_history'}]]});
        }
        return;
      }

      if(entry.type === 'BULK EMAIL' || entry.type === 'BULK TEMP MAIL') {
        const batch = getAmBatchHistory(userId,entry.batchId);
        const pending = batch.filter(x=>x.status==='waiting' && x.step==='waiting_link');
        if(!pending.length) {
          return bot.answerCallbackQuery(cb.id,{text:'Batch ini sudah selesai.',show_alert:true});
        }
        const session = {
          step:'waiting_links', chatId, promptMsgId:msgId, timer:null,
          bulkEmails:batch.map(x=>x.email), bulkResults:batch.map(x=>({
            email:x.email,
            status:x.status==='success'?'verified':x.status==='failed'?'fail':'sent'
          })).filter(x=>x.status!=='fail' || pending.some(p=>p.email===x.email)),
          mode:'bulk', batchId:entry.batchId, sessionKey:String(entry.batchId || entry.sessionId || `resume_${Date.now()}`)
        };
        session.timer = setTimeout(async()=>{
          const current = getActiveAmSession(userId);
          if (current === session) customEmailSessions.delete(sessionUserKey(userId));
          const reg=getAmSessions(userId); reg.delete(sessionKeyOf(session)); if(!reg.size) amSessionRegistry.delete(sessionUserKey(userId));
          await safeEdit(bot,chatId,msgId,
            `<b>⏰ SESI BULK BERAKHIR</b>\n\nSesi sudah lebih dari 2 jam. Histori dan batch tetap tersimpan, sehingga bisa dilanjutkan lagi dari tombol <b>Lanjutkan</b>.`,
            {inline_keyboard:[[{text:'⬅️ Histori',callback_data:'am_history'}]]});
        },2*60*60*1000);
        registerAmSession(userId,session,true);
        await bot.answerCallbackQuery(cb.id,{text:'Sesi bulk dilanjutkan. Sesi lain tetap aktif.'}).catch(()=>{});
        const list=pending.map((x,i)=>`${i+1}. <code>${esc(x.email)}</code>`).join('\n');
        return safeEdit(bot,chatId,msgId,
          `<b>╭━━〔 BULK ${entry.type === 'BULK TEMP MAIL' ? 'TEMP MAIL' : 'EMAIL'} — DILANJUTKAN 〕━━╮</b>\n\n<blockquote expandable>📬 Masih menunggu magic link untuk:\n${list}\n\nKirim link satu per satu di chat ini.</blockquote>`,
          cancelBtn(userId));
      }
      return bot.answerCallbackQuery(cb.id,{text:'Sesi tidak dapat dilanjutkan.',show_alert:true});
    }

    // ── am_history ───────────────────────────────────────────────────────
    if(data==='am_history') {
      if(!isAllowed(userId))
        return bot.answerCallbackQuery(cb.id,{text:'Akses ditolak.',show_alert:true});
      await bot.answerCallbackQuery(cb.id).catch(()=>{});
      const history = getAmHistory(userId).slice(0,60);
      return bot.editMessageText(formatAmHistory(userId),{
        chat_id:chatId,
        message_id:msgId,
        parse_mode:'HTML',
        reply_markup:{
          inline_keyboard:[
            ...history.map(x => [{
              text:`${x.status==='success'?'✅':x.status==='failed'?'❌':'▶️'} ${x.email}`.slice(0,60),
              callback_data:`am_history_item_i:${history.indexOf(x)}`
            }]),
            [{ text:'Refresh', callback_data:'am_history' }],
            [{ text:'Bersihkan Histori', callback_data:'am_history_clear' }],
            [{ text:'‹‹‹', callback_data:'am_history_back' }]
          ]
        }
      }).catch(()=>{});
    }

    if(data==='am_history_clear') {
      if(!isAllowed(userId))
        return bot.answerCallbackQuery(cb.id,{text:'Akses ditolak.',show_alert:true});
      const db=loadAmHistoryDb();
      db.users[String(userId)]=[];
      saveAmHistoryDb(db);
      await bot.answerCallbackQuery(cb.id,{text:'Histori dihapus.'});
      const history = getAmHistory(userId).slice(0,60);
      return bot.editMessageText(formatAmHistory(userId),{
        chat_id:chatId,
        message_id:msgId,
        parse_mode:'HTML',
        reply_markup:{
          inline_keyboard:[
            ...history.map(x => [{
              text:`${x.status==='success'?'✅':x.status==='failed'?'❌':'▶️'} ${x.email}`.slice(0,60),
              callback_data:`am_history_item_i:${history.indexOf(x)}`
            }]),
            [{ text:'Refresh', callback_data:'am_history' }],
            [{ text:'‹‹‹', callback_data:'am_history_back' }]
          ]
        }
      }).catch(()=>{});
    }

    if(data==='am_history_back') {
      if(!isAllowed(userId))
        return bot.answerCallbackQuery(cb.id,{text:'Akses ditolak.',show_alert:true});
      await bot.answerCallbackQuery(cb.id).catch(()=>{});
      return bot.editMessageText(amMainText(userId),{
        chat_id:chatId,message_id:msgId,parse_mode:'HTML',
        reply_markup:amMainKeyboard(userId)
      }).catch(()=>{});
    }

    // ── am_stats ──────────────────────────────────────────────────────────
    if(data==='am_stats') {
      if(!isAllowed(userId))
        return bot.answerCallbackQuery(cb.id,{text:'Akses ditolak.',show_alert:true});
      await bot.answerCallbackQuery(cb.id).catch(()=>{});

      return bot.editMessageText(statsText(userId),{
        chat_id:chatId,
        message_id:msgId,
        parse_mode:'HTML',
        reply_markup:{
          inline_keyboard:[
            [{ text:'Refresh', callback_data:'am_stats' }],
            [{ text:'‹‹‹', callback_data:'am_menu_back' }]
          ]
        }
      }).catch(async()=>{
        try {
          await bot.sendMessage(chatId,statsText(userId),{
            parse_mode:'HTML',
            reply_markup:{inline_keyboard:[
              [{ text:'Refresh', callback_data:'am_stats' }],
              [{ text:'‹‹‹', callback_data:'am_menu_back' }]
            ]}
          });
        } catch {}
      });
    }

    // ── am_menu_back ──────────────────────────────────────────────────────
    if(data==='am_menu_back') {
      if(!isAllowed(userId))
        return bot.answerCallbackQuery(cb.id,{text:'Akses ditolak.',show_alert:true});
      await bot.answerCallbackQuery(cb.id).catch(()=>{});
      return bot.editMessageText(amMainText(userId),{
        chat_id:chatId,message_id:msgId,parse_mode:'HTML',
        reply_markup:amMainKeyboard(userId)
      }).catch(()=>{});
    }

    if(data==='am_menu_back_start') {
      return bot.answerCallbackQuery(cb.id).then(()=>bot.sendMessage(chatId,'Ketik /amprem untuk membuka menu AM Premium.')).catch(()=>{});
    }

    // ── am_bulk_email ─────────────────────────────────────────────────────
    if(data==='am_bulk_email') {
      if(!isAllowed(userId))
        return bot.answerCallbackQuery(cb.id,{text:`Akses ditolak.`,show_alert:true});
      const amLimit=amLimitInfo(userId);
      if(!amLimit.allowed)
        return bot.answerCallbackQuery(cb.id,{text:`Limit habis (${amLimit.used}/${amLimit.limit}). Coba besok.`,show_alert:true});

      await safeEdit(bot,chatId,msgId,
        `<b>╭━━〔 AM PREMIUM — BULK EMAIL 〕━━╮</b>\n\n`+
        `<blockquote expandable>📧 <b>Pilih jumlah email</b> yang ingin diproses sekaligus.\n\nAtau tekan <b>Kustom</b> untuk input sendiri.</blockquote>`,
        { inline_keyboard:[
          [{ text:'1 Email',  callback_data:'am_bulk_count_1'  },
           { text:'3 Email',  callback_data:'am_bulk_count_3'  },
           { text:'5 Email',  callback_data:'am_bulk_count_5'  }],
          [{ text:'10 Email', callback_data:'am_bulk_count_10' },
           { text:'Kustom', callback_data:'am_bulk_count_custom'}],
          [{ text:'Batal',  callback_data:`am_custom_cancel_${userId}` }],
        ]}
      );
      return;
    }

    // ── Bulk custom count (+/-) ──────────────────────────────────────────
    if(data==='am_bulk_count_custom') {
      if(!isAllowed(userId)) return bot.answerCallbackQuery(cb.id,{text:'Akses ditolak.',show_alert:true});
      if(false) return bot.answerCallbackQuery(cb.id,{text:'',show_alert:false});
      const info=amLimitInfo(userId);
      if(!info.allowed) return bot.answerCallbackQuery(cb.id,{text:`Limit habis (${info.used}/${info.limit}). Coba besok.`,show_alert:true});
      const current=Math.min(100,Math.max(1,Number(bulkCustomCounts.get(userId)||1)));
      bulkCustomCounts.set(userId,current);
      await safeEdit(bot,chatId,msgId,
        `<b>╭━━〔 BULK EMAIL — KUSTOM 〕━━╮</b>\n\n`+
        `<blockquote expandable>Atur jumlah email dengan tombol <b>−</b> dan <b>+</b>.\n\n`+
        `Jumlah: <b>${current} email</b>\n\nMaksimal <b>100 email</b> per batch.</blockquote>`,
        {inline_keyboard:[
          [{text:'−',callback_data:'am_bulk_custom_dec'}, {text:`${current} Email`,callback_data:'am_bulk_custom_noop'}, {text:'+',callback_data:'am_bulk_custom_inc'}],
          [{text:'Lanjutkan',callback_data:'am_bulk_custom_start'}],
          [{text:'‹‹‹',callback_data:'am_bulk_email'}],
          [{text:'Batal',callback_data:`am_custom_cancel_${userId}`}],
        ]});
      return bot.answerCallbackQuery(cb.id).catch(()=>{});
    }

    if(data==='am_bulk_custom_inc' || data==='am_bulk_custom_dec') {
      if(!isAllowed(userId)) return bot.answerCallbackQuery(cb.id,{text:'Akses ditolak.',show_alert:true});
      let count=Math.min(100,Math.max(1,Number(bulkCustomCounts.get(userId)||1)));
      count += data==='am_bulk_custom_inc' ? 1 : -1;
      count=Math.min(100,Math.max(1,count));
      bulkCustomCounts.set(userId,count);
      await safeEdit(bot,chatId,msgId,
        `<b>╭━━〔 BULK EMAIL — KUSTOM 〕━━╮</b>\n\n`+
        `<blockquote expandable>Atur jumlah email dengan tombol <b>−</b> dan <b>+</b>.\n\n`+
        `Jumlah: <b>${count} email</b>\n\nMaksimal <b>100 email</b> per batch.</blockquote>`,
        {inline_keyboard:[
          [{text:'−',callback_data:'am_bulk_custom_dec'}, {text:`${count} Email`,callback_data:'am_bulk_custom_noop'}, {text:'+',callback_data:'am_bulk_custom_inc'}],
          [{text:'Lanjutkan',callback_data:'am_bulk_custom_start'}],
          [{text:'‹‹‹',callback_data:'am_bulk_email'}],
          [{text:'Batal',callback_data:`am_custom_cancel_${userId}`}],
        ]});
      return bot.answerCallbackQuery(cb.id,{text:`${count} email`}).catch(()=>{});
    }

    if(data==='am_bulk_custom_noop') return bot.answerCallbackQuery(cb.id,{text:'Gunakan tombol − / + untuk mengubah jumlah.'}).catch(()=>{});

    if(data==='am_bulk_custom_start') {
      if(!isAllowed(userId)) return bot.answerCallbackQuery(cb.id,{text:'Akses ditolak.',show_alert:true});
      if(false) return bot.answerCallbackQuery(cb.id,{text:'',show_alert:false});
      const count=Math.min(100,Math.max(1,Number(bulkCustomCounts.get(userId)||1)));
      bulkCustomCounts.delete(userId);
      const promptText=`<b>╭━━〔 AM PREMIUM — BULK EMAIL 〕━━╮</b>\n\n`+
        `<blockquote expandable>📧 <b>Masukkan email manual</b>\n\nKirim tepat <b>${count} email</b>, satu per baris.\n\n<b>Contoh:</b>\n<code>email1@gmail.com\nemail2@gmail.com</code>\n\n⏰ Sesi aktif sampai <b>2 jam</b>.</blockquote>`;
      const promptMsg=await (async()=>{ try{return await bot.editMessageText(promptText,{chat_id:chatId,message_id:msgId,parse_mode:'HTML',reply_markup:bulkManualPromptMarkup(userId)})}catch{return await bot.sendMessage(chatId,promptText,{parse_mode:'HTML',reply_markup:bulkManualPromptMarkup(userId)})} })();
      let inputSession;
      const timer=setTimeout(async()=>{
        if(!inputSession) return;
        removeAmSession(userId,inputSession);
        await safeEdit(bot,chatId,inputSession.promptMsgId,`<b>⏰ AM PREMIUM — SESI HABIS</b>\n\nSesi ini sudah 2 jam. Sesi lain milikmu tetap aktif dan histori tetap tersimpan.`,{inline_keyboard:[[ {text:'Histori',callback_data:'am_history'} ]]});
      },2*60*60*1000);
      inputSession=registerAmSession(userId,{step:'waiting_bulk_emails',chatId,promptMsgId:promptMsg?.message_id||msgId,maxCount:count,timer,bulkResults:[],bulkEmails:[],mode:'bulk'});
      return bot.answerCallbackQuery(cb.id,{text:`Mode ${count} email dipilih.`}).catch(()=>{});
    }

    // ── Bulk manual setelah jumlah dipilih ───────────────────────────────
    if(data.startsWith('am_bulk_manual_')) {
      if(!isAllowed(userId)) return bot.answerCallbackQuery(cb.id,{text:'Akses ditolak.',show_alert:true});
      if(false) return bot.answerCallbackQuery(cb.id,{text:'',show_alert:false});
      const part=data.replace('am_bulk_manual_','');
      const isCustom=part==='custom';
      const maxCount=isCustom?10:Math.min(10,Math.max(1,parseInt(part,10)||1));
      const promptText=`<b>╭━━〔 AM PREMIUM — BULK EMAIL 〕━━╮</b>\n\n`+
        `<blockquote expandable>📧 <b>Masukkan email manual</b>\n\nKirim ${isCustom?'daftar email (maksimal 10)':`<b>${maxCount} email</b>`}, satu per baris.\n\n<b>Contoh:</b>\n<code>email1@gmail.com\nemail2@gmail.com</code>\n\n⏰ Sesi aktif sampai <b>2 jam</b>.</blockquote>`;
      const promptMsg=await (async()=>{ try{return await bot.editMessageText(promptText,{chat_id:chatId,message_id:msgId,parse_mode:'HTML',reply_markup:bulkManualPromptMarkup(userId)})}catch{return await bot.sendMessage(chatId,promptText,{parse_mode:'HTML',reply_markup:bulkManualPromptMarkup(userId)})} })();
      const timer=setTimeout(async()=>{const sess=getActiveAmSession(userId);if(!sess)return;removeAmSession(userId,sess);await safeEdit(bot,chatId,sess.promptMsgId,`<b>⏰ AM PREMIUM — SESI HABIS</b>\n\nSesi 2 jam berakhir. Histori tetap tersimpan dan dapat dilanjutkan.`,{inline_keyboard:[[ {text:'Histori',callback_data:'am_history'} ]]});},2*60*60*1000);
      registerAmSession(userId,{step:'waiting_bulk_emails',chatId,promptMsgId:promptMsg?.message_id||msgId,maxCount,timer,bulkResults:[],bulkEmails:[],mode:'bulk'});
      return;
    }

    // ── Temp Mail dari mode Bulk Manual ─────────────────────────────────
    // Tetap berada di sesi input email manual. Temp Mail hanya menjadi alat bantu
    // untuk membuat mailbox + melihat inbox; tombol kembali mengembalikan prompt manual.
    if(data.startsWith('am_bulk_manual_temp_')) {
      if(!isAllowed(userId)) return bot.answerCallbackQuery(cb.id,{text:'Akses ditolak.',show_alert:true});
      const sess=getActiveAmSession(userId);
      if(!sess || sess.step!=='waiting_bulk_emails')
        return bot.answerCallbackQuery(cb.id,{text:'Sesi input email manual sudah tidak aktif.',show_alert:true});
      bulkManualTempReturns.set(String(userId), { promptMsgId:sess.promptMsgId, chatId:sess.chatId, createdAt:Date.now() });
      await bot.answerCallbackQuery(cb.id).catch(()=>{});
      return safeEdit(bot,chatId,msgId,
        `<b>╭━━〔 BULK MANUAL — TEMP MAIL 〕━━╮</b>\n\n`+
        `<blockquote expandable>Temp Mail hanya dipakai sebagai mailbox tambahan.\n\n`+
        `Pilih provider untuk membuat <b>1 email</b>. Setelah dibuat, kamu bisa membuka inbox dan kembali lagi ke input email manual tanpa kehilangan sesi.</blockquote>`,
        {inline_keyboard:[
          [{text:'Temp Mail 1 — Generator.email',callback_data:'am_bulk_manual_tm_create_1'}],
          [{text:'Temp Mail 2 — creatett-seven.vercel.app',callback_data:'am_bulk_manual_tm_create_2'}],
          [{text:'⬅️ ‹',callback_data:'am_bulk_manual_temp_back'}]
        ]});
    }

    if(data==='am_bulk_manual_temp_back') {
      const sess=getActiveAmSession(userId);
      if(!sess || sess.step!=='waiting_bulk_emails')
        return bot.answerCallbackQuery(cb.id,{text:'Sesi input manual sudah tidak aktif.',show_alert:true});
      bulkManualTempReturns.delete(String(userId));
      await bot.answerCallbackQuery(cb.id).catch(()=>{});
      return safeEdit(bot,chatId,msgId,
        `<b>╭━━〔 AM PREMIUM — BULK EMAIL 〕━━╮</b>\n\n`+
        `<blockquote expandable>📧 <b>Masukkan email manual</b>\n\nKirim ${sess.maxCount>=10?'daftar email (maksimal 10)':`<b>${sess.maxCount} email</b>`}, satu per baris.\n\n<b>Contoh:</b>\n<code>email1@gmail.com\nemail2@gmail.com</code>\n\n⏰ Sesi aktif sampai <b>2 jam</b>.</blockquote>`,
        bulkManualPromptMarkup(userId));
    }

    if(data==='am_bulk_manual_tm_create_1' || data==='am_bulk_manual_tm_create_2') {
      const sess=getActiveAmSession(userId);
      if(!sess || sess.step!=='waiting_bulk_emails')
        return bot.answerCallbackQuery(cb.id,{text:'Sesi input manual sudah tidak aktif.',show_alert:true});
      const provider=data.endsWith('_2')?2:1;
      await bot.answerCallbackQuery(cb.id,{text:'Membuat Temp Mail...'}).catch(()=>{});
      await safeEdit(bot,chatId,msgId,
        `<b>╭━━〔 TEMP MAIL 〕━━╮</b>\n\n<blockquote expandable>⏳ Membuat mailbox dari <b>${esc(tempMailProviderInfo(provider).name)}</b>...</blockquote>`,
        {inline_keyboard:[[{text:'⬅️ ‹',callback_data:'am_bulk_manual_temp_back'}]]});
      try {
        const ed=await generateTempMail(provider);
        if(!ed) throw new Error('Provider tidak menghasilkan mailbox');
        tmStoreAdd(userId,{email:ed.email,username:ed.username,domain:ed.domain,password:ed.password||null,token:ed.token||null,base:ed.base,inboxUrl:ed.inboxUrl,provider,status:'created'});
        addAmStat(userId,'created');
        bulkManualTempReturns.set(String(userId), {promptMsgId:sess.promptMsgId,chatId:sess.chatId,createdAt:Date.now(), email:ed.email});
        const idx=tmStoreGet(userId).findIndex(x=>x.email===ed.email);
        return safeEdit(bot,chatId,msgId,
          `<b>╭━━〔 TEMP MAIL SIAP 〕━━╮</b>\n\n`+
          `<blockquote expandable>📧 <b>Email:</b> <code>${esc(ed.email)}</code>\n\n`+
          `Mailbox sudah dibuat. Kamu bisa cek inbox sekarang atau kembali ke input manual.\n\n`+
          `Temp Mail ini tidak mengganti mode <b>Manual Email</b>.</blockquote>`,
          {inline_keyboard:[
            ...(ed.inboxUrl ? [[{text:'🔗 Buka Inbox',url:ed.inboxUrl}]] : []),
            [{text:'📬 Lihat Inbox',callback_data:`am_bulk_manual_tm_inbox_${userId}`}],
            [{text:'⬅️ ‹',callback_data:'am_bulk_manual_temp_back'}]
          ]});
      } catch(e) {
        return safeEdit(bot,chatId,msgId,
          `<b>❌ TEMP MAIL GAGAL</b>\n\n<code>${esc(e.message)}</code>`,
          {inline_keyboard:[[{text:'🔄 Coba Lagi',callback_data:`am_bulk_manual_tm_create_${provider}`}],[{text:'⬅️ ‹',callback_data:'am_bulk_manual_temp_back'}]]});
      }
    }

    if(data.startsWith('am_bulk_manual_tm_inbox_')) {
      const ownerId=data.replace('am_bulk_manual_tm_inbox_','');
      if(String(ownerId)!==String(userId)) return bot.answerCallbackQuery(cb.id,{text:'Bukan milik kamu.',show_alert:true});
      const ret=bulkManualTempReturns.get(String(userId));
      const stored=tmStoreGet(userId);
      if(!stored.length) return bot.answerCallbackQuery(cb.id,{text:'Belum ada Temp Mail.',show_alert:true});
      bulkManualTempReturns.set(String(userId), {...ret,createdAt:Date.now()});
      const buttons=stored.slice(-100).map((entry,i)=>[{text:`📧 ${entry.email}`,callback_data:`am_bulk_manual_tm_read_${i}_${userId}`}]);
      buttons.push([{text:'⬅️ ‹',callback_data:'am_bulk_manual_temp_back'}]);
      const lines=stored.slice(-100).map((e,i)=>`${i+1}. <code>${esc(e.email)}</code>`).join('\n');
      return safeEdit(bot,chatId,msgId,
        `<b>╭━━〔 INBOX TEMP MAIL 〕━━╮</b>\n\n<blockquote expandable>📬 Pilih mailbox yang ingin dicek:\n\n${lines}</blockquote>`,
        {inline_keyboard:buttons});
    }

    if(data.startsWith('am_bulk_manual_tm_read_')) {
      const parts=data.replace('am_bulk_manual_tm_read_','').split('_');
      const idx=parseInt(parts[0],10); const ownerId=parts.slice(1).join('_');
      if(String(ownerId)!==String(userId)) return bot.answerCallbackQuery(cb.id,{text:'Bukan milik kamu.',show_alert:true});
      const stored=tmStoreGet(userId); const entry=stored[idx];
      if(!entry) return bot.answerCallbackQuery(cb.id,{text:'Email tidak ditemukan.',show_alert:true});
      await bot.answerCallbackQuery(cb.id,{text:'Memuat inbox...'}).catch(()=>{});
      await safeEdit(bot,chatId,msgId,`<b>╭━━〔 INBOX: ${esc(entry.email)} 〕━━╮</b>\n\n<blockquote expandable>⏳ Mengambil pesan...</blockquote>`,{inline_keyboard:[]});
      try {
        const items=await checkTempMailInbox(entry);
        let text=`<b>╭━━〔 INBOX: ${esc(entry.email)} 〕━━╮</b>\n\n`;
        if(!items.length) text+=`<blockquote expandable>📭 <b>Inbox kosong</b>\n\nBelum ada pesan masuk.</blockquote>`;
        else {
          text+=`<blockquote expandable>📬 <b>${items.length} pesan ditemukan</b>\n`;
          for(const m of items.slice(0,8)) {
            text+=`\n━━━━━━━━━━━━\n📤 <b>Dari:</b> <code>${esc(m.from||'-')}</code>\n📌 <b>Subjek:</b> ${esc(m.subject||'(tanpa subjek)')}\n`;
            if(m.date) text+=`🕐 <b>Tanggal:</b> ${esc(m.date)}\n`;
            const link=m.verification_link||safeExtractMagicLink(m.body||'');
            if(link) text+=`\n🔗 <b>Magic Link:</b>\n<code>${esc(link.slice(0,800))}</code>\n`;
            else text+=`\n📝 ${esc(String(m.body||'').replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim().slice(0,400)||'(kosong)')}\n`;
          }
          text+=`</blockquote>`;
        }
        return safeEdit(bot,chatId,msgId,text,{inline_keyboard:[
          [{text:'🔄 Refresh Inbox',callback_data:`am_bulk_manual_tm_read_${idx}_${userId}`}],
          [{text:'📬 Daftar Inbox',callback_data:`am_bulk_manual_tm_inbox_${userId}`}],
          [{text:'⬅️ ‹',callback_data:'am_bulk_manual_temp_back'}]
        ]});
      } catch(e) {
        return safeEdit(bot,chatId,msgId,`<b>❌ Gagal mengambil inbox</b>\n\n<code>${esc(e.message)}</code>`,{inline_keyboard:[
          [{text:'🔄 Coba Lagi',callback_data:`am_bulk_manual_tm_read_${idx}_${userId}`}],
          [{text:'⬅️ ‹',callback_data:'am_bulk_manual_temp_back'}]
        ]});
      }
    }

    // ── Bulk Temp Mail: pilih provider ───────────────────────────────────
    if(data==='am_bulk_temp_menu' || data.startsWith('am_bulk_temp_menu_count_')) {
      if(!isAllowed(userId)) return bot.answerCallbackQuery(cb.id,{text:'Akses ditolak.',show_alert:true});
      const countPart = data.startsWith('am_bulk_temp_menu_count_') ? data.replace('am_bulk_temp_menu_count_','') : '';
      const selectedCount = countPart === 'custom' ? 10 : Math.min(10,Math.max(1,parseInt(countPart,10)||1));
      await safeEdit(bot,chatId,msgId,
        `<b>╭━━〔 AM PREMIUM — BULK TEMP MAIL 〕━━╮</b>\n\n`+
        `<blockquote expandable>${countPart ? `Jumlah dipilih: <b>${countPart==='custom'?'maksimal 10':selectedCount}</b>\n\n` : ''}Pilih provider temp mail.\n\n<b>Temp Mail 1</b> — Generator.email\n<b>Temp Mail 2</b> — creatett-seven.vercel.app</blockquote>`,
        {inline_keyboard:[
          [{text:'Temp Mail 1 — Generator.email',callback_data:`am_bulk_temp_provider_1_${countPart||'menu'}`}],
          [{text:'Temp Mail 2 — creatett-seven.vercel.app',callback_data:`am_bulk_temp_provider_2_${countPart||'menu'}`}],
          [{text:'⬅️ ‹',callback_data:'am_bulk_email'}]
        ]});
      return;
    }

    if(data.startsWith('am_bulk_temp_provider_1_') || data.startsWith('am_bulk_temp_provider_2_')) {
      const provider=data.includes('provider_2_')?2:1;
      const selected=data.split('_').slice(5).join('_');
      const initial = (selected && selected!=='menu' && selected!=='custom') ? Math.max(1, Math.min(100, parseInt(selected,10)||1)) : 10;
      const countKey = `am_bulk_temp_pick_${provider}_${initial}`;
      const providerRows = [
        [{text:'➖',callback_data:`am_bulk_temp_adjust_${provider}_${initial}_-1`},
         {text:`Jumlah: ${initial}`,callback_data:'am_noop'},
         {text:'➕',callback_data:`am_bulk_temp_adjust_${provider}_${initial}_1`}],
        [{text:'Buat Temp Mail',callback_data:`am_bulk_temp_count_${provider}_${initial}`}],
        [{text:'⬅️ ‹',callback_data:'am_bulk_temp_menu'}]
      ];
      await safeEdit(bot,chatId,msgId,
        `<b>╭━━〔 BULK ${tempMailProviderInfo(provider).name.toUpperCase()} 〕━━╮</b>\n\n`+
        `<blockquote expandable>Pilih jumlah Temp Mail yang ingin dibuat.\n\n`+
        `Jumlah saat ini: <b>${initial}</b>\n`+
        `Rentang: <b>1–100 mailbox</b>.\n\n`+
        `Gunakan tombol <b>➕</b> dan <b>➖</b> untuk mengatur jumlah.</blockquote>`,
        {inline_keyboard:providerRows});
      return;
    }

    if(data.startsWith('am_bulk_temp_adjust_')) {
      const parts=data.replace('am_bulk_temp_adjust_','').split('_');
      const provider=parseInt(parts[0],10)||1;
      let count=Math.max(1,Math.min(100,parseInt(parts[1],10)||1));
      const delta=parseInt(parts[2],10)||0;
      count=Math.max(1,Math.min(100,count+delta));
      await bot.answerCallbackQuery(cb.id,{text:`Jumlah Temp Mail: ${count}`}).catch(()=>{});
      return safeEdit(bot,chatId,msgId,
        `<b>╭━━〔 BULK ${tempMailProviderInfo(provider).name.toUpperCase()} 〕━━╮</b>\n\n`+
        `<blockquote expandable>Pilih jumlah Temp Mail yang ingin dibuat.\n\n`+
        `Jumlah saat ini: <b>${count}</b>\n`+
        `Rentang: <b>1–100 mailbox</b>.</blockquote>`,
        {inline_keyboard:[
          [{text:'➖',callback_data:`am_bulk_temp_adjust_${provider}_${count}_-1`},{text:`Jumlah: ${count}`,callback_data:'am_noop'},{text:'➕',callback_data:`am_bulk_temp_adjust_${provider}_${count}_1`}],
          [{text:'Buat Temp Mail',callback_data:`am_bulk_temp_count_${provider}_${count}`}],
          [{text:'⬅️ ‹',callback_data:'am_bulk_temp_menu'}]
        ]});
    }

    if(data==='am_noop') return bot.answerCallbackQuery(cb.id,{text:'Atur jumlah dengan tombol + atau -.'}).catch(()=>{});

    if(data.startsWith('am_bulk_temp_count_')) {
      const parts=data.replace('am_bulk_temp_count_','').split('_');
      const provider=parseInt(parts[0],10)||1;
      const count=Math.min(100,Math.max(1,parseInt(parts[1],10)||1));
      const amLimit=amLimitInfo(userId);
      if(!amLimit.allowed) return bot.answerCallbackQuery(cb.id,{text:`Limit habis (${amLimit.used}/${amLimit.limit}).`,show_alert:true});
      const prompt=await safeEdit(bot,chatId,msgId,
        `<b>╭━━〔 BULK TEMP MAIL 〕━━╮</b>\n\n<blockquote expandable>⏳ Membuat <b>${count}</b> mailbox dari <b>${esc(tempMailProviderInfo(provider).name)}</b>...</blockquote>`,
        {inline_keyboard:[]});
      const session={step:'processing_bulk',chatId,promptMsgId:prompt?.message_id||msgId,maxCount:count,timer:null,bulkResults:[],bulkEmails:[],mode:'bulk_temp',provider,batchId:`bulk_tm_${userId}_${Date.now()}`};
      registerAmSession(userId,session,true);
      session.timer=setTimeout(()=>{ removeAmSession(userId,session); },2*60*60*1000);
      (async()=>{
        for(let i=0;i<count;i++) {
          try {
            const ed=await generateTempMail(provider);
            if(!ed) throw new Error('Provider tidak menghasilkan mailbox');
            const email=ed.email;
            session.bulkEmails.push(email);
            session.bulkResults.push({email,status:'pending',msg:'Mailbox dibuat'});
            tmStoreAdd(userId,{email,username:ed.username,domain:ed.domain,password:ed.password||null,token:ed.token||null,base:ed.base,inboxUrl:ed.inboxUrl,provider,status:'created'});
            addAmStat(userId,'created'); addAmStat(userId,'processed');
            addAmHistory(userId,{email,type:'BULK TEMP MAIL',status:'processing',step:'send_magic_link',sessionId:`${session.batchId}_${Buffer.from(email).toString('base64url')}`,batchId:session.batchId,chatId,messageId:session.promptMsgId,username:ed.username,domain:ed.domain,base:ed.base});
            const sendRes=await customEmailSendVerif(email);
            const r=session.bulkResults.find(x=>x.email===email);
            if(sendRes?.success) {
              r.status='sent'; r.msg='Magic link dikirim'; addAmStat(userId,'sent'); updateAmHistory(userId,email,{status:'waiting',step:'waiting_link',batchId:session.batchId}); tmStoreUpdate(userId,email,{status:'waiting',step:'waiting_link',batchId:session.batchId});
            } else {
              r.status='fail'; r.msg=sendRes?.error||'Gagal mengirim magic link'; addAmStat(userId,'failed'); updateAmHistory(userId,email,{status:'failed',step:'failed',batchId:session.batchId}); tmStoreUpdate(userId,email,{status:'failed',step:'failed',batchId:session.batchId});
            }
          } catch(e) {
            const email=session.bulkEmails[i]||`Mailbox ${i+1}`;
            session.bulkResults.push({email,status:'fail',msg:e.message}); addAmStat(userId,'failed');
          }
          registerAmSession(userId,session,true);
          await safeEdit(bot,chatId,session.promptMsgId,renderBulkStatusText(session.bulkResults,session.bulkEmails,`Memproses ${i+1}/${count}...`),{inline_keyboard:[]});
          await sleep(700);
        }
        const sent=session.bulkResults.filter(r=>r.status==='sent');
        if(!sent.length) { clearTimeout(session.timer); removeAmSession(userId,session); return safeEdit(bot,chatId,session.promptMsgId,`<b>❌ BULK TEMP MAIL GAGAL</b>\n\nTidak ada mailbox yang berhasil dikirimi magic link.`,{inline_keyboard:[[ {text:'⬅️ ‹',callback_data:'am_bulk_temp_menu'} ]]}); }
        session.step='waiting_links'; registerAmSession(userId,session,true);
        await safeEdit(bot,chatId,session.promptMsgId,
          `<b>╭━━〔 BULK TEMP MAIL — MANUAL 〕━━╮</b>\n\n<blockquote expandable>📬 <b>${sent.length}</b> mailbox siap.\n\nMagic link dikirim ke:\n${sent.map((r,i)=>`${i+1}. <code>${esc(r.email)}</code>`).join('\n')}\n\nBuka inbox temp mail, lalu <b>paste magic link satu per satu</b> di chat ini.\n\n⏰ Sesi aktif sampai 2 jam.</blockquote>`,
          provider===2 ? {inline_keyboard:[[{text:'📬 Lihat Inbox Temp Mail 2',callback_data:`am_bulk_tm2_inbox_${userId}`}],[{text:'⬅️ ‹',callback_data:'am_bulk_temp_menu'}]]} : cancelBtn(userId));
      })().catch(async e=>{
        try { clearTimeout(session.timer); } catch {}
        try { removeAmSession(userId,session); } catch {}
        try { await safeEdit(bot,chatId,session.promptMsgId,`<b>❌ BULK TEMP MAIL ERROR</b>\n\n<code>${esc(e?.message || e)}</code>`,{inline_keyboard:[[ {text:'⬅️ ‹',callback_data:'am_bulk_temp_menu'} ]]}); } catch {}
      });
      return;
    }

    // ── Bulk Temp Mail Provider 2 inbox viewer ─────────────────────────────
    if(data.startsWith('am_bulk_tm2_inbox_')) {
      const ownerId=data.replace('am_bulk_tm2_inbox_','');
      if(String(ownerId)!==String(userId)) return bot.answerCallbackQuery(cb.id,{text:'Bukan milik kamu.',show_alert:true});
      const stored=tmStoreGet(userId).filter(x=>Number(x.provider)===2);
      if(!stored.length) return bot.answerCallbackQuery(cb.id,{text:'Belum ada mailbox Provider 2.',show_alert:true});
      await bot.answerCallbackQuery(cb.id).catch(()=>{});
      const rows=stored.slice(-100).map((entry,i)=>[{text:`📧 ${entry.email}`,callback_data:`am_bulk_tm2_read_${i}_${userId}`}]);
      rows.push([{text:'🔄 Refresh Daftar',callback_data:`am_bulk_tm2_inbox_${userId}`}]);
      rows.push([{text:'⬅️ ‹',callback_data:'am_bulk_temp_menu'}]);
      const lines=stored.slice(-100).map((e,i)=>`${i+1}. <code>${esc(e.email)}</code>`).join('\n');
      return safeEdit(bot,chatId,msgId,
        `<b>╭━━〔 INBOX TEMP MAIL 2 〕━━╮</b>\n\n<blockquote expandable>📬 Pilih mailbox untuk melihat pesan.\n\n${lines}</blockquote>`,
        {inline_keyboard:rows});
    }

    if(data.startsWith('am_bulk_tm2_read_')) {
      const parts=data.replace('am_bulk_tm2_read_','').split('_');
      const idx=parseInt(parts[0],10); const ownerId=parts.slice(1).join('_');
      if(String(ownerId)!==String(userId)) return bot.answerCallbackQuery(cb.id,{text:'Bukan milik kamu.',show_alert:true});
      const stored=tmStoreGet(userId).filter(x=>Number(x.provider)===2);
      const entry=stored[idx];
      if(!entry) return bot.answerCallbackQuery(cb.id,{text:'Mailbox tidak ditemukan.',show_alert:true});
      await bot.answerCallbackQuery(cb.id,{text:'Memuat inbox...'}).catch(()=>{});
      await safeEdit(bot,chatId,msgId,
        `<b>╭━━〔 INBOX TEMP MAIL 2 〕━━╮</b>\n\n<blockquote expandable>📧 <b>${esc(entry.email)}</b>\n\n⏳ Mengambil pesan...</blockquote>`,
        {inline_keyboard:[]});
      try {
        const checkedAt = Date.now();
        const items=await tempMail2CheckInbox(entry.username,entry.domain);
        tmStoreUpdate(userId,entry.email,{lastInboxCheckAt:checkedAt,lastInboxCount:items.length,lastInboxError:''});
        let text=`<b>╭━━〔 INBOX TEMP MAIL 2 〕━━╮</b>\n\n<blockquote expandable>📧 <b>${esc(entry.email)}</b>\n`;
        if(!items.length) text+=`\n📭 <b>Inbox kosong</b>\nBelum ada pesan masuk.`;
        else {
          text+=`\n📬 <b>${items.length} pesan ditemukan</b>\n`;
          for(const m of items.slice(0,10)) {
            text+=`\n━━━━━━━━━━━━\n📤 <b>Dari:</b> <code>${esc(m.from||'-')}</code>\n📌 <b>Subjek:</b> ${esc(m.subject||'(tanpa subjek)')}\n`;
            if(m.date) text+=`🕐 <b>Tanggal:</b> ${esc(m.date)}\n`;
            const link=m.verification_link||safeExtractMagicLink(m.body||'');
            if(link) text+=`\n🔗 <b>Magic Link:</b>\n<code>${esc(link.slice(0,800))}</code>\n`;
            else {
              const body=String(m.body||'').replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim();
              if(body) text+=`\n📝 ${esc(body.slice(0,500))}\n`;
            }
          }
        }
        text+=`</blockquote>`;
        return safeEdit(bot,chatId,msgId,text,{inline_keyboard:[
          [{text:'🔄 Refresh Inbox',callback_data:`am_bulk_tm2_read_${idx}_${userId}`}],
          [{text:'📬 Daftar Inbox',callback_data:`am_bulk_tm2_inbox_${userId}`}],
          [{text:'🔗 Buka Inbox API',url:entry.inboxUrl||`${TEMP_MAIL_BASE}/inbox/${encodeURIComponent(entry.email)}`}],
          [{text:'⬅️ ‹',callback_data:'am_bulk_temp_menu'}]
        ]});
      } catch(e) {
        return safeEdit(bot,chatId,msgId,
          `<b>❌ Gagal mengambil inbox</b>\n\n<code>${esc(e.message)}</code>`,
          {inline_keyboard:[
            [{text:'🔄 Coba Lagi',callback_data:`am_bulk_tm2_read_${idx}_${userId}`}],
            [{text:'📬 Daftar Inbox',callback_data:`am_bulk_tm2_inbox_${userId}`}],
            [{text:'⬅️ ‹',callback_data:'am_bulk_temp_menu'}]
          ]});
      }
    }

    // ── am_bulk_count_* ───────────────────────────────────────────────────
    if(data.startsWith('am_bulk_count_')) {
      if(false)
        return bot.answerCallbackQuery(cb.id,{text:'',show_alert:false});
      const part=data.replace('am_bulk_count_','');
      const isCustom=part==='custom';
      const maxCount=isCustom ? null : parseInt(part,10);

      // Setelah jumlah dipilih, pengguna wajib memilih metode: email manual atau temp mail.
      await safeEdit(bot,chatId,msgId,
        `<b>╭━━〔 AM PREMIUM — BULK EMAIL 〕━━╮</b>\n\n`+
        `<blockquote expandable>Jumlah: <b>${isCustom ? 'Kustom (maks. 10)' : maxCount + ' email'}</b>\n\nPilih sumber email yang akan dipakai:</blockquote>`,
        {inline_keyboard:[
          [{text:'Manual Email',callback_data:`am_bulk_manual_${isCustom?'custom':maxCount}`}],
          [{text:'Temp Mail',callback_data:`am_bulk_temp_menu_count_${isCustom?'custom':maxCount}`}],
          [{text:'⬅️ ‹',callback_data:'am_bulk_email'}]
        ]});
      return;

      const promptText=
        `<b>╭━━〔 AM PREMIUM — BULK EMAIL 〕━━╮</b>\n\n`+
        `<blockquote expandable>📧 <b>Langkah 1/2 — Masukkan Daftar Email</b>\n\n`+
        (isCustom
          ? `Kirim daftar email (satu per baris), maksimal <b>10 email</b>.`
          : `Kirim <b>${maxCount} email</b>, satu per baris.`
        )+`\n\n<b>Contoh:</b>\n<code>email1@gmail.com\nemail2@gmail.com</code>\n\n`+
        `⚠️ Pesan kamu akan otomatis <b>dihapus</b> setelah dibaca.</blockquote>\n\n`+
        `⏰ Batas waktu: <b>2 jam</b>`;

      const promptMsg=await (async()=>{
        try { return await bot.editMessageText(promptText,{chat_id:chatId,message_id:msgId,parse_mode:'HTML',reply_markup:cancelBtn(userId)}); }
        catch { return await bot.sendMessage(chatId,promptText,{parse_mode:'HTML',reply_markup:cancelBtn(userId)}); }
      })();

      const timer=setTimeout(async()=>{
        const sess=getActiveAmSession(userId);
        if(!sess) return;
        customEmailSessions.delete(sessionUserKey(userId));
        await safeEdit(bot,chatId,sess.promptMsgId,
          `<b>⏰ AM PREMIUM — SESI HABIS</b>\n\nTidak ada respons dalam 20 menit. Dibatalkan otomatis.`,
          {inline_keyboard:[]});
      }, 2*60*60*1000);

      registerAmSession(userId,{
        step:'waiting_bulk_emails',
        chatId, promptMsgId:promptMsg?.message_id||msgId,
        maxCount:isCustom?10:maxCount, timer,
        bulkResults:[], bulkEmails:[], mode:'bulk',
      });
      return;
    }

    // ── am_tempmail_menu ──────────────────────────────────────────────────
    if(data==='am_tempmail_menu') {
      if(!isAllowed(userId))
        return bot.answerCallbackQuery(cb.id,{text:'Akses ditolak.',show_alert:true});
      const amLimit=amLimitInfo(userId);
      if(!amLimit.allowed)
        return bot.answerCallbackQuery(cb.id,{text:`Limit habis (${amLimit.used}/${amLimit.limit}).`,show_alert:true});

      await safeEdit(bot,chatId,msgId,
        `<b>╭━━〔 AM PREMIUM — TEMP MAIL 〕━━╮</b>\n\n`+
        `<blockquote expandable>📨 <b>Pilih berapa email temp</b> yang ingin dibuat.\n\nBot akan otomatis generate email, kirim magic link, lalu cek inbox dan ambil link login AM.</blockquote>`,
        { inline_keyboard:[
          [{ text:'1 Email',  callback_data:'am_tm_count_1' },
           { text:'3 Email',  callback_data:'am_tm_count_3' },
           { text:'5 Email',  callback_data:'am_tm_count_5' }],
          [{ text:'10 Email', callback_data:'am_tm_count_10' }],
          [{ text:'⬅️ ‹', callback_data:'am_menu_back' }],
        ]}
      );
      return;
    }

    // ── am_tm_count_* ─────────────────────────────────────────────────────
    if(data.startsWith('am_tm_count_')) {
      const count=Math.min(10, Math.max(1, parseInt(data.replace('am_tm_count_',''),10)||1));

      // Mulai proses temp mail otomatis
      await safeEdit(bot,chatId,msgId,
        `<b>╭━━〔 AM PREMIUM — TEMP MAIL 〕━━╮</b>\n\n`+
        `<blockquote expandable>⏳ <b>Memulai proses untuk ${count} email temp...</b>\n\nMohon tunggu.</blockquote>`,
        {inline_keyboard:[]}
      );

      // Jalankan async — tidak block
      (async()=>{
        const results=[]; // { email, link, status }

        for(let i=0;i<count;i++) {
          const num=`[${i+1}/${count}]`;
          // 1) Generate email
          await safeEdit(bot,chatId,msgId,
            `<b>╭━━〔 AM PREMIUM — TEMP MAIL 〕━━╮</b>\n\n`+
            `<blockquote expandable>📨 ${num} <b>Generate email temp...</b></blockquote>`,
            {inline_keyboard:[]}
          );
          const emailData=await tempMail2Get();
          if(!emailData) {
            results.push({ email:'(gagal generate)', link:null, status:'gen_fail' });
            continue;
          }
          const { email, username, domain, token, base: emailBase, inboxUrl }=emailData;
          addAmStat(userId,'created');
          addAmStat(userId,'processed');
          // Simpan mailbox SEBELUM mengirim magic link supaya inbox langsung
          // bisa dibuka/di-refresh walaupun email belum masuk atau proses AM masih berjalan.
          tmStoreAdd(userId,{
            email, username, domain, token:token||null, password:emailData.password||null,
            base:emailBase||TEMP_MAIL_BASE, inboxUrl:inboxUrl||`${TEMP_MAIL_BASE}/inbox/${encodeURIComponent(email)}`,
            provider:2, providerBackend:emailData.providerBackend||'creatett',
            fallbackFrom:emailData.fallbackFrom||null,
            status:'created', step:'mailbox_created'
          });
          const sessionId = `tm_${userId}_${Date.now()}_${i}`;
          addAmHistory(userId,{email,type:'TEMP MAIL',status:'processing',step:'send_magic_link',sessionId,chatId,messageId:msgId,username,domain,base:emailBase||TEMP_MAIL_BASE});

          // 2) Kirim magic link
          await safeEdit(bot,chatId,msgId,
            `<b>╭━━〔 AM PREMIUM — TEMP MAIL 〕━━╮</b>\n\n`+
            `<blockquote expandable>📨 ${num} <b>Kirim magic link ke</b>\n<code>${esc(email)}</code>...</blockquote>`,
            {inline_keyboard:[]}
          );
          updateAmHistory(userId,email,{step:'send_magic_link'}); tmStoreUpdate(userId,email,{step:'send_magic_link'});
          const sendRes=await customEmailSendVerif(email);
          if(!sendRes.success) {
            updateAmHistory(userId,email,{status:'failed',step:'failed'}); tmStoreUpdate(userId,email,{status:'failed',step:'failed'});
            addAmStat(userId,'failed');
            results.push({ email, link:null, status:'send_fail' });
            await sleep(1000);
            continue;
          }

          // 3) Polling inbox
          await safeEdit(bot,chatId,msgId,
            `<b>╭━━〔 AM PREMIUM — TEMP MAIL 〕━━╮</b>\n\n`+
            `<blockquote expandable>📬 ${num} <b>Menunggu email masuk...</b>\n<code>${esc(email)}</code>\n\nBot cek inbox setiap 5 detik (maks 2 menit)</blockquote>`,
            {inline_keyboard:[]}
          );
          updateAmHistory(userId,email,{step:'waiting_inbox',status:'processing'});
          tmStoreUpdate(userId,email,{step:'waiting_inbox',status:'processing'});
          const entry = tmStoreGet(userId).find(x => String(x.email).toLowerCase() === String(email).toLowerCase()) || {
            email, username, domain, base:emailBase||TEMP_MAIL_BASE, provider:2,
            providerBackend:emailData.providerBackend||'creatett',
            fallbackFrom:emailData.fallbackFrom||null,
            inboxUrl:inboxUrl||`${TEMP_MAIL_BASE}/inbox/${encodeURIComponent(email)}`
          };
          // Provider bisa butuh beberapa menit untuk benar-benar menampilkan email.
          const link=await waitTempMailLink(entry,300000);
          tmStoreUpdate(userId,email,{status:link ? 'success' : 'failed',step:link ? 'completed' : 'no_link'});
          if(link) {
            updateAmHistory(userId,email,{status:'success',step:'completed'}); tmStoreUpdate(userId,email,{status:'success',step:'completed'});
            addAmStat(userId,'success');
            results.push({ email, link, status:'got_link' });
          } else {
            updateAmHistory(userId,email,{status:'failed',step:'no_link'}); tmStoreUpdate(userId,email,{status:'failed',step:'no_link'});
            addAmStat(userId,'failed');
            results.push({ email, link:null, status:'no_link' });
          }
          await sleep(800);
        }

        // Tampilkan hasil akhir
        const lines=results.map((r,i)=>{
          const num=`${i+1}.`;
          if(r.status==='gen_fail')  return `${num} ❌ Gagal generate email`;
          if(r.status==='send_fail') return `${num} ❌ <code>${esc(r.email)}</code> — Gagal kirim`;
          if(r.status==='no_link')   return `${num} ⚠️ <code>${esc(r.email)}</code> — Link tidak masuk`;
          return `${num} ✅ <code>${esc(r.email)}</code> — Link didapat`;
        });

        let resultText=
          `<b>╭━━〔 AM PREMIUM — TEMP MAIL 〕━━╮</b>\n\n`+
          `<blockquote expandable>🏁 <b>SELESAI</b>\n\n${lines.join('\n')}</blockquote>`;

        // Tampilkan link yang berhasil di blockquote masing-masing
        for(const r of results.filter(r=>r.status==='got_link')) {
          resultText+=
            `\n\n<blockquote expandable>📧 <b>${esc(r.email)}</b>\n\n`+
            `⚠️ Kirim ke diri sendiri via WA/TG, lalu klik dari dalam app AM:\n\n`+
            `<code>${esc(r.link)}</code></blockquote>`;
          consumeAmLimit(userId);
          await notifyAmFinal(bot,{msg:cb.message,email:r.email,status:'success',detail:'Temp Mail auto link.'});
        }
        resultText+=`\n\n<i>by Yoen</i>`;

        const hasStored = tmStoreGet(userId).length > 0;
        await safeEdit(bot,chatId,msgId,resultText,{
          inline_keyboard: hasStored
            ? [[{ text:'Lihat Inbox', callback_data:`am_tm_inbox_${userId}` }]]
            : []
        });
      })().catch(async e=>{
        try { await reportError(bot,'am_tempmail_auto',e,{chatId,userId,stage:'tempmail_auto'}); } catch {}
        try { await notifyAmError(bot,{msg:cb.message,stage:'tempmail_auto',error:e}); } catch {}
        try { await safeEdit(bot,chatId,msgId,
          `<b>❌ AM TEMP MAIL GAGAL</b>\n\n<code>${esc(e?.message || e)}</code>`,
          {inline_keyboard:[]}); } catch {}
      });
      return;
    }

    // ── am_tm_inbox_<userId> — daftar email tersimpan ─────────────────────
    if(data.startsWith('am_tm_inbox_')) {
      const ownerId = data.replace('am_tm_inbox_','');
      if(String(userId) !== String(ownerId))
        return bot.answerCallbackQuery(cb.id,{text:'Bukan milik kamu.',show_alert:true});
      if(!isAllowed(userId))
        return bot.answerCallbackQuery(cb.id,{text:'Akses ditolak.',show_alert:true});

      const stored = tmStoreGet(userId);
      if(!stored.length) {
        return bot.answerCallbackQuery(cb.id,{text:'Tidak ada email tersimpan.',show_alert:true});
      }

      const buttons = stored.map((entry,i) => ([{
        text: `📧 ${entry.email}`,
        callback_data: `am_tm_read_${i}_${userId}`
      }]));
      buttons.push([{ text:'⬅️ ‹', callback_data:'am_menu_back' }]);

      const lines = stored.map((e,i)=>`${i+1}. <code>${esc(e.email)}</code>`).join('\n');
      await safeEdit(bot,chatId,msgId,
        `<b>╭━━〔 INBOX VIEWER 〕━━╮</b>\n\n`+
        `<blockquote expandable>📬 <b>${stored.length} email tersimpan</b>\n\n${lines}\n\nPilih email untuk cek inbox:</blockquote>`,
        { inline_keyboard: buttons }
      );
      return;
    }

    // ── am_tm_read_<idx>_<userId> — tampilkan inbox dari provider baru
    if(data.startsWith('am_tm_read_')) {
      await bot.answerCallbackQuery(cb.id,{text:'⏳ Memuat inbox...'}).catch(()=>{});
      const parts = data.replace('am_tm_read_','').split('_');
      const idx = parseInt(parts[0],10);
      const ownerId = parts.slice(1).join('_');
      if(String(userId) !== String(ownerId))
        return bot.answerCallbackQuery(cb.id,{text:'Bukan milik kamu.',show_alert:true});

      const stored = tmStoreGet(userId);
      const entry = stored[idx];
      if(!entry) return bot.answerCallbackQuery(cb.id,{text:'Email tidak ditemukan.',show_alert:true});

      await safeEdit(bot,chatId,msgId,
        `<b>╭━━〔 INBOX: ${esc(entry.email)} 〕━━╮</b>\n\n`+
        `<blockquote expandable>⏳ Mengambil inbox dari temp-mail...</blockquote>`,
        {inline_keyboard:[]}
      );

      try {
        const items = await checkTempMailInbox(entry);
        if(!items.length) {
          await safeEdit(bot,chatId,msgId,
            `<b>╭━━〔 INBOX: ${esc(entry.email)} 〕━━╮</b>\n\n`+
            `<blockquote expandable>📭 <b>Inbox kosong</b>\n\nBelum ada pesan masuk.</blockquote>`,
            { inline_keyboard:[
              [{ text:'🔄 Cek Lagi', callback_data:`am_tm_read_${idx}_${userId}` }],
              [{ text:'🔗 Tempel Magic Link', callback_data:`am_tm_manual_${idx}_${userId}` }],
              [{ text:'↩️ ‹', callback_data:`am_tm_inbox_${userId}` }]
            ] }
          );
          return;
        }

        let text = `<b>╭━━〔 INBOX: ${esc(entry.email)} 〕━━╮</b>\n\n`;
        text += `<blockquote expandable>📬 <b>${items.length} pesan ditemukan</b>\n\n`;
        for(const m of items.slice(0,8)) {
          text += `━━━━━━━━━━━━\n`;
          text += `📤 <b>Dari:</b> <code>${esc(m.from || '-')}</code>\n`;
          text += `📌 <b>Subjek:</b> ${esc(m.subject || '(tanpa subjek)')}\n`;
          if(m.date) text += `🕐 <b>Tanggal:</b> ${esc(m.date)}\n`;
          const link = m.verification_link || safeExtractMagicLink(m.body||'');
          if(link) text += `\n🔗 <b>Magic Link:</b>\n<code>${esc(link.slice(0,800))}</code>\n`;
          else {
            const preview = String(m.body||'').replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim().slice(0,500);
            text += `\n📝 <b>Preview:</b>\n${esc(preview || '(kosong)')}\n`;
          }
        }
        text += `</blockquote>\n<i>Magic link hanya ditampilkan. Bot tidak otomatis membuka/menjalankan link tersebut.</i>`;

        await safeEdit(bot,chatId,msgId,text,{
          inline_keyboard:[
            [{ text:'🔄 Refresh Inbox', callback_data:`am_tm_read_${idx}_${userId}` }],
            [{ text:'🔗 Tempel Magic Link', callback_data:`am_tm_manual_${idx}_${userId}` }],
            [{ text:'↩️ ‹', callback_data:`am_tm_inbox_${userId}` }]
          ]
        });
      } catch(e) {
        await safeEdit(bot,chatId,msgId,
          `<b>❌ Gagal ambil inbox</b>\n\n<code>${esc(e.message)}</code>`,
          { inline_keyboard:[
            [{ text:'🔄 Coba Lagi', callback_data:`am_tm_read_${idx}_${userId}` }],
            [{ text:'↩️ ‹', callback_data:`am_tm_inbox_${userId}` }]
          ] }
        );
      }
      return;
    }

    // ── am_tm_manual_<idx>_<userId> — minta user menempelkan magic link
    if(data.startsWith('am_tm_manual_')) {
      const parts = data.replace('am_tm_manual_','').split('_');
      const idx = parseInt(parts[0],10);
      const ownerId = parts.slice(1).join('_');
      if(String(userId) !== String(ownerId))
        return bot.answerCallbackQuery(cb.id,{text:'Bukan milik kamu.',show_alert:true});
      const stored = tmStoreGet(userId);
      const entry = stored[idx];
      if(!entry) return bot.answerCallbackQuery(cb.id,{text:'Email tidak ditemukan.',show_alert:true});

      tempMailManualSessions.set(String(userId), { idx, chatId, messageId:msgId, createdAt:Date.now() });
      await bot.answerCallbackQuery(cb.id,{text:'Tempel magic link di chat ini.'}).catch(()=>{});
      await safeEdit(bot,chatId,msgId,
        `<b>╭━━〔 TEMPEL MAGIC LINK 〕━━╮</b>\n\n`+
        `<blockquote expandable>📧 Email: <code>${esc(entry.email)}</code>\n\n`+
        `Kirim <b>1 pesan</b> berisi magic link/URL di chat ini.\n`+
        `Contoh: <code>https://...</code>\n\n`+
        `Bot hanya akan menyimpan dan menampilkan link tersebut.</blockquote>`,
        {inline_keyboard:[[{text:'❌ Batal',callback_data:`am_tm_read_${idx}_${userId}`}]]}
      );
      return;
    }

    // ── am_custom_cancel_* ────────────────────────────────────────────────
    if(data?.startsWith('am_custom_cancel_')) {
      const targetId=data.split('am_custom_cancel_')[1];
      if(String(userId)!==String(targetId))
        return bot.answerCallbackQuery(cb.id,{text:'Hanya pemilik sesi yang dapat membatalkan.',show_alert:true});

      await bot.answerCallbackQuery(cb.id).catch(()=>{});
      const sessKey=sessionUserKey(targetId);
      const sess=getActiveAmSession(targetId);
      if(sess) {
        clearTimeout(sess.timer);
        const key=sessionKeyOf(sess);
        removeAmSession(targetId,key);
        await safeEdit(bot,chatId,sess.promptMsgId,
          `<b>❌ AM PREMIUM — DIBATALKAN</b>\n\nProses dibatalkan.`,
          {inline_keyboard:[]});
      }
      return;
    }

    // ── am_custom_email (backward compat) ─────────────────────────────────
    if(data==='am_custom_email') {
      // Redirect ke bulk email
      if(!isAllowed(userId))
        return bot.answerCallbackQuery(cb.id,{text:'Akses ditolak.',show_alert:true});
      if(false)
        return bot.answerCallbackQuery(cb.id,{text:'',show_alert:false});

      await safeEdit(bot,chatId,msgId,
        `<b>╭━━〔 AM PREMIUM — BULK EMAIL 〕━━╮</b>\n\n`+
        `<blockquote expandable>📧 <b>Pilih jumlah email</b> yang ingin diproses.</blockquote>`,
        { inline_keyboard:[
          [{ text:'1',  callback_data:'am_bulk_count_1'  },
           { text:'3',  callback_data:'am_bulk_count_3'  },
           { text:'5',  callback_data:'am_bulk_count_5'  }],
          [{ text:'10', callback_data:'am_bulk_count_10' },
           { text:'Kustom', callback_data:'am_bulk_count_custom'}],
          [{ text:'Batal', callback_data:`am_custom_cancel_${userId}` }],
        ]}
      );
      return;
    }
  });

  // ══════════════════════════════════════════════════════════════════════════
  //  LISTENER PESAN — Bulk Email input & verif link
  // ══════════════════════════════════════════════════════════════════════════
  bot.on('message', async (msg)=>{
    if(!msg.text || msg.text.startsWith('/')) return;
    const userId=msg.from?.id;
    if(!userId) return;
    let session=getActiveAmSession(userId);
    // Untuk banyak sesi: bila sesi aktif tidak sedang menunggu link/email, cari sesi
    // lain milik user yang masih mempunyai email pending. Sesi lama tidak dimatikan.
    if(!session || !['waiting_bulk_emails','waiting_links','waiting_link'].includes(session.step)) {
      const sessions=[...getAmSessions(userId).values()]
        .filter(x=>x && ['waiting_bulk_emails','waiting_links','waiting_link'].includes(x.step));
      if(sessions.length) session=sessions.sort((a,b)=>Number(b.lastActivatedAt||0)-Number(a.lastActivatedAt||0))[0];
    }
    if(!session) return;
    const chatId=msg.chat.id;
    if(String(chatId)!==String(session.chatId)) return;

    // ── Step: waiting_bulk_emails ─────────────────────────────────────────
    // Jangan menyentuh pesan user kalau isinya bukan email.
    if(session.step==='waiting_bulk_emails') {
      const rawLines=msg.text.trim().split(/\r?\n/).map(e=>e.trim()).filter(Boolean);
      const emailRe=/^[^\s@]+@[^\s@]+\.[^\s@]+$/i;
      const emails=rawLines.slice(0, session.maxCount||10);

      // Semua baris harus benar-benar email. Kalau bukan, bot diam dan pesan tetap ada.
      if(!rawLines.length || rawLines.length>(session.maxCount||10) || !emails.every(e=>emailRe.test(e))) {
        return;
      }

      // Baru hapus setelah validasi email lolos.
      try { await bot.deleteMessage(chatId, msg.message_id); } catch {}

      const batchId = `bulk_${userId}_${Date.now()}`;
      session.batchId = batchId;
      addAmStat(userId,'created',emails.length);
      addAmStat(userId,'processed',emails.length);
      // Simpan setiap email bulk agar USER maupun OWNER bisa melihat alamat emailnya langsung.
      for (const email of emails) {
        addAmHistory(userId,{email,type:'BULK EMAIL',status:'processing',step:'send_magic_link',sessionId:`${batchId}_${Buffer.from(email).toString('base64url')}`,batchId,chatId,messageId:session.promptMsgId});
      }
      session.bulkEmails=emails;
      session.bulkResults=[];
      session.step='processing_bulk';
      registerAmSession(userId,session,true);

      await safeEdit(bot,chatId,session.promptMsgId,
        renderBulkStatusText([],emails,'Memulai pengiriman magic link...'),
        {inline_keyboard:[]});

      // Kirim ke tiap email
      for(const email of emails) {
        try {
          const res=await customEmailSendVerif(email);
          session.bulkResults.push({
            email,
            status: res.success ? 'sent' : 'fail',
            msg: res.error || '',
          });
          updateAmHistory(userId,email,{status:res.success?'waiting':'failed',step:res.success?'waiting_link':'failed',batchId:session.batchId});
          if(res.success) addAmStat(userId,'sent');
          else addAmStat(userId,'failed');
        } catch(e) {
          session.bulkResults.push({ email, status:'fail', msg:e.message });
          updateAmHistory(userId,email,{status:'failed'});
          addAmStat(userId,'failed');
        }
        registerAmSession(userId,session,true);
        await safeEdit(bot,chatId,session.promptMsgId,
          renderBulkStatusText(session.bulkResults,emails,'Mengirim magic link...'),
          {inline_keyboard:[]});
        await sleep(800);
      }

      const sentCount=session.bulkResults.filter(r=>r.status==='sent').length;

      if(sentCount===0) {
        clearTimeout(session.timer);
        removeAmSession(userId,session);
        await safeEdit(bot,chatId,session.promptMsgId,
          `<b>╭━━〔 AM PREMIUM — BULK EMAIL 〕━━╮</b>\n\n`+
          `<blockquote expandable>❌ <b>Semua email gagal dikirim.</b>\n\nServer menolak semua permintaan. Coba lagi nanti.</blockquote>`,
          {inline_keyboard:[]});
        return;
      }

      session.step='waiting_links';
      for (const r of session.bulkResults.filter(x=>x.status==='sent')) {
        updateAmHistory(userId,r.email,{status:'waiting',step:'waiting_link',batchId:session.batchId});
      }
      registerAmSession(userId,session,true);

      const sentList=session.bulkResults.filter(r=>r.status==='sent')
        .map((r,i)=>`${i+1}. <code>${esc(r.email)}</code>`).join('\n');

      await safeEdit(bot,chatId,session.promptMsgId,
        `<b>╭━━〔 AM PREMIUM — BULK EMAIL 〕━━╮</b>\n\n`+
        `<blockquote expandable>📬 <b>Langkah 2/2 — Masukkan Link Verifikasi</b>\n\n`+
        `Magic link berhasil dikirim ke ${sentCount} email:\n${sentList}\n\n`+
        `<b>Cara lanjut:</b>\n`+
        `1. Buka inbox / SPAM masing-masing email\n`+
        `2. Cari email dari <b>Alight Motion</b>\n`+
        `3. Copy link verifikasi\n`+
        `4. Paste di sini (satu per satu)\n\n`+
        `⚠️ Link yang dikirim akan <b>dihapus</b> otomatis.</blockquote>\n\n`+
        `⏰ Sisa waktu: <b>2 jam</b> sejak awal sesi.`,
        cancelBtn(userId));
      return;
    }

    // ── Step: waiting_links ───────────────────────────────────────────────
    if(session.step==='waiting_links'||session.step==='waiting_link') {
      const link=msg.text.trim();

      // Hanya magic link Alight Motion yang dianggap input valid.
      // Pesan lain tidak dihapus dan bot tidak merespons.
      const validMagic = isValidAlightMagicLink(link);
      if(!validMagic) return;

      // Hapus setelah validasi format lolos. Jika API gagal, bot tetap memberi hasil.
      try { await bot.deleteMessage(chatId, msg.message_id); } catch {}

      const pendingEmails=(session.bulkResults||[])
        .filter(r=>r.status==='sent')
        .map(r=>r.email);

      if(pendingEmails.length===0) {
        clearTimeout(session.timer);
        removeAmSession(userId,session);
        await safeEdit(bot,chatId,session.promptMsgId,
          `<b>╭━━〔 AM PREMIUM — BULK EMAIL 〕━━╮</b>\n\n`+
          `<blockquote expandable>✅ <b>Semua email sudah diproses.</b></blockquote>`,
          {inline_keyboard:[]});
        return;
      }

      const targetEmail=pendingEmails[0];

      await safeEdit(bot,chatId,session.promptMsgId,
        `<b>╭━━〔 AM PREMIUM — BULK EMAIL 〕━━╮</b>\n\n`+
        `<blockquote expandable>⏳ <b>Memverifikasi...</b>\n\nMemproses link untuk:\n<code>${esc(targetEmail)}</code></blockquote>`,
        {inline_keyboard:[]});

      let verifyRes;
      try {
        verifyRes=await customEmailVerify(targetEmail,link);
      } catch(e) {
        await notifyAmError(bot,{msg,stage:'verify_link',error:e,email:targetEmail});
        const idx=session.bulkResults.findIndex(r=>r.email===targetEmail);
        if(idx!==-1) session.bulkResults[idx].status='verif_fail';
        registerAmSession(userId,session,true);
        await safeEdit(bot,chatId,session.promptMsgId,
          `<b>╭━━〔 AM PREMIUM — BULK EMAIL 〕━━╮</b>\n\n`+
          `<blockquote expandable>⚠️ <b>Gagal verifikasi untuk:</b>\n<code>${esc(targetEmail)}</code>\n\nError: <code>${esc(e.message)}</code>\n\nKirim link email lain, atau tekan Batal.</blockquote>`,
          cancelBtn(userId));
        return;
      }

      const verifyBody=verifyRes?.data||verifyRes?.json||{};
      const verifyMessage=String(verifyBody.message||verifyRes?.text||'');
      const explicitFail=verifyBody.status===false||verifyBody.success===false||verifyBody.error===true;
      const success=!explicitFail&&verifyRes?.success===true&&
        (verifyBody.status===true||verifyBody.success===true||
         /berhasil|sukses|premium|aktif|unlocked|verified|success|confirmed/i.test(verifyMessage));

      const idx=session.bulkResults.findIndex(r=>r.email===targetEmail);
      if(idx!==-1) session.bulkResults[idx].status=success?'verified':'verif_fail';
      updateAmHistory(userId,targetEmail,{status:success?'success':'failed',step:success?'completed':'verif_failed',batchId:session.batchId});
      registerAmSession(userId,session,true);

      if(success) {
        consumeAmLimit(userId);
        addAmStat(userId,'success');
        await notifyAmFinal(bot,{msg,email:targetEmail,status:'success',detail:'Bulk verifikasi berhasil.'});
        // DM sukses ke user dengan detail quota & expiry
        try {
          const prem = verifyBody?.premium || {};
          const quota = prem?.quota || verifyBody?.quota || null;
          const result = prem?.data?.result || prem?.result || null;
          let detail = `✅ <b>AM Premium berhasil!</b>\n📧 <code>${esc(targetEmail)}</code>`;
          if(quota) detail += `\n📊 Sisa quota hari ini: <b>${quota.remainingToday ?? '-'}</b> | Reset: ${esc(quota.resetFormatted||'-')}`;
          if(result?.expiryTimeMillis) detail += `\n📅 Aktif sampai: <b>${new Date(result.expiryTimeMillis).toLocaleString('id-ID')}</b>`;
          await bot.sendMessage(userId, detail, {parse_mode:'HTML'});
        } catch {}
      } else {
        addAmStat(userId,'failed');
        await notifyAmFinal(bot,{msg,email:targetEmail,status:'failed',detail:verifyMessage||'Verifikasi gagal.'});
        // DM alasan gagal langsung ke user
        try {
          const errDetail = verifyMessage || verifyRes?.error || 'Unknown error';
          await bot.sendMessage(userId,
            `❌ <b>AM Premium gagal</b>\n📧 <code>${esc(targetEmail)}</code>\n\n<b>Alasan:</b>\n<code>${esc(errDetail.slice(0,800))}</code>`,
            {parse_mode:'HTML'}
          );
        } catch {}
      }

      const stillPending=session.bulkResults.filter(r=>r.status==='sent');

      if(stillPending.length===0) {
        clearTimeout(session.timer);
        removeAmSession(userId,session);
        const resultLines=(session.bulkResults||[]).map((r,i)=>{
          const icon=r.status==='verified'?'✅':r.status==='verif_fail'?'⚠️':'❌';
          return `${i+1}. ${icon} <code>${esc(r.email)}</code>`;
        }).join('\n');
        await safeEdit(bot,chatId,session.promptMsgId,
          `<b>╭━━〔 AM PREMIUM — BULK EMAIL 〕━━╮</b>\n\n`+
          `<blockquote expandable>🏁 <b>SEMUA EMAIL SELESAI DIPROSES</b>\n\n${resultLines}</blockquote>\n\n<i>by Yoen</i>`,
          {inline_keyboard:[]});
      } else {
        const resultLines=(session.bulkResults||[]).map((r,i)=>{
          const icon=r.status==='verified'?'✅':r.status==='verif_fail'?'⚠️':r.status==='sent'?'📬':'❌';
          return `${i+1}. ${icon} <code>${esc(r.email)}</code>`;
        }).join('\n');
        await safeEdit(bot,chatId,session.promptMsgId,
          `<b>╭━━〔 AM PREMIUM — BULK EMAIL 〕━━╮</b>\n\n`+
          `<blockquote expandable><b>Progress:</b>\n${resultLines}\n\n`+
          `📬 Masih ada <b>${stillPending.length} email</b> menunggu link.\nKirim link verifikasi berikutnya.</blockquote>`,
          cancelBtn(userId));
      }
      return;
    }
  });

};
