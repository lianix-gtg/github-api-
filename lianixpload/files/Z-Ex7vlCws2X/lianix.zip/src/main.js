const { loadJsonData, saveJsonData } = require('../src/data/function');
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const chalk = require("chalk");
const { execSync, exec, spawn } = require("child_process");
const axios = require("axios");
const { Client } = require("ssh2");
const QRCode = require('qrcode');
const archiver = require("archiver");
const { createCanvas, loadImage } = require("./optionalCanvas");
const sharp = require("sharp");
const fetch = require("node-fetch");
const fsExtra = require("fs-extra");
const os = require("os");
const readline = require("readline");
const https = require("https");
const settings = require('../settings.js');
const { checkLimit } = require('./limit.js');
const expiry = require('./expiry.js');
const { respawnAndExit } = require('./data/respawn.js');
const { reportError } = require('./data/errorReporter.js');

const OWNER_UIDB = String(settings.ownerId).trim();
const OWNER_UID = settings.ownerId;

const OWNER_ID = settings.ownerId;
const OWNER_FILE = './db/users/adminID.json';
const FOUNDER_FILE    = './db/users/founderUsers.json';
const ROOT_FILE       = './db/users/rootUsers.json';
// GOD-tier roles (di atas FOUNDER, di bawah DEV/OWNER)
const PEMILIK_FILE    = './db/users/pemilikUsers.json';
const COFOUNDER_FILE  = './db/users/cofounderUsers.json';
const KING_FILE       = './db/users/kingUsers.json';
const KHUSUS_FILE     = './db/users/khususUsers.json';
const GOD_FILE        = './db/users/godUsers.json';
const DEV_FILE = './db/users/developerUsers.json';

const PREMIUM_FILE = './db/users/premiumUsers.json';
const PREMV2_FILE = './db/users/version/premiumV2.json';
const PREMV3_FILE = './db/users/version/premiumV3.json';
const PREMV4_FILE = './db/users/version/premiumV4.json';
const PREMV5_FILE = './db/users/version/premiumV5.json';
const PREMV6_FILE = './db/users/version/premiumV6.json';
const PREMV7_FILE = './db/users/version/premiumV7.json';
const PREMV8_FILE = './db/users/version/premiumV8.json';
const PREMV9_FILE = './db/users/version/premiumV9.json';
const PREMV10_FILE = './db/users/version/premiumV10.json';

const RESS_FILE = './db/users/resellerUsers.json';
const RESSV2_FILE = './db/users/version/resellerV2.json';
const RESSV3_FILE = './db/users/version/resellerV3.json';
const RESSV4_FILE = './db/users/version/resellerV4.json';
const RESSV5_FILE = './db/users/version/resellerV5.json';
const RESSV6_FILE = './db/users/version/resellerV6.json';
const RESSV7_FILE = './db/users/version/resellerV7.json';
const RESSV8_FILE = './db/users/version/resellerV8.json';
const RESSV9_FILE = './db/users/version/resellerV9.json';
const RESSV10_FILE = './db/users/version/resellerV10.json';

const CEO_FILE = './db/users/ceoUsers.json';
const TK_FILE = './db/users/tkUsers.json';
const PT_FILE = './db/users/ptUsers.json';
const RESSVPS_FILE = './db/users/resellerVps.json';
const settingsPath = "./settings.js";
const ANTICULIK_FILE = "./db/anticulikbot.json";

// Pastikan semua folder database (db/users & db/users/version) sudah ada
// sebelum file JSON di dalamnya dibaca/ditulis. Tanpa ini, semua perintah
// yang menyimpan role (addall, addprem, addres, addceo, dll) akan gagal
// menyimpan secara diam-diam karena folder tujuannya belum dibuat.
[
    OWNER_FILE, FOUNDER_FILE, PREMIUM_FILE, PREMV2_FILE, PREMV3_FILE, PREMV4_FILE, PREMV5_FILE, PREMV6_FILE, PREMV7_FILE, PREMV8_FILE, PREMV9_FILE, PREMV10_FILE,
    RESS_FILE, RESSV2_FILE, RESSV3_FILE, RESSV4_FILE, RESSV5_FILE, RESSV6_FILE, RESSV7_FILE, RESSV8_FILE, RESSV9_FILE, RESSV10_FILE,
    CEO_FILE, TK_FILE, PT_FILE, RESSVPS_FILE
].forEach((file) => {
    const dir = path.dirname(file);
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }
    if (!fs.existsSync(file)) {
        fs.writeFileSync(file, JSON.stringify([], null, 2));
    }
});

// Pastikan database role tambahan juga selalu tersedia.
[FOUNDER_FILE, ROOT_FILE, DEV_FILE, PEMILIK_FILE, COFOUNDER_FILE, KING_FILE, KHUSUS_FILE, GOD_FILE].forEach((file) => {
    const dir = path.dirname(file);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    if (!fs.existsSync(file)) fs.writeFileSync(file, JSON.stringify([], null, 2));
});

function loadAntiCulik() {
  if (!fs.existsSync(ANTICULIK_FILE)) {
    fs.mkdirSync(path.dirname(ANTICULIK_FILE), { recursive: true });
     fs.writeFileSync(
       ANTICULIK_FILE,
        JSON.stringify({ enabled: false }, null, 2)
      );
    }
    return JSON.parse(fs.readFileSync(ANTICULIK_FILE));
  }

function saveAntiCulik(data) {
    fs.writeFileSync(ANTICULIK_FILE, JSON.stringify(data, null, 2));
  }

module.exports = (bot) => {
function notifyOwner(commandName, msg) {
    const userId = msg.from.id;
    const username = msg.from.username || msg.from.first_name;
    const chatId = msg.chat.id;
    const now = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });

    const logMessage = `<pre>⟐ Command: /${commandName}
◉ User: @${username}
⌇ ID: ${userId}
◷ Waktu: ${now}
</pre>
    `;
    bot.sendMessage(OWNER_ID, logMessage, { parse_mode: 'HTML' });
}
const {
    ownerId,
    dev,
    qris,
    pp,
    ppVid,
    panel
} = settings;

async function safeReply(bot, chatId, text, opts = {}) {
  try { return await bot.sendMessage(chatId, text, opts); } catch (e) { console.error("safeReply:", e?.message || e); return null; }
}

/////////////////////////////////////////////////////////////////
bot.onText(/^\/cekid$/, async (msg) => {
  const chatId = msg.chat.id;
  const user = msg.from;

  try {
    const fullName = `${user.first_name || ''} ${user.last_name || ''}`.trim() || 'Pengguna';
    const username = user.username ? `@${user.username}` : '-';
    const userId = String(user.id);
    const today = new Date().toISOString().split('T')[0];
    const dcId = Math.floor(Number(user.id) / 1000000000) % 256;

    let photoDataUri = "";
    try {
      const photos = await bot.getUserProfilePhotos(user.id, { limit: 1 });
      if (photos.total_count > 0) {
        const fileId = photos.photos[0][0].file_id;
        const file = await bot.getFile(fileId);
        const photoUrl = `https://api.telegram.org/file/bot${settings.token}/${file.file_path}`;
        const response = await axios.get(photoUrl, {
          responseType: "arraybuffer",
          timeout: 15000
        });
        const ext = String(file.file_path || "").toLowerCase();
        const mime = ext.endsWith(".png") ? "image/png" : "image/jpeg";
        photoDataUri = `data:${mime};base64,${Buffer.from(response.data).toString("base64")}`;
      }
    } catch (e) {
      console.log("Gagal ambil foto profil:", e.message);
    }

    const esc = (v) => String(v ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");

    const avatar = photoDataUri
      ? `<image href="${photoDataUri}" x="80" y="150" width="140" height="140" preserveAspectRatio="xMidYMid slice" clip-path="url(#avatarClip)"/>`
      : `<circle cx="150" cy="220" r="70" fill="#1b314a"/><text x="150" y="230" text-anchor="middle" font-size="42" fill="#fff">ID</text>`;

    const svg = `
<svg xmlns="http://www.w3.org/2000/svg" width="800" height="450" viewBox="0 0 800 450">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#07111f"/>
      <stop offset=".55" stop-color="#10243b"/>
      <stop offset="1" stop-color="#0b6b61"/>
    </linearGradient>
    <clipPath id="avatarClip"><circle cx="150" cy="220" r="70"/></clipPath>
  </defs>
  <rect width="800" height="450" fill="url(#bg)"/>
  <rect x="28" y="28" width="744" height="394" rx="28" fill="#fff" fill-opacity=".08" stroke="#fff" stroke-opacity=".16" stroke-width="2"/>
  <text x="52" y="78" fill="#fff" font-family="Arial, sans-serif" font-size="31" font-weight="700">TELEGRAM ID CARD</text>
  <text x="52" y="103" fill="#fff" fill-opacity=".58" font-family="Arial, sans-serif" font-size="16">USER PROFILE • LIANIX CPANEL</text>
  <line x1="52" y1="120" x2="748" y2="120" stroke="#fff" stroke-opacity=".14"/>
  ${avatar}
  <circle cx="150" cy="220" r="70" fill="none" stroke="#fff" stroke-opacity=".9" stroke-width="4"/>
  <text x="280" y="150" fill="#fff" font-family="Arial, sans-serif" font-size="24" font-weight="700">Informasi Pengguna:</text>
  <text x="280" y="190" fill="#fff" font-family="Arial, sans-serif" font-size="20">Nama: ${esc(fullName)}</text>
  <text x="280" y="220" fill="#fff" font-family="Arial, sans-serif" font-size="20">User ID: ${esc(userId)}</text>
  <text x="280" y="250" fill="#fff" font-family="Arial, sans-serif" font-size="20">Username: ${esc(username)}</text>
  <text x="280" y="280" fill="#fff" font-family="Arial, sans-serif" font-size="20">Tanggal: ${esc(today)}</text>
  <text x="280" y="310" fill="#fff" font-family="Arial, sans-serif" font-size="20">DC ID: ${esc(dcId)}</text>
  <text x="400" y="400" text-anchor="middle" fill="#fff" fill-opacity=".65" font-family="Arial, sans-serif" font-size="16" font-style="italic">ID Card by #Lianix - @${esc(dev)}</text>
</svg>`;

    const buffer = await sharp(Buffer.from(svg)).png().toBuffer();

    const caption = `
◉ *Nama         :* ${fullName}
⌇ *User ID      :* \`${userId}\`
⟐ *Username :* ${username}
    `;

    await bot.sendPhoto(chatId, buffer, {
      caption,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [[{ text: "ʙᴜʏ ꜱᴄʀɪᴘᴛ", url: settings.buyScriptUrl }]]
      }
    });
  } catch (err) {
    console.error('Gagal generate ID card:', err.message);
    await safeReply(bot, chatId, '◇ Gagal generate ID card — coba lagi.');
  }
});
  bot.onText(/^\/pay/, async (msg) => {
    const chatId = msg.chat.id;

    await bot.sendPhoto(chatId, qris, {
      caption: `<blockquote expandable>⌗ Metode Pembayaran Qris

Silahkan scan QRIS di atas untuk melakukan pembayaran.

◆ Dana Payment
Nomor: <code>${settings.dana}</code>

Kirim bukti transfer dan hubungi owner!</blockquote>`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "⟐ Chat Owner", url: `https://t.me/${dev}` }]
        ]
      }
    });
  });
  bot.onText(/^\/backup_legacy_disabled$/i, async (msg) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id;

    if (fromId !== OWNER_UID) {
      return bot.sendMessage(chatId, `◇ Kamu bukan ${settings.dev}`, {
        parse_mode: "Markdown",
        reply_to_message_id: msg.message_id
      });
    }

    const backupFile = path.join(__dirname, "..", "lianix.zip");
    const output = fs.createWriteStream(backupFile);
    const archive = archiver("zip", { zlib: { level: 9 } });

    await bot.sendMessage(chatId, "⏳ Proses Backup.....");

    let archiveFailed = false;

    archive.on("error", (err) => {
      archiveFailed = true;
      console.error("[/backup] archive error:", err);
      bot.sendMessage(chatId, `◇ Gagal membuat backup!\nAlasan: ${err.message}`);
    });

    output.on("error", (err) => {
      archiveFailed = true;
      console.error("[/backup] output stream error:", err);
      bot.sendMessage(chatId, `◇ Gagal menulis file backup!\nAlasan: ${err.message}`);
    });

    archive.pipe(output);

    ["index.js", "settings.js", "package.json"].forEach((file) => {
      const filePath = path.join(__dirname, "..", file);
      if (fs.existsSync(filePath)) {
        archive.file(filePath, { name: file });
      }
    });

    ["src", "db", "@rexzystore"].forEach((dir) => {
      const dirPath = path.join(__dirname, "..", dir);
      if (fs.existsSync(dirPath)) {
        archive.directory(dirPath, dir);
      }
    });

    output.on("close", async () => {
      if (archiveFailed) return;

      try {
        // Limit dokumen Bot API Telegram ±50MB. Kalau lebih, kirim nggak akan
        // pernah berhasil dan sebelumnya bakal "diam" tanpa pesan error.
        const sizeMB = fs.statSync(backupFile).size / (1024 * 1024);
        if (sizeMB > 49) {
          fs.unlinkSync(backupFile);
          return bot.sendMessage(
            chatId,
            `◇ Backup gagal dikirim: ukuran file ${sizeMB.toFixed(1)}MB, melebihi limit Telegram (50MB).\nCoba kecilin isi folder db/ atau kecualikan folder besar dari backup.`
          );
        }

        // Manual backup selalu dikirim ke chat asal (private/grup/channel),
        // bukan dipaksa masuk ke private chat owner.
        await bot.sendDocument(chatId, backupFile);
        fs.unlinkSync(backupFile);
      } catch (err) {
        console.error("[/backup] send error:", err);
        bot.sendMessage(chatId, `◇ Gagal mengirim file backup!\nAlasan: ${err.message}`);
      }
    });

    archive.finalize();
  });

// ─── /setpanelpw <password> ───────────────────────────────────────────────────
// Set password panel web untuk login via Mini App
bot.onText(/^\/setpanelpw(?:\s+(.+))?$/, async (msg, match) => {
  const chatId   = msg.chat.id;
  const fromId   = msg.from.id;
  const password = (match[1] || "").trim();

  if (!password) {
    return bot.sendMessage(chatId,
      "◈ *Format:* `/setpanelpw <password>`\n\nPassword minimal 6 karakter.",
      { parse_mode: "Markdown", reply_to_message_id: msg.message_id }
    );
  }
  if (password.length < 6) {
    return bot.sendMessage(chatId,
      "◈ Password minimal *6 karakter*.",
      { parse_mode: "Markdown", reply_to_message_id: msg.message_id }
    );
  }

  try {
    const webserver = require("./webserver");
    const username  = msg.from.username || String(fromId);
    await webserver._setPassword(fromId, username, password);
    bot.sendMessage(chatId,
      `◉ Password panel berhasil disimpan!\n\n` +
      `◉ Username: \`${username}\`\n` +
      `◈ Password: \`${password}\`\n\n` +
      `Gunakan tombol *Panel Login* untuk masuk ke dashboard.`,
      { parse_mode: "Markdown", reply_to_message_id: msg.message_id }
    );
  } catch (err) {
    bot.sendMessage(chatId, `◇ Gagal simpan password: ${err.message}`,
      { reply_to_message_id: msg.message_id }
    );
  }
});

// ─── /panel ─────────────────────────────────────────────────────────────────
// Kirim keyboard persistent dengan tombol "Panel Login" (Telegram Mini App)
bot.onText(/^\/panel$/, async (msg) => {
  const chatId    = msg.chat.id;
  const settings  = require("../settings");
  const panelUrl  = settings.webpanel && settings.webpanel.url
    ? settings.webpanel.url
    : null;

  if (!panelUrl || panelUrl.includes("ganti-dengan-domain")) {
    return bot.sendMessage(chatId,
      "◈ URL webpanel belum dikonfigurasi.\nIsi `webpanel.url` di `settings.js` dengan URL HTTPS server kamu.",
      { parse_mode: "Markdown", reply_to_message_id: msg.message_id }
    );
  }

  bot.sendMessage(chatId,
    "[ ] Panel Jhonaley Store\n\nTap tombol di bawah untuk membuka dashboard panel.\nBelum punya akun panel? Ketik `/setpanelpw <password>` dulu.",
    {
      parse_mode: "Markdown",
      reply_markup: {
        keyboard: [[
          { text: "[ ] Panel Login", web_app: { url: panelUrl } }
        ]],
        resize_keyboard: true,
        one_time_keyboard: false,
      }
    }
  );
});

// ─── /closepanel ─────────────────────────────────────────────────────────────
// Tutup / hapus keyboard Panel Login
bot.onText(/^\/closepanel$/, async (msg) => {
  bot.sendMessage(msg.chat.id, "Keyboard panel ditutup.", {
    reply_markup: { remove_keyboard: true }
  });
});



bot.onText(/^\/info(@\w+)*\s*(.*)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  let targetUser = null;

  const parameter = match[2] ? match[2].trim() : '';

  if (parameter.startsWith('@')) {
    try {
      const chatMember = await bot.getChatMember(chatId, `@${parameter.substring(1)}`);
      targetUser = chatMember.user;
    } catch {
      return bot.sendMessage(chatId, `◇ User @${parameter.substring(1)} tidak ditemukan.`, { reply_to_message_id: msg.message_id });
    }
  } else if (msg.reply_to_message) {
    targetUser = msg.reply_to_message.from;
  } else {
    targetUser = msg.from;
  }

  const userId   = String(targetUser.id);
  const username = targetUser.username ? `@${targetUser.username}` : `(no username)`;
  const fullName = [targetUser.first_name, targetUser.last_name].filter(Boolean).join(' ') || 'User';

  // Helpers — absolute paths biar aman
  const absPath = f => path.join(__dirname, '..', f.replace(/^\.\//, ''));
  const loadArr = f => { try { const p = absPath(f); return fs.existsSync(p) ? JSON.parse(fs.readFileSync(p, 'utf8')) : []; } catch { return []; } };
  const has = (f) => loadArr(f).map(String).includes(userId);

  // Role badge pakai getUserRoleExtended dari limit.js (sudah absolute path, paling akurat)
  const { getUserRoleExtended, ROLE_DISPLAY_LABELS } = require('./limit.js');
  const roleKey   = getUserRoleExtended(userId);
  const roleBadge = ROLE_DISPLAY_LABELS[roleKey] || 'MEMBER';

  // Status start bot
  let startedBot = false;
  try { startedBot = !!(await bot.getChat(userId)); } catch {}

  // Server akses — V1..V10 cek RESS + PREM
  const SERVER_SLOTS = [
    { label: 'Server V1',  ress: 'db/users/resellerUsers.json',     prem: 'db/users/premiumUsers.json' },
    { label: 'Server V2',  ress: 'db/users/version/resellerV2.json', prem: 'db/users/version/premiumV2.json' },
    { label: 'Server V3',  ress: 'db/users/version/resellerV3.json', prem: 'db/users/version/premiumV3.json' },
    { label: 'Server V4',  ress: 'db/users/version/resellerV4.json', prem: 'db/users/version/premiumV4.json' },
    { label: 'Server V5',  ress: 'db/users/version/resellerV5.json', prem: 'db/users/version/premiumV5.json' },
    { label: 'Server V6',  ress: 'db/users/version/resellerV6.json', prem: 'db/users/version/premiumV6.json' },
    { label: 'Server V7',  ress: 'db/users/version/resellerV7.json', prem: 'db/users/version/premiumV7.json' },
    { label: 'Server V8',  ress: 'db/users/version/resellerV8.json', prem: 'db/users/version/premiumV8.json' },
    { label: 'Server V9',  ress: 'db/users/version/resellerV9.json', prem: 'db/users/version/premiumV9.json' },
    { label: 'Server V10', ress: 'db/users/version/resellerV10.json', prem: 'db/users/version/premiumV10.json' },
  ];

  // Selalu tampilkan V1, yang lain hanya kalau file-nya ada
  const serverRows = SERVER_SLOTS.filter((s, i) => {
    if (i === 0) return true; // V1 always shown
    return fs.existsSync(absPath(s.ress)) || fs.existsSync(absPath(s.prem));
  }).map((s, i, arr) => {
    const hasRess = has(s.ress);
    const hasPrem = has(s.prem);
    const mark    = (hasRess || hasPrem) ? '◆' : '◌';
    const type    = hasRess ? 'RESS' : hasPrem ? 'PREM' : 'Tidak ada akses';
    return `${mark} <b>${s.label}</b>  ${type}`;
  });

  const chatBotLine = startedBot ? '◆ Sudah start bot' : '◌ Belum start bot';

  // Expiry info — tampilkan semua role yang punya expiry (aktif maupun expired)
  const EXPIRY_ROLE_MAP = [
    { key: 'reseller',   label: 'Reseller'   },
    { key: 'premium',    label: 'Premium'    },
    { key: 'pt',         label: 'PT'         },
    { key: 'tk',         label: 'TK'         },
    { key: 'ceo',        label: 'CEO'        },
    { key: 'founder',    label: 'Founder'    },
    { key: 'pemilik',    label: 'Pemilik'    },
    { key: 'cofounder',  label: 'Co-Founder' },
    { key: 'king',       label: 'King'       },
    { key: 'khusus',     label: 'Khusus'     },
    { key: 'resellerVps',label: 'Reseller VPS'},
  ];

  const expiryEntries = [];
  for (const { key, label } of EXPIRY_ROLE_MAP) {
    const ei = expiry.getExpiry(userId, key);
    if (!ei) continue;
    const formatted = expiry.formatExpiry(userId, key);
    const isExp = expiry.isExpired(userId, key);
    expiryEntries.push({ label, formatted, isExp });
  }

  // Build expiry lines
  let expiryLines = '';
  if (expiryEntries.length === 0) {
    expiryLines = `╰ <b>Expired</b>  : Unlimited\n`;
  } else if (expiryEntries.length === 1) {
    const e = expiryEntries[0];
    expiryLines = `╰ <b>Expired</b>  : ${e.isExp ? `⚠ ${e.label} <b>EXPIRED</b>` : e.formatted}\n`;
  } else {
    // Multiple roles — tampilkan semua
    expiryLines = `├ <b>Expired</b>  :\n`;
    expiryEntries.forEach((e, i) => {
      const isLast = i === expiryEntries.length - 1;
      const prefix = isLast ? '  ╰' : '  ├';
      const status = e.isExp ? `⚠ <b>EXPIRED</b>` : e.formatted;
      expiryLines += `${prefix} ${e.label}: ${status}\n`;
    });
  }


  const text =
    `⟐ <b>#Lianix</b> — INFO ⟐\n\n` +

    `<blockquote expandable>` +
    `<b>◆ IDENTITAS</b>\n` +
    `├ <b>Nama</b>     : ${fullName}\n` +
    `├ <b>Username</b> : ${username}\n` +
    `├ <b>ID</b>       : <code>${userId}</code>\n` +
    `├ <b>Role</b>     : <b>${roleBadge}</b>\n` +
    expiryLines +
    `</blockquote>\n\n` +

    `<blockquote expandable>` +
    `<b>≋ AKSES SERVER</b>\n` +
    (serverRows.length ? serverRows.join('\n') : 'Belum ada akses panel') +
    `</blockquote>\n\n` +

    `<blockquote expandable>` +
    `<b>⌘ STATUS BOT</b>\n` +
    `╰ ${chatBotLine}` +
    `</blockquote>`;

  bot.sendMessage(chatId, text, {
    parse_mode: 'HTML',
    reply_to_message_id: msg.message_id,
  });
});

// ===== /role — tampilkan semua role, mana yang dimiliki vs belum =====
bot.onText(/^\/role$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();

  const getRoleLbl = require('./limit.js').getUserRoleLabel;
  const currentRole = getRoleLbl(userId);

  const load = f => {
    try { return fs.existsSync(f) ? JSON.parse(fs.readFileSync(f)) : []; } catch { return []; }
  };

  // Semua role + deskripsi akses masing-masing
  const ROLE_DEF = [
    {
      key: 'owner', label: 'OWNER', file: './db/users/adminID.json',
      desc: 'Owner biasa — dapat mengelola fitur owner sesuai akses yang diberikan, tetapi bukan pembuat/developer bot.',
      akses: 'Kelola role & fitur owner sesuai izin',
    },
    {
      key: 'reseller', label: 'RESELLER', file: './db/users/resellerUsers.json',
      desc: 'Bisa create panel RESS di Server V1. Dasar dari semua akses ilegal.',
      akses: '/unli (Panel Unlimited V1)',
    },
    {
      key: 'premium', label: 'PREMIUM', file: './db/users/premiumUsers.json',
      desc: 'Bisa create panel di server premium legal. RAM lebih besar, NVMe SSD.',
      akses: 'Panel Legal Premium S1',
    },
    {
      key: 'pt', label: 'PT', file: './db/users/ptUsers.json',
      desc: 'Tier di atas Premium. Bisa akses lebih banyak server premium.',
      akses: 'Panel Legal PT S1-S2',
    },
    {
      key: 'tk', label: 'TK', file: './db/users/tkUsers.json',
      desc: 'Tier TK — akses penuh server legal + limit lebih tinggi.',
      akses: 'Panel Legal TK S1-S3',
    },
    {
      key: 'ceo', label: 'CEO', file: './db/users/ceoUsers.json',
      desc: 'Akses admin bot & manajemen reseller. Bisa add/remove RESS & PREM.',
      akses: 'Kelola RESS, PREM, PT, TK + Panel S1-S4',
    },
    {
      key: 'founder', label: 'FOUNDER', file: './db/users/founderUsers.json',
      desc: 'Role tinggi, bisa akses semua server & bypass limit harian.',
      akses: 'Semua server legal + bypass limit',
    },
    {
      key: 'admin_owner', label: 'OWNER', file: './db/users/adminID.json',
      desc: 'Owner biasa — akses administrasi bot sesuai hak yang diberikan, berbeda dari DEVELOPER pembuat.',
      akses: 'Kelola role & fitur sesuai izin Owner',
    },
    {
      key: 'pemilik', label: 'PEMILIK', file: './db/users/pemilikUsers.json',
      desc: 'GOD-tier 1 — di atas Founder, bisa kelola RESS sampai FOUNDER.',
      akses: 'Kelola semua role s/d FOUNDER + semua server',
    },
    {
      key: 'cofounder', label: 'CO-FOUNDER', file: './db/users/cofounderUsers.json',
      desc: 'GOD-tier 2 — bisa add/manage PEMILIK ke bawah.',
      akses: 'Kelola RESS - PEMILIK + CADP Server 2 (jika punya key)',
    },
    {
      key: 'king', label: 'KING', file: './db/users/kingUsers.json',
      desc: 'GOD-tier 3 — akses CADP S1 & S2 + kelola sampai CO-FOUNDER.',
      akses: 'CADP S1-S2 + Kelola RESS - CO-FOUNDER',
    },
    {
      key: 'khusus', label: 'ROLE KHUSUS', file: './db/users/khususUsers.json',
      desc: 'GOD-tier 4 — role spesial khusus, akses hampir setara KING.',
      akses: 'CADP S1-S2 + semua server + bypass penuh',
    },
    {
      key: 'god', label: 'GOD', file: './db/users/godUsers.json',
      desc: 'GOD-tier tertinggi — akses penuh semua fitur tanpa batasan.',
      akses: 'Semua fitur + CADP S1-S2 + bypass semua limit',
    },
    {
      key: 'developer', label: 'DEVELOPER', file: './db/users/developerUsers.json',
      desc: 'Pembuat/developer bot — role tertinggi dan identitas utama sistem.',
      akses: 'Semua fitur + konfigurasi inti + bypass penuh',
    },
  ];

  const lines = ROLE_DEF.map((r, i) => {
    const list = load(r.file);
    const punya = list.includes(userId);
    const last = i === ROLE_DEF.length - 1;
    const mark = punya ? '◆' : '◌';
    const prefix = last ? '└' : '•';
    return (
      `${prefix} <b>${mark} ${r.label}</b>\n` +
      `  ${r.desc}\n` +
      `  Akses: ${r.akses}`
    );
  }).join('\n\n');

  const text =
    `<b>— ROLE INFORMATION —</b>\n\n` +
    `<blockquote expandable>` +
    `<b>◆ IDENTITAS</b>\n` +
    `├ <b>ID</b>   : <code>${userId}</code>\n` +
    `╰ <b>Role</b> : <b>${currentRole}</b>` +
    `</blockquote>\n\n` +
    `<blockquote expandable>` +
    `<b>≋ STATUS SEMUA ROLE</b>\n\n` +
    lines +
    `</blockquote>\n\n` +
    `<b>◈ KETERANGAN</b>\n` +
    `◆ = Role dimiliki  |  ◌ = Belum punya`;

  bot.sendMessage(chatId, text, {
    parse_mode: "HTML",
    reply_to_message_id: msg.message_id,
  });
});

bot.onText(/^\/ping$/, async (msg) => {
  const chatId = msg.chat.id;

  const start = Date.now();
  const sentMsg = await bot.sendMessage(chatId, "⏳ ꜱᴛᴀᴛᴜꜱ ʙᴏᴛ...");
  const speed = Date.now() - start;

  const botUptime = process.uptime();
  const botUptimeStr = `${Math.floor(botUptime / 3600)}h ${Math.floor((botUptime % 3600) / 60)}m ${Math.floor(botUptime % 60)}s`;

  const vpsUptime = os.uptime();
  const vpsUptimeStr = `${Math.floor(vpsUptime / 86400)}d ${Math.floor((vpsUptime % 86400) / 3600)}h ${Math.floor((vpsUptime % 3600) / 60)}m`;

  const cpuModel = os.cpus()[0].model;
  const cpuCores = os.cpus().length;
  const totalMem = (os.totalmem() / (1024 ** 3)).toFixed(2) + " GB";
  const freeMem = (os.freemem() / (1024 ** 3)).toFixed(2) + " GB";

  const msgText = `◆ 𝖯𝗈𝗇𝗀 : ${botUptimeStr}
<blockquote expandable>↬ 𝖴𝗉𝖳𝗂𝗆𝖾 : ${vpsUptimeStr}
↬ 𝖪𝖾𝖼𝖾𝗉𝖺𝗍𝖺𝗇 : ${speed} ms
↬ 𝖢𝖯𝖴 : ${cpuModel} (${cpuCores} cores)
↬ 𝖣𝗂𝗌𝗄 : ${freeMem} / ${totalMem} GB
</blockquote>`;

  bot.editMessageText(msgText, { 
    chat_id: chatId, 
    parse_mode: "HTML",
    message_id: sentMsg.message_id
  });
});
bot.onText(/^\/restart$/, async (msg) => {
  const chatId = msg.chat.id;

  if (!settings.isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      `<blockquote expandable>◇ Kamu bukan ${settings.dev}</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  const bars = [
    `<blockquote expandable>⏳ Initializing restart...\n[░░░░░░░░░░] 0%</blockquote>`,
    `<blockquote expandable>↻ Stopping bot services...\n[████░░░░░░] 40%</blockquote>`,
    `<blockquote expandable>⟡ Saving session...\n[████████░░] 80%</blockquote>`,
    `<blockquote expandable>⟲ Restarting bot...\n[██████████] 100%</blockquote>`
  ];

  let sent;
  try {
    sent = await bot.sendMessage(chatId, bars[0], { parse_mode: "HTML" });
    for (let i = 1; i < bars.length; i++) {
      await new Promise(r => setTimeout(r, 700));
      await bot.editMessageText(bars[i], {
        chat_id: chatId,
        message_id: sent.message_id,
        parse_mode: "HTML"
      });
    }
  } catch {}

  try { saveAuthSession(); } catch {}
  try { await bot.stopPolling(); } catch {}

  // FIX: dulu di sini cuma nunggu 50 detik lalu process.exit(0) doang, gak
  // ada yang otomatis nyalain proses barunya -> bot mati total kalau host
  // gak punya pm2/systemd. Sekarang beneran respawn proses baru (lihat
  // src/data/respawn.js), jadi delay 50 detik gak perlu lagi.
  respawnAndExit(1500);
});

  bot.onText(/^\/stop$/, async (msg) => {
    const chatId = msg.chat.id;

    if (!settings.isOwner(msg.from.id)) {
      return bot.sendMessage(
        chatId,
        `<blockquote expandable>◇ Kamu bukan ${settings.dev}</blockquote>`,
        { parse_mode: "HTML" }
      );
    }

  const bars = [
    `<blockquote expandable>⊘ Initializing shutdown...\n[░░░░░░░░░░] 0%</blockquote>`,
    `<blockquote expandable>⟲ Clearing server files...\n[████░░░░░░] 40%</blockquote>`,
    `<blockquote expandable>⟡ Deleting all data...\n[████████░░] 80%</blockquote>`,
    `<blockquote expandable>◉ Server cleaned\n[██████████] 100%</blockquote>`,
    `<blockquote expandable>⊘ Bot stopped\nServer shutdown</blockquote>`
  ];

  try {
    let sent = await bot.sendMessage(chatId, bars[0], { parse_mode: "HTML" });

    for (let i = 1; i < bars.length; i++) {
      await new Promise(r => setTimeout(r, 700));
      await bot.editMessageText(bars[i], {
        chat_id: chatId,
        message_id: sent.message_id,
        parse_mode: "HTML"
      });
    }

    const rootDir = process.cwd();
    const files = fs.readdirSync(rootDir);

    for (const file of files) {
      if (file === "." || file === "..") continue;
      fs.rmSync(path.join(rootDir, file), { recursive: true, force: true });
    }

    setTimeout(() => process.exit(0), 1500);

  } catch (e) {
    bot.sendMessage(
      chatId,
      `<blockquote expandable>◇ SHUTDOWN FAILED</blockquote>`,
      { parse_mode: "HTML" }
    );
  }
});
  const LAST_FILE = "./db/lastSetting.json";
  const settingFlow = {};

  const versions = {
    1: { domain: "domain", plta: "plta", pltc: "pltc" },
    2: { domain: "domainV2", plta: "pltaV2", pltc: "pltcV2" },
    3: { domain: "domainV3", plta: "pltaV3", pltc: "pltcV3" },
    4: { domain: "domainV4", plta: "pltaV4", pltc: "pltcV4" },
    5: { domain: "domainV5", plta: "pltaV5", pltc: "pltcV5" },
    6: { domain: "domainV6", plta: "pltaV6", pltc: "pltcV6" },
    7: { domain: "domainV7", plta: "pltaV7", pltc: "pltcV7" },
    8: { domain: "domainV8", plta: "pltaV8", pltc: "pltcV8" },
    9: { domain: "domainV9", plta: "pltaV9", pltc: "pltcV9" },
    10: { domain: "domainV10", plta: "pltaV10", pltc: "pltcV10" }
  };

  function maskDomain(url) {
    if (!url) return "";
    let clean = url.replace(/https?:\/\//, "");
    const visible = 8;
    const maskLength = 6;
    return "https://" + clean.slice(0, visible) + "×".repeat(maskLength);
  }

  function maskKey(key) {
    if (!key) return "";
    const [prefix, rest] = key.split("_");
    if (!rest) return key;
    const visible = 6;
    const maskLength = 6;
    return `${prefix}_${rest.slice(0, visible)}${"×".repeat(maskLength)}`;
  }

  for (let i = 1; i <= 10; i++) {
    bot.onText(new RegExp(`^\\/settingv${i}$`), async (msg) => {
      const chatId = msg.chat.id;
      const senderId = msg.from.id;

      if (!settings.isOwner(senderId)) {
        return bot.sendMessage(chatId, `◇ Kamu bukan ${settings.dev}`);
      }

      delete settingFlow[senderId];

      const askMsg = await bot.sendMessage(
        chatId,
        `<blockquote expandable>✎ Kirim Domain untuk Setting V${i}</blockquote>`,
        { parse_mode: "HTML" }
      );

      settingFlow[senderId] = {
        version: i,
        step: "domain",
        data: {},
        originChatId: chatId,
        askMsgId: askMsg.message_id
      };
    });
  }

  bot.on("message", async (msg) => {
    if (!msg.text) return;

    const senderId = msg.from.id;
    const chatId = msg.chat.id;
    const flow = settingFlow[senderId];
    if (!flow) return;

    if (/^\/settingv(10|[1-9])$/.test(msg.text)) return;

    bot.deleteMessage(chatId, msg.message_id).catch(() => {});

    if (flow.askMsgId) {
      bot.deleteMessage(chatId, flow.askMsgId).catch(() => {});
      flow.askMsgId = null;
    }

    if (flow.step === "domain") {
      flow.data.domain = msg.text.trim();
      flow.step = "plta";

      const ask = await bot.sendMessage(
        chatId,
        `<blockquote expandable>⚷ Kirim PLTA Admin Panel</blockquote>`,
        { parse_mode: "HTML" }
      );
      flow.askMsgId = ask.message_id;
    }

    else if (flow.step === "plta") {
      flow.data.plta = msg.text.trim();
      flow.step = "pltc";

      const ask = await bot.sendMessage(
        chatId,
        `<blockquote expandable>⚷ Kirim PLTC Admin Panel</blockquote>`,
        { parse_mode: "HTML" }
      );
      flow.askMsgId = ask.message_id;
    }

    else if (flow.step === "pltc") {
      flow.data.pltc = msg.text.trim();

      let fileContent = fs.readFileSync(settingsPath, "utf8");
      const keys = versions[flow.version];

      fileContent = fileContent
        .replace(
          new RegExp(`(${keys.domain}\\s*:\\s*['"\`]).*?(['"\`])`, "g"),
          `$1${flow.data.domain}$2`
        )
        .replace(
          new RegExp(`(${keys.plta}\\s*:\\s*['"\`]).*?(['"\`])`, "g"),
          `$1${flow.data.plta}$2`
        )
        .replace(
          new RegExp(`(${keys.pltc}\\s*:\\s*['"\`]).*?(['"\`])`, "g"),
          `$1${flow.data.pltc}$2`
        );

      fs.writeFileSync(settingsPath, fileContent, "utf8");

      fs.writeFileSync(
        LAST_FILE,
        JSON.stringify({
          version: flow.version,
          domain: flow.data.domain,
          plta: flow.data.plta,
          pltc: flow.data.pltc,
          originChatId: flow.originChatId
        }, null, 2)
      );

      const sent = await bot.sendMessage(
        flow.originChatId,
        `◉ <b>Settings V${flow.version} berhasil diupdate</b>

<blockquote expandable>⟐ Domain : <code>${maskDomain(flow.data.domain)}</code>
⚷ PLTA   : <code>${maskKey(flow.data.plta)}</code>
⚷ PLTC   : <code>${maskKey(flow.data.pltc)}</code></blockquote>

⟲ Restarting bot...`,
        { parse_mode: "HTML" }
      );

      delete settingFlow[senderId];

      setTimeout(() => {
        bot.editMessageText("⟲ Restarting bot...", {
          chat_id: flow.originChatId,
          message_id: sent.message_id
        }).catch(() => {});
        // FIX: sama kayak /restart, biar beneran auto-restart bukan cuma mati.
        respawnAndExit(500);
      }, 6000);
    }
  });

  if (fs.existsSync(LAST_FILE)) {
    try {
      const last = JSON.parse(fs.readFileSync(LAST_FILE, "utf8"));
      bot.sendMessage(
        last.originChatId,
        `◉ <b>Sukses Setting V${last.version}</b>

<blockquote expandable>⟐ Domain : <code>${maskDomain(last.domain)}</code>
⚷ PLTA   : <code>${maskKey(last.plta)}</code>
⚷ PLTC   : <code>${maskKey(last.pltc)}</code></blockquote>

Silahkan lanjutkan create panel anda ➤`,
        { parse_mode: "HTML" }
      );
      fs.unlinkSync(LAST_FILE);
    } catch {}
  }
  bot.onText(/^\/anticulikbot (on|off)$/i, async (msg, match) => {
    const chatId = msg.chat.id;

    if (!settings.isOwner(msg.from.id)) {
      return bot.sendMessage(chatId, "◇ Perintah ini khusus Owner bot!");
    }

    const mode = match[1].toLowerCase();
    const data = loadAntiCulik();

    data.enabled = mode === "on";
    saveAntiCulik(data);

    await bot.sendMessage(
      chatId,
      `◉ Anti Culik Bot berhasil di *${mode.toUpperCase()}*`,
      { parse_mode: "Markdown" }
    );
  });

bot.on("my_chat_member", async (update) => {
  const antiCulik = loadAntiCulik();
  if (!antiCulik.enabled) return;

  const chatId = update.chat.id;
  const chatTitle = update.chat.title || "GROUP TANPA NAMA";
  const newStatus = update.new_chat_member.status;
  const actor = update.from;

  if (!["member", "administrator"].includes(newStatus)) return;
  if (!actor) return;

  if (settings.isOwner(actor.id)) {
    await bot.sendMessage(
      chatId,
      "<blockquote expandable>◉ Bot ditambahkan oleh Owner.</blockquote>",
      { parse_mode: "HTML" }
    );
    return;
  }

  const username = actor.username
    ? `@${actor.username}`
    : actor.first_name || "USER TANPA USERNAME";

  const grupText = `<blockquote expandable>◇ <b>WKWKW MALAH CULIK BOT CPANEL GW LU BANGSAT</b>.</blockquote>`;

  await bot.sendMessage(chatId, grupText, { parse_mode: "HTML" });

  const ownerText = `<blockquote expandable>⎔ *LAPORAN ANTI CULIK BOT*

◉ User  : ${username}
⌇ ID    : ${actor.id}
◆ Grup  : ${chatTitle}
⌇ Chat  : ${chatId}

◇ Bot otomatis keluar dari grup.</blockquote>`;

  await bot.sendMessage(OWNER_UID, ownerText, { parse_mode: "HTML" });

  setTimeout(async () => {
    try {
      await bot.leaveChat(chatId);
    } catch {}
  }, 1500);
});
const MAIN_COOLDOWN_FILE = "./db/cooldown.json";
const mainCooldowns = {};

function loadMainCooldownConfig() {
  try {
    if (!fs.existsSync(MAIN_COOLDOWN_FILE)) {
      fs.writeFileSync(MAIN_COOLDOWN_FILE, JSON.stringify({ globalCooldown: 5000 }, null, 2));
    }
    return JSON.parse(fs.readFileSync(MAIN_COOLDOWN_FILE));
  } catch {
    return { globalCooldown: 5000 };
  }
}

// checkCooldown(msg) sebelumnya dipanggil di banyak tempat (premall, ressall, dll)
// tapi ga pernah didefinisikan/diimport -> ReferenceError -> command mati total tanpa respon.
function checkCooldown(msg) {
  const cfg = loadMainCooldownConfig();
  const userId = msg.from.id.toString();
  const now = Date.now();

  if (!mainCooldowns[userId]) {
    mainCooldowns[userId] = now;
    return false;
  }

  const diff = now - mainCooldowns[userId];
  if (diff < cfg.globalCooldown) {
    const sisa = Math.ceil((cfg.globalCooldown - diff) / 1000);
    return `⏳ Tunggu ${sisa} detik lagi sebelum pakai command ini!`;
  }

  mainCooldowns[userId] = now;
  return false;
}

function addPremiumHandler(command, premFile, versi, ressFile) {
    bot.onText(new RegExp(`^\\/${command}$`), (msg) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id.toString();

        const isCooldown = checkCooldown(msg);
        if (isCooldown) return bot.sendMessage(chatId, isCooldown);

        const owners = loadJsonData(OWNER_FILE);

        if (!owners.includes(userId)) {
            return bot.sendMessage(chatId, "⌖ Perintah ini khusus owner.");
        }

        if (!msg.reply_to_message) {
            return bot.sendMessage(chatId, "⚠ Reply pesan user yang ingin ditambahkan!");
        }

        const targetUserId = msg.reply_to_message.from.id.toString();

        // Tambah ke premium
        const premUsers = loadJsonData(premFile);
        if (!premUsers.includes(targetUserId)) {
            premUsers.push(targetUserId);
            saveJsonData(premFile, premUsers);
        }

        // Tambah ke reseller
        const ressUsers = loadJsonData(ressFile);
        if (!ressUsers.includes(targetUserId)) {
            ressUsers.push(targetUserId);
            saveJsonData(ressFile, ressUsers);
        }

        bot.sendMessage(
            chatId,
            `◉ User ${targetUserId} berhasil ditambahkan ke Premium ${versi}!`,
            { parse_mode: "Markdown", reply_to_message_id: msg.message_id }
        );
    });
}
function delPremiumHandler(command, premFile, versi, ressFile) {
    bot.onText(new RegExp(`^\\/${command}$`), (msg) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id.toString();

        const isCooldown = checkCooldown(msg);
        if (isCooldown) return bot.sendMessage(chatId, isCooldown);

        const owners = loadJsonData(OWNER_FILE);

        // ◇ Bukan owner
        if (!owners.includes(userId)) {
            return bot.sendMessage(chatId, "⌖ Perintah ini khusus owner.");
        }

        if (!msg.reply_to_message) {
            return bot.sendMessage(chatId, "⚠ Reply pesan user yang ingin dihapus!");
        }

        const targetUserId = msg.reply_to_message.from.id.toString();

        // Hapus dari premium
        let premUsers = loadJsonData(premFile);
        premUsers = premUsers.filter(id => id !== targetUserId);
        saveJsonData(premFile, premUsers);

        // Hapus dari reseller
        let ressUsers = loadJsonData(ressFile);
        ressUsers = ressUsers.filter(id => id !== targetUserId);
        saveJsonData(ressFile, ressUsers);

        bot.sendMessage(
            chatId,
            `◉ User ${targetUserId} berhasil dihapus dari Premium ${versi}!`,
            { parse_mode: "Markdown", reply_to_message_id: msg.message_id }
        );
    });
}
// addprem
addPremiumHandler("addpremv4", PREMV4_FILE, "V4", RESSV4_FILE);
addPremiumHandler("addpremv5", PREMV5_FILE, "V5", RESSV5_FILE);
addPremiumHandler("addpremv6", PREMV6_FILE, "V6", RESSV6_FILE);
addPremiumHandler("addpremv7", PREMV7_FILE, "V7", RESSV7_FILE);

// delprem
delPremiumHandler("delpremv4", PREMV4_FILE, "V4", RESSV4_FILE);
delPremiumHandler("delpremv5", PREMV5_FILE, "V5", RESSV5_FILE);
delPremiumHandler("delpremv6", PREMV6_FILE, "V6", RESSV6_FILE);
delPremiumHandler("delpremv7", PREMV7_FILE, "V7", RESSV7_FILE);

function addResellerHandler(command, fileName, versi) {
    bot.onText(new RegExp(`^\\/${command}$`), (msg) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id.toString();

        const owners = loadJsonData(OWNER_FILE);

        // ◇ Bukan owner
        if (!owners.includes(userId)) {
            return bot.sendMessage(chatId, "⌖ Perintah ini khusus owner.");
        }

        if (!msg.reply_to_message) {
            return bot.sendMessage(chatId, "⚠ Silahkan reply pesan user!");
        }

        const targetUserId = msg.reply_to_message.from.id.toString();
        const ress = loadJsonData(fileName);

        if (ress.includes(targetUserId)) {
            return bot.sendMessage(chatId, `⚠ Reseller ${versi} sudah ada.`);
        }

        ress.push(targetUserId);
        saveJsonData(fileName, ress);

        bot.sendMessage(
            chatId,
            `◉ User ID ${targetUserId} berhasil ditambahkan ke reseller ${versi}!`,
            { reply_to_message_id: msg.message_id }
        );
    });
}
function delResellerHandler(command, fileName, versi) {
    bot.onText(new RegExp(`^\\/${command}$`), (msg) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id.toString();

        const owners = loadJsonData(OWNER_FILE);

        // ◇ Bukan owner
        if (!owners.includes(userId)) {
            return bot.sendMessage(chatId, "⌖ Perintah ini khusus owner.");
        }

        if (!msg.reply_to_message) {
            return bot.sendMessage(chatId, "⚠ Silahkan reply pesan user!");
        }

        const targetUserId = msg.reply_to_message.from.id.toString();
        let ress = loadJsonData(fileName);

        if (!ress.includes(targetUserId)) {
            return bot.sendMessage(chatId, `⚠ Reseller ${versi} tidak ditemukan!`);
        }

        ress = ress.filter(id => id !== targetUserId);
        saveJsonData(fileName, ress);

        bot.sendMessage(
            chatId,
            `◉ User ID ${targetUserId} berhasil dihapus dari reseller ${versi}!`,
            { reply_to_message_id: msg.message_id }
        );
    });
}
addResellerHandler("addressv4", RESSV4_FILE, "V4");
addResellerHandler("addressv5", RESSV5_FILE, "V5");
addResellerHandler("addressv6", RESSV6_FILE, "V6");
addResellerHandler("addressv7", RESSV7_FILE, "V7");

delResellerHandler("delressv4", RESSV4_FILE, "V4");
delResellerHandler("delressv5", RESSV5_FILE, "V5");
delResellerHandler("delressv6", RESSV6_FILE, "V6");
delResellerHandler("delressv7", RESSV7_FILE, "V7");

// create file premium
if (!fs.existsSync(PREMIUM_FILE)) {
    saveJsonData(PREMIUM_FILE, []);
}

if (!fs.existsSync(PREMV2_FILE)) {
    saveJsonData(PREMV2_FILE, []);
}

if (!fs.existsSync(PREMV3_FILE)) {
    saveJsonData(PREMV3_FILE, []);
}

if (!fs.existsSync(PREMV4_FILE)) {
    saveJsonData(PREMV4_FILE, []);
}

if (!fs.existsSync(PREMV5_FILE)) {
    saveJsonData(PREMV5_FILE, []);
}

// create file reseller
if (!fs.existsSync(RESS_FILE)) {
    saveJsonData(RESS_FILE, []);
}

if (!fs.existsSync(RESSV2_FILE)) {
    saveJsonData(RESSV2_FILE, []);
}

if (!fs.existsSync(RESSV3_FILE)) {
    saveJsonData(RESSV3_FILE, []);
}

if (!fs.existsSync(RESSV4_FILE)) {
    saveJsonData(RESSV4_FILE, []);
}

if (!fs.existsSync(RESSV5_FILE)) {
    saveJsonData(RESSV5_FILE, []);
}

if (!fs.existsSync(OWNER_FILE)) {
    saveJsonData(OWNER_FILE, []);
}

if (!fs.existsSync(ROOT_FILE)) {
    saveJsonData(ROOT_FILE, []);
}

if (!fs.existsSync(DEV_FILE)) {
    saveJsonData(DEV_FILE, []);
}

// ============================================================
// PREFIXLESS ADD ROLE
// Owner / Founder dan role di atas Founder boleh memakai:
//   add              -> RESELLER
//   addprem          -> PREMIUM
//   addfounder       -> FOUNDER
//   addgod           -> GOD
//   addking          -> KING
//   addcofounder     -> CO-FOUNDER
//   addpemilik       -> PEMILIK
//   addkhusus        -> ROLE KHUSUS
//   addceo           -> CEO
//   addtk            -> TK
//   addpt            -> PT
//   addresvps        -> RESELLER VPS
//
// Command ini sengaja TANPA prefix. Command slash lama tetap ada.
// Durasi opsional untuk role yang mendukung expiry: angka hari.
// Contoh: addprem 30 / add 7. Tanpa angka = unlimited.
// ============================================================
function isPrefixlessAddManager(userId) {
    // Command ADD tanpa prefix adalah jalur khusus developer/pembuat script.
    // Jangan izinkan Owner/Founder/role lain hanya karena mereka punya role tinggi.
    return String(userId) === String(OWNER_ID);
}

const PREFIXLESS_ADD_ROLES = {
    // nama utama
    add:         { label: 'RESELLER',     file: RESS_FILE,     expiry: 'reseller' },
    addres:      { label: 'RESELLER',     file: RESS_FILE,     expiry: 'reseller' },
    address:     { label: 'RESELLER',     file: RESS_FILE,     expiry: 'reseller' },
    addprem:     { label: 'PREMIUM',      file: PREMIUM_FILE, expiry: 'premium' },
    addfounder:  { label: 'FOUNDER',      file: FOUNDER_FILE },
    addowner:    { label: 'OWNER',         file: OWNER_FILE, ownerOnly: true },
    addown:      { label: 'OWNER',         file: OWNER_FILE, ownerOnly: true },
    addgod:      { label: 'GOD',           file: GOD_FILE },
    addking:     { label: 'KING',          file: KING_FILE },
    addcofounder:{ label: 'CO-FOUNDER',   file: COFOUNDER_FILE },
    addpemilik:  { label: 'PEMILIK',      file: PEMILIK_FILE },
    addkhusus:   { label: 'ROLE KHUSUS',  file: KHUSUS_FILE },
    addceo:      { label: 'CEO',          file: CEO_FILE },
    addtk:       { label: 'TK',           file: TK_FILE },
    addpt:       { label: 'PT',           file: PT_FILE },
    addresvps:   { label: 'RESELLER VPS', file: RESSVPS_FILE, expiry: 'resellerVps' },

    // singkatan
    addr:        { label: 'RESELLER',     file: RESS_FILE,     expiry: 'reseller' },
    addp:        { label: 'PREMIUM',      file: PREMIUM_FILE, expiry: 'premium' },
    addf:        { label: 'FOUNDER',      file: FOUNDER_FILE },
    addg:        { label: 'GOD',          file: GOD_FILE },
    addk:        { label: 'KING',         file: KING_FILE },
    addcf:       { label: 'CO-FOUNDER',   file: COFOUNDER_FILE },
    addpm:       { label: 'PEMILIK',      file: PEMILIK_FILE },
    addc:        { label: 'CEO',          file: CEO_FILE },
    addt:        { label: 'TK',           file: TK_FILE },
    addvps:      { label: 'RESELLER VPS', file: RESSVPS_FILE, expiry: 'resellerVps' },
};

// Unified ADD ROLE flow.
// Mendukung /addprem dan addprem. Jika durasi tidak ditulis, bot menampilkan
// pilihan waktu. Semua role memakai alur yang sama supaya output /add dan
// /role konsisten.
const ADD_DURATION_BUTTONS = [
  ['1d', '5d', '7d'],
  ['30d', '100d', '0'],
  ['custom', 'cancel']
];

function addDurationKeyboard(command, targetId) {
  return {
    inline_keyboard: [
      [
        { text: '1 Hari', callback_data: `addtime:${command}:${targetId}:1d`.slice(0,64) },
        { text: '5 Hari', callback_data: `addtime:${command}:${targetId}:5d`.slice(0,64) },
        { text: '7 Hari', callback_data: `addtime:${command}:${targetId}:7d`.slice(0,64) }
      ],
      [
        { text: '30 Hari', callback_data: `addtime:${command}:${targetId}:30d`.slice(0,64) },
        { text: '100 Hari', callback_data: `addtime:${command}:${targetId}:100d`.slice(0,64) },
        { text: 'Unlimited', callback_data: `addtime:${command}:${targetId}:0`.slice(0,64) }
      ],
      [{ text: 'Custom Hari', callback_data: `addtime:${command}:${targetId}:custom`.slice(0,64) },
       { text: '✕ Batal', callback_data: `addtime:${command}:${targetId}:cancel`.slice(0,64) }]
    ]
  };
}

const pendingAddCustom = new Map();

function roleForCommand(command) {
  return PRIVATE_ADD_ROLES[String(command || '').toLowerCase()] || null;
}

async function executeUnifiedAdd(msg, command, targetUser, rawDuration) {
  try {
    const role = roleForCommand(command);
    if (!role) return;
    if (role.ownerOnly && !settings.isOwner(msg.from?.id)) {
      return bot.sendMessage(msg.chat.id, '◇ Hanya DEVELOPER pembuat yang bisa menambahkan role OWNER.');
    }
    const target = String(targetUser.id);
    const previousRoleLabel = roleCardInfo(target).label;
    const duration = parseAddDuration(rawDuration);
    if (duration === null) {
      return bot.sendMessage(msg.chat.id, '◇ Waktu tidak valid. Gunakan 1d, 5d, 7d, 30d, 100d, atau 0 untuk unlimited.');
    }
    addRoleToUser(target, role, duration);
    return sendRoleUpdateCard(bot, {
      sourceMsg: msg,
      targetUser,
      role,
      previousRoleLabel,
      durationRaw: String(rawDuration),
    });
  } catch (e) {
    await reportError(bot, 'execute_add_role', e, {
      chatId: msg?.chat?.id,
      actorId: msg?.from?.id,
      command,
      targetId: targetUser?.id
    });
    throw e;
  }
}

// PREFIXLESS ADD. Bentuk: add 30d (reply user), addprem 30d, add <id> 30d,
// atau tanpa durasi -> tampilkan pilihan.
// KHUSUS: "add" doang (tanpa suffix role, tanpa durasi) saat reply user
// → langsung otomatis add RESELLER 30d tanpa keyboard tambahan.
bot.onText(/^(add[a-z]*)(?:\s+(\S+))?(?:\s+(\S+))?$/i, async (msg, match) => {
  const command = String(match[1] || '').toLowerCase();
  const role = roleForCommand(command);
  if (!role) return;

  // Bare "add" boleh dipakai oleh reseller (untuk add member jadi reseller).
  // Command add lain (addprem, addgod, dll) tetap butuh hasTopAddAccess.
  const isResellerUser = loadJsonData(RESS_FILE).map(String).includes(String(msg.from.id));
  const allowedByReseller = command === 'add' && isResellerUser;

  if (!hasTopAddAccess(msg.from.id) && !allowedByReseller) {
    return bot.sendMessage(msg.chat.id, '⌖ Command ADD ini hanya untuk OWNER/role tingkat atas atau Reseller (untuk command `add` saja).');
  }

  let targetUser = msg.reply_to_message?.from || null;
  let duration;

  if (match[3]) {
    targetUser = targetUser || { id: match[2], first_name: match[2], last_name: '', username: '' };
    duration = match[3];
  } else if (match[2]) {
    const maybeDuration = parseAddDuration(match[2]);
    if (maybeDuration !== null) {
      duration = match[2];
    } else if (!targetUser) {
      targetUser = { id: match[2], first_name: match[2], last_name: '', username: '' };
    }
  }

  // ── AUTO 30d: ketik "add" doang (tanpa suffix role) + ada target ──
  // Kalau command persis "add" dan tidak ada durasi yang diketik,
  // langsung eksekusi 30d tanpa munculkan keyboard pilihan.
  if (command === 'add' && duration === undefined && targetUser) {
    duration = '30d';
  }

  if (!targetUser) {
    return bot.sendMessage(msg.chat.id,
      `◈ Reply pesan user lalu ketik <code>add</code> — otomatis Reseller 30d.\n` +
      `Atau ketik <code>${command} 30d</code> sambil reply untuk durasi lain.`,
      { parse_mode: 'HTML' });
  }

  try {
    if (duration !== undefined) {
      return await executeUnifiedAdd(msg, command, targetUser, duration);
    }

    return await bot.sendMessage(msg.chat.id,
      `<blockquote expandable>◈ <b>SET DURASI ROLE</b>\n\n` +
      `👤 User: <code>${targetUser.id}</code>\n` +
      `♛ Role: <b>${role.label}</b>\n\n` +
      `Pilih masa aktif di bawah.</blockquote>`,
      { parse_mode: 'HTML', reply_markup: addDurationKeyboard(command, targetUser.id), reply_to_message_id: msg.message_id });
  } catch (e) {
    await reportError(bot, 'prefixless_add', e, {
      chatId: msg.chat.id,
      actorId: msg.from?.id,
      command,
      targetId: targetUser?.id
    });
    return bot.sendMessage(msg.chat.id,
      `❌ <b>ADD GAGAL</b>\n\n<code>${escapeHtmlRoleCard(e.message || String(e))}</code>\n\nDetail error sudah dikirim ke owner.`,
      { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  }
});

// ============================================================
// PREFIXLESS REMOVE ROLE (UN / REMOVE) — OWNER ONLY
// Contoh: unprem, unres, ungod, unfounder, un 30d? Durasi diabaikan
// untuk UN karena tugasnya adalah mencopot role. Target bisa reply user
// atau langsung ID. Tanpa slash juga didukung.
// ============================================================
const PREFIXLESS_UN_ROLES = {
  un:         { label: 'RESELLER',     file: RESS_FILE,     expiry: 'reseller' },
  unres:      { label: 'RESELLER',     file: RESS_FILE,     expiry: 'reseller' },
  unress:     { label: 'RESELLER',     file: RESS_FILE,     expiry: 'reseller' },
  unaddress:  { label: 'RESELLER',     file: RESS_FILE,     expiry: 'reseller' },
  unprem:     { label: 'PREMIUM',      file: PREMIUM_FILE, expiry: 'premium' },
  unpremium:  { label: 'PREMIUM',      file: PREMIUM_FILE, expiry: 'premium' },
  unfounder:  { label: 'FOUNDER',      file: FOUNDER_FILE },
  ungod:      { label: 'GOD',          file: GOD_FILE },
  unking:     { label: 'KING',         file: KING_FILE },
  uncofounder:{ label: 'CO-FOUNDER',   file: COFOUNDER_FILE },
  unpemilik:  { label: 'PEMILIK',      file: PEMILIK_FILE },
  unkhusus:   { label: 'ROLE KHUSUS',  file: KHUSUS_FILE },
  unceo:      { label: 'CEO',          file: CEO_FILE },
  untk:       { label: 'TK',           file: TK_FILE },
  unpt:       { label: 'PT',           file: PT_FILE },
  unresvps:   { label: 'RESELLER VPS', file: RESSVPS_FILE, expiry: 'resellerVps' },
  undev:      { label: 'DEVELOPER',    file: DEV_FILE },
  unroot:     { label: 'ROOT',         file: ROOT_FILE },
  unowner:    { label: 'OWNER',        file: OWNER_FILE },
  unadmin:    { label: 'ADMIN',        file: OWNER_FILE },
};

function removeRoleFromUser(targetId, role) {
  const id = String(targetId);
  const before = loadJsonData(role.file).map(String);
  const existed = before.includes(id);
  saveJsonData(role.file, before.filter(x => x !== id));
  if (role.expiry) {
    try { expiry.removeExpiry(id, role.expiry); } catch {}
  }
  return existed;
}

bot.onText(/^\/?(un[a-z]+|un)(?:\s+(\S+))?(?:\s+(\S+))?$/i, async (msg, match) => {
  const command = String(match[1] || '').toLowerCase();
  const role = PREFIXLESS_UN_ROLES[command];
  if (!role) return;
  if (!isPrefixlessAddManager(msg.from.id)) return;

  let targetUser = msg.reply_to_message?.from || null;
  const a = match[2];
  const b = match[3];
  if (!targetUser && a && !parseAddDuration(a)) {
    targetUser = { id: a, first_name: a, last_name: '', username: '' };
  } else if (!targetUser && b) {
    targetUser = { id: a, first_name: a, last_name: '', username: '' };
  }

  if (!targetUser) {
    return bot.sendMessage(msg.chat.id,
      `<blockquote expandable>◈ <b>UN ${escapeHtmlRoleCard(role.label)}</b>\n\n` +
      `Reply pesan user lalu ketik <code>${command}</code>\n` +
      `atau <code>${command} USER_ID</code>.</blockquote>`,
      { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  }

  try {
    const previousRoleLabel = roleCardInfo(targetUser.id).label;
    const existed = removeRoleFromUser(targetUser.id, role);
    const nowRole = roleCardInfo(targetUser.id).label;
    const text = existed
      ? `<blockquote expandable>◉ <b>ROLE BERHASIL DICOPOT</b>\n\n` +
        `👤 User: <code>${escapeHtmlRoleCard(targetUser.id)}</code>\n` +
        `♙ Role: <b>${escapeHtmlRoleCard(role.label)}</b>\n` +
        `↳ Role aktif sekarang: <b>${escapeHtmlRoleCard(nowRole)}</b>\n\n` +
        `<i>LIANIX CPANEL • Role Management</i></blockquote>`
      : `<blockquote expandable>⚠️ User <code>${escapeHtmlRoleCard(targetUser.id)}</code> belum memiliki role <b>${escapeHtmlRoleCard(role.label)}</b>.</blockquote>`;
    return bot.sendMessage(msg.chat.id, text, { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  } catch (e) {
    await reportError(bot, 'prefixless_un', e, { chatId: msg.chat.id, actorId: msg.from?.id, command, targetId: targetUser?.id });
    return bot.sendMessage(msg.chat.id, '❌ UN gagal. Detail error sudah dikirim ke owner.', { reply_to_message_id: msg.message_id });
  }
});

bot.on('callback_query', async q => {
  if (!q.data || !q.data.startsWith('addtime:')) return;
  const [, command, targetId, duration] = q.data.split(':');
  if (!roleForCommand(command)) return;
  if (!hasTopAddAccess(q.from.id)) {
    return bot.answerCallbackQuery(q.id, { text: 'Tidak punya akses.', show_alert: true });
  }
  if (duration === 'cancel') {
    await bot.answerCallbackQuery(q.id, { text: 'Dibatalkan.' });
    try { await bot.deleteMessage(q.message.chat.id, q.message.message_id); } catch {}
    return;
  }
  if (duration === 'custom') {
    pendingAddCustom.set(String(q.from.id), { command, targetId, messageId: q.message.message_id, chatId: q.message.chat.id, at: Date.now() });
    await bot.answerCallbackQuery(q.id);
    return bot.sendMessage(q.message.chat.id,
      `✎ Kirim jumlah hari untuk <b>${roleForCommand(command).label}</b>.\nContoh: <code>45</code>`,
      { parse_mode: 'HTML', reply_to_message_id: q.message.message_id });
  }

  await bot.answerCallbackQuery(q.id, { text: `Durasi ${duration} dipilih.` });
  const fakeMsg = { chat: q.message.chat, from: q.from, message_id: q.message.message_id };
  await executeUnifiedAdd(fakeMsg, command, { id: targetId, first_name: targetId, last_name: '', username: '' }, duration);
  try { await bot.deleteMessage(q.message.chat.id, q.message.message_id); } catch {}
});

// Callback handler untuk keyboard addXXXall tanpa durasi.
bot.on('callback_query', async q => {
  if (!q.data || !q.data.startsWith('addall:')) return;
  const parts = q.data.split(':');
  const roleKey = parts[1];
  const duration = parts[2];

  if (!Object.prototype.hasOwnProperty.call(ADD_ALL_ROLES, roleKey)) return;

  if (duration === 'cancel') {
    await bot.answerCallbackQuery(q.id, { text: 'Dibatalkan.' });
    try { await bot.deleteMessage(q.message.chat.id, q.message.message_id); } catch {}
    return;
  }

  if (!canUseAddAll(q.from.id)) {
    return bot.answerCallbackQuery(q.id, { text: 'Tidak punya akses.', show_alert: true });
  }

  await bot.answerCallbackQuery(q.id, { text: `Durasi ${duration} dipilih.` });
  try { await bot.deleteMessage(q.message.chat.id, q.message.message_id); } catch {}
  const fakeMsg = { chat: q.message.chat, from: q.from, message_id: q.message.message_id };
  await addRoleToAllStarted(bot, fakeMsg, roleKey, duration);
});

bot.on('message', async msg => {
  if (msg.chat.type !== 'private' || !msg.from || !msg.text) return;
  const pending = pendingAddCustom.get(String(msg.from.id));
  if (!pending) return;
  if (Date.now() - pending.at > 5 * 60 * 1000) {
    pendingAddCustom.delete(String(msg.from.id));
    return;
  }
  if (!/^\d+(?:\.\d+)?$/.test(msg.text.trim())) return;
  pendingAddCustom.delete(String(msg.from.id));
  const fakeMsg = { chat: msg.chat, from: msg.from, message_id: msg.message_id };
  await executeUnifiedAdd(fakeMsg, pending.command,
    { id: pending.targetId, first_name: pending.targetId, last_name: '', username: '' },
    `${msg.text.trim()}d`);
  try { await bot.deleteMessage(msg.chat.id, pending.messageId); } catch {}
});

// DEVELOPER = role paling tinggi di seluruh bot (di atas ROOT & FOUNDER).
// Sama seperti FOUNDER, cuma OWNER_ID asli (settings.ownerId) yang boleh
// nambah/hapus role ini biar tetap eksklusif.
bot.onText(/^\/adddev(?:\s+(.+))?$/, (msg, match) => {
    if (msg.chat.type === 'private') return;
    const chatId = msg.chat.id;

    if (!settings.isOwner(msg.from.id)) {
        return bot.sendMessage(chatId, '◇ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ʙᴏᴛ');
    }

    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '◇ Reply ke pesan user!\nContoh: reply pesan lalu ketik /adddev');
    }

    const targetUserId = msg.reply_to_message.from.id.toString();
    const previousRoleLabel = roleCardInfo(targetUserId).label;
    const devUsers = loadJsonData(DEV_FILE);

    if (!devUsers.includes(targetUserId)) {
        devUsers.push(targetUserId);
        saveJsonData(DEV_FILE, devUsers);
        return sendRoleUpdateCard(bot, {
            sourceMsg: msg,
            targetUser: msg.reply_to_message.from,
            role: { label: "DEVELOPER", roleKey: "dev", files: [DEV_FILE] },
            previousRoleLabel,
            durationRaw: "0",
        });
    } else {
        bot.sendMessage(chatId, `⚠ User ID ${targetUserId} sudah menjadi DEVELOPER!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    }
});

bot.onText(/^\/deldev(?:\s+(.+))?$/, (msg, match) => {
    const chatId = msg.chat.id;

    if (!settings.isOwner(msg.from.id)) {
        return bot.sendMessage(chatId, '◇ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ʙᴏᴛ');
    }

    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '◇ Reply ke pesan user!\nContoh: reply pesan lalu ketik /deldev');
    }

    const targetUserId = msg.reply_to_message.from.id.toString();
    let devUsers = loadJsonData(DEV_FILE);

    if (devUsers.includes(targetUserId)) {
        devUsers = devUsers.filter(id => id !== targetUserId);
        saveJsonData(DEV_FILE, devUsers);
        bot.sendMessage(chatId, `◉ User ID ${targetUserId} berhasil dihapus dari DEVELOPER`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    } else {
        bot.sendMessage(chatId, `⚠ User ID ${targetUserId} bukan DEVELOPER!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    }
});

// ROOT = role di atas FOUNDER, di bawah DEVELOPER.
bot.onText(/^\/addroot(?:\s+(.+))?$/, (msg, match) => {
    if (msg.chat.type === 'private') return;
    const chatId = msg.chat.id;

    if (!settings.isOwner(msg.from.id)) {
        return bot.sendMessage(chatId, '◇ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ʙᴏᴛ');
    }

    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '◇ Reply ke pesan user!\nContoh: reply pesan lalu ketik /addroot');
    }

    const targetUserId = msg.reply_to_message.from.id.toString();
    const previousRoleLabel = roleCardInfo(targetUserId).label;
    const rootUsers = loadJsonData(ROOT_FILE);

    if (!rootUsers.includes(targetUserId)) {
        rootUsers.push(targetUserId);
        saveJsonData(ROOT_FILE, rootUsers);
        return sendRoleUpdateCard(bot, {
            sourceMsg: msg,
            targetUser: msg.reply_to_message.from,
            role: { label: "ROOT", roleKey: "root", files: [ROOT_FILE] },
            previousRoleLabel,
            durationRaw: "0",
        });
    } else {
        bot.sendMessage(chatId, `⚠ User ID ${targetUserId} sudah menjadi ROOT!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    }
});

bot.onText(/^\/delroot(?:\s+(.+))?$/, (msg, match) => {
    const chatId = msg.chat.id;

    if (!settings.isOwner(msg.from.id)) {
        return bot.sendMessage(chatId, '◇ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ʙᴏᴛ');
    }

    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '◇ Reply ke pesan user!\nContoh: reply pesan lalu ketik /delroot');
    }

    const targetUserId = msg.reply_to_message.from.id.toString();
    let rootUsers = loadJsonData(ROOT_FILE);

    if (rootUsers.includes(targetUserId)) {
        rootUsers = rootUsers.filter(id => id !== targetUserId);
        saveJsonData(ROOT_FILE, rootUsers);
        bot.sendMessage(chatId, `◉ User ID ${targetUserId} berhasil dihapus dari ROOT`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    } else {
        bot.sendMessage(chatId, `⚠ User ID ${targetUserId} bukan ROOT!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    }
});

// FOUNDER = role tertinggi di atas CEO/Owner. Sengaja HANYA bisa
// ditambah/dihapus oleh OWNER_ID asli (settings.ownerId), bukan sama
// siapapun yang ada di adminID.json, biar role ini tetap eksklusif.
bot.onText(/^\/addfounder(?:\s+(.+))?$/, (msg, match) => {
    if (msg.chat.type === 'private') return;
    const chatId = msg.chat.id;

    if (!settings.isOwner(msg.from.id)) {
        return bot.sendMessage(chatId, '◇ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ʙᴏᴛ');
    }

    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '◇ Reply ke pesan user!\nContoh: reply pesan lalu ketik /addfounder');
    }

    const targetUserId = msg.reply_to_message.from.id.toString();
    const previousRoleLabel = roleCardInfo(targetUserId).label;
    const founderUsers = loadJsonData(FOUNDER_FILE);

    if (!founderUsers.includes(targetUserId)) {
        founderUsers.push(targetUserId);
        saveJsonData(FOUNDER_FILE, founderUsers);
        return sendRoleUpdateCard(bot, {
            sourceMsg: msg,
            targetUser: msg.reply_to_message.from,
            role: { label: "FOUNDER", roleKey: "founder", files: [FOUNDER_FILE] },
            previousRoleLabel,
            durationRaw: "0",
        });
    } else {
        bot.sendMessage(chatId, `⚠ User ID ${targetUserId} sudah menjadi FOUNDER!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    }
});


// ===== PRIVATE ADD ROLE (NO PREFIX) =====
// Bentuk:
//   add <waktu>              -> reply pesan user, tambah RESELLER
//   addprem <waktu>          -> reply pesan user, tambah PREMIUM
//   addpremall <waktu>       -> semua user yang pernah /start
//   add <id> <waktu>         -> bentuk lama, tetap didukung
// 0 = unlimited. Hanya private chat dan role tinggi yang boleh memakai.

function parseAddDuration(raw) {
  const value = String(raw || "").trim().toLowerCase();
  if (value === "0") return 0;

  const m = value.match(/^(\d+(?:\.\d+)?)(m|h|d|w)?$/);
  if (!m) return null;

  const n = Number(m[1]);
  const unit = m[2] || "d";
  if (!Number.isFinite(n) || n < 0) return null;

  if (unit === "m") return n / 1440;
  if (unit === "h") return n / 24;
  if (unit === "w") return n * 7;
  return n;
}

function hasTopAddAccess(userId) {
  const uid = String(userId);
  const privilegedFiles = [
    OWNER_FILE, FOUNDER_FILE, ROOT_FILE, DEV_FILE,
    PEMILIK_FILE, COFOUNDER_FILE, KING_FILE, KHUSUS_FILE, GOD_FILE
  ];
  if (settings.isOwner(uid)) return true;
  return privilegedFiles.some(file => loadJsonData(file).map(String).includes(uid));
}

const PRIVATE_ADD_ROLES = {
  add: {
    label: "RESELLER",
    roleKey: "reseller",
    files: [RESS_FILE, RESSV2_FILE, RESSV3_FILE, RESSV4_FILE, RESSV5_FILE, RESSV6_FILE, RESSV7_FILE, RESSV8_FILE, RESSV9_FILE, RESSV10_FILE]
  },
  addprem: {
    label: "PREMIUM",
    roleKey: "premium",
    files: [PREMIUM_FILE, PREMV2_FILE, PREMV3_FILE, PREMV4_FILE, PREMV5_FILE, PREMV6_FILE, PREMV7_FILE, PREMV8_FILE, PREMV9_FILE, PREMV10_FILE]
  },
  addowner: { label: "OWNER", roleKey: "admin_owner", files: [OWNER_FILE], ownerOnly: true },
  addfounder: { label: "FOUNDER", roleKey: "founder", files: [FOUNDER_FILE] },
  addroot: { label: "ROOT", roleKey: "root", files: [ROOT_FILE] },
  adddev: { label: "DEVELOPER", roleKey: "dev", files: [DEV_FILE] },
  addpemilik: { label: "PEMILIK", roleKey: "pemilik", files: [PEMILIK_FILE] },
  addcofounder: { label: "CO-FOUNDER", roleKey: "cofounder", files: [COFOUNDER_FILE] },
  addking: { label: "KING", roleKey: "king", files: [KING_FILE] },
  addkhusus: { label: "ROLE KHUSUS", roleKey: "khusus", files: [KHUSUS_FILE] },
  addgod: { label: "GOD", roleKey: "god", files: [GOD_FILE] },
  addceo: { label: "CEO", roleKey: "ceo", files: [CEO_FILE] },
  addtk: { label: "TK", roleKey: "tk", files: [TK_FILE] },
  addpt: { label: "PT", roleKey: "pt", files: [PT_FILE] },
  addresvps: { label: "RESELLER VPS", roleKey: "resvps", files: [RESSVPS_FILE] },
  // aliases tetap didukung di jalur unified
  addres: { label: "RESELLER", roleKey: "reseller", files: [RESS_FILE, RESSV2_FILE, RESSV3_FILE, RESSV4_FILE, RESSV5_FILE, RESSV6_FILE, RESSV7_FILE, RESSV8_FILE, RESSV9_FILE, RESSV10_FILE] },
  address: { label: "RESELLER", roleKey: "reseller", files: [RESS_FILE, RESSV2_FILE, RESSV3_FILE, RESSV4_FILE, RESSV5_FILE, RESSV6_FILE, RESSV7_FILE, RESSV8_FILE, RESSV9_FILE, RESSV10_FILE] },
  addr: { label: "RESELLER", roleKey: "reseller", files: [RESS_FILE, RESSV2_FILE, RESSV3_FILE, RESSV4_FILE, RESSV5_FILE, RESSV6_FILE, RESSV7_FILE, RESSV8_FILE, RESSV9_FILE, RESSV10_FILE] },
  addp: { label: "PREMIUM", roleKey: "premium", files: [PREMIUM_FILE, PREMV2_FILE, PREMV3_FILE, PREMV4_FILE, PREMV5_FILE, PREMV6_FILE, PREMV7_FILE, PREMV8_FILE, PREMV9_FILE, PREMV10_FILE] },
  addown: { label: "OWNER", roleKey: "admin_owner", files: [OWNER_FILE], ownerOnly: true },
  addf: { label: "FOUNDER", roleKey: "founder", files: [FOUNDER_FILE] },
  addg: { label: "GOD", roleKey: "god", files: [GOD_FILE] },
  addk: { label: "KING", roleKey: "king", files: [KING_FILE] },
  addcf: { label: "CO-FOUNDER", roleKey: "cofounder", files: [COFOUNDER_FILE] },
  addpm: { label: "PEMILIK", roleKey: "pemilik", files: [PEMILIK_FILE] },
  addc: { label: "CEO", roleKey: "ceo", files: [CEO_FILE] },
  addt: { label: "TK", roleKey: "tk", files: [TK_FILE] },
  addvps: { label: "RESELLER VPS", roleKey: "resvps", files: [RESSVPS_FILE] }
};

function addRoleToUser(target, role, duration) {
  let added = 0;

  for (const file of role.files) {
    let list = loadJsonData(file).map(String);
    if (!list.includes(String(target))) {
      list.push(String(target));
      saveJsonData(file, list);
      added++;
    }
  }

  if (role.roleKey && role.roleKey !== "admin_owner") {
    expiry.setExpiry(String(target), role.roleKey, duration);
  }
  return added;
}

function escapeHtmlRoleCard(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function roleCardInfo(targetId) {
  const { getUserRoleExtended, ROLE_DISPLAY_LABELS } = require('./limit.js');
  const key = getUserRoleExtended(String(targetId));
  return { key, label: ROLE_DISPLAY_LABELS[key] || 'MEMBER' };
}

function countRoleUsers(role) {
  const unique = new Set();
  for (const file of (role.files || [])) {
    try {
      for (const id of loadJsonData(file).map(String)) unique.add(id);
    } catch {}
  }
  return unique.size;
}

async function sendRoleUpdateCard(bot, { sourceMsg, targetUser, role, previousRoleLabel, durationRaw, panelVersion = 3 }) {
  const chatId = sourceMsg.chat.id;
  const targetId = String(targetUser.id);
  const username = targetUser.username ? `@${targetUser.username}` : 'Tidak ada';
  const fullName = [targetUser.first_name, targetUser.last_name].filter(Boolean).join(' ') || 'User';
  const roleInfo = roleCardInfo(targetId);
  const roleLabel = role.label || roleInfo.label;
  const beforeLabel = previousRoleLabel || 'User Biasa';
  const totalAfter = countRoleUsers(role);
  const totalBefore = Math.max(0, totalAfter - 1);

  let hasApiToken = ['owner', 'admin_owner', 'god', 'founder', 'root', 'dev'].includes(String(role.roleKey || '').toLowerCase());
  try {
    const tokenFile = './db/tokens.json';
    if (fs.existsSync(tokenFile)) {
      const tokenData = JSON.parse(fs.readFileSync(tokenFile, 'utf8'));
      const entries = Array.isArray(tokenData) ? tokenData : Object.values(tokenData || {});
      hasApiToken = hasApiToken || entries.some(x => String(x?.userId ?? x?.id ?? x).trim() === targetId);
    }
  } catch {}

  const adminList = loadJsonData(OWNER_FILE).map(String);
  const godList = loadJsonData(GOD_FILE).map(String);
  const founderList = loadJsonData(FOUNDER_FILE).map(String);
  const devList = loadJsonData(DEV_FILE).map(String);
  const createAdmin = adminList.includes(targetId)
    || godList.includes(targetId)
    || founderList.includes(targetId)
    || devList.includes(targetId)
    || ['owner', 'admin_owner', 'god', 'founder', 'root', 'dev'].includes(String(role.roleKey || '').toLowerCase());

  const now = new Date().toLocaleString('id-ID', {
    timeZone: 'Asia/Jakarta', year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false
  }).replace(',', '');

  const durationText = durationRaw === undefined || durationRaw === null
    ? 'Tidak ditentukan'
    : (String(durationRaw) === '0' ? 'Unlimited / Selamanya' : String(durationRaw));

  const durationDisplay = String(durationText)
    .replace(/^(\d+(?:\.\d+)?)d$/i, '$1 Hari')
    .replace(/^(\d+(?:\.\d+)?)h$/i, '$1 Jam')
    .replace(/^(\d+(?:\.\d+)?)m$/i, '$1 Menit')
    .replace(/^(\d+(?:\.\d+)?)w$/i, '$1 Minggu');

  const caption =
    `<blockquote expandable><b>LIANIX CPANEL</b>\n` +
    `<i>Role Management</i>\n` +
    `<i>Access • Roles • Permissions</i>\n` +
    `</blockquote>\n\n` +
    `☑️ <b>ROLE BERHASIL DIPERBARUI</b>\n` +
    `🎛️ <b>Panel:</b> V${escapeHtmlRoleCard(panelVersion)}  •  🟢 SUCCESS\n\n` +
    `<blockquote expandable>` +
    `<b>👤 DATA USER</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `▣ <b>Username</b>   ${escapeHtmlRoleCard(username)}\n` +
    `♡ <b>Nama</b>       ${escapeHtmlRoleCard(fullName)}\n` +
    `◎ <b>ID Akun</b>    <code>${escapeHtmlRoleCard(targetId)}</code>\n\n` +
    `♙ <b>Role Lama</b>   ${escapeHtmlRoleCard(beforeLabel)}\n` +
    `♛ <b>Role Baru</b>   <b>${escapeHtmlRoleCard(roleLabel)}</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `⚙️ <b>Create Admin</b>  ${createAdmin ? '🟢 Ya' : '🔴 Tidak'}\n` +
    `▣ <b>API Token</b>     ${hasApiToken ? '🟢 Ya' : '🔴 Tidak'}\n` +
    `◉ <b>Total ${escapeHtmlRoleCard(roleLabel)}</b>  <b>${totalBefore} → ${totalAfter}</b> User\n` +
    `⏱ <b>Masa Aktif</b>    <b>${escapeHtmlRoleCard(durationDisplay)}</b>\n` +
    `◴ <b>Waktu</b>         ${escapeHtmlRoleCard(now)}\n` +
    `</blockquote>\n\n` +
    `<i>✦ LIANIX CPANEL • Role Management System</i>`;


  const replyMarkup = {
    inline_keyboard: [[
      { text: '▤ List Role', callback_data: `rolecard:list:${sourceMsg.from.id}:${targetId}`.slice(0, 64) },
      { text: '🗑 Hapus Pesan', callback_data: `rolecard:del:${sourceMsg.from.id}`.slice(0, 64) }
    ]]
  };

  try {
    if (settings.pp) {
      return await bot.sendPhoto(chatId, settings.pp, {
        caption, parse_mode: 'HTML', reply_markup: replyMarkup,
        reply_to_message_id: sourceMsg.message_id
      });
    }
  } catch {}

  return bot.sendMessage(chatId, caption, {
    parse_mode: 'HTML', reply_markup: replyMarkup,
    reply_to_message_id: sourceMsg.message_id
  });
}

bot.on('callback_query', async (cb) => {
  if (!cb.data || !cb.data.startsWith('rolecard:')) return;

  const parts = cb.data.split(':');
  const action = parts[1];
  const actorId = String(parts[2] || '');
  const targetId = String(parts[3] || '');

  if (String(cb.from.id) !== actorId) {
    return bot.answerCallbackQuery(cb.id, {
      text: 'Hanya orang yang melakukan ADD yang bisa memakai tombol ini.',
      show_alert: true
    }).catch(() => {});
  }

  if (action === 'del') {
    await bot.answerCallbackQuery(cb.id).catch(() => {});
    try { await bot.deleteMessage(cb.message.chat.id, cb.message.message_id); } catch {}
    return;
  }

  if (action === 'list') {
    await bot.answerCallbackQuery(cb.id).catch(() => {});
    const roleFiles = [
      ['DEVELOPER', DEV_FILE], ['ROOT', ROOT_FILE], ['FOUNDER', FOUNDER_FILE],
      ['CEO', CEO_FILE], ['TK', TK_FILE], ['PT', PT_FILE],
      ['PREMIUM', PREMIUM_FILE], ['RESELLER', RESS_FILE],
      ['GOD', GOD_FILE], ['KING', KING_FILE], ['CO-FOUNDER', COFOUNDER_FILE],
      ['PEMILIK', PEMILIK_FILE], ['ROLE KHUSUS', KHUSUS_FILE]
    ];
    const found = [];
    for (const [label, file] of roleFiles) {
      if (loadJsonData(file).map(String).includes(targetId)) found.push(label);
    }
    const info = roleCardInfo(targetId);
    return bot.sendMessage(cb.message.chat.id,
      `<b>▤ LIST ROLE USER</b>\n\n` +
      `👤 <b>ID:</b> <code>${escapeHtmlRoleCard(targetId)}</code>\n` +
      `♛ <b>Role aktif:</b> ${found.length ? found.map(escapeHtmlRoleCard).join(', ') : escapeHtmlRoleCard(info.label)}`,
      { parse_mode: 'HTML', reply_to_message_id: cb.message.message_id }
    ).catch(() => {});
  }
});

function formatAddDuration(raw, duration) {
  return duration === 0 ? "UNLIMITED" : String(raw);
}

// Bantuan.
bot.onText(/^\/?addhelp$/i, (msg) => {
  if (msg.chat.type !== "private" || !hasTopAddAccess(msg.from.id)) return;

  bot.sendMessage(
    msg.chat.id,
    `<blockquote expandable>◇ <b>ADD ROLE</b>\n\n` +
    `Reply pesan user lalu ketik:\n` +
    `• <code>add 30d</code> → RESELLER\n` +
    `• <code>addprem 30d</code> → PREMIUM\n` +
    `• <code>addfounder 0</code> → FOUNDER unlimited\n` +
    `• <code>addgod 7d</code> → GOD 7 hari\n\n` +
    `Atau gunakan ID:\n<code>add &lt;id&gt; &lt;waktu&gt;</code>\n\n` +
    `<b>ALL:</b>\n` +
    `• <code>addpremall 30d</code>\n` +
    `• <code>addressall 0</code>\n\n` +
    `0 = unlimited</blockquote>`,
    { parse_mode: "HTML" }
  );
});

// ===== GOD-TIER ROLE COMMANDS =====
// Urutan: PEMILIK < CO-FOUNDER < KING < KHUSUS < GOD
// Semua hanya bisa dikelola OWNER_ID.

const GOD_ROLES = [
  { key: 'pemilik',   label: 'PEMILIK',    file: PEMILIK_FILE,   add: '/addpemilik',   del: '/delpemilik'   },
  { key: 'cofounder', label: 'CO-FOUNDER', file: COFOUNDER_FILE, add: '/addcofounder', del: '/delcofounder' },
  { key: 'king',      label: 'KING',       file: KING_FILE,      add: '/addking',      del: '/delking'      },
  { key: 'khusus',    label: 'ROLE KHUSUS',file: KHUSUS_FILE,    add: '/addkhusus',    del: '/delkhusus'    },
  { key: 'god',       label: 'GOD',        file: GOD_FILE,       add: '/addgod',       del: '/delgod'       },
];

for (const r of GOD_ROLES) {
  // /add<role>
  bot.onText(new RegExp(`^\\${r.add}(?:\\s+(.+))?$`), (msg) => {
    const chatId = msg.chat.id;
    if (!settings.isOwner(msg.from.id))
      return bot.sendMessage(chatId, `⌖ Perintah ini khusus owner. Bot.`);
    if (!msg.reply_to_message)
      return bot.sendMessage(chatId, `◈ Reply ke pesan user lalu ketik ${r.add}`);
    const tid = msg.reply_to_message.from.id.toString();
    const previousRoleLabel = roleCardInfo(tid).label;
    const list = loadJsonData(r.file);
    if (list.includes(tid)) {
      return bot.sendMessage(chatId, `◈ User ${tid} sudah jadi ${r.label}!`, { reply_to_message_id: msg.message_id });
    }
    list.push(tid);
    saveJsonData(r.file, list);
    return sendRoleUpdateCard(bot, {
      sourceMsg: msg,
      targetUser: msg.reply_to_message.from,
      role: { label: r.label, roleKey: r.key, files: [r.file] },
      previousRoleLabel,
      durationRaw: "0",
    });
  });

  // /del<role>
  bot.onText(new RegExp(`^\\${r.del}(?:\\s+(.+))?$`), (msg) => {
    const chatId = msg.chat.id;
    if (!settings.isOwner(msg.from.id))
      return bot.sendMessage(chatId, `⌖ Perintah ini khusus owner. Bot.`);
    if (!msg.reply_to_message)
      return bot.sendMessage(chatId, `◈ Reply ke pesan user lalu ketik ${r.del}`);
    const tid = msg.reply_to_message.from.id.toString();
    let list = loadJsonData(r.file);
    if (!list.includes(tid)) {
      return bot.sendMessage(chatId, `◈ User ${tid} bukan ${r.label}!`, { reply_to_message_id: msg.message_id });
    }
    list = list.filter(id => id !== tid);
    saveJsonData(r.file, list);
    bot.sendMessage(chatId, `◇ User ID ${tid} berhasil dicopot dari <b>${r.label}</b>.`, { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  });
}

bot.onText(/^\/delfounder(?:\s+(.+))?$/, (msg, match) => {
    const chatId = msg.chat.id;

    if (!settings.isOwner(msg.from.id)) {
        return bot.sendMessage(chatId, '◇ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ʙᴏᴛ');
    }

    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '◇ Reply ke pesan user!\nContoh: reply pesan lalu ketik /delfounder');
    }

    const targetUserId = msg.reply_to_message.from.id.toString();
    let founderUsers = loadJsonData(FOUNDER_FILE);

    if (founderUsers.includes(targetUserId)) {
        founderUsers = founderUsers.filter(id => id !== targetUserId);
        saveJsonData(FOUNDER_FILE, founderUsers);
        bot.sendMessage(chatId, `◉ User ID ${targetUserId} berhasil dihapus dari FOUNDER`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    } else {
        bot.sendMessage(chatId, `⚠ User ID ${targetUserId} bukan FOUNDER!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    }
});

bot.onText(/^\/addceo(?:\s+(.+))?$/, (msg, match) => { 
    if (msg.chat.type === 'private') return;
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    
    const owners = loadJsonData(OWNER_FILE);
    if (!settings.isOwner(msg.from.id) && !owners.includes(userId)) {
        return bot.sendMessage(chatId, '◇ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ʙᴏᴛ');
    }

    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '◇ Reply ke pesan user!\nContoh: reply pesan lalu ketik /addceo');
    }

    const targetUserId = msg.reply_to_message.from.id.toString();
    const previousRoleLabel = roleCardInfo(targetUserId).label;
    const ceoUsers = loadJsonData(CEO_FILE);

    if (!ceoUsers.includes(targetUserId)) {
        ceoUsers.push(targetUserId);
        saveJsonData(CEO_FILE, ceoUsers);
        return sendRoleUpdateCard(bot, {
            sourceMsg: msg,
            targetUser: msg.reply_to_message.from,
            role: { label: "CEO", roleKey: "ceo", files: [CEO_FILE] },
            previousRoleLabel,
            durationRaw: "0",
        });
    } else {
        bot.sendMessage(chatId, `⚠ User ID ${targetUserId} sudah menjadi CEO!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    }
});

// command /addtk
bot.onText(/^\/addtk(?:\s+(\d+))?$/, (msg, match) => { 
    if (msg.chat.type === 'private') return;
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    
    const owners = loadJsonData(OWNER_FILE);
    if (!settings.isOwner(msg.from.id) && !owners.includes(userId)) {
        return bot.sendMessage(chatId, '◇ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ʙᴏᴛ');
    }

    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '◇ Reply ke pesan user!\nContoh: reply pesan lalu ketik /addtk <day>\n(0 = unlimited/selamanya)');
    }

    const dayParam = match && match[1] !== undefined ? match[1] : null;
    if (dayParam === null) {
        return bot.sendMessage(chatId, '◇ Wajib sertakan jumlah hari!\nContoh: /addtk 30\nGunakan 0 untuk unlimited/selamanya.');
    }
    const days = parseInt(dayParam, 10);

    const targetUserId = msg.reply_to_message.from.id.toString();
    const previousRoleLabel = roleCardInfo(targetUserId).label;

    let tkUsers = loadJsonData(TK_FILE);
    if (!tkUsers.includes(targetUserId)) {
        tkUsers.push(targetUserId);
        saveJsonData(TK_FILE, tkUsers);
    }
    expiry.setExpiry(targetUserId, 'tk', days);

    // Tambahkan otomatis ke PT, Premium, dan Res
    let ptUsers = loadJsonData(PT_FILE);
    if (!ptUsers.includes(targetUserId)) {
        ptUsers.push(targetUserId);
        saveJsonData(PT_FILE, ptUsers);
    }
    expiry.setExpiry(targetUserId, 'pt', days);

    [PREMIUM_FILE, PREMV2_FILE, PREMV3_FILE, PREMV4_FILE, PREMV5_FILE, PREMV6_FILE, PREMV7_FILE, PREMV8_FILE, PREMV9_FILE, PREMV10_FILE].forEach(file => {
        let premUsers = loadJsonData(file);
        if (!premUsers.includes(targetUserId)) {
            premUsers.push(targetUserId);
            saveJsonData(file, premUsers);
        }
    });
    expiry.setExpiry(targetUserId, 'premium', days);

    [RESS_FILE, RESSV2_FILE, RESSV3_FILE, RESSV4_FILE, RESSV5_FILE, RESSV6_FILE, RESSV7_FILE, RESSV8_FILE, RESSV9_FILE, RESSV10_FILE].forEach(file => {
        let ressUsers = loadJsonData(file);
        if (!ressUsers.includes(targetUserId)) {
            ressUsers.push(targetUserId);
            saveJsonData(file, ressUsers);
        }
    });
    expiry.setExpiry(targetUserId, 'reseller', days);

    const expiryText = days === 0 ? 'Unlimited / Selamanya' : `${days} hari`;
    return sendRoleUpdateCard(bot, {
      sourceMsg: msg,
      targetUser: msg.reply_to_message.from,
      role: { label: "TK", roleKey: "tk", files: [TK_FILE] },
      previousRoleLabel,
      durationRaw: dayParam || "0",
    });
});

bot.onText(/^\/deltk(?:\s+(.+))?$/, (msg, match) => { 
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    const owners = loadJsonData(OWNER_FILE);
    if (!settings.isOwner(msg.from.id) && !owners.includes(userId)) {
        return bot.sendMessage(chatId, '◇ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ʙᴏᴛ');
    }

    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '◇ Reply ke pesan user!\nContoh: reply pesan lalu ketik /deltk');
    }

    const targetUserId = msg.reply_to_message.from.id.toString();

    let tkUsers = loadJsonData(TK_FILE);
    tkUsers = tkUsers.filter(id => id !== targetUserId);
    saveJsonData(TK_FILE, tkUsers);

    let ptUsers = loadJsonData(PT_FILE);
    ptUsers = ptUsers.filter(id => id !== targetUserId);
    saveJsonData(PT_FILE, ptUsers);

    [PREMIUM_FILE, PREMV2_FILE, PREMV3_FILE, PREMV4_FILE, PREMV5_FILE, PREMV6_FILE, PREMV7_FILE, PREMV8_FILE, PREMV9_FILE, PREMV10_FILE].forEach(file => {
        let premUsers = loadJsonData(file);
        premUsers = premUsers.filter(id => id !== targetUserId);
        saveJsonData(file, premUsers);
    });

    [RESS_FILE, RESSV2_FILE, RESSV3_FILE, RESSV4_FILE, RESSV5_FILE, RESSV6_FILE, RESSV7_FILE, RESSV8_FILE, RESSV9_FILE, RESSV10_FILE].forEach(file => {
        let ressUsers = loadJsonData(file);
        ressUsers = ressUsers.filter(id => id !== targetUserId);
        saveJsonData(file, ressUsers);
    });

    bot.sendMessage(chatId, `◉ User ID ${targetUserId} berhasil dihapus dari TK!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
}); 

// command /addpt
bot.onText(/^\/addpt(?:\s+(\d+))?$/, (msg, match) => { 
    if (msg.chat.type === 'private') return;
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    const owners = loadJsonData(OWNER_FILE);
    if (!settings.isOwner(msg.from.id) && !owners.includes(userId)) {
        return bot.sendMessage(chatId, '◇ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ʙᴏᴛ');
    }

    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '◇ Reply ke pesan user!\nContoh: reply pesan lalu ketik /addpt <day>\n(0 = unlimited/selamanya)');
    }

    const dayParam = match && match[1] !== undefined ? match[1] : null;
    if (dayParam === null) {
        return bot.sendMessage(chatId, '◇ Wajib sertakan jumlah hari!\nContoh: /addpt 30\nGunakan 0 untuk unlimited/selamanya.');
    }
    const days = parseInt(dayParam, 10);

    const targetUserId = msg.reply_to_message.from.id.toString();
    const previousRoleLabel = roleCardInfo(targetUserId).label;

    // ===== Tambahkan ke PT =====
    const ptUsers = loadJsonData(PT_FILE);
    if (!ptUsers.includes(targetUserId)) {
        ptUsers.push(targetUserId);
        saveJsonData(PT_FILE, ptUsers);
        return sendRoleUpdateCard(bot, {
            sourceMsg: msg,
            targetUser: msg.reply_to_message.from,
            role: { label: "PT", roleKey: "pt", files: [PT_FILE] },
            previousRoleLabel,
            durationRaw: dayParam || "0",
        });
    } else {
        bot.sendMessage(chatId, `⚠ User ID ${targetUserId} sudah menjadi PT!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    }

    // ===== Tambahkan ke Premium V1 & V2 =====
    [PREMIUM_FILE, PREMV2_FILE, PREMV3_FILE, PREMV4_FILE, PREMV5_FILE, PREMV6_FILE, PREMV7_FILE, PREMV8_FILE, PREMV9_FILE, PREMV10_FILE].forEach(file => {
        const premUsers = loadJsonData(file);
        if (!premUsers.includes(targetUserId)) {
            premUsers.push(targetUserId);
            saveJsonData(file, premUsers);
        }
    });
    expiry.setExpiry(targetUserId, 'premium', days);

    // ===== Tambahkan ke Reseller V1 & V2 =====
    [RESS_FILE, RESSV2_FILE, RESSV3_FILE, RESSV4_FILE, RESSV5_FILE, RESSV6_FILE, RESSV7_FILE, RESSV8_FILE, RESSV9_FILE, RESSV10_FILE].forEach(file => {
        const ressUsers = loadJsonData(file);
        if (!ressUsers.includes(targetUserId)) {
            ressUsers.push(targetUserId);
            saveJsonData(file, ressUsers);
        }
    });
    expiry.setExpiry(targetUserId, 'reseller', days);
    const expiryTextPt = days === 0 ? 'Unlimited / Selamanya' : `${days} hari`;
    bot.sendMessage(chatId, `◉ User ID ${targetUserId} berhasil ditambahkan ke dalam daftar PT!\n⏱ Durasi: ${expiryTextPt}`, { reply_to_message_id: msg.message_id });
});
bot.onText(/^\/delpt(?:\s+(.+))?$/, (msg, match) => { 
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    const owners = loadJsonData(OWNER_FILE);
    if (!settings.isOwner(msg.from.id) && !owners.includes(userId)) {
        return bot.sendMessage(chatId, '◇ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ʙᴏᴛ');
    }

    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '◇ Reply ke pesan user!\nContoh: reply pesan lalu ketik /delpt');
    }

    const targetUserId = msg.reply_to_message.from.id.toString();

    // ===== Hapus dari PT =====
    let ptUsers = loadJsonData(PT_FILE);
    if (ptUsers.includes(targetUserId)) {
        ptUsers = ptUsers.filter(id => id !== targetUserId);
        saveJsonData(PT_FILE, ptUsers);
        bot.sendMessage(chatId, `◉ User ID ${targetUserId} berhasil dihapus dari PT`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    } else {
        bot.sendMessage(chatId, `⚠ User ID ${targetUserId} tidak ditemukan di PT!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    }

    // ===== Hapus dari Premium V1 & V2 =====
    [PREMIUM_FILE, PREMV2_FILE, PREMV3_FILE, PREMV4_FILE, PREMV5_FILE, PREMV6_FILE, PREMV7_FILE, PREMV8_FILE, PREMV9_FILE, PREMV10_FILE].forEach(file => {
        let premUsers = loadJsonData(file);
        if (premUsers.includes(targetUserId)) {
            premUsers = premUsers.filter(id => id !== targetUserId);
            saveJsonData(file, premUsers);
        }
    });

    // ===== Hapus dari Reseller V1 & V2 =====
    [RESS_FILE, RESSV2_FILE, RESSV3_FILE, RESSV4_FILE, RESSV5_FILE, RESSV6_FILE, RESSV7_FILE, RESSV8_FILE, RESSV9_FILE, RESSV10_FILE].forEach(file => {
        let ressUsers = loadJsonData(file);
        if (ressUsers.includes(targetUserId)) {
            ressUsers = ressUsers.filter(id => id !== targetUserId);
            saveJsonData(file, ressUsers);
        }
    });
});
// command /addown panel
// /addown hanya menambahkan ROLE OWNER. Tidak lagi otomatis menambahkan
// Premium/Reseller/PT/TK karena itu menyebabkan role target salah.
bot.onText(/^\/addown$/, (msg) => {
    const chatId = msg.chat.id;

    if (!settings.isOwner(msg.from.id)) {
        return bot.sendMessage(chatId, '◇ KHUSUS DEVELOPER PEMBUAT SCRIPT');
    }

    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '◇ Reply ke pesan user lalu ketik /addown');
    }

    const targetUserId = String(msg.reply_to_message.from.id);
    const ownerUsers = loadJsonData(OWNER_FILE).map(String);

    if (ownerUsers.includes(targetUserId)) {
        return bot.sendMessage(chatId, `⚠ User ID ${targetUserId} sudah menjadi OWNER!`, {
            reply_to_message_id: msg.message_id
        });
    }

    ownerUsers.push(targetUserId);
    saveJsonData(OWNER_FILE, ownerUsers);

    return bot.sendMessage(chatId,
        `◉ User ID ${targetUserId} berhasil ditambahkan menjadi OWNER!`,
        { parse_mode: 'Markdown', reply_to_message_id: msg.message_id }
    );
});
bot.onText(/^\/delown(?:\s+(.+))?$/, (msg, match) => {
    const chatId = msg.chat.id;

    if (!settings.isOwner(msg.from.id)) {
        return bot.sendMessage(chatId, '◇ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ʙᴏᴛ');
    }

    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '◇ Reply ke pesan user!\nContoh: reply pesan lalu ketik /delown');
    }

    const targetUserId = msg.reply_to_message.from.id.toString();

    // Hapus dari OWNER
    saveJsonData(OWNER_FILE, loadJsonData(OWNER_FILE).filter(id => id !== targetUserId));

    // Hapus dari semua Premium
    const premiumFiles = [PREMIUM_FILE, PREMV2_FILE, PREMV3_FILE, PREMV4_FILE, PREMV5_FILE, PREMV6_FILE, PREMV7_FILE, PREMV8_FILE, PREMV9_FILE, PREMV10_FILE];
    premiumFiles.forEach(file => {
        saveJsonData(file, loadJsonData(file).filter(id => id !== targetUserId));
    });

    // Hapus dari semua Res
    const ressFiles = [RESS_FILE, RESSV2_FILE, RESSV3_FILE, RESSV4_FILE, RESSV5_FILE, RESSV6_FILE, RESSV7_FILE, RESSV8_FILE, RESSV9_FILE, RESSV10_FILE];
    ressFiles.forEach(file => {
        saveJsonData(file, loadJsonData(file).filter(id => id !== targetUserId));
    });

    // Hapus dari PT
    saveJsonData(PT_FILE, loadJsonData(PT_FILE).filter(id => id !== targetUserId));

    // Hapus dari TK
    saveJsonData(TK_FILE, loadJsonData(TK_FILE).filter(id => id !== targetUserId));

    bot.sendMessage(chatId, `◉ User ID ${targetUserId} berhasil dihapus dari daftar Owner!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
}); 
// command add premium & reseller
bot.onText(/^\/addpr (.+)$/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    
    const owners = loadJsonData(OWNER_FILE);
    if (!settings.isOwner(msg.from.id) && !owners.includes(userId)) {
        return bot.sendMessage(chatId, '◇ ᴋʜᴜsᴜs ᴏᴡɴᴇʀ', { reply_to_message_id: msg.message_id });
    }

    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '◇ Reply ke pesan user!\nContoh: reply pesan lalu ketik /addpr', { reply_to_message_id: msg.message_id });
    }

    const targetUserId = msg.reply_to_message.from.id.toString();
    const premiumUsers = loadJsonData(PREMIUM_FILE);
    const ressUsers = loadJsonData(RESS_FILE);

    let addedPrem = false;
    let addedRes = false;

    if (!premiumUsers.includes(targetUserId)) {
        premiumUsers.push(targetUserId);
        saveJsonData(PREMIUM_FILE, premiumUsers);
        addedPrem = true;
    }

    if (!ressUsers.includes(targetUserId)) {
        ressUsers.push(targetUserId);
        saveJsonData(RESS_FILE, ressUsers);
        addedRes = true;
    }

    if (addedPrem || addedRes) {
        bot.sendMessage(chatId, `◉ User ID ${targetUserId} berhasil ditambahkan menjadi Premium & Reseller`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    } else {
        bot.sendMessage(chatId, `⚠ User ID ${targetUserId} sudah menjadi Premium & Reseller!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    }
});

// ============================================================
// ADD <ROLE>ALL — tambah semua user yang sudah /start ke role.
// Khusus owner dan role di atas founder. Bisa dipakai tanpa "/".
// Contoh: addpremall, addressall, addgodall, addkingall
// ============================================================
const ADD_ALL_ROLES = {
    prem: PREMIUM_FILE,
    premium: PREMIUM_FILE,
    ress: RESS_FILE,
    res: RESS_FILE,
    reseller: RESS_FILE,
    address: RESS_FILE,
    ceo: CEO_FILE,
    tk: TK_FILE,
    pt: PT_FILE,
    god: GOD_FILE,
    king: KING_FILE,
    founder: FOUNDER_FILE,
    root: ROOT_FILE,
    developer: DEV_FILE,
    dev: DEV_FILE,
    pemilik: PEMILIK_FILE,
    cofounder: COFOUNDER_FILE,
    khusus: KHUSUS_FILE,
    resellervps: RESSVPS_FILE,
};

const ADD_ALL_LABELS = {
    prem: "PREMIUM",
    premium: "PREMIUM",
    ress: "RESELLER",
    res: "RESELLER",
    reseller: "RESELLER",
    address: "RESELLER",
    ceo: "CEO",
    tk: "TK",
    pt: "PT",
    god: "GOD",
    king: "KING",
    founder: "FOUNDER",
    root: "ROOT",
    developer: "DEVELOPER",
    dev: "DEVELOPER",
    pemilik: "PEMILIK",
    cofounder: "COFOUNDER",
    khusus: "KHUSUS",
    resellervps: "RESELLER VPS",
};

function canUseAddAll(userId) {
    // addXXXall boleh dipakai oleh OWNER dan role di atas Founder.
    // Selaras dengan pesan error & hasTopAddAccess.
    return hasTopAddAccess(userId);
}

function getStartedUserIds() {
    try {
        const raw = fs.existsSync("./db/users/users.json")
            ? JSON.parse(fs.readFileSync("./db/users/users.json"))
            : [];
        return [...new Set(raw.map(String).map(x => x.trim()).filter(Boolean))];
    } catch {
        return [];
    }
}

async function addRoleToAllStarted(bot, msg, roleKey, rawDuration) {
    const chatId = msg.chat.id;
    const duration = parseAddDuration(rawDuration);
    if (duration === null) {
        return bot.sendMessage(chatId, "◇ Waktu tidak valid. Contoh: addpremall 30d atau addpremall 0.", { reply_to_message_id: msg.message_id });
    }
    const file = ADD_ALL_ROLES[roleKey];
    const label = ADD_ALL_LABELS[roleKey] || roleKey.toUpperCase();

    if (!file) return;

    if (!canUseAddAll(msg.from.id)) {
        return bot.sendMessage(chatId, "◇ Perintah ini khusus Owner / Founder ke atas.", {
            reply_to_message_id: msg.message_id
        });
    }

    // Owner-all sengaja tidak dibuat agar satu typo tidak menjadikan
    // seluruh database user sebagai Owner.
    const targets = getStartedUserIds();
    if (!targets.length) {
        return bot.sendMessage(chatId,
            `<blockquote expandable>◇ <b>TIDAK ADA TARGET</b>\nBelum ada user yang sudah /start bot.</blockquote>`,
            { parse_mode: "HTML", reply_to_message_id: msg.message_id }
        );
    }

    // ── Hirarki role: index lebih tinggi = role lebih tinggi ──
    // Urutan dari terendah ke tertinggi (sesuai ROLE_ORDER di limit.js + extended)
    const ROLE_HIERARCHY = [
        "member", "reseller", "premium", "pt", "tk", "ceo",
        "founder", "pemilik", "cofounder", "king", "khusus", "god",
        "owner", "developer"
    ];

    // Normalisasi roleKey ke nama canonical yang ada di ROLE_HIERARCHY
    const ROLE_KEY_TO_CANONICAL = {
        prem: "premium", premium: "premium",
        ress: "reseller", res: "reseller", reseller: "reseller", address: "reseller",
        ceo: "ceo", tk: "tk", pt: "pt",
        god: "god", king: "king", founder: "founder", root: "owner",
        developer: "developer", dev: "developer",
        pemilik: "pemilik", cofounder: "cofounder",
        khusus: "khusus", resellervps: "reseller"
    };

    const { getUserRoleExtended } = require('./limit.js');

    const targetRoleCanonical = ROLE_KEY_TO_CANONICAL[roleKey] || roleKey;
    const targetRoleLevel = ROLE_HIERARCHY.indexOf(targetRoleCanonical);

    const current = loadJsonData(file).map(String);
    const currentSet = new Set(current);
    const added = [];
    const skipped = []; // sudah punya role sama atau lebih tinggi

    const expiryKey = roleKey === "prem" || roleKey === "premium" ? "premium"
        : roleKey === "ress" || roleKey === "res" || roleKey === "reseller" || roleKey === "address" ? "reseller"
        : roleKey;

    for (const id of targets) {
        // Cek role user saat ini
        const currentRoleKey = getUserRoleExtended(id);
        const currentRoleLevel = ROLE_HIERARCHY.indexOf(currentRoleKey);

        // Jika role user sudah >= role yang mau di-add, skip (didiamkan)
        if (currentRoleLevel >= targetRoleLevel) {
            skipped.push(id);
            continue;
        }

        // Role user lebih rendah — tambahkan
        if (!currentSet.has(id)) {
            current.push(id);
            currentSet.add(id);
        }
        expiry.setExpiry(String(id), String(expiryKey), duration);
        added.push(id);
    }

    if (added.length) {
        saveJsonData(file, current);
    }

    // Ambil nama/username dari Telegram supaya laporan menyebut siapa saja.
    const display = [];
    for (const id of added) {
        try {
            const u = await bot.getChat(id);
            const name = [u.first_name, u.last_name].filter(Boolean).join(" ").trim() || "User";
            const username = u.username ? ` @${u.username}` : "";
            display.push(`• ${name}${username} — <code>${id}</code>`);
        } catch {
            display.push(`• User — <code>${id}</code>`);
        }
    }

    const text =
        `<blockquote expandable>◈ <b>ADD ${label} ALL</b>\n\n` +
        `◉ Total user sudah start: <b>${targets.length}</b>\n` +
        `✓ Berhasil ditambahkan: <b>${added.length}</b>\n` +
        `⏭ Dilewati (role lebih tinggi): <b>${skipped.length}</b>\n` +
        `⏱ Masa aktif: <b>${duration === 0 ? "UNLIMITED" : String(rawDuration)}</b>\n\n` +
        (display.length
            ? `<b>USER YANG DITAMBAHKAN:</b>\n${display.join("\n")}`
            : `Tidak ada user baru yang perlu ditambahkan.`) +
        `</blockquote>`;

    // Telegram maksimal ~4096 karakter per pesan.
    if (text.length <= 4000) {
        return bot.sendMessage(chatId, text, {
            parse_mode: "HTML",
            reply_to_message_id: msg.message_id
        });
    }

    const header =
        `<blockquote expandable>◈ <b>ADD ${label} ALL</b>\n` +
        `◉ Total user sudah start: <b>${targets.length}</b>\n` +
        `✓ Berhasil ditambahkan: <b>${added.length}</b>\n` +
        `⏭ Dilewati (role lebih tinggi): <b>${skipped.length}</b>\n\n` +
        `<b>USER YANG DITAMBAHKAN:</b>\n`;
    const chunks = [];
    let chunk = header;

    for (const row of display) {
        if ((chunk + row + "\n</blockquote>").length > 3900) {
            chunks.push(chunk + "</blockquote>");
            chunk = "<blockquote expandable>" + row + "\n";
        } else {
            chunk += row + "\n";
        }
    }
    if (chunk.trim() !== "<blockquote expandable>") chunks.push(chunk + "</blockquote>");

    for (const part of chunks) {
        await bot.sendMessage(chatId, part, {
            parse_mode: "HTML",
            reply_to_message_id: msg.message_id
        });
    }
}

// Slash maupun tanpa slash: addpremall 30d / addressall 0 / addgodall 7d / dst.
// Durasi opsional — jika tidak ditulis, tampilkan keyboard pilihan durasi.
bot.onText(/^\/?add([a-z0-9]+)all(?:\s+(0|\d+(?:\.\d+)?(?:m|h|d|w)?))?$/i, async (msg, match) => {
    const roleKey = String(match[1]).toLowerCase();

    // Jangan tangkap command lain yang kebetulan berakhiran "all".
    if (!Object.prototype.hasOwnProperty.call(ADD_ALL_ROLES, roleKey)) return;

    // Jika durasi tidak ditulis, tampilkan keyboard pilihan.
    if (!match[2]) {
        if (!canUseAddAll(msg.from.id)) {
            return bot.sendMessage(msg.chat.id, '◇ Perintah ini khusus Owner / Founder ke atas.', {
                reply_to_message_id: msg.message_id
            });
        }
        const label = ADD_ALL_LABELS[roleKey] || roleKey.toUpperCase();
        return bot.sendMessage(
            msg.chat.id,
            `<blockquote expandable>◈ <b>ADD ${label} ALL</b>\n\nPilih masa aktif untuk semua user yang sudah /start.\nGunakan 0 untuk unlimited.</blockquote>`,
            {
                parse_mode: 'HTML',
                reply_to_message_id: msg.message_id,
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '1 Hari',    callback_data: `addall:${roleKey}:1d` },
                            { text: '5 Hari',    callback_data: `addall:${roleKey}:5d` },
                            { text: '7 Hari',    callback_data: `addall:${roleKey}:7d` }
                        ],
                        [
                            { text: '30 Hari',   callback_data: `addall:${roleKey}:30d` },
                            { text: '100 Hari',  callback_data: `addall:${roleKey}:100d` },
                            { text: 'Unlimited', callback_data: `addall:${roleKey}:0` }
                        ],
                        [{ text: '✕ Batal', callback_data: `addall:${roleKey}:cancel` }]
                    ]
                }
            }
        );
    }

    // addownerall sengaja tidak tersedia.
    await addRoleToAllStarted(bot, msg, roleKey, match[2]);
});

bot.onText(/^\/addall$/, async (msg) => {
    const chatId = msg.chat.id;
    const actorId = String(msg.from.id);
    const developers = loadJsonData(DEV_FILE).map(String);

    if (!developers.includes(actorId)) {
        return bot.sendMessage(chatId, '◇ PERINTAH INI KHUSUS DEVELOPER');
    }

    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '◇ Reply pesan user lalu ketik /addall');
    }

    const targetUser = msg.reply_to_message.from;
    const target = String(targetUser.id);

    // /addall = seluruh role yang bisa diberikan, termasuk GOD.
    // DEVELOPER pembuat TIDAK ikut diberikan karena hanya settings.ownerId.
    const ALL_ASSIGNABLE_ROLES = [
        { label: 'OWNER', key: 'admin_owner', files: [OWNER_FILE] },
        { label: 'FOUNDER', key: 'founder', files: [FOUNDER_FILE] },
        { label: 'ROOT', key: 'root', files: [ROOT_FILE] },
        { label: 'CEO', key: 'ceo', files: [CEO_FILE] },
        { label: 'TK', key: 'tk', files: [TK_FILE] },
        { label: 'PT', key: 'pt', files: [PT_FILE] },
        { label: 'PREMIUM', key: 'premium', files: [PREMIUM_FILE, PREMV2_FILE, PREMV3_FILE, PREMV4_FILE, PREMV5_FILE, PREMV6_FILE, PREMV7_FILE, PREMV8_FILE, PREMV9_FILE, PREMV10_FILE] },
        { label: 'RESELLER', key: 'reseller', files: [RESS_FILE, RESSV2_FILE, RESSV3_FILE, RESSV4_FILE, RESSV5_FILE, RESSV6_FILE, RESSV7_FILE, RESSV8_FILE, RESSV9_FILE, RESSV10_FILE] },
        { label: 'RESELLER VPS', key: 'resvps', files: [RESSVPS_FILE] },
        { label: 'PEMILIK', key: 'pemilik', files: [PEMILIK_FILE] },
        { label: 'CO-FOUNDER', key: 'cofounder', files: [COFOUNDER_FILE] },
        { label: 'KING', key: 'king', files: [KING_FILE] },
        { label: 'ROLE KHUSUS', key: 'khusus', files: [KHUSUS_FILE] },
        { label: 'GOD', key: 'god', files: [GOD_FILE] },
    ];

    const previousRole = roleCardInfo(target).label;
    const added = [];
    const already = [];

    for (const role of ALL_ASSIGNABLE_ROLES) {
        let roleAdded = false;
        for (const file of role.files) {
            const list = loadJsonData(file).map(String);
            if (!list.includes(target)) {
                list.push(target);
                saveJsonData(file, list);
                roleAdded = true;
            }
        }
        if (roleAdded) added.push(role.label);
        else already.push(role.label);
        if (role.key !== 'admin_owner') {
            try { expiry.setExpiry(target, role.key, 0); } catch {}
        }
    }

    const currentRole = roleCardInfo(target).label;
    const caption =
      `<blockquote expandable><b>LIANIX CPANEL</b>\n` +
      `<i>Role Management</i>\n` +
      `<i>Access • Roles • Permissions</i>\n` +
      `</blockquote>\n\n` +
      `☑️ <b>ADD ALL BERHASIL</b>\n\n` +
      `👤 <b>User:</b> ${escapeHtmlRoleCard(targetUser.username ? '@' + targetUser.username : [targetUser.first_name, targetUser.last_name].filter(Boolean).join(' ') || target)}\n` +
      `◎ <b>ID:</b> <code>${target}</code>\n` +
      `♙ <b>Role Sebelumnya:</b> ${escapeHtmlRoleCard(previousRole)}\n` +
      `♛ <b>Role Sekarang:</b> <b>${escapeHtmlRoleCard(currentRole)}</b>\n\n` +
      `<b>ROLE DITAMBAHKAN</b>\n${added.length ? added.map(x => `✓ ${x}`).join('\n') : 'Tidak ada role baru'}\n\n` +
      `<b>SUDAH DIMILIKI</b>\n${already.length ? already.map(x => `• ${x}`).join('\n') : '-'}\n\n` +
      `<i>DEVELOPER pembuat tidak ikut diberikan oleh /addall.</i></blockquote>`;

    return bot.sendMessage(chatId, caption, { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
});

bot.onText(/^\/delall$/, (msg) => {
    const chatId = msg.chat.id;
    const actorId = String(msg.from.id);
    const owners = loadJsonData(OWNER_FILE).map(String);
    if (actorId !== String(OWNER_ID) && !owners.includes(actorId)) {
        return bot.sendMessage(chatId, '◇ KHUSUS OWNER / DEVELOPER');
    }
    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '◇ Reply pesan user lalu ketik /delall');
    }

    const target = String(msg.reply_to_message.from.id);
    if (target === String(OWNER_ID)) {
        return bot.sendMessage(chatId, '◇ DEVELOPER pembuat tidak bisa dihapus dengan /delall.');
    }

    const files = [
      OWNER_FILE, FOUNDER_FILE, ROOT_FILE, DEV_FILE, CEO_FILE, TK_FILE, PT_FILE, RESSVPS_FILE,
      PEMILIK_FILE, COFOUNDER_FILE, KING_FILE, KHUSUS_FILE, GOD_FILE,
      PREMIUM_FILE, PREMV2_FILE, PREMV3_FILE, PREMV4_FILE, PREMV5_FILE, PREMV6_FILE, PREMV7_FILE, PREMV8_FILE, PREMV9_FILE, PREMV10_FILE,
      RESS_FILE, RESSV2_FILE, RESSV3_FILE, RESSV4_FILE, RESSV5_FILE, RESSV6_FILE, RESSV7_FILE, RESSV8_FILE, RESSV9_FILE, RESSV10_FILE
    ];
    let removed = 0;
    for (const file of files) {
        const before = loadJsonData(file).map(String);
        const after = before.filter(id => id !== target);
        if (after.length !== before.length) { removed += before.length - after.length; saveJsonData(file, after); }
    }
    for (const roleKey of ['admin_owner','founder','root','ceo','tk','pt','premium','reseller','resvps','pemilik','cofounder','king','khusus','god']) {
        try { expiry.removeExpiry(target, roleKey); } catch {}
    }

    return bot.sendMessage(chatId,
      `<blockquote expandable>⌫ <b>ALL ROLE DIHAPUS</b>\n\n◎ ID: <code>${target}</code>\n✓ Entri role dihapus: <b>${removed}</b>\n◉ DEVELOPER pembuat tetap aman.</blockquote>`,
      { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
});
bot.onText(/^\/addresvps(?:\s+(\d+))?$/, (msg, match) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id.toString();

    const owners = loadJsonData(OWNER_FILE);

    if (!settings.isOwner(msg.from.id) && !owners.includes(fromId)) {
        return bot.sendMessage(chatId, '◇ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ʙᴏᴛ');
    }

    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '◇ Reply pesan user!\nContoh: /addresvps <day>\n(0 = unlimited/selamanya)');
    }

    const dayParam = match && match[1] !== undefined ? match[1] : null;
    if (dayParam === null) {
        return bot.sendMessage(chatId, '◇ Wajib sertakan jumlah hari!\nContoh: /addresvps 30\nGunakan 0 untuk unlimited/selamanya.');
    }
    const days = parseInt(dayParam, 10);

    const target = msg.reply_to_message.from.id.toString();
    const ressVps = loadJsonData(RESSVPS_FILE);

    if (!ressVps.includes(target)) {
        ressVps.push(target);
        saveJsonData(RESSVPS_FILE, ressVps);
        return bot.sendMessage(chatId, `◉ User *${target}* ditambahkan ke RESSVPS`, {
            parse_mode: "Markdown",
            reply_to_message_id: msg.message_id
        });
    }

    bot.sendMessage(chatId, `⚠ User *${target}* sudah ada di RESSVPS`, {
        parse_mode: "Markdown",
        reply_to_message_id: msg.message_id
    });
});
bot.onText(/^\/delresvps$/, (msg) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id.toString();

    const owners = loadJsonData(OWNER_FILE);

    if (!settings.isOwner(msg.from.id) && !owners.includes(fromId)) {
        return bot.sendMessage(chatId, '◇ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ʙᴏᴛ');
    }

    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '◇ Reply pesan user!\nLalu ketik /delvps');
    }

    const target = msg.reply_to_message.from.id.toString();
    const ressVps = loadJsonData(RESSVPS_FILE);

    if (ressVps.includes(target)) {
        const updated = ressVps.filter(id => id !== target);
        saveJsonData(RESSVPS_FILE, updated);

        return bot.sendMessage(chatId, `⌫ User *${target}* dihapus dari RESSVPS`, {
            parse_mode: "Markdown",
            reply_to_message_id: msg.message_id
        });
    }

    bot.sendMessage(chatId, `⚠ User *${target}* tidak ada di RESSVPS`, {
        parse_mode: "Markdown",
        reply_to_message_id: msg.message_id
    });
});
bot.onText(/^\/addprem(?:\s+([0-9]+(?:\.[0-9]+)?(?:m|h|d|w)?))?$/i, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    const owners = loadJsonData(OWNER_FILE);
    const tkUsers = loadJsonData(TK_FILE);
    const ptUsers = loadJsonData(PT_FILE);

    // Slash /addprem tetap mengikuti akses lama.
    if (!owners.includes(userId) && !tkUsers.includes(userId) && !ptUsers.includes(userId)) {
        return bot.sendMessage(chatId, '◇ Hanya Owner, TK, atau PT yang bisa menggunakan command ini!');
    }

    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '◇ Reply ke pesan user!\nContoh: /addprem 30d\nJika tanpa waktu, otomatis 30d.\n0 = unlimited/selamanya.');
    }

    // Default /addprem tanpa waktu = 30 hari.
    const rawDuration = match && match[1] !== undefined ? match[1] : '30d';
    const parsed = parseAddDuration(rawDuration);
    const days = parsed === null ? 30 : parsed;

    const targetUserId = msg.reply_to_message.from.id.toString();
    const previousRoleLabel = roleCardInfo(targetUserId).label;
    const premUsers = loadJsonData(PREMIUM_FILE);

    if (!premUsers.includes(targetUserId)) {
        premUsers.push(targetUserId);
        saveJsonData(PREMIUM_FILE, premUsers);
        expiry.setExpiry(targetUserId, 'premium', days);
        const expiryText = rawDuration === '0' ? 'Unlimited / Selamanya' : rawDuration;
        return sendRoleUpdateCard(bot, {
            sourceMsg: msg,
            targetUser: msg.reply_to_message.from,
            role: { label: "PREMIUM", roleKey: "premium", files: [PREMIUM_FILE] },
            previousRoleLabel,
            durationRaw: rawDuration,
        });
    }

    return bot.sendMessage(chatId, `⚠ User ID ${targetUserId} sudah menjadi Premium!`);
});
// Command /delprem
bot.onText(/^\/delprem$/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    const owners = loadJsonData(OWNER_FILE);
    const tkUsers = loadJsonData(TK_FILE);
    const ptUsers = loadJsonData(PT_FILE);

    if (!owners.includes(userId) && !tkUsers.includes(userId) && !ptUsers.includes(userId)) {
        return bot.sendMessage(chatId, '◇ Hanya Owner, TK, atau PT yang bisa menggunakan command ini!');
    }

    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '◇ Reply ke pesan user!\nContoh: reply pesan lalu ketik /delprem');
    }

    const targetUserId = msg.reply_to_message.from.id.toString();

    let premUsers = loadJsonData(PREMIUM_FILE);
    if (premUsers.includes(targetUserId)) {
        premUsers = premUsers.filter(uid => uid !== targetUserId);
        saveJsonData(PREMIUM_FILE, premUsers);

        return bot.sendMessage(chatId, `◉ User ID ${targetUserId} berhasil dihapus dari Premium!`, {
            parse_mode: "Markdown",
            reply_to_message_id: msg.message_id
        });
    }

    bot.sendMessage(chatId, `⚠ User ID ${targetUserId} tidak ditemukan di daftar Premium!`);
});

// Command /address
bot.onText(/^\/address(?:\s+(\d+))?$/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    const owners = loadJsonData(OWNER_FILE);
    const tkUsers = loadJsonData(TK_FILE);
    const ptUsers = loadJsonData(PT_FILE);
    const premUsers = loadJsonData(PREMIUM_FILE);

    // Hanya Owner, TK, PT, atau Premium
    if (!owners.includes(userId) && !tkUsers.includes(userId) && !ptUsers.includes(userId) && !premUsers.includes(userId)) {
        return bot.sendMessage(chatId, '◇ Hanya Owner, TK, PT, atau Premium yang bisa menggunakan command ini!');
    }

    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '◇ Reply ke pesan user!\nContoh: reply pesan lalu ketik /address <day>\n(0 = unlimited/selamanya)');
    }

    const dayParam = match && match[1] !== undefined ? match[1] : null;
    if (dayParam === null) {
        return bot.sendMessage(chatId, '◇ Wajib sertakan jumlah hari!\nContoh: /address 30\nGunakan 0 untuk unlimited/selamanya.');
    }
    const days = parseInt(dayParam, 10);

    const targetUserId = msg.reply_to_message.from.id.toString();
    const previousRoleLabel = roleCardInfo(targetUserId).label;

    // Tambah ke Reseller
    const ressUsers = loadJsonData(RESS_FILE);
    if (!ressUsers.includes(targetUserId)) {
        ressUsers.push(targetUserId);
        saveJsonData(RESS_FILE, ressUsers);
        expiry.setExpiry(targetUserId, 'reseller', days);
        const expiryText = days === 0 ? 'Unlimited / Selamanya' : `${days} hari`;
        return sendRoleUpdateCard(bot, {
            sourceMsg: msg,
            targetUser: msg.reply_to_message.from,
            role: { label: "RESELLER", roleKey: "reseller", files: [RESS_FILE] },
            previousRoleLabel,
            durationRaw: dayParam || "0",
        });
    } else {
        bot.sendMessage(chatId, `⚠ User ID ${targetUserId} sudah menjadi Reseller Panel!`);
    }
});
bot.onText(/^\/delress$/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    const owners = loadJsonData(OWNER_FILE);
    const tkUsers = loadJsonData(TK_FILE);
    const ptUsers = loadJsonData(PT_FILE);
    const premUsers = loadJsonData(PREMIUM_FILE);

    // Hanya Owner, TK, PT, atau Premium
    if (!owners.includes(userId) && !tkUsers.includes(userId) && !ptUsers.includes(userId) && !premUsers.includes(userId)) {
        return bot.sendMessage(chatId, '◇ Hanya Owner, TK, PT, atau Premium yang bisa menggunakan command ini!');
    }

    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '◇ Reply ke pesan user!\nContoh: reply pesan lalu ketik /delress');
    }

    const targetUserId = msg.reply_to_message.from.id.toString();

    let ressUsers = loadJsonData(RESS_FILE);
    if (ressUsers.includes(targetUserId)) {
        ressUsers = ressUsers.filter(uid => uid !== targetUserId);
        saveJsonData(RESS_FILE, ressUsers);
        bot.sendMessage(chatId, `◉ User ID ${targetUserId} berhasil dihapus dari Reseller Panel!`, {
            parse_mode: "Markdown",
            reply_to_message_id: msg.message_id
        });
    } else {
        bot.sendMessage(chatId, `⚠ User ID ${targetUserId} tidak ditemukan di daftar Reseller Panel!`);
    }
});
// Command /addressv2
bot.onText(/^\/addressv2(?:\s+(\d+))?$/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    const owners = loadJsonData(OWNER_FILE);
    const tkUsers = loadJsonData(TK_FILE);
    const ptUsers = loadJsonData(PT_FILE);

    // Hanya Owner, TK, PT
    if (!owners.includes(userId) && !tkUsers.includes(userId) && !ptUsers.includes(userId)) {
        return bot.sendMessage(
            chatId,
            '◇ Command ini hanya bisa digunakan oleh Owner, TK, dan PT!'
        );
    }

    if (!msg.reply_to_message) {
        return bot.sendMessage(
            chatId,
            '◇ Reply ke pesan user!\nContoh: reply pesan lalu ketik /addressv2 <day>\n(0 = unlimited/selamanya)'
        );
    }

    const targetUserId = msg.reply_to_message.from.id.toString();

    // Tambah ke RESSV2_FILE
    const ressV2Users = loadJsonData(RESSV2_FILE);

    if (!ressV2Users.includes(targetUserId)) {
        ressV2Users.push(targetUserId);
        saveJsonData(RESSV2_FILE, ressV2Users);

        bot.sendMessage(
            chatId,
            `◉ User ID ${targetUserId} berhasil ditambahkan ke Reseller V2!`,
            {
                reply_to_message_id: msg.message_id
            }
        );
    } else {
        bot.sendMessage(
            chatId,
            `⚠ User ID ${targetUserId} sudah terdaftar di Reseller V2!`
        );
    }
});
bot.onText(/^\/delressv2$/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    const owners = loadJsonData(OWNER_FILE);
    const tkUsers = loadJsonData(TK_FILE);
    const ptUsers = loadJsonData(PT_FILE);

    // Hanya Owner, TK, PT
    if (!owners.includes(userId) && !tkUsers.includes(userId) && !ptUsers.includes(userId)) {
        return bot.sendMessage(
            chatId,
            '◇ Command ini hanya bisa digunakan oleh Owner, TK, dan PT!'
        );
    }

    if (!msg.reply_to_message) {
        return bot.sendMessage(
            chatId,
            '◇ Reply ke pesan user!\nContoh: reply pesan lalu ketik /delressv2'
        );
    }

    const targetUserId = msg.reply_to_message.from.id.toString();

    let ressV2Users = loadJsonData(RESSV2_FILE);

    if (ressV2Users.includes(targetUserId)) {
        ressV2Users = ressV2Users.filter(id => id !== targetUserId);
        saveJsonData(RESSV2_FILE, ressV2Users);

        bot.sendMessage(
            chatId,
            `◉ User ID ${targetUserId} berhasil dihapus dari Reseller V2!`,
            { reply_to_message_id: msg.message_id }
        );
    } else {
        bot.sendMessage(
            chatId,
            `⚠ User ID ${targetUserId} tidak terdaftar di Reseller V2!`
        );
    }
});
// Command /addressv3
bot.onText(/^\/addressv3(?:\s+(\d+))?$/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    const owners = loadJsonData(OWNER_FILE);
    const tkUsers = loadJsonData(TK_FILE);

    // Hanya Owner dan TK
    if (!owners.includes(userId) && !tkUsers.includes(userId)) {
        return bot.sendMessage(
            chatId,
            '◇ Command ini hanya bisa digunakan oleh Owner dan TK!'
        );
    }

    if (!msg.reply_to_message) {
        return bot.sendMessage(
            chatId,
            '◇ Reply ke pesan user!\nContoh: reply pesan lalu ketik /addressv3 <day>\n(0 = unlimited/selamanya)'
        );
    }

    const targetUserId = msg.reply_to_message.from.id.toString();

    // Tambah ke RESSV3_FILE
    const ressV3Users = loadJsonData(RESSV3_FILE);

    if (!ressV3Users.includes(targetUserId)) {
        ressV3Users.push(targetUserId);
        saveJsonData(RESSV3_FILE, ressV3Users);

        bot.sendMessage(
            chatId,
            `◉ User ID ${targetUserId} berhasil ditambahkan ke Reseller V3!`,
            {
                reply_to_message_id: msg.message_id
            }
        );
    } else {
        bot.sendMessage(
            chatId,
            `⚠ User ID ${targetUserId} sudah terdaftar di Reseller V3!`
        );
    }
});
// Command /deladdressv3
bot.onText(/^\/delressv3$/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    const owners = loadJsonData(OWNER_FILE);
    const tkUsers = loadJsonData(TK_FILE);

    // Hanya Owner dan TK
    if (!owners.includes(userId) && !tkUsers.includes(userId)) {
        return bot.sendMessage(
            chatId,
            '◇ Command ini hanya bisa digunakan oleh Owner dan TK!'
        );
    }

    if (!msg.reply_to_message) {
        return bot.sendMessage(
            chatId,
            '◇ Reply ke pesan user!\nContoh: reply pesan lalu ketik /delressv3'
        );
    }

    const targetUserId = msg.reply_to_message.from.id.toString();

    // Hapus dari RESSV3_FILE
    let ressV3Users = loadJsonData(RESSV3_FILE);

    if (ressV3Users.includes(targetUserId)) {
        ressV3Users = ressV3Users.filter(id => id !== targetUserId);
        saveJsonData(RESSV3_FILE, ressV3Users);

        bot.sendMessage(
            chatId,
            `◉ User ID ${targetUserId} berhasil dihapus dari Reseller V3!`,
            {
                reply_to_message_id: msg.message_id
            }
        );
    } else {
        bot.sendMessage(
            chatId,
            `⚠ User ID ${targetUserId} tidak terdaftar di Reseller V3!`
        );
    }
});
// Command /addpremv2
bot.onText(/^\/addpremv2(?:\s+(\d+))?$/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    const owners = loadJsonData(OWNER_FILE);
    const tkUsers = loadJsonData(TK_FILE);
    const ptUsers = loadJsonData(PT_FILE);

    // Hanya Owner, TK, PT
    if (!owners.includes(userId) && !tkUsers.includes(userId) && !ptUsers.includes(userId)) {
        return bot.sendMessage(
            chatId,
            '◇ Hanya Owner, TK, atau PT yang bisa menggunakan command ini!'
        );
    }

    if (!msg.reply_to_message) {
        return bot.sendMessage(
            chatId,
            '◇ Reply ke pesan user!\nContoh: reply pesan lalu ketik /addpremv2 <day>\n(0 = unlimited/selamanya)'
        );
    }

    const targetUserId = msg.reply_to_message.from.id.toString();

    // Tambah ke PREMV2_FILE
    const premV2Users = loadJsonData(PREMV2_FILE);

    if (!premV2Users.includes(targetUserId)) {
        premV2Users.push(targetUserId);
        saveJsonData(PREMV2_FILE, premV2Users);

        return bot.sendMessage(
            chatId,
            `◉ User ID ${targetUserId} berhasil ditambahkan ke Premium V2!`,
            { reply_to_message_id: msg.message_id }
        );
    }

    bot.sendMessage(
        chatId,
        `⚠ User ID ${targetUserId} sudah terdaftar di Premium V2!`
    );
});
// Command /addpremv3
bot.onText(/^\/addpremv3(?:\s+(\d+))?$/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    const owners = loadJsonData(OWNER_FILE);
    const tkUsers = loadJsonData(TK_FILE);

    // Hanya Owner dan TK
    if (!owners.includes(userId) && !tkUsers.includes(userId)) {
        return bot.sendMessage(
            chatId,
            '◇ Command ini hanya bisa digunakan oleh Owner dan TK!'
        );
    }

    if (!msg.reply_to_message) {
        return bot.sendMessage(
            chatId,
            '◇ Reply ke pesan user!\nContoh: reply pesan lalu ketik /addpremv3 <day>\n(0 = unlimited/selamanya)'
        );
    }

    const targetUserId = msg.reply_to_message.from.id.toString();

    // Tambah ke PREMV3_FILE
    const premV3Users = loadJsonData(PREMV3_FILE);

    if (!premV3Users.includes(targetUserId)) {
        premV3Users.push(targetUserId);
        saveJsonData(PREMV3_FILE, premV3Users);

        return bot.sendMessage(
            chatId,
            `◉ User ID ${targetUserId} berhasil ditambahkan ke Premium V3!`,
            { reply_to_message_id: msg.message_id }
        );
    }

    bot.sendMessage(
        chatId,
        `⚠ User ID ${targetUserId} sudah terdaftar di Premium V3!`
    );
});
// Command /delpremv2
bot.onText(/^\/delpremv2$/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    const owners = loadJsonData(OWNER_FILE);
    const tkUsers = loadJsonData(TK_FILE);
    const ptUsers = loadJsonData(PT_FILE);

    // Hanya Owner, TK, PT
    if (!owners.includes(userId) && !tkUsers.includes(userId) && !ptUsers.includes(userId)) {
        return bot.sendMessage(
            chatId,
            '◇ Hanya Owner, TK, atau PT yang bisa menggunakan command ini!'
        );
    }

    if (!msg.reply_to_message) {
        return bot.sendMessage(
            chatId,
            '◇ Reply ke pesan user!\nContoh: reply pesan lalu ketik /delpremv2'
        );
    }

    const targetUserId = msg.reply_to_message.from.id.toString();

    // Hapus dari PREMV2_FILE
    let premV2Users = loadJsonData(PREMV2_FILE);

    if (premV2Users.includes(targetUserId)) {
        premV2Users = premV2Users.filter(id => id !== targetUserId);
        saveJsonData(PREMV2_FILE, premV2Users);

        return bot.sendMessage(
            chatId,
            `◉ User ID ${targetUserId} berhasil dihapus dari Premium V2!`,
            { reply_to_message_id: msg.message_id }
        );
    }

    bot.sendMessage(
        chatId,
        `⚠ User ID ${targetUserId} tidak terdaftar di Premium V2!`
    );
});
// Command /delpremv3
bot.onText(/^\/delpremv3$/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    const owners = loadJsonData(OWNER_FILE);
    const tkUsers = loadJsonData(TK_FILE);

    // Hanya Owner dan TK
    if (!owners.includes(userId) && !tkUsers.includes(userId)) {
        return bot.sendMessage(
            chatId,
            '◇ Command ini hanya bisa digunakan oleh Owner dan TK!'
        );
    }

    if (!msg.reply_to_message) {
        return bot.sendMessage(
            chatId,
            '◇ Reply ke pesan user!\nContoh: reply pesan lalu ketik /delpremv3'
        );
    }

    const targetUserId = msg.reply_to_message.from.id.toString();

    // Hapus dari PREMV3_FILE
    let premV3Users = loadJsonData(PREMV3_FILE);

    if (premV3Users.includes(targetUserId)) {
        premV3Users = premV3Users.filter(id => id !== targetUserId);
        saveJsonData(PREMV3_FILE, premV3Users);

        return bot.sendMessage(
            chatId,
            `◉ User ID ${targetUserId} berhasil dihapus dari Premium V3!`,
            { reply_to_message_id: msg.message_id }
        );
    }

    bot.sendMessage(
        chatId,
        `⚠ User ID ${targetUserId} tidak terdaftar di Premium V3!`
    );
});
const PREMIUM_FILES = [
    PREMIUM_FILE,
    PREMV2_FILE,
    PREMV3_FILE,
    PREMV4_FILE,
    PREMV5_FILE,
    PREMV6_FILE,
    PREMV7_FILE
];

const RESELLER_FILES = [
    RESS_FILE,
    RESSV2_FILE,
    RESSV3_FILE,
    RESSV4_FILE,
    RESSV5_FILE,
    RESSV6_FILE,
    RESSV7_FILE
];

function addToAllFiles(fileList, userId) {
    let added = 0;
    fileList.forEach(file => {
        const data = loadJsonData(file);
        if (!data.includes(userId)) {
            data.push(userId);
            saveJsonData(file, data);
            added++;
        }
    });
    return added;
}

function removeFromAllFiles(fileList, userId) {
    let removed = 0;
    fileList.forEach(file => {
        const data = loadJsonData(file);
        const newData = data.filter(id => id !== userId);
        if (newData.length !== data.length) {
            saveJsonData(file, newData);
            removed++;
        }
    });
    return removed;
}

bot.onText(/\/premall/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    const isCooldown = checkCooldown(msg);
    if (isCooldown) return bot.sendMessage(chatId, isCooldown);

    const owners = loadJsonData(OWNER_FILE);
    if (!owners.includes(userId)) return bot.sendMessage(chatId, '◇ Khusus owner');

    if (!msg.reply_to_message) return bot.sendMessage(chatId, '⚠ Reply pesan user!');

    const target = msg.reply_to_message.from.id.toString();
    const added = addToAllFiles(PREMIUM_FILES, target);

    bot.sendMessage(
        chatId,
        `◉ User ${target} ditambahkan premium di ${added} versi`,
        { reply_to_message_id: msg.message_id }
    );
});

bot.onText(/\/ressall/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    const isCooldown = checkCooldown(msg);
    if (isCooldown) return bot.sendMessage(chatId, isCooldown);

    const owners = loadJsonData(OWNER_FILE);
    if (!owners.includes(userId)) return bot.sendMessage(chatId, '◇ Khusus owner');

    if (!msg.reply_to_message) return bot.sendMessage(chatId, '⚠ Reply pesan user!');

    const target = msg.reply_to_message.from.id.toString();
    const added = addToAllFiles(RESELLER_FILES, target);

    bot.sendMessage(
        chatId,
        `◉ User ${target} ditambahkan reseller di ${added} versi`,
        { reply_to_message_id: msg.message_id }
    );
});

bot.onText(/\/delpremall/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    const isCooldown = checkCooldown(msg);
    if (isCooldown) return bot.sendMessage(chatId, isCooldown);

    const owners = loadJsonData(OWNER_FILE);
    if (!owners.includes(userId)) return bot.sendMessage(chatId, '◇ Khusus owner');

    if (!msg.reply_to_message) return bot.sendMessage(chatId, '⚠ Reply pesan user!');

    const target = msg.reply_to_message.from.id.toString();
    const removed = removeFromAllFiles(PREMIUM_FILES, target);

    bot.sendMessage(
        chatId,
        `⌫ User ${target} dihapus dari premium di ${removed} versi`,
        { reply_to_message_id: msg.message_id }
    );
});

bot.onText(/\/delressall/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    const isCooldown = checkCooldown(msg);
    if (isCooldown) return bot.sendMessage(chatId, isCooldown);

    const owners = loadJsonData(OWNER_FILE);
    if (!owners.includes(userId)) return bot.sendMessage(chatId, '◇ Khusus owner');

    if (!msg.reply_to_message) return bot.sendMessage(chatId, '⚠ Reply pesan user!');

    const target = msg.reply_to_message.from.id.toString();
    const removed = removeFromAllFiles(RESELLER_FILES, target);

    bot.sendMessage(
        chatId,
        `⌫ User ${target} dihapus dari reseller di ${removed} versi`,
        { reply_to_message_id: msg.message_id }
    );
});

const PANEL_FILE = "./db/kode.json";

function loadPanel() {
    if (!fs.existsSync(PANEL_FILE)) {
        fs.writeFileSync(PANEL_FILE, JSON.stringify({
            status: false,
            github_url: "",
            kode_reseller: "K2GB1A7",
            kode_prem: "P3RTEM8"
        }, null, 2));
    }

    try {
        return JSON.parse(fs.readFileSync(PANEL_FILE));
    } catch {
        return {
            status: false,
            github_url: "",
            kode_reseller: "K2GB1A7",
            kode_prem: "P3RTEM8"
        };
    }
}

function savePanel(data) {
    fs.writeFileSync(PANEL_FILE, JSON.stringify(data, null, 2));
}

// ================= PANEL ON/OFF =================
bot.onText(/^\/panel (on|off)$/i, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    const owners = loadJsonData(OWNER_FILE) || [];
    if (!owners.includes(userId)) {
        return bot.sendMessage(chatId, "◇ Hanya Owner yang bisa mengatur panel!");
    }

    const mode = match[1].toLowerCase();
    const panel = loadPanel();

    panel.status = mode === "on";
    savePanel(panel);

    bot.sendMessage(chatId, `◉ Panel berhasil di ${mode.toUpperCase()}`);
});

// ================= REDEEM =================
bot.onText(/^\/redeem\s+(.+)/i, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    // ⌖ HARUS DI GROUP
    if (msg.chat.type === "private") return;

    const panel = loadPanel();
    if (!panel.status) return;

    // ⟡ NORMALISASI KODE (ANTI ERROR)
    const kode = match[1]
        .replace(/\s+/g, "") // hapus semua spasi
        .trim()
        .toUpperCase(); // samakan huruf

    const owners = loadJsonData(OWNER_FILE) || [];
    const tkUsers = loadJsonData(TK_FILE) || [];
    const ptUsers = loadJsonData(PT_FILE) || [];
    const premUsers = loadJsonData(PREMIUM_FILE) || [];
    const ressUsers = loadJsonData(RESS_FILE) || [];

    // ⌖ SUDAH PUNYA AKSES → DIAM
    if (
        owners.includes(userId) ||
        tkUsers.includes(userId) ||
        ptUsers.includes(userId) ||
        premUsers.includes(userId) ||
        ressUsers.includes(userId)
    ) {
        return;
    }

    // ================= VALIDASI =================

    // PREMIUM
    if (kode === panel.kode_prem.toUpperCase()) {
        if (!premUsers.includes(userId)) {
            premUsers.push(userId);
            saveJsonData(PREMIUM_FILE, premUsers);
        }

        return bot.sendMessage(chatId, "◉ Berhasil! Kamu sekarang PREMIUM ⟡");
    }

    // RESELLER
    if (kode === panel.kode_reseller.toUpperCase()) {
        if (!ressUsers.includes(userId)) {
            ressUsers.push(userId);
            saveJsonData(RESS_FILE, ressUsers);
        }

        return bot.sendMessage(chatId, "◉ Berhasil! Kamu sekarang RESELLER PANEL ➤");
    }

    // ◇ SALAH
    return bot.sendMessage(chatId, "◇ Kode tidak valid!");
});

const SLOT_DB = "./db/slot.json";

// ================= ANTI SPAM =================
const slotRunning = {};

// ================= WIN MODE GLOBAL =================
let winMode = {
    type: "default", // default | percent
    chance: 0
};



function loadJsonData(file) {
    try {
        return JSON.parse(fs.readFileSync(file));
    } catch {
        return [];
    }
}

function saveJsonData(file, data) {
    try {
        const dir = path.dirname(file);
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }
        fs.writeFileSync(file, JSON.stringify(data, null, 2));
    } catch (err) {
        console.error(`[saveJsonData] Gagal menyimpan ke ${file}:`, err.message);
    }
}

// ================= SLOT DATA =================
function loadSlot() {
    try {
        return JSON.parse(fs.readFileSync(SLOT_DB));
    } catch {
        return {};
    }
}

function saveSlot(data) {
    try {
        fs.writeFileSync(SLOT_DB, JSON.stringify(data, null, 2));
    } catch {}
}

const delay = (ms) => new Promise(res => setTimeout(res, ms));

// ================= SPIN =================
const buah = ["◆","◆","◆","◆","◆"];

function spinLose() {
    let a = buah[Math.floor(Math.random() * buah.length)];
    let b = buah[Math.floor(Math.random() * buah.length)];
    let c = buah[Math.floor(Math.random() * buah.length)];

    while (a === b && b === c) {
        c = buah[Math.floor(Math.random() * buah.length)];
    }

    return [a, b, c];
}

function spinWin() {
    const pick = buah[Math.floor(Math.random() * buah.length)];
    return [pick, pick, pick];
}

// ================= RANK SYSTEM FIX =================
function getRank(userId, owners, tk, prem, res) {
    userId = userId.toString();

    if (owners.includes(userId)) return "OWNER";
    if (tk.includes(userId)) return "TK";
    if (prem.includes(userId)) return "PREMIUM";
    if (res.includes(userId)) return "RESELLER";
    return null;
}

function setRank(userId, newRank, owners, tk, prem, res) {
    userId = userId.toString();

    owners = owners.filter(id => id !== userId);
    tk = tk.filter(id => id !== userId);
    prem = prem.filter(id => id !== userId);
    res = res.filter(id => id !== userId);

    if (newRank === "OWNER") owners.push(userId);
    else if (newRank === "TK") tk.push(userId);
    else if (newRank === "PREMIUM") prem.push(userId);
    else if (newRank === "RESELLER") res.push(userId);

    saveJsonData(OWNER_FILE, owners);
    saveJsonData(TK_FILE, tk);
    saveJsonData(PREMIUM_FILE, prem);
    saveJsonData(RESS_FILE, res);
}

// ================= RANK UP =================
function rankUp(rank) {
    if (rank === "RESELLER") return "PREMIUM";
    if (rank === "PREMIUM") return "TK";
    if (rank === "TK") return "OWNER";
    return "OWNER";
}

// ================= RANK DOWN =================
function rankDown(rank) {
    if (rank === "OWNER") return "TK";
    if (rank === "TK") return "PREMIUM";
    if (rank === "PREMIUM") return "RESELLER";
    return null;
}

// ================= /WIN (OWNER ONLY) =================
bot.onText(/^\/win (.+)$/i, async (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    if (!settings.isOwner(userId)) return;

    let input = match[1].replace("%", "").trim();
    let percent = parseInt(input);

    if (isNaN(percent) || percent < 0 || percent > 100) return;

    if (percent === 0) {
        winMode.type = "default";
        winMode.chance = 0;
        return bot.sendMessage(chatId, "⟡ MODE NORMAL AKTIF");
    }

    winMode.type = "percent";
    winMode.chance = percent;

    return bot.sendMessage(chatId, `⟡ WIN RATE: ${percent}%`);
});

// ================= SLOT =================
bot.onText(/^\/slot$/i, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    if (msg.chat.type === "private") return;

    if (slotRunning[userId]) return bot.sendMessage(chatId, "⏳ tunggu dulu");

    slotRunning[userId] = true;

    try {
        let owners = loadJsonData(OWNER_FILE);
        let tkUsers = loadJsonData(TK_FILE);
        let premUsers = loadJsonData(PREMIUM_FILE);
        let ressUsers = loadJsonData(RESS_FILE);

        let currentRank = getRank(userId, owners, tkUsers, premUsers, ressUsers);
        if (!currentRank) return;

        let slotData = loadSlot();

        if (!slotData[userId]) {
            slotData[userId] = {
                win: 0,
                lose: 0,
                sessionWin: 0
            };
        }

        let data = slotData[userId];

        let msgSpin = await bot.sendMessage(chatId, "⟡ SPINNING...");

        let finalSpin;

        for (let i = 0; i < 2; i++) {
            finalSpin = spinLose();
            await delay(800);

            await bot.editMessageText(`⟡ SLOT\n\n${finalSpin.join(" | ")}`, {
                chat_id: chatId,
                message_id: msgSpin.message_id
            });
        }

        await delay(800);

        // ================= WIN LOGIC =================
        let isWin = false;
        let roll = Math.random() * 100;

        if (winMode.type === "percent") {
            isWin = roll < winMode.chance;
        } else {
            isWin = data.sessionWin < 2;
        }

        if (isWin) {
            finalSpin = spinWin();
        } else {
            finalSpin = spinLose();
        }

        await bot.editMessageText(`⟡ SLOT\n\n${finalSpin.join(" | ")}`, {
            chat_id: chatId,
            message_id: msgSpin.message_id
        });

        let text = `⟡ SLOT\n\n${finalSpin.join(" | ")}\n\n`;

        // ================= WIN =================
        if (isWin) {
            data.win++;
            data.lose = 0;
            data.sessionWin++;

            text += `⟡ WIN\nWin: ${data.win}`;

            if (data.win >= 3) {
                let newRank = rankUp(currentRank);

                setRank(userId, newRank, owners, tkUsers, premUsers, ressUsers);

                owners = loadJsonData(OWNER_FILE);
                tkUsers = loadJsonData(TK_FILE);
                premUsers = loadJsonData(PREMIUM_FILE);
                ressUsers = loadJsonData(RESS_FILE);

                currentRank = getRank(userId, owners, tkUsers, premUsers, ressUsers);

                text += `\n\n➤ NAIK RANK → ${currentRank}`;

                data.win = 0;
                data.lose = 0;
                data.sessionWin = 0;
            }

        // ================= LOSE =================
        } else {
            data.lose++;
            data.win = 0;
            data.sessionWin = 0;

            text += `☠ LOSE\nLose: ${data.lose}`;

            if (data.lose >= 3) {
                let newRank = rankDown(currentRank);

                setRank(userId, newRank, owners, tkUsers, premUsers, ressUsers);

                owners = loadJsonData(OWNER_FILE);
                tkUsers = loadJsonData(TK_FILE);
                premUsers = loadJsonData(PREMIUM_FILE);
                ressUsers = loadJsonData(RESS_FILE);

                currentRank = getRank(userId, owners, tkUsers, premUsers, ressUsers);

                if (currentRank) {
                    text += `\n\n⚠ TURUN RANK → ${currentRank}`;
                } else {
                    text += `\n\n☠ RANK HABIS`;
                }

                data.win = 0;
                data.lose = 0;
                data.sessionWin = 0;
            }
        }

        text += `\n\n◆ Rank Saat Ini: ${currentRank || "NONE"}`;

        saveSlot(slotData);

        return bot.sendMessage(chatId, text);

    } finally {
        slotRunning[userId] = false;
    }
});


// ==================== /rolemem ====================
// Owner-only role dashboard. Semua role ditampilkan sampai GOD.
// Dibuat paginated agar daftar panjang tidak terpotong dan tidak perlu
// mengirim banyak pesan yang membuat user mengira role berhenti di TK.
const ROLEMEM_PAGE_SIZE = 4;
const ROLEMEM_ROLES = [
    { key: 'reseller',  label: 'RESELLER',    file: RESS_FILE },
    { key: 'premium',   label: 'PREMIUM',     file: PREMIUM_FILE },
    { key: 'pt',        label: 'PT',          file: PT_FILE },
    { key: 'tk',        label: 'TK',          file: TK_FILE },
    { key: 'ceo',       label: 'CEO',         file: CEO_FILE },
    { key: 'founder',   label: 'FOUNDER',     file: FOUNDER_FILE },
    { key: 'pemilik',   label: 'PEMILIK',     file: PEMILIK_FILE },
    { key: 'cofounder', label: 'CO-FOUNDER',  file: COFOUNDER_FILE },
    { key: 'king',      label: 'KING',        file: KING_FILE },
    { key: 'khusus',    label: 'ROLE KHUSUS', file: KHUSUS_FILE },
    { key: 'god',       label: 'GOD',         file: GOD_FILE },
    { key: 'resvps',    label: 'RESELLER VPS',file: RESSVPS_FILE },
    { key: 'root',      label: 'ROOT',        file: ROOT_FILE },
    { key: 'developer', label: 'DEVELOPER',   file: DEV_FILE },
];

function rolememReadUsers(file) {
    try { return [...new Set((loadJsonData(file) || []).map(String).filter(Boolean))]; }
    catch { return []; }
}

function rolememExpiryKey(roleKey) {
    return roleKey === 'resvps' ? 'resellerVps' : roleKey;
}

async function rolememBuildPage(page = 0) {
    const totalPages = Math.max(1, Math.ceil(ROLEMEM_ROLES.length / ROLEMEM_PAGE_SIZE));
    const safePage = Math.max(0, Math.min(totalPages - 1, Number(page) || 0));
    const groups = ROLEMEM_ROLES.slice(safePage * ROLEMEM_PAGE_SIZE, (safePage + 1) * ROLEMEM_PAGE_SIZE);
    const counts = ROLEMEM_ROLES.map(role => ({ role, users: rolememReadUsers(role.file) }));
    const totalAssigned = counts.reduce((n, x) => n + x.users.length, 0);
    const nonEmpty = counts.filter(x => x.users.length).length;
    const totalMembers = new Set(counts.flatMap(x => x.users)).size;
    const top = counts.slice().sort((a,b) => b.users.length - a.users.length).slice(0, 3);

    let text =
        `<b>╭━━〔 ROLE MEMBER 〕━━╮</b>\n` +
        `<i>Role management • access overview</i>\n\n` +
        `<blockquote expandable><b>OVERVIEW</b>\n` +
        `◈ Total assignment : <b>${totalAssigned}</b>\n` +
        `◈ Unique member   : <b>${totalMembers}</b>\n` +
        `◈ Active role      : <b>${nonEmpty}/${ROLEMEM_ROLES.length}</b>\n` +
        `◈ Terbanyak        : <b>${top[0]?.role.label || '-'} (${top[0]?.users.length || 0})</b>\n` +
        `</blockquote>\n` +
        `<b>PAGE ${safePage + 1}/${totalPages}</b>  •  ${groups.length} role\n`;

    for (const role of groups) {
        const users = rolememReadUsers(role.file);
        text += `\n<blockquote expandable><b>◆ ${role.label}</b>  <code>${users.length}</code>\n`;
        if (!users.length) {
            text += `<i>Belum ada member pada role ini.</i></blockquote>\n`;
            continue;
        }
        const displayUsers = users.slice(0, 30);
        const chatInfos = await Promise.all(displayUsers.map(uid => bot.getChat(uid).catch(() => null)));
        for (let i = 0; i < displayUsers.length; i++) {
            const uid = displayUsers[i];
            const exp = rolememExpiryKey(role.key);
            const info = chatInfos[i];
            const username = info && info.username ? `@${info.username}` : null;
            const expiryStr = expiry.formatExpiry(uid, exp);
            text += username
                ? `⪼ <code>${uid}</code> • ${username}\n   ${expiryStr}\n`
                : `⪼ <code>${uid}</code> • ${expiryStr}\n`;
        }
        if (users.length > 30) text += `<i>+${users.length - 30} member lainnya</i>\n`;
        text += `</blockquote>`;
    }
    text += `\n<blockquote expandable><b>INFO</b>\nUnlimited = tanpa masa aktif\nEXPIRED = role sudah melewati masa aktif\nGunakan navigasi untuk melihat role berikutnya.</blockquote>`;
    return { text, page: safePage, totalPages };
}

function rolememKeyboard(page, totalPages) {
    const rows = [];
    if (totalPages > 1) {
        const nav = [];
        if (page > 0) nav.push({ text: '‹ Sebelumnya', callback_data: `rolemem_page_${page - 1}` });
        if (page < totalPages - 1) nav.push({ text: 'Berikutnya ›', callback_data: `rolemem_page_${page + 1}` });
        if (nav.length) rows.push(nav);
    }
    rows.push([{ text: '↻ REFRESH', callback_data: `rolemem_page_${page}` }]);
    rows.push([{ text: '< ‹', callback_data: 'rolemem_close' }]);
    return { inline_keyboard: rows };
}

async function sendRolemem(bot, chatId, messageId, page, edit = false) {
    const payload = await rolememBuildPage(page);
    const opts = { parse_mode: 'HTML', reply_markup: rolememKeyboard(payload.page, payload.totalPages) };
    if (edit && messageId) {
        try {
            return await bot.editMessageText(payload.text, { chat_id: chatId, message_id: messageId, ...opts });
        } catch (e) {
            try {
                return await bot.editMessageCaption(payload.text, { chat_id: chatId, message_id: messageId, ...opts });
            } catch {}
        }
    }
    return bot.sendMessage(chatId, payload.text, opts);
}

bot.onText(/^\/rolemem$/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = String(msg.from.id);
    const owners = (loadJsonData(OWNER_FILE) || []).map(String);
    if (!owners.includes(userId) && !settings.isOwner(msg.from.id)) {
        return bot.sendMessage(chatId,
            '<b>╭━━〔 ROLE MEMBER 〕━━╮</b>\n\n<blockquote expandable><b>AKSES DITOLAK</b>\nPerintah ini khusus OWNER / DEVELOPER.</blockquote>',
            { parse_mode: 'HTML' }
        );
    }
    return sendRolemem(bot, chatId, null, 0, false);
});

bot.on('callback_query', async (cb) => {
    const data = String(cb.data || '');
    if (data === 'rolemem_close') {
        await bot.answerCallbackQuery(cb.id).catch(() => {});
        return bot.deleteMessage(cb.message.chat.id, cb.message.message_id).catch(() => {});
    }
    if (!/^rolemem_page_\d+$/.test(data)) return;
    const owners = (loadJsonData(OWNER_FILE) || []).map(String);
    if (!owners.includes(String(cb.from.id)) && String(cb.from.id) !== String(OWNER_ID)) {
        return bot.answerCallbackQuery(cb.id, { text: 'Khusus OWNER / DEVELOPER.', show_alert: true }).catch(() => {});
    }
    const page = Number(data.replace('rolemem_page_', ''));
    await bot.answerCallbackQuery(cb.id).catch(() => {});
    return sendRolemem(bot, cb.message.chat.id, cb.message.message_id, page, true);
});
}
