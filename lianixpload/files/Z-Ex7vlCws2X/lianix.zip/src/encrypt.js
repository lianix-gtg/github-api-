const fs = require("fs-extra");
const crypto = require("crypto");

const JsConfuser = require("js-confuser");
const path = require("path");
const AdmZip = require("adm-zip");

// Shared ENC config: top-level so Backup Center can safely reuse the existing /enc engine.
function getObfuscationConfig(level = "high") {
  return {
    target: "node",
    compact: true,
    renameVariables: true,
    renameGlobals: true,
    identifierGenerator: "hexadecimal",
    stringEncoding: true,
    stringSplitting: true,
    controlFlowFlattening: level === "high" ? 0.95 : level === "medium" ? 0.75 : 0.5,
    duplicateLiteralsRemoval: true,
    deadCode: true,
    calculator: true,
    opaquePredicates: true,
    lock: {
        selfDefending: true,
        antiDebug: true,
        integrity: true,
        // JsConfuser Tamper Protection cannot be applied to files
        // containing "use strict". Keep the other protections enabled
        // so ENC still works on strict-mode Node.js files.
        tamperProtection: false
    }
  };
}
const os = require("os");
const { webcrack } = require("webcrack");
const settings = require("../settings.js");

const q = (msg) => msg?.message_id ? { reply_to_message_id: msg.message_id } : {};

const ENC_TMP_DIR = path.join(os.tmpdir(), "lianix-enc");
try { fs.ensureDirSync(ENC_TMP_DIR); } catch {}

// /enc ZIP session: one user can inspect/select a ZIP before processing it.
const encZipSessions = new Map();
const ENC_ZIP_TTL = 15 * 60 * 1000;

function zipSessionKey(chatId, userId) { return `${chatId}:${userId}`; }
function cleanupZipSession(key) {
  const st = encZipSessions.get(key);
  if (!st) return;
  if (st.dir) { try { fs.removeSync(st.dir); } catch {} }
  encZipSessions.delete(key);
}
function html(s) { return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function zipEntrySafeName(name) {
  const n = String(name || '').replace(/\\/g, '/');
  const clean = path.posix.normalize('/' + n).replace(/^\/+/, '');
  if (!clean || clean.startsWith('../') || clean.includes('/../') || path.posix.isAbsolute(clean)) return null;
  return clean;
}
function analyzeZip(zipPath) {
  const zip = new AdmZip(zipPath);
  const entries = zip.getEntries();
  const files = [];
  let totalBytes = 0;
  for (const zipEntry of entries) {
    if (zipEntry.isDirectory) continue;
    const name = zipEntrySafeName(zipEntry.entryName);
    if (!name) continue;
    const size = Number(zipEntry.header?.size || zipEntry.getData()?.length || 0);
    totalBytes += size;
    files.push({ name, size, js: /\.js$/i.test(name) });
  }
  return { entries: files, jsFiles: files.filter(x => x.js), totalBytes };
}

async function prepareZipSession(bot, msg, file, level) {
  const chatId = msg.chat.id, userId = msg.from.id;
  const key = zipSessionKey(chatId, userId);
  cleanupZipSession(key);
  const dir = path.join(ENC_TMP_DIR, `zip-${chatId}-${userId}-${Date.now()}`);
  fs.ensureDirSync(dir);
  const zipPath = path.join(dir, 'input.zip');
  try {
    const link = await bot.getFileLink(file.file_id);
    const response = await fetch(link);
    if (!response.ok) throw new Error(`Gagal mengunduh ZIP: HTTP ${response.status}`);
    await fs.writeFile(zipPath, Buffer.from(await response.arrayBuffer()));
    const info = analyzeZip(zipPath);
    if (!info.jsFiles.length) throw new Error('ZIP tidak berisi file .js yang bisa di-ENC.');
    encZipSessions.set(key, { chatId, userId, fileName: file.file_name, zipPath, dir, level, info, selected: new Set(), createdAt: Date.now() });
    const rows = [
      [{ text: `ENC SEMUA (${info.jsFiles.length})`, callback_data: 'enczip_all' }],
      [{ text: 'PILIH FILE', callback_data: 'enczip_pick' }, { text: 'BATAL', callback_data: 'enczip_cancel' }]
    ];
    return bot.sendMessage(chatId,
      `<b>╭━━〔 ANALISIS ZIP SELESAI 〕━━╮</b>\n` +
      `<blockquote expandable><b>File</b> : <code>${html(file.file_name)}</code>\n` +
      `<b>Total</b>: <b>${info.entries.length}</b> file\n` +
      `<b>JS</b>   : <b>${info.jsFiles.length}</b> file\n` +
      `<b>Data</b> : <b>${(info.totalBytes / 1048576).toFixed(2)} MB</b></blockquote>\n` +
      `Mau semua file <code>.js</code> di-ENC atau pilih beberapa?`,
      { parse_mode: 'HTML', reply_to_message_id: msg.message_id, reply_markup: { inline_keyboard: rows } }
    );
  } catch (e) {
    cleanupZipSession(key);
    throw e;
  }
}

async function processZipSession(bot, key, mode) {
  const st = encZipSessions.get(key);
  if (!st) throw new Error('Sesi ZIP sudah kedaluwarsa. Kirim ZIP lalu jalankan /enc lagi.');
  if (Date.now() - st.createdAt > ENC_ZIP_TTL) { cleanupZipSession(key); throw new Error('Sesi ZIP sudah kedaluwarsa.'); }
  const selected = mode === 'all' ? st.info.jsFiles.map((_, i) => i) : [...st.selected];
  if (!selected.length) throw new Error('Belum ada file JS yang dipilih.');

  const outPath = path.join(st.dir, `enc-${st.fileName}`);
  const workDir = path.join(st.dir, 'work');
  fs.ensureDirSync(workDir);
  const srcZip = new AdmZip(st.zipPath);
  const outZip = new AdmZip();
  const selectedNames = new Set(selected.map(i => st.info.jsFiles[i]?.name).filter(Boolean));
  let encrypted = 0, skipped = 0;

  for (const zipEntry of srcZip.getEntries()) {
    if (zipEntry.isDirectory) { outZip.addFile(zipEntry.entryName, Buffer.alloc(0)); continue; }
    const name = zipEntrySafeName(zipEntry.entryName);
    if (!name) continue;
    let data = zipEntry.getData();
    if (selectedNames.has(name) && /\.js$/i.test(name)) {
      try {
        const source = data.toString('utf8');
        const obfuscated = await JsConfuser.obfuscate(source, getObfuscationConfig(st.level));
        if (!obfuscated?.code) throw new Error('hasil ENC kosong');
        data = Buffer.from(obfuscated.code, 'utf8');
        encrypted++;
      } catch (encErr) {
        skipped++;
      }
    }
    outZip.addFile(name, data);
  }
  if (!encrypted) throw new Error('Tidak ada file JS yang berhasil di-ENC.');
  outZip.addFile('LIANIX-ENC-MANIFEST.json', Buffer.from(JSON.stringify({
    format: 'LIANIX ZIP ENC', version: 1, mode: st.level.toUpperCase(),
    source: st.fileName, encryptedFiles: [...selectedNames], encrypted, skipped
  }, null, 2)));
  outZip.writeZip(outPath);
  return { outPath, encrypted, skipped, selected: selectedNames.size, total: st.info.jsFiles.length };
}


module.exports = (bot) => {
  const REQUIRED_CHANNEL = '@M1yuunReseller';
  const REQUIRED_CHANNEL_URL = 'https://t.me/M1yuunReseller';

  const isMember = async (userId) => {
    try {
      const member = await bot.getChatMember(REQUIRED_CHANNEL, userId);
      return ['creator', 'administrator', 'member'].includes(member.status) ||
        (member.status === 'restricted' && member.is_member === true);
    } catch (err) {
      console.error('[join-check] Gagal mengecek channel:', err.message);
      return null;
    }
  };

  const sendJoinChannel = async (msg, edit = false) => {
    const chatId = msg.chat.id;
    const text = `<blockquote expandable>◈ <b>WAJIB JOIN CHANNEL</b>\n\n` +
      `Akses fitur ini membutuhkan kamu bergabung di channel resmi terlebih dahulu.\n\n` +
      `📢 Channel: <b>@M1yuunReseller</b>\n` +
      `Selesai Setelah join, tekan tombol <b>Sudah Join</b> untuk memeriksa kembali.</blockquote>`;
    const opts = {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [{ text: 'Join Channel', url: REQUIRED_CHANNEL_URL }],
          [{ text: 'Sudah Join • Check', callback_data: 'verify_join_channel' }]
        ]
      }
    };
    if (edit && msg.message_id) {
      try { return await bot.editMessageText(text, { chat_id: chatId, message_id: msg.message_id, ...opts }); }
      catch {}
    }
    return bot.sendMessage(chatId, text, { reply_to_message_id: msg.message_id, ...opts });
  };

  bot.on('callback_query', async (callbackQuery) => {
    const msg = callbackQuery.message;
    const userId = callbackQuery.from.id;
    const chatId = msg.chat.id;
    const data = callbackQuery.data || '';
    const sessionKey = zipSessionKey(chatId, userId);

    if (data === 'enczip_cancel') {
      cleanupZipSession(sessionKey);
      await bot.answerCallbackQuery(callbackQuery.id, { text: 'Dibatalkan.' }).catch(() => {});
      return bot.editMessageText('<blockquote expandable>Batal <b>ENC ZIP DIBATALKAN</b></blockquote>', { chat_id: chatId, message_id: msg.message_id, parse_mode: 'HTML' }).catch(() => {});
    }

    if (data === 'enczip_all' || data === 'enczip_run') {
      await bot.answerCallbackQuery(callbackQuery.id, { text: 'Memproses ZIP...' }).catch(() => {});
      try {
        const result = await processZipSession(bot, sessionKey, 'all');
        await bot.sendDocument(chatId, result.outPath, {
          caption: `<b>YOEN YOEN ENC ZIP SELESAI</b>\n<blockquote expandable>Mode : <b>${html(encZipSessions.get(sessionKey)?.level || 'high').toUpperCase()}</b>\nEncrypted : <b>${result.encrypted}/${result.total}</b> file JS\n${result.skipped ? `Skipped : <b>${result.skipped}</b>` : 'Status : Semua file terpilih berhasil diproses.'}</blockquote>`,
          parse_mode: 'HTML', reply_to_message_id: msg.message_id, filename: `enc-${encZipSessions.get(sessionKey)?.fileName || 'project.zip'}`
        });
        cleanupZipSession(sessionKey);
        return bot.editMessageText('<blockquote expandable>Selesai <b>ZIP BERHASIL DI-ENC</b>\nFile hasil sudah dikirim.</blockquote>', { chat_id: chatId, message_id: msg.message_id, parse_mode: 'HTML' }).catch(() => {});
      } catch (e) {
        return bot.sendMessage(chatId, `❌ ${html(e.message)}`, { parse_mode: 'HTML' }).catch(() => {});
      }
    }

    if (data === 'enczip_pick') {
      const st = encZipSessions.get(sessionKey);
      if (!st) return bot.answerCallbackQuery(callbackQuery.id, { text: 'Sesi ZIP sudah kedaluwarsa.', show_alert: true }).catch(() => {});
      const rows = [];
      for (let i = 0; i < st.info.jsFiles.length; i++) {
        const f = st.info.jsFiles[i];
        rows.push([{ text: `${st.selected.has(i) ? '☑' : '☐'} ${f.name}`, callback_data: `enczip_file_${i}` }]);
      }
      rows.push([{ text: `ENC ${st.selected.size} FILE`, callback_data: 'enczip_selected' }]);
      rows.push([{ text: 'RESET', callback_data: 'enczip_reset' }, { text: '‹‹‹', callback_data: 'enczip_back' }]);
      await bot.answerCallbackQuery(callbackQuery.id).catch(() => {});
      return bot.editMessageText(`<b>╭━━〔 PILIH FILE JS 〕━━╮</b>\n\nDipilih: <b>${st.selected.size}</b> / ${st.info.jsFiles.length}\nTekan file yang ingin di-ENC.`, { chat_id: chatId, message_id: msg.message_id, parse_mode: 'HTML', reply_markup: { inline_keyboard: rows } }).catch(() => {});
    }

    if (data.startsWith('enczip_file_')) {
      const st = encZipSessions.get(sessionKey);
      const idx = Number(data.slice('enczip_file_'.length));
      if (!st || !Number.isInteger(idx) || !st.info.jsFiles[idx]) return bot.answerCallbackQuery(callbackQuery.id, { text: 'File tidak ditemukan.', show_alert: true }).catch(() => {});
      if (st.selected.has(idx)) st.selected.delete(idx); else st.selected.add(idx);
      await bot.answerCallbackQuery(callbackQuery.id, { text: st.selected.has(idx) ? 'File dipilih' : 'File dilepas' }).catch(() => {});
      const rows = [];
      for (let i = 0; i < st.info.jsFiles.length; i++) rows.push([{ text: `${st.selected.has(i) ? '☑' : '☐'} ${st.info.jsFiles[i].name}`, callback_data: `enczip_file_${i}` }]);
      rows.push([{ text: `ENC ${st.selected.size} FILE`, callback_data: 'enczip_selected' }]);
      rows.push([{ text: 'RESET', callback_data: 'enczip_reset' }, { text: '‹‹‹', callback_data: 'enczip_back' }]);
      return bot.editMessageText(`<b>╭━━〔 PILIH FILE JS 〕━━╮</b>\n\nDipilih: <b>${st.selected.size}</b> / ${st.info.jsFiles.length}`, { chat_id: chatId, message_id: msg.message_id, parse_mode: 'HTML', reply_markup: { inline_keyboard: rows } }).catch(() => {});
    }

    if (data === 'enczip_reset') {
      const st = encZipSessions.get(sessionKey); if (st) st.selected.clear();
      await bot.answerCallbackQuery(callbackQuery.id, { text: 'Pilihan di-reset.' }).catch(() => {});
      return bot.editMessageText('<b>Pilihan di-reset.</b>\n\nTekan <b>‹‹‹</b> lalu pilih file lagi.', { chat_id: chatId, message_id: msg.message_id, parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: 'PILIH FILE', callback_data: 'enczip_pick' }, { text: '‹‹‹', callback_data: 'enczip_back' }]] } }).catch(() => {});
    }

    if (data === 'enczip_back') {
      const st = encZipSessions.get(sessionKey);
      if (!st) return bot.answerCallbackQuery(callbackQuery.id, { text: 'Sesi ZIP sudah kedaluwarsa.', show_alert: true }).catch(() => {});
      await bot.answerCallbackQuery(callbackQuery.id).catch(() => {});
      return bot.editMessageText(`<b>╭━━〔 ANALISIS ZIP 〕━━╮</b>\n\nFile: <code>${html(st.fileName)}</code>\nJS: <b>${st.info.jsFiles.length}</b>\n\nMau semua file JS di-ENC atau pilih beberapa?`, { chat_id: chatId, message_id: msg.message_id, parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: `ENC SEMUA (${st.info.jsFiles.length})`, callback_data: 'enczip_all' }], [{ text: 'PILIH FILE', callback_data: 'enczip_pick' }, { text: 'BATAL', callback_data: 'enczip_cancel' }]] } }).catch(() => {});
    }

    if (data === 'enczip_selected') {
      const st = encZipSessions.get(sessionKey);
      if (!st || !st.selected.size) return bot.answerCallbackQuery(callbackQuery.id, { text: 'Pilih minimal 1 file JS.', show_alert: true }).catch(() => {});
      await bot.answerCallbackQuery(callbackQuery.id, { text: 'Memproses file terpilih...' }).catch(() => {});
      try {
        const result = await processZipSession(bot, sessionKey, 'selected');
        const current = encZipSessions.get(sessionKey);
        await bot.sendDocument(chatId, result.outPath, {
          caption: `<b>YOEN YOEN ENC ZIP SELESAI</b>\n<blockquote expandable>Mode : <b>${html(current?.level || 'high').toUpperCase()}</b>\nEncrypted : <b>${result.encrypted}</b> file\nSkipped : <b>${result.skipped}</b> file</blockquote>`,
          parse_mode: 'HTML', reply_to_message_id: msg.message_id, filename: `enc-${current?.fileName || 'project.zip'}`
        });
        cleanupZipSession(sessionKey);
        return bot.editMessageText('<blockquote expandable>Selesai <b>FILE TERPILIH BERHASIL DI-ENC</b>\nZIP hasil sudah dikirim.</blockquote>', { chat_id: chatId, message_id: msg.message_id, parse_mode: 'HTML' }).catch(() => {});
      } catch (e) {
        return bot.sendMessage(chatId, `❌ ${html(e.message)}`, { parse_mode: 'HTML' }).catch(() => {});
      }
    }

    if (callbackQuery.data === "verify_join_channel") {
      try {
        const joined = await isMember(userId);
        if (joined === true) {
          await bot.answerCallbackQuery(callbackQuery.id, { text: 'Selesai Join terverifikasi!', show_alert: false });
          return bot.editMessageText(
            `<blockquote expandable>Selesai <b>JOIN TERVERIFIKASI</b>\n\n` +
            `Akses fitur enkripsi sekarang sudah dibuka.</blockquote>`,
            { chat_id: chatId, message_id: msg.message_id, parse_mode: 'HTML' }
          ).catch(() => {});
        }
        if (joined === false) {
          await bot.answerCallbackQuery(callbackQuery.id, { text: '❌ Kamu belum join channel.', show_alert: true });
          return sendJoinChannel(msg, true);
        }
        await bot.answerCallbackQuery(callbackQuery.id, { text: '⚠️ Status join tidak bisa dicek. Pastikan bot bisa mengakses channel.', show_alert: true });
      } catch (err) {
        await bot.answerCallbackQuery(callbackQuery.id, { text: '❌ Gagal mengecek status join.', show_alert: true }).catch(() => {});
      }
    }
  });

  const command = (regex, callback) => {
    bot.onText(regex, async (msg, match) => {
      const userId = msg.from.id;
      const joined = await isMember(userId);

      if (joined === null) {
        return bot.sendMessage(msg.chat.id, `<blockquote expandable>⚠️ <b>GAGAL CEK JOIN</b>\n\nBot belum bisa memeriksa keanggotaan channel <b>@M1yuunReseller</b>. Pastikan bot memiliki akses ke channel tersebut.</blockquote>`, { parse_mode: 'HTML', ...q(msg) }).catch(() => {});
      }
      if (!joined) return sendJoinChannel(msg);

      callback(msg, match);
    });
  };
    
function createProgressBar(percent = 0, size = 20) {
    
  let p = Number(percent);
  if (!isFinite(p)) p = 0;
  p = Math.max(0, Math.min(100, Math.round(p)));

  const filled = Math.max(0, Math.min(size, Math.round((p / 100) * size)));
  const empty = Math.max(0, size - filled);

  const barFilled = '█'.repeat(filled);
  const barEmpty = '░'.repeat(empty);
  return `${barFilled}${barEmpty} ${p}%`;
}

const encProgressState = new Map();
async function updateProgress(bot, chatId, messageId, percent = 0, label = '') {
  try {
    let p = Number(percent);
    if (!isFinite(p)) p = 0;
    p = Math.max(0, Math.min(100, Math.round(p)));
    const bar = createProgressBar(p, 20);
    const text = `<b>ENC • PROSES</b>\n<code>${html(label)}</code> · <b>${p}%</b>\n<code>${bar}</code>`;
    const stateKey = `${chatId}:${messageId || 'new'}`;
    if (encProgressState.get(stateKey) === text) return true;
    if (messageId) {
      try {
        await bot.editMessageText(text, { chat_id: chatId, message_id: messageId, parse_mode: 'HTML' });
        encProgressState.set(stateKey, text);
        return true;
      } catch (err) {
        const desc = String(err?.response?.body?.description || err?.message || err);
        if (/message is not modified|message to edit not found|message can't be edited|message to be edited not found/i.test(desc)) {
          return false;
        }
        return false;
      }
    }
    try {
      const sent = await bot.sendMessage(chatId, text, { parse_mode: 'HTML' });
      if (sent?.message_id) encProgressState.set(`${chatId}:${sent.message_id}`, text);
      return true;
    } catch { return false; }
  } catch { return false; }
}
    
const log = (message, error = null) => {
    const timestamp = new Date().toISOString().replace("T", " ").replace("Z", "");
    const timeStyle = `\x1b[33m[${timestamp}]\x1b[0m`;
    const msgStyle = `\x1b[32m${message}\x1b[0m`;
    console.log(`${timeStyle} ${msgStyle}`);
    if (error) {
        const errorStyle = `\x1b[31m✖ Error: ${error.message || error}\x1b[0m`;
        console.error(`${timeStyle} ${errorStyle}`);
        if (error.stack) console.error(`\x1b[90m${error.stack}\x1b[0m`);
    }
};

const obfuscateTimeLocked = async (fileContent, days) => {
    const expiryDate = new Date();
    expiryDate.setDate(expiryDate.getDate() + parseInt(days));
    const expiryTimestamp = expiryDate.getTime();
    try {
        const obfuscated = await JsConfuser.obfuscate(
            `(function(){const expiry=${expiryTimestamp};if(new Date().getTime()>expiry){throw new Error('Script has expired after ${days} days');}${fileContent}})();`,
            {
                target: "node",
                compact: true,
                renameVariables: true,
                renameGlobals: true,
                identifierGenerator: "randomized",
                stringCompression: true,
                stringConcealing: true,
                stringEncoding: true,
                controlFlowFlattening: 0.75,
                flatten: true,
                shuffle: true,
                rgf: false,
                opaquePredicates: {
                    count: 6,
                    complexity: 4
                },
                dispatcher: true,
                globalConcealing: true,
                lock: {
                    selfDefending: true,
                    antiDebug: (code) => `if(typeof debugger!=='undefined'||process.env.NODE_ENV==='debug')throw new Error('Debugging disabled');${code}`,
                    integrity: true,
                    tamperProtection: (code) => `if(!((function(){return eval('1+1')===2;})()))throw new Error('Tamper detected');${code}`
                },
                duplicateLiteralsRemoval: true
            }
        );
        let obfuscatedCode = obfuscated.code || obfuscated;
        if (typeof obfuscatedCode !== "string") {
            throw new Error("Hasil obfuscation bukan string");
        }
        return obfuscatedCode;
    } catch (error) {
        throw new Error(`Gagal obfuscate: ${error.message}`);
    }
};

// Konstanta fungsi async untuk obfuscation Quantum Vortex Encryption
const obfuscateQuantum = async (fileContent) => {
  
    const generateTimeBasedIdentifier = () => {
        const timeStamp = new Date().getTime().toString().slice(-5);
        const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_$#@&*";
        let identifier = "qV_";
        for (let i = 0; i < 7; i++) {
            identifier += chars[Math.floor((parseInt(timeStamp[i % 5]) + i * 2) % chars.length)];
        }
        return identifier;
    };

    const currentMilliseconds = new Date().getMilliseconds();
    const phantomCode = currentMilliseconds % 3 === 0 ? `if(Math.random()>0.999)console.log('PhantomTrigger');` : "";

    try {
        const obfuscated = await JsConfuser.obfuscate(fileContent + phantomCode, {
            target: "node",
            compact: true,
            renameVariables: true,
            renameGlobals: true,
            identifierGenerator: generateTimeBasedIdentifier,
            stringCompression: true,
            stringConcealing: false,
            stringEncoding: true,
            controlFlowFlattening: 0.85, 
            flatten: true,
            shuffle: true,
            rgf: true,
            opaquePredicates: {
                count: 8, 
                complexity: 5
            },
            dispatcher: true,
            globalConcealing: true,
            lock: {
                selfDefending: true,
                antiDebug: (code) => `if(typeof debugger!=='undefined'||(typeof process!=='undefined'&&process.env.NODE_ENV==='debug'))throw new Error('Debugging disabled');${code}`,
                integrity: true,
                tamperProtection: (code) => `if(!((function(){return eval('1+1')===2;})()))throw new Error('Tamper detected');${code}`
            },
            duplicateLiteralsRemoval: true
        });
        let obfuscatedCode = obfuscated.code || obfuscated;
        if (typeof obfuscatedCode !== "string") {
            throw new Error("Hasil obfuscation bukan string");
        }
        // Self-evolving code dengan XOR dinamis
        const key = currentMilliseconds % 256;
        obfuscatedCode = `(function(){let k=${key};return function(c){return c.split('').map((x,i)=>String.fromCharCode(x.charCodeAt(0)^(k+(i%16)))).join('');}('${obfuscatedCode}');})()`;
        return obfuscatedCode;
    } catch (error) {
        throw new Error(`Gagal obfuscate: ${error.message}`);
    }
};

// Konfigurasi obfuscation untuk Siu + Calcrick style dengan keamanan ekstrem
const getSiuCalcrickObfuscationConfig = () => {
    const generateSiuCalcrickName = () => {
        // Identifier generator pseudo-random tanpa crypto
        const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        let randomPart = "";
        for (let i = 0; i < 6; i++) { // 6 karakter untuk keseimbangan
            randomPart += chars[Math.floor(Math.random() * chars.length)];
        }
        return `气CalceKarik和SiuSiu无${randomPart}`;
    };

    return {
    target: "node",
    compact: true,
    renameVariables: true,
    renameGlobals: true,
    identifierGenerator: generateSiuCalcrickName,
    stringCompression: true,       
        stringEncoding: true,           
        stringSplitting: true,      
    controlFlowFlattening: 0.95,
    shuffle: true,
        rgf: false,
        flatten: true,
    duplicateLiteralsRemoval: true,
    deadCode: true,
    calculator: true,
    opaquePredicates: true,
    lock: {
        selfDefending: true,
        antiDebug: true,
        integrity: true,
        tamperProtection: true
        }
    };
};

// Konfigurasi obfuscation untuk Nebula style dengan banyak opsi aktif
const getNebulaObfuscationConfig = () => {
    const generateNebulaName = () => {
        // Identifier generator pseudo-random tanpa crypto atau timeHash
        const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        const prefix = "NX";
        let randomPart = "";
        for (let i = 0; i < 4; i++) {
            randomPart += chars[Math.floor(Math.random() * chars.length)];
        }
        return `${prefix}${randomPart}`;
    };

    return {
        target: "node",
        compact: true,                  // Minimalkan whitespace
        renameVariables: true,          // Rename variabel
        renameGlobals: true,            // Rename global untuk keamanan
        identifierGenerator: generateNebulaName,
        stringCompression: true,        // Kompresi string
        stringConcealing: false,         // Sembunyikan string
        stringEncoding: true,           // Enkripsi string
        stringSplitting: false,          // Pecah string untuk kebingungan
        controlFlowFlattening: 0.75,     // Aktif dengan intensitas sedang
        flatten: true,                  // Ratakan struktur kode
        shuffle: true,                  // Acak urutan eksekusi
        rgf: true,                      // Randomized Global Functions
        deadCode: true,                 // Tambah kode mati untuk kebingungan
        opaquePredicates: true,         // Predikat buram
        dispatcher: true,               // Acak eksekusi fungsi
        globalConcealing: true,         // Sembunyikan variabel global
        objectExtraction: true,         // Ekstrak objek untuk kebingungan
        duplicateLiteralsRemoval: true,// Pertahankan duplikat untuk kebingungan
        lock: {
            selfDefending: true,        // Lindungi dari modifikasi
            antiDebug: true,            // Cegah debugging
            integrity: true,            // Pastikan integritas
            tamperProtection: true      // Lindungi dari tampering
        }
    };
};

// Fungsi invisible encoding yang efisien dan kecil
function encodeInvisible(text) {
    try {
        // Kompresi kode dengan menghapus spasi berlebih
        const compressedText = text.replace(/\s+/g, ' ').trim();
        // Gunakan base64 untuk efisiensi
        const base64Text = Buffer.from(compressedText).toString('base64');
        // Tambahkan penanda invisible di awal
        return '\u200B' + base64Text; // Hanya penanda awal untuk invisibility minimal
    } catch (e) {
        log("Gagal encode invisible", e);
        return Buffer.from(text).toString('base64'); // Fallback ke base64
    }
}

// Konfigurasi obfuscation untuk Nova style
const getNovaObfuscationConfig = () => {
    const generateNovaName = () => {
        // Identifier generator unik dan keren
        const prefixes = ["nZ", "nova", "nx"];
        const randomPrefix = prefixes[Math.floor(Math.random() * prefixes.length)];
        const hash = crypto.createHash('sha256')
            .update(crypto.randomBytes(8))
            .digest('hex')
            .slice(0, 6); // Ambil 6 karakter pertama dari hash SHA-256
        const suffix = Math.random().toString(36).slice(2, 5); // Sufiks acak 3 karakter
        return `${randomPrefix}_${hash}_${suffix}`;
    };

    return {
        target: "node",
        compact: true,
        renameVariables: true,
        renameGlobals: true,
        identifierGenerator: generateNovaName, 
        stringCompression: true,
        stringConcealing: true,
        stringEncoding: true,
        stringSplitting: false,
        controlFlowFlattening: 0.5, 
        flatten: true,
        shuffle: true,
        rgf: false,
        deadCode: false, 
        opaquePredicates: true,
        dispatcher: true,
        globalConcealing: true,
        objectExtraction: true,
        duplicateLiteralsRemoval: true,
        lock: {
            selfDefending: true,
            antiDebug: true,
            integrity: true,
            tamperProtection: true
        }
    };
};

// Fungsi decode invisible yang efisien
function decodeInvisible(encodedText) {
    try {
        if (!encodedText.startsWith('\u200B')) return encodedText; // Fallback jika tidak ada penanda
        const base64Text = encodedText.slice(1); // Hapus penanda invisible
        return Buffer.from(base64Text, 'base64').toString('utf-8');
    } catch (e) {
        log("Gagal decode invisible", e);
        return encodedText; // Fallback ke teks asli
    }
}

// Konfigurasi obfuscation untuk X style
const getXObfuscationConfig = () => {
    const generateXName = () => {
        const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        return "xZ" + crypto.randomUUID().slice(0, 4); // Nama pendek dan unik
    };

    return {
        target: "node",
        compact: true,
        renameVariables: true,
        renameGlobals: true,
        identifierGenerator: () => generateXName(),
        stringCompression: true,
        stringConcealing: true,
        stringEncoding: true,
        stringSplitting: false,
        controlFlowFlattening: 0.5, // Stabil dan aman
        flatten: true,
        shuffle: true,
        rgf: true,
        deadCode: false, // Nonaktif untuk ukuran kecil
        opaquePredicates: true,
        dispatcher: true,
        globalConcealing: true,
        objectExtraction: true,
        duplicateLiteralsRemoval: true,
        lock: {
            selfDefending: true,
            antiDebug: true,
            integrity: true,
            tamperProtection: true
        }
    };
};

// Konfigurasi obfuscation untuk Max style dengan intensitas yang dapat diatur
const getMaxObfuscationConfig = (intensity) => {
    const generateMaxName = () => {
        // Nama variabel unik: prefiks "mX" + kombinasi acak
        const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        const length = Math.floor(Math.random() * 4) + 4; // 4-7 karakter
        let name = "mX";
        for (let i = 0; i < length; i++) {
            name += chars[Math.floor(Math.random() * chars.length)];
        }
        return name;
    };

    // Skala intensitas dari 1-10 ke 0.1-1.0 untuk controlFlowFlattening
    const flatteningLevel = intensity / 10;

    return {
        target: "node",
        compact: true,
        renameVariables: true,
        renameGlobals: true,
        identifierGenerator: () => generateMaxName(),
        stringCompression: true, // Kompresi string
        stringConcealing: true, // Menyembunyikan string
        stringEncoding: true, // Enkripsi string
        stringSplitting: true, // Memecah string
        controlFlowFlattening: flatteningLevel, // Intensitas berdasarkan input (0.1-1.0)
        flatten: true, // Meratakan struktur kontrol
        shuffle: true, // Mengacak urutan
        rgf: true, // Randomized Global Functions
        calculator: true, // Mengacak operasi matematika
        deadCode: true,
        opaquePredicates: true,
        dispatcher: true, // Mengacak eksekusi
        globalConcealing: true, // Menyembunyikan variabel global
        objectExtraction: true, // Mengekstrak objek untuk kebingungan
        duplicateLiteralsRemoval: false, // Menjaga redundansi
        lock: {
            selfDefending: true,
            antiDebug: true,
            integrity: true,
            tamperProtection: true
        }
    };
};


// Konfigurasi obfuscation untuk Strong style (diperbaiki berdasarkan dokumentasi)
const getStrongObfuscationConfig = () => {
    return {
        target: "node",
        compact: true,
        renameVariables: true,
        renameGlobals: true,
        identifierGenerator: "randomized", // Valid: menghasilkan nama acak
        stringEncoding: true, // Valid: mengenkripsi string
        stringSplitting: true, // Valid: memecah string
        controlFlowFlattening: 0.75, // Valid: mengacak alur kontrol
        duplicateLiteralsRemoval: true, // Valid: menghapus literal duplikat
        calculator: true, // Valid: mengacak operasi matematika
        dispatcher: true, // Valid: mengacak eksekusi dengan dispatcher
        deadCode: true, // Valid: menambahkan kode mati
        opaquePredicates: true, // Valid: menambahkan predikat buram
        lock: {
            selfDefending: true, // Valid: mencegah modifikasi
            antiDebug: true, // Valid: mencegah debugging
            integrity: true, // Valid: memastikan integritas
            tamperProtection: true // Valid: perlindungan tamper
        }
    };
};

// Konfigurasi obfuscation untuk Big style (ukuran file besar)
const getBigObfuscationConfig = () => {
    const generateBigName = () => {
        const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        const length = Math.floor(Math.random() * 5) + 5; // Nama 5-9 karakter
        let name = "";
        for (let i = 0; i < length; i++) {
            name += chars[Math.floor(Math.random() * chars.length)];
        }
        return name;
    };

    return {
        target: "node",
        compact: true,
        renameVariables: true,
        renameGlobals: true,
        identifierGenerator: () => generateBigName(),
        stringEncoding: true,
        stringSplitting: true,
        controlFlowFlattening: 0.75, // Stabil dan kuat
        shuffle: true,
        duplicateLiteralsRemoval: true,
        deadCode: true,
        opaquePredicates: true,
        lock: {
            selfDefending: true,
            antiDebug: true,
            integrity: true,
            tamperProtection: true
        }
    };
};

// Konfigurasi obfuscation untuk Invisible style (diperbaiki)
const getInvisObfuscationConfig = () => {
    const generateInvisName = () => {
        const length = Math.floor(Math.random() * 4) + 3; // Panjang 3-6 karakter
        let name = "";
        for (let i = 0; i < length; i++) {
            name += "_"; // Menggunakan underscore untuk "invis" yang aman
        }
        // Tambahkan variasi acak agar unik
        return name + Math.random().toString(36).substring(2, 5);
    };

    return {
        target: "node",
        compact: true,
        renameVariables: true,
        renameGlobals: true,
        identifierGenerator: () => generateInvisName(),
        stringEncoding: true,
        stringSplitting: true,
        controlFlowFlattening: 0.95,
        shuffle: true,
        duplicateLiteralsRemoval: true,
        deadCode: true,
        calculator: true,
        opaquePredicates: true,
        lock: {
            selfDefending: true,
            antiDebug: true,
            integrity: true,
            tamperProtection: true
        }
    };
};

// Konfigurasi obfuscation untuk Stealth style (diperbaiki untuk stabilitas)
const getStealthObfuscationConfig = () => {
    const generateStealthName = () => {
        const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        const length = Math.floor(Math.random() * 3) + 1; // Nama pendek 1-3 karakter
        let name = "";
        for (let i = 0; i < length; i++) {
            name += chars[Math.floor(Math.random() * chars.length)];
        }
        return name;
    };

    return {
        target: "node",
        compact: true,
        renameVariables: true,
        renameGlobals: true,
        identifierGenerator: () => generateStealthName(),
        stringEncoding: true,
        stringSplitting: true,
        controlFlowFlattening: 0.75, // Dikurangi untuk stabilitas
        shuffle: true,
        duplicateLiteralsRemoval: true,
        deadCode: true,
        opaquePredicates: true,
        lock: {
            selfDefending: true,
            antiDebug: true,
            integrity: true,
            tamperProtection: true
        }
    };
};

// Konfigurasi obfuscation untuk Custom style (dengan nama kustom)
const getCustomObfuscationConfig = (customName) => {
    const generateCustomName = () => {
        const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        const randomSuffixLength = Math.floor(Math.random() * 3) + 2; // Sufiks acak 2-4 karakter
        let suffix = "";
        for (let i = 0; i < randomSuffixLength; i++) {
            suffix += chars[Math.floor(Math.random() * chars.length)];
        }
        // Gunakan nama kustom sebagai prefiks, tambahkan sufiks acak
        return `${customName}_${suffix}`;
    };

    return {
        target: "node",
        compact: true,
        renameVariables: true,
        renameGlobals: true,
        identifierGenerator: () => generateCustomName(),
        stringEncoding: true,
        stringSplitting: true,
        controlFlowFlattening: 0.75, // Stabil dan kuat
        shuffle: true,
        duplicateLiteralsRemoval: true,
        deadCode: true,
        opaquePredicates: true,
        lock: {
            selfDefending: true,
            antiDebug: true,
            integrity: true,
            tamperProtection: true
        }
    };
};

// Konfigurasi obfuscation untuk Mandarin style (diperkuat dan aman)
const getMandarinObfuscationConfig = () => {
    const mandarinChars = [
        "龙", "虎", "风", "云", "山", "河", "天", "地", "雷", "电",
        "火", "水", "木", "金", "土", "星", "月", "日", "光", "影",
        "峰", "泉", "林", "海", "雪", "霜", "雾", "冰", "焰", "石"
    ];

    const generateMandarinName = () => {
        const length = Math.floor(Math.random() * 4) + 3;
        let name = "";
        for (let i = 0; i < length; i++) {
            name += mandarinChars[Math.floor(Math.random() * mandarinChars.length)];
        }
        return name;
    };

    return {
        target: "node",
        compact: true,
        renameVariables: true,
        renameGlobals: true,
        identifierGenerator: () => generateMandarinName(),
        stringEncoding: true,
        stringSplitting: true,
        controlFlowFlattening: 0.95,
        shuffle: true,
        duplicateLiteralsRemoval: true,
        deadCode: true,
        calculator: true,
        opaquePredicates: true,
        lock: {
            selfDefending: true,
            antiDebug: true,
            integrity: true,
            tamperProtection: true
        }
    };
};

// Konfigurasi obfuscation untuk Arab style (diperkuat dan aman)
const getArabObfuscationConfig = () => {
    const arabicChars = [
        "أ", "ب", "ت", "ث", "ج", "ح", "خ", "د", "ذ", "ر",
        "ز", "س", "ش", "ص", "ض", "ط", "ظ", "ع", "غ", "ف",
        "ق", "ك", "ل", "م", "ن", "ه", "و", "ي"
    ];

    const generateArabicName = () => {
        const length = Math.floor(Math.random() * 4) + 3;
        let name = "";
        for (let i = 0; i < length; i++) {
            name += arabicChars[Math.floor(Math.random() * arabicChars.length)];
        }
        return name;
    };

    return {
        target: "node",
        compact: true,
        renameVariables: true,
        renameGlobals: true,
        identifierGenerator: () => generateArabicName(),
        stringEncoding: true,
        stringSplitting: true,
        controlFlowFlattening: 0.95,
        shuffle: true,
        duplicateLiteralsRemoval: true,
        deadCode: true,
        calculator: true,
        opaquePredicates: true,
        lock: {
            selfDefending: true,
            antiDebug: true,
            integrity: true,
            tamperProtection: true
        }
    };
};

const getJapanxArabObfuscationConfig = () => {
    const japaneseXArabChars = [
        "あ", "い", "う", "え", "お", "か", "き", "く", "け", "こ",
        "さ", "し", "す", "せ", "そ", "た", "ち", "つ", "て", "と",
        "な", "に", "ぬ", "ね", "の", "は", "ひ", "ふ", "へ", "ほ",
        "ま", "み", "む", "め", "も", "や", "ゆ", "よ","أ", "ب", "ت", "ث", "ج", "ح", "خ", "د", "ذ", "ر",
        "ز", "س", "ش", "ص", "ض", "ط", "ظ", "ع", "غ", "ف",
        "ق", "ك", "ل", "م", "ن", "ه", "و", "ي","ら", "り", "る", "れ", "ろ", "わ", "を", "ん" 
    ];

    const generateJapaneseXArabName = () => {
        const length = Math.floor(Math.random() * 4) + 3; // Panjang 3-6 karakter
        let name = "";
        for (let i = 0; i < length; i++) {
            name += japaneseXArabChars[Math.floor(Math.random() * japaneseXArabChars.length)];
        }
        return name;
    };

    return {
        target: "node",
        compact: true,
        renameVariables: true,
        renameGlobals: true,
        identifierGenerator: () => generateJapaneseXArabName(),
        stringCompression: true, // Kompresi string
        stringConcealing: true, // Menyembunyikan string
        stringEncoding: true, // Enkripsi string
        stringSplitting: true, // Memecah string        
        controlFlowFlattening: 0.95, // Sedikit lebih rendah untuk variasi
        flatten: true,              // Metode baru: mengganti struktur kontrol
        shuffle: true,
        rgf: false,
        dispatcher: true,
        duplicateLiteralsRemoval: true,
        deadCode: true,
        calculator: true,
        opaquePredicates: true,
        lock: {
            selfDefending: true,
            antiDebug: true,
            integrity: true,
            tamperProtection: true
        }
    };
};

const getUltraObfuscationConfig = () => {
    const generateUltraName = () => {
        const chars = "abcdefghijklmnopqrstuvwxyz";
        const numbers = "0123456789";
        const randomNum = numbers[Math.floor(Math.random() * numbers.length)];
        const randomChar = chars[Math.floor(Math.random() * chars.length)];
        return `z${randomNum}${randomChar}${Math.random().toString(36).substring(2, 6)}`;
    };

    return {
        target: "node",
        compact: true,
        renameVariables: true,
        renameGlobals: true,
        identifierGenerator: () => generateUltraName(),
        stringCompression: true, // Kompresi string untuk keamanan tinggi
        stringEncoding: true,
        stringSplitting: true,
        controlFlowFlattening: 0.9,
        flatten: true,
        shuffle: true,
        rgf: true, // Randomized Global Functions
        deadCode: true,
        opaquePredicates: true,
        dispatcher: true,
        lock: {
            selfDefending: true,
            antiDebug: true,
            integrity: true,
            tamperProtection: true
        }
    };
};

// Konfigurasi obfuscation untuk Japan style (diperkuat dan aman)
const getJapanObfuscationConfig = () => {
    const japaneseChars = [
        "あ", "い", "う", "え", "お", "か", "き", "く", "け", "こ",
        "さ", "し", "す", "せ", "そ", "た", "ち", "つ", "て", "と",
        "な", "に", "ぬ", "ね", "の", "は", "ひ", "ふ", "へ", "ほ",
        "ま", "み", "む", "め", "も", "や", "ゆ", "よ",
        "ら", "り", "る", "れ", "ろ", "わ", "を", "ん"
    ];

    const generateJapaneseName = () => {
        const length = Math.floor(Math.random() * 4) + 3; // Panjang 3-6 karakter
        let name = "";
        for (let i = 0; i < length; i++) {
            name += japaneseChars[Math.floor(Math.random() * japaneseChars.length)];
        }
        return name;
    };

    return {
        target: "node",
        compact: true,
        renameVariables: true,
        renameGlobals: true,
        identifierGenerator: () => generateJapaneseName(),
        stringEncoding: true,
        stringSplitting: true,
        controlFlowFlattening: 0.9, // Sedikit lebih rendah untuk variasi
        flatten: true,              // Metode baru: mengganti struktur kontrol
        shuffle: true,
        duplicateLiteralsRemoval: true,
        deadCode: true,
        calculator: true,
        opaquePredicates: true,
        lock: {
            selfDefending: true,
            antiDebug: true,
            integrity: true,
            tamperProtection: true
        }
    };
};

// Konfigurasi obfuscation untuk /encnew (diperkuat dan aman)
const getNewObfuscationConfig = () => ({
    target: "node",
    compact: true,
    renameVariables: true,
    renameGlobals: true,
    identifierGenerator: "hexadecimal",
    stringEncoding: true,
    stringSplitting: true,
    controlFlowFlattening: 0.95,
    shuffle: true,
    duplicateLiteralsRemoval: true,
    deadCode: true,
    calculator: true,
    opaquePredicates: true,
    lock: {
        selfDefending: true,
        antiDebug: true,
        integrity: true,
        tamperProtection: true
    }
});

    // enc
command(/^\/enc(?:\s+(low|medium|high))?$/, async (msg, match) => {
    const chatId = msg.chat.id;

    if (!msg.reply_to_message || !msg.reply_to_message.document) {
        return bot.sendMessage(chatId, "❌ *Error:* Balas file .js dengan `/enc [level]`!", { parse_mode: "Markdown" });
    }

    const file = msg.reply_to_message.document;
    const encryptionLevel = match[1] && ["low", "medium", "high"].includes(match[1]) ? match[1] : "high";

    // ZIP: analisis isi dulu, lalu user memilih ENC semua atau file tertentu.
    if (/\.zip$/i.test(file.file_name || '')) {
        try {
            return await prepareZipSession(bot, msg, file, encryptionLevel);
        } catch (e) {
            return bot.sendMessage(chatId, `❌ ${html(e.message)}`, { parse_mode: 'HTML' });
        }
    }

    if (!/\.js$/i.test(file.file_name || '')) {
        return bot.sendMessage(chatId, "❌ Balas file <b>.js</b> atau <b>.zip</b> dengan <code>/enc [level]</code>.", { parse_mode: "HTML" });
    }
    const encryptedPath = path.join(ENC_TMP_DIR, `encrypted-${file.file_name}`);
    let progressMessage = null;

    try {
        progressMessage = await bot.sendMessage(
            chatId,
            `<b>YOEN YOEN ENC</b>\n` +
            `<blockquote expandable>` +
            `File   : <code>${String(file.file_name).replace(/[&<>]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;"}[c]))}</code>\n` +
            `Mode   : <b>${encryptionLevel.toUpperCase()}</b>\n` +
            `Status : Menyiapkan enkripsi...` +
            `</blockquote>\n` +
            `<code>${createProgressBar(1)}</code>`,
            { parse_mode: "HTML" }
        );

        const fileLink = await bot.getFileLink(file.file_id);
        log(`Mengunduh file: ${file.file_name}`);
        await updateProgress(bot, chatId, progressMessage.message_id, 10, "Mengunduh");

        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(bot, chatId, progressMessage.message_id, 20, "Mengunduh Selesai");

        log(`Memvalidasi kode: ${file.file_name}`);
        await updateProgress(bot, chatId, progressMessage.message_id, 30, "Memvalidasi Kode");
        try {
            new Function(fileContent);
        } catch (syntaxError) {
            throw new Error(`Kode tidak valid: ${syntaxError.message}`);
        }

        log(`Mengenkripsi file dengan level: ${encryptionLevel}`);
        await updateProgress(bot, chatId, progressMessage.message_id, 40, "Inisialisasi Hardened Enkripsi");

        const obfuscated = await JsConfuser.obfuscate(fileContent, getObfuscationConfig(encryptionLevel));
        await updateProgress(bot, chatId, progressMessage.message_id, 60, "Transformasi Kode");

        await fs.writeFile(encryptedPath, obfuscated.code);
        await updateProgress(bot, chatId, progressMessage.message_id, 80, "Finalisasi Enkripsi");

        log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
        try {
            new Function(obfuscated.code);
        } catch (postObfuscationError) {
            throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
        }

        log(`Mengirim file terenkripsi: encrypted-${file.file_name}`);
        await updateProgress(bot, chatId, progressMessage.message_id, 95, `Menyiapkan hasil ENC (${encryptionLevel})`);
        await bot.sendDocument(chatId, encryptedPath, {
            reply_to_message_id: msg.message_id,
            caption: `<b>YOEN YOEN ENC SELESAI</b>\n<blockquote expandable>Mode   : <b>${encryptionLevel.toUpperCase()}</b>\nFile   : <code>${String(file.file_name).replace(/[&<>]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;"}[c]))}</code>\nStatus : Berhasil diproses.</blockquote>`,
            parse_mode: "HTML",
            filename: `enc-${file.file_name}`
        });

        await updateProgress(bot, chatId, progressMessage.message_id, 100, `ENC (${encryptionLevel}) selesai`);

        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
            // ignore delete errors
        }

        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
            log(`file sementara dihapus: ${encryptedPath}`);
        }
    } catch (error) {
        log("Kesalahan saat mengenkripsi", error);

        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
            // ignore
        }

        await bot.sendMessage(
            chatId,
            `❌ ${error.message || "Tidak diketahui"}`,
            { parse_mode: "Markdown" }
        );

        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
            log(`File sementara dihapus setelah error: ${encryptedPath}`);
        }
    }
});

    // enc eval
command(/^\/enceval(?:\s+(low|medium|high))?$/, async (msg, match) => {
    const chatId = msg.chat.id;

    if (!msg.reply_to_message || !msg.reply_to_message.document) {
        return bot.sendMessage(chatId, "❌ *Error:* Balas file .js dengan `/enceval [level]`!", { parse_mode: "Markdown" });
    }

    const file = msg.reply_to_message.document;

    if (!file.file_name.endsWith(".js")) {
        return bot.sendMessage(chatId, "❌ *Error:* Hanya file .js yang didukung!", { parse_mode: "Markdown" });
    }

    const encryptionLevel = match[1] && ["low", "medium", "high"].includes(match[1]) ? match[1] : "high";
    const encryptedPath = path.join(ENC_TMP_DIR, `eval-encrypted-${file.file_name}`);
    let progressMessage = null;

    try {
        progressMessage = await bot.sendMessage(
            chatId,
            "```yoennakbobo\n" +
            "🔒 Starting Encrypted...\n" +
            ` ⚙️ Memulai Evaluasi (${encryptionLevel}) (1%)\n` +
            ` ${createProgressBar(1)}\n` +
            "```\n",
            { parse_mode: "Markdown" }
        );

        const fileLink = await bot.getFileLink(file.file_id);
        log(`Mengunduh file untuk evaluasi: ${file.file_name}`);
        await updateProgress(bot, chatId, progressMessage.message_id, 10, "Mengunduh");

        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(bot, chatId, progressMessage.message_id, 20, "Mengunduh Selesai");

        let evalResult;
        try {
            await updateProgress(bot, chatId, progressMessage.message_id, 30, "Mengevaluasi Kode Asli");
            evalResult = eval(fileContent);
            if (typeof evalResult === "function") {
                evalResult = "Function detected (cannot display full output)";
            } else if (evalResult === undefined) {
                evalResult = "No return value";
            }
        } catch (evalError) {
            evalResult = `Evaluation error: ${evalError.message}`;
        }

        log(`Memvalidasi kode: ${file.file_name}`);
        await updateProgress(bot, chatId, progressMessage.message_id, 40, "Memvalidasi Kode");
        try {
            new Function(fileContent);
        } catch (syntaxError) {
            throw new Error(`Kode tidak valid: ${syntaxError.message}`);
        }

        log(`Mengenkripsi dan mengevaluasi file dengan level: ${encryptionLevel}`);
        await updateProgress(bot, chatId, progressMessage.message_id, 50, "Inisialisasi Hardened Enkripsi");

        const obfuscated = await JsConfuser.obfuscate(fileContent, getObfuscationConfig(encryptionLevel));
        await updateProgress(bot, chatId, progressMessage.message_id, 70, "Transformasi Kode");

        await fs.writeFile(encryptedPath, obfuscated.code);
        await updateProgress(bot, chatId, progressMessage.message_id, 90, "Finalisasi Enkripsi");

        log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
        try {
            new Function(obfuscated.code);
        } catch (postObfuscationError) {
            throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
        }

        log(`Mengirim file terenkripsi dan hasil evaluasi: ${file.file_name}`);
        await bot.sendMessage(
            chatId,
            `*Original Code Result:* \n\`\`\`javascript\n${evalResult}\n\`\`\`\n`,
            { parse_mode: "Markdown" }
        );

        await bot.sendDocument(chatId, encryptedPath, {
            reply_to_message_id: msg.message_id,
            parse_mode: "Markdown",
            filename: `eval-enc-${file.file_name}`
        });

        await updateProgress(bot, chatId, progressMessage.message_id, 100, `Evaluasi & Enkripsi (${encryptionLevel}) Selesai`);

        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
        }

        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
            log(`file sementara dihapus: ${encryptedPath}`);
        }
    } catch (error) {
        log("Kesalahan saat mengenkripsi/evaluasi", error);

        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
        }

        await bot.sendMessage(
            chatId,
            `❌ ${error.message || "Tidak diketahui"}`,
            { parse_mode: "Markdown" }
        );

        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
            log(`File sementara dihapus setelah error: ${encryptedPath}`);
        }
    }
});

    // enc china
command(/^\/encchina$/, async (msg) => {
    const chatId = msg.chat.id;

    if (!msg.reply_to_message || !msg.reply_to_message.document) {
        return bot.sendMessage(chatId, "❌ *Error:* Balas file .js dengan `/encchina`!", { parse_mode: "Markdown" });
    }

    const file = msg.reply_to_message.document;

    if (!file.file_name.endsWith(".js")) {
        return bot.sendMessage(chatId, "❌ *Error:* Hanya file .js yang didukung!", { parse_mode: "Markdown" });
    }

    const encryptedPath = path.join(ENC_TMP_DIR, `china-encrypted-${file.file_name}`);
    let progressMessage = null;

    try {
        progressMessage = await bot.sendMessage(
            chatId,
            "```yoennakbobo\n" +
            "🔒 Starting Encrypted...\n" +
            ` ⚙️ Memulai (Hardened Mandarin) (1%)\n` +
            ` ${createProgressBar(1)}\n` +
            "```\n",
            { parse_mode: "Markdown" }
        );

        const fileLink = await bot.getFileLink(file.file_id);
        log(`Mengunduh file untuk Mandarin obfuscation: ${file.file_name}`);
        await updateProgress(bot, chatId, progressMessage.message_id, 10, "Mengunduh");

        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(bot, chatId, progressMessage.message_id, 20, "Mengunduh Selesai");

        log(`Memvalidasi kode: ${file.file_name}`);
        await updateProgress(bot, chatId, progressMessage.message_id, 30, "Memvalidasi Kode");
        try {
            new Function(fileContent);
        } catch (syntaxError) {
            throw new Error(`Kode tidak valid: ${syntaxError.message}`);
        }

        log(`Mengenkripsi file dengan gaya Mandarin yang diperkuat`);
        await updateProgress(bot, chatId, progressMessage.message_id, 40, "Inisialisasi Hardened Mandarin Obfuscation");

        const obfuscated = await JsConfuser.obfuscate(fileContent, getMandarinObfuscationConfig());
        await updateProgress(bot, chatId, progressMessage.message_id, 60, "Transformasi Kode");

        await fs.writeFile(encryptedPath, obfuscated.code);
        await updateProgress(bot, chatId, progressMessage.message_id, 80, "Finalisasi Enkripsi");

        log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
        try {
            new Function(obfuscated.code);
        } catch (postObfuscationError) {
            throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
        }

        log(`Mengirim file terenkripsi gaya Mandarin: ${file.file_name}`);
        await bot.sendDocument(chatId, encryptedPath, {
            reply_to_message_id: msg.message_id,
            parse_mode: "Markdown",
            filename: `china-enc-${file.file_name}`
        });

        await updateProgress(bot, chatId, progressMessage.message_id, 100, "Hardened Mandarin Obfuscation Selesai");

        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
        }

        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
            log(`file sementara dihapus: ${encryptedPath}`);
        }
    } catch (error) {
        log("Kesalahan saat Mandarin obfuscation", error);

        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
        }

        await bot.sendMessage(
            chatId,
            `❌ ${error.message || "Tidak diketahui"}`,
            { parse_mode: "Markdown" }
        );

        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
            log(`File sementara dihapus setelah error: ${encryptedPath}`);
        }
    }
});
    
    // enc arab
command(/^\/encarab$/, async (msg) => {
    const chatId = msg.chat.id;

    if (!msg.reply_to_message || !msg.reply_to_message.document) {
        return bot.sendMessage(chatId, "❌ *Error:* Balas file .js dengan `/encarab`!", { parse_mode: "Markdown" });
    }

    const file = msg.reply_to_message.document;

    if (!file.file_name.endsWith(".js")) {
        return bot.sendMessage(chatId, "❌ *Error:* Hanya file .js yang didukung!", { parse_mode: "Markdown" });
    }

    const encryptedPath = path.join(ENC_TMP_DIR, `arab-encrypted-${file.file_name}`);
    let progressMessage = null;

    try {
        progressMessage = await bot.sendMessage(
            chatId,
            "```yoennakbobo\n" +
            "🔒 Starting Encrypted...\n" +
            ` ⚙️ Memulai (Hardened Arab) (1%)\n` +
            ` ${createProgressBar(1)}\n` +
            "```\n",
            { parse_mode: "Markdown" }
        );

        const fileLink = await bot.getFileLink(file.file_id);
        log(`Mengunduh file untuk Arab obfuscation: ${file.file_name}`);
        await updateProgress(bot, chatId, progressMessage.message_id, 10, "Mengunduh");

        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(bot, chatId, progressMessage.message_id, 20, "Mengunduh Selesai");

        log(`Memvalidasi kode: ${file.file_name}`);
        await updateProgress(bot, chatId, progressMessage.message_id, 30, "Memvalidasi Kode");
        try {
            new Function(fileContent);
        } catch (syntaxError) {
            throw new Error(`Kode tidak valid: ${syntaxError.message}`);
        }

        log(`Mengenkripsi file dengan gaya Arab yang diperkuat`);
        await updateProgress(bot, chatId, progressMessage.message_id, 40, "Inisialisasi Hardened Arab Obfuscation");

        const obfuscated = await JsConfuser.obfuscate(fileContent, getArabObfuscationConfig());
        await updateProgress(bot, chatId, progressMessage.message_id, 60, "Transformasi Kode");

        await fs.writeFile(encryptedPath, obfuscated.code);
        await updateProgress(bot, chatId, progressMessage.message_id, 80, "Finalisasi Enkripsi");

        log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
        try {
            new Function(obfuscated.code);
        } catch (postObfuscationError) {
            throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
        }

        log(`Mengirim file terenkripsi gaya Arab: ${file.file_name}`);
        await bot.sendDocument(chatId, encryptedPath, {
            reply_to_message_id: msg.message_id,
            parse_mode: "Markdown",
            filename: `arab-enc-${file.file_name}`
        });

        await updateProgress(bot, chatId, progressMessage.message_id, 100, "Hardened Arab Obfuscation Selesai");

        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
        }

        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
            log(`file sementara dihapus: ${encryptedPath}`);
        }
    } catch (error) {
        log("Kesalahan saat Arab obfuscation", error);

        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
        }

        await bot.sendMessage(
            chatId,
            `❌ ${error.message || "Tidak diketahui"}`,
            { parse_mode: "Markdown" }
        );

        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
            log(`File sementara dihapus setelah error: ${encryptedPath}`);
        }
    }
});
    
    // enc japan
command(/^\/encjapan$/, async (msg) => {
    const chatId = msg.chat.id;

    if (!msg.reply_to_message || !msg.reply_to_message.document) {
        return bot.sendMessage(chatId, "❌ *Error:* Balas file .js dengan `/encjapan`!", { parse_mode: "Markdown" });
    }

    const file = msg.reply_to_message.document;

    if (!file.file_name.endsWith(".js")) {
        return bot.sendMessage(chatId, "❌ *Error:* Hanya file .js yang didukung!", { parse_mode: "Markdown" });
    }

    const encryptedPath = path.join(ENC_TMP_DIR, `japan-encrypted-${file.file_name}`);
    let progressMessage = null;

    try {
        progressMessage = await bot.sendMessage(
            chatId,
            "```yoennakbobo\n" +
            "🔒 Starting Encrypted...\n" +
            ` ⚙️ Memulai (Hardened Japan) (1%)\n` +
            ` ${createProgressBar(1)}\n` +
            "```\n",
            { parse_mode: "Markdown" }
        );

        const fileLink = await bot.getFileLink(file.file_id);
        log(`Mengunduh file untuk Japan obfuscation: ${file.file_name}`);
        await updateProgress(bot, chatId, progressMessage.message_id, 10, "Mengunduh");

        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(bot, chatId, progressMessage.message_id, 20, "Mengunduh Selesai");

        log(`Memvalidasi kode: ${file.file_name}`);
        await updateProgress(bot, chatId, progressMessage.message_id, 30, "Memvalidasi Kode");
        try {
            new Function(fileContent);
        } catch (syntaxError) {
            throw new Error(`Kode tidak valid: ${syntaxError.message}`);
        }

        log(`Mengenkripsi file dengan gaya Japan yang diperkuat`);
        await updateProgress(bot, chatId, progressMessage.message_id, 40, "Inisialisasi Hardened Japan Obfuscation");

        const obfuscated = await JsConfuser.obfuscate(fileContent, getJapanObfuscationConfig());
        await updateProgress(bot, chatId, progressMessage.message_id, 60, "Transformasi Kode");

        await fs.writeFile(encryptedPath, obfuscated.code);
        await updateProgress(bot, chatId, progressMessage.message_id, 80, "Finalisasi Enkripsi");

        log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
        try {
            new Function(obfuscated.code);
        } catch (postObfuscationError) {
            throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
        }

        log(`Mengirim file terenkripsi gaya Japan: ${file.file_name}`);
        await bot.sendDocument(chatId, encryptedPath, {
            reply_to_message_id: msg.message_id,
            parse_mode: "Markdown",
            filename: `japan-enc-${file.file_name}`
        });

        await updateProgress(bot, chatId, progressMessage.message_id, 100, "Hardened Japan Obfuscation Selesai");

        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
        }

        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
            log(`file sementara dihapus: ${encryptedPath}`);
        }
    } catch (error) {
        log("Kesalahan saat Japan obfuscation", error);

        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
        }

        await bot.sendMessage(
            chatId,
            `❌ ${error.message || "Tidak diketahui"}`,
            { parse_mode: "Markdown" }
        );

        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
            log(`File sementara dihapus setelah error: ${encryptedPath}`);
        }
    }
});
    
    // enc japxab
command(/^\/encjapxab$/, async (msg) => {
    const chatId = msg.chat.id;

    if (!msg.reply_to_message || !msg.reply_to_message.document) {
        return bot.sendMessage(chatId, "❌ *Error:* Balas file .js dengan `/encjapxab`!", { parse_mode: "Markdown" });
    }

    const file = msg.reply_to_message.document;

    if (!file.file_name.endsWith(".js")) {
        return bot.sendMessage(chatId, "❌ *Error:* Hanya file .js yang didukung!", { parse_mode: "Markdown" });
    }

    const encryptedPath = path.join(ENC_TMP_DIR, `japan-arab-encrypted-${file.file_name}`);
    let progressMessage = null;

    try {
        progressMessage = await bot.sendMessage(
            chatId,
            "```yoennakbobo\n" +
            "🔒 Starting Encrypted...\n" +
            ` ⚙️ Memulai (Hardened Japan X Arab) (1%)\n` +
            ` ${createProgressBar(1)}\n` +
            "```\n",
            { parse_mode: "Markdown" }
        );

        const fileLink = await bot.getFileLink(file.file_id);
        await updateProgress(bot, chatId, progressMessage.message_id, 10, "Mengunduh");

        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(bot, chatId, progressMessage.message_id, 20, "Mengunduh Selesai");

        await updateProgress(bot, chatId, progressMessage.message_id, 30, "Memvalidasi Kode");
        try {
            new Function(fileContent);
        } catch (syntaxError) {
            throw new Error(`Kode tidak valid: ${syntaxError.message}`);
        }

        await updateProgress(bot, chatId, progressMessage.message_id, 40, "Inisialisasi Hardened Japan X Arab Obfuscation");

        const obfuscated = await JsConfuser.obfuscate(fileContent, getJapanxArabObfuscationConfig());
        await updateProgress(bot, chatId, progressMessage.message_id, 60, "Transformasi Kode");

        await fs.writeFile(encryptedPath, obfuscated.code);
        await updateProgress(bot, chatId, progressMessage.message_id, 80, "Finalisasi Enkripsi");

        try {
            new Function(obfuscated.code);
        } catch (postObfuscationError) {
            throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
        }

        await bot.sendDocument(chatId, encryptedPath, {
            reply_to_message_id: msg.message_id,
            parse_mode: "Markdown",
            filename: `japan-arab-enc-${file.file_name}`
        });

        await updateProgress(bot, chatId, progressMessage.message_id, 100, "Hardened Japan X Arab Obfuscation Selesai");

        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
        }

        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
        }
    } catch (error) {
        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
        }

        await bot.sendMessage(
            chatId,
            `❌ ${error.message || "Tidak diketahui"}`,
            { parse_mode: "Markdown" }
        );

        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
        }
    }
});
    
    // enc new
command(/^\/encnew$/, async (msg) => {
    const chatId = msg.chat.id;

    if (!msg.reply_to_message || !msg.reply_to_message.document) {
        return bot.sendMessage(chatId, "❌ *Error:* Balas file .js dengan `/encnew`!", { parse_mode: "Markdown" });
    }

    const file = msg.reply_to_message.document;

    if (!file.file_name.endsWith(".js")) {
        return bot.sendMessage(chatId, "❌ *Error:* Hanya file .js yang didukung!", { parse_mode: "Markdown" });
    }

    const encryptedPath = path.join(ENC_TMP_DIR, `new-encrypted-${file.file_name}`);
    let progressMessage = null;

    try {
        progressMessage = await bot.sendMessage(
            chatId,
            "```yoennakbobo\n" +
            "🔒 Starting Encrypted...\n" +
            ` ⚙️ Memulai (Hardened Advanced) (1%)\n` +
            ` ${createProgressBar(1)}\n` +
            "```\n",
            { parse_mode: "Markdown" }
        );

        const fileLink = await bot.getFileLink(file.file_id);
        await updateProgress(bot, chatId, progressMessage.message_id, 10, "Mengunduh");

        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(bot, chatId, progressMessage.message_id, 20, "Mengunduh Selesai");

        await updateProgress(bot, chatId, progressMessage.message_id, 30, "Memvalidasi Kode");
        try {
            new Function(fileContent);
        } catch (syntaxError) {
            throw new Error(`Kode tidak valid: ${syntaxError.message}`);
        }

        await updateProgress(bot, chatId, progressMessage.message_id, 40, "Inisialisasi Hardened Advanced Obfuscation");

        const obfuscated = await JsConfuser.obfuscate(fileContent, getNewObfuscationConfig());
        await updateProgress(bot, chatId, progressMessage.message_id, 60, "Transformasi Kode");

        await fs.writeFile(encryptedPath, obfuscated.code);
        await updateProgress(bot, chatId, progressMessage.message_id, 80, "Finalisasi Enkripsi");

        try {
            new Function(obfuscated.code);
        } catch (postObfuscationError) {
            throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
        }

        await bot.sendDocument(chatId, encryptedPath, {
            reply_to_message_id: msg.message_id,
            parse_mode: "Markdown",
            filename: `new-enc-${file.file_name}`
        });

        await updateProgress(bot, chatId, progressMessage.message_id, 100, "Hardened Advanced Obfuscation Selesai");

        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
        }

        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
        }
    } catch (error) {
        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
        }

        await bot.sendMessage(
            chatId,
            `❌ ${error.message || "Tidak diketahui"}`,
            { parse_mode: "Markdown" }
        );

        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
        }
    }
});
    
    // invis hard
command(/^\/invishard$/, async (msg) => {
    const chatId = msg.chat.id;

    if (!msg.reply_to_message || !msg.reply_to_message.document) {
        return bot.sendMessage(chatId, "❌ *Error:* Balas file .js dengan `/invishard`!", { parse_mode: "Markdown" });
    }

    const file = msg.reply_to_message.document;

    if (!file.file_name.endsWith(".js")) {
        return bot.sendMessage(chatId, "❌ *Error:* Hanya file .js yang didukung!", { parse_mode: "Markdown" });
    }

    const encryptedPath = path.join(ENC_TMP_DIR, `invisible-encrypted-${file.file_name}`);
    let progressMessage = null;

    try {
        progressMessage = await bot.sendMessage(
            chatId,
            "```yoennakbobo\n" +
            "🔒 Starting Encrypted...\n" +
            ` ⚙️ Memulai (InvisiBle) (1%)\n` +
            ` ${createProgressBar(1)}\n` +
            "```\n",
            { parse_mode: "Markdown" }
        );

        const fileLink = await bot.getFileLink(file.file_id);
        log(`Mengunduh File Untuk Invisible Obfuscation: ${file.file_name}`);
        await updateProgress(bot, chatId, progressMessage.message_id, 10, "Mengunduh");

        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(bot, chatId, progressMessage.message_id, 20, "Mengunduh Selesai");

        log(`Memvalidasi kode awal: ${file.file_name}`);
        await updateProgress(bot, chatId, progressMessage.message_id, 30, "Memvalidasi Kode");
        try {
            new Function(fileContent);
        } catch (syntaxError) {
            throw new Error(`syntaxError: Kode tidak valid ${syntaxError.message}`);
        }

        log(`Mengenkripsi File Dengan Gaya Invisible Hardened`);
        await updateProgress(bot, chatId, progressMessage.message_id, 40, "Inisialisasi Hardened Invisible Obfuscation");

        const obfuscated = await JsConfuser.obfuscate(fileContent, getStrongObfuscationConfig());
        let obfuscatedCode = obfuscated.code || obfuscated;
        if (typeof obfuscatedCode !== "string") {
            throw new Error("Hasil Obfuscation Bukan String");
        }
        log(`Hasil Obfuscation (50 Char Pertama): ${obfuscatedCode.substring(0, 50)}...`);
        await updateProgress(bot, chatId, progressMessage.message_id, 60, "Transformasi Kode");

        log(`Memvalidasi Hasil Obfuscation: ${file.file_name}`);
        try {
            new Function(obfuscatedCode);
        } catch (postObfuscationError) {
            throw new Error(`Hasil Obfuscation Tidak Valid: ${postObfuscationError.message}`);
        }

        await updateProgress(bot, chatId, progressMessage.message_id, 80, "Finalisasi Enkripsi");
        await fs.writeFile(encryptedPath, obfuscatedCode);

        log(`Mengirim File Terenkripsi Gaya Invisible: ${file.file_name}`);
        await bot.sendDocument(chatId, encryptedPath, {
            reply_to_message_id: msg.message_id,
            parse_mode: "Markdown",
            filename: `Invisible-Enc-${file.file_name}`
        });

        await updateProgress(bot, chatId, progressMessage.message_id, 100, "Hardened Invisible Obfuscation Selesai");

        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
        }

        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
            log(`file sementara dihapus: ${encryptedPath}`);
        }
    } catch (error) {
        log("Kesalahan Saat Invisible Obfuscation", error);

        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
        }

        await bot.sendMessage(
            chatId,
            `❌ ${error.message || "Tidak diketahui"}`,
            { parse_mode: "Markdown" }
        );

        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
            log(`File sementara dihapus setelah error: ${encryptedPath}`);
        }
    }
});
    
    // enc invis
command(/^\/encinvis$/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;

    if (!msg.reply_to_message || !msg.reply_to_message.document) {
        return bot.sendMessage(chatId, "❌ *Error:* Balas file .js dengan `/encinvis`!", { parse_mode: "Markdown" });
    }

    const file = msg.reply_to_message.document;

    if (!file.file_name.endsWith(".js")) {
        return bot.sendMessage(chatId, "❌ *Error:* Hanya file .js yang didukung!", { parse_mode: "Markdown" });
    }

    const encryptedPath = path.join(ENC_TMP_DIR, `invis-encrypted-${file.file_name}`);
    let progressMessage = null;

    try {
        progressMessage = await bot.sendMessage(
            chatId,
            "```yoennakbobo\n" +
            "🔒 Starting Encrypted...\n" +
            ` ⚙️ Memulai (Hardened Invisible) (1%)\n` +
            ` ${createProgressBar(1)}\n` +
            "```\n",
            { parse_mode: "Markdown" }
        );

        const fileLink = await bot.getFileLink(file.file_id);
        log(`Mengunduh file untuk Invisible obfuscation: ${file.file_name}`);
        await updateProgress(bot, chatId, progressMessage.message_id, 10, "Mengunduh");

        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(bot, chatId, progressMessage.message_id, 20, "Mengunduh Selesai");

        log(`Memvalidasi kode: ${file.file_name}`);
        await updateProgress(bot, chatId, progressMessage.message_id, 30, "Memvalidasi Kode");
        try {
            new Function(fileContent);
        } catch (syntaxError) {
            throw new Error(`Kode tidak valid: ${syntaxError.message}`);
        }

        log(`Mengenkripsi file dengan gaya Invisible yang diperkuat`);
        await updateProgress(bot, chatId, progressMessage.message_id, 40, "Inisialisasi Hardened Invisible Obfuscation");

        const obfuscated = await JsConfuser.obfuscate(fileContent, getInvisObfuscationConfig());
        await updateProgress(bot, chatId, progressMessage.message_id, 60, "Transformasi Kode");

        await fs.writeFile(encryptedPath, obfuscated.code);
        await updateProgress(bot, chatId, progressMessage.message_id, 80, "Finalisasi Enkripsi");

        log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
        try {
            new Function(obfuscated.code);
        } catch (postObfuscationError) {
            throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
        }

        log(`Mengirim file terenkripsi gaya Invisible: ${file.file_name}`);
        await bot.sendDocument(chatId, encryptedPath, {
            reply_to_message_id: msg.message_id,
            parse_mode: "Markdown",
            filename: `invis-enc-${file.file_name}`
        });

        await updateProgress(bot, chatId, progressMessage.message_id, 100, "Hardened Invisible Obfuscation Selesai");

        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
            // ignore delete errors
        }

        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
            log(`file sementara dihapus: ${encryptedPath}`);
        }
    } catch (error) {
        log("Kesalahan saat Invisible obfuscation", error);

        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
            // ignore
        }

        await bot.sendMessage(
            chatId,
            `❌ ${error.message || "Tidak diketahui"}`,
            { parse_mode: "Markdown" }
        );

        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
            log(`File sementara dihapus setelah error: ${encryptedPath}`);
        }
    }
});
    
    // enc stealth
command(/^\/encstealth$/, async (msg) => {
    const chatId = msg.chat.id;

    if (!msg.reply_to_message || !msg.reply_to_message.document) {
        return bot.sendMessage(chatId, "❌ *Error:* Balas file .js dengan `/encstealth`!", { parse_mode: "Markdown" });
    }

    const file = msg.reply_to_message.document;

    if (!file.file_name.endsWith(".js")) {
        return bot.sendMessage(chatId, "❌ *Error:* Hanya file .js yang didukung!", { parse_mode: "Markdown" });
    }

    const encryptedPath = path.join(ENC_TMP_DIR, `stealth-encrypted-${file.file_name}`);
    let progressMessage = null;

    try {
        progressMessage = await bot.sendMessage(
            chatId,
            "```yoennakbobo\n" +
            "🔒 Starting Encrypted...\n" +
            ` ⚙️ Memulai (Hardened Stealth) (1%)\n` +
            ` ${createProgressBar(1)}\n` +
            "```\n",
            { parse_mode: "Markdown" }
        );

        const fileLink = await bot.getFileLink(file.file_id);
        await updateProgress(bot, chatId, progressMessage.message_id, 10, "Mengunduh");

        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(bot, chatId, progressMessage.message_id, 20, "Mengunduh Selesai");

        await updateProgress(bot, chatId, progressMessage.message_id, 30, "Memvalidasi Kode");
        try {
            new Function(fileContent);
        } catch (syntaxError) {
            throw new Error(`Kode tidak valid: ${syntaxError.message}`);
        }

        await updateProgress(bot, chatId, progressMessage.message_id, 40, "Inisialisasi Hardened Stealth Obfuscation");

        const obfuscated = await JsConfuser.obfuscate(fileContent, getStealthObfuscationConfig());
        await updateProgress(bot, chatId, progressMessage.message_id, 60, "Transformasi Kode");

        await fs.writeFile(encryptedPath, obfuscated.code);
        await updateProgress(bot, chatId, progressMessage.message_id, 80, "Finalisasi Enkripsi");

        try {
            new Function(obfuscated.code);
        } catch (postObfuscationError) {
            throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
        }

        await bot.sendDocument(chatId, encryptedPath, {
            reply_to_message_id: msg.message_id,
            parse_mode: "Markdown",
            filename: `stealth-enc-${file.file_name}`
        });

        await updateProgress(bot, chatId, progressMessage.message_id, 100, "Hardened Stealth Obfuscation Selesai");

        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
        }

        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
        }
    } catch (error) {
        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
        }

        await bot.sendMessage(
            chatId,
            `❌ ${error.message || "Tidak diketahui"}`,
            { parse_mode: "Markdown" }
        );

        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
        }
    }
});
    
    // custom enc
command(/^\/customenc (.+)$/, async (msg, match) => {
    const chatId = msg.chat.id;

    const customName = match[1].replace(/[^a-zA-Z0-9_]/g, "");
    if (!customName) {
        return bot.sendMessage(chatId, "❌ *Error:* Nama kustom harus berisi huruf, angka, atau underscore!", { parse_mode: "Markdown" });
    }

    if (!msg.reply_to_message || !msg.reply_to_message.document) {
        return bot.sendMessage(chatId, "❌ *Error:* Balas file .js dengan `/customenc <nama>`!", { parse_mode: "Markdown" });
    }

    const file = msg.reply_to_message.document;

    if (!file.file_name.endsWith(".js")) {
        return bot.sendMessage(chatId, "❌ *Error:* Hanya file .js yang didukung!", { parse_mode: "Markdown" });
    }

    const encryptedPath = path.join(ENC_TMP_DIR, `custom-${customName}-encrypted-${file.file_name}`);
    let progressMessage = null;

    try {
        progressMessage = await bot.sendMessage(
            chatId,
            "```yoennakbobo\n" +
            "🔒 Starting Encrypted...\n" +
            ` ⚙️ Memulai (Hardened Custom: ${customName}) (1%)\n` +
            ` ${createProgressBar(1)}\n` +
            "```\n",
            { parse_mode: "Markdown" }
        );

        const fileLink = await bot.getFileLink(file.file_id);
        await updateProgress(bot, chatId, progressMessage.message_id, 10, "Mengunduh");

        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(bot, chatId, progressMessage.message_id, 20, "Mengunduh Selesai");

        await updateProgress(bot, chatId, progressMessage.message_id, 30, "Memvalidasi Kode");
        try {
            new Function(fileContent);
        } catch (syntaxError) {
            throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
        }

        await updateProgress(bot, chatId, progressMessage.message_id, 40, "Inisialisasi Hardened Custom Obfuscation");

        const obfuscated = await JsConfuser.obfuscate(fileContent, getCustomObfuscationConfig(customName));
        await updateProgress(bot, chatId, progressMessage.message_id, 60, "Transformasi Kode");

        try {
            new Function(obfuscated.code);
        } catch (postObfuscationError) {
            throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
        }

        await fs.writeFile(encryptedPath, obfuscated.code);
        await updateProgress(bot, chatId, progressMessage.message_id, 80, "Finalisasi Enkripsi");

        await bot.sendDocument(chatId, encryptedPath, {
            reply_to_message_id: msg.message_id,
            parse_mode: "Markdown",
            filename: `custom-${customName}-enc-${file.file_name}`
        });

        await updateProgress(bot, chatId, progressMessage.message_id, 100, `Hardened Custom (${customName}) Obfuscation Selesai`);

        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
        }

        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
        }
    } catch (error) {
        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
        }

        await bot.sendMessage(
            chatId,
            `❌ ${error.message || "Tidak diketahui"}`,
            { parse_mode: "Markdown" }
        );

        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
        }
    }
});
    
    // enc strong
command(/^\/encstrong$/, async (msg) => {
    const chatId = msg.chat.id;

    if (!msg.reply_to_message || !msg.reply_to_message.document) {
        return bot.sendMessage(chatId, "❌ *Error:* Balas file .js dengan `/encstrong`!", { parse_mode: "Markdown" });
    }

    const file = msg.reply_to_message.document;

    if (!file.file_name.endsWith(".js")) {
        return bot.sendMessage(chatId, "❌ *Error:* Hanya file .js yang didukung!", { parse_mode: "Markdown" });
    }

    const encryptedPath = path.join(ENC_TMP_DIR, `strong-encrypted-${file.file_name}`);
    let progressMessage = null;

    try {
        progressMessage = await bot.sendMessage(
            chatId,
            "```yoennakbobo\n" +
            "🔒 Starting Encrypted...\n" +
            ` ⚙️ Memulai (Hardened Strong) (1%)\n` +
            ` ${createProgressBar(1)}\n` +
            "```\n",
            { parse_mode: "Markdown" }
        );

        const fileLink = await bot.getFileLink(file.file_id);
        await updateProgress(bot, chatId, progressMessage.message_id, 10, "Mengunduh");

        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(bot, chatId, progressMessage.message_id, 20, "Mengunduh Selesai");

        await updateProgress(bot, chatId, progressMessage.message_id, 30, "Memvalidasi Kode");
        try {
            new Function(fileContent);
        } catch (syntaxError) {
            throw new Error(`Kode tidak valid: ${syntaxError.message}`);
        }

        await updateProgress(bot, chatId, progressMessage.message_id, 40, "Inisialisasi Hardened Strong Obfuscation");

        const obfuscated = await JsConfuser.obfuscate(fileContent, getStrongObfuscationConfig());
        let obfuscatedCode = obfuscated.code || obfuscated;
        if (typeof obfuscatedCode !== "string") {
            throw new Error("Hasil obfuscation bukan string");
        }
        await updateProgress(bot, chatId, progressMessage.message_id, 60, "Transformasi Kode");

        try {
            new Function(obfuscatedCode);
        } catch (postObfuscationError) {
            throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
        }

        await updateProgress(bot, chatId, progressMessage.message_id, 80, "Finalisasi Enkripsi");
        await fs.writeFile(encryptedPath, obfuscatedCode);

        await bot.sendDocument(chatId, encryptedPath, {
            reply_to_message_id: msg.message_id,
            parse_mode: "Markdown",
            filename: `strong-enc-${file.file_name}`
        });

        await updateProgress(bot, chatId, progressMessage.message_id, 100, "Hardened Strong Obfuscation Selesai");

        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
        }

        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
        }
    } catch (error) {
        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
        }

        await bot.sendMessage(
            chatId,
            `❌ ${error.message || "Tidak diketahui"}`,
            { parse_mode: "Markdown" }
        );

        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
        }
    }
});

    // enc big
command(/^\/encbig (\d+)$/, async (msg, match) => {
    const chatId = msg.chat.id;

    const targetSizeMB = Math.max(1, parseInt(match[1], 10));

    if (!msg.reply_to_message || !msg.reply_to_message.document) {
        return bot.sendMessage(chatId, "❌ *Error:* Balas file .js dengan `/encbig <size_in_mb>`!", { parse_mode: "Markdown" });
    }

    const file = msg.reply_to_message.document;

    if (!file.file_name.endsWith(".js")) {
        return bot.sendMessage(chatId, "❌ *Error:* Hanya file .js yang didukung!", { parse_mode: "Markdown" });
    }

    const encryptedPath = path.join(ENC_TMP_DIR, `big-encrypted-${file.file_name}`);
    let progressMessage = null;

    try {
        progressMessage = await bot.sendMessage(
            chatId,
            "```yoennakbobo\n" +
            "🔒 Starting Encrypted...\n" +
            ` ⚙️ Memulai (Hardened Big: ${targetSizeMB}MB) (1%)\n` +
            ` ${createProgressBar(1)}\n` +
            "```\n",
            { parse_mode: "Markdown" }
        );

        const fileLink = await bot.getFileLink(file.file_id);
        await updateProgress(bot, chatId, progressMessage.message_id, 10, "Mengunduh");

        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(bot, chatId, progressMessage.message_id, 20, "Mengunduh Selesai");

        await updateProgress(bot, chatId, progressMessage.message_id, 30, "Memvalidasi Kode");
        try {
            new Function(fileContent);
        } catch (syntaxError) {
            throw new Error(`Kode tidak valid: ${syntaxError.message}`);
        }

        await updateProgress(bot, chatId, progressMessage.message_id, 40, "Inisialisasi Hardened Big Obfuscation");

        const obfuscated = await JsConfuser.obfuscate(fileContent, getBigObfuscationConfig());
        let obfuscatedCode = obfuscated.code || obfuscated;
        if (typeof obfuscatedCode !== "string") {
            throw new Error("Hasil obfuscation bukan string");
        }
        await updateProgress(bot, chatId, progressMessage.message_id, 60, "Transformasi Kode");

        const currentSizeBytes = Buffer.byteLength(obfuscatedCode, "utf8");
        const targetSizeBytes = targetSizeMB * 1024 * 1024;
        if (currentSizeBytes < targetSizeBytes) {
            const paddingSize = targetSizeBytes - currentSizeBytes;
            const padding = crypto.randomBytes(paddingSize).toString("base64");
            obfuscatedCode += `\n/* Binary Padding (${paddingSize} bytes) */\n// ${padding}`;
        }

        try {
            new Function(obfuscatedCode);
        } catch (postObfuscationError) {
            throw new Error(`Hasil obfuscation tidak valid setelah padding: ${postObfuscationError.message}`);
        }

        await updateProgress(bot, chatId, progressMessage.message_id, 80, "Finalisasi Enkripsi");
        await fs.writeFile(encryptedPath, obfuscatedCode);

        await bot.sendDocument(chatId, encryptedPath, {
            reply_to_message_id: msg.message_id,
            parse_mode: "Markdown",
            filename: `big-enc-${file.file_name}`
        });

        await updateProgress(bot, chatId, progressMessage.message_id, 100, `Hardened Big (${targetSizeMB}MB) Obfuscation Selesai`);

        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
        }

        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
        }
    } catch (error) {
        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
        }

        await bot.sendMessage(
            chatId,
            `❌ ${error.message || "Tidak diketahui"}`,
            { parse_mode: "Markdown" }
        );

        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
        }
    }
});
    
    // enc ultra
command(/^\/encultra$/, async (msg) => {
    const chatId = msg.chat.id;

    if (!msg.reply_to_message || !msg.reply_to_message.document) {
        return bot.sendMessage(chatId, "❌ *Error:* Balas file .js dengan `/encultra`!", { parse_mode: "Markdown" });
    }

    const file = msg.reply_to_message.document;

    if (!file.file_name.endsWith(".js")) {
        return bot.sendMessage(chatId, "❌ *Error:* Hanya file .js yang didukung!", { parse_mode: "Markdown" });
    }

    const encryptedPath = path.join(ENC_TMP_DIR, `ultra-encrypted-${file.file_name}`);
    let progressMessage = null;

    try {
        progressMessage = await bot.sendMessage(
            chatId,
            "```yoennakbobo\n" +
            "🔒 Starting Encrypted...\n" +
            ` ⚙️ Memulai (Hardened Ultra) (1%)\n` +
            ` ${createProgressBar(1)}\n` +
            "```\n",
            { parse_mode: "Markdown" }
        );

        const fileLink = await bot.getFileLink(file.file_id);
        await updateProgress(bot, chatId, progressMessage.message_id, 10, "Mengunduh");

        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(bot, chatId, progressMessage.message_id, 20, "Mengunduh Selesai");

        await updateProgress(bot, chatId, progressMessage.message_id, 30, "Memvalidasi Kode");
        try {
            new Function(fileContent);
        } catch (syntaxError) {
            throw new Error(`Kode tidak valid: ${syntaxError.message}`);
        }

        await updateProgress(bot, chatId, progressMessage.message_id, 40, "Inisialisasi Hardened Ultra Obfuscation");

        const obfuscated = await JsConfuser.obfuscate(fileContent, getUltraObfuscationConfig());
        let obfuscatedCode = obfuscated.code || obfuscated;
        if (typeof obfuscatedCode !== "string") {
            throw new Error("Hasil obfuscation bukan string");
        }
        await updateProgress(bot, chatId, progressMessage.message_id, 60, "Transformasi Kode");

        try {
            new Function(obfuscatedCode);
        } catch (postObfuscationError) {
            throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
        }

        await updateProgress(bot, chatId, progressMessage.message_id, 80, "Finalisasi Enkripsi");
        await fs.writeFile(encryptedPath, obfuscatedCode);

        await bot.sendDocument(chatId, encryptedPath, {
            reply_to_message_id: msg.message_id,
            parse_mode: "Markdown",
            filename: `ultra-enc-${file.file_name}`
        });

        await updateProgress(bot, chatId, progressMessage.message_id, 100, "Hardened Ultra Obfuscation Selesai");

        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
        }

        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
        }
    } catch (error) {
        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
        }

        await bot.sendMessage(
            chatId,
            `❌ ${error.message || "Tidak diketahui"}`,
            { parse_mode: "Markdown" }
        );

        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
        }
    }
});
    
    // enc max
command(/^\/encmax (\d+)$/, async (msg, match) => {
    const chatId = msg.chat.id;

    const intensity = Math.min(Math.max(1, parseInt(match[1], 10)), 10);

    if (!msg.reply_to_message || !msg.reply_to_message.document) {
        return bot.sendMessage(chatId, "❌ *Error:* Balas file .js dengan `/encmax <intensity>`!", { parse_mode: "Markdown" });
    }

    const file = msg.reply_to_message.document;

    if (!file.file_name.endsWith(".js")) {
        return bot.sendMessage(chatId, "❌ *Error:* Hanya file .js yang didukung!", { parse_mode: "Markdown" });
    }

    const encryptedPath = path.join(ENC_TMP_DIR, `max-encrypted-${file.file_name}`);
    let progressMessage = null;

    try {
        progressMessage = await bot.sendMessage(
            chatId,
            "```yoennakbobo\n" +
            "🔒 Starting Encrypted...\n" +
            ` ⚙️ Memulai (Hardened Max Intensity ${intensity}) (1%)\n` +
            " " + createProgressBar(1) + "\n" +
            "```\n",
            { parse_mode: "Markdown" }
        );

        const fileLink = await bot.getFileLink(file.file_id);
        await updateProgress(bot, chatId, progressMessage.message_id, 10, "Mengunduh");

        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(bot, chatId, progressMessage.message_id, 20, "Mengunduh Selesai");

        await updateProgress(bot, chatId, progressMessage.message_id, 30, "Memvalidasi Kode");
        try {
            new Function(fileContent);
        } catch (syntaxError) {
            throw new Error(`Kode tidak valid: ${syntaxError.message}`);
        }

        await updateProgress(bot, chatId, progressMessage.message_id, 40, "Inisialisasi Hardened Max Obfuscation");

        const obfuscated = await JsConfuser.obfuscate(fileContent, getMaxObfuscationConfig(intensity));
        let obfuscatedCode = obfuscated.code || obfuscated;
        if (typeof obfuscatedCode !== "string") {
            throw new Error("Hasil obfuscation bukan string");
        }
        await updateProgress(bot, chatId, progressMessage.message_id, 60, "Transformasi Kode");

        try {
            new Function(obfuscatedCode);
        } catch (postObfuscationError) {
            throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
        }

        await updateProgress(bot, chatId, progressMessage.message_id, 80, "Finalisasi Enkripsi");
        await fs.writeFile(encryptedPath, obfuscatedCode);

        await bot.sendDocument(chatId, encryptedPath, {
            reply_to_message_id: msg.message_id,
            parse_mode: "Markdown",
            filename: `max-enc-${file.file_name}`
        });

        await updateProgress(bot, chatId, progressMessage.message_id, 100, `Hardened Max (Intensity ${intensity}) Obfuscation Selesai`);

        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
        }

        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
        }
    } catch (error) {
        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
        }

        await bot.sendMessage(
            chatId,
            `❌ ${error.message || "Tidak diketahui"}`,
            { parse_mode: "Markdown" }
        );

        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
        }
    }
});

    // enc quantum
command(/^\/encquantum$/, async (msg) => {
    const chatId = msg.chat.id;

    if (!msg.reply_to_message || !msg.reply_to_message.document) {
        return bot.sendMessage(chatId, "❌ *Error:* Balas file .js dengan `/encquantum`!", { parse_mode: "Markdown" });
    }

    const file = msg.reply_to_message.document;

    if (!file.file_name.endsWith(".js")) {
        return bot.sendMessage(chatId, "❌ *Error:* Hanya file .js yang didukung!", { parse_mode: "Markdown" });
    }

    const encryptedPath = path.join(ENC_TMP_DIR, `quantum-encrypted-${file.file_name}`);
    let progressMessage = null;

    try {
        progressMessage = await bot.sendMessage(
            chatId,
            "```yoennakbobo\n" +
            "🔒 Starting Encrypted...\n" +
            " ⚙️ Memulai (Quantum Vortex Encryption) (1%)\n" +
            " " + createProgressBar(1) + "\n" +
            "```\n",
            { parse_mode: "Markdown" }
        );

        const fileLink = await bot.getFileLink(file.file_id);
        await updateProgress(bot, chatId, progressMessage.message_id, 10, "Mengunduh");

        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(bot, chatId, progressMessage.message_id, 20, "Mengunduh Selesai");

        await updateProgress(bot, chatId, progressMessage.message_id, 30, "Memvalidasi Kode");
        try {
            new Function(fileContent);
        } catch (syntaxError) {
            throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
        }

        await updateProgress(bot, chatId, progressMessage.message_id, 40, "Inisialisasi Quantum Vortex Encryption");

        const obfuscatedCode = await obfuscateQuantum(fileContent);
        await updateProgress(bot, chatId, progressMessage.message_id, 60, "Transformasi Kode");

        try {
            new Function(obfuscatedCode);
        } catch (postObfuscationError) {
            throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
        }

        await updateProgress(bot, chatId, progressMessage.message_id, 80, "Finalisasi Enkripsi");
        await fs.writeFile(encryptedPath, obfuscatedCode);

        await bot.sendDocument(chatId, encryptedPath, {
            reply_to_message_id: msg.message_id,
            parse_mode: "Markdown",
            filename: `quantum-enc-${file.file_name}`
        });

        await updateProgress(bot, chatId, progressMessage.message_id, 100, "Quantum Vortex Encryption Selesai");

        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
        }

        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
        }
    } catch (error) {
        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
        }

        await bot.sendMessage(
            chatId,
            `❌ ${error.message || "Tidak diketahui"}`,
            { parse_mode: "Markdown" }
        );

        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
        }
    }
});

    // encx
command(/^\/encx$/, async (msg) => {
    const chatId = msg.chat.id;

    if (!msg.reply_to_message || !msg.reply_to_message.document) {
        return bot.sendMessage(chatId, "❌ *Error:* Balas file .js dengan `/encx`!", { parse_mode: "Markdown" });
    }

    const file = msg.reply_to_message.document;

    if (!file.file_name.endsWith(".js")) {
        return bot.sendMessage(chatId, "❌ *Error:* Hanya file .js yang didukung!", { parse_mode: "Markdown" });
    }

    const encryptedPath = path.join(ENC_TMP_DIR, `x-encrypted-${file.file_name}`);
    let progressMessage = null;

    try {
        progressMessage = await bot.sendMessage(
            chatId,
            "```yoennakbobo\n" +
            "🔒 Starting Encrypted...\n" +
            " ⚙️ Memulai (Hardened X Invisible) (1%)\n" +
            " " + createProgressBar(1) + "\n" +
            "```\n",
            { parse_mode: "Markdown" }
        );

        const fileLink = await bot.getFileLink(file.file_id);
        await updateProgress(bot, chatId, progressMessage.message_id, 10, "Mengunduh");

        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(bot, chatId, progressMessage.message_id, 20, "Mengunduh Selesai");

        await updateProgress(bot, chatId, progressMessage.message_id, 30, "Memvalidasi Kode");
        try {
            new Function(fileContent);
        } catch (syntaxError) {
            throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
        }

        await updateProgress(bot, chatId, progressMessage.message_id, 40, "Inisialisasi Hardened X Obfuscation");

        const obfuscated = await JsConfuser.obfuscate(fileContent, getXObfuscationConfig());
        let obfuscatedCode = obfuscated.code || obfuscated;
        if (typeof obfuscatedCode !== "string") {
            throw new Error("Hasil obfuscation bukan string");
        }

        const encodedInvisible = encodeInvisible(obfuscatedCode);
        const finalCode = `
        (function(){
            function decodeInvisible(encodedText) {
                if (!encodedText.startsWith('\u200B')) return encodedText;
                try {
                    return Buffer.from(encodedText.slice(1), 'base64').toString('utf-8');
                } catch (e) {
                    return encodedText;
                }
            }
            try {
                const hiddenCode = "${encodedInvisible}";
                const decodedCode = decodeInvisible(hiddenCode);
                if (!decodedCode || decodedCode === hiddenCode) throw new Error("Decoding failed");
                eval(decodedCode);
            } catch (e) {
                console.error("Execution error:", e);
            }
        })();
        `;
        await updateProgress(bot, chatId, progressMessage.message_id, 60, "Transformasi Kode");

        try {
            new Function(finalCode);
        } catch (postObfuscationError) {
            throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
        }

        await updateProgress(bot, chatId, progressMessage.message_id, 80, "Finalisasi Enkripsi");
        await fs.writeFile(encryptedPath, finalCode);

        await bot.sendDocument(chatId, encryptedPath, {
            reply_to_message_id: msg.message_id,
            parse_mode: "Markdown",
            filename: `x-enc-${file.file_name}`
        });

        await updateProgress(bot, chatId, progressMessage.message_id, 100, "Hardened X Invisible Obfuscation Selesai");

        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
        }

        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
        }
    } catch (error) {
        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
        }

        await bot.sendMessage(
            chatId,
            `❌ ${error.message || "Tidak diketahui"}`,
            { parse_mode: "Markdown" }
        );

        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
        }
    }
});
    
    // enc nova
command(/^\/encnova$/, async (msg) => {
    const chatId = msg.chat.id;

    if (!msg.reply_to_message || !msg.reply_to_message.document) {
        return bot.sendMessage(chatId, "❌ *Error:* Balas file .js dengan `/encnova`!", { parse_mode: "Markdown" });
    }

    const file = msg.reply_to_message.document;

    if (!file.file_name.endsWith(".js")) {
        return bot.sendMessage(chatId, "❌ *Error:* Hanya file .js yang didukung!", { parse_mode: "Markdown" });
    }

    const encryptedPath = path.join(ENC_TMP_DIR, `nova-encrypted-${file.file_name}`);
    let progressMessage = null;

    try {
        progressMessage = await bot.sendMessage(
            chatId,
            "```yoennakbobo\n" +
            "🔒 Starting Encrypted...\n" +
            " ⚙️ Memulai (Nova Dynamic) (1%)\n" +
            " " + createProgressBar(1) + "\n" +
            "```\n",
            { parse_mode: "Markdown" }
        );

        const fileLink = await bot.getFileLink(file.file_id);
        await updateProgress(bot, chatId, progressMessage.message_id, 10, "Mengunduh");

        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(bot, chatId, progressMessage.message_id, 20, "Mengunduh Selesai");

        await updateProgress(bot, chatId, progressMessage.message_id, 30, "Memvalidasi Kode");
        try {
            new Function(fileContent);
        } catch (syntaxError) {
            throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
        }

        await updateProgress(bot, chatId, progressMessage.message_id, 40, "Inisialisasi Nova Dynamic Obfuscation");

        const obfuscated = await JsConfuser.obfuscate(fileContent, getNovaObfuscationConfig());
        let obfuscatedCode = obfuscated.code || obfuscated;
        if (typeof obfuscatedCode !== "string") {
            throw new Error("Hasil obfuscation bukan string");
        }
        await updateProgress(bot, chatId, progressMessage.message_id, 60, "Transformasi Kode");

        try {
            new Function(obfuscatedCode);
        } catch (postObfuscationError) {
            throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
        }

        await updateProgress(bot, chatId, progressMessage.message_id, 80, "Finalisasi Enkripsi");
        await fs.writeFile(encryptedPath, obfuscatedCode);

        await bot.sendDocument(chatId, encryptedPath, {
            reply_to_message_id: msg.message_id,
            parse_mode: "Markdown",
            filename: `nova-enc-${file.file_name}`
        });

        await updateProgress(bot, chatId, progressMessage.message_id, 100, "Nova Dynamic Obfuscation Selesai");

        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
        }

        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
        }
    } catch (error) {
        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
        }

        await bot.sendMessage(
            chatId,
            `❌ ${error.message || "Tidak diketahui"}`,
            { parse_mode: "Markdown" }
        );

        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
        }
    }
});

    // enc nebula
command(/^\/encnebula$/, async (msg) => {
    const chatId = msg.chat.id;

    if (!msg.reply_to_message || !msg.reply_to_message.document) {
        return bot.sendMessage(chatId, "❌ *Error:* Balas file .js dengan `/encnebula`!", { parse_mode: "Markdown" });
    }

    const file = msg.reply_to_message.document;

    if (!file.file_name.endsWith(".js")) {
        return bot.sendMessage(chatId, "❌ *Error:* Hanya file .js yang didukung!", { parse_mode: "Markdown" });
    }

    const encryptedPath = path.join(ENC_TMP_DIR, `nebula-encrypted-${file.file_name}`);
    let progressMessage = null;

    try {
        progressMessage = await bot.sendMessage(
            chatId,
            "```yoennakbobo\n" +
            "🔒 Starting Encrypted...\n" +
            " ⚙️ Memulai (Nebula Polymorphic Storm) (1%)\n" +
            " " + createProgressBar(1) + "\n" +
            "```\n",
            { parse_mode: "Markdown" }
        );

        const fileLink = await bot.getFileLink(file.file_id);
        await updateProgress(bot, chatId, progressMessage.message_id, 10, "Mengunduh");

        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(bot, chatId, progressMessage.message_id, 20, "Mengunduh Selesai");

        await updateProgress(bot, chatId, progressMessage.message_id, 30, "Memvalidasi Kode");
        try {
            new Function(fileContent);
        } catch (syntaxError) {
            throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
        }

        await updateProgress(bot, chatId, progressMessage.message_id, 40, "Inisialisasi Nebula Polymorphic Storm");

        const obfuscated = await JsConfuser.obfuscate(fileContent, getNebulaObfuscationConfig());
        let obfuscatedCode = obfuscated.code || obfuscated;
        if (typeof obfuscatedCode !== "string") {
            throw new Error("Hasil obfuscation bukan string");
        }
        await updateProgress(bot, chatId, progressMessage.message_id, 60, "Transformasi Kode");

        try {
            new Function(obfuscatedCode);
        } catch (postObfuscationError) {
            throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
        }

        await updateProgress(bot, chatId, progressMessage.message_id, 80, "Finalisasi Enkripsi");
        await fs.writeFile(encryptedPath, obfuscatedCode);

        await bot.sendDocument(chatId, encryptedPath, {
            reply_to_message_id: msg.message_id,
            parse_mode: "Markdown",
            filename: `nebula-enc-${file.file_name}`
        });

        await updateProgress(bot, chatId, progressMessage.message_id, 100, "Nebula Polymorphic Storm Selesai");

        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
        }

        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
        }
    } catch (error) {
        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
        }

        await bot.sendMessage(
            chatId,
            `❌ ${error.message || "Tidak diketahui"}`,
            { parse_mode: "Markdown" }
        );

        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
        }
    }
});

    // enc siu
command(/^\/encsiu$/, async (msg) => {
    const chatId = msg.chat.id;

    if (!msg.reply_to_message || !msg.reply_to_message.document) {
        return bot.sendMessage(chatId, "❌ *Error:* Balas file .js dengan `/encsiu`!", { parse_mode: "Markdown" });
    }

    const file = msg.reply_to_message.document;

    if (!file.file_name.endsWith(".js")) {
        return bot.sendMessage(chatId, "❌ *Error:* Hanya file .js yang didukung!", { parse_mode: "Markdown" });
    }

    const encryptedPath = path.join(ENC_TMP_DIR, `siucalcrick-encrypted-${file.file_name}`);
    let progressMessage = null;

    try {
        progressMessage = await bot.sendMessage(
            chatId,
            "```yoennakbobo\n" +
            "🔒 Starting Encrypted...\n" +
            " ⚙️ Memulai (Calcrick Chaos Core) (1%)\n" +
            " " + createProgressBar(1) + "\n" +
            "```\n",
            { parse_mode: "Markdown" }
        );

        const fileLink = await bot.getFileLink(file.file_id);
        await updateProgress(bot, chatId, progressMessage.message_id, 10, "Mengunduh");

        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(bot, chatId, progressMessage.message_id, 20, "Mengunduh Selesai");

        await updateProgress(bot, chatId, progressMessage.message_id, 30, "Memvalidasi Kode");
        try {
            new Function(fileContent);
        } catch (syntaxError) {
            throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
        }

        await updateProgress(bot, chatId, progressMessage.message_id, 40, "Inisialisasi Calcrick Chaos Core");

        const obfuscated = await JsConfuser.obfuscate(fileContent, getSiuCalcrickObfuscationConfig());
        let obfuscatedCode = obfuscated.code || obfuscated;
        if (typeof obfuscatedCode !== "string") {
            throw new Error("Hasil obfuscation bukan string");
        }
        await updateProgress(bot, chatId, progressMessage.message_id, 60, "Transformasi Kode");

        try {
            new Function(obfuscatedCode);
        } catch (postObfuscationError) {
            throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
        }

        await updateProgress(bot, chatId, progressMessage.message_id, 80, "Finalisasi Enkripsi");
        await fs.writeFile(encryptedPath, obfuscatedCode);

        await bot.sendDocument(chatId, encryptedPath, {
            reply_to_message_id: msg.message_id,
            parse_mode: "Markdown",
            filename: `siucalcrick-enc-${file.file_name}`
        });

        await updateProgress(bot, chatId, progressMessage.message_id, 100, "Calcrick Chaos Core Selesai");

        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
        }

        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
        }
    } catch (error) {
        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
        }

        await bot.sendMessage(
            chatId,
            `❌ ${error.message || "Tidak diketahui"}`,
            { parse_mode: "Markdown" }
        );

        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
        }
    }
});

    // enc locked
command(/^\/enclocked (\d+)$/, async (msg, match) => {
    const chatId = msg.chat.id;

    const days = match[1];
    const expiryDate = new Date();
    expiryDate.setDate(expiryDate.getDate() + parseInt(days));
    const expiryFormatted = expiryDate.toLocaleDateString();

    if (!msg.reply_to_message || !msg.reply_to_message.document) {
        return bot.sendMessage(chatId, "❌ *Error:* Balas file .js dengan `/enclocked [1-365]`!", { parse_mode: "Markdown" });
    }

    const file = msg.reply_to_message.document;

    if (!file.file_name.endsWith(".js")) {
        return bot.sendMessage(chatId, "❌ *Error:* Hanya file .js yang didukung!", { parse_mode: "Markdown" });
    }

    const encryptedPath = path.join(ENC_TMP_DIR, `locked-encrypted-${file.file_name}`);
    let progressMessage = null;

    try {
        progressMessage = await bot.sendMessage(
            chatId,
            "```yoennakbobo\n" +
            "🔒 Starting Encrypted...\n" +
            " ⚙️ Memulai (Time-Locked Encryption) (1%)\n" +
            " " + createProgressBar(1) + "\n" +
            "```\n",
            { parse_mode: "Markdown" }
        );

        const fileLink = await bot.getFileLink(file.file_id);
        await updateProgress(bot, chatId, progressMessage.message_id, 10, "Mengunduh");

        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(bot, chatId, progressMessage.message_id, 20, "Mengunduh Selesai");

        await updateProgress(bot, chatId, progressMessage.message_id, 30, "Memvalidasi Kode");
        try {
            new Function(fileContent);
        } catch (syntaxError) {
            throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
        }

        await updateProgress(bot, chatId, progressMessage.message_id, 40, "Inisialisasi Time-Locked Encryption");

        const obfuscatedCode = await obfuscateTimeLocked(fileContent, days);
        await updateProgress(bot, chatId, progressMessage.message_id, 60, "Transformasi Kode");

        try {
            new Function(obfuscatedCode);
        } catch (postObfuscationError) {
            throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
        }

        await updateProgress(bot, chatId, progressMessage.message_id, 80, "Finalisasi Enkripsi");
        await fs.writeFile(encryptedPath, obfuscatedCode);

        await bot.sendMessage(
            chatId,
            `⏰ Masa aktif: ${days} hari\n` +
            `(Kadaluwarsa: ${expiryFormatted})`,
            { parse_mode: "Markdown" }
        );

        await bot.sendDocument(chatId, encryptedPath, {
            reply_to_message_id: msg.message_id,
            parse_mode: "Markdown",
            filename: `locked-enc-${file.file_name}`
        });

        await updateProgress(bot, chatId, progressMessage.message_id, 100, "Time-Locked Encryption Selesai");

        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
        }

        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
        }
    } catch (error) {
        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
        }

        await bot.sendMessage(
            chatId,
            `❌ ${error.message || "Tidak diketahui"}`,
            { parse_mode: "Markdown" }
        );

        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
        }
    }
});

    // deobfuscate
command(/^\/deobfuscate$/, async (msg) => {
    const chatId = msg.chat.id;

    if (!msg.reply_to_message || !msg.reply_to_message.document) {
        return bot.sendMessage(chatId, "❌ *Error:* Balas file .js yang diobfuscate dengan `/deobfuscate`!", { parse_mode: "Markdown" });
    }

    const file = msg.reply_to_message.document;

    if (!file.file_name.endsWith(".js")) {
        return bot.sendMessage(chatId, "❌ *Error:* Hanya file .js yang didukung!", { parse_mode: "Markdown" });
    }

    const deobfuscatedPath = path.join(ENC_TMP_DIR, `Cracked-By-yoennakbobo-${file.file_name}`);
    let progressMessage = null;

    try {
        progressMessage = await bot.sendMessage(
            chatId,
            "```yoennakbobo\n" +
            "🔒 Starting Decrypted...\n" +
            ` ⚙️ Memulai Deobfuscation (1%)\n` +
            ` ${createProgressBar(1)}\n` +
            "```\n",
            { parse_mode: "Markdown" }
        );

        const fileLink = await bot.getFileLink(file.file_id);
        await updateProgress(bot, chatId, progressMessage.message_id, 10, "Mengunduh");

        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(bot, chatId, progressMessage.message_id, 20, "Mengunduh Selesai");

        await updateProgress(bot, chatId, progressMessage.message_id, 30, "Memvalidasi Kode Awal");
        try {
            new Function(fileContent);
        } catch (syntaxError) {
            throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
        }

        await updateProgress(bot, chatId, progressMessage.message_id, 40, "Memulai Deobfuscation");
        const result = await webcrack(fileContent);
        let deobfuscatedCode = result.code;

        let bundleInfo = "";
        if (result.bundle) {
            bundleInfo = "// Detected as bundled code (e.g., Webpack/Browserify)\n";
        }

        if (!deobfuscatedCode || typeof deobfuscatedCode !== "string" || deobfuscatedCode.trim() === fileContent.trim()) {
            deobfuscatedCode = `${bundleInfo}// Webcrack Tidak Dapat Mendekode Sepenuhnya Atau Hasil Invalid\n${fileContent}`;
        }

        await updateProgress(bot, chatId, progressMessage.message_id, 60, "Memvalidasi Kode Hasil");
        let isValid = true;
        try {
            new Function(deobfuscatedCode);
        } catch (syntaxError) {
            deobfuscatedCode = `${bundleInfo}// Kesalahan validasi: ${syntaxError.message}\n${deobfuscatedCode}`;
            isValid = false;
        }

        await updateProgress(bot, chatId, progressMessage.message_id, 80, "Menyimpan Hasil");
        await fs.writeFile(deobfuscatedPath, deobfuscatedCode);

        await bot.sendDocument(chatId, deobfuscatedPath, {
            reply_to_message_id: msg.message_id,
            parse_mode: "Markdown",
            filename: `Cracked-By-yoennakbobo-${file.file_name}`
        });

        await updateProgress(bot, chatId, progressMessage.message_id, 100, "Cracked Selesai");

        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
        }

        if (await fs.pathExists(deobfuscatedPath)) {
            await fs.unlink(deobfuscatedPath);
        }
    } catch (error) {
        try {
            if (progressMessage && progressMessage.message_id) {
                await bot.deleteMessage(chatId, progressMessage.message_id);
            }
        } catch (e) {
        }

        await bot.sendMessage(
            chatId,
            `❌ ${error.message || "Tidak diketahui"}`,
            { parse_mode: "Markdown" }
        );

        if (await fs.pathExists(deobfuscatedPath)) {
            await fs.unlink(deobfuscatedPath);
        }
    }
});


// ------------------------------------------------------------
// /unlockenc — deobfuscate JS / selected JS entries inside ZIP.
// This reverses common JavaScript obfuscation; it cannot decrypt
// a file protected by an unknown cryptographic key/password.
// ------------------------------------------------------------
const unlockZipSessions = new Map();
const UNLOCK_ZIP_TTL = 15 * 60 * 1000;
function unlockKey(chatId, userId) { return `${chatId}:${userId}`; }
function cleanupUnlockSession(key) {
  const st = unlockZipSessions.get(key);
  if (!st) return;
  if (st.dir) { try { fs.removeSync(st.dir); } catch {} }
  unlockZipSessions.delete(key);
}
function unlockCandidates(info) {
  return info.entries.filter(x => /\.(?:js|enc)$/i.test(x.name));
}
function analyzeUnlockZip(zipPath) {
  const zip = new AdmZip(zipPath);
  const entries = [];
  for (const e of zip.getEntries()) {
    if (e.isDirectory) continue;
    const name = zipEntrySafeName(e.entryName);
    if (!name) continue;
    const data = e.getData();
    entries.push({ name, size: data.length, unlockable: /\.(?:js|enc)$/i.test(name) });
  }
  return { entries, candidates: unlockCandidates({ entries }) };
}
const unlockProgressState = new Map();
async function updateUnlockProgress(bot, chatId, messageId, percent, label) {
  const p = Math.max(0, Math.min(100, Math.round(Number(percent) || 0)));
  const frames = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"];
  const frame = frames[Math.floor(Date.now() / 180) % frames.length];
  const filled = Math.round(p / 5), bar = "█".repeat(filled) + "░".repeat(20 - filled);
  const text = `<b>UNLOCK ENC • PROSES</b>\n<blockquote expandable>${frame} <b>${html(label)}</b>\n<code>${bar}</code> <b>${p}%</b></blockquote>`;
  const key = `${chatId}:${messageId}`;
  if (unlockProgressState.get(key) === text) return;
  unlockProgressState.set(key, text);
  try { await bot.editMessageText(text, { chat_id: chatId, message_id: messageId, parse_mode: 'HTML' }); } catch (e) {
    const d = String(e?.response?.body?.description || e?.message || e);
    if (!/not modified|message to edit not found|message can't be edited/i.test(d)) {}
  }
}

async function crackJsSource(source) {
  const text = String(source || '');
  if (!text.trim()) throw new Error('File JS kosong.');
  let result;
  try { result = await webcrack(text); }
  catch (e) { throw new Error(`Deobfuscation gagal: ${e.message}`); }
  let code = typeof result?.code === 'string' ? result.code : '';
  if (!code.trim()) throw new Error('Webcrack tidak menghasilkan kode.');
  if (result?.bundle) code = `// Detected bundle\n${code}`;
  return code;
}
async function prepareUnlockZipSession(bot, msg, file) {
  const chatId = msg.chat.id, userId = msg.from.id, key = unlockKey(chatId, userId);
  cleanupUnlockSession(key);
  const dir = path.join(ENC_TMP_DIR, `unlock-${chatId}-${userId}-${Date.now()}`);
  fs.ensureDirSync(dir);
  const zipPath = path.join(dir, 'input.zip');
  try {
    const link = await bot.getFileLink(file.file_id);
    const response = await fetch(link);
    if (!response.ok) throw new Error(`Gagal mengunduh ZIP: HTTP ${response.status}`);
    await fs.writeFile(zipPath, Buffer.from(await response.arrayBuffer()));
    const info = analyzeUnlockZip(zipPath);
    if (!info.candidates.length) throw new Error('ZIP tidak berisi file .js/.enc yang bisa di-unlock.');
    unlockZipSessions.set(key, { chatId, userId, fileName: file.file_name, zipPath, dir, info, selected: new Set(), createdAt: Date.now() });
    const rows = [
      [{ text: `UNLOCK SEMUA (${info.candidates.length})`, callback_data: 'unlockzip_all' }],
      [{ text: 'PILIH FILE', callback_data: 'unlockzip_pick' }, { text: 'BATAL', callback_data: 'unlockzip_cancel' }]
    ];
    return bot.sendMessage(chatId,
      `<b>╭━━〔 ANALISIS ZIP UNLOCK 〕━━╮</b>\n<blockquote expandable><b>File</b> : <code>${html(file.file_name)}</code>\n<b>Total</b>: <b>${info.entries.length}</b> file\n<b>JS/ENC</b>: <b>${info.candidates.length}</b> file</blockquote>\nPilih bagian yang ingin di-unlock.`,
      { parse_mode: 'HTML', reply_to_message_id: msg.message_id, reply_markup: { inline_keyboard: rows } }
    );
  } catch (e) { cleanupUnlockSession(key); throw e; }
}
async function processUnlockZipSession(bot, key, mode) {
  const st = unlockZipSessions.get(key);
  if (!st) throw new Error('Sesi ZIP unlock sudah kedaluwarsa.');
  if (Date.now() - st.createdAt > UNLOCK_ZIP_TTL) { cleanupUnlockSession(key); throw new Error('Sesi ZIP unlock sudah kedaluwarsa.'); }
  const indexes = mode === 'all' ? st.info.candidates.map((_, i) => i) : [...st.selected];
  if (!indexes.length) throw new Error('Belum ada file yang dipilih.');
  const selectedNames = new Set(indexes.map(i => st.info.candidates[i]?.name).filter(Boolean));
  const src = new AdmZip(st.zipPath), out = new AdmZip();
  let unlocked = 0, skipped = 0;
  for (const e of src.getEntries()) {
    if (e.isDirectory) { out.addFile(e.entryName, Buffer.alloc(0)); continue; }
    const name = zipEntrySafeName(e.entryName);
    if (!name) continue;
    let data = e.getData();
    let outputName = name;
    if (selectedNames.has(name)) {
      try {
        data = Buffer.from(await crackJsSource(data.toString('utf8')), 'utf8');
        outputName = name.replace(/\.enc$/i, '.js');
        unlocked++;
      } catch {
        skipped++;
        // Jangan ubah file yang gagal di-unlock. Pertahankan byte + nama aslinya.
        outputName = name;
      }
    }
    // File yang TIDAK dipilih harus tetap persis seperti source ZIP.
    out.addFile(outputName, data);
  }
  if (!unlocked) throw new Error('Tidak ada file yang berhasil di-unlock. File mungkin memakai enkripsi/password yang tidak didukung.');
  const outPath = path.join(st.dir, `unlocked-${st.fileName}`);
  out.addFile('LIANIX-UNLOCK-MANIFEST.json', Buffer.from(JSON.stringify({ format:'LIANIX UNLOCK', version:1, source:st.fileName, unlocked, skipped, selected:[...selectedNames] }, null, 2)));
  out.writeZip(outPath);
  return { outPath, unlocked, skipped, total: st.info.candidates.length };
}

command(/^\/unlockenc(?:@\w+)?$/i, async (msg) => {
  const chatId = msg.chat.id;
  const target = msg.reply_to_message?.document;
  if (!target) return bot.sendMessage(chatId, '❌ Balas file <b>.js</b>, <b>.enc</b>, atau <b>.zip</b> dengan <code>/unlockenc</code>.', { parse_mode:'HTML' });
  const name = target.file_name || 'file';
  let progress = null;
  let outPath = null;
  try {
    if (/\.zip$/i.test(name)) return await prepareUnlockZipSession(bot, msg, target);
    if (!/\.(?:js|enc)$/i.test(name)) throw new Error('Format yang didukung: .js, .enc, atau .zip.');

    progress = await bot.sendMessage(chatId,
      `<b>UNLOCK ENC • MENYIAPKAN</b>\n<blockquote expandable>File : <code>${html(name)}</code>\nStatus: <b>Mengunduh file…</b></blockquote>`,
      { parse_mode:'HTML', reply_to_message_id: msg.message_id });
    await updateUnlockProgress(bot, chatId, progress.message_id, 10, 'Mengunduh file');

    const link = await bot.getFileLink(target.file_id);
    const response = await fetch(link);
    if (!response.ok) throw new Error(`Gagal mengunduh file: HTTP ${response.status}`);
    const source = await response.text();
    await updateUnlockProgress(bot, chatId, progress.message_id, 25, 'Membaca source');

    // Validasi bahwa input memang JavaScript/obfuscated JavaScript.
    if (!source.trim()) throw new Error('File kosong.');
    await updateUnlockProgress(bot, chatId, progress.message_id, 45, 'Menganalisis obfuscation');
    const code = await crackJsSource(source);
    await updateUnlockProgress(bot, chatId, progress.message_id, 75, 'Merapikan hasil deobfuscation');

    // Hasil unlock harus tetap JavaScript yang valid. Jangan kirim hasil parsial.
    try { new Function(code); } catch (e) { throw new Error(`Hasil unlock tidak valid: ${e.message}`); }
    outPath = path.join(ENC_TMP_DIR, `unlocked-${name.replace(/\.enc$/i, '.js')}`);
    await fs.writeFile(outPath, code, 'utf8');
    await updateUnlockProgress(bot, chatId, progress.message_id, 92, 'Memvalidasi hasil');

    await bot.sendDocument(chatId, outPath, {
      reply_to_message_id: msg.message_id,
      filename: path.basename(outPath),
      caption: '<b>UNLOCK ENC BERHASIL</b>\n<blockquote expandable>File hasil sudah divalidasi sebagai JavaScript dan dikirim tanpa mengubah ekstensi hasil.</blockquote>',
      parse_mode:'HTML'
    });
    await updateUnlockProgress(bot, chatId, progress.message_id, 100, 'Selesai');
  } catch (e) {
    if (progress?.message_id) await updateUnlockProgress(bot, chatId, progress.message_id, 100, `Gagal: ${e.message}`);
    else await bot.sendMessage(chatId, `❌ <b>UNLOCK ENC GAGAL</b>\n\n${html(e.message)}`, { parse_mode:'HTML' }).catch(() => {});
  } finally {
    if (progress?.message_id) await bot.deleteMessage(chatId, progress.message_id).catch(() => {});
    if (outPath) await fs.remove(outPath).catch(() => {});
    if (progress?.message_id) unlockProgressState.delete(`${chatId}:${progress.message_id}`);
  }
});

bot.on('callback_query', async (cq) => {
  const data = String(cq.data || '');
  if (!data.startsWith('unlockzip_')) return;
  const msg = cq.message, chatId = msg.chat.id, key = unlockKey(chatId, cq.from.id);
  const st = unlockZipSessions.get(key);
  await bot.answerCallbackQuery(cq.id).catch(() => {});
  if (!st) return bot.editMessageText('<blockquote expandable>Sesi unlock sudah kedaluwarsa. Kirim ZIP lagi.</blockquote>', {chat_id:chatId,message_id:msg.message_id,parse_mode:'HTML'}).catch(()=>{});
  if (data === 'unlockzip_cancel') { cleanupUnlockSession(key); return bot.editMessageText('<blockquote expandable>UNLOCK ZIP DIBATALKAN</blockquote>', {chat_id:chatId,message_id:msg.message_id,parse_mode:'HTML'}).catch(()=>{}); }
  if (data === 'unlockzip_pick' || data === 'unlockzip_back') {
    const rows = st.info.candidates.map((f,i)=>[{text:`${st.selected.has(i)?'☑':'☐'} ${f.name}`,callback_data:`unlockzip_file_${i}`}]);
    rows.push([{text:`UNLOCK ${st.selected.size} FILE`,callback_data:'unlockzip_selected'}],[{text:'RESET',callback_data:'unlockzip_reset'},{text:'‹‹‹',callback_data:'unlockzip_back'}]);
    return bot.editMessageText('<b>PILIH FILE UNTUK UNLOCK</b>\n\nCentang file yang ingin dibuka.', {chat_id:chatId,message_id:msg.message_id,parse_mode:'HTML',reply_markup:{inline_keyboard:rows}}).catch(()=>{});
  }
  if (data.startsWith('unlockzip_file_')) {
    const i=Number(data.slice('unlockzip_file_'.length));
    if (Number.isInteger(i)&&st.info.candidates[i]) st.selected.has(i)?st.selected.delete(i):st.selected.add(i);
    const rows=st.info.candidates.map((f,j)=>[{text:`${st.selected.has(j)?'☑':'☐'} ${f.name}`,callback_data:`unlockzip_file_${j}`}]);
    rows.push([{text:`UNLOCK ${st.selected.size} FILE`,callback_data:'unlockzip_selected'}],[{text:'RESET',callback_data:'unlockzip_reset'},{text:'‹‹‹',callback_data:'unlockzip_back'}]);
    return bot.editMessageText('<b>PILIH FILE UNTUK UNLOCK</b>', {chat_id:chatId,message_id:msg.message_id,parse_mode:'HTML',reply_markup:{inline_keyboard:rows}}).catch(()=>{});
  }
  if (data === 'unlockzip_reset') { st.selected.clear(); return bot.editMessageText('<b>PILIH FILE UNTUK UNLOCK</b>\n\nPilihan di-reset.', {chat_id:chatId,message_id:msg.message_id,parse_mode:'HTML',reply_markup:{inline_keyboard:[[ {text:'PILIH FILE',callback_data:'unlockzip_pick'} ]]}}).catch(()=>{}); }
  if (data === 'unlockzip_all' || data === 'unlockzip_selected') {
    if (data === 'unlockzip_selected' && !st.selected.size) return bot.answerCallbackQuery(cq.id,{text:'Pilih minimal 1 file.',show_alert:true}).catch(()=>{});
    try {
      await updateUnlockProgress(bot, chatId, msg.message_id, 5, 'Menyiapkan file ZIP');
      await updateUnlockProgress(bot, chatId, msg.message_id, 20, 'Menganalisis file terpilih');
      const result=await processUnlockZipSession(bot,key,data==='unlockzip_all'?'all':'selected');
      await updateUnlockProgress(bot, chatId, msg.message_id, 85, `Menyusun ZIP hasil • ${result.unlocked} berhasil`);
      await bot.sendDocument(chatId,result.outPath,{filename:`unlocked-${st.fileName}`,caption:`<b>UNLOCK ZIP SELESAI</b>\n<blockquote expandable>Berhasil: <b>${result.unlocked}</b>\nGagal: <b>${result.skipped}</b>\nFile yang tidak dipilih tetap dipertahankan apa adanya.</blockquote>`,parse_mode:'HTML',reply_to_message_id:msg.message_id});
      await updateUnlockProgress(bot, chatId, msg.message_id, 100, 'Selesai');
      cleanupUnlockSession(key);
      return bot.editMessageText('<blockquote expandable><b>UNLOCK ZIP BERHASIL</b>\nFile hasil sudah dikirim.</blockquote>',{chat_id:chatId,message_id:msg.message_id,parse_mode:'HTML'}).catch(()=>{});
    } catch(e) {
      await updateUnlockProgress(bot, chatId, msg.message_id, 100, `Gagal: ${e.message}`);
      return bot.editMessageText(`<blockquote expandable><b>UNLOCK ZIP GAGAL</b>\n${html(e.message)}</blockquote>`,{chat_id:chatId,message_id:msg.message_id,parse_mode:'HTML'}).catch(()=>{});
    }
  }
});

}


// Lazy export: loading this module never runs ENC. The encoder is invoked only when
// a caller explicitly calls obfuscateSource(), e.g. /enc or Backup Center.
module.exports.getObfuscationConfig = getObfuscationConfig;
module.exports.obfuscateSource = async function obfuscateSource(fileContent, level = "high") {
  const code = String(fileContent);
  if (!code.trim()) throw new Error("File JS kosong");
  try { new Function(code); } catch (e) { throw new Error(`Kode tidak valid: ${e.message}`); }
  const cfg = getObfuscationConfig(level);
  let result = await JsConfuser.obfuscate(code, cfg);
  let output = result && result.code ? result.code : result;
  if (typeof output !== "string" || !output.trim()) throw new Error("Hasil ENC tidak valid");
  // Validasi output — jika JsConfuser menghasilkan duplicate declaration (bisa terjadi
  // pada file dengan banyak nested scope + controlFlowFlattening tinggi), retry sekali
  // dengan identifierGenerator yang dijamin unik.
  try {
    new Function(output);
  } catch (validErr) {
    if (/duplicate declaration|identifier .* has already been declared/i.test(validErr.message)) {
      const saferCfg = { ...cfg, identifierGenerator: "hexadecimal" };
      const retried = await JsConfuser.obfuscate(code, saferCfg);
      output = retried && retried.code ? retried.code : retried;
      if (typeof output !== "string" || !output.trim()) throw new Error("Hasil ENC tidak valid setelah retry");
      try { new Function(output); } catch (e) { throw new Error(`Hasil ENC tidak valid: ${e.message}`); }
    } else {
      throw new Error(`Hasil ENC tidak valid: ${validErr.message}`);
    }
  }
  return output;
};
