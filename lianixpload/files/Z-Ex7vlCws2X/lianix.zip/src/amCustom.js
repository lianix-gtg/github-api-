/**
 * AM CUSTOM EMAIL TELEGRAM BRIDGE
 * ZNN Alight Motion API
 */
const https = require('https');
const { URL } = require('url');

const API_BASE = 'https://znn-alightmotion.vercel.app/api';

function post(path, body) {
  return new Promise((resolve, reject) => {
    const url = new URL(path, API_BASE + '/');
    const payload = JSON.stringify(body);
    const req = https.request(url, {
      method: 'POST',
      timeout: 30000,
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(payload),
        'Referer': 'https://znn-alightmotion.vercel.app/'
      }
    }, res => {
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => {
        const text = Buffer.concat(chunks).toString('utf8');
        let json = null;
        try { json = JSON.parse(text); } catch {}
        resolve({ statusCode: res.statusCode, text, json });
      });
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('timeout')); });
    req.write(payload);
    req.end();
  });
}

async function sendEmail(email) {
  if (!email || !email.includes('@')) throw new Error('Email tidak valid.');
  return post('/send', { email });
}

async function verifyLink(email, link) {
  if (!email || !email.includes('@')) throw new Error('Email tidak valid.');
  if (!/^https?:\/\//i.test(link)) throw new Error('Link tidak valid.');
  return post('/verify', { email, link });
}

module.exports = { sendEmail, verifyLink, API_BASE };
