const axios = require('axios');
const cheerio = require('cheerio');

class GeneratorEmail {
  static BASE_URL = 'https://generator.email';
  static WS_URL = 'wss://generator.email/notificon/ws';
  static VERSION = '3.0.0';
  static DEFAULT_USER_AGENT =
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36';

  constructor(options = {}) {
    this.userAgent = options.userAgent || GeneratorEmail.DEFAULT_USER_AGENT;
    this.timeout = options.timeout || 15000;
    this.cacheTtl = options.cacheTtl || 300000;
    this._apiToken = null;
    this._tokenFetchedAt = 0;
    this._cachedDomains = [];
    this._domainsFetchedAt = 0;
    this.cookies = new Map();
  }

  _getHeaders(extra = {}) {
    const headers = {
      'User-Agent': this.userAgent,
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
      'Accept-Language': 'en-US,en;q=0.9,id;q=0.8',
      ...extra,
    };
    if (this.cookies.size) {
      headers.Cookie = [...this.cookies.entries()].map(([k, v]) => `${k}=${v}`).join('; ');
    }
    return headers;
  }

  _updateCookies(headers) {
    const raw = headers?.['set-cookie'];
    if (!raw) return;
    for (const cookie of (Array.isArray(raw) ? raw : [raw])) {
      const [name, ...parts] = String(cookie).split(';')[0].split('=');
      if (name) this.cookies.set(name.trim(), parts.join('=').trim());
    }
  }

  async getApiToken(forceRefresh = false) {
    const now = Date.now();
    if (this._apiToken && !forceRefresh && now - this._tokenFetchedAt < this.cacheTtl) {
      return this._apiToken;
    }
    const res = await axios.get(`${GeneratorEmail.BASE_URL}/`, {
      headers: this._getHeaders(),
      timeout: this.timeout,
      validateStatus: () => true,
    });
    this._updateCookies(res.headers);
    if (res.status !== 200) throw new Error(`Generator.email HTTP ${res.status}`);
    const $ = cheerio.load(res.data);
    const token = $('meta[name="api-token"]').attr('content');
    if (!token) throw new Error('Generator.email api-token tidak ditemukan');
    this._apiToken = token.trim();
    this._tokenFetchedAt = now;
    return this._apiToken;
  }

  async getActiveDomains(forceRefresh = false) {
    const now = Date.now();
    if (this._cachedDomains.length && !forceRefresh && now - this._domainsFetchedAt < this.cacheTtl) {
      return this._cachedDomains;
    }
    try {
      const token = await this.getApiToken(forceRefresh);
      const headers = this._getHeaders({
        'X-API-Token': token,
        'X-Requested-With': 'XMLHttpRequest',
        Referer: `${GeneratorEmail.BASE_URL}/`,
      });
      let res = await axios.get(`${GeneratorEmail.BASE_URL}/api/domains.php`, {
        headers, timeout: this.timeout, validateStatus: () => true,
      });
      if (res.status === 403) {
        headers['X-API-Token'] = await this.getApiToken(true);
        res = await axios.get(`${GeneratorEmail.BASE_URL}/api/domains.php`, {
          headers, timeout: this.timeout, validateStatus: () => true,
        });
      }
      if (res.status === 200 && Array.isArray(res.data)) {
        const domains = res.data
          .map(x => typeof x === 'object' && x ? (x.ascii || x.display) : null)
          .filter(Boolean).map(x => String(x).trim().toLowerCase());
        if (domains.length) {
          this._cachedDomains = domains;
          this._domainsFetchedAt = now;
          return domains;
        }
      }
    } catch (e) {
      if (this._cachedDomains.length) return this._cachedDomains;
      throw e;
    }
    throw new Error('Generator.email tidak mengembalikan domain aktif');
  }

  sanitizeUsername(username) {
    if (!username) return `user_${Math.floor(Date.now() / 1000)}`;
    const cleaned = String(username).trim().toLowerCase().replace(/[^a-z0-9_.-]/g, '');
    return cleaned || `user_${Math.floor(Date.now() / 1000)}`;
  }

  async generateEmail(username = null, domain = null) {
    const domains = await this.getActiveDomains();
    let selected = domain ? String(domain).trim().toLowerCase().replace(/^@/, '') : '';
    if (!selected || !domains.includes(selected)) {
      selected = domains[Math.floor(Math.random() * domains.length)];
    }
    const user = username ? this.sanitizeUsername(username) : `user_${Math.random().toString(36).slice(2, 12)}`;
    return `${user}@${selected}`.toLowerCase();
  }

  async checkInbox(email) {
    const formatted = String(email || '').trim().toLowerCase();
    if (!formatted.includes('@')) throw new Error('Email tidak valid');
    const [username, domain] = formatted.split('@');
    this.cookies.set('inbox_ctx', encodeURIComponent(`${domain}/${username}/`));
    this.cookies.set('surl', `${domain}/${username}`);
    this.cookies.set('embx', encodeURIComponent(JSON.stringify([formatted])));

    const res = await axios.get(`${GeneratorEmail.BASE_URL}/inbox1/`, {
      headers: this._getHeaders({ Referer: `${GeneratorEmail.BASE_URL}/` }),
      timeout: this.timeout,
      validateStatus: () => true,
    });
    this._updateCookies(res.headers);
    if (res.status !== 200) throw new Error(`Inbox HTTP ${res.status}`);

    const $ = cheerio.load(res.data);
    const messages = [];
    $('#email-table .list-group-item').each((_, el) => {
      const item = $(el);
      const onclick = item.attr('onclick') || '';
      const match = onclick.match(/loadInboxClientSide\(['"](.*?)['"]\)/);
      messages.push({
        from: item.find('[class*="from_div"]').text().trim(),
        subject: item.find('[class*="subj_div"]').text().trim(),
        date: item.find('[class*="time_div"]').text().trim(),
        link: match ? match[1] : '',
      });
    });
    return { email: formatted, messages };
  }

  async readMessage(email, linkOrMsgId) {
    const formatted = String(email || '').trim().toLowerCase();
    const [username, domain] = formatted.split('@');
    const link = String(linkOrMsgId || '').replace(/^\//, '');
    const url = link.startsWith(domain)
      ? `${GeneratorEmail.BASE_URL}/${link}`
      : `${GeneratorEmail.BASE_URL}/${domain}/${username}/${link}`;
    this.cookies.set('inbox_ctx', encodeURIComponent(`${domain}/${username}/${link}`));
    this.cookies.set('surl', `${domain}/${username}`);
    this.cookies.set('embx', encodeURIComponent(JSON.stringify([formatted])));

    const res = await axios.get(url, {
      headers: this._getHeaders({ Referer: `${GeneratorEmail.BASE_URL}/inbox1/` }),
      timeout: this.timeout,
      validateStatus: () => true,
    });
    this._updateCookies(res.headers);
    if (res.status !== 200) throw new Error(`Message HTTP ${res.status}`);

    const $ = cheerio.load(res.data);
    const { bodyText, rawHtml } = this._extractBody($);
    const links = this._extractVerificationLinks(rawHtml);
    return {
      email: formatted,
      from: this._headerValue($('#mail-summary-head').text(), /(?:from|dari):\s*(.+)/i),
      subject: this._headerValue($('#mail-summary-head').text(), /(?:subject|subjek):\s*(.+)/i),
      date: this._headerValue($('#mail-summary-head').text(), /(?:date|tanggal|received):\s*(.+)/i),
      bodyText,
      body: rawHtml,
      verification_link: links.primary_link,
      all_links: links.all_links,
    };
  }

  _headerValue(text, re) {
    const m = String(text || '').match(re);
    return m ? m[1].trim() : '';
  }

  _extractBody($) {
    const selectors = ['div.mess_bodiyy','div[class*="mess_bod"]','div.user_mess_content','#email_content','#mail-summary-body'];
    for (const sel of selectors) {
      const node = $(sel).first();
      if (!node.length) continue;
      const clone = node.clone();
      clone.find('script,style,ins,button,iframe,.adsbygoogle,.mesg-row,.mailsrc-panel,.tooltip-container').remove();
      return { bodyText: clone.text().replace(/\n\s*\n/g, '\n').trim(), rawHtml: clone.html() || '' };
    }
    return { bodyText: '', rawHtml: '' };
  }

  _extractVerificationLinks(html) {
    if (!html) return { primary_link: null, all_links: [] };
    const $ = cheerio.load(html);
    const action = ['verify','verifikasi','confirm','konfirmasi','activate','aktifkan','click here','klik di sini','login','reset password','complete registration','get started','join','accept','approve'];
    const ignore = ['unsubscribe','privacy policy','terms','facebook','twitter','instagram','linkedin','youtube','help center','support','preferences','settings','android','ios'];
    const links = [];
    let primary = null;
    let best = -1;
    $('a[href]').each((_, el) => {
      const href = String($(el).attr('href') || '').trim();
      if (!/^https?:\/\//i.test(href)) return;
      const text = $(el).text().trim();
      const low = `${text} ${href}`.toLowerCase();
      if (ignore.some(x => low.includes(x))) return;
      let score = 0;
      for (const kw of action) {
        if (text.toLowerCase().includes(kw)) score += 15;
        if (href.toLowerCase().includes(kw)) score += 5;
      }
      if (/token=|code=|key=|verify|activate|confirmation|auth/i.test(href)) score += 10;
      if (!links.some(x => x.url === href)) links.push({ text, url: href, score });
      if (score > best) { best = score; primary = href; }
    });
    links.sort((a,b) => b.score - a.score);
    return { primary_link: primary || links[0]?.url || null, all_links: links.map(x => ({ text:x.text, url:x.url })) };
  }
}

module.exports = { GeneratorEmail };
