// src/roleAccess.js
// Manajemen role yang diberikan melalui Code Redeem.
// Role redeem bisa punya masa aktif; setelah expired user otomatis dikeluarkan
// dari file role agar seluruh pengecekan lama tetap kompatibel.

const fs = require("fs");
const path = require("path");

const ROOT = path.join(__dirname, "..");
const EXPIRY_FILE = path.join(ROOT, "db", "redeemRoleExpiry.json");

const ROLE_FILES = {
  reseller: path.join(ROOT, "db/users/resellerUsers.json"),
  premium: path.join(ROOT, "db/users/premiumUsers.json"),
  pt: path.join(ROOT, "db/users/ptUsers.json"),
  tk: path.join(ROOT, "db/users/tkUsers.json"),
  ceo: path.join(ROOT, "db/users/ceoUsers.json"),
  founder: path.join(ROOT, "db/users/founderUsers.json"),
  pemilik: path.join(ROOT, "db/users/pemilikUsers.json"),
  cofounder: path.join(ROOT, "db/users/cofounderUsers.json"),
  king: path.join(ROOT, "db/users/kingUsers.json"),
  khusus: path.join(ROOT, "db/users/khususUsers.json"),
  god: path.join(ROOT, "db/users/godUsers.json"),
  resellervps: path.join(ROOT, "db/users/resellerVps.json"),
};

function loadJson(file, fallback) {
  try {
    if (!fs.existsSync(file)) return fallback;
    return JSON.parse(fs.readFileSync(file, "utf8"));
  } catch {
    return fallback;
  }
}

function saveJson(file, data) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

function loadExpiry() {
  const data = loadJson(EXPIRY_FILE, {});
  return data && typeof data === "object" && !Array.isArray(data) ? data : {};
}

function saveExpiry(data) {
  saveJson(EXPIRY_FILE, data);
}

function key(role, userId) {
  return `${String(role).toLowerCase()}:${String(userId)}`;
}

function setRoleExpiry(role, userId, expiresAt) {
  const data = loadExpiry();
  const k = key(role, userId);
  if (expiresAt === null || expiresAt === undefined) delete data[k];
  else data[k] = Number(expiresAt);
  saveExpiry(data);
}

function getRoleExpiry(role, userId) {
  const data = loadExpiry();
  const value = data[key(role, userId)];
  return Number.isFinite(Number(value)) ? Number(value) : null;
}

function isExpired(role, userId, now = Date.now()) {
  const expiry = getRoleExpiry(role, userId);
  return expiry !== null && expiry <= now;
}

function removeUserFromRoleFile(role, userId) {
  const file = ROLE_FILES[role];
  if (!file) return false;

  const users = loadJson(file, []);
  const id = String(userId);
  const next = users.filter((x) => String(x) !== id);

  if (next.length !== users.length) {
    saveJson(file, next);
    return true;
  }
  return false;
}

function hasActiveRole(role, userId) {
  const file = ROLE_FILES[role];
  if (!file) return false;

  const users = loadJson(file, []).map(String);
  const id = String(userId);
  if (!users.includes(id)) return false;

  if (isExpired(role, id)) {
    removeUserFromRoleFile(role, id);
    const data = loadExpiry();
    delete data[key(role, id)];
    saveExpiry(data);
    return false;
  }

  return true;
}

function cleanupExpiredRoles() {
  const data = loadExpiry();
  const now = Date.now();
  let changed = false;

  for (const [k, expiry] of Object.entries(data)) {
    const sep = k.indexOf(":");
    if (sep <= 0) continue;

    const role = k.slice(0, sep);
    const userId = k.slice(sep + 1);
    const ts = Number(expiry);

    if (!ROLE_FILES[role] || !Number.isFinite(ts) || ts > now) continue;

    removeUserFromRoleFile(role, userId);
    delete data[k];
    changed = true;
  }

  if (changed) saveExpiry(data);
}

function formatDuration(expiresAt) {
  if (expiresAt === null || expiresAt === undefined) return "∞ Unlimited";

  const diff = Number(expiresAt) - Date.now();
  if (diff <= 0) return "⌛ Expired";

  const minute = 60 * 1000;
  const hour = 60 * minute;
  const day = 24 * hour;

  if (diff < hour) return `${Math.max(1, Math.ceil(diff / minute))} menit`;
  if (diff < day) return `${Math.ceil(diff / hour)} jam`;
  return `${Math.ceil(diff / day)} hari`;
}


function restrictedResellerText() {
  return `<blockquote expandable>🚫 <b>AKSES RESELLER TERBATAS</b>

👤 <b>Role</b>
   └ RESELLER

📌 <b>Status</b>
   └ Belum aktif

💬 <b>Akses belum tersedia untuk akun ini.</b>
Silakan hubungi <b>OWNER</b> untuk mendapatkan akses reseller.</blockquote>`;
}

function restrictedResellerKeyboard() {
  let username = "yoennakbobo";
  try {
    const settings = require("../settings.js");
    username = String(settings.dev || username).replace(/^@/, "");
  } catch {}

  return {
    inline_keyboard: [
      [{ text: "◆ Hubungi OWNER", url: `https://t.me/${username}` }],
      [{ text: "↩ Menu Utama", callback_data: "back" }],
    ],
  };
}

function formatExpiryDate(expiresAt) {
  if (expiresAt === null || expiresAt === undefined) return "∞ Unlimited";
  return new Date(Number(expiresAt)).toLocaleString("id-ID", {
    timeZone: "Asia/Jakarta",
    dateStyle: "medium",
    timeStyle: "short",
  }) + " WIB";
}

// Bersihkan saat module dimuat dan secara berkala.
// unref() supaya timer tidak menahan proses Node.js saat bot dimatikan.
cleanupExpiredRoles();
const timer = setInterval(cleanupExpiredRoles, 60 * 1000);
if (timer.unref) timer.unref();

module.exports = {
  ROLE_FILES,
  setRoleExpiry,
  getRoleExpiry,
  hasActiveRole,
  cleanupExpiredRoles,
  formatDuration,
  formatExpiryDate,
  restrictedResellerText,
  restrictedResellerKeyboard,
};
