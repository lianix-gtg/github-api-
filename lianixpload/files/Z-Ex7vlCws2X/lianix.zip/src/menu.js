// src/menu.js
// Helper menu utama VVIP

const fs = require("fs");
const os = require("os");
const theme = require("./theme");
const settings = require("../settings.js");
const roleAccess = require("./roleAccess");

const OWNER_FILE    = "./db/users/adminID.json";
const PREMIUM_FILE  = "./db/users/premiumUsers.json";
const RESELLER_FILE = "./db/users/resellerUsers.json";
const FOUNDER_FILE  = "./db/users/founderUsers.json";
const ROOT_FILE     = "./db/users/rootUsers.json";
const DEV_FILE      = "./db/users/developerUsers.json";

function loadArr(file) {
  try {
    if (!fs.existsSync(file)) return [];
    return JSON.parse(fs.readFileSync(file)).map(String);
  } catch {
    return [];
  }
}

function mapAlpha(str, upperBase, lowerBase) {
  return str.replace(/[A-Za-z]/g, (ch) => {
    const code = ch.charCodeAt(0);
    if (code >= 65 && code <= 90) return String.fromCodePoint(upperBase + (code - 65));
    if (code >= 97 && code <= 122) return String.fromCodePoint(lowerBase + (code - 97));
    return ch;
  });
}
function toBoldSans(str) {
  let out = mapAlpha(str, 0x1d5d4, 0x1d5ee);
  out = out.replace(/[0-9]/g, (d) => String.fromCodePoint(0x1d7ec + (d.charCodeAt(0) - 48)));
  return out;
}
function toBoldScript(str) {
  return mapAlpha(str, 0x1d4d0, 0x1d4ea);
}

const UI = { deco: "⟐" };

// Semua ikon: murni simbol unicode, bukan emoji
// ↯=zigzag ◉=bullseye ⟡=lozenge ⌖=position ◈=circle-dot ◆=diamond ⌀=diameter
function identityCard({ username, status, timeLabel, timeValue, footer }) {
  const statusIcon =
    status === "Developer" ? "↯" :
    status === "Root"      ? "◉" :
    status === "Founder"   ? "⟡" :
    status === "Owner"     ? "⌖" :
    status === "Premium"   ? "◈" :
    status === "Reseller"  ? "◆" : "⌀";

  return (
    `⟐ ${toBoldSans("#LianiX")} ⟐\n\n` +
    `<blockquote expandable>` +
    `${toBoldScript("Member")}   : ${username}\n` +
    `${toBoldScript("Rank")}     : ${statusIcon} ${toBoldSans(status)}\n` +
    `${toBoldScript(timeLabel)}   : ${timeValue}` +
    `</blockquote>\n\n` +
    `→ ${footer}`
  );
}

function getStatus(userId) {
  roleAccess.cleanupExpiredRoles();
  const uid = String(userId);
  if (loadArr(DEV_FILE).includes(uid))      return "Developer";
  if (loadArr(ROOT_FILE).includes(uid))     return "Root";
  if (loadArr(FOUNDER_FILE).includes(uid))  return "Founder";
  if (loadArr(OWNER_FILE).includes(uid))    return "Owner";
  if (loadArr(PREMIUM_FILE).includes(uid))  return "Premium";
  if (loadArr(RESELLER_FILE).includes(uid)) return "Reseller";
  return "User";
}

// ============================================================
//  MAIN MENU KEYBOARD
//  Semua label tombol: bold sans + simbol unicode, BUKAN emoji
//  Layout 2 kolom, callback_data semua unik
// ============================================================
function mainMenuKeyboard(userId) {
  const t = theme.getTheme();
  const status = getStatus(userId);

  const btn  = (text, cb) => theme.styled({ text, callback_data: cb }, t);
  const uBtn = (text, url) => theme.styled({ text, url }, t);

  // SINGLE CANONICAL DASHBOARD.
  // Jangan tambahkan Tools/AI/Downloader/Game/Search/Image sebagai tombol
  // terpisah. Semua fitur tersebut masuk ke Group Menu.
  const rows = [
    [ btn("Create Panel", "createpanel"), btn("Install Panel", "installmenu") ],
    [ btn("WhatsApp Panel", "cpanelwa"), btn("VPS / CVPS", "cvpsmenu") ],
    [ btn("Tools Center", "toolsmenu") ],
    [ btn("Protection", "protectmenu"), btn("Encryption", "encryptmenu") ],
    [ btn("Group Tools", "groupmenu"), btn("Special Features", "cekfitur") ],
    [ btn("Code Redeem", "coderedeem"), btn("Owner Center", "ownermenu") ],
    ...(settings.isOwner && settings.isOwner(userId) ? [[ btn("DevPanel", "devpanel") ]] : []),
  ];

  try {
    const ps = require('./data/panelStore.js');
    if (ps.PANEL_KEYS.some(k => { const x = ps.getPanel(k); return x?.domain && x?.plta; })) {
      rows.splice(2, 0, [btn("My Panel", "mypanel")]);
    }
  } catch {}

  rows.push([ btn("Chat Owner", "relay_start") ]);

  rows.push([ uBtn("Buy Script", settings.buyScriptUrl) ]);
  rows.push([ btn("‹‹‹", "dashboard_back_start") ]);

  return { inline_keyboard: rows };
}

function mainMenuText(userId, username) {
  const { getUserRoleExtended, ROLE_DISPLAY_LABELS } = require('./limit.js');
  const roleKey = getUserRoleExtended(String(userId));
  const roleFull = ROLE_DISPLAY_LABELS[roleKey] || 'USER';

  return (
    `<blockquote expandable>` +
    `<b>𝙸𝙽𝙵𝙾 𝚄𝚂𝙴𝚁</b>\n` +
    `⪼ <b>Username :</b> ${username}\n` +
    `⪼ <b>ID :</b> <code>${userId}</code>\n` +
    `⪼ <b>Role :</b> ${roleFull}` +
    `</blockquote>\n\n` +
    `<blockquote expandable>` +
    `<b>𝙸𝙽𝙵𝙾 𝙱𝙾𝚃</b>\n` +
    `⪼ <b>Name Bot :</b> Lianix Asisten\n` +
    `⪼ <b>Version Bot :</b> 6.1 Premium\n` +
    `⪼ <b>Runtime Bot :</b> ${Math.floor(process.uptime()/86400)} hari ${Math.floor((process.uptime()%86400)/3600)} jam ${Math.floor((process.uptime()%3600)/60)} menit` +
    `</blockquote>\n\n` +
    `<blockquote expandable>` +
    `<b>𝚂ＰＥ𝙲𝙸𝙰𝙻 𝙼𝙴𝙽𝚄</b>\n` +
    `⪼ <b>/info</b> - Cek info user\n` +
    `⪼ <b>/cekserver</b> - Cek server on\n` +
    `⪼ <b>/cekid</b> - Cek ID\n` +
    `⪼ <b>/totalserver</b> - Total server\n` +
    `⪼ <b>/servercpu</b> - Cek CPU server\n` +
    `⪼ <b>/backup</b> - Backup file` +
    `</blockquote>\n\n` +
    `<blockquote><b>LIANIX CPANEL</b></blockquote>`
  );
}

async function showMainMenu(bot, chatId, messageId, userId, fromUser) {
  if (typeof theme.bindMenuBot === "function") theme.bindMenuBot(bot);
  const username = fromUser?.username
    ? "@" + fromUser.username
    : fromUser?.first_name || "Pengguna";

  const text         = mainMenuText(userId, username);
  const reply_markup = mainMenuKeyboard(userId);

  if (messageId) {
    const opts = { chat_id: chatId, message_id: messageId, parse_mode: "HTML", reply_markup };

    // Jangan menganggap hasil `{ ok:false }`, `{ skipped:true }`, atau `null`
    // sebagai edit yang berhasil. Wrapper Telegram di index.js/runtimeGuard.js
    // memang bisa mengembalikan sentinel tersebut saat target adalah foto,
    // kena throttle, atau edit tidak dapat dilakukan. Kalau langsung `return`,
    // tombol BUKA DASHBOARD terlihat seperti tidak merespons.
    try {
      const result = await bot.editMessageText(text, opts);
      const editFailed = result == null || result?.ok === false || result?.skipped === true;
      if (!editFailed) {
        theme.registerMenuMessage(chatId, messageId, userId, username);
        return;
      }
    } catch { /* lanjut ke caption */ }

    try {
      const result = await bot.editMessageCaption(text, opts);
      const editFailed = result == null || result?.ok === false || result?.skipped === true;
      if (!editFailed) {
        theme.registerMenuMessage(chatId, messageId, userId, username);
        return;
      }
    } catch { /* fallback ke pesan baru */ }
  }

  const sent = await bot.sendMessage(chatId, text, { parse_mode: "HTML", reply_markup });
  if (sent?.message_id) theme.registerMenuMessage(chatId, sent.message_id, userId, username);
}

module.exports = {
  showMainMenu,
  mainMenuText,
  mainMenuKeyboard,
  identityCard,
  toBoldSans,
  toBoldScript,
  UI,
  getStatus,
};
