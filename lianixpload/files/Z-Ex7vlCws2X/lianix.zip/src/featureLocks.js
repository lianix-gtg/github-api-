const fs = require("fs");
const path = require("path");

const FILE = path.resolve("./db/featureLocks.json");
const DEFAULT = {
  version: 1,
  adpLocked: false,
  unliLocked: false,
  updatedAt: "",
  updatedBy: ""
};

function ensure() {
  const dir = path.dirname(FILE);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  if (!fs.existsSync(FILE)) fs.writeFileSync(FILE, JSON.stringify(DEFAULT, null, 2));
}
function load() {
  ensure();
  try {
    const raw = JSON.parse(fs.readFileSync(FILE, "utf8"));
    return { ...DEFAULT, ...(raw && typeof raw === "object" ? raw : {}) };
  } catch {
    return { ...DEFAULT };
  }
}
function save(patch = {}) {
  const next = { ...load(), ...(patch && typeof patch === "object" ? patch : {}), updatedAt: new Date().toISOString() };
  fs.writeFileSync(FILE, JSON.stringify(next, null, 2));
  return next;
}
function isAdpLocked() { return load().adpLocked === true; }
function isUnliLocked() { return load().unliLocked === true; }
function setAdpLocked(locked, updatedBy = "") { return save({ adpLocked: !!locked, updatedBy: String(updatedBy || "") }); }
function setUnliLocked(locked, updatedBy = "") { return save({ unliLocked: !!locked, updatedBy: String(updatedBy || "") }); }
function statusText() {
  const s = load();
  return [
    "<b>FEATURE LOCK STATUS</b>",
    "",
    `├ ADP : <b>${s.adpLocked ? "LOCKED" : "UNLOCKED"}</b>`,
    `├ UNLI: <b>${s.unliLocked ? "LOCKED" : "UNLOCKED"}</b>`,
    `╰ Updated: <code>${s.updatedAt || "-"}</code>`
  ].join("\n");
}
module.exports = { load, save, isAdpLocked, isUnliLocked, setAdpLocked, setUnliLocked, statusText };
