const settings = require("../settings");

const ID_OWNER = settings.ownerId.toString();

/**
 * NOTE (update): seluruh command /installprotectN & sejenisnya (tema, node,
 * wings, dsb) sudah DIMATIKAN di protect.js & install.js karena terbukti
 * menjalankan script dari repo GitHub pihak ketiga yang tidak terverifikasi
 * -- salah satunya (pr1.sh dari rexzy223/pro) terbukti backdoor: mengganti
 * password root VPS lalu mengirimkannya diam-diam ke Telegram pembuat script.
 *
 * File checklist ini sengaja disederhanakan jadi satu command informasi,
 * supaya user tidak lagi diarahkan mengikuti langkah instalasi yang
 * sebenarnya sudah nonaktif.
 */
module.exports = (bot) => {
  bot.onText(/^\/panduanprotect(?:all|\d+)?$/i, async (msg) => {
    const chatId = msg.chat.id;
    const userId = String(msg.from.id);
    if (userId !== ID_OWNER) return;
    return bot.sendMessage(chatId,
      "🛡 *LIANIX PROTECT PANEL*\n\n" +
      "Protect versi lama berbasis script pihak ketiga sudah tidak dipakai. Sistem aktif sekarang memakai middleware lokal Lianix dan dipasang dengan:\n\n" +
      "`/installprotect host|password|id_admin_utama`\n\n" +
      "Setelah SSH dan admin utama tervalidasi, pilih level 1–20 lewat tombol. Untuk melepas seluruh proteksi Lianix gunakan:\n\n" +
      "`/uninstallprotect host|password`",
      { parse_mode: "Markdown" }
    );
  });
};
