// src/relaychat.js
// Fitur "Chat Owner" via tombol — biasanya dipasang di pesan "limit habis"
// biar user bisa langsung nego/nanya ke Owner tanpa keluar dari bot.
//
// Alurnya:
// 1. User pencet tombol "⟐ Chat Owner" -> sesi relay aktif buat user itu.
// 2. Semua pesan (teks) yang dikirim user berikutnya diteruskan ke Owner,
//    dengan header info siapa pengirimnya.
// 3. Owner balikin balesan dengan cara REPLY ke pesan yang diteruskan itu,
//    bot otomatis kirim balesannya ke user yang bersangkutan.
// 4. User (atau Owner) bisa pencet tombol "⊠ Tutup Sesi" buat nutup sesi relay.
// 5. Owner bisa pencet tombol "⚒ Ganti Owner" di pesan relay buat ganti
//    ID/nama Owner tanpa perlu edit settings.js manual (lihat
//    src/data/ownerStore.js — disimpen di db/owner.json).

const settings = require("../settings.js");
const ownerStore = require("./data/ownerStore.js");
const { enqueueSend, isFlood429, getRetryAfterMs } = require("./data/tgQueue.js");
// Dipasang belakangan sama start.js pas modulnya jalan (lihat index.js,
// "./src/start" di-load duluan sebelum "./src/relaychat"), jadi udah
// tersedia begitu handler2 di bawah ini kepanggil.
const startModule = require("./start.js");

// userId (string) -> { chatId, active }
const relaySessions = {};
// message_id (pesan yang diteruskan ke Owner) -> { userId, chatId }
// dipakai buat tau relay balesan Owner harus dikirim ke siapa.
const relayMessageMap = {};
// ownerId (string) -> true kalau lagi nunggu owner ngetik ID/nama owner baru
const pendingOwnerChange = {};

function relayKeyboard() {
  return { inline_keyboard: [[{ text: "⊠ Tutup Sesi", callback_data: "relay_cancel" }]] };
}

module.exports = function registerRelayChat(bot) {
  // ============== Mulai sesi relay ==============
  // FIX: dulu gak ada try/catch sama sekali di sini. Kalau bot.sendMessage
  // gagal SETELAH answerCallbackQuery sukses (network hiccup, rate limit,
  // dll), tombolnya keliatan "delay lalu diem" -> spinner berhenti (karena
  // answerCallbackQuery udah kejawab) tapi gak ada pesan konfirmasi yang
  // muncul sama sekali, dan errornya cuma numpuk di unhandledRejection.
  bot.on("callback_query", async (q) => {
    if (q.data !== "relay_start") return;

    try {
      const userId = String(q.from.id);
      const chatId = q.message.chat.id;

      if (userId === String(ownerStore.getOwnerId())) {
        return bot.answerCallbackQuery(q.id, { text: "Ini kan kamu ownernya ⟡", show_alert: true });
      }

      relaySessions[userId] = { chatId, active: true, menuMessageId: q.message.message_id };
      await bot.answerCallbackQuery(q.id);

      await bot.sendMessage(
        chatId,
        "⟐ Sesi chat ke Owner udah aktif.\nKetik pesan kamu di sini, nanti langsung diteruskan ke Owner. Owner bakal bales lewat bot ini juga.\n\nTekan ◇ Batal kalau udah selesai.",
        { reply_markup: relayKeyboard() }
      );
    } catch (e) {
      console.error("[relaychat] Gagal mulai sesi relay (relay_start):", e.message);
      try {
        await bot.answerCallbackQuery(q.id, { text: "◇ Gagal buka sesi Chat Owner, coba lagi.", show_alert: true });
      } catch (_) {}
      try {
        await bot.sendMessage(q.message.chat.id, "◇ Gagal buka sesi Chat Owner, coba pencet lagi ya.");
      } catch (_) {}
    }
  });

  // ============== Batalin sesi relay ==============
  // FIX: sama kayak relay_start, dulu gak ada try/catch buat bagian
  // editMessageCaption/sendPhoto -> kalau gagal, tombol "Batal" keliatan
  // delay lalu diem tanpa balik ke menu.
  bot.on("callback_query", async (q) => {
    if (q.data !== "relay_cancel") return;

    try {
      const userId = String(q.from.id);

      // Kalau yang mencet Batal itu Owner sendiri (dari sisi chat Owner),
      // gak ada sesi khusus buat di-clear di sisi Owner, cukup dikasih tau aja.
      if (userId === String(ownerStore.getOwnerId())) {
        await bot.answerCallbackQuery(q.id);
        return bot.sendMessage(q.message.chat.id, "✦ Oke, sesi ditutup.");
      }

      const session = relaySessions[userId];
      delete relaySessions[userId];
      await bot.answerCallbackQuery(q.id);

      const chatId = q.message.chat.id;
      const usernameDisplay = q.from.username ? `@${q.from.username}` : (q.from.first_name || "Pengguna");
      const { text, reply_markup } = startModule.buildMainMenuPayload(q.from.id, usernameDisplay);

      // FIX: dulu pesan "Sesi chat ke Owner udah aktif..." (yang tombol
      // Batal-nya dipencet) dibiarin nyangkut di chat, bot cuma nyoba
      // munculin/edit menu utama TERPISAH. Sekarang pesan sesi itu langsung
      // dihapus duluan, baru menu utama ditampilin, biar keliatan kayak
      // beneran "balik ke menu" bukan numpuk pesan baru.
      try {
        await bot.deleteMessage(chatId, q.message.message_id);
      } catch (e) {
        // gagal hapus (misal udah lebih dari 48 jam / pesan udah kehapus
        // duluan) -> gak fatal, lanjut aja nampilin menu utama di bawah.
      }

      // Coba edit balik pesan menu utama yang tombol "Chat Owner"-nya dipencet
      // (pesan foto dengan caption), biar keliatan kayak abis pencet "back".
      if (session && session.menuMessageId) {
        try {
          await bot.editMessageCaption(text, {
            chat_id: chatId,
            message_id: session.menuMessageId,
            parse_mode: "HTML",
            reply_markup,
          });
          return;
        } catch (e) {
          // Pesan lama mungkin kena delete/expired, lanjut fallback di bawah.
        }
      }

      // Fallback: kirim ulang menu utama sebagai pesan baru.
      await bot.sendPhoto(chatId, settings.pp, {
        caption: text,
        parse_mode: "HTML",
        reply_markup,
      });
    } catch (e) {
      console.error("[relaychat] Gagal batalin sesi relay (relay_cancel):", e.message);
      try {
        await bot.answerCallbackQuery(q.id, { text: "◇ Gagal nutup sesi, coba lagi.", show_alert: true });
      } catch (_) {}
      try {
        await bot.sendMessage(q.message.chat.id, "◇ Sesi ditutup, tapi gagal nampilin menu lagi. Ketik /start ya.");
      } catch (_) {}
    }
  });

  // ============== Dev/Owner tutup sesi user tertentu (dari tombol di pesan relay) ==============
  bot.on("callback_query", async (q) => {
    if (!q.data || !q.data.startsWith("relay_close_")) return;

    if (String(q.from.id) !== String(ownerStore.getOwnerId())) {
      return bot.answerCallbackQuery(q.id, { text: "Khusus Owner/Dev.", show_alert: true });
    }

    const targetUserId = q.data.slice("relay_close_".length);
    const session = relaySessions[targetUserId];

    if (!session) {
      return bot.answerCallbackQuery(q.id, { text: "Sesi ini udah ditutup sebelumnya.", show_alert: true });
    }

    delete relaySessions[targetUserId];
    await bot.answerCallbackQuery(q.id, { text: "◉ Sesi user berhasil ditutup." });

    try {
      await bot.sendMessage(session.chatId, "◇ Sesi chat ke Owner udah ditutup oleh Owner.");
    } catch (e) {
      console.error("[relaychat] Gagal notif user soal sesi ditutup owner:", e.message);
    }
  });

  // ============== Owner pencet "⚒ Ganti Owner" ==============
  bot.on("callback_query", async (q) => {
    if (q.data !== "change_owner_start") return;

    try {
      const requesterId = String(q.from.id);
      if (requesterId !== String(ownerStore.getOwnerId())) {
        return bot.answerCallbackQuery(q.id, { text: "Khusus Owner.", show_alert: true });
      }

      pendingOwnerChange[requesterId] = true;
      await bot.answerCallbackQuery(q.id);
      await bot.sendMessage(
        q.message.chat.id,
        "⚒ <b>Ganti Owner/Admin</b>\n\nKirim ID Telegram numerik owner baru, boleh ditambah nama tampilan (pisah pakai spasi).\nContoh: <code>123456789 Kevin</code>\n\nKetik /batalganti buat batalin.",
        { parse_mode: "HTML" }
      );
    } catch (e) {
      console.error("[relaychat] Gagal mulai ganti owner (change_owner_start):", e.message);
      try {
        await bot.answerCallbackQuery(q.id, { text: "◇ Gagal, coba lagi.", show_alert: true });
      } catch (_) {}
    }
  });

  // ============== Terusin pesan USER -> OWNER ==============
  // FIX: sebelumnya try/catch cuma ngebungkus bagian enqueueSend. Kalau ada
  // error DI ATAS try block itu (misal saat baca ownerStore.getOwnerId(),
  // atau akses properti lain), handler-nya reject tanpa ke-catch sama
  // sekali -> user gak dapet respon APAPUN ("diem aja"), errornya cuma
  // numpuk jadi unhandledRejection di console yang gak pernah keliatan
  // user. Sekarang SELURUH badan handler dibungkus try/catch dari paling
  // atas, jadi apapun yang gagal, user PASTI dapet pesan balik (gak akan
  // pernah silent lagi), dan errornya ke-log jelas biar gampang di-debug.
  bot.on("message", async (msg) => {
    try {
      const userId = String(msg.from?.id);
      const session = relaySessions[userId];
      if (!session || !session.active) return;
      if (userId === String(ownerStore.getOwnerId())) return; // owner gak punya sesi ke dirinya sendiri
      if (!msg.text) return;

      console.log(`[relaychat] Pesan masuk dari ${userId} (sesi aktif), diterusin ke owner...`);

      if (msg.text === "/batal") {
        delete relaySessions[userId];
        return bot.sendMessage(msg.chat.id, "◇ Sesi chat ke Owner udah ditutup.");
      }
      if (msg.text.startsWith("/")) return; // biarin command lain jalan normal, jangan ikut ke-relay

      const uname = msg.from.username ? `@${msg.from.username}` : (msg.from.first_name || "Tidak diketahui");
      const ownerId = ownerStore.getOwnerId();

      try {
        // Dilewatin ke antrian global (src/data/tgQueue.js) biar gak ikut
        // numpuk sama fitur lain (broadcast/autoga/dll) yang bisa nge-flood
        // limit bot secara keseluruhan, dan otomatis retry kalau kena 429.
        const sent = await enqueueSend(
          () =>
            bot.sendMessage(
              ownerId,
              `✉ <b>Pesan dari ${uname}</b> (<code>${msg.from.id}</code>)\n\n${msg.text}\n\n<i>Reply pesan ini buat bales ke usernya.</i>`,
              {
                parse_mode: "HTML",
                reply_markup: {
                  inline_keyboard: [
                    [{ text: "◇ Tutup Sesi Ini", callback_data: `relay_close_${userId}` }],
                    [{ text: "⚒ Ganti Owner", callback_data: "change_owner_start" }],
                  ],
                },
              }
            ),
          ownerId
        );
        relayMessageMap[sent.message_id] = { userId, chatId: msg.chat.id, uname };
        await enqueueSend(() => bot.sendMessage(msg.chat.id, "◉ Terkirim ke Owner."), msg.chat.id);
        console.log(`[relaychat] Berhasil diterusin ke owner (${ownerId}), message_id owner: ${sent.message_id}`);
      } catch (e) {
        console.error("[relaychat] Gagal terusin pesan ke owner:", e.message);

        // Error paling umum di titik ini: ownerId gak valid / owner belum
        // pernah /start bot -> Telegram bales "chat not found" / "bot was
        // blocked by the user". Dikasih pesan yang lebih jelas biar gampang
        // ketauan akar masalahnya, bukan cuma "gagal, coba lagi" generik.
        const emsg = String(e.message || "");
        let failMsg;
        if (isFlood429(e)) {
          const ms = getRetryAfterMs(e);
          const mins = ms ? Math.ceil(ms / 60000) : null;
          failMsg = mins
            ? `◇ Bot lagi kena limit kirim pesan dari Telegram, coba lagi dalam ~${mins} menit ya.`
            : "◇ Bot lagi kena limit kirim pesan dari Telegram, coba lagi beberapa saat lagi.";
        } else if (/chat not found/i.test(emsg)) {
          failMsg = "◇ Gagal ngirim ke Owner: ID Owner di db/owner.json salah, atau Owner belum pernah /start bot ini.";
        } else if (/blocked by the user|bot was blocked/i.test(emsg)) {
          failMsg = "◇ Gagal ngirim ke Owner: Owner sepertinya udah block bot ini.";
        } else {
          failMsg = "◇ Gagal ngirim pesan ke Owner, coba lagi.";
        }

        try {
          await bot.sendMessage(msg.chat.id, failMsg);
        } catch (_) {
          // kalau ini juga gagal (misal masih kena limit), diemin aja,
          // gak perlu bikin loop error tambahan.
        }
      }
    } catch (outerErr) {
      // Safety net terakhir: apapun yang error TAK TERDUGA di luar try di
      // atas (termasuk sebelum ownerId kebaca), user tetep dikasih tau,
      // bukan didiemin.
      console.error("[relaychat] Error tak terduga di handler user->owner:", outerErr);
      try {
        await bot.sendMessage(msg.chat.id, "◇ Ada error internal pas ngirim pesan ke Owner. Coba lagi, atau hubungi admin kalau terus kejadian.");
      } catch (_) {}
    }
  });

  // ============== Owner lagi ngetik ID/nama Owner baru ==============
  bot.on("message", async (msg) => {
    const chatId = String(msg.chat.id);
    const currentOwnerId = String(ownerStore.getOwnerId());
    if (chatId !== currentOwnerId) return;
    if (!pendingOwnerChange[currentOwnerId]) return;
    if (!msg.text) return;
    if (msg.reply_to_message) return; // biar gak bentrok sama alur "reply buat bales user"

    if (msg.text === "/batalganti") {
      delete pendingOwnerChange[currentOwnerId];
      return bot.sendMessage(msg.chat.id, "◇ Ganti owner dibatalin.");
    }

    const parts = msg.text.trim().split(/\s+/);
    const newIdRaw = parts[0];
    const newName = parts.slice(1).join(" ") || null;

    if (!/^\d+$/.test(newIdRaw)) {
      return bot.sendMessage(
        msg.chat.id,
        "◇ Format salah. Kirim ID numerik Telegram, contoh: <code>123456789 Kevin</code>\n\nAtau /batalganti buat batalin.",
        { parse_mode: "HTML" }
      );
    }

    const updated = ownerStore.setOwner(newIdRaw, newName);
    delete pendingOwnerChange[currentOwnerId];

    await bot.sendMessage(
      msg.chat.id,
      `◉ Owner berhasil diganti ke <code>${updated.ownerId}</code>${updated.ownerName ? ` (${updated.ownerName})` : ""}.\n\n⚠ Catatan: fitur Chat Owner ini langsung ikut owner baru. Tapi beberapa panel/perintah lain di luar fitur ini masih pakai ID owner lama sampai bot di-restart — restart bot biar semuanya konsisten ke owner baru.`,
      { parse_mode: "HTML" }
    );

    try {
      await bot.sendMessage(
        updated.ownerId,
        "⌖ Kamu baru aja dijadiin Owner bot ini lewat fitur Chat Owner."
      );
    } catch (e) {
      console.error("[relaychat] Gagal notif owner baru (mungkin belum /start bot):", e.message);
    }
  });

  // ============== Terusin balesan OWNER -> USER (via reply) ==============
  bot.on("message", async (msg) => {
    if (String(msg.chat.id) !== String(ownerStore.getOwnerId())) return;
    if (!msg.reply_to_message) return;
    if (!msg.text) return;

    const target = relayMessageMap[msg.reply_to_message.message_id];
    if (!target) return; // reply ke pesan biasa, bukan ke relay -> abaikan

    try {
      await enqueueSend(
        () => bot.sendMessage(target.chatId, `⌖ <b>Owner:</b> ${msg.text}`, { parse_mode: "HTML" }),
        target.chatId
      );
      await enqueueSend(
        () => bot.sendMessage(msg.chat.id, `◉ Balesan terkirim ke ${target.uname}.`),
        msg.chat.id
      );
    } catch (e) {
      console.error("[relaychat] Gagal terusin balesan ke user:", e.message);
      const failMsg = isFlood429(e)
        ? "◇ Bot lagi kena limit kirim pesan dari Telegram, tunggu sebentar lalu reply lagi."
        : "◇ Gagal ngirim balesan, mungkin usernya udah blokir bot.";
      try {
        await bot.sendMessage(msg.chat.id, failMsg);
      } catch (_) {}
    }
  });
};

module.exports.relayKeyboard = relayKeyboard;
