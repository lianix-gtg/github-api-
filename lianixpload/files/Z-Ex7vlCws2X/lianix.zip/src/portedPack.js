/**
 * LIANIX CPANEL — ZETA/OURIN TELEGRAM PACK
 * Adapted from the supplied ZETA-MD source for node-telegram-bot-api.
 * Downloader, uploader, tools and lightweight games.
 */
const fs = require("fs");
const path = require("path");
const os = require("os");
const crypto = require("crypto");
const axios = require("axios");
const { execFile } = require("child_process");
const { promisify } = require("util");
const settings = require("../settings.js");
/**
 * safeReply — sendMessage with reply_to_message_id fallback.
 */
async function safeReply(bot, chatId, text, opts = {}) {
  try {
    return await bot.sendMessage(chatId, text, opts);
  } catch (err) {
    const desc = String(err?.response?.body?.description || err?.message || '');
    if (/message to be replied not found/i.test(desc) && opts.reply_to_message_id) {
      const { reply_to_message_id: _, ...safeOpts } = opts;
      return await bot.sendMessage(chatId, text, safeOpts);
    }
    throw err;
  }
}

const execFileAsync = promisify(execFile);

const UA = "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/130.0 Mobile Safari/537.36";
const sessions = new Map();

const q = (m) => m?.message_id ? { reply_to_message_id: m.message_id } : {};
const esc = (s="") => String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
const pick = a => a[Math.floor(Math.random()*a.length)];

async function ffmpeg() {
  try { await execFileAsync("ffmpeg",["-version"],{timeout:5000}); return true; } catch { return false; }
}

async function getMedia(bot,msg) {
  const t = msg.reply_to_message || msg;
  const id = t.photo?.at(-1)?.file_id || t.video?.file_id || t.document?.file_id ||
    t.audio?.file_id || t.voice?.file_id || t.animation?.file_id || t.sticker?.file_id;
  if (!id) throw new Error("Balas media terlebih dahulu.");
  const f = await bot.getFile(id);
  const url = `https://api.telegram.org/file/bot${settings.token}/${f.file_path}`;
  const r = await axios.get(url,{responseType:"arraybuffer",timeout:90000,maxContentLength:49*1024*1024,maxBodyLength:49*1024*1024,headers:{"User-Agent":UA}});
  return {buffer:Buffer.from(r.data), name:t.document?.file_name || t.audio?.file_name || path.basename(f.file_path) || `media-${Date.now()}`};
}

async function youtubeSearch(query) {
  const yts = require("yt-search");
  const r = await yts(query);
  return r.videos.slice(0,10);
}

async function sendYtResults(bot,msg,query) {
  const items = await youtubeSearch(query);
  if (!items.length) throw new Error("Video tidak ditemukan.");
  const rows = items.map((v,i)=>({text:`${i+1}. ${v.title.slice(0,55)}`,callback_data:`zeta_yt:${msg.from.id}:${encodeURIComponent(v.url)}`}));
  const kb=[]; for(let i=0;i<rows.length;i+=2) kb.push(rows.slice(i,i+2));
  kb.push([{text:"‹‹‹",callback_data:"utilitymenu"}]);
  await bot.sendMessage(msg.chat.id,
    `<b>⌕ YOUTUBE SEARCH</b>\n\nQuery: <code>${esc(query)}</code>\nPilih video untuk diunduh.`,
    {parse_mode:"HTML",reply_markup:{inline_keyboard:kb},...q(msg)});
}

async function ytDownload(bot,msg,url,type="video") {
  const ytdl = require("ytdl-core");
  if (!ytdl.validateURL(url)) throw new Error("URL YouTube tidak valid.");
  const info = await ytdl.getInfo(url);
  const title = info.videoDetails?.title || "YouTube";
  const temp = path.join(os.tmpdir(),`tg-${Date.now()}-${crypto.randomBytes(3).toString("hex")}`);
  const ext = type==="audio" ? "mp3" : "mp4";
  const out = `${temp}.${ext}`;
  try {
    if (type==="audio") {
      if (!(await ffmpeg())) throw new Error("FFmpeg belum terpasang untuk YTMP3.");
      const stream = ytdl(url,{quality:"highestaudio",filter:"audioonly"});
      const input = `${temp}.source`;
      await new Promise((resolve,reject)=>{const w=fs.createWriteStream(input);stream.pipe(w);stream.on("error",reject);w.on("finish",resolve);});
      await execFileAsync("ffmpeg",["-y","-i",input,"-vn","-codec:a","libmp3lame","-q:a","2",out],{timeout:180000,maxBuffer:1024*1024*4});
      await bot.sendAudio(msg.chat.id,out,{caption:`♪ <b>YOUTUBE MP3</b>\n\n${esc(title)}`,parse_mode:"HTML",title,performer:"LIANIX CPANEL",...q(msg)});
      try{fs.unlinkSync(input)}catch{}
    } else {
      const stream = ytdl(url,{quality:"18"});
      await new Promise((resolve,reject)=>{const w=fs.createWriteStream(out);stream.pipe(w);stream.on("error",reject);w.on("finish",resolve);});
      await bot.sendVideo(msg.chat.id,out,{caption:`▶ <b>YOUTUBE MP4</b>\n\n${esc(title)}`,parse_mode:"HTML",supports_streaming:true,...q(msg)});
    }
  } finally { try{fs.unlinkSync(out)}catch{}; try{fs.unlinkSync(`${temp}.source`)}catch{} }
}

async function spotifySearch(bot,msg,query) {
  const res = await axios.get("https://api.hiuraa.my.id/search/spotify",{params:{q:query},timeout:60000});
  const arr = res.data?.result || [];
  if (!arr.length) throw new Error("Lagu tidak ditemukan.");
  const rows=arr.slice(0,10).map((v,i)=>({text:`${i+1}. ${(v.title||"Spotify").slice(0,55)}`,callback_data:`zeta_sp:${msg.from.id}:${encodeURIComponent(v.url||"")}`}));
  const kb=[];for(let i=0;i<rows.length;i+=2)kb.push(rows.slice(i,i+2));
  await bot.sendMessage(msg.chat.id,`<b>♪ SPOTIFY SEARCH</b>\n\n<code>${esc(query)}</code>`,{parse_mode:"HTML",reply_markup:{inline_keyboard:kb},...q(msg)});
}

async function spotifyDownload(bot,msg,url) {
  const mod = require("spotifydl-x");
  const fn = mod.spotifydl || mod.default || mod;
  if (typeof fn!=="function") throw new Error("spotifydl-x API tidak cocok dengan versi terpasang.");
  const r = await fn(url);
  if (!r?.download) throw new Error("Link audio Spotify tidak tersedia.");
  await bot.sendAudio(msg.chat.id,r.download,{caption:`♪ <b>SPOTIFY DOWNLOADER</b>\n\n${esc(r.title||"Spotify")}`,parse_mode:"HTML",title:r.title||"Spotify",performer:r.artis||"Unknown",...q(msg)});
}

async function gitClone(bot,msg,url) {
  const m=url.match(/github\.com[/:]([^/]+)\/([^/#?]+?)(?:\.git)?$/i);
  if(!m) throw new Error("Gunakan link repository GitHub.");
  const api=`https://api.github.com/repos/${m[1]}/${m[2]}/zipball`;
  const r=await axios.get(api,{responseType:"arraybuffer",headers:{Accept:"application/vnd.github+json","User-Agent":"YOEN-CPANEL"},timeout:120000});
  await bot.sendDocument(msg.chat.id,Buffer.from(r.data),{filename:`${m[1]}-${m[2]}.zip`,caption:`◇ <b>GITHUB CLONE</b>\n\n${esc(m[1])}/${esc(m[2])}`,parse_mode:"HTML",...q(msg)});
}

async function githubStalk(bot,msg,user) {
  const r=await axios.get(`https://api.github.com/users/${encodeURIComponent(user)}`,{headers:{"User-Agent":"YOEN-CPANEL"},timeout:30000});
  const d=r.data;
  const text=`<b>◆ GITHUB STALK</b>\n\n<b>Username:</b> ${esc(d.login)}\n<b>Name:</b> ${esc(d.name||"-")}\n<b>ID:</b> <code>${d.id}</code>\n<b>Repo:</b> ${d.public_repos}\n<b>Followers:</b> ${d.followers}\n<b>Following:</b> ${d.following}\n<b>Bio:</b> ${esc(d.bio||"-")}\n<a href="${esc(d.html_url)}">Open GitHub</a>`;
  await bot.sendPhoto(msg.chat.id,d.avatar_url,{caption:text,parse_mode:"HTML",...q(msg)});
}

async function npmStalk(bot,msg,pkg) {
  const r=await axios.get(`https://registry.npmjs.org/${encodeURIComponent(pkg)}`,{timeout:30000});
  const d=r.data;
  await bot.sendMessage(msg.chat.id,`<b>⌘ NPM STALK</b>\n\n<b>Package:</b> <code>${esc(d.name)}</code>\n<b>Version:</b> ${esc(d["dist-tags"]?.latest||"-")}\n<b>Description:</b> ${esc(d.description||"-")}\n<b>License:</b> ${esc(d.license||"-")}\n<b>Repository:</b> ${esc(d.repository?.url||"-")}`,{parse_mode:"HTML",...q(msg)});
}

async function define(bot,msg,word) {
  const r=await axios.get("https://api.urbandictionary.com/v0/define",{params:{term:word},timeout:30000});
  const x=r.data?.list?.[0]; if(!x) throw new Error("Definisi tidak ditemukan.");
  await bot.sendMessage(msg.chat.id,`<b>⌕ DEFINE</b>\n\n<b>${esc(word)}</b>\n\n${esc(x.definition).replace(/\\r?\\n/g,"\n\n")}\n\n<i>Example:</i>\n${esc(x.example||"-")}`,{parse_mode:"HTML",...q(msg)});
}

function gameMenu(bot,msg) {
  return bot.sendMessage(msg.chat.id,
    `<b>🎮 GAME CENTER</b>\n\nPilih game atau gunakan command:\n• <code>/suit</code>\n• <code>/dadu</code>\n• <code>/tebakangka 1-100</code>\n• <code>/susunkata</code>\n• <code>/rate teks</code>\n• <code>/can pertanyaan</code>`,
    {parse_mode:"HTML",reply_markup:{inline_keyboard:[
      [{text:"♟ Suit",callback_data:"zeta_game:suit"},{text:"🎲 Dadu",callback_data:"zeta_game:dadu"}],
      [{text:"⌁ Tebak Angka",callback_data:"zeta_game:angka"},{text:"🔤 Susun Kata",callback_data:"zeta_game:susun"}],
      [{text:"‹‹‹",callback_data:"utilitymenu"}]
    ]},...q(msg)});
}

function rateText(text){return Math.floor(Math.random()*101);}
function answerFun(cmd,text){
  const yes=["Bisa","Tentu bisa","Kemungkinan besar bisa","Coba saja"];
  const no=["Tidak bisa","Belum tentu","Kemungkinan kecil","Coba lagi"];
  if(cmd==="can") return pick([...yes,...no]);
  if(cmd==="is") return pick(["Ya","Tidak","Mungkin","Benar"]);
  if(cmd==="when") return pick(["Besok","Lusa","1 minggu lagi","1 bulan lagi","Suatu saat"]);
  if(cmd==="where") return pick(["Di rumah","Di sekolah","Di suatu tempat","Di luar sana"]);
  if(cmd==="how") return pick(["Pelan-pelan","Cari tutorial","Tanya ahlinya","Coba dan evaluasi"]);
  return "Tidak ada jawaban.";
}

function startGuess(bot,msg) {
  const n=Math.floor(Math.random()*100)+1;
  sessions.set(`${msg.chat.id}:${msg.from.id}`,{type:"angka",n,expires:Date.now()+120000});
  return bot.sendMessage(msg.chat.id,"⌁ <b>TEBAK ANGKA</b>\n\nAku sudah memilih angka 1-100. Kirim angka tebakanmu.",{parse_mode:"HTML",...q(msg)});
}

function startScramble(bot,msg) {
  const words=["telegram","javascript","cpanel","komputer","internet","database","developer","premium"];
  const word=pick(words); const shuffled=word.split("").sort(()=>Math.random()-.5).join("");
  sessions.set(`${msg.chat.id}:${msg.from.id}`,{type:"susun",word,expires:Date.now()+120000});
  return bot.sendMessage(msg.chat.id,`🔤 <b>SUSUN KATA</b>\n\nSusun kembali: <code>${shuffled}</code>\nWaktu 2 menit.`,{parse_mode:"HTML",...q(msg)});
}

function register(bot) {
  bot.onText(/^\/(?:game|games)(?:@\w+)?$/i,msg=>gameMenu(bot,msg));
  bot.onText(/^\/(?:yts|ytsearch)(?:@\w+)?\s+(.+)$/i,async(msg,m)=>{try{await sendYtResults(bot,msg,m[1].trim())}catch(e){await bot.sendMessage(msg.chat.id,`❌ ${esc(e.message)}`,{parse_mode:"HTML",...q(msg)})}});
  bot.onText(/^\/(?:ytmp3|ytaudio)(?:@\w+)?\s+(\S+)$/i,async(msg,m)=>{try{await ytDownload(bot,msg,m[1],"audio")}catch(e){await bot.sendMessage(msg.chat.id,`❌ YTMP3: ${esc(e.message)}`,{parse_mode:"HTML",...q(msg)})}});
  bot.onText(/^\/(?:play|ytplay)(?:@\w+)?\s+(.+)$/i,async(msg,m)=>{try{const x=(await youtubeSearch(m[1]))[0];if(!x)throw new Error("Tidak ditemukan.");await ytDownload(bot,msg,x.url,"audio")}catch(e){await bot.sendMessage(msg.chat.id,`❌ PLAY: ${esc(e.message)}`,{parse_mode:"HTML",...q(msg)})}});
  bot.onText(/^\/(?:spotify|spotifys)(?:@\w+)?\s+(.+)$/i,async(msg,m)=>{try{await spotifySearch(bot,msg,m[1].trim())}catch(e){await bot.sendMessage(msg.chat.id,`❌ Spotify: ${esc(e.message)}`,{parse_mode:"HTML",...q(msg)})}});
  bot.onText(/^\/(?:spdl|spotifydl)(?:@\w+)?\s+(\S+)$/i,async(msg,m)=>{try{await spotifyDownload(bot,msg,m[1])}catch(e){await bot.sendMessage(msg.chat.id,`❌ SPDL: ${esc(e.message)}`,{parse_mode:"HTML",...q(msg)})}});
  bot.onText(/^\/git(?:clone)?(?:@\w+)?\s+(\S+)$/i,async(msg,m)=>{try{await gitClone(bot,msg,m[1])}catch(e){await bot.sendMessage(msg.chat.id,`❌ GIT: ${esc(e.message)}`,{parse_mode:"HTML",...q(msg)})}});
  bot.onText(/^\/githubstalk(?:@\w+)?\s+(\S+)$/i,async(msg,m)=>{try{await githubStalk(bot,msg,m[1])}catch(e){await bot.sendMessage(msg.chat.id,`❌ GITHUB: ${esc(e.message)}`,{parse_mode:"HTML",...q(msg)})}});
  bot.onText(/^\/npmstalk(?:@\w+)?\s+(\S+)$/i,async(msg,m)=>{try{await npmStalk(bot,msg,m[1])}catch(e){await bot.sendMessage(msg.chat.id,`❌ NPM: ${esc(e.message)}`,{parse_mode:"HTML",...q(msg)})}});
  bot.onText(/^\/define(?:@\w+)?\s+(.+)$/i,async(msg,m)=>{try{await define(bot,msg,m[1].trim())}catch(e){await bot.sendMessage(msg.chat.id,`❌ DEFINE: ${esc(e.message)}`,{parse_mode:"HTML",...q(msg)})}});
  bot.onText(/^\/(?:can|is|when|where|how)(?:@\w+)?\s+(.+)$/i,async(msg,m)=>{const c=msg.text.split(/\s+/)[0].replace(/^\/|@\w+$/g,"").toLowerCase();await bot.sendMessage(msg.chat.id,`⌁ <b>${c.toUpperCase()}</b>\n\nPertanyaan: ${esc(m[1])}\nJawaban: <b>${answerFun(c,m[1])}</b>`,{parse_mode:"HTML",...q(msg)})});
  bot.onText(/^\/rate(?:@\w+)?\s+(.+)$/i,async(msg,m)=>{await bot.sendMessage(msg.chat.id,`⌁ <b>RATE</b>\n\n${esc(m[1])}\n\nNilai: <b>${rateText(m[1])}%</b>`,{parse_mode:"HTML",...q(msg)});});
  bot.onText(/^\/(?:suit|rps)(?:@\w+)?$/i, async msg => {
    await bot.sendMessage(
      msg.chat.id,
      "♟ <b>SUIT</b>\n\nPilih langkahmu.",
      {
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [[
            {text:"Batu",callback_data:`zeta_suit:${msg.from.id}:Batu`},
            {text:"Kertas",callback_data:`zeta_suit:${msg.from.id}:Kertas`},
            {text:"Gunting",callback_data:`zeta_suit:${msg.from.id}:Gunting`}
          ]]
        },
        ...q(msg)
      }
    );
  });
  bot.onText(/^\/dadu(?:@\w+)?$/i,async msg=>{await bot.sendMessage(msg.chat.id,`🎲 <b>DADU</b>\n\nHasil: <b>${1+Math.floor(Math.random()*6)}</b>`,{parse_mode:"HTML",...q(msg)});});
  bot.onText(/^\/(?:tebakangka|guess)(?:@\w+)?$/i,msg=>startGuess(bot,msg));
  bot.onText(/^\/(?:susunkata|scramble)(?:@\w+)?$/i,msg=>startScramble(bot,msg));

  bot.on("message",async msg=>{
    const key=`${msg.chat.id}:${msg.from?.id}`;
    const s=sessions.get(key); if(!s || !msg.text || msg.text.startsWith("/")) return;
    if(Date.now()>s.expires){sessions.delete(key);return;}
    if(s.type==="angka"){
      const n=Number(msg.text.trim()); if(!Number.isInteger(n)) return;
      if(n===s.n){sessions.delete(key);return bot.sendMessage(msg.chat.id,"🎉 Benar! Tebakanmu tepat.",{...q(msg)})}
      return bot.sendMessage(msg.chat.id,n<s.n?"Terlalu kecil.":"Terlalu besar.",{...q(msg)});
    }
    if(s.type==="susun"){
      if(msg.text.trim().toLowerCase()===s.word){sessions.delete(key);return bot.sendMessage(msg.chat.id,"🎉 Benar! Kata berhasil disusun.",{...q(msg)})}
    }
  });

  bot.on("callback_query",async cq=>{
    const d=cq.data||"";
    if(d.startsWith("zeta_yt:")){
      const [,uid,url]=d.split(":"); if(String(cq.from.id)!==String(uid)) return bot.answerCallbackQuery(cq.id,{text:"Menu ini milik user lain.",show_alert:true});
      await bot.answerCallbackQuery(cq.id,{text:"Memproses..."});
      try{await ytDownload(bot,cq.message,decodeURIComponent(url),"video")}catch(e){await bot.sendMessage(cq.message.chat.id,`❌ ${esc(e.message)}`,{parse_mode:"HTML",...q(cq.message)})}
    } else if(d.startsWith("zeta_sp:")){
      const [,uid,url]=d.split(":"); if(String(cq.from.id)!==String(uid)) return bot.answerCallbackQuery(cq.id,{text:"Menu ini milik user lain.",show_alert:true});
      await bot.answerCallbackQuery(cq.id,{text:"Memproses..."});
      try{await spotifyDownload(bot,cq.message,decodeURIComponent(url))}catch(e){await bot.sendMessage(cq.message.chat.id,`❌ ${esc(e.message)}`,{parse_mode:"HTML",...q(cq.message)})}
    } else if(d.startsWith("zeta_game:")){
      await bot.answerCallbackQuery(cq.id).catch(()=>{});
      const g=d.split(":")[1]; if(g==="suit") return;
      if(g==="dadu") return bot.sendMessage(cq.message.chat.id,`🎲 <b>DADU</b>\n\nHasil: <b>${1+Math.floor(Math.random()*6)}</b>`,{parse_mode:"HTML",...q(cq.message)});
      if(g==="angka") return startGuess(bot,cq.message);
      if(g==="susun") return startScramble(bot,cq.message);
    } else if(d.startsWith("zeta_suit:")){
      const [,uid,choice]=d.split(":"); if(String(cq.from.id)!==String(uid)) return bot.answerCallbackQuery(cq.id,{text:"Menu ini milik user lain.",show_alert:true});
      const botChoice=pick(["Batu","Kertas","Gunting"]);
      const win={Batu:"Gunting",Kertas:"Batu",Gunting:"Kertas"};
      const result=choice===botChoice?"Seri":win[choice]===botChoice?"Menang":"Kalah";
      await bot.answerCallbackQuery(cq.id,{text:result});
      await bot.sendMessage(cq.message.chat.id,`♟ <b>SUIT</b>\n\nKamu: <b>${esc(choice)}</b>\nBot: <b>${botChoice}</b>\nHasil: <b>${result}</b>`,{parse_mode:"HTML",...q(cq.message)});
    }
  });
}

module.exports = {register};
