/**
 * src/reactwa.js — React Emoji ke Pesan Saluran WhatsApp
 * Credit By Zx | Ported ke Telegram Bot (OURIN TELE API)
 *
 * Command: /reactwa
 * Akses: Owner / Admin
 */

const axios  = require('axios');
const fs     = require('fs');
const settings = require('../settings.js');

const ADMIN_FILE = './db/users/adminID.json';

// ─── helper ──────────────────────────────────────────────────────────────────
function isAllowed(userId) {
  if (settings.isOwner(userId)) return true;
  try {
    const list = JSON.parse(fs.readFileSync(ADMIN_FILE, 'utf8'));
    return list.includes(String(userId));
  } catch { return false; }
}

function esc(s = '') {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
function q(msg) { return msg?.message_id ? { reply_to_message_id: msg.message_id } : {}; }

// ─── bycf lazy loader ────────────────────────────────────────────────────────
let bycf = null;
function loadBycf() {
  if (bycf) return bycf;
  try { const mod = require('bycf'); bycf = mod?.shz || mod?.default || mod; return bycf; }
  catch { return null; }
}

// ═══════════════════════════════════════════════════════════════════════════════
//  CLASS WhatsAppChannelReactor  (sama persis dengan pastebin 38cVB8VQ)
// ═══════════════════════════════════════════════════════════════════════════════
class WhatsAppChannelReactor {
  constructor() {
    this.apiEndpoint    = 'https://reactionwa.berryservice1.workers.dev/';
    this.configEndpoint = 'https://db.reactionwa.online/api/config';

    this.turnstileSiteKey = '0x4AAAAAADs10GLlpHjiDbqM';
    this.turnstileUrl     = 'https://auto.reactionwa.online/Free/';

    this.firebaseConfig = null;
    this.bearerToken    = null;

    this.headers = {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Origin'    : 'https://auto.reactionwa.online',
      'Referer'   : 'https://auto.reactionwa.online/Free/'
    };
  }

  async init() {
    // 1. Ambil konfigurasi Firebase
    try {
      const { data } = await axios.get(this.configEndpoint, { headers: this.headers });
      this.firebaseConfig = data;
    } catch (error) {
      throw new Error('Gagal mengambil konfigurasi Firebase: ' + error.message);
    }

    // 2. Login anonymous ke Firebase
    try {
      const apiKey = this.firebaseConfig.apiKey;
      if (!apiKey) throw new Error('API Key tidak ditemukan di konfigurasi Firebase.');
      const { data } = await axios.post(
        `https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=${apiKey}`,
        { returnSecureToken: true },
        { headers: this.headers }
      );
      this.bearerToken = data.idToken;
    } catch (error) {
      const errMsg = error.response?.data?.error?.message || error.message;
      throw new Error('Gagal login anonymous Firebase: ' + errMsg);
    }
  }

  async solveCaptcha() {
    const bycfLib = loadBycf();
    if (!bycfLib) throw new Error('Modul bycf tidak dapat dimuat. Jalankan npm install jika dependency belum terpasang.');
    try {
      const token = await bycfLib.turnstileMin(this.turnstileUrl, this.turnstileSiteKey);
      if (!token) throw new Error('Token kosong');
      return token;
    } catch {
      // fallback ke turnstileMax
      try {
        const token = await bycfLib.turnstileMax(this.turnstileUrl);
        if (!token) throw new Error('Token kosong dari turnstileMax.');
        return token;
      } catch (err) {
        throw new Error('Gagal menyelesaikan CAPTCHA: ' + err.message);
      }
    }
  }

  async sendReaction(channelUrl, emojis) {
    if (!this.bearerToken) await this.init();

    if (!channelUrl.includes('whatsapp.com/channel/')) {
      throw new Error('URL tidak valid. Pastikan URL adalah URL Saluran WhatsApp (whatsapp.com/channel/...).');
    }

    const emojiArray = emojis.split(',').map(e => e.trim()).filter(e => e);
    if (emojiArray.length > 5) {
      throw new Error('Maksimal 5 emoji untuk versi Gratis. Pisahkan dengan koma, contoh: 😭,🔥,🚀,😮,👍');
    }

    const captchaToken = await this.solveCaptcha();

    const payload = { url: channelUrl, reaction: emojis, captchaToken };

    const requestHeaders = {
      ...this.headers,
      'Content-Type' : 'application/json',
      'Authorization': `Bearer ${this.bearerToken}`
    };

    const response = await axios.post(this.apiEndpoint, payload, {
      headers: requestHeaders,
      timeout: 30000
    });

    return response.data;
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
//  STATE MACHINE: menyimpan input user per userId
// ═══════════════════════════════════════════════════════════════════════════════
const inputState = new Map();
// state: { step: 'url' | 'emoji', channelUrl: string, chatId: number, messageId: number }

// ═══════════════════════════════════════════════════════════════════════════════
//  TELEGRAM COMMAND HANDLER
// ═══════════════════════════════════════════════════════════════════════════════
module.exports = (bot) => {

  // ── /reactwa — tampilkan menu info ─────────────────────────────────────────
  bot.onText(/^\/reactwa(?:@\w+)?$/i, async (msg) => {
    const chatId = msg.chat.id;
    if (!isAllowed(msg.from.id)) {
      return bot.sendMessage(chatId,
        '⌖ <b>AKSES DITOLAK</b>\n\nFitur ini khusus Owner / Admin.',
        { parse_mode: 'HTML', ...q(msg) });
    }

    const text =
      `<b>╭━━〔 REACT WA CHANNEL 〕━━╮</b>\n` +
      `<i>Auto react emoji ke pesan saluran WhatsApp</i>\n` +
      `╰━━━━━━━━━━━━━━━━━━━━━━━━━━━╯\n\n` +
      `<blockquote expandable>` +
      `<b>CARA PAKAI:</b>\n` +
      `├ 1. Tekan tombol "Kirim Reaksi"\n` +
      `├ 2. Masukkan URL saluran WA\n` +
      `│      contoh: https://whatsapp.com/channel/xxx/104\n` +
      `├ 3. Masukkan emoji (pisah koma, max 5)\n` +
      `│      contoh: 😭,😮‍💨,🔥,🚀,🫪\n` +
      `╰ 4. Tunggu hasil\n` +
      `</blockquote>\n\n` +
      `<blockquote expandable>` +
      `<b>INFO:</b>\n` +
      `├ Menggunakan Firebase Anonymous Auth\n` +
      `├ CAPTCHA solved otomatis via bycf\n` +
      `╰ Versi Gratis max 5 emoji\n` +
      `</blockquote>\n\n` +
      `⚠️ Modul CAPTCHA belum tersedia. Pastikan dependency <code>bycf</code> dan <code>axios</code> terpasang.`;

    return bot.sendMessage(chatId, text, {
      parse_mode: 'HTML',
      ...q(msg),
      reply_markup: {
        inline_keyboard: [
          [{ text: '💬 Kirim Reaksi', callback_data: 'reactwa_start' }],
          [{ text: '‹ ‹', callback_data: 'groupmenu' }]
        ]
      }
    });
  });

  // ── callback: tombol Kirim Reaksi ──────────────────────────────────────────
  bot.on('callback_query', async (cb) => {
    if (cb.data !== 'reactwa_start') return;
    await bot.answerCallbackQuery(cb.id).catch(() => {});

    const msg    = cb.message;
    const chatId = msg.chat.id;
    const userId = cb.from.id;

    if (!isAllowed(userId)) {
      return bot.answerCallbackQuery(cb.id, { text: 'Akses ditolak.', show_alert: true });
    }

    inputState.set(userId, { step: 'url', chatId, messageId: msg.message_id });

    try {
      await bot.editMessageText(
        `<b>💬 REACT WA CHANNEL — STEP 1/2</b>\n\n` +
        `Kirim URL saluran WhatsApp:\n` +
        `<code>https://whatsapp.com/channel/xxxx/104</code>\n\n` +
        `Ketik /batal untuk membatalkan.`,
        { chat_id: chatId, message_id: msg.message_id, parse_mode: 'HTML' }
      );
    } catch {}
  });

  // ── intercept pesan teks untuk state machine ────────────────────────────────
  bot.on('message', async (msg) => {
    if (!msg.text || !inputState.has(msg.from?.id)) return;

    const userId = msg.from.id;
    const state  = inputState.get(userId);
    const chatId = msg.chat.id;

    // batal
    if (msg.text.trim() === '/batal') {
      inputState.delete(userId);
      return bot.sendMessage(chatId, '◇ Dibatalkan.', q(msg));
    }

    // ── Step 1: terima URL ──────────────────────────────────────────────────
    if (state.step === 'url') {
      const url = msg.text.trim();
      if (!url.includes('whatsapp.com/channel/')) {
        return bot.sendMessage(chatId,
          '❌ URL tidak valid.\n\nKirim URL saluran WA yang benar:\n<code>https://whatsapp.com/channel/xxxx/104</code>\n\nAtau /batal.',
          { parse_mode: 'HTML', ...q(msg) });
      }

      inputState.set(userId, { ...state, step: 'emoji', channelUrl: url });

      return bot.sendMessage(chatId,
        `<b>💬 REACT WA CHANNEL — STEP 2/2</b>\n\n` +
        `URL disimpan ✅\n\n` +
        `Sekarang kirim emoji (pisah koma, max 5):\n` +
        `<code>😭,😮‍💨,🔥,🚀,🫪</code>\n\n` +
        `Atau /batal.`,
        { parse_mode: 'HTML', ...q(msg) });
    }

    // ── Step 2: terima emoji & proses ──────────────────────────────────────
    if (state.step === 'emoji') {
      const emojis = msg.text.trim();
      inputState.delete(userId);

      const loadMsg = await bot.sendMessage(chatId,
        `<b>⏳ MENGIRIM REAKSI...</b>\n\n` +
        `URL: <code>${esc(state.channelUrl.slice(0, 60))}</code>\n` +
        `Emoji: <code>${esc(emojis)}</code>\n\n` +
        `Harap tunggu...`,
        { parse_mode: 'HTML', ...q(msg) });

      const reactor = new WhatsAppChannelReactor();
      try {
        await reactor.init();
        const result = await reactor.sendReaction(state.channelUrl, emojis);

        let out = '';
        if (result?.success) {
          out =
            `<b>✅ REAKSI BERHASIL DIKIRIM!</b>\n\n` +
            `├ <b>URL:</b> <code>${esc(state.channelUrl.slice(0, 60))}</code>\n` +
            `├ <b>Emoji:</b> <code>${esc(emojis)}</code>\n`;
          if (result.vip?.pointRemaining !== undefined) {
            out += `╰ <b>Sisa Poin VIP:</b> ${result.vip.pointRemaining}\n`;
          }
          if (result.message) out += `\n📝 ${esc(result.message)}`;
        } else {
          out =
            `<b>⚠️ REAKSI TERKIRIM (status tidak pasti)</b>\n\n` +
            `Response server:\n<code>${esc(JSON.stringify(result).slice(0, 300))}</code>`;
        }

        await bot.editMessageText(out, {
          chat_id: chatId, message_id: loadMsg.message_id, parse_mode: 'HTML'
        });

      } catch (e) {
        await bot.editMessageText(
          `<b>❌ GAGAL MENGIRIM REAKSI</b>\n\n<code>${esc(e.message)}</code>`,
          { chat_id: chatId, message_id: loadMsg.message_id, parse_mode: 'HTML' }
        );
      }
    }
  });

};
