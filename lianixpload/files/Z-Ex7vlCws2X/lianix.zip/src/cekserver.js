// src/cekserver.js
// ─────────────────────────────────────────────────────────────
// Auto-scheduled server status checker.
// UI layout matches SISTEM PENGECEKAN design spec (screenshot).
//
// Commands (owner only):
//   /cekserver                           — cek semua server sekarang
//   /setcekserver <chatId> <menit>       — aktifkan auto-cek terjadwal
//   /stopcekserver                       — hentikan auto-cek
//   /setcheckinterval <menit>            — ganti interval tanpa reset target
//   /setservermeta <n> <LABEL> | <specs> — set label & specs server ke-n
//   /setservertype <n> <public|private|premium>
//   /setbrand <nama>                     — set brand di footer
//   /statuscekserver                     — lihat konfigurasi saat ini
// ─────────────────────────────────────────────────────────────

"use strict";

const fs         = require("fs");
const path       = require("path");
const axios      = require("axios");
const settings   = require("../settings.js");
const panelStore = require("./data/panelStore.js");

// ── paths ────────────────────────────────────────────────────
const META_PATH  = path.join(__dirname, "..", "db", "serverMeta.json");
const OWNER_FILE = path.join(__dirname, "..", "db", "users", "adminID.json");

// ── owner check ──────────────────────────────────────────────
function isOwner(userId) {
  try {
    const list = JSON.parse(fs.readFileSync(OWNER_FILE, "utf8"));
    return (
      list.includes(String(userId)) ||
      settings.isOwner(userId)
    );
  } catch {
    return settings.isOwner(userId);
  }
}

// ── server meta store ────────────────────────────────────────
const DEFAULT_META = {
  enabled:      false,
  intervalMin:  8,
  targetChatId: null,
  brand:        "Lianix",
  servers:      {},
};

function readMeta() {
  try {
    const raw  = fs.readFileSync(META_PATH, "utf8");
    const data = JSON.parse(raw);
    return Object.assign({}, DEFAULT_META, data);
  } catch {
    return JSON.parse(JSON.stringify(DEFAULT_META));
  }
}

function writeMeta(data) {
  fs.mkdirSync(path.dirname(META_PATH), { recursive: true });
  fs.writeFileSync(META_PATH, JSON.stringify(data, null, 2));
}

function getServerMeta(n) {
  const meta = readMeta();
  return meta.servers[String(n)] || { label: "TIDAK DISET", specs: "-", type: "public" };
}

// ── single server check ──────────────────────────────────────
async function checkOneServer(no) {
  const panel             = panelStore.getPanel(String(no));
  const { label, specs, type } = getServerMeta(no);

  if (!panel.domain || !panel.plta) {
    return { no, label, type, specs, online: false, errorMsg: "Domain / PLTA belum diset" };
  }

  try {
    await axios.get(`${panel.domain}/api/application/servers`, {
      params:  { per_page: 1 },
      headers: {
        Authorization: `Bearer ${panel.plta}`,
        Accept:        "Application/vnd.pterodactyl.v1+json",
      },
      timeout: 9000,
    });
    return { no, label, type, specs, online: true, errorMsg: null };
  } catch (err) {
    let msg    = "Koneksi panel gagal";
    const code = err?.response?.status;
    if (code) {
      msg = `Panel merespons HTTP ${code}`;
    } else if (err.code === "ECONNABORTED" || err.code === "ETIMEDOUT") {
      msg = "Koneksi panel melewati batas waktu";
    } else if (err.code === "ECONNREFUSED") {
      msg = "Koneksi ditolak oleh panel";
    } else if (err.code === "ENOTFOUND") {
      msg = "Domain panel tidak ditemukan";
    } else if (err.message) {
      msg = err.message.slice(0, 55);
    }
    return { no, label, type, specs, online: false, errorMsg: msg };
  }
}

// ── collect slots with domain + plta set ────────────────────
function getConfiguredSlots() {
  const slots = [];
  for (let i = 1; i <= 20; i++) {
    const p = panelStore.getPanel(String(i));
    if (p.domain && p.plta) slots.push(i);
  }
  return slots;
}

// ── padEnd that accounts for emoji visual width ──────────────
function padEnd(str, len) {
  const s = String(str);
  // each emoji takes 2 columns in a monospace terminal
  const emojiW = (s.match(/[\u{1F000}-\u{1FAFF}]|\u2B50|\u{1F300}-\u{1F9FF}/gu) || []).length;
  const visual = s.length - emojiW + emojiW * 2;
  return s + " ".repeat(Math.max(0, len - visual));
}

// ── build full status message (HTML, parse_mode HTML) ────────
function buildStatusMessage(results, meta) {
  const intervalMin = meta.intervalMin || 8;
  const brand = meta.brand || "Lianix";

  const onlineCount  = results.filter(r => r.online && r.type !== "premium").length;
  const errorCount   = results.filter(r => !r.online).length;
  const premiumCount = results.filter(r => r.online && r.type === "premium").length;
  const privateCount = results.filter(r => r.online && r.type === "private").length;

  const total = results.length;
  const checkedAt = new Date().toLocaleString("id-ID", {
    timeZone: "Asia/Jakarta",
    hour12: false
  });

  const esc = (value) => String(value ?? "-")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");

  const percent = total ? Math.round((onlineCount + premiumCount + privateCount) / total * 100) : 0;

  const statusRows = results.map((r) => {
    let status;
    if (r.online && r.type === "premium") status = "PREMIUM";
    else if (r.online && r.type === "private") status = "PRIVATE";
    else if (r.online) status = "ONLINE";
    else status = "OFFLINE";

    const detail = r.online ? (r.specs || "Server aktif") : (r.errorMsg || "Tidak dapat terhubung");
    return [
      `<b>SERVER V${esc(r.no)} — ${esc(r.label || "UNNAMED")}</b>`,
      `Status  : <b>${status}</b>`,
      `Detail  : <code>${esc(detail)}</code>`
    ].join("\n");
  }).join("\n\n");

  const healthLine =
    percent >= 100 ? "SEMUA SERVER NORMAL" :
    percent >= 75 ? "SEBAGIAN BESAR SERVER NORMAL" :
    percent > 0 ? "PERLU PEMERIKSAAN" :
    "SEMUA SERVER BERMASALAH";

  return (
    `<blockquote expandable>` +
    `<b>LIANIX • SERVER MONITOR</b>\n` +
    `<i>Real-time infrastructure status</i>\n` +
    `\n` +
    `<b>STATUS KESEHATAN</b>\n` +
    `<code>${healthLine}</code>\n` +
    `\n` +
    `<b>RINGKASAN</b>\n` +
    `┌─────────────────────────\n` +
    `│ Online    : <b>${onlineCount}</b>\n` +
    `│ Premium   : <b>${premiumCount}</b>\n` +
    `│ Private   : <b>${privateCount}</b>\n` +
    `│ Offline   : <b>${errorCount}</b>\n` +
    `│ Health    : <b>${percent}%</b>\n` +
    `└─────────────────────────\n` +
    `\n` +
    `<b>DETAIL SERVER</b>\n` +
    `${statusRows || "<i>Belum ada server yang dikonfigurasi.</i>"}\n` +
    `\n` +
    `<b>MONITORING</b>\n` +
    `Interval : <b>${intervalMin} menit</b>\n` +
    `Checked  : <code>${esc(checkedAt)} WIB</code>\n` +
    `\n` +
    `<i>Protected monitoring by ${esc(brand)}</i>` +
    `</blockquote>`
  );
}

// ── run full check ───────────────────────────────────────────
async function runCheck() {
  const slots = getConfiguredSlots();
  return Promise.all(slots.map(n => checkOneServer(n)));
}

// ── interval handle ──────────────────────────────────────────
let _timer = null;

function stopAutoCheck() {
  if (_timer) { clearInterval(_timer); _timer = null; }
}

function startAutoCheck(bot) {
  stopAutoCheck();
  const meta = readMeta();
  if (!meta.enabled || !meta.targetChatId) return;

  const ms = Math.max(60000, (meta.intervalMin || 8) * 60 * 1000);

  _timer = setInterval(async () => {
    try {
      const freshMeta = readMeta();
      if (!freshMeta.enabled || !freshMeta.targetChatId) { stopAutoCheck(); return; }

      const results = await runCheck();
      if (!results.length) return;

      const text = buildStatusMessage(results, freshMeta);
      await bot.sendMessage(freshMeta.targetChatId, text, { parse_mode: "HTML" });
    } catch (err) {
      console.error("[cekserver] auto-check error:", err.message);
    }
  }, ms);

  console.log(`[cekserver] auto aktif → ${meta.intervalMin} menit → chatId ${meta.targetChatId}`);
}

// ─────────────────────────────────────────────────────────────
module.exports = (bot) => {

  // kick-start if previously enabled
  startAutoCheck(bot);

  // /cekserver — immediate manual check
  bot.onText(/^\/cekserver$/, async (msg) => {
    const chatId = msg.chat.id;
    if (!isOwner(msg.from.id))
      return bot.sendMessage(chatId, "\u2715 Hanya untuk owner!");

    const sent = await bot.sendMessage(chatId,
      "\u23F3 <b>Mengecek semua server...</b>", { parse_mode: "HTML" });

    try {
      const results = await runCheck();
      if (!results.length) {
        return bot.editMessageText(
          "\u2757 Belum ada server yang diset domain/PLTA-nya.\n" +
          "Atur lewat <b>Kelola Panel</b>, lalu set metadata dengan <code>/setservermeta</code>.",
          { chat_id: chatId, message_id: sent.message_id, parse_mode: "HTML" }
        );
      }
      const meta = readMeta();
      const text = buildStatusMessage(results, meta);
      await bot.editMessageText(text, {
        chat_id: chatId, message_id: sent.message_id, parse_mode: "HTML",
      });
    } catch (err) {
      await bot.editMessageText(
        `\u2715 Gagal: <code>${err.message}</code>`,
        { chat_id: chatId, message_id: sent.message_id, parse_mode: "HTML" }
      );
    }
  });

  // /setcekserver <chatId> <menit>
  bot.onText(/^\/setcekserver\s+(-?\d+)\s+(\d+)$/, async (msg, match) => {
    const chatId = msg.chat.id;
    if (!isOwner(msg.from.id))
      return bot.sendMessage(chatId, "\u2715 Hanya untuk owner!");

    const targetId    = parseInt(match[1], 10);
    const intervalMin = Math.max(1, parseInt(match[2], 10));

    const meta        = readMeta();
    meta.enabled      = true;
    meta.targetChatId = targetId;
    meta.intervalMin  = intervalMin;
    writeMeta(meta);
    stopAutoCheck();
    startAutoCheck(bot);

    return bot.sendMessage(chatId,
      `\u2713 <b>Auto CekServer Aktif</b>\n\n` +
      `\u2022 Target Chat: <code>${targetId}</code>\n` +
      `\u2022 Interval: <b>${intervalMin} menit</b>\n\n` +
      `Kirim <code>/stopcekserver</code> untuk menghentikan.`,
      { parse_mode: "HTML" }
    );
  });

  // /setcheckinterval <menit>
  bot.onText(/^\/setcheckinterval\s+(\d+)$/, async (msg, match) => {
    const chatId = msg.chat.id;
    if (!isOwner(msg.from.id))
      return bot.sendMessage(chatId, "\u2715 Hanya untuk owner!");

    const intervalMin = Math.max(1, parseInt(match[1], 10));
    const meta        = readMeta();
    meta.intervalMin  = intervalMin;
    writeMeta(meta);
    stopAutoCheck();
    if (meta.enabled) startAutoCheck(bot);

    return bot.sendMessage(chatId,
      `\u2713 Interval diubah ke <b>${intervalMin} menit</b>.`,
      { parse_mode: "HTML" }
    );
  });

  // /stopcekserver
  bot.onText(/^\/stopcekserver$/, async (msg) => {
    const chatId = msg.chat.id;
    if (!isOwner(msg.from.id))
      return bot.sendMessage(chatId, "\u2715 Hanya untuk owner!");

    const meta    = readMeta();
    meta.enabled  = false;
    writeMeta(meta);
    stopAutoCheck();

    return bot.sendMessage(chatId, "\u2715 Auto CekServer dihentikan.", { parse_mode: "HTML" });
  });

  // /setservermeta <n> <LABEL> | <specs>
  // e.g. /setservermeta 1 ILEGAL | RAM 8 GB • CPU 4 Core • Disk 160 GB SSD • DO
  bot.onText(/^\/setservermeta\s+(\d+)\s+(.+?)\s*\|\s*(.+)$/s, async (msg, match) => {
    const chatId = msg.chat.id;
    if (!isOwner(msg.from.id))
      return bot.sendMessage(chatId, "\u2715 Hanya untuk owner!");

    const n     = parseInt(match[1], 10);
    const label = match[2].trim().toUpperCase();
    const specs = match[3].trim();
    let   type  = "public";
    if (/premium/i.test(label))  type = "premium";
    else if (/private/i.test(label)) type = "private";

    const meta = readMeta();
    meta.servers[String(n)] = { label, specs, type };
    writeMeta(meta);

    return bot.sendMessage(chatId,
      `\u2713 Server ${n} diperbarui:\n\n` +
      `\u2022 Label : <b>${label}</b>\n` +
      `\u2022 Type  : <code>${type}</code>\n` +
      `\u2022 Specs : <code>${specs}</code>`,
      { parse_mode: "HTML" }
    );
  });

  // /setservertype <n> <public|private|premium>
  bot.onText(/^\/setservertype\s+(\d+)\s+(public|private|premium)$/i, async (msg, match) => {
    const chatId = msg.chat.id;
    if (!isOwner(msg.from.id))
      return bot.sendMessage(chatId, "\u2715 Hanya untuk owner!");

    const n    = parseInt(match[1], 10);
    const type = match[2].toLowerCase();
    const meta = readMeta();
    if (!meta.servers[String(n)])
      meta.servers[String(n)] = { label: "TIDAK DISET", specs: "-", type };
    else
      meta.servers[String(n)].type = type;
    writeMeta(meta);

    return bot.sendMessage(chatId,
      `\u2713 Server ${n} type \u2192 <b>${type}</b>.`,
      { parse_mode: "HTML" }
    );
  });

  // /setbrand <nama>
  bot.onText(/^\/setbrand\s+(.+)$/, async (msg, match) => {
    const chatId = msg.chat.id;
    if (!isOwner(msg.from.id))
      return bot.sendMessage(chatId, "\u2715 Hanya untuk owner!");

    const brand  = match[1].trim();
    const meta   = readMeta();
    meta.brand   = brand;
    writeMeta(meta);

    return bot.sendMessage(chatId,
      `\u2713 Brand footer \u2192 <b>${brand}</b>.`,
      { parse_mode: "HTML" }
    );
  });

  // /statuscekserver
  bot.onText(/^\/statuscekserver$/, async (msg) => {
    const chatId = msg.chat.id;
    if (!isOwner(msg.from.id))
      return bot.sendMessage(chatId, "\u2715 Hanya untuk owner!");

    const meta    = readMeta();
    const running = _timer !== null;
    const keys    = Object.keys(meta.servers);

    return bot.sendMessage(chatId,
      `\uD83D\uDCCA <b>Status Auto CekServer</b>\n\n` +
      `\u2022 Berjalan   : ${running ? "\u2713 Ya" : "\u2715 Tidak"}\n` +
      `\u2022 Enabled    : ${meta.enabled ? "\u2713 Ya" : "\u2715 Tidak"}\n` +
      `\u2022 Interval   : <b>${meta.intervalMin} menit</b>\n` +
      `\u2022 Target Chat: <code>${meta.targetChatId ?? "Belum diset"}</code>\n` +
      `\u2022 Brand      : <b>${meta.brand}</b>\n` +
      `\u2022 Server set : ${keys.length ? keys.join(", ") : "Belum ada"}\n\n` +
      `<b>Commands:</b>\n` +
      `<code>/setcekserver &lt;chatId&gt; &lt;menit&gt;</code>\n` +
      `<code>/stopcekserver</code>\n` +
      `<code>/setcheckinterval &lt;menit&gt;</code>\n` +
      `<code>/setservermeta &lt;n&gt; &lt;LABEL&gt; | &lt;specs&gt;</code>\n` +
      `<code>/setservertype &lt;n&gt; public|private|premium</code>\n` +
      `<code>/setbrand &lt;nama&gt;</code>\n` +
      `<code>/cekserver</code>`,
      { parse_mode: "HTML" }
    );
  });
};
