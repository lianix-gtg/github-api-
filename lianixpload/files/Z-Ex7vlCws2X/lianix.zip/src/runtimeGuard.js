// src/runtimeGuard.js
// Centralized error telemetry for Telegram + process-level failures.
const settings = require("../settings.js");
const ownerStore = require("./data/ownerStore.js");
const fs = require("fs");
const os = require("os");
const path = require("path");

const SENSITIVE = /((?:bot|token|apikey|api[_-]?key|authorization|password|secret)[^:=\n]*[:=]\s*)([^\s,;]+)/ig;
const seen = new Map();
const editCache = new Map();
const rateLimitedUntil = new Map();

function redact(value) {
  return String(value ?? "")
    .replace(SENSITIVE, "$1[REDACTED]")
    .replace(/(\d{8,12}:[A-Za-z0-9_-]{20,})/g, "[BOT_TOKEN_REDACTED]")
    .slice(0, 3500);
}

function plainButtonText(value) {
  const original = String(value ?? "");
  if (/buy\s+script/i.test(original)) return original;

  // Telegram menerima Unicode penuh pada label tombol. Jangan menghapus
  // simbol/ikon Unicode tetap dipertahankan agar label tombol tidak berubah menjadi fallback kosong.
  // Itu yang menyebabkan tombol-tombol seperti pada screenshot muncul.
  return original
    .replace(/[\u0000-\u001F\u007F]/g, " ")
    .replace(/[\u200B-\u200D\uFEFF]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

function isDevPanelButton(btn) {
  const cb = typeof btn?.callback_data === "string" ? btn.callback_data : "";
  // Dev-panel callbacks are intentionally exempt from the global button
  // cleanup requested for normal user-facing menus.
  return /^dev(?:_|panel)/i.test(cb);
}

function isBuyScriptButton(btn) {
  const url = typeof btn?.url === "string" ? btn.url : "";
  const configured = String(settings.buyScriptUrl || "").trim();
  return /buy\s+script/i.test(String(btn?.text || "")) || (configured && url === configured);
}

function normalizeReplyMarkup(markup) {
  if (markup == null) return markup;
  let m = markup;
  if (typeof m === "string") {
    try { m = JSON.parse(m); } catch { return undefined; }
  }
  if (!m || typeof m !== "object") return undefined;

  if (Array.isArray(m.inline_keyboard)) {
    const rows = [];
    for (const row of m.inline_keyboard) {
      if (!Array.isArray(row)) continue;
      const cleanRow = [];
      for (const btn of row) {
        if (!btn || typeof btn !== "object" || typeof btn.text !== "string" || !btn.text.trim()) continue;
        const exempt = isDevPanelButton(btn) || isBuyScriptButton(btn);
        let label = exempt ? btn.text : plainButtonText(btn.text);
        // Satu label Back yang konsisten untuk seluruh UI: tiga chevron kecil.
        // Berlaku juga untuk Dev Panel supaya tidak ada variasi <, ←, Back, Kembali, dll.
        if (/^(?:[‹<←↩↪⟵⟸→⬅️]+\s*)*(?:back|kembali|menu utama|home)?$/i.test(label) &&
            (/(?:back|kembali|menu utama|home)/i.test(label) || /^[‹<←↩↪⟵⟸→⬅️\s]+$/u.test(label))) {
          label = "‹‹‹";
        }
        const clean = { text: label };
        if (typeof btn.callback_data === "string") {
          const bytes = Buffer.byteLength(btn.callback_data, "utf8");
          if (bytes >= 1 && bytes <= 64) clean.callback_data = btn.callback_data;
          else continue;
        } else if (typeof btn.url === "string" && btn.url.trim()) {
          clean.url = btn.url;
        } else if (btn.web_app && typeof btn.web_app === "object" && typeof btn.web_app.url === "string") {
          clean.web_app = { url: btn.web_app.url };
        } else if (btn.login_url && typeof btn.login_url === "object" && typeof btn.login_url.url === "string") {
          clean.login_url = { url: btn.login_url.url };
        } else if (typeof btn.switch_inline_query === "string") {
          clean.switch_inline_query = btn.switch_inline_query;
        } else if (typeof btn.switch_inline_query_current_chat === "string") {
          clean.switch_inline_query_current_chat = btn.switch_inline_query_current_chat;
        } else if (btn.switch_inline_query_chosen_chat && typeof btn.switch_inline_query_chosen_chat === "object") {
          clean.switch_inline_query_chosen_chat = {
            ...(typeof btn.switch_inline_query_chosen_chat.allow_user_chats === "boolean"
              ? { allow_user_chats: btn.switch_inline_query_chosen_chat.allow_user_chats } : {}),
            ...(typeof btn.switch_inline_query_chosen_chat.allow_bot_chats === "boolean"
              ? { allow_bot_chats: btn.switch_inline_query_chosen_chat.allow_bot_chats } : {}),
            ...(typeof btn.switch_inline_query_chosen_chat.allow_group_chats === "boolean"
              ? { allow_group_chats: btn.switch_inline_query_chosen_chat.allow_group_chats } : {}),
            ...(typeof btn.switch_inline_query_chosen_chat.allow_channel_chats === "boolean"
              ? { allow_channel_chats: btn.switch_inline_query_chosen_chat.allow_channel_chats } : {}),
          };
        } else if (btn.callback_game && typeof btn.callback_game === "object") {
          clean.callback_game = {};
        } else if (btn.copy_text && typeof btn.copy_text === "object" && typeof btn.copy_text.text === "string") {
          clean.copy_text = { text: btn.copy_text.text };
        } else if (btn.pay === true) {
          clean.pay = true;
        } else {
          continue;
        }
        cleanRow.push(clean);
      }
      if (cleanRow.length) rows.push(cleanRow);
    }
    return rows.length ? { inline_keyboard: rows } : undefined;
  }

  // Reply keyboard variants.
  if (Array.isArray(m.keyboard)) {
    const keyboard = m.keyboard
      .filter(Array.isArray)
      .map(row => row.filter(btn => typeof btn === "string" || (btn && typeof btn === "object")));
    return keyboard.length ? { ...m, keyboard } : undefined;
  }
  if (m.remove_keyboard === true || m.force_reply === true) return { ...m };
  return undefined;
}

function serializeError(err) {
  if (!err) return "Unknown error";
  if (err instanceof Error) return `${err.name}: ${err.message}\n${err.stack || ""}`;
  try { return JSON.stringify(err, null, 2); } catch { return String(err); }
}

function isTransientNetworkError(err) {
  if (!err) return false;
  const msg = String(err?.message || err || "");
  const code = String(err?.code || "");
  const status = Number(err?.response?.statusCode || err?.response?.status || 0);
  if (/ECONNRESET|ECONNREFUSED|ETIMEDOUT|EPIPE|ENOTFOUND|EAI_AGAIN|socket hang up|read ECONNRESET/i.test(msg)) return true;
  if (/ECONNRESET|ECONNREFUSED|ETIMEDOUT|EPIPE|ENOTFOUND|EAI_AGAIN/i.test(code)) return true;
  if (/AggregateError/i.test(msg)) return true;
  if ([502,503,504].includes(status)) return true;
  if (/ETELEGRAM:\s*(502|503|504)|502 Bad Gateway|503 Service Unavailable|504 Gateway/i.test(msg)) return true;
  return false;
}

async function report(bot, source, err) {
  // polling/network drop dari Telegram/hosting adalah kondisi transient.
  // node-telegram-bot-api akan polling lagi sendiri; jangan broadcast sebagai SYSTEM ERROR.
  if (isTransientNetworkError(err)) return;
  const detail = redact(serializeError(err));
  // Node.js deprecation warning from node-telegram-bot-api about future
  // multipart content-type defaults is informational, not a bot failure.
  if (/DeprecationWarning:.*content-type of files you send will default to "application\/octet-stream"/is.test(detail)) return;
  // Telegram "message is not modified" is an expected no-op, not a system failure.
  if (/400\s+Bad Request:\s*message is not modified/i.test(detail)) return;
  if (/400\s+Bad Request:\s*(?:chat not found|message to (?:delete|edit) not found|message to be replied not found)/i.test(detail)) return;
  // 429 is handled by the guarded API wrapper; avoid flooding the owner with repeated rate-limit logs.
  if (/429\s+Too Many Requests/i.test(detail)) {
    // Flood-limit is operational/transient. Never send it back through the
    // SYSTEM ERROR reporter; the Telegram method wrapper handles the cooldown.
    return;
  }

  const key = `${source}:${detail}`;
  const now = Date.now();
  if (seen.get(key) && now - seen.get(key) < 1500) return;
  seen.set(key, now);

  let ownerIds = [];
  try {
    ownerIds = [...new Set(ownerStore.getOwnerIds().map(String).filter(Boolean))];
  } catch (_) {
    ownerIds = settings.ownerId ? [String(settings.ownerId)] : [];
  }
  if (!ownerIds.length || !bot?.sendMessage) return;

  const text =
    `<b>⚠️ LIANIX • SYSTEM ERROR</b>\n\n` +
    `<blockquote expandable>` +
    `<b>Source</b>  : <code>${redact(source)}</code>\n` +
    `<b>Time</b>    : <code>${new Date().toLocaleString("id-ID",{timeZone:"Asia/Jakarta"})}</code>\n\n` +
    `<b>Detail</b>\n<pre>${detail.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}</pre>` +
    `</blockquote>`;

  const sender = bot.__yoenRawSendMessage || bot.sendMessage;
  for (const ownerId of ownerIds) {
    try {
      await sender.call(bot, ownerId, text, { parse_mode: "HTML", disable_web_page_preview: true });
    } catch (_) {
      // Pengiriman ke Owner #1 dan #2 independen.
    }
  }
}

function install(bot) {
  if (!bot || bot.__yoenRuntimeGuard) return;
  bot.__yoenRuntimeGuard = true;

  bot.on("error", err => report(bot, "telegram.error", err));
  bot.on("polling_error", err => report(bot, "telegram.polling_error", err));
  bot.on("webhook_error", err => report(bot, "telegram.webhook_error", err));

  process.on("uncaughtException", err => {
    report(bot, "process.uncaughtException", err).finally(() => {
      // Jangan restart otomatis dari error reporter.
    });
  });
  process.on("unhandledRejection", err => report(bot, "process.unhandledRejection", err));
  process.on("warning", warning => report(bot, "process.warning", warning));

  const methods = [
    "sendMessage","editMessageText","editMessageCaption","editMessageReplyMarkup",
    "sendPhoto","sendVideo","sendAudio","sendDocument","sendAnimation","sendVoice",
    "deleteMessage","getFile","approveChatJoinRequest","declineChatJoinRequest",
    "getChat","getChatMember","banChatMember","unbanChatMember","restrictChatMember"
  ];

  for (const name of methods) {
    const original = bot[name];
    if (typeof original !== "function" || original.__yoenGuarded) continue;
    if (name === "sendMessage" && !bot.__yoenRawSendMessage) bot.__yoenRawSendMessage = original;

    const wrapped = async function(...args) {
      // Avoid hammering Telegram with identical progress updates.
      if (name === "editMessageCaption" || name === "editMessageText") {
        // editMessageText(text, options) — args[0]=text, args[1]=options
        // editMessageCaption(caption, options) — same layout
        const textOrCaption = args[0];
        const options = args[1] || {};
        const chatId = options.chat_id;
        const messageId = options.message_id;
        if (Object.prototype.hasOwnProperty.call(options, "reply_markup")) {
          const normalized = normalizeReplyMarkup(options.reply_markup);
          if (normalized) options.reply_markup = normalized;
          else delete options.reply_markup;
        }
        let sig = "";
        try { sig = JSON.stringify([chatId, messageId, textOrCaption, options.parse_mode || null, options.reply_markup || null]); } catch {}
        const cacheKey = `${name}:${chatId}:${messageId}`;
        const previous = editCache.get(cacheKey);
        const now = Date.now();
        if (previous && previous.sig === sig && now - previous.at < 30000) {
          return Promise.resolve({ ok: true, skipped: true, description: "message not modified" });
        }
        // Telegram flood limits can be triggered by fast progress edits.
        // Keep a small per-message edit interval so backup progress stays smooth.
        if (previous && now - previous.at < 2200) {
          return Promise.resolve({ ok: false, skipped: true, rate_limited: true });
        }
        editCache.set(cacheKey, { sig, at: now });
      }

      const rateKey = `rate:${name}`;
      const blockedUntil = rateLimitedUntil.get(rateKey) || 0;
      if (blockedUntil > Date.now() && (name === "editMessageCaption" || name === "editMessageText" || name === "editMessageReplyMarkup")) {
        return Promise.resolve({ ok: false, skipped: true, rate_limited: true });
      }

      // Sanitize reply markup centrally. This prevents malformed/oversized
      // inline keyboards from turning into Telegram 400 errors.
      const optionIndex = (name === "editMessageText" || name === "editMessageCaption") ? 1 : 2;
      const optionArg = args[optionIndex];
      if (optionArg && typeof optionArg === "object" && Object.prototype.hasOwnProperty.call(optionArg, "reply_markup")) {
        const normalized = normalizeReplyMarkup(optionArg.reply_markup);
        if (normalized) optionArg.reply_markup = normalized;
        else delete optionArg.reply_markup;
      }
      let tempMedia = null;
      const mediaMethods = new Set(["sendPhoto","sendDocument","sendVideo","sendAudio","sendVoice","sendAnimation"]);
      if (mediaMethods.has(name) && Buffer.isBuffer(args[1])) {
        const ext = name === "sendPhoto" ? "jpg" : name === "sendVideo" ? "mp4" : name === "sendAudio" ? "mp3" : name === "sendAnimation" ? "mp4" : "bin";
        tempMedia = path.join(os.tmpdir(), `lianix_media_${Date.now()}_${Math.random().toString(36).slice(2)}.${ext}`);
        await fs.promises.writeFile(tempMedia, args[1]);
        args[1] = tempMedia;
      } else if (mediaMethods.has(name) && args[1] && typeof args[1] === "object" && Buffer.isBuffer(args[1].source)) {
        const filename = String(args[1].filename || (name === "sendPhoto" ? "image.jpg" : "file.bin")).replace(/[^a-zA-Z0-9._-]/g, "_");
        tempMedia = path.join(os.tmpdir(), `lianix_media_${Date.now()}_${Math.random().toString(36).slice(2)}_${filename}`);
        await fs.promises.writeFile(tempMedia, args[1].source);
        args[1] = tempMedia;
      }
      let result;
      try { result = original.apply(this, args); }
      catch (err) {
        const detail = serializeError(err);
        const m = String(detail).match(/retry after\s+(\d+)/i);
        if (m) rateLimitedUntil.set(rateKey, Date.now() + Number(m[1]) * 1000);
        report(bot, `telegram.${name}`, err);
        throw err;
      }
      if (result && typeof result.then === "function" && tempMedia) result = result.finally(() => fs.promises.unlink(tempMedia).catch(() => {}));
      if (result && typeof result.catch === "function") {
        return result.catch(async err => {
          const detail = serializeError(err);
          const retry = String(detail).match(/retry after\s+(\d+)/i);
          if (retry) rateLimitedUntil.set(rateKey, Date.now() + Number(retry[1]) * 1000);
          // Telegram HTML/Markdown entity errors are usually caused by user-provided
          // text containing an unescaped "<", ">", or an incomplete HTML tag.
          // Retry once as plain text so a malformed caption/message never becomes
          // a SYSTEM ERROR or an unhandled rejection.
          if ((name === "sendMessage" || name === "sendVideo" || name === "sendPhoto" ||
               name === "sendDocument" || name === "sendAudio" || name === "sendVoice" ||
               name === "sendAnimation" || name === "editMessageText" || name === "editMessageCaption") &&
              /can't parse entities|unsupported start tag|unexpected end tag|can't find end tag|unclosed tag/i.test(detail)) {
            try {
              const retryArgs = [...args];
              const idx = (name === "editMessageText" || name === "editMessageCaption") ? 1 : 2;
              const opts = retryArgs[idx];
              if (opts && typeof opts === "object") {
                const plain = { ...opts };
                delete plain.parse_mode;
                retryArgs[idx] = plain;
                return await original.apply(this, retryArgs);
              }
            } catch (plainErr) {
              // A malformed entity should never be allowed to escape as an
              // unhandled rejection. The original error is intentionally hidden.
            }
            return { ok: false, skipped: true, description: "invalid Telegram entities; plain-text fallback attempted" };
          }

          // Telegram never allows restricting a creator/administrator. This is
          // an expected permission condition, not a bot error. Swallow it before
          // the generic reporter so it cannot trigger AI FIX or SYSTEM ERROR.
          if (name === "restrictChatMember" &&
              /user is an administrator of the chat|user is an administrator|administrator of the chat/i.test(detail)) {
            return { ok: false, skipped: true, description: "target is an administrator/creator" };
          }

          // Missing chats/members are normal lifecycle conditions.
          if ((name === "getChat" || name === "getChatMember") &&
              /chat not found|user not found|chat_id is empty/i.test(detail)) {
            return { ok: false, skipped: true, description: "chat/member no longer available" };
          }

          // "message is not modified" is an expected idempotent no-op.
          if (/can't parse reply keyboard markup JSON object|reply keyboard markup/i.test(detail)) {
            // Jangan menghapus reply_markup di fallback. Itu membuat semua
            // tombol hilang. Coba sanitasi ulang lalu kirim kembali dengan
            // keyboard yang masih terlihat.
            try {
              const retryArgs = [...args];
              const idx = (name === "editMessageText" || name === "editMessageCaption") ? 1 : 2;
              const opts = retryArgs[idx];
              if (opts && typeof opts === "object" && opts.reply_markup != null) {
                const cleaned = normalizeReplyMarkup(opts.reply_markup);
                if (cleaned) {
                  retryArgs[idx] = { ...opts, reply_markup: cleaned };
                  return await original.apply(this, retryArgs);
                }
              }
            } catch (_) {}
            return { ok: false, skipped: true, description: "invalid reply keyboard could not be sanitized" };
          }
          if (/message is not modified/i.test(detail) ||
              /specified new message content and reply markup are exactly the same/i.test(detail)) {
            return { ok: true, skipped: true, description: "message not modified" };
          }
          // Deleting a message that is already gone is also an expected no-op.
          // This happens when an auto-delete timer, moderation rule, callback,
          // or another worker removes the same message first. Do not report it
          // as SYSTEM ERROR and do not rethrow it to the caller.
          if (name === "deleteMessage" && /400\s+Bad Request:\s*message to delete not found/i.test(detail)) {
            return { ok: true, skipped: true, description: "message to delete not found (already deleted)" };
          }
          // A Telegram media message has no text body, so editMessageText fails.
          // Fall back to editing its caption; if that is not possible, send a fresh
          // text message instead of surfacing a noisy 400 to the owner.
          // 429 from progress edits is expected under Telegram flood control.
          // Swallow it after recording the cooldown; do NOT rethrow/report it.
          if (/429\s+Too Many Requests/i.test(detail)) {
            return { ok: false, skipped: true, rate_limited: true };
          }
          if (name === "editMessageText" && /there is no text in the message to edit/i.test(detail)) {
            const text = args[0];
            const options = args[1] || {};
            // Media messages often have a caption instead of a text body.
            // Try caption first, but IMPORTANT: wait for its rejection before
            // deciding to send a fresh text message. Otherwise a second
            // Telegram 400 can escape and produce the same SYS-MSV error.
            try {
              const captionOptions = { ...options };
              const cap = bot.editMessageCaption;
              if (typeof cap === "function") {
                try {
                  return await cap.call(bot, text, captionOptions);
                } catch (captionErr) {
                  const capDetail = serializeError(captionErr);
                  if (!/there is no caption|message is not modified|message to edit/i.test(capDetail)) {
                    report(bot, `telegram.${name}.caption_fallback`, captionErr);
                  }
                }
              }
            } catch (_) {}
            try {
              const chatId = options.chat_id;
              if (chatId != null && typeof bot.sendMessage === "function") {
                const sendOptions = { ...options };
                delete sendOptions.message_id;
                return await bot.sendMessage(chatId, text, sendOptions);
              }
            } catch (_) {}
            return { ok: false, skipped: true, description: "message has no editable text/caption body" };
          }
          report(bot, `telegram.${name}`, err);
          throw err;
        });
      }
      return result;
      }
    wrapped.__yoenGuarded = true;
    bot[name] = wrapped;
  }
}

module.exports = { install, report };
