const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const chalk = require("chalk");
const { execSync, exec, spawn } = require("child_process");
const settings = require("./settings");
const TelegramBot = require("node-telegram-bot-api");
const axios = require("axios");
const { Client } = require("ssh2");
// Global safety net for legacy ssh2 exec() calls. Core Lianix installers use
// runLianixRemoteScript(), but older VPS tools must not hang forever either.
if (!Client.prototype.__lianixExecSafetyInstalled) {
  const __rawSshExec = Client.prototype.exec;
  Object.defineProperty(Client.prototype, "__lianixExecSafetyInstalled", { value: true });
  Client.prototype.exec = function(command, options, callback) {
    if (typeof options === "function") { callback = options; options = undefined; }
    if (typeof callback !== "function") return __rawSshExec.call(this, command, options || {}, callback);
    let called = false;
    const openTimer = setTimeout(() => { if (!called) { called = true; callback(new Error("SSH_EXEC_CHANNEL_TIMEOUT")); } }, 20000);
    if (openTimer.unref) openTimer.unref();
    const wrapped = (err, stream) => {
      if (called) { try { stream?.close(); } catch {} return; }
      called = true; clearTimeout(openTimer);
      if (err || !stream) return callback(err || new Error("SSH_EXEC_NO_STREAM"));
      let idle = null;
      const arm = () => { clearTimeout(idle); idle=setTimeout(() => { try{stream.close();}catch{} try{stream.destroy();}catch{} }, 10*60*1000); if(idle.unref)idle.unref(); };
      arm(); stream.on("data",arm); stream.stderr?.on("data",arm); stream.once("close",()=>clearTimeout(idle)); stream.once("error",()=>clearTimeout(idle));
      callback(null, stream);
    };
    return options === undefined ? __rawSshExec.call(this, command, wrapped) : __rawSshExec.call(this, command, options, wrapped);
  };
}

const archiver = require("archiver");
const { createCanvas, loadImage } = require("./src/optionalCanvas");
const __rawNodeFetch = require("node-fetch");
// Runtime safety net only: legacy modules historically called node-fetch without
// any deadline. Keep their UI/flow untouched, but prevent an unreachable API
// from hanging a Telegram handler forever. Existing caller-provided signals are
// preserved; the fallback deadline is only injected when no signal is supplied.
const fetch = async (url, options = {}) => {
  if (options && options.signal) return __rawNodeFetch(url, options);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 120000);
  if (timer.unref) timer.unref();
  try { return await __rawNodeFetch(url, { ...options, signal: controller.signal }); }
  finally { clearTimeout(timer); }
};
try {
  const fetchModulePath = require.resolve("node-fetch");
  if (require.cache[fetchModulePath]) require.cache[fetchModulePath].exports = fetch;
} catch {}
// Same principle for legacy axios calls. Explicit per-request timeout values
// still override this default; this only prevents an accidental infinite wait.
if (!axios.defaults.timeout) axios.defaults.timeout = 120000;
const fsExtra = require("fs-extra");
const os = require("os");
const readline = require("readline");
const https = require("https");
const startBot = require("./src/start");
const { enqueueSend } = require("./src/data/tgQueue");
const themeEngine = require("./src/theme");
const canonicalMenu = require("./src/menu");
const errorAudit = require("./src/errorAudit");
const aiErrorRepair    = require("./src/aiErrorRepair");
const aiCodeAnalyzer   = require("./src/aiCodeAnalyzer");

const OWNER_UIDB = String(settings.ownerId).trim();
const OWNER_UID = settings.ownerId;

const delay = ms => new Promise(r => setTimeout(r, ms));

/**
 * safeReply — sendMessage dengan reply_to_message_id yang aman.
 * Kalau pesan aslinya sudah dihapus (ETELEGRAM 400 "message to be replied not found"),
 * otomatis retry tanpa reply daripada melempar error ke unhandledRejection / SYSTEM ERROR.
 */
async function safeReply(bot, chatId, text, opts = {}) {
  try {
    return await bot.sendMessage(chatId, text, opts);
  } catch (err) {
    const desc = String(err?.response?.body?.description || err?.message || '');
    if (/message to be replied not found/i.test(desc) && opts.reply_to_message_id) {
      const { reply_to_message_id: _, ...safeOpts } = opts;
      return await bot.sendMessage(chatId, text, safeOpts);
    }
    throw err;
  }
}

async function runBot(bot) {
  // ============================================================
  // LIANIX — PIXEL STARTUP UI
  // Tampilan startup dibuat mengikuti gaya logo pixel pada desain.
  // ============================================================
  console.clear();

  const blue = (text) => chalk.hex("#91ADFF")(text);
  const dimBlue = (text) => chalk.hex("#5F78B8")(text);
  const white = (text) => chalk.whiteBright(text);
  const green = (text) => chalk.hex("#73E6A5")(text);
  const gray = (text) => chalk.hex("#5B6478")(text);

  const logo = [
    "██      ██  ██  █████  ███    ██ ██████ ██   ██",
    "██      ██  ██ ██   ██ ████   ██   ██    ██ ██ ",
    "██      ██  ██ ███████ ██ ██  ██   ██     ███  ",
    "██      ██  ██ ██   ██ ██  ██ ██   ██    ██ ██ ",
    "██      ██  ██ ██   ██ ██   ████   ██   ██   ██",
    "██████████  ██ ██   ██ ██    ███ ██████ ██   ██"
  ];

  console.log(blue("\n"));
  logo.forEach((line, i) => {
    const shadow = dimBlue(line.replace(/█/g, "░"));
    console.log("  " + blue(line) + "  " + gray(i === 0 ? "z" : i === 1 ? "z" : ""));
    if (i === 5) console.log("  " + shadow);
  });

  console.log(blue("\n  ╭──────────────────────────────────────────────────────────╮"));
  console.log(blue("  │ ") + white("LianiX CPanel") + gray("  •  V1.0.0") + blue("                           │"));
  console.log(blue("  ├──────────────────────────────────────────────────────────┤"));
  console.log(blue("  │ ") + gray(">") + white(" SYSTEM STATUS") + gray(":" ) + green(" ONLINE") + blue("                              │"));
  console.log(blue("  │ ") + gray(">") + white(" TELEGRAM API") + gray(":" ) + white(" CONNECTING...") + blue("                         │"));
  console.log(blue("  ╰──────────────────────────────────────────────────────────╯"));

  try {
    await bot.getMe();
    console.log(blue("\n  > ") + white("TELEGRAM API") + gray(": ") + green("CONNECTED"));
    console.log(blue("  > ") + white("BOT STATUS") + gray(": ") + green("READY / ONLINE"));
  } catch (e) {
    console.log(blue("\n  > ") + white("TELEGRAM API") + gray(": ") + chalk.redBright("FAILED"));
    console.log(chalk.redBright("    " + e.message));
    throw e;
  }

  console.log(gray("\n  ────────────────────────────────────────────────────────────"));
  console.log(dimBlue("  ◈ LianiX • Developer: LianiX (@yoennakbobo)"));
  console.log(dimBlue("  ◇ Secure Console  •  Bot Runtime  •  Telegram"));
  console.log("");
}


bot = new TelegramBot(settings.token, { polling: false });

// Global fallback untuk reply_to_message_id yang targetnya sudah dihapus.
// Semua modul yang memanggil bot.sendMessage ikut aman.
if (!bot.__lianixSafeSendMessage) {
  const originalSendMessage = bot.sendMessage.bind(bot);
  bot.sendMessage = async function safeSendMessage(chatId, text, options = {}, ...rest) {
    try {
      return await originalSendMessage(chatId, text, options, ...rest);
    } catch (err) {
      const desc = String(err?.response?.body?.description || err?.message || "");
      if (/message to be replied not found/i.test(desc) && options?.reply_to_message_id) {
        const { reply_to_message_id: _replyId, ...safeOptions } = options;
        return await originalSendMessage(chatId, text, safeOptions, ...rest);
      }
      throw err;
    }
  };
  bot.__lianixSafeSendMessage = true;
}

// Global short-window output dedupe. Prevents duplicate sends caused by
// overlapping handlers/retries without suppressing legitimate later output.
if (!bot.__lianixOutputDedupe) {
  const methods = ['sendMessage', 'sendDocument', 'sendPhoto', 'sendVideo', 'sendAudio', 'sendAnimation'];
  const original = {};
  const recent = new Map();
  const hash = value => require('crypto').createHash('sha1').update(String(value || '')).digest('hex');
  const escapeHtml = value => String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');

  // Telegram output polish: only plain-text output is decorated.
  // Existing HTML/Markdown output is left untouched so no feature layout
  // or formatting is unexpectedly changed.
  const hasTelegramMarkup = value => /<\/?(?:b|strong|i|em|u|s|code|pre|a|blockquote|tg-spoiler|del|ins)(?:\s|>)/i.test(String(value ?? ''));
  const decoratePlainText = (text, options) => {
    if (typeof text !== 'string' || !text.trim()) return { text, options };
    if (options?.parse_mode || hasTelegramMarkup(text)) return { text, options };
    const safe = escapeHtml(text);
    return {
      text: `<blockquote>${safe}</blockquote>`,
      options: { ...options, parse_mode: 'HTML' }
    };
  };

  for (const method of methods) {
    if (typeof bot[method] !== 'function') continue;
    original[method] = bot[method].bind(bot);
    bot[method] = async function dedupeOutput(chatId, payload, options = {}, ...rest) {
      let finalPayload = payload;
      let finalOptions = options || {};

      // Give plain text messages/captions a clean Telegram presentation:
      // bold service label + quoted content. Existing rich output is preserved.
      if (method === 'sendMessage') {
        const decorated = decoratePlainText(payload, finalOptions);
        finalPayload = decorated.text;
        finalOptions = decorated.options;
      } else if (typeof finalOptions?.caption === 'string' && !finalOptions.parse_mode && !hasTelegramMarkup(finalOptions.caption)) {
        const decorated = decoratePlainText(finalOptions.caption, finalOptions);
        finalOptions = decorated.options;
        finalOptions.caption = decorated.text;
      }

      const caption = finalOptions?.caption || '';
      const fileKey = typeof finalPayload === 'string' ? finalPayload : finalPayload?.source || finalPayload?.file_id || finalPayload?.filename || '';
      const key = `${method}:${chatId}:${hash(`${fileKey}|${caption}|${method === 'sendMessage' ? finalPayload : ''}`)}`;
      const now = Date.now();
      const previous = recent.get(key);
      if (previous && now - previous.at < 1500) return previous.result;
      let promise;
      try {
        promise = original[method](chatId, finalPayload, finalOptions, ...rest);
        recent.set(key, { at: now, result: promise });
        return await promise;
      } catch (err) {
        const desc = String(err?.response?.body?.description || err?.message || '');
        // HTML/Markdown entity errors must never leave a feature dead. Retry the
        // same payload as plain text/caption when Telegram rejects markup.
        if (/can't parse entities|unexpected end tag|unsupported start tag|unexpected end tag|unclosed tag/i.test(desc)) {
          const fallbackOptions = { ...(finalOptions || {}) };
          delete fallbackOptions.parse_mode;
          if (typeof fallbackOptions.caption === 'string') fallbackOptions.caption = fallbackOptions.caption.replace(/<[^>]*>/g, '');
          if (method === 'sendMessage' && typeof finalPayload === 'string') {
            const plain = finalPayload.replace(/<[^>]*>/g, '');
            return await original[method](chatId, plain, fallbackOptions, ...rest);
          }
          return await original[method](chatId, finalPayload, fallbackOptions, ...rest);
        }
        throw err;
      } finally {
        setTimeout(() => {
          const current = recent.get(key);
          if (current?.result === promise) recent.delete(key);
        }, 1600);
      }
    };
  }
  bot.__lianixOutputDedupe = true;
}


// ============================================================
// GLOBAL CALLBACK_DATA GUARD
// Telegram hanya menerima callback_data 1..64 byte UTF-8. Beberapa
// fitur menggunakan ID dinamis (droplet/tag/session/email) yang kadang
// melewati batas tersebut. Jangan dipotong karena itu akan merusak
// command/handler; simpan alias pendek dan pulihkan kembali saat callback.
// ============================================================
(function installCallbackDataGuard(botInstance) {
  if (!botInstance || botInstance.__lianixCallbackGuard) return;
  botInstance.__lianixCallbackGuard = true;

  const dbDir = path.join(__dirname, 'db');
  const dbFile = path.join(dbDir, 'callbackAliases.json');
  try { fs.mkdirSync(dbDir, { recursive: true }); } catch {}

  let aliases = Object.create(null);
  try {
    const raw = fs.readFileSync(dbFile, 'utf8');
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === 'object') aliases = parsed;
  } catch {}

  const reverse = new Map();
  for (const [alias, original] of Object.entries(aliases)) {
    if (typeof original === 'string' && alias.startsWith('lxcb_')) reverse.set(original, alias);
  }

  const save = (() => {
    let timer = null;
    return () => {
      clearTimeout(timer);
      timer = setTimeout(() => {
        try {
          const entries = Object.entries(aliases).slice(-5000);
          fs.writeFileSync(dbFile, JSON.stringify(Object.fromEntries(entries), null, 2));
        } catch {}
      }, 250);
    };
  })();

  function aliasFor(original) {
    if (typeof original !== 'string') return original;
    if (Buffer.byteLength(original, 'utf8') >= 1 && Buffer.byteLength(original, 'utf8') <= 64) return original;
    if (!original) return 'lxcb_empty';
    const existing = reverse.get(original);
    if (existing) return existing;

    let alias;
    for (let i = 0; i < 20; i++) {
      const suffix = i ? `_${i}` : '';
      alias = `lxcb_${crypto.createHash('sha256').update(original + suffix).digest('base64url').slice(0, 28)}`;
      if (!aliases[alias] || aliases[alias] === original) break;
    }
    aliases[alias] = original;
    reverse.set(original, alias);
    save();
    return alias;
  }

  function cleanInlineButtonText(value, callbackData) {
    const original = String(value ?? '');
    if (/buy script|dev panel/i.test(original)) return original;

    const normalized = original.normalize('NFKC');
    const controlCallback = String(callbackData || '');
    const isControl = /(?:^|[:_])(plus|minus|inc|dec|increase|decrease|adjust|threshold_(?:up|down)|cpu_(?:up|down)|disk_(?:up|down)|add|del)(?:$|[:_\-])/i.test(controlCallback);
    const controlOnly = /^[+−–—±＋－➕➖-]\s*$/.test(normalized);

    let cleaned = normalized
      .replace(/[\p{Extended_Pictographic}\u200B-\u200D\uFE0E\uFE0F\u{1F3FB}-\u{1F3FF}]/gu, '')
      .replace(/[•·◆◇◈◉⟐⟡⌖↯◌✦✧★☆✓✔✕✖⚙▣◒]/gu, '')
      .replace(/\s{2,}/g, ' ')
      .trim();

    if (isControl || controlOnly) {
      const controlPrefix = normalized.match(/^[\s]*(?:\+|-|−|–|—|±|＋|－|➕|➖)/u);
      if (controlPrefix) {
        const rest = cleaned.replace(/^[+−–—±＋－➕➖-]\s*/u, '').trim();
        cleaned = controlPrefix[0].trim() + (rest ? ' ' + rest : '');
      }
    }

    return cleaned || (controlOnly ? normalized : 'Back');
  }

  function normalizeMarkup(value) {
    if (!value || typeof value !== 'object') return value;
    if (Array.isArray(value)) return value.map(normalizeMarkup);
    const out = { ...value };
    if (Array.isArray(out.inline_keyboard)) {
      out.inline_keyboard = out.inline_keyboard.map(row =>
        Array.isArray(row) ? row.map(btn => {
          if (!btn || typeof btn !== 'object') return btn;
          const next = { ...btn };
          if (typeof next.text === 'string') next.text = cleanInlineButtonText(next.text, next.callback_data);
          if (typeof next.callback_data === 'string') next.callback_data = aliasFor(next.callback_data);
          return next;
        }) : row
      );
    }
    return out;
  }

  function normalizeOptions(options) {
    if (!options || typeof options !== 'object') return options;
    const out = { ...options };
    if (out.reply_markup) out.reply_markup = normalizeMarkup(out.reply_markup);
    return out;
  }

  const methodsWithOptions = [
    'sendMessage','sendPhoto','sendVideo','sendDocument','sendAudio','sendVoice',
    'sendAnimation','sendMediaGroup','copyMessage','editMessageText','editMessageCaption',
    'editMessageReplyMarkup','answerCallbackQuery'
  ];

  for (const method of methodsWithOptions) {
    if (typeof botInstance[method] !== 'function') continue;
    const original = botInstance[method].bind(botInstance);
    botInstance[method] = (...args) => {
      const next = args.slice();
      if (method === 'sendMediaGroup' && Array.isArray(next[1])) {
        next[1] = next[1].map(item => normalizeOptions(item));
      } else if (next.length) {
        const idx = next.length - 1;
        if (next[idx] && typeof next[idx] === 'object' && !Array.isArray(next[idx])) {
          next[idx] = normalizeOptions(next[idx]);
        }
      }
      return original(...next);
    };
  }

  // Listener ini dipasang sebelum modul-modul fitur mendaftarkan handler lain.
  // EventEmitter mengirim objek query yang sama, sehingga handler berikutnya
  // menerima callback_data aslinya kembali.
  botInstance.on('callback_query', query => {
    try {
      const data = query?.data;
      if (typeof data === 'string' && aliases[data]) query.data = aliases[data];
    } catch {}
  });
})(bot);

// Global Telegram edit recovery. Some menus can be rendered as media messages
// (photo/document/etc.), where editMessageText fails with "there is no text in
// the message to edit". Retry as a caption update and silently ignore the
// harmless "message is not modified" response.
(function installTelegramEditRecovery(botInstance) {
  if (!botInstance || botInstance.__lianixEditRecovery) return;
  botInstance.__lianixEditRecovery = true;
  const rawEditText = botInstance.editMessageText.bind(botInstance);
  const rawEditCaption = botInstance.editMessageCaption.bind(botInstance);
  botInstance.editMessageText = async (...args) => {
    try {
      return await rawEditText(...args);
    } catch (err) {
      const desc = String(err?.response?.body?.description || err?.message || err || '');
      if (/there is no text in the message to edit/i.test(desc)) {
        try { return await rawEditCaption(...args); } catch (captionErr) {
          const captionDesc = String(captionErr?.response?.body?.description || captionErr?.message || captionErr || '');
          if (/message is not modified/i.test(captionDesc)) return null;
          // Jangan samarkan kegagalan caption sebagai sukses. Wrapper safe-edit
          // di bawah perlu melihat error asli agar bisa retry/finalize dengan benar.
          throw captionErr;
        }
      }
      if (/message is not modified/i.test(desc)) return null;
      throw err;
    }
  };
})(bot);

// AI debugger: menyimpan konteks error agar OWNER bisa meminta analisis/patch.
aiErrorRepair.register(bot);

// AI Code Analyzer: upload zip → analisis + auto-patch kode via DeepAI.
aiCodeAnalyzer.register(bot);


// ============================================================
// GLOBAL TELEGRAM API ERROR MONITOR
// Semua rejection dari Bot API dilaporkan ke OWNER, termasuk error
// kecil seperti message_not_modified, callback kadaluarsa, 404, 400, dll.
// Error tetap dilempar kembali supaya alur caller tidak berubah.
// ============================================================
let __reportingApiError = false;
const __errorReportQueue = [];
let __errorReportWorker = false;
const __apiErrorMethods = [
  'sendMessage','sendPhoto','sendVideo','sendDocument','sendAudio','sendVoice',
  'sendAnimation','sendMediaGroup','copyMessage','forwardMessage',
  'editMessageText','editMessageCaption','editMessageReplyMarkup','deleteMessage',
  'answerCallbackQuery','getChat','getChatMember','getChatAdministrators','getChatMemberCount',
  'getFile','getFileLink','createChatInviteLink','approveChatJoinRequest','declineChatJoinRequest',
  'banChatMember','unbanChatMember','restrictChatMember','promoteChatMember',
  'setChatAdministratorCustomTitle','setChatPermissions','setChatTitle','setChatDescription',
  'leaveChat','pinChatMessage','unpinChatMessage','getMe','getUpdates'
];
function __installApiErrorMonitor(botInstance) {
  for (const method of __apiErrorMethods) {
    if (typeof botInstance?.[method] !== 'function') continue;
    const flag = `__errorMonitored_${method}`;
    if (botInstance[flag]) continue;
    botInstance[flag] = true;
    const original = botInstance[method].bind(botInstance);
    botInstance[method] = (...args) => {
      let result;
      try { result = original(...args); }
      catch (err) {
        if (!isTransientNetworkError(err)) reportGlobalError(`telegram:${method}`, err, { method });
        throw err;
      }
      return Promise.resolve(result).catch(err => {
        const desc = err?.response?.body?.description || err?.message || String(err || '');
        if (method === 'answerCallbackQuery' && /query is too old|response timeout expired|query ID is invalid/i.test(desc)) return null;
        // Invalid HTML/Markdown entities in user-generated text are recoverable:
        // retry once without parse_mode so send/edit operations still complete.
        if (['sendMessage','sendVideo','sendPhoto','sendDocument','sendAudio','sendVoice',
             'sendAnimation','editMessageText','editMessageCaption'].includes(method) &&
            /can't parse entities|unsupported start tag|unexpected end tag|can't find end tag|unclosed tag/i.test(desc)) {
          try {
            const retryArgs = [...args];
            const idx = (method === 'editMessageText' || method === 'editMessageCaption') ? 1 : 2;
            const opts = retryArgs[idx];
            if (opts && typeof opts === 'object') {
              const plain = { ...opts };
              delete plain.parse_mode;
              retryArgs[idx] = plain;
              return Promise.resolve(original(...retryArgs));
            }
          } catch (_) {}
          return null;
        }
        // restrictChatMember terhadap admin/owner memang ditolak Telegram.
        // Jangan report sebagai SYSTEM ERROR dan jangan lempar rejection ke caller.
        // Fitur mute/lock akan cukup melewati target tersebut.
        if (method === 'restrictChatMember' &&
            /user is an administrator of the chat|user is an administrator|administrator of the chat/i.test(desc)) {
          return null;
        }
        // getChat / getChatMember: target memang bisa tidak ada / belum start bot.
        // Return null agar caller tidak menghasilkan unhandledRejection atau SYSTEM ERROR.
        if ((method === 'getChat' || method === 'getChatMember') &&
            /chat not found|user not found|bot was blocked|bot was kicked|deactivated|have no rights/i.test(desc)) {
          return null;
        }
        // sendMessage reply_to_message_id: pesan yang mau di-reply sudah dihapus user.
        // Ini race condition biasa, bukan bug bot — skip report.
        if (method === 'sendMessage' &&
            /message to be replied not found|replied message not found/i.test(desc)) {
          throw err;
        }
        // sendPhoto: URL foto mati / Telegram tidak bisa fetch URL.
        // Sudah ada fallback ke sendMessage di start.js — jangan dobel report.
        if (method === 'sendPhoto' &&
            /there is no photo in the request|wrong file identifier|wrong remote file/i.test(desc)) {
          throw err;
        }
        // 429 adalah rate limit Telegram, bukan bug aplikasi. Biarkan wrapper
        // safe-edit menangani retry_after tanpa membuat SYSTEM ERROR berantai.
        if (/429|too many requests|retry after/i.test(desc)) throw err;
        // editMessageText/editMessageCaption can legitimately target the other
        // Telegram message type; the UI wrapper below will switch method or send
        // a fresh message. Do not report this expected 400 as a SYSTEM ERROR.
        if ((method === 'editMessageText' || method === 'editMessageCaption') &&
            /there is no text in the message to edit|there is no caption in the message to edit/i.test(desc)) {
          throw err;
        }
        // Idempotent Telegram edit: kalau isi/caption/markup sama persis,
        // Telegram mengembalikan 400 `message is not modified`. Ini bukan bug.
        // Pesan yang sudah dihapus juga bukan error aplikasi karena registry/menu
        // akan dibersihkan oleh refresh handler.
        if ((method === 'editMessageText' || method === 'editMessageCaption' || method === 'editMessageReplyMarkup') &&
            /message is not modified|message to edit not found/i.test(desc)) {
          throw err;
        }

        // wrapSafeEdit (outer) menangani retry + logging untuk error ini.
        // Jangan dobel-report ke SYSTEM ERROR.
        if (/can't parse reply keyboard markup|reply keyboard markup/i.test(desc)) {
          throw err;
        }
        // Transient network errors bukan bug bot — skip monitor
        if (!isTransientNetworkError(err)) reportGlobalError(`telegram:${method}`, err, { method });
        throw err;
      });
    };
  }
}
__installApiErrorMonitor(bot);

// ============================================================
// TRANSIENT NETWORK ERROR DETECTOR
// Error-error ini adalah gangguan jaringan sementara dari sisi
// Telegram/hosting — bukan bug bot. Jangan kirim ke error monitor
// karena hanya akan banjiri notif owner tanpa manfaat. Bot akan
// otomatis reconnect/retry sendiri.
// ============================================================
function isTransientNetworkError(err) {
  if (!err) return false;
  const msg   = String(err?.message || err || '');
  const code  = String(err?.code || '');
  const status = Number(err?.response?.statusCode || err?.response?.status || 0);
  // TCP-level drops
  if (/ECONNRESET|ECONNREFUSED|ETIMEDOUT|EPIPE|ENOTFOUND|EAI_AGAIN|socket hang up/i.test(msg)) return true;
  if (/ECONNRESET|ECONNREFUSED|ETIMEDOUT|EPIPE|ENOTFOUND|EAI_AGAIN/i.test(code)) return true;
  // AggregateError = multiple TCP failures at once
  if (err instanceof AggregateError || /AggregateError/i.test(msg)) return true;
  // Telegram 502 / 503 / 504 — server-side blip, bukan error kode bot
  if ([502, 503, 504].includes(status)) return true;
  if (/ETELEGRAM:\s*(502|503|504)/i.test(msg)) return true;
  if (/502 Bad Gateway|503 Service Unavailable|504 Gateway/i.test(msg)) return true;
  // Reply-to message deleted — race condition, benign, no action needed.
  if (/message to be replied not found/i.test(msg)) return true;
  return false;
}

function reportGlobalError(type, error, context = {}) {
  // Transient network errors (ECONNRESET, AggregateError, 502/503/504) bukan
  // bug bot — hanya gangguan jaringan sesaat. Drop silently, jangan banjiri
  // owner dengan SYSTEM ERROR yang tidak actionable.
  if (isTransientNetworkError(error)) {
    console.warn(`[monitor] transient network error (${type}): ${error?.message || error} — skipped`);
    return;
  }
  const ownerIds = (() => {
    try {
      const ids = ownerStore.getOwnerIds();
      return [...new Set((ids || []).map(String).filter(Boolean))];
    } catch (_) {
      return settings.ownerId ? [String(settings.ownerId)] : [];
    }
  })();
  if (!ownerIds.length || !bot) return;
  const code = `SYS-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 7).toUpperCase()}`;
  let raw = error?.stack || error?.message || String(error || 'Unknown error');
  const secrets = [settings.token, process.env.BOT_TOKEN, process.env.FIREBASE_API_KEY].filter(Boolean);
  for (const secret of secrets) raw = raw.split(String(secret)).join('[REDACTED]');
  const safe = raw.slice(0, 3500).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  const ctx = Object.entries(context || {}).filter(([,v]) => v !== undefined && v !== null && v !== '').slice(0, 8).map(([k,v]) => `${k}: ${String(v).slice(0,200)}`).join('\n');
  aiErrorRepair.remember(code, { type, raw, context });
  const text = `<b>╭━━〔 SYSTEM ERROR 〕━━╮</b>\n🧾 <b>Code:</b> <code>${code}</code>\n⚙️ <b>Type:</b> <code>${String(type).slice(0,80)}</code>${ctx ? `\n\n<b>Context</b>\n<code>${ctx.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}</code>` : ''}\n\n<pre>${safe}</pre>\n╰━━━━━━━━━━━━━━━━━━━━━━╯`;
  __errorReportQueue.push({ text, code });
  while (__errorReportQueue.length > 20) __errorReportQueue.shift();
  void __flushErrorReportQueue();
}

async function __flushErrorReportQueue() {
  if (__errorReportWorker || !bot) return;
  __errorReportWorker = true;
  try {
    while (__errorReportQueue.length) {
      const item = __errorReportQueue.shift();
      __reportingApiError = true;
      try {
        // Owner #1 dan Owner #2 menerima SYSTEM ERROR yang sama.
        // Kegagalan mengirim ke salah satu owner tidak boleh menghentikan
        // pengiriman ke owner lainnya.
        let ownerIds = [];
        try {
          ownerIds = [...new Set(ownerStore.getOwnerIds().map(String).filter(Boolean))];
        } catch (_) {
          ownerIds = settings.ownerId ? [String(settings.ownerId)] : [];
        }
        for (const ownerId of ownerIds) {
          try {
            await bot.sendMessage(ownerId, item.text, {
              parse_mode: 'HTML',
              reply_markup: aiErrorRepair.keyboard(item.code)
            });
          } catch (_) {}
        }
      } finally { __reportingApiError = false; }
      await new Promise(r => setTimeout(r, 150));
    }
  } finally {
    __errorReportWorker = false;
  }
}

// Deep runtime monitor: menangkap error yang sebelumnya cuma ditulis ke console.error/warn
// sehingga tidak pernah masuk SYSTEM ERROR. Dedupe agar tidak spam owner.
errorAudit.installConsoleMonitor({
  report: (type, err, context) => reportGlobalError(type, err, context)
});

bot.on('error', err => {
  reportGlobalError('telegram:error', err);
});
bot.on('polling_error', err => {
  // 502/ECONNRESET dll adalah Telegram-side blip — bot auto-reconnect sendiri.
  // Jangan kirim ke error monitor supaya tidak spam owner.
  if (isTransientNetworkError(err)) {
    console.warn(`[polling] transient: ${err?.message || err}`);
    return;
  }
  reportGlobalError('polling_error', err);
});
bot.on('webhook_error', err => {
  reportGlobalError('webhook_error', err);
});


// PERBAIKAN DOUBLE OUTPUT: startBot(bot) DIHAPUS dari sini.
// Handler start.js sudah didaftarkan lewat loop modules di dalam initializeBot().
// Memanggil startBot(bot) di sini DAN di loop = semua handler terdaftar 2x
// = setiap /start, /menu, dll menghasilkan 2 balasan sekaligus.

// ======================= SAFE EDIT (FIX error berulang di menu) =======================
// FIX: hampir semua menu tombol (termasuk "⬡ Kelola Channel" di Dev Panel)
// manggil bot.editMessageCaption/editMessageText TANPA .catch(). Begitu isi
// pesan yang mau di-edit PERSIS SAMA kayak sebelumnya (misal bolak-balik
// Kelola Channel <-> Dev Panel tanpa ubah apa-apa), Telegram nolak dengan
// error "400: message is not modified" -> promise reject tanpa ditangkep
// -> muncul di console TERUS-TERUSAN tiap tombol itu dipencet lagi, dan
// dari sisi user tombolnya keliatan gak ngefek (macet di error yang sama).
// Di-patch sekali di sini (bukan nambelin .catch satu-satu di puluhan
// tempat) supaya SEMUA pemanggil otomatis aman, error "gak penting" kayak
// gitu didiemin, error lain tetep kelihatan di console buat debug.
// ======================= SAFE EDIT =======================
// Telegram membatasi editMessageText. Semua edit sekarang:
// 1) diantrikan agar tidak meledak bersamaan,
// 2) menghormati retry_after dari Telegram,
// 3) mengabaikan "message is not modified",
// 4) tidak mengirim SYSTEM ERROR berulang untuk 429.
const __telegramEditQueue = [];
let __telegramEditWorker = false;

function __getRetryAfterMs(error) {
  const retryAfter = Number(
    error?.response?.body?.parameters?.retry_after ??
    String(error?.response?.body?.description || error?.message || "")
      .match(/retry after\s+(\d+)/i)?.[1]
  );
  return Number.isFinite(retryAfter) && retryAfter > 0
    ? (retryAfter * 1000) + 250
    : 0;
}

function __sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function __runTelegramEditQueue() {
  if (__telegramEditWorker) return;
  __telegramEditWorker = true;

  try {
    while (__telegramEditQueue.length) {
      const job = __telegramEditQueue.shift();
      try {
        const result = await Promise.race([
          Promise.resolve().then(() => job.run()),
          new Promise(resolve => { const t=setTimeout(() => resolve(null), 8000); if (t.unref) t.unref(); })
        ]);
        job.resolve(result);
      } catch (e) {
        job.reject(e);
      }

      // Beri jarak antar-edit agar refresh massal tidak langsung
      // memicu flood control Telegram.
      if (__telegramEditQueue.length) await __sleep(120);
    }
  } finally {
    __telegramEditWorker = false;
  }
}

function __enqueueTelegramEdit(run) {
  return new Promise((resolve, reject) => {
    __telegramEditQueue.push({ run, resolve, reject });
    void __runTelegramEditQueue();
  });
}

function __sanitizeTelegramReplyMarkup(markup) {
  if (markup == null) return null;
  let m = markup;
  // Telegram accepts reply_markup as an object. node-telegram-bot-api can
  // also receive a JSON string, but only if it parses into an object.
  if (typeof m === "string") {
    try { m = JSON.parse(m); } catch { return null; }
  }
  if (!m || typeof m !== "object" || Array.isArray(m)) return null;

  // INLINE KEYBOARD: construct a brand-new object containing ONLY fields
  // Telegram officially accepts. This prevents custom/theme fields from
  // leaking into the API request and causing "can't parse reply keyboard
  // markup JSON object".
  if (Object.prototype.hasOwnProperty.call(m, "inline_keyboard")) {
    if (!Array.isArray(m.inline_keyboard)) return null;
    const rows = [];
    for (const row of m.inline_keyboard) {
      if (!Array.isArray(row)) continue;
      const cleanRow = [];
      for (const btn of row) {
        if (!btn || typeof btn !== "object" || Array.isArray(btn)) continue;
        const text = typeof btn.text === "string" ? btn.text : "";
        if (!text.trim()) continue;

        const clean = { text };
        // Telegram Bot API terbaru mendukung warna tombol resmi. Pertahankan
        // hanya nilai style yang valid agar sanitizer tidak mematikan Auto Cycle.
        if (["primary", "success", "danger"].includes(btn.style)) clean.style = btn.style;
        if (typeof btn.icon_custom_emoji_id === "string" && btn.icon_custom_emoji_id.trim()) clean.icon_custom_emoji_id = btn.icon_custom_emoji_id.trim();
        let action = false;

        if (typeof btn.callback_data === "string") {
          if (Buffer.byteLength(btn.callback_data, "utf8") >= 1 && Buffer.byteLength(btn.callback_data, "utf8") <= 64) {
            clean.callback_data = btn.callback_data;
            action = true;
          }
        } else if (typeof btn.url === "string" && /^(https?:\/\/|tg:\/\/)/i.test(btn.url.trim())) {
          clean.url = btn.url.trim();
          action = true;
        } else if (btn.web_app && typeof btn.web_app === "object" && !Array.isArray(btn.web_app) && typeof btn.web_app.url === "string" && /^https?:\/\//i.test(btn.web_app.url.trim())) {
          clean.web_app = { url: btn.web_app.url.trim() };
          action = true;
        } else if (btn.login_url && typeof btn.login_url === "object" && !Array.isArray(btn.login_url) && typeof btn.login_url.url === "string" && /^https?:\/\//i.test(btn.login_url.url.trim())) {
          clean.login_url = { url: btn.login_url.url.trim() };
          action = true;
        } else if (typeof btn.switch_inline_query === "string") {
          clean.switch_inline_query = btn.switch_inline_query;
          action = true;
        } else if (typeof btn.switch_inline_query_current_chat === "string") {
          clean.switch_inline_query_current_chat = btn.switch_inline_query_current_chat;
          action = true;
        } else if (btn.switch_inline_query_chosen_chat && typeof btn.switch_inline_query_chosen_chat === "object" && !Array.isArray(btn.switch_inline_query_chosen_chat)) {
          const x = btn.switch_inline_query_chosen_chat;
          const chosen = {};
          for (const key of ["allow_user_chats", "allow_bot_chats", "allow_group_chats", "allow_channel_chats"]) {
            if (typeof x[key] === "boolean") chosen[key] = x[key];
          }
          // Empty switch_inline_query_chosen_chat is invalid/useless; don't send it.
          if (Object.keys(chosen).length) {
            clean.switch_inline_query_chosen_chat = chosen;
            action = true;
          }
        } else if (btn.callback_game && typeof btn.callback_game === "object" && !Array.isArray(btn.callback_game)) {
          clean.callback_game = {};
          action = true;
        } else if (btn.copy_text && typeof btn.copy_text === "object" && !Array.isArray(btn.copy_text) && typeof btn.copy_text.text === "string") {
          clean.copy_text = { text: btn.copy_text.text };
          action = true;
        } else if (btn.pay === true) {
          clean.pay = true;
          action = true;
        }

        if (action) cleanRow.push(clean);
      }
      if (cleanRow.length) rows.push(cleanRow);
    }
    return rows.length ? { inline_keyboard: rows } : null;
  }

  // Reply keyboard. Only keep Telegram's reply-keyboard fields and valid rows.
  if (Object.prototype.hasOwnProperty.call(m, "keyboard")) {
    if (!Array.isArray(m.keyboard)) return null;
    const keyboard = m.keyboard
      .filter(Array.isArray)
      .map(row => row.map(btn => {
        if (typeof btn === "string") return btn;
        if (!btn || typeof btn !== "object" || Array.isArray(btn)) return null;
        const clean = {};
        if (typeof btn.text === "string") clean.text = btn.text;
        if (["primary", "success", "danger"].includes(btn.style)) clean.style = btn.style;
        if (typeof btn.icon_custom_emoji_id === "string" && btn.icon_custom_emoji_id.trim()) clean.icon_custom_emoji_id = btn.icon_custom_emoji_id.trim();
        if (typeof btn.request_contact === "boolean") clean.request_contact = btn.request_contact;
        if (typeof btn.request_location === "boolean") clean.request_location = btn.request_location;
        if (btn.request_poll && typeof btn.request_poll === "object" && !Array.isArray(btn.request_poll)) {
          clean.request_poll = {};
          if (typeof btn.request_poll.type === "string") clean.request_poll.type = btn.request_poll.type;
        }
        if (btn.web_app && typeof btn.web_app === "object" && typeof btn.web_app.url === "string" && /^https?:\/\//i.test(btn.web_app.url)) {
          clean.web_app = { url: btn.web_app.url };
        }
        return Object.keys(clean).length ? clean : null;
      }).filter(Boolean))
      .filter(row => row.length);
    if (!keyboard.length) return null;
    return {
      keyboard,
      ...(m.is_persistent === true ? { is_persistent: true } : {}),
      ...(m.resize_keyboard === true ? { resize_keyboard: true } : {}),
      ...(m.one_time_keyboard === true ? { one_time_keyboard: true } : {}),
      ...(typeof m.input_field_placeholder === "string" ? { input_field_placeholder: m.input_field_placeholder } : {}),
      ...(m.selective === true ? { selective: true } : {}),
    };
  }

  if (m.remove_keyboard === true) return { remove_keyboard: true, ...(m.selective === true ? { selective: true } : {}) };
  if (m.force_reply === true) return {
    force_reply: true,
    ...(typeof m.input_field_placeholder === "string" ? { input_field_placeholder: m.input_field_placeholder } : {}),
    ...(m.selective === true ? { selective: true } : {}),
  };
  return null;
}

function wrapSafeEdit(bot, methodName) {
  // IMPORTANT: keep the raw Telegram methods here. Calling the wrapped
  // counterpart from inside the edit queue can deadlock the queue.
  const rawText = bot.editMessageText.bind(bot);
  const rawCaption = bot.editMessageCaption.bind(bot);
  const original = methodName === "editMessageCaption" ? rawCaption : rawText;

  const isNoText = (desc) => /there is no text in the message to edit/i.test(desc);
  const isNoCaption = (desc) => /there is no caption in the message to edit/i.test(desc);
  const isMessageGone = (desc) => /message to (?:edit|delete) not found|message not found/i.test(desc);
  const isCaptionTooLong = (desc) => /MEDIA_CAPTION_TOO_LONG|caption.*(?:too long|must be.*1024)|message caption is too long/i.test(desc);
  const isNotModified = (desc) => /message is not modified/i.test(desc);
  const isMarkupError = (desc) => /can't parse reply keyboard markup(?: JSON object)?|reply keyboard markup/i.test(desc);

  // Telegram membatasi caption media sampai 1024 karakter. Kalau Telegram
  // masih menolak caption setelah pre-truncate, retry pada MEDIA YANG SAMA
  // sebagai plain caption yang lebih pendek. Jangan membuat output baru.
  const retryShortCaptionSameMessage = async (args) => {
    const text = String(args?.[0] ?? '');
    const options = args?.[1];
    if (!options || typeof options !== 'object' || !options.chat_id || !options.message_id || !text) return null;
    const plain = text
      .replace(/<br\s*\/?>(?=.)/gi, "\n")
      .replace(/<[^>]+>/g, '')
      .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&')
      .replace(/&quot;/g, '"').replace(/&#39;/g, "'");
    const shortOptions = { ...options };
    delete shortOptions.parse_mode;
    return await rawCaption(plain.slice(0, 880) + "\n\n… Detail dipersingkat agar tetap di kartu yang sama.", shortOptions);
  };

  const retryWithCleanMarkup = async (args) => {
    const fallbackArgs = args.slice();
    const options = fallbackArgs[1];
    if (!options || typeof options !== 'object' || options.reply_markup == null) return null;
    const cleaned = __sanitizeTelegramReplyMarkup(options.reply_markup);
    if (!cleaned) return null;
    fallbackArgs[1] = { ...options, reply_markup: cleaned };
    return await original(...fallbackArgs);
  };

  // Last-resort safety: Telegram rejects the WHOLE edit when reply_markup is
  // malformed. Never let a bad keyboard make the underlying text edit fail.
  // We first try a strictly sanitized keyboard; if Telegram still rejects it,
  // retry the exact same text/caption WITHOUT reply_markup. This prevents the
  // recurring "can't parse reply keyboard markup JSON object" spam while
  // keeping the message itself editable.
  const retryWithoutMarkup = async (args) => {
    const fallbackArgs = args.slice();
    const options = fallbackArgs[1];
    if (!options || typeof options !== 'object') return null;
    const { reply_markup, ...safeOptions } = options;
    fallbackArgs[1] = safeOptions;
    return await original(...fallbackArgs);
  };

  const runRaw = async (args) => {
    // Sanitize BEFORE the first Telegram request. The previous patch only
    // sanitized after Telegram rejected the keyboard, so an invalid
    // reply_markup could still reach editMessageText and be logged by
    // errorAudit before the retry happened.
    const safeArgs = args.slice();
    const safeOptions = safeArgs[1];
    if (safeOptions && typeof safeOptions === "object" && safeOptions.reply_markup != null) {
      const cleaned = __sanitizeTelegramReplyMarkup(safeOptions.reply_markup);
      safeArgs[1] = { ...safeOptions, ...(cleaned ? { reply_markup: cleaned } : { reply_markup: undefined }) };
      if (!cleaned) delete safeArgs[1].reply_markup;
    }
    // Hindari MEDIA_CAPTION_TOO_LONG sebelum request dikirim. Telegram membatasi
    // caption media ~1024 karakter; untuk dashboard media kita pertahankan pesan
    // yang sama dan ringkas caption, bukan membuat output baru.
    if (methodName === "editMessageCaption" && typeof safeArgs[0] === "string" && safeArgs[0].length > 980) {
      const plain = safeArgs[0].replace(/<br\s*\/?>(?=.)/gi, "\n").replace(/<[^>]+>/g, "").replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/&amp;/g,"&");
      safeArgs[0] = plain.slice(0, 900) + "\n\n… Detail dipersingkat agar tetap di kartu yang sama.";
      if (safeArgs[1] && typeof safeArgs[1] === "object") {
        safeArgs[1] = { ...safeArgs[1] };
        delete safeArgs[1].parse_mode;
      }
    }
    try {
      return await original(...safeArgs);
    } catch (e) {
      const desc = String(e?.response?.body?.description || e?.message || e || "");

      if (isNotModified(desc)) return null;

      // Caption media terlalu panjang: jangan biarkan edit gagal dan
      // jangan biarkan keyboard/tampilan lama tetap menempel.
      if (isCaptionTooLong(desc) && methodName === "editMessageCaption") {
        try {
          return await retryShortCaptionSameMessage(safeArgs);
        } catch (replacementErr) {
          // Kalau retry caption pendek gagal, biarkan error asli diproses di bawah.
        }
      }

      // A very common case in this bot: some menu handlers call
      // editMessageCaption even though the current dashboard is a TEXT
      // message. Transparently switch to editMessageText, and vice versa.
      if (methodName === "editMessageCaption" && isNoCaption(desc)) {
        try { return await rawText(...safeArgs); } catch (textErr) {
          const textDesc = String(textErr?.response?.body?.description || textErr?.message || textErr || "");
          if (isNotModified(textDesc)) return null;
          if (isMarkupError(textDesc)) {
            try { return await retryWithCleanMarkup(safeArgs); } catch {}
          }
          throw textErr;
        }
      }

      if (methodName === "editMessageText" && isNoText(desc)) {
        try { return await rawCaption(...safeArgs); } catch (captionErr) {
          const captionDesc = String(captionErr?.response?.body?.description || captionErr?.message || captionErr || "");
          if (isNotModified(captionDesc)) return null;
          if (isMarkupError(captionDesc)) {
            try { return await retryWithCleanMarkup(safeArgs); } catch {}
          }
          throw captionErr;
        }
      }

      const retryMs = __getRetryAfterMs(e);
      if (retryMs > 0) throw Object.assign(e, { __lianixRetryMs: retryMs });

      if (isMarkupError(desc)) {
        try {
          const result = await retryWithCleanMarkup(safeArgs);
          if (result !== null && result !== undefined) return result;
        } catch (cleanErr) {
          throw cleanErr;
        }
        // Telegram can still reject a dynamically generated keyboard even
        // after sanitizing it (for example stale/double-encoded markup).
        // The text edit must still succeed, so retry once without the keyboard.
        try {
          const result = await retryWithoutMarkup(safeArgs);
          if (result !== null && result !== undefined) return result;
        } catch (fallbackErr) {
          const fallbackDesc = String(fallbackErr?.response?.body?.description || fallbackErr?.message || fallbackErr || '');
          if (isNotModified(fallbackDesc)) return null;
          throw fallbackErr;
        }
        throw e;
      }

      throw e;
    }
  };

  bot[methodName] = (...args) => __enqueueTelegramEdit(async () => {
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        const result = await runRaw(args);
        // runRaw mengembalikan null hanya untuk edit idempotent (message is not modified).
        // Tandai sebagai SUKSES supaya caller tidak mengirim output fallback kedua.
        if (result == null) return { ok: true, unchanged: true, __lianixEditResult: true };
        return result;
      } catch (e) {
        const desc = String(e?.response?.body?.description || e?.message || e || "");
        if (isNotModified(desc)) return { ok: true, unchanged: true, __lianixEditResult: true };
        if (isMessageGone(desc)) return { ok: false, gone: true, __lianixEditResult: true };

        const retryMs = e?.__lianixRetryMs || __getRetryAfterMs(e);
        if (retryMs > 0) {
          if (attempt >= 2) {
            console.warn(`[${methodName}] rate limited; retry limit reached`);
            return { ok:false, rateLimited:true, error:desc, __lianixEditResult:true };
          }
          await __sleep(retryMs);
          continue;
        }

        // A malformed/dynamic keyboard must never bubble into the global
        // error audit. At this point runRaw already attempted the sanitized
        // keyboard and the no-keyboard fallback. If Telegram still rejects
        // the edit, fail silently for this specific markup error so the bot
        // remains usable and no SYS-MT... error is generated.
        if (isMarkupError(desc)) {
          // reply_markup sudah dicoba: sanitized -> tanpa keyboard.
          // Jangan console.error di sini karena errorAudit memonitor console.error
          // dan akan membuat SYSTEM ERROR palsu/berulang untuk error markup yang
          // memang sudah ditangani oleh safe-edit.
          return { ok:false, skipped:true, error:desc, __lianixEditResult:true };
        }

        console.warn(`[${methodName}] gagal dan diteruskan ke caller:`, desc);
        throw e;
      }
    }
    return { ok:false, skipped:true, error:"edit retry exhausted", __lianixEditResult:true };
  });
}
wrapSafeEdit(bot, "editMessageCaption");
wrapSafeEdit(bot, "editMessageText");

// ================= SAFE SEND / DELETE =================
// Telegram HTML parser errors must never create a second error cascade.
// If a dynamically-built HTML message is malformed, retry the SAME message
// as plain text instead of leaving the feature failed/unhandled.
(function installSafeSendDelete(botInstance) {
  if (!botInstance || botInstance.__lianixSafeSendDelete) return;
  botInstance.__lianixSafeSendDelete = true;

  const rawSend = botInstance.sendMessage.bind(botInstance);
  const rawDelete = botInstance.deleteMessage.bind(botInstance);

  const isEntityError = (err) => /can't parse entities|unexpected end tag|unsupported start tag|can't find end tag/i.test(
    String(err?.response?.body?.description || err?.message || err || '')
  );
  const isGone = (err) => /message to delete not found|message to edit not found|message not found/i.test(
    String(err?.response?.body?.description || err?.message || err || '')
  );
  const stripHtml = (value) => String(value ?? '')
    .replace(/<[^>]*>/g, '')
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"').replace(/&#39;/g, "'");

  botInstance.sendMessage = async (chatId, text, options = {}) => {
    try {
      return await rawSend(chatId, text, options);
    } catch (err) {
      if (!isEntityError(err) || String(options?.parse_mode || '').toUpperCase() !== 'HTML') throw err;
      const fallbackOptions = { ...options };
      delete fallbackOptions.parse_mode;
      return rawSend(chatId, stripHtml(text), fallbackOptions);
    }
  };

  botInstance.deleteMessage = async (chatId, messageId) => {
    try {
      return await rawDelete(chatId, messageId);
    } catch (err) {
      if (isGone(err)) return false;
      throw err;
    }
  };
})(bot);

// editMessageReplyMarkup menerima reply_markup langsung di options. Patch
// terpisah supaya keyboard yang rusak tidak pernah lolos ke Telegram dari
// jalur verifikasi wajib-join / menu lain.
(function installSafeEditReplyMarkup(botInstance) {
  if (!botInstance || botInstance.__lianixSafeEditReplyMarkup) return;
  botInstance.__lianixSafeEditReplyMarkup = true;
  const raw = botInstance.editMessageReplyMarkup.bind(botInstance);
  botInstance.editMessageReplyMarkup = (...args) => __enqueueTelegramEdit(async () => {
    const safeArgs = args.slice();
    const markup = safeArgs[0];
    const options = safeArgs[1];
    const cleaned = __sanitizeTelegramReplyMarkup(markup);
    safeArgs[0] = cleaned || { inline_keyboard: [] };
    try {
      return await raw(...safeArgs);
    } catch (e) {
      const desc = String(e?.response?.body?.description || e?.message || e || "");
      if (/message is not modified/i.test(desc)) return null;
      // If Telegram still rejects it, remove the keyboard entirely.
      if (/can't parse reply keyboard markup(?: JSON object)?|reply keyboard markup/i.test(desc)) {
        try { return await raw({ inline_keyboard: [] }, options); } catch (fallback) {
          const fd = String(fallback?.response?.body?.description || fallback?.message || fallback || "");
          if (/message is not modified/i.test(fd)) return null;
          console.error("[editMessageReplyMarkup] gagal:", fd);
          return null;
        }
      }
      console.error("[editMessageReplyMarkup] gagal:", desc);
      return null;
    }
  });
})(bot);

// ======================= SINGLE INSTANCE LOCK =======================
// FIX: root cause dari "kadang diam / kadang delay" yang dilaporin -> ada
// 2+ proses node index.js jalan bareng pakai token bot yang SAMA (biasanya
// gara-gara tombol Stop di panel hosting gak bener-bener bunuh proses lama
// / ada instance pm2 nyangkut). Telegram cuma ngasih tiap update ke SALAH
// SATU proses secara gak konsisten (race condition di long-polling), jadi
// user kadang direspon proses baru (udah kena fix), kadang "kemakan"
// proses lama -> keliatan random/kadang diam total. Sekarang sebelum
// startPolling(), bot cek lockfile berisi PID proses yang lagi pegang
// polling. Kalau ada proses lain yang masih HIDUP pegang lock itu, proses
// baru ini nolak lanjut (biar gak dobel polling), jelasin ke console PID
// mana yang harus di-kill manual. Lockfile otomatis dianggap basi/stale
// kalau PID di dalemnya udah gak hidup lagi (misal proses lama mati gak
// sempet cleanup), atau lockfile-nya ke-tinggal dari 30+ menit lalu.
const LOCK_FILE = path.join(__dirname, ".bot.lock");
const LOCK_STALE_MS = 30 * 60 * 1000; // 30 menit

function isPidAlive(pid) {
  try {
    process.kill(pid, 0); // gak bener2 kill, cuma cek proses masih ada
    return true;
  } catch (e) {
    return false; // ESRCH = proses udah gak ada
  }
}

function acquireSingleInstanceLock() {
  try {
    if (fs.existsSync(LOCK_FILE)) {
      const raw = fs.readFileSync(LOCK_FILE, "utf8").trim();
      const data = JSON.parse(raw || "{}");
      const stale =
        !data.pid ||
        !isPidAlive(data.pid) ||
        (data.startedAt && Date.now() - data.startedAt > LOCK_STALE_MS);

      if (!stale) {
        console.error(chalk.red.bold("\n⊘ Bot BATAL start: kedetect proses lain masih jalan pakai token yang sama."));
        console.error(chalk.red(`   PID proses lama: ${data.pid} (mulai ${new Date(data.startedAt).toLocaleString()})`));
        console.error(chalk.yellow(`   Kalau proses itu emang udah gak dipake / zombie, matiin dulu manual:`));
        console.error(chalk.yellow(`   kill -9 ${data.pid}   (atau: pm2 delete <nama-app>)`));
        console.error(chalk.yellow(`   lalu jalanin ulang bot ini.`));
        console.error(chalk.gray(`   (Ini buat nyegah 409 Conflict / update Telegram "kemakan" proses lama.)\n`));
        process.exit(1);
      }

      console.log(chalk.yellow(`(info) Lockfile lama basi (PID ${data.pid} udah gak hidup / kadaluarsa), ditimpa.`));
    }

    fs.writeFileSync(LOCK_FILE, JSON.stringify({ pid: process.pid, startedAt: Date.now() }, null, 2));
  } catch (e) {
    // Kalau lockfile-nya sendiri gagal dibaca/ditulis (misal permission),
    // jangan sampe bikin bot gagal start total cuma gara2 ini -> cukup
    // dikasih tau di console, fitur intinya tetep jalan.
    console.log(chalk.yellow("(info) Gagal setup single-instance lock (non-critical):"), e.message);
  }
}

function releaseSingleInstanceLock() {
  try {
    if (fs.existsSync(LOCK_FILE)) {
      const data = JSON.parse(fs.readFileSync(LOCK_FILE, "utf8") || "{}");
      if (data.pid === process.pid) fs.unlinkSync(LOCK_FILE);
    }
  } catch (e) {
    // diemin, non-critical
  }
}

acquireSingleInstanceLock();
process.on("exit", releaseSingleInstanceLock);
process.on("SIGINT", () => { releaseSingleInstanceLock(); process.exit(0); });
process.on("SIGTERM", () => { releaseSingleInstanceLock(); process.exit(0); });
// Banyak modul (start.js, panel.js, cvps.js, dst) masing-masing daftar
// listener "callback_query"-nya sendiri (puluhan total), jadi naikkan
// batas default EventEmitter (10) biar gak keluar warning di console.
// Dibungkus try/catch soalnya ini cuma biar konsol bersih (non-critical),
// jangan sampe bikin bot gagal start kalo method-nya beda di versi lib ini.
try {
  if (typeof bot?.setMaxListeners === 'function') {
    bot.setMaxListeners(100);
  } else {
    const events = require('events');
    if (typeof events.setMaxListeners === 'function') events.setMaxListeners(100, bot);
  }
} catch {}

process.on('uncaughtException', (err) => {
  console.error('[UNCAUGHT EXCEPTION]', err);
  reportGlobalError('uncaughtException', err);
});
process.on('unhandledRejection', (reason) => {
  console.error('[UNHANDLED REJECTION]', reason);
  reportGlobalError('unhandledRejection', reason);
});

async function initializeBot() {
  await runBot(bot);

  // PREFIX ALTERNATIF: semua command ber-prefix tetap didukung.
  // Prefix yang diterima: / dan . saja.
  // Semua prefix alternatif dinormalisasi menjadi slash SEBELUM module handler
  // menerima update, sehingga seluruh fitur lama yang terdaftar dengan /cmd
  // tetap bisa dipanggil memakai .cmd, !cmd, #cmd, ~cmd, dll.
  // Semua command, termasuk seluruh fitur ADD, mengikuti aturan prefix yang sama.
  if (!bot.__alternativePrefixPatch) {
    const originalProcessUpdate = bot.processUpdate?.bind(bot);
    if (typeof originalProcessUpdate === 'function') {
      bot.processUpdate = function(update) {
        try {
          const message = update?.message || update?.edited_message;
          if (message && typeof message.text === 'string') {
            const raw = message.text;
            const m = raw.match(/^([/.])([A-Za-z][A-Za-z0-9_-]{1,40})(@\w+)?(\s|$)/);
            if (m) {
              const command = m[2].toLowerCase();
              // Semua command, termasuk ADD, dinormalisasi ke bentuk slash
              // agar handler lama yang terdaftar dengan /command tetap bekerja.
              const normalized = '/' + command + (m[3] || '') + raw.slice(m[0].length - (m[4] ? 1 : 0));
              const cloned = { ...message, text: normalized };
              if (update.message) update = { ...update, message: cloned };
              else if (update.edited_message) update = { ...update, edited_message: cloned };
            }
          }
        } catch (e) {
          // Prefix normalizer tidak boleh menjatuhkan update Telegram.
        }
        return originalProcessUpdate(update);
      };
      bot.__alternativePrefixPatch = true;
    }
  }

  const modules = [
    "./src/botMaintenance", // BOT-WIDE MAINTENANCE — harus paling pertama supaya emit-patch jalan sebelum handler lain
    "./src/mode", // WAJIB paling atas, biar semua modul di bawahnya ke-patch cek self/public mode
    "./src/start",
    "./src/panel",
    "./src/install",
    "./src/random",
    "./src/cvps",
    "./src/status",
    "./src/group",
    "./src/groupGuard", // JAGA GRUP dari Zanzy
    "./src/featureHub",
    "./src/scrapeCanvas", // SCRAPE + CANVAS PORT — GROUP MENU
    "./src/panelwa",
    // "./src/protect", // legacy protect/theme disabled: digantikan installer Lianix di src/install.js
    "./src/checklist",
    "./src/limit",
    "./src/relaychat",
    "./src/panelsettings",
    "./src/redeem",
    "./src/antikill",
    "./src/killfix",
    "./src/panelToolsV5",
    "./src/privateCpanel", // PRIVATE CPANEL: OWNER / FOUNDER+ ONLY
    "./src/webserver",
    "./src/cekserver",
    "./src/encrypt",
    "./src/am",
    "./src/reactwa",
    "./src/filters",
    "./src/ownerFeatures",
    "./src/aiCommands",
    "./src/downloaderCommands",
    "./src/archiveFeatureCommands", // ARCHIVE FEATURES — only commands not already registered
    "./src/main"
  ];

  // Known non-fatal errors: native module bindings not compiled, WhatsApp bridge missing.
  const KNOWN_NATIVE_ERRORS = [
    /No "exports" main defined in.*whatsapp-rust-bridge/i,
    /Cannot find module.*bcrypt.*binding/i,
    /Cannot find module.*bcrypt/i,
    /ERR_PACKAGE_PATH_NOT_EXPORTED/i,
  ];

  for (let file of modules) {
    try {
      require(file)(bot);
    } catch (err) {
      const msg = String(err?.message || err);
      const isKnownNative = KNOWN_NATIVE_ERRORS.some(re => re.test(msg) || re.test(String(err?.stack || '')));

      if (file === './src/panelwa' && /whatsapp-rust-bridge|ERR_PACKAGE_PATH_NOT_EXPORTED/i.test(msg + String(err?.stack || ''))) {
        console.warn(`\n◈ PERINGATAN: ${file} tidak dapat dimuat (WhatsApp Bridge tidak terinstall).`);
        console.warn(`  Fitur WhatsApp/Baileys dinonaktifkan. Bot Telegram tetap berjalan normal.`);
      } else if (file === './src/webserver' && /bcrypt/i.test(msg)) {
        console.warn(`\n◈ PERINGATAN: ${file} — bcrypt native binding tidak ditemukan.`);
        console.warn(`  Pastikan bcryptjs terinstall: npm install bcryptjs`);
      } else if (isKnownNative) {
        console.warn(`\n◈ PERINGATAN: ${file} — native module tidak tersedia: ${msg.slice(0, 120)}`);
      } else {
        console.error(`\n◇ ERROR FILE: ${file}`);
        console.error(`◈ PENYEBAB: ${err.message}`);
        console.error(err.stack);
      }
    }
  }


  // ===== SMART COMMAND SUGGESTION =====
  // Jika user typo command, contoh /stayt -> /start, bot memberi saran
  // tanpa mengganggu pesan biasa atau command yang sudah benar.
  try {
    const commandSet = new Set([
      'start','help','menu','aihelp','txt2img','img2video','image2video',
      'upscale','enhance','unblur','denoise','restore','colorize','rembg',
      'status','cekid','panel','addpanel','delpanel','editpanel','restart',
      'batal','ping','owner','runtime','list','tools'
    ]);

    const levenshtein = (a,b) => {
      const prev=Array.from({length:b.length+1},(_,i)=>i);
      for(let i=1;i<=a.length;i++){
        let cur=[i];
        for(let j=1;j<=b.length;j++){
          cur[j]=Math.min(
            cur[j-1]+1,
            prev[j]+1,
            prev[j-1]+(a[i-1]===b[j-1]?0:1)
          );
        }
        for(let j=0;j<cur.length;j++) prev[j]=cur[j];
      }
      return prev[b.length];
    };

    // Ambil command yang tertulis di source agar command baru otomatis ikut
    // dikenali sebagai kandidat saran.
    for (const file of modules) {
      try {
        const full = path.resolve(__dirname, file);
        const src = fs.readFileSync(full + '.js', 'utf8');
        const re = /\/([A-Za-z][A-Za-z0-9_-]{1,30})/g;
        let m;
        while ((m = re.exec(src))) commandSet.add(m[1].toLowerCase());
      } catch {}
    }

    bot.on('message', async (msg) => {
      try {
        if (!msg || typeof msg.text !== 'string') return;
        const text = msg.text.trim();
        const match = text.match(/^\/([A-Za-z0-9_-]+)(?:@\w+)?(?:\s|$)/);
        if (!match) return;

        const typed = match[1].toLowerCase();
        if (commandSet.has(typed)) return;

        let best=null;
        for (const cmd of commandSet) {
          const d=levenshtein(typed,cmd);
          const max=typed.length<=4?1:typed.length<=7?2:3;
          if(d<=max && (!best || d<best.d || (d===best.d && cmd.length<best.cmd.length))) {
            best={cmd,d};
          }
        }
        if (!best) return;

        return safeReply(
          bot, msg.chat.id,
          `**Maksud lu** /${best.cmd}**?**`,
          {parse_mode:'Markdown', reply_to_message_id:msg.message_id}
        );
      } catch {}
    });
  } catch (e) {
    console.error('[command-suggest] init gagal:', e.message);
  }

  // ===== AUTO CYCLE TEMA: canonical dashboard, selalu ON saat startup =====
  // Jangan bergantung pada buildMainMenuPayload dari start.js. Dashboard resmi
  // dibangun langsung dari src/menu sehingga siklus tidak mati hanya karena
  // urutan load module berubah.
  try {
    const ok = themeEngine.startAutoCycle(
      bot,
      (uid, username) => ({
        text: canonicalMenu.mainMenuText(uid, username || "Pengguna"),
        reply_markup: canonicalMenu.mainMenuKeyboard(uid),
      }),
      themeEngine.getIntervalMs()
    );
    console.log(ok
      ? chalk.green(`◉ Auto Cycle tema NYALA otomatis (interval ${themeEngine.getIntervalMs()}ms).`)
      : chalk.yellow("◉ Auto Cycle gagal diinisialisasi: builder menu tidak tersedia."));
  } catch (err) {
    console.error("[auto-cycle] Gagal nyalain otomatis:", err.message);
  }

  const {
    ownerId,
    dev,
    qris,
    pp,
    ppVid,
    panel
  } = settings;

const { createCanvas } = require("./src/optionalCanvas");

const BOOM_GAMES = {};
const LAST_IMAGE = {};

// ================= IMAGE =================
function generateBoomImage(opened = [], bombs = [], reveal = false) {
  const scale = 2;
  const canvas = createCanvas(700 * scale, 420 * scale);
  const ctx = canvas.getContext("2d");
  ctx.scale(scale, scale);

  const bg = ctx.createLinearGradient(0, 0, 0, 420);
  bg.addColorStop(0, "#151522");
  bg.addColorStop(1, "#1f1f33");
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, 700, 420);

  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.font = "bold 22px Arial";

  let n = 1;
  for (let r = 0; r < 3; r++) {
    for (let c = 0; c < 5; c++) {
      const x = 110 + c * 110;
      const y = 120 + r * 100;

      ctx.beginPath();
      ctx.arc(x + 3, y + 5, 36, 0, Math.PI * 2);
      ctx.fillStyle = "rgba(0,0,0,0.4)";
      ctx.fill();

      ctx.beginPath();
      ctx.arc(x, y, 36, 0, Math.PI * 2);

      if (reveal && bombs.includes(n)) ctx.fillStyle = "#ff3b3b";
      else if (opened.includes(n)) ctx.fillStyle = "#2ecc71";
      else ctx.fillStyle = "#0b0b0b";

      ctx.fill();
      ctx.fillStyle = "#fff";
      ctx.fillText(n, x, y);
      n++;
    }
  }
  return canvas.toBuffer("image/png");
}

// ================= IMAGE SENDER =================
async function sendGameImage(chatId, buffer, caption) {
  if (LAST_IMAGE[chatId]) {
    try {
      await bot.deleteMessage(chatId, LAST_IMAGE[chatId]);
    } catch {}
  }

  const tmp = path.join(os.tmpdir(), `lianix_game_${Date.now()}_${Math.random().toString(36).slice(2)}.png`);
  await fs.promises.writeFile(tmp, buffer);
  let msg;
  try {
    msg = await bot.sendPhoto(chatId, tmp, {
      caption,
      parse_mode: "HTML",
    });
  } finally {
    fs.promises.unlink(tmp).catch(() => {});
  }

  LAST_IMAGE[chatId] = msg.message_id;
}

// ================= PLAYER LIST =================
function renderPlayers(players) {
  let text = "<b>DAFTAR PEMAIN:</b>\n<blockquote expandable>";
  players.forEach((p, i) => {
    text += p.alive
      ? `${i + 1}. ${p.name}\n`
      : `${i + 1}. <s>${p.name}</s> ☠\n`;
  });
  return text + "</blockquote>";
}

// ================= /tebakboom =================
bot.onText(/^\/tebakboom$/, (msg) => {
  const chatId = msg.chat.id;
  if (BOOM_GAMES[chatId]) {
    return bot.sendMessage(
      chatId,
      "<blockquote expandable>◇ Game masih berjalan\nGunakan /batal untuk menghentikan</blockquote>",
      { parse_mode: "HTML" }
    );
  }

  BOOM_GAMES[chatId] = { stage: "mode" };

  bot.sendMessage(
    chatId,
    `<blockquote expandable>
⬡ <b>Pilih Mode Permainan</b>

1⃣ Multi Player
2⃣ Main Sendiri

Ketik <b>1</b> atau <b>2</b>
</blockquote>`,
    { parse_mode: "HTML" }
  );
});

// ================= MESSAGE HANDLER =================
bot.on("message", async (msg) => {
  const chatId = msg.chat.id;
  const text = msg.text;
  if (!text || !BOOM_GAMES[chatId]) return;

  const game = BOOM_GAMES[chatId];
  const userId = msg.from.id;
  const username = msg.from.username || msg.from.first_name;

  // ===== BATAL GAME =====
  if (text === "/batal") {
    delete BOOM_GAMES[chatId];
    delete LAST_IMAGE[chatId];

    return bot.sendMessage(
      chatId,
      "<blockquote expandable>⊘ Permainan dibatalkan</blockquote>",
      { parse_mode: "HTML" }
    );
  }

  // ===== MODE SELECT =====
  if (game.stage === "mode") {
    if (text === "1") {
      game.stage = "lobby";
      game.players = [];
      game.host = userId;

      return bot.sendMessage(
        chatId,
        `<blockquote expandable>
⌂ <b>MULTI PLAYER</b>

Ketik <b>/join</b> untuk ikut
Host ketik <b>/mulai</b> untuk mulai
</blockquote>`,
        { parse_mode: "HTML" }
      );
    }

    if (text === "2") {
      const nums = Array.from({ length: 15 }, (_, i) => i + 1);
      game.bombs = nums.sort(() => Math.random() - 0.5).slice(0, 5);
      game.opened = [];
      game.stage = "solo";

      return sendGameImage(
        chatId,
        generateBoomImage(),
        `<blockquote expandable>
⊘ <b>MODE SOLO</b>

Kirim angka <b>1–15</b>
</blockquote>`
      );
    }
  }

  // ===== JOIN =====
  if (text === "/join" && game.stage === "lobby") {
    if (game.players.find(p => p.id === userId)) return;

    game.players.push({ id: userId, name: username, alive: true });

    return bot.sendMessage(
      chatId,
      `<blockquote expandable>◉ ${username} join</blockquote>\n\n${renderPlayers(game.players)}`,
      { parse_mode: "HTML" }
    );
  }

  // ===== START MULTI =====
  if (text === "/mulai" && game.stage === "lobby") {
    if (userId !== game.host) return;
    if (game.players.length < 2) {
      return bot.sendMessage(
        chatId,
        "<blockquote expandable>◇ Minimal 2 pemain</blockquote>",
        { parse_mode: "HTML" }
      );
    }

    const nums = Array.from({ length: 15 }, (_, i) => i + 1);
    game.bombs = nums.sort(() => Math.random() - 0.5).slice(0, 5);
    game.opened = [];
    game.turn = 0;
    game.stage = "multi";

    return sendGameImage(
      chatId,
      generateBoomImage(),
      `<blockquote expandable>⌂ <b>Giliran:</b> ${game.players[0].name}</blockquote>\n\n${renderPlayers(game.players)}`
    );
  }

  // ===== SOLO TURN =====
  if (game.stage === "solo") {
    if (!/^\d+$/.test(text)) return;

    const num = parseInt(text);
    if (num < 1 || num > 15 || game.opened.includes(num)) return;

    game.opened.push(num);

    if (game.bombs.includes(num)) {
      delete BOOM_GAMES[chatId];
      delete LAST_IMAGE[chatId];

      return sendGameImage(
        chatId,
        generateBoomImage(game.opened, game.bombs, true),
        `<blockquote expandable>⟡ <b>KAMU KALAH</b>
Kena bom di angka <b>${num}</b></blockquote>`
      );
    }

    if (game.opened.length === 10) {
      delete BOOM_GAMES[chatId];
      delete LAST_IMAGE[chatId];

      return sendGameImage(
        chatId,
        generateBoomImage(game.opened, game.bombs, true),
        `<blockquote expandable>⌖ <b>KAMU MENANG!</b></blockquote>`
      );
    }

    return sendGameImage(
      chatId,
      generateBoomImage(game.opened),
      `<blockquote expandable>⊘ <b>MODE SOLO</b>
Pilih angka <b>1–15</b></blockquote>`
    );
  }

  // ===== MULTI TURN =====
  if (game.stage === "multi") {
    const player = game.players[game.turn];
    if (player.id !== userId) return;
    if (!/^\d+$/.test(text)) return;

    const num = parseInt(text);
    if (num < 1 || num > 15 || game.opened.includes(num)) return;

    game.opened.push(num);
    if (game.bombs.includes(num)) player.alive = false;

    const alive = game.players.filter(p => p.alive);
    if (alive.length === 1) {
      delete BOOM_GAMES[chatId];
      delete LAST_IMAGE[chatId];

      return sendGameImage(
        chatId,
        generateBoomImage(game.opened, game.bombs, true),
        `<blockquote expandable>⌖ <b>${alive[0].name} MENANG!</b></blockquote>\n\n${renderPlayers(game.players)}`
      );
    }

    do {
      game.turn = (game.turn + 1) % game.players.length;
    } while (!game.players[game.turn].alive);

    return sendGameImage(
      chatId,
      generateBoomImage(game.opened),
      `<blockquote expandable>⌂ <b>Giliran:</b> ${game.players[game.turn].name}</blockquote>\n\n${renderPlayers(game.players)}`
    );
  }
});
// [removed] target-vulnerability / DDoS-potential scanner command was here

bot.onText(/\/cekid(?:\s+(.+))?/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const arg = match[1] ? match[1].trim() : "";

  // Jika tidak ada argumen
  if (!arg) {
    if (msg.chat.type === "group" || msg.chat.type === "supergroup") {
      return bot.sendMessage(chatId, `<b>ID Group:</b> <code>${chatId}</code>`, { parse_mode: "HTML" });
    }
    if (msg.chat.type === "channel") {
      return bot.sendMessage(chatId, `<b>ID Channel:</b> <code>${chatId}</code>`, { parse_mode: "HTML" });
    }
    // Chat pribadi tanpa argumen
    return bot.sendMessage(
      chatId,
      `<b>Gunakan:</b> /cekid &lt;@username atau reply ke user&gt;

<b>Contoh:</b>
- /cekid (reply pesan user)
- /cekid`,
      { parse_mode: "HTML" }
    );
  }

  // Jika user reply ke pesan lain, ambil info user target
  let targetUser = null;
  if (msg.reply_to_message) {
    targetUser = msg.reply_to_message.from;
  }

  // Jika tidak reply, ambil info sendiri
  if (!targetUser) targetUser = msg.from;

  // Build info
  const fullName = targetUser.first_name + (targetUser.last_name ? " " + targetUser.last_name : "");
  const username = targetUser.username ? "@" + targetUser.username : "-";
  const userId = targetUser.id;

  const infoText = `<b>Full Name :</b> ${fullName}
<b>Username  :</b> ${username}
<b>ID        :</b> <code>${userId}</code>
<b>Chat ID   :</b> <code>${chatId}</code>
<b>Type      :</b> ${msg.chat.type}`;

  // Kirim info
  bot.sendMessage(chatId, infoText, { parse_mode: "HTML" });
});


bot.onText(/\/nest (.+)/, async (msg, match) => {

const chatId = msg.chat.id;
const [domain, ptla] = match[1].split("|");

if (!domain || !ptla) {
return bot.sendMessage(chatId,"Format:\n/delnest domain|plta");
}

const headers = {
Authorization: `Bearer ${ptla}`,
Accept: "Application/vnd.pterodactyl.v1+json",
"Content-Type": "application/json"
};

const nestIds = [1,2,3,4];

let eggDeleted = 0;
let nestDeleted = 0;

for (const nestId of nestIds) {

try {

const eggRes = await axios.get(`${domain}/api/application/nests/${nestId}/eggs`,{headers});
const eggs = eggRes.data.data;

for (const egg of eggs) {

try {
await axios.delete(`${domain}/api/application/nests/${nestId}/eggs/${egg.attributes.id}`,{headers});
eggDeleted++;
} catch {}

}

try {
await axios.delete(`${domain}/api/application/nests/${nestId}`,{headers});
nestDeleted++;
} catch {}

} catch {}

}

bot.sendMessage(chatId,
`⟡ DELETE NEST SELESAI

Target Nest : 1,2,3,4
⬡ Egg Dihapus : ${eggDeleted}
⬢ Nest Dihapus : ${nestDeleted}`
);

});


/* ================= ADD NEST ================= */

bot.onText(/\/addnest (.+)/, async (msg, match) => {

const chatId = msg.chat.id

if (!msg.reply_to_message) {
return bot.sendMessage(chatId,
"Reply ke file atau teks egg JSON")
}

const input = match[1]
const parts = input.split("|")

const domain = parts[0]
const ptla = parts[1]
const nestName = parts.slice(2).join("|")  // agar nama bisa pakai spasi

if (!domain || !ptla || !nestName) {
return bot.sendMessage(chatId,
"Format:\n/addnest domain|plta|nama nest")
}

const headers = {
Authorization: `Bearer ${ptla}`,
Accept: "Application/vnd.pterodactyl.v1+json",
"Content-Type": "application/json"
}

try {

const nestRes = await axios.post(
`${domain}/api/application/nests`,
{
name: nestName,
description: "Nest dibuat oleh bot"
},
{headers}
)

const nestId = nestRes.data.attributes.id

let eggJson

if (msg.reply_to_message.document) {

const fileId = msg.reply_to_message.document.file_id
const file = await bot.getFile(fileId)
const fileUrl = `https://api.telegram.org/file/bot${bot.token}/${file.file_path}`

const res = await axios.get(fileUrl)
eggJson = res.data

} else {

eggJson = JSON.parse(msg.reply_to_message.text)

}

await axios.post(
`${domain}/api/application/nests/${nestId}/eggs`,
eggJson,
{headers}
)

bot.sendMessage(chatId,
`◉ NEST BERHASIL DIBUAT

⬢ Nama Nest : ${nestName}
⬡ Egg : ${eggJson.name}
⟐ Panel : ${domain}`)

} catch (err) {

bot.sendMessage(chatId,"◇ Gagal membuat nest atau egg")

}
});
    const fs = require("fs")

// ============================================================
// TWO OWNER SYSTEM
// Owner #1 = root/permanent owner. Owner #1 can add Owner #2.
// Command dapat dipakai dengan atau tanpa prefix.
// ============================================================
const ownerStore = require("./src/data/ownerStore.js");
function isRootOwner(msg){ return String(msg?.from?.id) === String(ownerStore.getOwnerId()); }
async function addSecondOwner(msg, targetId, targetName){
  if(!isRootOwner(msg)) return bot.sendMessage(msg.chat.id, "◇ Hanya Owner #1 yang dapat menambahkan Owner #2.");
  try {
    const d=ownerStore.addOwner(targetId,targetName);
    return bot.sendMessage(msg.chat.id, `◉ Owner #2 berhasil ditambahkan.\nID: <code>${targetId}</code>\nTotal owner: ${d.ownerIds.length}/2`, {parse_mode:"HTML"});
  } catch(e){ return bot.sendMessage(msg.chat.id, `◇ Gagal menambah owner: ${e.message}`); }
}
bot.onText(/^\/?adddevown(?:\s+(\d+))?$/i, async (msg,match)=>{
  if(!isRootOwner(msg)) return;
  let target=match?.[1];
  let name=null;
  if(!target && msg.reply_to_message?.from){ target=String(msg.reply_to_message.from.id); name=msg.reply_to_message.from.username ? `@${msg.reply_to_message.from.username}` : msg.reply_to_message.from.first_name; }
  if(!target) return bot.sendMessage(msg.chat.id, "Format: <code>adddevown 123456789</code>\nAtau reply pesan user lalu ketik <code>adddevown</code>.", {parse_mode:"HTML"});
  return addSecondOwner(msg,target,name);
});
bot.onText(/^\/?listdevown$/i, async (msg)=>{
  if(!settings.isOwner(msg.from.id)) return;
  const ids=ownerStore.getOwnerIds();
  return bot.sendMessage(msg.chat.id, `◉ Daftar Owner\n\nOwner #1: <code>${ids[0]||"-"}</code>\nOwner #2: <code>${ids[1]||"-"}</code>`, {parse_mode:"HTML"});
});


const DB_FOLDER = "./db"
const DB_FILE = "./db/ga.json"

if (!fs.existsSync(DB_FOLDER)) fs.mkdirSync(DB_FOLDER)
if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, JSON.stringify([]))

function loadGA() {
    return JSON.parse(fs.readFileSync(DB_FILE))
}

function saveGA(data) {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2))
}

function isOwner(msg) {
    return settings.isOwner(msg?.from?.id)
}

// ADD GA
bot.onText(/^\/addga$/, (msg) => {
    const chatId = msg.chat.id

    if (!isOwner(msg)) return

    if (!msg.reply_to_message || !msg.reply_to_message.text) {
        return bot.sendMessage(chatId, "Reply teks untuk dijadikan GA")
    }

    let data = loadGA()

    data.push({
        chat_id: chatId,
        text: msg.reply_to_message.text
    })

    saveGA(data)

    bot.sendMessage(chatId, "◉ GA berhasil disimpan")
})


// AUTOGA COUNTDOWN
bot.onText(/^\/autoga (\d+) on$/, async (msg,match)=>{

    const chatId = msg.chat.id
    if(!isOwner(msg)) return

    let sisa = parseInt(match[1])

    if(!sisa) return bot.sendMessage(chatId,"Masukkan detik")

    const sent = await bot.sendMessage(chatId,`⏳ Countdown ${sisa} detik`)
    const mid = sent.message_id

    const timer = setInterval(async ()=>{

        sisa--

        if(sisa <= 0){

            clearInterval(timer)

            try{
                await bot.editMessageText("◉ Countdown selesai",{
                    chat_id:chatId,
                    message_id:mid
                })
            }catch{}

            const data = loadGA()

            // PENTING: sebelumnya ini nembak bot.sendMessage() ke SEMUA
            // chat_id sekaligus tanpa jeda sama sekali. Kalau data-nya
            // banyak, itu gampang banget bikin Telegram nge-flood-limit
            // SELURUH bot (bukan cuma fitur ini) sampai belasan jam,
            // yang efeknya bikin fitur lain kayak "Chat Owner" ikut mati
            // walau kodenya sendiri gak diubah. Sekarang dikirim satu-satu
            // lewat antrian bareng (src/data/tgQueue.js), pakai jeda dan
            // auto-retry kalau kena limit.
            for (const d of data) {
                await enqueueSend(() => bot.sendMessage(d.chat_id, d.text), d.chat_id).catch(() => {});
            }

            return
        }

        try{
            await bot.editMessageText(`⏳ Countdown ${sisa} detik`,{
                chat_id:chatId,
                message_id:mid
            })
        }catch{}

    },1000)

})
  function renderBanner() {
    const blue = (text) => chalk.hex("#91ADFF")(text);
    const dimBlue = (text) => chalk.hex("#5F78B8")(text);
    const white = (text) => chalk.whiteBright(text);
    const green = (text) => chalk.hex("#73E6A5")(text);
    const gray = (text) => chalk.hex("#5B6478")(text);

    const logo = [
      "██      ██  ██████  ███    ██ ██████ ██   ██",
      "██      ██ ██    ██ ████   ██   ██   ██   ██",
      "██      ██ ██    ██ ██ ██  ██   ██    ██ ██ ",
      "██      ██ ████████ ██  ██ ██   ██     ███  ",
      "██      ██ ██    ██ ██   ████   ██    ██ ██ ",
      "██████████ ██    ██ ██    ███ ██████ ██   ██"
    ];

    console.log("");
    logo.forEach((line, i) => {
      console.log("  " + blue(line) + (i < 2 ? "  " + dimBlue("z") : ""));
    });
    console.log(blue("\n  ╭──────────────────────────────────────────────────────────╮"));
    console.log(blue("  │ ") + white("LianiX CPanel") + gray("  •  V1.0.0") + blue("                           │"));
    console.log(blue("  ├──────────────────────────────────────────────────────────┤"));
    console.log(blue("  │ ") + white("> SYSTEM STATUS") + gray(": ") + green("ONLINE") + blue("                              │"));
    console.log(blue("  │ ") + white("> BOT STATUS") + gray(": ") + green("READY / ONLINE") + blue("                         │"));
    console.log(blue("  ╰──────────────────────────────────────────────────────────╯"));
    console.log(dimBlue("  ◈ LianiX • Developer: LianiX (@yoennakbobo)"));
    console.log(dimBlue("  ◇ Secure Console  •  Bot Runtime  •  Telegram\n"));
  }

  function silentClear() {
    console.clear();
    renderBanner();
  }

  // ===== ERROR HANDLER TANPA UBAH TAMPILAN =====

  bot.on("error", (err) => {
    console.error("\n⟡ BOT ERROR");
    console.error(`◈ ${err.message}`);
    console.error(err.stack);
    silentClear();
  });

  bot.on("polling_error", (err) => {
    // Transient: 502/503/504, ECONNRESET, AggregateError — Telegram-side blip.
    // node-telegram-bot-api auto-reconnect polling, jadi cukup log warn ringkas.
    // Jangan console.error karena errorAudit akan ikut nangkep dan kirim ke monitor.
    if (isTransientNetworkError(err)) {
      console.warn(`[polling] transient (${err?.message || err}) — auto-reconnect...`);
      silentClear();
      return;
    }

    console.error("\n⚠ POLLING ERROR");
    console.error(`◈ ${err.message}`);
    console.error(err.stack);

    if (err.code === "ETELEGRAM" && err.response?.statusCode === 409) {
      // 409 = ada 2 proses polling bareng pakai token yang sama (biasanya
      // kejadian SESAAT pas restart/deploy). Sebelumnya ini langsung
      // process.exit(1) -> kalau host gak ada auto-restart (pm2/systemd),
      // bot MATI TOTAL sampai di-restart manual. Sekarang di-recover
      // sendiri: stop polling sebentar, lalu coba nyala lagi.
      console.error("⚠ 409 Conflict kedetect, coba recover otomatis dalam 5 detik...");
      silentClear();
      try {
        bot.stopPolling().finally(() => {
          setTimeout(() => {
            bot.startPolling({ allowed_updates: ["message","edited_message","callback_query","my_chat_member","chat_member","chat_join_request"] }).catch((e) => {
              console.error("◇ Gagal restart polling:", e.message);
            });
          }, 5000);
        });
      } catch (e) {
        console.error("◇ Gagal stop polling buat recovery:", e.message);
      }
      return;
    }

    silentClear();
  });

  // Global exception/rejection handlers are installed once above.
}

// ======================= PASSWORD STARTUP =======================
// Aktif lagi: tiap kali bot di-Start di panel hosting (Pterodactyl/VPS),
// wajib masukin kode ini dulu baru bot jalan. Kodenya ditarik dari
// settings.startPassword ("velquira") biar sama dengan password gerbang
// /start di Telegram -- satu sumber, gampang diganti dari satu tempat.
// Kalau dijalanin non-interaktif (pm2/systemd/docker tanpa TTY), prompt
// otomatis di-skip (lihat verifyStartPassword) supaya bot gak nyangkut
// nunggu input yang gak pernah dateng.
const REQUIRE_START_PASSWORD = true;
// Password disimpan sebagai hash, jangan dibandingkan plaintext
const _crypto_idx = require("crypto");
const START_PASSWORD = settings.startPassword; // ini sudah berupa hash SHA-256
const checkPassword = (input) =>
  _crypto_idx.createHash("sha256").update(String(input ?? "")).digest("hex") === START_PASSWORD;
const MAX_PASSWORD_ATTEMPTS = 3;
// Bisa dijalankan langsung: node index.js <password>
// Catatan: argumen CLI dapat masuk shell history, jadi untuk server bersama
// lebih aman memakai BOT_AUTO_PASSWORD di environment.
const CLI_PASSWORD = process.argv.slice(2).join(" ").trim();

// CATATAN: sebelumnya di sini pakai "raw mode" (baca input keystroke demi
// keystroke) buat nyamarin password pakai simbol per-huruf. Ternyata itu
// gampang berantakan di console panel hosting (Pterodactyl dkk), soalnya
// console kayak gitu sering ngirim input SATU BARIS PENUH sekaligus (bukan
// per huruf) -- parser manualnya gagal ngenalin Enter/karakter tertentu
// (misal "+"), password gak pernah keproses, bot nyangkut nunggu input yang
// gak pernah "selesai" -> gak startPolling() tapi prosesnya juga gak mati
// -> numpuk proses -> pas restart Telegram nolak karena "bot lain lagi
// jalan" (conflict 409).
//
// Sekarang baliknya pakai `readline` biasa (yang emang udah teruji nanganin
// input baris-per-baris ATAUPUN keystroke-per-keystroke di semua jenis
// konsol), password-nya tetap ke-samarin dengan cara nge-mute output pas
// user ngetik (mirip prompt password `sudo` -- ga nongol apa-apa di layar,
// termasuk gak ada karakter/simbol tercetak sama sekali), bukan lagi
// parsing manual per-keystroke.
function askStartPassword(promptText) {
  return new Promise((resolve) => {
    const stdin = process.stdin;
    const stdout = process.stdout;

    const rl = readline.createInterface({ input: stdin, output: stdout });

    const origWrite = stdout.write.bind(stdout);
    let muted = false;

    // Saat password diketik, tampilkan bullet agar user tahu inputnya masuk.
    // Backspace juga menghapus satu bullet. Karakter password aslinya tidak
    // pernah ditulis ke terminal.
    let bulletCount = 0;
    stdout.write = (chunk, ...args) => {
      if (!muted) return origWrite(chunk, ...args);
      const text = String(chunk);
      if (/\x08|\x7f/.test(text)) {
        const n = Math.min(bulletCount, (text.match(/[\x08\x7f]/g) || []).length);
        if (n) {
          bulletCount -= n;
          origWrite('\b \b'.repeat(n));
        }
        return true;
      }
      // readline dapat mengirim ANSI cursor-control; jangan tampilkan itu.
      const printable = text.replace(/\x1b\[[0-?]*[ -\/]*[@-~]/g, '').replace(/[\r\n]/g, '');
      if (printable) {
        const n = [...printable].filter(ch => /[^\s]/.test(ch)).length;
        if (n) {
          bulletCount += n;
          origWrite('•'.repeat(n));
        }
      }
      return true;
    };

    const restore = () => {
      muted = false;
      stdout.write = origWrite;
    };

    // Prompt-nya ditulis manual dulu SEBELUM di-mute, jadi tetap kelihatan.
    origWrite(promptText);
    muted = true;

    rl.question("", (answer) => {
      restore();
      rl.close();
      stdout.write("\n");
      resolve(String(answer || "").trim());
    });

    // Jaga-jaga kalau readline ditutup paksa (Ctrl-C dsb) sebelum sempet
    // jawab -- pastikan stdout.write balik normal, jangan sampai ke-mute
    // selamanya dan bikin log berikutnya ikut ilang.
    rl.on("close", restore);
  });
}

async function verifyStartPassword() {
  if (!REQUIRE_START_PASSWORD) return true;
  // CLEAN BACKUP intentionally leaves the startup password empty. In that
  // state there is no credential to validate, so do not reject every input.
  if (!START_PASSWORD) {
    // Clean backup: tidak ada password startup yang harus diminta.
    return true;
  }

  // Skip otomatis jika ini adalah restart internal (dari /restart atau file-watcher).
  // Flag BOT_INTERNAL_RESTART=1 di-set oleh respawn.js sebelum spawn child baru.
  if (process.env.BOT_INTERNAL_RESTART === "1" &&
      process.env.BOT_INTERNAL_RESTART_HASH &&
      process.env.BOT_INTERNAL_RESTART_HASH === String(START_PASSWORD)) {
    console.log(chalk.green("◉ Internal restart terdeteksi — password terautentikasi otomatis."));
    return true;
  }

  // Jalur langsung: `node index.js <password>`.
  if (CLI_PASSWORD) {
    if (checkPassword(CLI_PASSWORD)) {
      console.log(chalk.green("◉ Password dari command line benar — menjalankan bot..."));
      return true;
    }
    console.log(chalk.red("◇ Password dari command line salah."));
    return false;
  }

  // Skip jika BOT_AUTO_PASSWORD di .env cocok dengan START_PASSWORD.
  // Berguna untuk panel hosting yang perlu auto-start tanpa TTY sama sekali.
  if (process.env.BOT_AUTO_PASSWORD && checkPassword(process.env.BOT_AUTO_PASSWORD)) {
    console.log(chalk.green("◉ Auto-password dari .env cocok — menjalankan bot..."));
    return true;
  }

  // Kalau dijalanin non-interaktif (pm2, systemd, docker, panel hosting tanpa
  // TTY), process.stdin.isTTY bakal undefined/false -> gak akan pernah ada
  // yang bisa ngetik password, jadi kode SEBELUMNYA bakal nyangkut selama-
  // lamanya nunggu input yang gak pernah dateng (bot keliatan "down" total
  // tiap kali auto-restart). Di kondisi itu, langsung skip aja.
  if (!process.stdin.isTTY) {
    console.log(chalk.yellow("⚠ Non-interactive shell terdeteksi (pm2/systemd/docker/panel), password prompt di-skip otomatis."));
    return true;
  }

  console.log(chalk.gray("╭──────────────────────────────╮"));
  console.log(chalk.gray("│ ") + chalk.white.bold("⚿ #LianiX VVIP"));
  console.log(chalk.gray("│ ") + chalk.white("Masukkan password buat menjalankan bot"));
  console.log(chalk.gray("╰──────────────────────────────╯"));

  for (let attempt = 1; attempt <= MAX_PASSWORD_ATTEMPTS; attempt++) {
    const input = await askStartPassword(`Password (percobaan ${attempt}/${MAX_PASSWORD_ATTEMPTS}): `);

    if (checkPassword(input)) {
      console.log(chalk.green("◉ Password benar! Menjalankan bot..."));
      return true;
    }

    console.log(chalk.red(`◇ Password salah! (${attempt}/${MAX_PASSWORD_ATTEMPTS})`));
  }

  console.log(chalk.red.bold("⊘ Terlalu banyak percobaan gagal. Bot dihentikan."));
  return false;
}

// ======================= WHITELIST TOKEN LOKAL =======================
// Selain daftar resmi dari GitHub (dikontrol penjual/dev), owner bot juga
// bisa nambahin token bot LAIN yang boleh pakai script ini lewat command
// Telegram "/addtoken <token>" (lihat src/panelToolsV5.js). Token yang
// ditambahin lewat situ disimpen di sini sebagai hash SHA-256, BUKAN token
// mentahnya -- biar db/tokens.json aman kalau kebocor/ke-share.
const TOKENS_DB_PATH = path.join(__dirname, "db", "tokens.json");

function loadLocalTokenHashes() {
  try {
    if (!fs.existsSync(TOKENS_DB_PATH)) return [];
    const data = JSON.parse(fs.readFileSync(TOKENS_DB_PATH, "utf8"));
    return Array.isArray(data.tokens) ? data.tokens : [];
  } catch {
    return [];
  }
}

// ======================= LISENSI GITHUB (UPDATED) =======================
// Cek apakah token bot ini ada di token.json di GitHub.
// URL: https://raw.githubusercontent.com/ibnuuyingjunde-art/bot-tokens/main/token.json
// Format token.json: ["TOKEN_1", "TOKEN_2", ...]
// Tambah token via Bot Add Token (/addtoken <token>).
async function verifyGithubLicense() {
  const myToken = String(settings.token).trim();
  const { owner, repo, branch, path: filePath, readToken } = settings.licenseGithub || {};

  // Clean backup: kredensial/lisensi sengaja dikosongkan. Jangan mencoba
  // GitHub dengan konfigurasi kosong karena itu membuat startup gagal hanya
  // karena token.json milik instalasi lama belum dibuat.
  if (!owner || !repo || !branch || !filePath) return true;
  const CACHE_PATH = path.join(__dirname, "db", "licenseCache.json");
  const rawUrl = `https://raw.githubusercontent.com/${owner}/${repo}/${branch}/${filePath}`;
  const apiUrl = `https://api.github.com/repos/${owner}/${repo}/contents/${encodeURIComponent(filePath)}?ref=${encodeURIComponent(branch)}`;
  const cdnUrl = `https://cdn.jsdelivr.net/gh/${owner}/${repo}@${encodeURIComponent(branch)}/${filePath}`;
  const baseHeaders = { "User-Agent": "LianiX-License-Check/2.0", "Accept": "application/vnd.github+json" };
  const authHeaders = readToken ? { ...baseHeaders, Authorization: `Bearer ${readToken}` } : baseHeaders;
  const CACHE_MAX_AGE = 24 * 60 * 60 * 1000;

  function tokenHash() {
    return crypto.createHash("sha256").update(myToken).digest("hex");
  }
  function readCache() {
    try {
      if (!fs.existsSync(CACHE_PATH)) return null;
      const data = JSON.parse(fs.readFileSync(CACHE_PATH, "utf8"));
      return data && typeof data === "object" ? data : null;
    } catch { return null; }
  }
  function cacheAllowsStart() {
    const c = readCache();
    return !!(c && c.tokenHash === tokenHash() && c.owner === owner && c.repo === repo &&
      c.branch === branch && c.filePath === filePath && Number.isFinite(c.verifiedAt) &&
      (Date.now() - c.verifiedAt) <= CACHE_MAX_AGE);
  }
  function saveCache() {
    try {
      fs.mkdirSync(path.dirname(CACHE_PATH), { recursive: true });
      fs.writeFileSync(CACHE_PATH, JSON.stringify({
        tokenHash: tokenHash(), verifiedAt: Date.now(), owner, repo, branch, filePath
      }, null, 2));
    } catch (e) {
      console.warn(`[LICENSE] gagal menyimpan cache: ${e.message}`);
    }
  }

  function normalizeTokenList(value) {
    if (Array.isArray(value)) return value.map(String);
    if (value && Array.isArray(value.tokens)) return value.tokens.map(String);
    if (value && typeof value === 'object' && Array.isArray(value.data)) return value.data.map(String);
    return [];
  }

  async function request(url, timeoutMs = 12000, headers = baseHeaders) {
    const res = await axios.get(url, {
      headers,
      timeout: timeoutMs,
      responseType: "json",
      validateStatus: s => s >= 200 && s < 500,
      maxContentLength: 2 * 1024 * 1024,
    });
    if (res.status === 429) {
      const retryAfter = Number(res.headers?.['retry-after'] || 0);
      const err = Object.assign(new Error('GitHub rate limit (429)'), { response: res, retryAfter });
      throw err;
    }
    if (res.status >= 400) throw Object.assign(new Error(`HTTP ${res.status}`), { response: res });
    return res;
  }

  async function getTokensFromApi() {
    const res = await request(apiUrl, 12000, authHeaders);
    const data = res.data;
    if (!data || typeof data !== 'object' || typeof data.content !== 'string') {
      throw new Error('GitHub API mengembalikan format file yang tidak dikenali');
    }
    const decoded = Buffer.from(data.content.replace(/\s+/g, ''), 'base64').toString('utf8');
    let parsed;
    try { parsed = JSON.parse(decoded); }
    catch { throw new Error('Isi token.json bukan JSON valid'); }
    return normalizeTokenList(parsed);
  }

  async function getTokensFromRaw(url) {
    const res = await request(url, 12000, authHeaders);
    return normalizeTokenList(res.data);
  }

  let lastErr = null;
  const sources = [
    ['github-api', getTokensFromApi],
    ['github-raw', () => getTokensFromRaw(rawUrl)],
    ['jsdelivr', () => getTokensFromRaw(cdnUrl)],
  ];

  try {
    let tokens = null;
    for (const [name, loader] of sources) {
      try {
        tokens = await loader();
        console.log(chalk.gray(`[LICENSE] sumber aktif: ${name}`));
        break;
      } catch (e) {
        lastErr = e;
        const status = e.response?.status;
        if (status === 404) {
          // File memang tidak ada; sumber lain tidak akan memperbaiki 404 file yang sama.
          break;
        }
      }
    }

    if (!Array.isArray(tokens)) throw lastErr || new Error('Semua endpoint lisensi gagal diakses');

    if (tokens.includes(myToken)) {
      saveCache();
      console.log(chalk.green("◉ Token bot terdaftar di GitHub. Melanjutkan..."));
      return true;
    }

    console.error(chalk.red.bold("\n⊘ Bot BATAL start: token bot ini belum terdaftar."));
    console.error(chalk.yellow(`   Token ini tidak ada di ${owner}/${repo}/${filePath}`));
    console.error(chalk.yellow("   Daftarkan token lewat Bot Add Token."));
    console.error(chalk.yellow("   Command: /addtoken <token_bot>\n"));
    return false;
  } catch (e) {
    const status = e.response?.status;
    const message = String(e.message || '');
    const transient = status === 429 || /timeout|timed out|ECONNRESET|ETIMEDOUT|ENETUNREACH|EAI_AGAIN|socket hang up|network|rate limit|too many requests/i.test(message);

    if (status === 404) {
      console.error(chalk.red.bold("\n⊘ Bot BATAL start: file token.json tidak ditemukan di GitHub."));
      console.error(chalk.yellow(`   Pastikan repo ${owner}/${repo} sudah ada dan token.json sudah dibuat.`));
      console.error(chalk.yellow("   Tambah token pertama lewat Bot Add Token.\n"));
      return false;
    }

    if (transient && cacheAllowsStart()) {
      console.log(chalk.yellow("⚠ GitHub sementara tidak dapat diakses. Lisensi terakhir yang berhasil diverifikasi masih berlaku di cache 24 jam; bot dilanjutkan."));
      return true;
    }

    console.error(chalk.red.bold("\n⊘ Bot BATAL start: gagal mengambil data lisensi dari GitHub."));
    console.error(chalk.yellow(`   Error: ${message || 'request failed'}`));
    console.error(chalk.yellow("   Endpoint dicoba: GitHub API → raw.githubusercontent.com → jsDelivr."));
    console.error(chalk.yellow("   Setelah satu verifikasi online berhasil, cache 24 jam akan melindungi startup dari gangguan jaringan."));
    console.error("");
    return false;
  }
}

// ======================= BOOT =======================

async function bootSystem() {
  // Audit seluruh source sebelum handler diaktifkan. Ini menangkap syntax error
  // dan JSON rusak yang sebelumnya baru kelihatan ketika file tersebut dipakai.
  const audit = errorAudit.startupAudit(__dirname);
  console.log(`[ERROR-AUDIT] checked=${audit.checked} errors=${audit.errors.length}`);
  if (audit.errors.length) {
    for (const item of audit.errors.slice(0, 20)) {
      console.error(`[ERROR-AUDIT] ${item.type} ${item.file}: ${item.error}`);
    }
    // Hanya throw jika ada error SYNTAX di file inti (bukan node_modules atau file lock/generated)
    const fatalErrors = audit.errors.filter(e =>
      e.type === 'JS_SYNTAX' &&
      !e.file.includes('node_modules') &&
      !e.file.endsWith('.patch')
    );
    if (fatalErrors.length > 0) {
      throw new Error(`Startup audit menemukan ${fatalErrors.length} syntax error fatal. Periksa log ERROR-AUDIT.`);
    }
    console.warn(`[ERROR-AUDIT] ${audit.errors.length} peringatan (non-fatal). Bot tetap berjalan.`);
  }
  await initializeBot();
}

// ======================= FILE WATCHER (AUTO-RESTART) =======================
// Pantau perubahan file .js di root & src/ secara rekursif.
// Kalau ada file berubah → debounce 2 detik → kirim notif ke owner →
// respawn proses baru (dengan BOT_INTERNAL_RESTART=1 via respawn.js)
// sehingga bot baru skip password otomatis & langsung jalan.
// db/ dan node_modules/ sengaja TIDAK diawasi (perubahan data bukan kode).
const { respawnAndExit } = require("./src/data/respawn");

function startFileWatcher(botInstance) {
  // Direktori & file yang diawasi
  const watchTargets = [
    path.join(__dirname, "src"),
    path.join(__dirname, "index.js"),
    path.join(__dirname, "settings.js"),
  ];

  let debounceTimer    = null;
  let lastChangedFile  = null;

  function onFileChange(filename) {
    if (!filename) return;
    // AM/TEMP-MAIL berjalan sebagai network request saja. Jangan pernah
    // memicu restart proses karena ada operasi AM yang sedang berlangsung.
    if (Number(globalThis.__YOEN_AM_MAGIC_SENDING || 0) > 0) return;
    // Hanya watch .js files, abaikan lock, log, dsb.
    if (!filename.endsWith(".js")) return;
    // Abaikan file di db/ dan node_modules/
    if (filename.includes("node_modules") || filename.includes(".bot.lock")) return;

    lastChangedFile = filename;

    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(async () => {
      const changedPath = lastChangedFile || filename;
      console.log(chalk.yellow(`\n↻ [file-watcher] Perubahan: ${changedPath} → auto-restart...`));

      // Kirim notif ke owner dulu sebelum restart
      try {
        await botInstance.sendMessage(
          settings.ownerId,
          `\uD83D\uDD04 <b>Auto-Restart Terdeteksi</b>\n\n` +
          `File diubah: <code>${changedPath}</code>\n` +
          `\u23F3 Bot sedang restart otomatis...`,
          { parse_mode: "HTML" }
        );
      } catch {}

      // Tunggu sebentar supaya pesan terkirim
      await new Promise(r => setTimeout(r, 1200));
      respawnAndExit(500);
    }, 2000); // 2s debounce — tunggu batch perubahan selesai dulu
  }

  for (const target of watchTargets) {
    try {
      if (!fs.existsSync(target)) continue;
      const isDir = fs.statSync(target).isDirectory();
      fs.watch(target, { recursive: isDir }, (event, filename) => {
        onFileChange(filename || target);
      });
    } catch (e) {
      // fs.watch recursive tidak didukung di semua OS (cth. beberapa Linux kernel lama)
      console.log(chalk.yellow(`[file-watcher] Skip ${target}: ${e.message}`));
    }
  }

  console.log(chalk.green("◉ File-watcher aktif — bot akan auto-restart saat kode berubah."));
}

// ======================= STARTUP "SUDAH TERUPDATE" NOTIF =======================
// Kalau ini adalah internal restart (file berubah / /restart command),
// kirim konfirmasi ke owner bahwa bot sudah berhasil jalan kembali.
async function sendUpdateNotifIfNeeded(botInstance) {
  if (process.env.BOT_INTERNAL_RESTART !== "1") return;
  try {
    await botInstance.sendMessage(
      settings.ownerId,
      `\u2705 <b>Sudah Terupdate!</b>\n\nBot berhasil restart dan berjalan kembali.`,
      { parse_mode: "HTML" }
    );
  } catch {}
}

setTimeout(() => {
  verifyStartPassword()
    .then(async (ok) => {
      if (!ok) {
        process.exit(1);
        return;
      }

      const licensed = await verifyGithubLicense();
      if (!licensed) {
        process.exit(1);
        return;
      }

      // password oke + lisensi valid -> baru mulai polling & load semua modul/fitur
      console.log(chalk.cyan("\n╭─ LIANIX-YUN CPANEL ─────────────────────────────────────╮"));
      console.log(chalk.white("│ ") + chalk.green.bold("✓ AUTHENTICATION OK") + chalk.gray("  Password & license verified"));
      console.log(chalk.white("│ ") + chalk.green.bold("✓ POLLING STARTED") + chalk.gray("      Telegram updates are now active"));
      console.log(chalk.white("│ ") + chalk.cyan("→ BOT STATUS") + chalk.gray("           READY / ONLINE"));
      console.log(chalk.cyan("╰──────────────────────────────────────────────────────╯\n"));
      bot.startPolling({ allowed_updates: ["message","edited_message","callback_query","my_chat_member","chat_member","chat_join_request"] });

      bootSystem().catch(err => {
        console.error("\n⟡ SYSTEM ERROR");
        console.error(err.message);
        console.error(err.stack);
        process.exit(1);
      });

      // Aktifkan file-watcher setelah bot jalan
      startFileWatcher(bot);

      // Kirim "sudah terupdate" ke owner jika ini internal restart
      setTimeout(() => sendUpdateNotifIfNeeded(bot), 3000);
    })
    .catch(err => {
      console.error("\n⟡ SYSTEM ERROR (password check)");
      console.error(err.message);
      console.error(err.stack);
      process.exit(1);
    });
}, 1000);