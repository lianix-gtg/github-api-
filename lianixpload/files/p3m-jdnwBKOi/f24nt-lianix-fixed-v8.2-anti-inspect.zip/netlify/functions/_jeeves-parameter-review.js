const { mergeInputs } = require('./_cli-parameter-parser');
const JEEVES_URL = 'https://api-faa.my.id/faa/jeeves-ai';

function extractText(data){
  if(!data)return''; if(typeof data==='string')return data;
  const keys=['result','response','answer','text','message','content','data'];
  for(const k of keys){const v=data[k];if(typeof v==='string'&&v.trim())return v;if(v&&typeof v==='object'){const x=extractText(v);if(x)return x}}
  return'';
}
function findJson(text){
  text=String(text||'').trim().replace(/^```(?:json)?\s*/i,'').replace(/\s*```$/,'');
  try{return JSON.parse(text)}catch{}
  const starts=[];for(let i=0;i<text.length;i++)if(text[i]==='{')starts.push(i);
  for(const st of starts){let depth=0,quote='',esc=false;for(let i=st;i<text.length;i++){const c=text[i];if(quote){if(esc)esc=false;else if(c==='\\')esc=true;else if(c===quote)quote='';continue}if(c==='"'||c==="'"){quote=c;continue}if(c==='{')depth++;else if(c==='}'){depth--;if(depth===0){try{return JSON.parse(text.slice(st,i+1))}catch{}break}}}}
  return null;
}
function normalizeAiInputs(items){
  if(!Array.isArray(items))return[];
  const validTypes=new Set(['text','textarea','url','number','select','file','image','audio','video','folder']);
  return items.map(p=>{
    const name=String(p?.name||'').trim();if(!name)return null;
    let type=String(p.type||'text').toLowerCase();if(!validTypes.has(type))type='text';
    const out={name,type,required:p.required===true,source:'ai'};
    if(p.default!==undefined&&p.default!==null&&p.default!=='')out.default=p.default;
    if(p.conditionalRequired)out.conditionalRequired=true;
    if(Array.isArray(p.choices))out.choices=p.choices.slice(0,30);
    if(p.placeholder)out.placeholder=String(p.placeholder).slice(0,160);
    if(p.description)out.description=String(p.description).slice(0,300);
    return out;
  }).filter(Boolean);
}
async function reviewWithJeeves({code,meta,probe,timeoutMs=9000}){
  const help=(probe?.stdout||'').slice(0,6000);
  const codeText=String(code||'');
  const excerpt=(codeText.length<=9000?codeText:codeText.slice(0,6000)+'\n/* ...dipotong... */\n'+codeText.slice(-2500));
  const prompt=`Kamu adalah analyzer parameter JavaScript untuk Lianix. Tugasmu HANYA mengoreksi metadata input API/CLI dari kode berikut. Jangan jalankan kode, jangan beri tutorial scraping. Balas JSON valid saja.\n\nAturan tipe: url=link yang diketik; image/audio/video/file/folder=upload binary; number=angka; select=pilihan; text/textarea=teks. Bedakan required, optional, dan conditionalRequired. Jika ada default maka parameter biasanya optional. Jangan mengarang parameter yang tidak didukung kode/help/comment. Untuk CLI, deteksi command, positional arg, short/long flag, default, enum.\n\nJSON schema:\n{"inputs":[{"name":"","type":"text","required":false,"conditionalRequired":false,"default":"","choices":[],"description":""}],"notes":[],"confidence":0}\n\nHasil analyzer statis saat ini:\n${JSON.stringify({inputs:meta?.inputs||[],dependencies:meta?.dependencies||[],method:meta?.method,endpoint:meta?.endpoint},null,2)}\n\nOutput safe --help probe (jika ada):\n${help||'(tidak ada)'}\n\nKode:\n${excerpt}`;
  try{
    const u=JEEVES_URL+'?prompt='+encodeURIComponent(prompt);
    const r=await fetch(u,{headers:{Accept:'application/json','User-Agent':'Lianix-AutoDetect/1.0'},signal:AbortSignal.timeout(timeoutMs)});
    if(!r.ok)return{ok:false,error:`Jeeves HTTP ${r.status}`};
    const ct=r.headers.get('content-type')||'';const raw=ct.includes('json')?await r.json():await r.text();
    const txt=extractText(raw)||String(raw||'');const parsed=findJson(txt);if(!parsed)return{ok:false,error:'Respons Jeeves tidak berisi JSON metadata yang valid.'};
    const inputs=normalizeAiInputs(parsed.inputs);return{ok:true,inputs,notes:Array.isArray(parsed.notes)?parsed.notes.slice(0,12):[],confidence:Number(parsed.confidence)||0,rawPreview:txt.slice(0,600)};
  }catch(e){return{ok:false,error:e?.name==='TimeoutError'?'Jeeves timeout':(e?.message||String(e))}}
}
function mergeJeeves(staticInputs,aiInputs){
  // Static/comment/CLI evidence wins for required/default/type. AI fills gaps and adds only plausible missing inputs.
  return mergeInputs(aiInputs||[],staticInputs||[]);
}
module.exports={reviewWithJeeves,mergeJeeves};
