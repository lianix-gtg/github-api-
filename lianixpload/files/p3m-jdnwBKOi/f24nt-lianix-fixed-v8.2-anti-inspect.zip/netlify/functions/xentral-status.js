// netlify/functions/xentral-status.js
// POST /api/payment/status
// Body: { order_id: string }
// Mengecek status pembayaran ke XentralPay. Kalau sudah lunas (paid/success/settled/completed):
//  - Upgrade plan user (disimpan di Netlify Blobs, keyed by deviceId) sesuai plan yang dipilih saat checkout
//  - Kirim notifikasi Telegram ke admin (sekali saja per order, ditandai lewat field "notified")

const { getTransaction, saveTransaction, setUserPlan, connectBlobs } = require('./_store');
const { sendTelegramNotify } = require("./_telegram");

const XENTRAL_BASE = "https://api.xentralpay.com/v1";
const PAID_STATUSES = ["paid", "success", "settled", "completed"];
const FAILED_STATUSES = ["expire", "expired", "cancel", "cancelled", "canceled"];

exports.handler = async (event) => {
  connectBlobs(event);
  const CORS = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type"
  };

  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers: CORS, body: "" };
  }
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, headers: CORS, body: JSON.stringify({ success: false, error: "Method not allowed" }) };
  }

  const apiKey = process.env.XENTRAL_API_KEY;
  if (!apiKey) {
    return {
      statusCode: 500,
      headers: CORS,
      body: JSON.stringify({ success: false, error: "XENTRAL_API_KEY belum dikonfigurasi di environment variable Netlify." })
    };
  }

  let payload;
  try {
    payload = JSON.parse(event.body || "{}");
  } catch (e) {
    return { statusCode: 400, headers: CORS, body: JSON.stringify({ success: false, error: "Body request bukan JSON yang valid." }) };
  }

  const { order_id } = payload;
  if (!order_id) {
    return { statusCode: 400, headers: CORS, body: JSON.stringify({ success: false, error: "Field 'order_id' wajib diisi." }) };
  }

  const localTx = await getTransaction(order_id);
  if (!localTx) {
    return { statusCode: 404, headers: CORS, body: JSON.stringify({ success: false, error: "Transaksi tidak ditemukan." }) };
  }

  try {
    const res = await fetch(`${XENTRAL_BASE}/qris/status`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
      body: JSON.stringify({ order_id }),
      signal: AbortSignal.timeout(15000)
    });

    const raw = await res.text();
    let data;
    try {
      data = JSON.parse(raw);
    } catch (e) {
      return { statusCode: 502, headers: CORS, body: JSON.stringify({ success: false, error: "Response dari XentralPay bukan JSON yang valid." }) };
    }

    if (res.status === 400) {
      return { statusCode: 400, headers: CORS, body: JSON.stringify({ success: false, error: data.message || "Bad request ke XentralPay (HTTP 400)." }) };
    }
    if (res.status === 401) {
      return { statusCode: 401, headers: CORS, body: JSON.stringify({ success: false, error: "API key XentralPay tidak valid (HTTP 401)." }) };
    }
    if (res.status >= 500) {
      return { statusCode: 502, headers: CORS, body: JSON.stringify({ success: false, error: "Server XentralPay bermasalah (HTTP " + res.status + ")." }) };
    }
    if (!res.ok || !data.success || !data.data) {
      return { statusCode: 502, headers: CORS, body: JSON.stringify({ success: false, error: data.message || "Gagal mengecek status di XentralPay." }) };
    }

    const remoteStatus = String(data.data.status || "").toLowerCase();
    const isPaid = PAID_STATUSES.includes(remoteStatus);
    const isFailed = FAILED_STATUSES.includes(remoteStatus);

    // Update status lokal
    localTx.status = remoteStatus;

    if (isPaid && !localTx.upgraded) {
      // Upgrade plan user
      const expiresAt = Date.now() + (Number(localTx.days) || 30) * 86400000;
      await setUserPlan(localTx.deviceId, {
        plan: localTx.plan,
        activatedAt: Date.now(),
        expiresAt,
        lastOrderId: order_id
      });
      localTx.upgraded = true;
    }

    if (isPaid && !localTx.notified) {
      const planLabel = localTx.plan === "gokil" ? "Gokil Plan" : "Abyz Plan";
      await sendTelegramNotify(
        `✅ <b>Pembayaran Diterima</b>\n\n` +
        `Order ID: <code>${order_id}</code>\n` +
        `Plan: ${planLabel}\n` +
        `Jumlah: Rp ${Number(localTx.amount).toLocaleString("id-ID")}\n` +
        `Durasi: ${localTx.days} hari\n` +
        `Status: ${remoteStatus}\n\n` +
        `Plan user sudah otomatis diupgrade oleh sistem.`
      );
      localTx.notified = true;
    }

    await saveTransaction(order_id, localTx);

    return {
      statusCode: 200,
      headers: CORS,
      body: JSON.stringify({
        success: true,
        data: {
          order_id,
          amount: localTx.amount,
          status: remoteStatus,
          paid: isPaid,
          failed: isFailed,
          plan: localTx.plan
        }
      })
    };
  } catch (err) {
    if (err.name === "TimeoutError" || err.name === "AbortError") {
      return { statusCode: 504, headers: CORS, body: JSON.stringify({ success: false, error: "Request ke XentralPay timeout. Coba lagi." }) };
    }
    return { statusCode: 500, headers: CORS, body: JSON.stringify({ success: false, error: "Error tak terduga: " + err.message }) };
  }
};
