const { OWNER, REPO, BRANCH, loadRegistry, categoryFolders, getJson, getRaw } = require('./_github');

const DEADLINE_MS = 13000;
const GH_TIMEOUT_MS = 5000;
const CONCURRENCY = 10;

async function mapLimit(items, limit, worker, deadline) {
  const results = new Array(items.length); let next = 0;
  async function runner() {
    while (true) {
      const i = next++; if (i >= items.length) return;
      if (Date.now() > deadline - 700) { results[i] = { skipped: true }; continue; }
      try { results[i] = await worker(items[i], i); }
      catch (error) { results[i] = { error }; }
    }
  }
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, runner));
  return results;
}

exports.handler = async function () {
  const started = Date.now(), deadline = started + DEADLINE_MS;
  try {
    const registry = await loadRegistry(GH_TIMEOUT_MS);
    if (!Array.isArray(registry.categories)) throw new Error('registry.json wajib punya categories[]');
    const categories = registry.categories.filter(c => c && c.enabled !== false);
    const folderJobs = [];
    for (const category of categories) for (const folder of categoryFolders(category)) folderJobs.push({ category, folder });

    const listed = await mapLimit(folderJobs, 6, async job => {
      const list = await getJson(job.folder, GH_TIMEOUT_MS);
      return { ...job, list: Array.isArray(list) ? list : [] };
    }, deadline);

    const warnings = [], filesToLoad = [], groupsById = new Map(categories.map(c => [c.id, { category:c, files:[], errors:[] }]));
    let successfulFolders = 0;
    listed.forEach((r, i) => {
      const job = folderJobs[i], group = groupsById.get(job.category.id);
      if (r?.error) {
        const declared = [ ...(Array.isArray(job.category?.folders)?job.category.folders:[]), job.category?.folder ].filter(Boolean);
        const optionalAlias = job.folder === 'canvasweb' && !declared.includes('canvasweb');
        if (optionalAlias && r.error.status === 404) return;
        const msg = `/${job.folder}: ${r.error.message || String(r.error)}`;
        group.errors.push(msg); warnings.push(msg); return;
      }
      if (r?.skipped) { const msg=`/${job.folder}: dilewati karena batas waktu sync`; group.errors.push(msg); warnings.push(msg); return; }
      successfulFolders++;
      for (const f of (r?.list || []).filter(x => x && x.type === 'file' && /\.js$/i.test(x.name))) filesToLoad.push({ category:job.category, folder:job.folder, name:f.name });
    });
    if (folderJobs.length && successfulFolders === 0) throw new Error(warnings[0] || 'Semua folder GitHub gagal dibaca.');

    const loaded = await mapLimit(filesToLoad, CONCURRENCY, async f => ({ ...f, raw:await getRaw(`${f.folder}/${f.name}`, GH_TIMEOUT_MS) }), deadline);
    loaded.forEach((r, i) => {
      const src = filesToLoad[i], group = groupsById.get(src.category.id);
      if (r?.error) { const msg=`/${src.folder}/${src.name}: ${r.error.message || String(r.error)}`; group.errors.push(msg); warnings.push(msg); return; }
      if (r?.skipped) { const msg=`/${src.folder}/${src.name}: dilewati karena batas waktu sync`; group.errors.push(msg); warnings.push(msg); return; }
      group.files.push({ name:r.name, folder:r.folder, raw:r.raw });
    });

    const groups = [...groupsById.values()];
    return {
      statusCode: 200,
      headers: { 'Content-Type':'application/json; charset=utf-8', 'Cache-Control':'no-store, no-cache, must-revalidate' },
      body: JSON.stringify({
        ok:true,
        partial:warnings.length>0,
        warnings:warnings.slice(0,50),
        durationMs:Date.now()-started,
        repository:{owner:OWNER,repo:REPO,branch:BRANCH},
        registry:{version:registry.version||1,settings:registry.settings||{}},
        groups
      })
    };
  } catch (error) {
    console.error('[github-registry]', error);
    return { statusCode:502, headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'}, body:JSON.stringify({ok:false,error:error.message||String(error),durationMs:Date.now()-started}) };
  }
};
