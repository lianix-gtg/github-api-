// netlify/functions/user-plan.js
// GET /api/user/plan?deviceId=xxxx
// Mengembalikan status plan user (abyz/gokil) yang tersimpan di server, berikut kedaluwarsanya.
// Dipakai client untuk sinkronisasi status plan tanpa bergantung pada localStorage saja.

const { getUserPlan, connectBlobs } = require('./_store');

exports.handler = async (event) => {
  connectBlobs(event);
  const CORS = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type"
  };

  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers: CORS, body: "" };
  }
  if (event.httpMethod !== "GET") {
    return { statusCode: 405, headers: CORS, body: JSON.stringify({ success: false, error: "Method not allowed" }) };
  }

  const deviceId = event.queryStringParameters?.deviceId;
  if (!deviceId) {
    return { statusCode: 400, headers: CORS, body: JSON.stringify({ success: false, error: "Query param 'deviceId' wajib diisi." }) };
  }

  try {
    const planData = await getUserPlan(deviceId);
    if (!planData) {
      return { statusCode: 200, headers: CORS, body: JSON.stringify({ success: true, data: { plan: null, active: false } }) };
    }

    const active = planData.expiresAt && planData.expiresAt > Date.now();
    return {
      statusCode: 200,
      headers: CORS,
      body: JSON.stringify({
        success: true,
        data: {
          plan: active ? planData.plan : null,
          active,
          expiresAt: planData.expiresAt || null
        }
      })
    };
  } catch (err) {
    return { statusCode: 500, headers: CORS, body: JSON.stringify({ success: false, error: "Error tak terduga: " + err.message }) };
  }
};
