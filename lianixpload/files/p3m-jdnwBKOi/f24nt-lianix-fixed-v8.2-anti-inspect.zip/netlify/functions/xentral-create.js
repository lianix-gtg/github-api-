// netlify/functions/xentral-create.js
// POST /api/payment/create
// Body: { amount: number, plan: "abyz"|"gokil", days: number, deviceId: string }
// Membuat transaksi QRIS baru lewat XentralPay dan menyimpan detailnya di Netlify Blobs
// agar bisa dicek/di-poll statusnya nanti oleh client dan diselesaikan otomatis.

const { saveTransaction, connectBlobs } = require('./_store');

const XENTRAL_BASE = "https://api.xentralpay.com/v1";

const HEADERS_JSON = { "Content-Type": "application/json" };

function genOrderId() {
  const rand = Math.random().toString(36).slice(2, 8).toUpperCase();
  return `CP-${Date.now()}${rand}`;
}

exports.handler = async (event) => {
  connectBlobs(event);
  const CORS = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type"
  };

  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers: CORS, body: "" };
  }

  if (event.httpMethod !== "POST") {
    return { statusCode: 405, headers: CORS, body: JSON.stringify({ success: false, error: "Method not allowed" }) };
  }

  const apiKey = process.env.XENTRAL_API_KEY;
  if (!apiKey) {
    return {
      statusCode: 500,
      headers: CORS,
      body: JSON.stringify({ success: false, error: "XENTRAL_API_KEY belum dikonfigurasi di environment variable Netlify." })
    };
  }

  let payload;
  try {
    payload = JSON.parse(event.body || "{}");
  } catch (e) {
    return { statusCode: 400, headers: CORS, body: JSON.stringify({ success: false, error: "Body request bukan JSON yang valid." }) };
  }

  const { amount, plan, days, deviceId } = payload;

  if (!amount || typeof amount !== "number" || amount <= 0) {
    return { statusCode: 400, headers: CORS, body: JSON.stringify({ success: false, error: "Field 'amount' wajib diisi dan harus berupa angka positif." }) };
  }
  if (!plan || !["abyz", "gokil"].includes(String(plan).toLowerCase())) {
    return { statusCode: 400, headers: CORS, body: JSON.stringify({ success: false, error: "Field 'plan' wajib diisi, salah satu dari: abyz, gokil." }) };
  }
  if (!deviceId || typeof deviceId !== "string") {
    return { statusCode: 400, headers: CORS, body: JSON.stringify({ success: false, error: "Field 'deviceId' wajib diisi." }) };
  }

  const orderId = genOrderId();

  try {
    const res = await fetch(`${XENTRAL_BASE}/qris/generate`, {
      method: "POST",
      headers: { ...HEADERS_JSON, Authorization: `Bearer ${apiKey}` },
      body: JSON.stringify({ amount, order_id: orderId }),
      signal: AbortSignal.timeout(20000)
    });

    const raw = await res.text();
    let data;
    try {
      data = JSON.parse(raw);
    } catch (e) {
      return {
        statusCode: 502,
        headers: CORS,
        body: JSON.stringify({ success: false, error: "Response dari XentralPay bukan JSON yang valid.", raw: raw.slice(0, 300) })
      };
    }

    if (res.status === 400) {
      return { statusCode: 400, headers: CORS, body: JSON.stringify({ success: false, error: data.message || data.error || "Bad request ke XentralPay (HTTP 400)." }) };
    }
    if (res.status === 401) {
      return { statusCode: 401, headers: CORS, body: JSON.stringify({ success: false, error: "API key XentralPay tidak valid atau ditolak (HTTP 401)." }) };
    }
    if (res.status >= 500) {
      return { statusCode: 502, headers: CORS, body: JSON.stringify({ success: false, error: "Server XentralPay bermasalah (HTTP " + res.status + ")." }) };
    }
    if (!res.ok || !data.success || !data.data) {
      return { statusCode: 502, headers: CORS, body: JSON.stringify({ success: false, error: data.message || data.error || "Gagal membuat QRIS di XentralPay." }) };
    }

    const d = data.data;

    // Simpan transaksi supaya bisa dicek statusnya nanti
    await saveTransaction(orderId, {
      order_id: d.order_id || orderId,
      amount,
      plan: String(plan).toLowerCase(),
      days: Number(days) || 30,
      deviceId,
      status: d.status || "pending",
      qr_image_url: d.qr_image_url,
      checkout_url: d.checkout_url,
      expires_at: d.expires_at,
      created_at: new Date().toISOString(),
      notified: false
    });

    return {
      statusCode: 200,
      headers: CORS,
      body: JSON.stringify({
        success: true,
        data: {
          order_id: d.order_id || orderId,
          amount,
          status: d.status || "pending",
          qr_image_url: d.qr_image_url,
          checkout_url: d.checkout_url,
          expires_at: d.expires_at
        }
      })
    };
  } catch (err) {
    if (err.name === "TimeoutError" || err.name === "AbortError") {
      return { statusCode: 504, headers: CORS, body: JSON.stringify({ success: false, error: "Request ke XentralPay timeout. Coba lagi." }) };
    }
    return { statusCode: 500, headers: CORS, body: JSON.stringify({ success: false, error: "Error tak terduga: " + err.message }) };
  }
};
