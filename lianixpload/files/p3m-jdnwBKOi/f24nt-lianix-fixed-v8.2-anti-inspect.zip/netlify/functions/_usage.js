const crypto = require('crypto');
const { makeStore, connectBlobs } = require('./_store');
function apiIdFromName(name){return String(name||'unknown').replace(/\.js$/i,'').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'')||'unknown'}
async function recordUsage({apiId,name,path,ok,status,latency,userUid}){
  try{
    const now=new Date(),day=now.toISOString().slice(0,10),id=apiIdFromName(apiId);
    const ev={apiId:id,name:String(name||apiId||'').slice(0,100),path:String(path||'').slice(0,180),ok:ok===true,status:Number(status)||0,latency:Math.max(0,Math.min(Number(latency)||0,120000)),userUid:userUid?String(userUid).slice(0,160):null,at:Date.now()};
    // Key carries aggregate fields so stats can be calculated from list() alone.
    const key=`${day}/${id}/${ev.ok?1:0}/${ev.status}/${ev.latency}/${ev.at}-${crypto.randomBytes(5).toString('hex')}`;
    await makeStore('f24nt-api-usage').setJSON(key,ev);
    return true;
  }catch(e){console.warn('[usage] skipped:',e.message);return false}
}
function wrapHandler(handler,meta={}){
  return async function(event,context){
    connectBlobs(event);
    const headers=event?.headers||{};
    const skip=headers['x-lianix-health-check']==='1'||headers['x-lianix-test']==='1';
    const started=Date.now();let result;let thrown;
    try{result=await handler(event,context);return result}
    catch(e){thrown=e;throw e}
    finally{
      if(!skip){const st=Number(result?.statusCode)||(thrown?500:0);await recordUsage({apiId:meta.apiId,name:meta.name||meta.apiId,path:event?.path||meta.path||'',ok:!thrown&&st>=200&&st<400,status:st,latency:Date.now()-started,userUid:event?.lianixApiUser?.uid||null})}
    }
  }
}
module.exports={recordUsage,wrapHandler,apiIdFromName};
