const { verifyAdminToken } = require('./_admin-auth');
const { analyzeCode } = require('./_api-meta');
const { safeProbe } = require('./_safe-script-probe');
const { parseCliText, mergeInputs } = require('./_cli-parameter-parser');
const { reviewWithJeeves, mergeJeeves } = require('./_jeeves-parameter-review');

const CORS = { 'Content-Type':'application/json', 'Access-Control-Allow-Origin':'*', 'Access-Control-Allow-Methods':'POST,OPTIONS', 'Access-Control-Allow-Headers':'Content-Type, Authorization' };
const out = (statusCode, body) => ({ statusCode, headers:CORS, body:JSON.stringify(body) });
exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return { statusCode:204, headers:CORS, body:'' };
  if (event.httpMethod !== 'POST') return out(405,{success:false,error:'Method not allowed'});
  if (!await verifyAdminToken(event)) return out(401,{success:false,error:'Tidak terautentikasi.'});
  try {
    const p = JSON.parse(event.body || '{}');
    if (!p.code || typeof p.code !== 'string') return out(400,{success:false,error:'Kode JS wajib diisi.'});
    const trace=[];
    let meta = analyzeCode(p.code,{filename:p.filename||'api.js',category:p.category||'tools',name:p.name,description:p.description,endpoint:p.endpoint});
    trace.push({stage:'AST + metadata + komentar',ok:true,parameters:meta.inputs.length});

    // Safe probe: executes with no real require/network/fetch/secret env and a hard VM timeout.
    const probe=safeProbe(p.code,{filename:p.filename||'api.js'});
    const probeInputs=parseCliText(probe.stdout||'');
    if(probeInputs.length){meta.inputs=mergeInputs(meta.inputs,probeInputs);meta.confidence=Math.min(99,Math.max(meta.confidence||0,86));}
    trace.push({stage:'Safe CLI --help probe',ok:probe.ok,parameters:probeInputs.length,preview:(probe.stdout||probe.stderr||'').slice(0,500)});

    let aiReview={ok:false,error:'Jeeves AI dinonaktifkan.'};
    if(p.useJeeves!==false){
      aiReview=await reviewWithJeeves({code:p.code,meta,probe});
      if(aiReview.ok){
        meta.inputs=mergeJeeves(meta.inputs,aiReview.inputs);
        meta.confidence=Math.min(99,Math.max(meta.confidence||0,Number(aiReview.confidence)||88));
      }
      trace.push({stage:'Jeeves AI review',ok:aiReview.ok,parameters:aiReview.inputs?.length||0,error:aiReview.error||'',notes:aiReview.notes||[]});
    }
    meta.analysis={probe:{attempted:probe.attempted,ok:probe.ok,mode:probe.mode,stdout:(probe.stdout||'').slice(0,1200),stderr:(probe.stderr||'').slice(0,700)},jeeves:{ok:aiReview.ok,error:aiReview.error||'',notes:aiReview.notes||[],confidence:aiReview.confidence||0},trace};
    const warnings=[];
    if(meta.confidence < 80) warnings.push('Confidence auto-detect belum tinggi. Cek parameter sebelum publish.');
    if(!probe.ok) warnings.push('Safe Probe tidak selesai penuh; analyzer tetap memakai AST/comment/help statis.');
    if(p.useJeeves!==false&&!aiReview.ok) warnings.push('Jeeves AI tidak tersedia; hasil fallback analyzer statis tetap dipakai.');
    return out(200,{success:true,data:meta,warnings});
  } catch (e) { return out(400,{success:false,error:e.message}); }
};
