// Public download route for LianixPload: /f/:id
// Keeps the short Lianix URL and serves bytes from GitHub using server-side credentials.
const { OWNER, REPO, BRANCH, request } = require('./_github');
const { getUpload } = require('./_pload-db');

const BASE_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'X-Content-Type-Options': 'nosniff'
};
function text(statusCode, message) {
  return { statusCode, headers: { ...BASE_HEADERS, 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' }, body: message };
}
function safeDisposition(name, inline = false) {
  const fallback = String(name || 'file').replace(/[^\x20-\x7E]|["\\\r\n]/g, '_');
  return `${inline ? 'inline' : 'attachment'}; filename="${fallback}"; filename*=UTF-8''${encodeURIComponent(String(name || 'file'))}`;
}
function deliveryType(mime = '') {
  const m = String(mime).toLowerCase().split(';')[0].trim();
  const safeInline = /^(image\/(?:png|jpeg|gif|webp|avif)|audio\/|video\/|application\/pdf$)/.test(m);
  const active = /^(text\/html|image\/svg\+xml|application\/(?:javascript|x-javascript|xml|xhtml\+xml))$/.test(m);
  return { mime: active ? 'application/octet-stream' : (m || 'application/octet-stream'), inline: safeInline && !active };
}
exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return { statusCode: 204, headers: { ...BASE_HEADERS, 'Access-Control-Allow-Methods': 'GET,HEAD,OPTIONS' }, body: '' };
  if (!['GET','HEAD'].includes(event.httpMethod)) return text(405, 'Method not allowed');
  try {
    const splat = event.pathParameters?.splat || event.pathParameters?.id || String(event.path || '').split('/').filter(Boolean).pop() || '';
    const id = String(splat).trim();
    if (!/^[A-Za-z0-9_-]{8,32}$/.test(id)) return text(404, 'File tidak ditemukan.');
    const meta = await getUpload(event, id);
    if (!meta) return text(404, 'File tidak ditemukan.');
    if (!meta?.path || !meta?.filename) return text(500, 'Metadata file rusak.');

    const rawUrl = `https://api.github.com/repos/${encodeURIComponent(OWNER)}/${encodeURIComponent(REPO)}/contents/${String(meta.path).split('/').map(encodeURIComponent).join('/')}?ref=${encodeURIComponent(BRANCH)}`;
    const res = await request(rawUrl, { headers: { Accept: 'application/vnd.github.raw+json' } }, 15000);
    if (!res.ok) return text(res.status === 404 ? 404 : 502, res.status === 404 ? 'File tidak ditemukan.' : `Storage error ${res.status}`);
    const delivery = deliveryType(meta.mime || res.headers.get('content-type') || 'application/octet-stream');
    const headers = {
      ...BASE_HEADERS,
      'Content-Type': delivery.mime,
      'Content-Disposition': safeDisposition(meta.filename, delivery.inline),
      'Content-Security-Policy': "default-src 'none'; sandbox",
      'Cache-Control': 'public, max-age=31536000, immutable',
      'ETag': meta.sha ? `"${meta.sha}"` : undefined
    };
    for (const k of Object.keys(headers)) if (headers[k] == null) delete headers[k];
    if (event.httpMethod === 'HEAD') return { statusCode: 200, headers: { ...headers, 'Content-Length': String(meta.size || 0) }, body: '' };
    const buf = Buffer.from(await res.arrayBuffer());
    return { statusCode: 200, headers: { ...headers, 'Content-Length': String(buf.length) }, isBase64Encoded: true, body: buf.toString('base64') };
  } catch (error) {
    console.error('[lianixpload-file]', error);
    return text(502, 'File sementara tidak dapat diambil.');
  }
};
