(function () {
  'use strict';
  if (window.__lianixSecurityGuard) return;
  window.__lianixSecurityGuard = true;

  var locked = false;
  var threshold = 180;

  function blackout(reason) {
    if (locked) return;
    locked = true;
    try {
      document.documentElement.setAttribute('data-lianix-locked', '1');
      document.documentElement.style.background = '#000';
      document.documentElement.style.colorScheme = 'dark';
      if (document.body) {
        document.body.innerHTML = '';
        document.body.style.cssText = 'margin:0!important;background:#000!important;overflow:hidden!important;display:block!important;min-height:100vh!important;';
      }
      var cover = document.createElement('div');
      cover.id = 'lianix-security-blackout';
      cover.setAttribute('aria-hidden', 'true');
      cover.style.cssText = 'position:fixed;inset:0;z-index:2147483647;background:#000!important;color:#000!important;pointer-events:auto;user-select:none;';
      (document.body || document.documentElement).appendChild(cover);
      try { sessionStorage.setItem('__lianix_guard_lock', String(Date.now())); } catch (_) {}
      try { console.clear(); } catch (_) {}
    } catch (_) {}
  }

  function isDesktopLike() {
    try {
      return Math.max(screen.width || 0, window.innerWidth || 0) >= 700 && !('ontouchstart' in window && window.innerWidth < 700);
    } catch (_) { return true; }
  }

  function checkDockedDevtools() {
    if (locked || !isDesktopLike()) return;
    try {
      var widthGap = Math.abs((window.outerWidth || 0) - (window.innerWidth || 0));
      var heightGap = Math.abs((window.outerHeight || 0) - (window.innerHeight || 0));
      if (widthGap > threshold || heightGap > threshold) blackout('devtools-docked');
    } catch (_) {}
  }

  function keyBlocked(e) {
    var key = String(e.key || '').toLowerCase();
    var code = e.keyCode || e.which;
    if (code === 123 || key === 'f12') return true;
    if (e.ctrlKey && e.shiftKey && (key === 'i' || key === 'j' || key === 'c' || key === 'k')) return true;
    if (e.metaKey && e.altKey && (key === 'i' || key === 'j' || key === 'c')) return true;
    if (e.ctrlKey && key === 'u') return true;
    return false;
  }

  document.addEventListener('keydown', function (e) {
    if (!keyBlocked(e)) return;
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    blackout('shortcut');
  }, true);

  document.addEventListener('contextmenu', function (e) {
    e.preventDefault();
    e.stopPropagation();
  }, true);

  window.addEventListener('resize', checkDockedDevtools, { passive: true });
  window.addEventListener('focus', checkDockedDevtools, { passive: true });
  setInterval(checkDockedDevtools, 1200);
  setTimeout(checkDockedDevtools, 700);
})();
