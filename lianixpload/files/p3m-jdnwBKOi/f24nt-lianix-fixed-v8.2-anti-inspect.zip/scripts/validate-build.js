const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const fail = msg => { console.error('[BUILD VALIDATION] FAIL:', msg); process.exitCode = 1; };
const read = p => fs.readFileSync(path.join(root,p),'utf8');
const exists = p => fs.existsSync(path.join(root,p));

const required = ['index.html','tools.html','upload.html','admin.html','docs.html','plan.html','recents.html','artifacts.html','404.html','_redirects','netlify.toml','src/settings.json','package.json'];
for (const f of required) if (!exists(f)) fail(`missing ${f}`);

try { JSON.parse(read('src/settings.json')); } catch (e) { fail(`src/settings.json invalid JSON: ${e.message}`); }
try { JSON.parse(read('package.json')); } catch (e) { fail(`package.json invalid JSON: ${e.message}`); }

// Every static redirect to a function must have a source file.
const redirects = read('_redirects');
for (const m of redirects.matchAll(/\/\.netlify\/functions\/([A-Za-z0-9_-]+)/g)) {
  const name = m[1];
  if (!exists(`netlify/functions/${name}.js`)) fail(`redirect target function missing: ${name}.js`);
}

// Every built-in /api path in settings must be routed.
try {
  const settings = JSON.parse(read('src/settings.json'));
  const toml = read('netlify.toml');
  for (const cat of settings.categories || []) for (const item of cat.items || []) {
    const ep = String(item.path || '');
    if (ep.startsWith('/api/') && !redirects.includes(ep) && !toml.includes(`from = "${ep}"`)) fail(`unrouted settings endpoint: ${ep}`);
  }
} catch {}

// Duplicate DOM ids are a common source of silent UI bugs.
for (const file of fs.readdirSync(root).filter(x => x.endsWith('.html'))) {
  const html = read(file); const seen = new Set();
  for (const m of html.matchAll(/\sid=["']([^"']+)["']/g)) {
    if (seen.has(m[1])) fail(`${file}: duplicate id ${m[1]}`); else seen.add(m[1]);
  }
}

// Keep secrets out of client/source bundle.
for (const file of fs.readdirSync(root).filter(x => /\.(html|js|json|toml)$/.test(x))) {
  const text = read(file);
  if (/github_pat_[A-Za-z0-9_]+|ghp_[A-Za-z0-9]+/.test(text)) fail(`${file}: hardcoded GitHub token detected`);
}

// /app is intentionally preserved from the user's reference build. Only verify routing here.
try {
  const rd = read('_redirects');
  const catchAll = rd.indexOf('/*                /404.html');
  for (const route of ['/app              /index.html','/app/*            /index.html','/api/hackai']) {
    const at = rd.indexOf(route); if (at < 0) fail(`_redirects: missing ${route}`); else if (catchAll >= 0 && at > catchAll) fail(`_redirects: ${route} appears after catch-all 404`);
  }
} catch (e) { fail(`app route validation failed: ${e.message}`); }

// AI proxy must be present before catch-all so /app model calls never fall into static 404.
try {
  if (!exists('netlify/functions/ai-proxy.js')) fail('AI proxy function missing');
  const rd = read('_redirects');
  const aiAt = rd.indexOf('/api/ai/*');
  const catchAll = rd.indexOf('/*                /404.html');
  if (aiAt < 0) fail('_redirects: /api/ai/* route missing');
  else if (catchAll >= 0 && aiAt > catchAll) fail('_redirects: /api/ai/* appears after catch-all 404');
  if (!read('netlify.toml').includes('from = "/api/ai/*"')) fail('netlify.toml: /api/ai/* redirect missing');
} catch (e) { fail(`AI proxy validation failed: ${e.message}`); }

// Lambda-compatible Netlify Blobs functions must initialize the Blobs context.
try {
  const store = read('netlify/functions/_store.js');
  if (!store.includes('connectLambda')) fail('_store.js: connectLambda missing');
  if (!store.includes('getStore(name)')) fail('_store.js: environment/context getStore(name) missing');
} catch (e) { fail(`Blobs validation failed: ${e.message}`); }

// Local file references in HTML must exist. Dynamic/application routes are ignored.
for (const file of fs.readdirSync(root).filter(x => x.endsWith('.html'))) {
  const html = read(file);
  for (const m of html.matchAll(/(?:src|href)=["']([^"']+)["']/gi)) {
    const ref = m[1];
    if (!ref || /^(?:https?:|data:|#|mailto:|javascript:)/i.test(ref) || ref.includes('${')) continue;
    const clean = ref.split(/[?#]/)[0];
    if (!clean || !path.extname(clean)) continue;
    const target = clean.startsWith('/') ? path.join(root, clean.slice(1)) : path.resolve(root, clean);
    if (!fs.existsSync(target)) fail(`${file}: missing local asset ${ref}`);
  }
}


// Shared public API key invariants.
try {
  const tools = read('tools.html');
  const protectedFns = ['lianixpload','pinvideo','winkv2','winkvid','upscalevid','removewm','audio2txt','uploader','allindownloader','web2apk','rmvbg','fakegc','fakecall','api-metrics'];
  if (!exists('netlify/functions/_user-api-key.js')) fail('shared API key helper missing');
  if (!read('netlify/functions/_user-api-key.js').includes("PUBLIC_API_KEY = 'lianix'")) fail('shared public API key is not lianix');
  if (!tools.includes("currentPublicApiKey = 'lianix'")) fail('tools.html does not auto-fill shared lianix key');
  if (!tools.includes("'X-API-Key': currentPublicApiKey")) fail('tools.html: TRY API does not attach X-API-Key');
  for (const name of protectedFns) if (!read(`netlify/functions/${name}.js`).includes('withPublicApiKey')) fail(`${name}.js: public API key guard missing`);
} catch (e) { fail(`API key validation failed: ${e.message}`); }

// GitHub live-sync invariants: add/edit/delete in Admin or GitHub must refresh Tools.
try {
  const tools = read('tools.html');
  const admin = read('admin.html');
  const rd = read('_redirects');
  const toml = read('netlify.toml');
  if (!exists('netlify/functions/github-state.js')) fail('github-state watcher function missing');
  if (!rd.includes('/api/github-state')) fail('_redirects: /api/github-state missing');
  if (!toml.includes('from = "/api/github-state"')) fail('netlify.toml: /api/github-state missing');
  if (!tools.includes("fetchWithTimeout('/api/github-state")) fail('tools.html: GitHub commit watcher missing');
  if (!tools.includes("setInterval(() => checkGithubRevision(false), 10000)")) fail('tools.html: GitHub watcher interval missing');
  if (!tools.includes("GH_SYNC_SIGNAL = 'lianix_github_sync_signal_v2'")) fail('tools.html: cross-tab GitHub sync signal missing');
  if (!admin.includes("localStorage.setItem('lianix_github_sync_signal_v2'")) fail('admin.html: repository-change signal missing');
  if (!admin.includes('signalGithubChanged();await loadGithub')) fail('admin.html: GitHub mutations do not invalidate web');
} catch (e) { fail(`GitHub live-sync validation failed: ${e.message}`); }


// LianixPload invariants.
try {
  if (!exists('netlify/functions/lianixpload.js')) fail('LianixPload upload function missing');
  if (!exists('netlify/functions/lianixpload-file.js')) fail('LianixPload file function missing');
  if (!exists('netlify/functions/lianixpload-info.js')) fail('LianixPload info function missing');
  if (!exists('netlify/functions/_pload-db.js')) fail('LianixPload database helper missing');
  const rd = read('_redirects');
  const toml = read('netlify.toml');
  if (!rd.includes('/api/lianixpload')) fail('_redirects: /api/lianixpload missing');
  if (!rd.includes('/api/lianixpload/info')) fail('_redirects: /api/lianixpload/info missing');
  if (!rd.includes('/f/*')) fail('_redirects: /f/* missing');
  if (!rd.includes('/upload')) fail('_redirects: /upload missing');
  if (!toml.includes('from = "/api/lianixpload"')) fail('netlify.toml: /api/lianixpload missing');
  if (!toml.includes('from = "/api/lianixpload/info"')) fail('netlify.toml: /api/lianixpload/info missing');
  if (!toml.includes('from = "/f/*"')) fail('netlify.toml: /f/* missing');
  if (!toml.includes('from = "/upload"')) fail('netlify.toml: /upload missing');
  const uploadPage = read('upload.html');
  if (!uploadPage.includes("'/api/lianixpload'")) fail('upload.html: uploader endpoint missing');
  if (!uploadPage.includes("'/api/lianixpload/info?id='")) fail('upload.html: database history verification missing');
  if (!read('tools.html').includes('href="/upload"')) fail('tools.html: Upload sidebar button missing');
  const db = read('netlify/functions/_pload-db.js');
  if (!db.includes("makeStore('lianixpload-db')") && !db.includes('STORE_NAME')) fail('_pload-db.js: persistent metadata store missing');
  if (!read('netlify/functions/lianixpload.js').includes('saveUpload(event, meta)')) fail('lianixpload.js: database save missing');
  if (!read('netlify/functions/lianixpload-file.js').includes('getUpload(event, id)')) fail('lianixpload-file.js: database lookup missing');
  const settings = JSON.parse(read('src/settings.json'));
  const all = (settings.categories || []).flatMap(c => c.items || []);
  if (!all.some(x => x.path === '/api/lianixpload')) fail('settings: LianixPload missing');
} catch (e) { fail(`LianixPload validation failed: ${e.message}`); }

if (!process.exitCode) console.log('[BUILD VALIDATION] PASS');
