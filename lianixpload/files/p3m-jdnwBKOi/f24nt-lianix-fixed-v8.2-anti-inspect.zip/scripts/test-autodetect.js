const assert = require('node:assert');
const { analyzeCode } = require('../netlify/functions/_api-meta');

const cli = `
const axios = require(${JSON.stringify('axios')});
console.log(\`NFTOKEN scraper Node.js
Perintah:
 node nfscraper.js test [opsi]
 node nfscraper.js stats [opsi]
 node nfscraper.js auto -n <jumlah> [opsi]
 node nfscraper.js convert '<cookie>' [opsi]
 node nfscraper.js check '<cookie>' [opsi]
Opsi:
 --proxy-file <file> file proxy
 --proxy "h:p,h:p" daftar proxy langsung
 --ua "<string>" paksa User-Agent
 -n, --count <n> jumlah token (default 5)
 -p, --plan <plan> premium | standard | basic
 -o, --out <file> output (default tokens.txt)
 -c, --conc <n> konkuransi (default 25)\`);
`;
const m=analyzeCode(cli,{filename:'nfscraper.js'});const by=Object.fromEntries(m.inputs.map(x=>[x.name,x]));
for(const n of ['command','cookie','proxyFile','proxy','ua','count','plan','out','conc'])assert(by[n],`missing ${n}`);
assert.equal(by.command.type,'select');assert.equal(by.command.required,true);
assert.equal(by.count.type,'number');assert.equal(by.count.required,false);assert.equal(by.count.default,5);
assert.equal(by.plan.type,'select');assert.deepEqual(by.plan.choices,['premium','standard','basic']);
assert.equal(by.out.type,'text');assert.equal(by.out.default,'tokens.txt');
assert.equal(by.cookie.required,false);assert.equal(by.cookie.conditionalRequired,true);assert.deepEqual(by.cookie.requiredWhen.command,['convert','check']);
assert(m.dependencies.includes('axios'),'axios dependency not detected');

const comment=analyzeCode(`// parameter: imageLink:url:required, folder:folder:optional, quality:number:optional\nmodule.exports=async function scrape(imageLink, folder, quality){ return imageLink }`,{filename:'comment.js'});
const cb=Object.fromEntries(comment.inputs.map(x=>[x.name,x]));assert.equal(cb.imageLink.type,'url');assert.equal(cb.imageLink.required,true);assert.equal(cb.folder.type,'folder');assert.equal(cb.folder.required,false);assert.equal(cb.quality.type,'number');
console.log('[AUTO DETECT TEST] PASS — CLI/help/comment/default/optional/dependency cases');
